"""Independent stack contracts, fresh Gforth batches, and generated USL runs."""
from __future__ import annotations
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent


def cases():
    # Contracts are authored here independently of the frontend's word tables.
    # Inputs/outputs use bottom-to-top stack order; -1 is the Forth true flag.
    lo, hi, mask = -(2**63), 2**63-1, 2**64-1
    signed = lambda n: (n & mask) - (2**64 if n & (2**63) else 0)
    flag = lambda b: -int(b)
    binary = {
        '+': lambda a,b:[signed(a+b)], '-':lambda a,b:[signed(a-b)], '*':lambda a,b:[signed(a*b)],
        '/':lambda a,b:[a//b], 'mod':lambda a,b:[a%b], '/mod':lambda a,b:[a%b,a//b],
        'min':lambda a,b:[min(a,b)], 'max':lambda a,b:[max(a,b)],
        '=':lambda a,b:[flag(a==b)], '<>':lambda a,b:[flag(a!=b)],
        '<':lambda a,b:[flag(a<b)], '>':lambda a,b:[flag(a>b)],
        '<=':lambda a,b:[flag(a<=b)], '>=':lambda a,b:[flag(a>=b)],
        'and':lambda a,b:[signed(a&b)], 'or':lambda a,b:[signed(a|b)], 'xor':lambda a,b:[signed(a^b)]}
    unary = {'negate':lambda a:signed(-a), 'abs':lambda a:signed(abs(a)), '1+':lambda a:signed(a+1),
             '1-':lambda a:signed(a-1), '2*':lambda a:signed(2*a), '2/':lambda a:a//2,
             '0=':lambda a:flag(a==0),'0<':lambda a:flag(a<0),'0>':lambda a:flag(a>0),
             '0<>':lambda a:flag(a!=0),'invert':lambda a:signed(~a)}
    groups=[]
    def add(name,body,items,contract):
        groups.append({'name':name,'source':body if body.startswith(':') else ': usl-main '+body+' ;',
                       'contract':contract,'cases':[{'input':list(a),'expected':list(b)} for a,b in items]})
    pairs=list(itertools.product(range(-2,3),repeat=2))+[(lo,1),(hi,1),(hi,2),(lo,2),(lo,-1),(hi,-1),(-7,3),(7,-3)]
    for word,fn in binary.items():
        inputs=[p for p in pairs if word not in {'/','mod','/mod'} or p[1]!=0 and p!=(lo,-1)]
        add('word-'+word,word,[(p,fn(*p)) for p in inputs], 'signed64 cells; wrapping arithmetic; floored quotient/remainder; comparisons produce canonical flags')
    values=list(range(-4,5))+[lo,hi]
    for word,fn in unary.items():add('word-'+word,word,[([a],[fn(a)]) for a in values],'independent unary cell contract, including signed64 boundaries')
    for word in ['lshift','rshift']:
        pairs=list(itertools.product([-3,-1,0,1,7,lo,hi],[0,1,2,31,63]))
        add('word-'+word,word,[(p,[signed(p[0]<<p[1]) if word=='lshift' else signed((p[0]&mask)>>p[1])]) for p in pairs], 'logical shift of the uint64 representation; count 0..63; serialize result as signed64 cell')
    permutations={'dup':([1],[1,1]),'drop':([1],[]),'swap':([1,2],[2,1]),'over':([1,2],[1,2,1]),
                  'rot':([1,2,3],[2,3,1]),'-rot':([1,2,3],[3,1,2]),'nip':([1,2],[2]),'tuck':([1,2],[2,1,2]),
                  '2dup':([1,2],[1,2,1,2]),'2drop':([1,2],[]),'2swap':([1,2,3,4],[3,4,1,2])}
    for word,(before,after) in permutations.items():
        add('word-'+word,word,[(prefix+before,prefix+after) for prefix in [[],[-8,9]]], 'explicit independent stack permutation with untouched lower prefix')
    add('word-depth','depth',[(list(range(n)),list(range(n))+[n]) for n in [0,1,2,8,32,63]],'depth adds the pre-operation stack size')
    for word,value in [('true',-1),('false',0)]:add('word-'+word,word,[([], [value]),([7],[7,value])], 'canonical Forth flag literal')
    add('empty-and-max-stack',': usl-main ;',[(list(range(n)),list(range(n))) for n in [0,1,9,32,64]], 'empty definition preserves all 64 cells, without native display truncation')
    add('absolute-conditional','dup 0< if negate else 0 + then',[([n],[abs(n)]) for n in range(-16,17)],'conditional consumes its flag, exactly one branch executes')
    add('triangular-while','0 swap begin dup 0> while tuck + swap 1- repeat drop',[([n],[n*(n+1)//2]) for n in range(17)],'finite summation equals independent closed-form triangular number')
    add('countdown-until','begin 1- dup 0= until',[([n],[0]) for n in range(1,18)],'until executes body before testing and stops at zero')
    add('defined-square',': square dup * ; : usl-main square ;',[([n],[n*n]) for n in range(-12,13)],'prior definition calls preserve multiplicative intent')
    add('case-comments',': SQUARE ( input -- output ) DUP * ;\n: USL-MAIN \\ line comment\n SQUARE ;',[([-3],[9]),([7],[49])],'case-insensitive words, parenthesized and backslash line comments')
    add('carriage-return-comment',': usl-main \\ comment\r 42 ;',[([], [42])],'backslash comments terminate at CR as well as LF')
    return groups


async def qualify(output, prefix):
    from forth_semantics import Program, WORDS, native_batch
    from semantic_records import resource_admission
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    generated_directory=output/'generated';generated_directory.mkdir(exist_ok=True)
    started=time.perf_counter();groups=cases()
    tested={g['source'].split()[2] for g in groups if g['name'].startswith('word-')}
    if tested!=set(WORDS):raise ValueError('Independent cases do not cover the exact declared word set')
    admission=resource_admission(len(groups),output)
    if not admission['thread_slots']:raise RuntimeError('No safe native process admission capacity')
    pool=ThreadPoolExecutor(max_workers=admission['thread_slots']);loop=asyncio.get_running_loop()
    ready=asyncio.Event();records=[]
    def group_job(g):
        program=Program(g['source'])
        source_key=hashlib.sha256(g['source'].encode()).hexdigest()
        source_file=generated_directory/(source_key+'.fs');generated_file=generated_directory/(source_key+'.usl')
        source_file.write_text(g['source']);generated_file.write_text(program.generated)
        observed,identity=native_batch(g['source'],[r['input'] for r in g['cases']],prefix)
        rows=[]
        for i,(case,native) in enumerate(zip(g['cases'],observed)):
            actual,receipt=program.run(case['input'])
            fresh_syntax = None
            if i==0:
                fresh_syntax,_=program.run(case['input'],cached_syntax=False)
            rows.append({**case,'native':native,'generated_USL':actual,'USL_receipt':receipt,
                         'uncached_syntax_crosscheck':fresh_syntax,
                         'passed':actual==native==case['expected'] and (fresh_syntax is None or fresh_syntax==actual)})
        return {k:v for k,v in g.items() if k!='cases'}|{'records':rows,'native_identity':identity,'generated_USL_sha256':program.artifact_sha256,
            'source_file':str(source_file.relative_to(output)),'generated_file':str(generated_file.relative_to(output))}
    async def actor(g):
        await ready.wait()
        try:return await loop.run_in_executor(pool,group_job,g)
        except Exception as e:return {'name':g['name'],'error':type(e).__name__+': '+str(e),'records':[]}
    tasks=[asyncio.create_task(actor(g)) for g in groups];ready.set()
    try:records=await asyncio.gather(*tasks)
    finally:pool.shutdown(wait=True)
    rows=[r for g in records for r in g['records']]
    failed=[g for g in records if 'error' in g]+[r for r in rows if not r['passed']]
    sources=['forth_semantics.py','qualify_forth.py','inputs/forth-debian.json']
    report={'schema':'usl.forth.selected-stack-profile.v1','catalog_id':'forth','passed':not failed,
            'scope':'Gforth 0.7.3 amd64, signed64 wrapping cells; 44 selected words; prior colon calls; if/else/then, begin/until, begin/while/repeat; pure stack only',
            'limits':{'maximum_live_stack_depth_including_intermediates':64,'definitions':64,'definition_call_depth':24,'control_nesting':24,'source_characters':65536,'USL_operations_per_case':2000000,'USL_seconds_per_case':3},
            'full_standard_qualified':False,'arbitrary_program_correctness_proved':False,
            'fresh_native_processing_cases':len(rows),'fresh_generated_USL_executions':len(rows)+len([g for g in records if 'error' not in g]),
            'independent_intent_cases':len(rows),'fresh_native_processes':sum(g.get('native_identity',{}).get('native_processes',0) for g in records),
            'all_ready_program_actors':len(tasks),'fixed_worker_cap':None,'resource_admission':admission,
            'native_execution_evidence_replayed':False,'pure_AST_reuse':True,'passed_cases':sum(r['passed'] for r in rows),
            'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sources},
            'seconds':time.perf_counter()-started,'outstanding':['all remaining Forth words and libraries','memory, addresses, return stack, exceptions, files, floats, compilation and environment dependencies','all dialects and complete normative audit','whole-profile universal implementation proof and independent review'],'groups':records,'failures':failed}
    (output/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in {'groups','failures'}}))
    if failed:raise ValueError('Forth counterexamples: '+str(failed)[:1500])
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--prefix',type=Path,default=Path('/workspace/.onboarding/forth-v4112'))
    parser.add_argument('--output',type=Path,default=Path('forth-results'))
    args=parser.parse_args();sys.path.insert(0,str(args.source_root.resolve()))
    asyncio.run(qualify(args.output,args.prefix))
