"""Independent original/generated processing via Python's standard JSON parser.

Invoked in isolated Python, imports no project parser or implementation code.
"""
import base64
import json
import sys


class Number(str):
    pass


class Object(list):
    pass


def invalid_constant(value):
    raise ValueError('Non-JSON numeric constant: ' + value)


def ir(value):
    if value is None: return ['null']
    if type(value) is bool: return ['boolean', value]
    if isinstance(value, Number): return ['number', str(value)]
    if isinstance(value, str): return ['string', [ord(c) for c in value]]
    if isinstance(value, Object): return ['object', [[[ord(c) for c in key], ir(item)] for key, item in value]]
    if isinstance(value, list): return ['array', [ir(item) for item in value]]
    raise ValueError('Unexpected native parser value')


def main():
    output = []
    for record in json.load(sys.stdin):
        try:
            data = base64.b64decode(record['base64'])
            if len(data) > 65536:
                raise OverflowError('Declared input-byte limit')
            text = data.decode('utf-8')
            if text.startswith('\ufeff'): text = text[1:]
            value = json.loads(text, parse_int=Number, parse_float=Number,
                               parse_constant=invalid_constant, object_pairs_hook=Object, strict=True)
            stack = [(value, 0)];nodes = 0
            while stack:
                item, depth = stack.pop();nodes += 1
                if depth > 40 or nodes > 10000:
                    raise OverflowError('Declared depth/node limit')
                if isinstance(item, Number) and len(item) > 1024:
                    raise OverflowError('Declared number-length limit')
                if isinstance(item, str) and not isinstance(item, Number) and len(item) > 8192:
                    raise OverflowError('Declared string-length limit')
                if isinstance(item, Object):
                    for key, child in item:
                        if len(key) > 8192:
                            raise OverflowError('Declared member-name length limit')
                        stack.append((child, depth + 1))
                elif isinstance(item, list):
                    stack.extend((child, depth + 1) for child in item)
            output.append({'id': record['id'], 'accepted': True, 'IR': ir(value)})
        except (RecursionError, MemoryError, OverflowError) as error:
            output.append({'id': record['id'], 'accepted': None, 'resource_limit': type(error).__name__})
        except (ValueError, UnicodeError) as error:
            output.append({'id': record['id'], 'accepted': False, 'error': type(error).__name__})
    json.dump(output, sys.stdout, ensure_ascii=True)


if __name__ == '__main__':
    main()
