: SQUARE ( input -- output ) DUP * ;
: USL-MAIN \ line comment
 SQUARE ;