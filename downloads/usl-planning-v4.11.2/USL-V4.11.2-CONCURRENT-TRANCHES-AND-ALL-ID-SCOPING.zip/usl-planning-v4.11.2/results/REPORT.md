# Conditional USL project schedule

This is an editable budget model, not an empirically calibrated completion forecast.

The snapshot has **247/606 scoped IDs**, **359 without a scoped profile**, **0 full standards**, and **0/21 completed entity tracks**. Existing scopes do not close whole-language obligations.

All 606 IDs have 15 generic prerequisite steps and 18 obligation dimensions. Exact version/dialect/library audits remain open; these templates are not completed normative audits.

## Conditional engineering budgets

Assumed 32 productive hours per lane per week. A lane is effective engineering capacity, not a virtual worker, CPU, or promise of autonomous work. Numbers below are hypothetical list schedules, with no host/license waits or newly discovered requirements. Cases are workload stress tests; none is a probability interval or asserted best/worst bound.

Counts are unrestricted positive integers supplied through --lanes. With no choices, comparisons use one baseline lane and the actual work-node count. These are simulation assumptions, not installed engineering resources.

| Milestone | Budget case | Engineering hours | Requested lanes | Simulated duration | Peak concurrent tasks |
|---|---|---:|---:|---:|---:|
| remaining_scoped_profiles | lean | 2,078 | 1 | 64.9 weeks | 1 |
| remaining_scoped_profiles | lean | 2,078 | 137 | 1.4 weeks | 137 |
| remaining_scoped_profiles | lean | 2,078 | 607 | 1.2 weeks | 359 |
| remaining_scoped_profiles | lean | 2,078 | 10,926 | 1.2 weeks | 359 |
| remaining_scoped_profiles | lean | 2,078 | 1,000,000,000,000,000,000 | 1.2 weeks | 359 |
| remaining_scoped_profiles | reference | 8,312 | 1 | 5.0 years | 1 |
| remaining_scoped_profiles | reference | 8,312 | 137 | 5.6 weeks | 137 |
| remaining_scoped_profiles | reference | 8,312 | 607 | 4.8 weeks | 359 |
| remaining_scoped_profiles | reference | 8,312 | 10,926 | 4.8 weeks | 359 |
| remaining_scoped_profiles | reference | 8,312 | 1,000,000,000,000,000,000 | 4.8 weeks | 359 |
| remaining_scoped_profiles | large | 33,248 | 1 | 20.0 years | 1 |
| remaining_scoped_profiles | large | 33,248 | 137 | 22.4 weeks | 137 |
| remaining_scoped_profiles | large | 33,248 | 607 | 19.4 weeks | 359 |
| remaining_scoped_profiles | large | 33,248 | 10,926 | 19.4 weeks | 359 |
| remaining_scoped_profiles | large | 33,248 | 1,000,000,000,000,000,000 | 19.4 weeks | 359 |
| full_pinned_profiles | lean | 138,320 | 1 | 83.1 years | 1 |
| full_pinned_profiles | lean | 138,320 | 137 | 47.6 weeks | 137 |
| full_pinned_profiles | lean | 138,320 | 607 | 40.9 weeks | 607 |
| full_pinned_profiles | lean | 138,320 | 10,926 | 40.9 weeks | 669 |
| full_pinned_profiles | lean | 138,320 | 1,000,000,000,000,000,000 | 40.9 weeks | 669 |
| full_pinned_profiles | reference | 553,280 | 1 | 332.5 years | 1 |
| full_pinned_profiles | reference | 553,280 | 137 | 3.7 years | 137 |
| full_pinned_profiles | reference | 553,280 | 607 | 3.1 years | 607 |
| full_pinned_profiles | reference | 553,280 | 10,926 | 3.1 years | 669 |
| full_pinned_profiles | reference | 553,280 | 1,000,000,000,000,000,000 | 3.1 years | 669 |
| full_pinned_profiles | large | 2,213,120 | 1 | 1330.0 years | 1 |
| full_pinned_profiles | large | 2,213,120 | 137 | 14.7 years | 137 |
| full_pinned_profiles | large | 2,213,120 | 607 | 12.6 years | 607 |
| full_pinned_profiles | large | 2,213,120 | 10,926 | 12.6 years | 669 |
| full_pinned_profiles | large | 2,213,120 | 1,000,000,000,000,000,000 | 12.6 years | 669 |

A full-profile budget includes the remaining whole-standard work for every original ID, including IDs with bounded scopes. Do not add the scoped milestone to that budget. Formats, logs and templates need their category-specific processing contract; many are not executable programming languages.

Shared family-core work is budgeted once. Per-ID semantics, independent tests and qualification remain separate. The proposed family reuse and hour allocations are assumptions, not proven compatible semantic artifacts or measured velocity.

## Why no committed full-project finish date

Full pinned-version language support has no measured completion rate yet. Nine IDs carry external host/license records; applicability still needs audit. The complete entity objective also has unbounded research/acceptance questions and unprovided devices/models. All 21 track next actions and dependencies remain in ENTITY_TRACKS.json. External waits and entity effort are unknown, not zero.

Universal termination/equivalence proofs for arbitrary programs cannot be guaranteed. Intent proof requires a formal contract and a supported proof domain; other cases must report unknown. Human-equivalent abilities and open-ended future learning do not currently define a finite, testable finish gate. These limitations keep the original whole-project ETA null.

## Partial workers and resource recovery

All 10,926 ID/dimension actors may be live concurrently, while physical jobs use measured resource admission. The existing qualification run coalesced 60 ID checks into 32 process jobs, preserved every ID's fresh checks, and built 414 exact pure artifacts for 10,926 logical requests. These figures do not measure compiler engineering productivity.

Overhead recovery: speedup = (1 + overhead/useful_work) / (1 + remaining_overhead/useful_work). Recovering half of 20% overhead gives 1.091×, not extra hardware. A hypothetical 5× speedup for 60% of engineering work gives 1.923× overall under Amdahl. Future skills and hosts receive no guaranteed credit before measurement.

Hardware discovery is read-only for this run. Registered remote capacity is counted only with explicit authorization, compatible workload support, and qualification evidence. There is no automatic network scan, paid allocation, or assumption that interacting with a device grants access to its resources.

## Fastest evidence-based route

1. Pin each ID's specification/version/category and convert the 15 template steps into actual chapter/feature/library obligations. Start license/platform requests alongside independent implementation work.
2. Maintain all logical workers, share exact pure artifacts by complete identity, and admit native jobs using live CPU/memory/I/O measurements. Never merge distinct program effects or replay execution evidence.
3. Build the shared IR and compatible family cores once, then implement per-ID deviations, native hosts, libraries, interop and independently authored intent contracts.
4. Qualify bounded profiles while full conformance remains open. Record active engineering hours, integration/review/rework and feature throughput for representative complex and simple IDs.
5. Replace every assumed hour budget with those observations. Compare sequential, parallel and collapsed routes end to end; promote improvements only after heldout correctness and cost checks. Report a calibrated forecast only when the audited scope and observed rate support it.

## Run

```bash
source /workspace/.onboarding/activate-usl.sh
python planner.py --source-root /workspace/usl-v4.10.0-clean-test --catalog joined-results/catalog.json --output results
python -m unittest -v test_planner test_semantics
```

Elsewhere, supply the extracted v4.10 runtime with its dependencies installed. The planner models work; qualify_forth.py and qualify_antlr.py perform separate fresh native qualifications. See assumptions.json, FAMILY_PLAN.csv, ALL_606_STEPS.json, capacity.json and results.json. The original snapshot files' SHA-256 identities are retained in inputs/provenance.json.
