"""Standalone restore of the exact Java generator and its seven jar packages."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parent


def restore(destination,archives):
    destination,archives=Path(destination),Path(archives)
    destination.mkdir(parents=True,exist_ok=True);archives.mkdir(parents=True,exist_ok=True)
    records=json.loads((ROOT/'inputs/antlr-java-debian.json').read_text())['packages']
    def obtain(r):
        path=archives/Path(r['Filename']).name
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=r['SHA256']:
            with urllib.request.urlopen('https://deb.debian.org/debian/'+urllib.parse.quote(r['Filename'],safe='/+'),timeout=45) as response:body=response.read()
            if len(body)!=int(r['Size']) or hashlib.sha256(body).hexdigest()!=r['SHA256']:raise ValueError('Java provider integrity failure: '+r['Package'])
            path.write_bytes(body)
        return path
    with ThreadPoolExecutor(max_workers=len(records)) as pool:paths=list(pool.map(obtain,records))
    for path in paths:subprocess.run(['dpkg-deb','--extract',str(path),str(destination)],check=True)
    report={'passed':True,'packages_verified':len(paths),'jar_directory':str(destination/'usr/share/java'),'requires_host':'compatible Java runtime; no native Java binary shipped'}
    print(json.dumps(report));return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--destination',type=Path,default=Path('/workspace/.onboarding/expansion-v411/sysroot'))
    p.add_argument('--archives',type=Path,default=Path('/workspace/.onboarding/expansion-v411/debs'))
    a=p.parse_args();restore(a.destination,a.archives)
