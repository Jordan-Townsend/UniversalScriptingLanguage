import sys
from pathlib import Path
import unittest

if not any(Path(p, 'usl_systems').is_dir() for p in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from json_semantics import JSONResourceLimit, JSONRuleError, generate_json, parse_json, run_usl


class JSONSemanticsTests(unittest.TestCase):
    def test_lossless_numbers_and_duplicate_members(self):
        text = b'{"a":1E400,"a":-0.000e+123,"b":9007199254740993}'
        value = parse_json(text)
        self.assertEqual(value, ['object', [[[97], ['number', '1E400']], [[97], ['number', '-0.000e+123']], [[98], ['number', '9007199254740993']]]])
        self.assertEqual(run_usl(value), value)
        self.assertEqual(parse_json(generate_json(value, 'preserve')), value)
        with self.assertRaises(JSONRuleError):
            generate_json(value)

    def test_surrogate_pair_lone_surrogate_and_escaped_member_identity(self):
        self.assertEqual(parse_json(b'"\\uD834\\uDD1E"'), ['string', [0x1D11E]])
        lone = ['string', [0xD800]]
        self.assertEqual(parse_json(generate_json(lone)), lone)
        value = parse_json(b'{"a":1,"\\u0061":2}')
        with self.assertRaises(JSONRuleError):
            generate_json(value)

    def test_all_scalar_roots_and_raw_slash(self):
        for text in [b'null', b'true', b'false', b'12', b'"/"', b'[]', b'{}']:
            value = parse_json(text)
            self.assertEqual(parse_json(generate_json(run_usl(value))), value)

    def test_invalid_syntax_and_encoding(self):
        for text in [b'01', b'+1', b'NaN', b'Infinity', b'[1,]', b'{"a":}', b'{a:1}', b'"a\x00b"', b'"\\x20"', b'true false', b'"\xff"', b'\x00n\x00u\x00l\x00l', b'\xc0\xaf']:
            with self.subTest(text=text), self.assertRaises(JSONRuleError):
                parse_json(text)

    def test_BOM_ignored_on_input_and_absent_on_output(self):
        value = parse_json(b'\xef\xbb\xbfnull')
        self.assertEqual(generate_json(value), b'null')

    def test_resource_limits_are_distinguished_from_syntax(self):
        with self.assertRaises(JSONResourceLimit):
            parse_json(b'[' * 41 + b'0' + b']' * 41)
        with self.assertRaises(JSONResourceLimit):
            parse_json(b'"' + b'a' * 8193 + b'"')

    def test_bad_IR_never_generates_invalid_JSON(self):
        for value in [['number', 'NaN'], ['number', '01'], ['boolean', 1], ['string', [-1]], ['null', 0], ['array', None]]:
            with self.assertRaises(JSONRuleError):
                generate_json(value)

    def test_independent_review_surrogate_pair_counterexample_rejected(self):
        with self.assertRaises(JSONRuleError):
            generate_json(['string', [0xD800, 0xDC00]])

    def test_independent_review_unicode_expansion_counterexample_fixed(self):
        source = ('"' + '\U0001F600' * 8192 + '"').encode('utf-8')
        value = parse_json(source)
        output = generate_json(value)
        self.assertLessEqual(len(output), 65536)
        self.assertEqual(parse_json(output), value)


if __name__ == '__main__':
    unittest.main()
