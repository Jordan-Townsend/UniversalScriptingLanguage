"""Query compact, hash-linked views; full records and failures stay available."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def build(directory, selected=None):
    from usl_systems.language import Interpreter
    directory = Path(directory)
    source = directory / 'SEMANTIC_RECORDS.json'
    document = json.loads(source.read_text())
    wanted = set(selected or [r['catalog_id'] for r in document['records']])
    records = [r for r in document['records'] if r['catalog_id'] in wanted]
    if {r['catalog_id'] for r in records} != wanted:
        raise ValueError('Unknown requested catalog ID')
    thin = [{'id': r['catalog_id'], 'family': r['family'], 'scope': r['prior_scoped_profile'],
             'references': r['document_objects'], 'syntax': r['syntax_objects'],
             'missing_rules': not r['semantic_records']['complete'],
             'blockers': [{'id': b['blocker_sha256'], 'kind': b['kind']} for b in r['unresolved_blockers']]} for r in records]
    value = {'full_records': str(source), 'full_records_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
             'view_kind': 'selected context view; full data retained separately; not a lossless replacement',
             'qualification_overlay': '../RULE_SET_PROGRESS.json', 'records': thin}
    body = json.dumps(value, separators=(',', ':')).encode()
    inputs = {'selected_count': len(records), 'distinct_ID_count': len({r['id'] for r in thin}),
              'full_records_retained': source.exists(), 'source_bytes': source.stat().st_size, 'view_bytes': len(body)}
    result = Interpreter(capabilities={'context_view': lambda: inputs}, timeout=2, max_ops=4000).run((ROOT / 'context_pack.usl').read_text())
    metrics = result.variables['result']
    if abs(metrics['byte_reduction_fraction'] - (1 - len(body) / source.stat().st_size)) > 1e-12:
        raise ValueError('USL context compaction arithmetic disagreement')
    return value, {**metrics, 'source_bytes': source.stat().st_size, 'view_bytes': len(body),
                   'actual_USL_execution': True, 'token_count_measured': False, 'full_evidence_not_deleted': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--records', type=Path, default=ROOT / 'semantic-records-final')
    parser.add_argument('--ids', help='Comma-separated exact catalog IDs; default all607')
    parser.add_argument('--output', type=Path, default=Path('CONTEXT_VIEW.json'))
    args = parser.parse_args();sys.path.insert(0, str(args.source_root.resolve()))
    value, metrics = build(args.records, args.ids.split(',') if args.ids else None)
    args.output.write_text(json.dumps(value, separators=(',', ':')) + '\n')
    args.output.with_suffix('.metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
    print(json.dumps(metrics))
