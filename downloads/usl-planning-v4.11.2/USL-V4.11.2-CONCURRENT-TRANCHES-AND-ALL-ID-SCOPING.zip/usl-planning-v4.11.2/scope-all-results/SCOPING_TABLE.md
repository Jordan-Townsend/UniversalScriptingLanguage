# All-ID scoping ledger

Every remaining ID has a candidate host, specific semantic questions, source locators where available, native/intent contracts, and unresolved gates. These are implementation plans; exact normative rule sets and full-standard qualification remain open.

| Family | Remaining IDs |
|---|---:|
| .NET managed languages | 3 |
| Array, numerical and statistical | 23 |
| Assembly and intermediate representations | 10 |
| BASIC and business procedural | 14 |
| BEAM languages | 1 |
| Configuration, build and deployment | 36 |
| Domain-specific and classification pending | 42 |
| Esoteric languages | 3 |
| Grammars, interfaces and schemas | 30 |
| HDL, shaders and compute | 8 |
| JVM and managed object languages | 8 |
| Lisp and related languages | 8 |
| Logic, proof and verification | 17 |
| ML/Haskell and typed functional | 14 |
| Markup, documents and styles | 9 |
| SQL and query languages | 20 |
| Scripting and general application languages | 50 |
| Shell and automation languages | 7 |
| Stack and concatenative languages | 3 |
| Systems and native imperative | 22 |
| Templates and composite sources | 34 |

| ID | Candidate host | Specific semantic work | References / parser |
|---|---|---|---|
| abap | SAP ABAP application server | internal tables; field symbols; Open SQL and transactions | 0 docs / no |
| actionscript | Apache Flex ASC or historical AVM1 host | ActionScript 1/2 identity; AVM1 coercions; Flash display and event model | 0 docs / no |
| actionscript3 | Apache Flex compiler and AVM2 host | ECMA-357 and AS3 types; prototype versus sealed classes; AVM2 events | 1 docs / no |
| adl | OpenEHR ADL tools or correct catalog ADL host after identity audit | ADL identity; constraint semantics; model and terminology dependencies | 1 docs / no |
| agda | Agda compiler with GHC | dependent typing; termination/positivity; backend erasure and standard library | 0 docs / no |
| aheui | aheui upstream interpreter | Hangul instruction decoding; storage selection; direction and integer/I/O rules | 1 docs / no |
| alloy | Alloy Analyzer | relational bounds; integer bitwidth; SAT scope versus unbounded claims | 0 docs / no |
| ambienttalk | AmbientTalk interpreter on JVM | actor isolation; eventual references; offline service discovery | 1 docs / no |
| amdgpu | LLVM AMDGPU assembler/backend plus compatible GPU | target ISA and wavefront; address spaces; barriers and device execution | 1 docs / no |
| ampl | authorized AMPL plus solver | algebraic model expansion; data/sets; solver status and numeric tolerance | 0 docs / no |
| androidbp | Android Soong | module/property typing; dependency variants; generated build graph and Android tree | 1 docs / no |
| ansys | authorized ANSYS APDL host | parameter and command state; element/material models; solver and license dependencies | 0 docs / no |
| antlr-actionscript | ANTLR 3 ActionScript target plus AVM2 host | ANTLR target revision; token/lexer behavior; generated AS runtime | 1 docs / no |
| antlr-cpp | ANTLR 4 tool and C++ runtime | target version match; lexer/prediction/recovery; generated C++ API and ABI | 1 docs / no |
| antlr-csharp | ANTLR 3/4 CSharp target audited separately | ANTLR generation version; prediction/recovery; matching CSharp runtime | 1 docs / no |
| antlr-objc | ANTLR 3 Objective-C target | legacy target availability; token ownership; Cocoa runtime/platform dependency | 1 docs / no |
| antlr-perl | ANTLR 3 Perl target | target support status; token streams; generated Perl runtime behavior | 1 docs / no |
| antlr-python | ANTLR 3 Python or ANTLR 4 Python3 separately | generator/runtime version match; lexer/prediction/recovery; Unicode and EOF | 1 docs / no |
| antlr-ruby | ANTLR 3 Ruby target | target revision; tree construction; generated Ruby runtime compatibility | 1 docs / no |
| apacheconf | Apache httpd configuration checker and test server | directive context/merge; module set; request routing and permissions | 1 docs / no |
| apl | GNU APL or Dyalog separately | array rank/shape; origin/tolerance; dialect primitives and nested arrays | 0 docs / no |
| applescript | macOS osascript host | application dictionaries; object specifiers; Apple events and permissions | 1 docs / no |
| arduino | arduino-cli and selected board toolchain | board/core identity; setup/loop timing; pin/peripheral libraries and device ABI | 0 docs / no |
| arrow | py-arrow-lang interpreter | Arrow package version; function/control evaluation; value types and Python host boundary | 1 docs / no |
| arturo | Arturo interpreter | stack/evaluation rules; symbol binding; native built-ins and modules | 0 docs / no |
| aspectj | AspectJ compiler and JVM | joinpoint/pointcut matching; advice precedence; weaving and bytecode effects | 0 docs / no |
| aspx-cs | ASP.NET Framework with CSharp on authorized compatible host | page lifecycle; CSharp code-behind; HTTP/session and server controls | 1 docs / no |
| aspx-vb | ASP.NET Framework with Visual Basic on authorized compatible host | page lifecycle; VB code-behind; HTTP/session and server controls | 1 docs / no |
| asymptote | Asymptote compiler | numeric geometry; module imports; graphics output and TeX dependencies | 0 docs / no |
| augeas | Augeas augtool and lens compiler | lens bidirectionality; tree paths; file roundtrip and error contracts | 1 docs / no |
| autohotkey | AutoHotkey v1/v2 separately on Windows | syntax/version split; hotkey and GUI event loop; Windows APIs | 0 docs / no |
| autoit | AutoIt on Windows | Variant coercions; GUI/COM and process automation; exact Windows runtime | 1 docs / no |
| bare | BARE upstream implementation plus chosen target language | schema grammar; integer/union encoding; canonical and invalid message behavior | 1 docs / no |
| basemake | POSIX make subset with selected GNU/BSD host | base rules versus preprocessing extensions; dependency/recipe execution; filesystem timestamps and errors | 0 docs / no |
| batch | Windows cmd.exe | percent/delayed expansion; quoting and errorlevel; filesystem/process effects | 0 docs / no |
| bbcbasic | BBC BASIC SDL edition or Brandy | BBC dialect differences; numeric formats; graphics and OS calls | 1 docs / no |
| bdd | Behave/Cucumber-compatible scenario runner after dialect audit | Given/When/Then bindings; scenario outlines and examples; actual step effects and assertions | 0 docs / no |
| befunge | Befunge-93 or Funge-98 host separately | playfield dimensions; self-modifying space; stack and nondeterministic direction | 0 docs / no |
| berry | Berry interpreter | compact VM types; class dispatch; embedded host bindings | 1 docs / no |
| blitzbasic | legacy BlitzBasic Windows host | BASIC dialect; graphics loop; Windows runtime ABI | 0 docs / no |
| blitzmax | BlitzMax NG | object and module rules; garbage collection; native linking | 0 docs / no |
| blueprint | GNOME Blueprint compiler | UI widget/type references; XML UI lowering; GTK version | 1 docs / no |
| bnf | chosen BNF dialect and parser generator | metasyntax identity; ambiguity and recursion; parse-result contract | 0 docs / no |
| boa | Boa compiler and dataset host | aggregator semantics; input dataset schema; distributed query execution | 0 docs / no |
| boo | Boo compiler and compatible CLR | duck/static typing; macros; CLR assemblies and exception behavior | 1 docs / no |
| boogie | Boogie and supported Z3 | verification condition generation; heap/map axioms; solver/trusted assumptions | 1 docs / no |
| bqn | CBQN | array rank/fill; modifiers and trains; numeric/Unicode and system functions | 1 docs / no |
| bst | BibTeX style interpreter | stack primitives; bibliography sorting; entry/global state and output formatting | 1 docs / no |
| bugs | OpenBUGS or WinBUGS separately | stochastic graph construction; distributions; sampler settings and convergence | 0 docs / no |
| ca65 | cc65 ca65 assembler and target emulator | CPU dialect/addressing; relocations; linked machine behavior | 1 docs / no |
| cadl | OpenEHR cADL constraint parser | ADL 1.4 versus ADL 2; complex object/attribute constraints; archetype and reference model validation | 1 docs / no |
| camkes | seL4 CAmkES toolchain | component/connector composition; capability generation; seL4 ABI and configuration | 1 docs / no |
| capdl | seL4 capDL toolchain | capability graph validity; kernel object sizes; target-architecture loader behavior | 0 docs / no |
| carbon | Carbon explorer/toolchain | experimental revision; generics and value categories; C++ interoperability | 1 docs / no |
| cbmbas | VICE Commodore BASIC host | machine model; tokenized lines; PEEK/POKE and screen state | 0 docs / no |
| cddl | CDDL RFC 8610 validator | group/type choices; control operators; CBOR/JSON data and extension RFCs | 1 docs / no |
| ceylon | Ceylon toolchain with compatible JVM | union/intersection types; module resolution; JVM/JS backend semantics | 0 docs / no |
| cfc | Lucee or Adobe ColdFusion component host | component inheritance and access; CFML scopes; serialization and remote calls | 1 docs / no |
| cfengine3 | CFEngine Community | promise evaluation; classes/variables; idempotent managed-state convergence | 0 docs / no |
| cfm | Lucee or Adobe ColdFusion page host | tag/script integration; variable scope; HTTP/database output effects | 1 docs / no |
| cfs | Lucee or Adobe ColdFusion CFScript | CFML engine/dialect; scopes/coercions; database/web effects | 1 docs / no |
| chaiscript | ChaiScript C++ embedding | dynamic dispatch; boxed values; C++ registration and ownership | 1 docs / no |
| chapel | Chapel compiler | locale and task semantics; array domains; distributed runtime and reductions | 1 docs / no |
| charmci | Charm++ charmxi and C++ | interface messages; entry methods; migration and distributed object ordering | 0 docs / no |
| cirru | Cirru parser plus chosen evaluator | tree syntax versus evaluator identity; indentation; data/semantic host contract | 1 docs / no |
| clay | Clay compiler pinned historical LLVM | overload/static evaluation; value and reference rules; LLVM/ABI compatibility | 1 docs / no |
| clean | Clean compiler | uniqueness types; lazy graph reduction; world/file effects | 1 docs / no |
| clojurescript | ClojureScript compiler and JavaScript host | persistent values; macros and protocols; JS interop and async semantics | 1 docs / no |
| codeql | CodeQL CLI and language extractor | database schema; relational fixpoints; library and extraction provenance | 1 docs / no |
| comal | OpenCOMAL candidate | line and block syntax; numeric model; procedure parameter passing | 0 docs / no |
| componentpascal | BlackBox Component Builder or Gardens Point Component Pascal | module visibility; extensible records; runtime and platform bindings | 0 docs / no |
| coq | Coq/Rocq pinned historical/current profile | kernel and universes; tactics versus proof terms; extraction and axioms | 1 docs / no |
| cplint | cplint on SWI-Prolog | probabilistic clause independence; inference mode; sampling seeds and evidence | 1 docs / no |
| cpsa | CPSA analyzer | strand algebra; penetrator assumptions; shape analysis and protocol claims | 1 docs / no |
| crmsh | crmsh with Pacemaker test cluster | CIB schema; resource/constraint meaning; cluster quorum and side effects | 1 docs / no |
| croc | Croc compiler/runtime | closures and coroutines; classes; native API and garbage collection | 0 docs / no |
| cryptol | Cryptol REPL and SMT solver | bitvector widths; sequence polymorphism; totality and solver assumptions | 0 docs / no |
| csound | Csound orchestra compiler | audio/control/init rates; opcode state; sample/block timing and plugin versions | 1 docs / no |
| csound-document | Csound unified document processor | CSD sections; options/orchestra/score composition; render configuration | 1 docs / no |
| csound-score | Csound score processor | event timing; carry and tempo; instrument/render coupling | 1 docs / no |
| css+lasso | Lasso engine plus CSS parser | template escape context; generated stylesheet; Lasso runtime/coercions | 0 docs / no |
| css+mozpreproc | Mozilla preprocessor plus CSS parser | directive expansion; CSS tokens; generated stylesheet equivalence | 1 docs / no |
| css+myghty | Myghty plus historical Python and CSS parser | component calls; escaping/context; generated CSS and Python version | 0 docs / no |
| cuda | NVIDIA CUDA toolkit and compatible device | host/device separation; memory model; SIMT/barriers and numeric behavior | 1 docs / no |
| cypher | Neo4j or openCypher host | dialect/revision; graph/path matching; null/order and transaction behavior | 0 docs / no |
| dart | Dart SDK | null safety; isolates and futures; package and platform libraries | 1 docs / no |
| dasm16 | DCPU-16 assembler and emulator | ISA revision; instruction/operand encoding; word wrap and device interrupts | 0 docs / no |
| dax | Power BI/Analysis Services DAX host | row/filter context; relationships; blank and aggregation semantics | 1 docs / no |
| devicetree | Device Tree Compiler plus target binding schemas | cell sizes/phandles; overlays; binding validation and device ABI | 1 docs / no |
| dg | pyos/dg compiler on compatible Python | prefix grammar; Python-version lowering; closures and macro-like constructs | 0 docs / no |
| docker | Dockerfile frontend and authorized container host | build stages/context; cache semantics; runtime/image and filesystem effects | 0 docs / no |
| duel | DUEL compiler plus Java/JavaScript hosts | view/code split; data binding; client/server rendering correspondence | 1 docs / no |
| dylan | Open Dylan | generic method dispatch; type constraints; libraries and native FFI | 1 docs / no |
| dylan-lid | Open Dylan library builder | build descriptor keys; library/module resolution; native link outputs | 1 docs / no |
| earl-grey | Earl Grey compiler on Node | macro expansion; lexical bindings; generated JavaScript behavior | 1 docs / no |
| easytrieve | authorized Broadcom Easytrieve host | record layouts; report processing; file and mainframe facilities | 0 docs / no |
| ec | Ecere SDK eC compiler | class/property semantics; reflection; C ABI and framework effects | 1 docs / no |
| ecl | HPCC ECL compiler and cluster host | lazy dataset transformations; distribution; record layouts and cluster actions | 0 docs / no |
| eiffel | Gobo Eiffel or EiffelStudio | contracts; inheritance and rename/select; exception and void safety | 1 docs / no |
| elm | Elm compiler and JavaScript host | type inference; Elm architecture effects; package and browser runtime | 1 docs / no |
| elpi | ELPI interpreter | lambda-Prolog binding; higher-order unification; constraints and host API | 1 docs / no |
| emacs-lisp | Emacs batch | dynamic/lexical binding; buffer/current state; reader and host primitives | 0 docs / no |
| evoque | Evoque template engine on compatible Python | template scoping; quoting/escaping; includes and Python host behavior | 0 docs / no |
| execline | skarnet execline tools | argv transformation; environment scoping; Unix process/exit semantics | 1 docs / no |
| extempore | Extempore runtime and LLVM | Scheme versus xtlang boundary; temporal scheduling; native/audio bindings | 0 docs / no |
| ezhil | Ezhil interpreter | Tamil tokenization; value conversions; Python-host library boundary | 0 docs / no |
| factor | Factor distribution | stack effect inference; combinators; vocabulary/image and native FFI | 1 docs / no |
| fan | Fantom SDK | nullable types and mixins; pods; JVM/CLR/JS backend distinction | 0 docs / no |
| fancy | Fancy on compatible Rubinius | message sends; blocks and classes; Rubinius-version dependencies | 1 docs / no |
| felix | Felix compiler with C++ | typed control flow; coroutines; generated C++ and native FFI | 0 docs / no |
| fift | TON Fift interpreter | stack and dictionary words; cell/builder/slice values; TVM serialization and libraries | 1 docs / no |
| flatline | BigML Flatline expression interpreter/API | Lisp-like expression evaluation; field/missing-value rules; BigML data and model bindings | 1 docs / no |
| floscript | ioflo FloScript parser/runtime | framer/frame transitions; deed and share resolution; scheduling and external actor effects | 1 docs / no |
| forth | Gforth or chosen Forth standard host | cell and division model; dictionary/immediate words; stacks, I/O and memory | 0 docs / no |
| foxpro | authorized Visual FoxPro host | xBase records; work areas and indexes; Windows COM behavior | 1 docs / no |
| freefem | FreeFEM | finite element spaces; variational assembly; solver tolerance and mesh behavior | 1 docs / no |
| fsharp | .NET FSharp compiler | computation expressions; CLR representation; async/task exceptions and libraries | 1 docs / no |
| fstar | F* and supported SMT solver | refinement/effect checking; extraction target; trusted code and solver assumptions | 1 docs / no |
| func | TON FunC compiler and TVM | cell/slice and integer semantics; TVM exceptions; gas and blockchain state | 0 docs / no |
| futhark | Futhark compiler and selected C/OpenCL/CUDA backend | uniqueness and size types; array fusion; floating/parallel reduction order | 1 docs / no |
| gdscript | Godot headless | Godot 3 versus 4; Variant and typed values; scene and signal lifecycle | 0 docs / no |
| gleam | Gleam with Erlang or JavaScript backend | typed immutable values; BEAM/JS differences; runtime libraries and interoperation | 1 docs / no |
| glsl | glslang plus Vulkan/OpenGL implementation | GLSL version/stage; layout and precision; shader pipeline execution | 0 docs / no |
| golo | Golo JVM compiler | dynamic invocation; closures; JVM type/library interoperation | 0 docs / no |
| gooddata-cl | GoodData CloudConnect/CL identity to audit | catalog dialect; dimensional/metric model; service query and license host | 0 docs / no |
| googlesql | BigQuery GoogleSQL or ZetaSQL reference engine | service versus core dialect; null/types; aggregation/time and remote features | 1 docs / no |
| gosu | Gosu compiler and JVM | enhancements and type loaders; properties; Java interoperability | 1 docs / no |
| gsql | TigerGraph GSQL host | graph schema; accumulators; parallel traversal and service behavior | 0 docs / no |
| gst | Gosu template engine and JVM | Gosu interpolation and directives; template parameters/scope; JVM-backed rendered output and escaping | 1 docs / no |
| haml | Haml Ruby engine | indentation and filters; interpolation escaping; Ruby code and HTML output | 1 docs / no |
| hare | Hare toolchain | tagged unions and slices; allocation/errors; Unix ABI and target support | 1 docs / no |
| haxeml | Haxe compiler HXML input | flag accumulation; target and defines; build/run semantics | 0 docs / no |
| hlsl | DXC plus Direct3D/Vulkan implementation | shader model and stage; resource binding; wave/memory and floating behavior | 1 docs / no |
| hsail | HSAIL tools and compatible historical HSA runtime | ISA revision; memory ordering; executable device/runtime availability | 0 docs / no |
| hspec | Hspec on GHC | test DSL embedding; exception/failure semantics; random property seeds | 1 docs / no |
| html+evoque | Evoque plus HTML processing | HTML escape context; template scoping; include and rendering behavior | 0 docs / no |
| html+lasso | Lasso plus HTML processing | embedded code boundaries; request scopes; HTML escaping and rendering | 0 docs / no |
| html+myghty | Myghty plus historical Python and HTML processing | component/argument rules; HTML escaping; Python host state | 0 docs / no |
| html+ng2 | Angular compiler and browser/SSR host | HTML parse boundaries; binding/type checking; DOM and hydration effects | 0 docs / no |
| hybris | Hybris upstream interpreter identity to resolve | language identity; object behavior; extension/module interface | 1 docs / no |
| i6t | Inform 6 template preprocessor and Inform 7 toolchain | template directives; insertion order; generated story VM semantics | 0 docs / no |
| icon | University of Arizona Icon or Unicon compatibility mode | goal-directed evaluation; generators and failure; string scanning | 0 docs / no |
| idl | NV5 IDL versus GDL compatibility | array indexing/order; numeric promotion; graphics and proprietary routines | 0 docs / no |
| idris | Idris 1 versus Idris 2 separately | dependent elaboration; totality; erasure and selected backend runtime | 1 docs / no |
| igor | authorized Igor Pro host | wave data/types; operation/function distinction; analysis and graph state | 1 docs / no |
| inform6 | Inform 6 compiler and Z-machine/Glulx interpreter | object/property lookup; target word sizes; story I/O and virtual machine | 1 docs / no |
| inform7 | Inform 7 compiler and story VM | rulebook ordering; world model; generated Inform 6 and story interpreter | 0 docs / no |
| io | Io VM | prototype lookup; message evaluation; coroutine and collector behavior | 1 docs / no |
| ioke | Ioke JVM or CLR implementation | prototype cells; restart conditions; message-chain evaluation | 1 docs / no |
| isabelle | Isabelle distribution | object logic/session identity; proof kernel; code generation and trusted tools | 1 docs / no |
| j | Jsoftware J engine | rank/agreement; trains/modifiers; numeric precision and locales | 1 docs / no |
| jags | JAGS | BUGS dialect; distribution parametrization; MCMC adaptation and stochastic evidence | 1 docs / no |
| janet | Janet interpreter | mutable/immutable data; fibers; macro expansion and C embedding | 1 docs / no |
| jasmin | Jasmin assembler plus JVM | classfile version; stack/local verification; JVM instruction and exception behavior | 1 docs / no |
| javascript+lasso | Lasso plus JavaScript host | string/code escaping; server evaluation; generated JS execution | 0 docs / no |
| javascript+mozpreproc | Mozilla preprocessor plus JavaScript host | directive environment; JS token boundaries; generated execution | 1 docs / no |
| javascript+myghty | Myghty plus JavaScript host | template scoping; JavaScript escaping; generated execution | 0 docs / no |
| jcl | IBM z/OS JES host or qualified emulator | job/step expansion; DD datasets; return codes and mainframe resources | 0 docs / no |
| jsgf | CMU Sphinx JSGF parser | rule imports; alternatives and weights; recognizer interpretation | 1 docs / no |
| jslt | JSLT Java implementation | JSON transformations; null/missing; function and extension behavior | 1 docs / no |
| jsp | Apache Tomcat/Jasper and Java | page translation lifecycle; expression language; request/session and tag libraries | 1 docs / no |
| julia | Julia distribution | multiple dispatch; type/array semantics; tasks and native library ABI | 1 docs / no |
| juttle | Juttle runtime and adapters | stream time windows; reducer semantics; external adapter behavior | 1 docs / no |
| k | Kona K3 versus commercial K separately | K dialect; atomic extension; adverb and dictionary semantics | 1 docs / no |
| kal | Kaffeine/Kal upstream identity to resolve | lexer identity; language revision; continuation and JavaScript lowering | 1 docs / no |
| kconfig | Linux Kconfig conf tool | tristate/select/dependencies; defaults/visibility; resulting configuration | 1 docs / no |
| koka | Koka compiler | effect rows and handlers; reference counting; C/JS backend behavior | 1 docs / no |
| kql | Kusto Query Language engine or Kusto emulator | tabular pipeline and scalar semantics; schema/types and nulls; time windows, joins and engine limits | 1 docs / no |
| kuin | Kuin compiler and supported host | language release; arrays and class ownership; Windows library behavior | 1 docs / no |
| lasso | Lasso runtime | tag versus modern syntax; type/coercion rules; request/database APIs | 0 docs / no |
| ldapconf | OpenLDAP client configuration host | option precedence; URI/TLS rules; directory lookup behavior | 1 docs / no |
| lean | Lean 3 historical toolchain | Lean 3 versus 4 separation; elaboration and kernel; metaprograms and libraries | 1 docs / no |
| lean4 | Lean 4 toolchain | kernel and elaborator; executable extraction; Lake/native ABI and libraries | 1 docs / no |
| lighttpd | lighttpd configuration checker and test server | condition scopes; module/directive merging; request routing | 1 docs / no |
| lilypond | LilyPond plus Guile | music expressions; timing and layout; Scheme embedding and rendered output | 1 docs / no |
| limbo | Inferno Limbo compiler and Dis VM | channels/processes; module loading; Dis representation and Styx host | 1 docs / no |
| literate-agda | Agda literate frontend | markup/code extraction; source positions; exact Agda elaborator/backend | 0 docs / no |
| literate-cryptol | Cryptol literate frontend | literate extraction; bitvector rules; proof/test correspondence | 0 docs / no |
| literate-idris | Idris literate frontend | Bird/Markdown dialect; extraction positions; elaboration and backend version | 0 docs / no |
| llvm-mir | LLVM llc matching MIR release | YAML/MIR dialect; register/liveness invariants; target instruction selection | 1 docs / no |
| llvm-mir-body | LLVM MIR containing-program harness | body scope/register declarations; CFG and target ops; machine verifier | 1 docs / no |
| logos | Theos Logos preprocessor and Objective-C toolchain | hook expansion; runtime method dispatch; Apple platform/jailbreak dependencies | 0 docs / no |
| logtalk | Logtalk with chosen Prolog backend | object categories/protocols; event handling; backend-specific predicates | 1 docs / no |
| lsl | OpenSimulator LSL scripting host | event state machine; vector/rotation arithmetic; simulator-specific APIs | 1 docs / no |
| luau | Luau CLI | gradual types; Lua compatibility boundaries; sandbox and library differences | 0 docs / no |
| macaulay2 | Macaulay2 | ring/type identity; polynomial algorithms; exact algebra and external packages | 0 docs / no |
| maple | authorized Maple host | symbolic evaluation levels; assumptions; numeric and package behavior | 1 docs / no |
| maql | GoodData MAQL host | metric context; dimensional aggregation; null and service semantics | 1 docs / no |
| mask | MaskJS compiler and JavaScript/DOM host | template component scopes; expression binding; render and event behavior | 1 docs / no |
| mason | HTML::Mason or Mason 2 separately | component inheritance; request/subrequest scope; Perl interpolation and escaping | 0 docs / no |
| mathematica | Wolfram Engine or Mathematica authorized host | held/evaluated expressions; rewrite ordering; exact/symbolic and numeric kernels | 1 docs / no |
| matlab | authorized MATLAB host | column-major indexing; array expansion; toolbox and numeric behavior | 1 docs / no |
| mcfunction | Minecraft Java/Bedrock dedicated host separately | edition/version commands; execution context; tick/world effects | 0 docs / no |
| mcschema | Minecraft schema provider identity to audit | schema dialect; game-version fields; validation target and processing contract | 1 docs / no |
| minid | MiniD legacy runtime versus renamed Croc | historical version; class and closure semantics; embedding ABI | 0 docs / no |
| miniscript | MiniScript interpreter | intrinsic calls; map/prototype semantics; numeric and host behavior | 1 docs / no |
| mips | GNU binutils or LLVM and QEMU MIPS | ISA/endian/ABI; delay slots; relocation and system-call environment | 0 docs / no |
| modelica | OpenModelica | equation flattening; initialization/events; DAE solver tolerances and libraries | 1 docs / no |
| modula2 | GNU Modula-2 or exact PIM/ISO compiler | PIM versus ISO; module/type checking; sets/ranges/exceptions and ABI | 1 docs / no |
| mojo | Mojo SDK with authorized platform | release-evolving syntax; ownership/lifetimes; Python interoperability and accelerator host | 0 docs / no |
| monkey | Monkey X compiler | target backend selection; modules and GC; graphics and target libraries | 1 docs / no |
| monte | Monte language upstream implementation | object capability scope; guards and auditors; eventual-send semantics | 0 docs / no |
| moocode | LambdaMOO server | verb permissions; object inheritance; task scheduling and persistent database | 1 docs / no |
| moonscript | MoonScript compiler and Lua | indentation lowering; expression returns; Lua-version metatables and libraries | 0 docs / no |
| mosel | authorized FICO Xpress Mosel | model execution; solver calls; data modules and optimization outcomes | 1 docs / no |
| mozhashpreproc | Mozilla preprocessor implementation | hash directives; include variables; conditional expansion and source locations | 1 docs / no |
| mozpercentpreproc | Mozilla percent preprocessor implementation | percent directive dialect; include/conditional expansion; embedding target | 1 docs / no |
| mql | MetaTrader MQL4/MQL5 compiler and strategy tester separately | MQL4 versus MQL5; event model; trading host and numeric behavior | 0 docs / no |
| mscgen | mscgen renderer | message-chart grammar; attribute resolution; deterministic SVG/render contract | 1 docs / no |
| mupad | authorized historical MuPAD host | symbolic domain dispatch; assumptions; version and MATLAB embedding | 1 docs / no |
| mxml | Apache Flex SDK | XML namespaces and binding; component initialization; ActionScript generated target | 0 docs / no |
| myghty | Myghty with compatible Python | component dispatch; argument scope and caching; web request effects | 0 docs / no |
| mysql | MySQL server isolated database | SQL mode and release; collation/null/transactions; stored routines and protocol | 1 docs / no |
| ncl | NCAR Command Language | missing values; array metadata; NetCDF/graphics and numeric behavior | 1 docs / no |
| nemerle | Nemerle compiler and compatible CLR | macro expansion; type inference; CLR lowering and legacy runtime | 0 docs / no |
| nesc | nesC compiler and TinyOS target | component wiring; async/atomic and race analysis; MCU runtime and hardware | 0 docs / no |
| newlisp | newLISP interpreter | context/value model; destructive list operations; native/library boundary | 0 docs / no |
| newspeak | Newspeak VM | nested classes and mixins; module instantiation; message-send rules | 1 docs / no |
| ng2 | Angular template compiler and browser/SSR host | Angular version; binding/change detection; directives and DOM/event context | 0 docs / no |
| nimrod | historical Nimrod versus renamed Nim toolchain | rename/version grammar; macros and templates; memory management and C backend | 0 docs / no |
| nit | Nit compiler | nullability; class refinements; separate compilation and FFI | 1 docs / no |
| nixos | Nix evaluator and NixOS module system | lazy attrsets; module merge priorities; derivation/build and activation effects | 1 docs / no |
| nsis | NSIS compiler and compatible Windows execution host | installer variables and stack; plugins; filesystem/registry and uninstall behavior | 0 docs / no |
| numba_ir | Numba with exact Python/LLVM versions | IR stage identity; SSA blocks and typing; lowered call and exception rules | 0 docs / no |
| nusmv | NuSMV or nuXmv with exact dialect | transition relation; fairness and temporal logic; finite-state/model assumptions | 1 docs / no |
| objective-j | Cappuccino Objective-J compiler on Node/browser | Objective-J message dispatch; class protocols; browser framework effects | 0 docs / no |
| octave | GNU Octave | MATLAB compatibility boundaries; arrays/indexing; numeric libraries and packages | 0 docs / no |
| odin | Odin compiler | context/allocator semantics; arrays/slices; explicit ownership and native ABI | 1 docs / no |
| omg-idl | omniORB or TAO IDL compiler | OMG version; type and interface mapping; CDR and target ABI | 1 docs / no |
| ooc | rock ooc compiler and C toolchain | cover/class types; generics; generated C and runtime ownership | 1 docs / no |
| opa | Opa compiler and supported JS/server runtime | distributed client/server placement; records; database and web effects | 1 docs / no |
| openedge | authorized Progress OpenEdge ABL host | transaction scope; record locking; database schema and session state | 0 docs / no |
| openscad | OpenSCAD CLI | CSG/geometry semantics; module/function scoping; tessellation and geometry comparison | 1 docs / no |
| pacmanconf | pacman parser in isolated root | repository/option precedence; signature policy; package database effects | 0 docs / no |
| pan | Quattor Pan compiler | template inclusion; typed paths; configuration tree generation | 1 docs / no |
| parasail | ParaSail compiler | pointer-free ownership; implicit parallel evaluation; contracts and runtime scheduling | 1 docs / no |
| pawn | Pawn compiler plus chosen game/embedding host | cell width; tags and arrays; native callback ABI | 1 docs / no |
| pddl | Fast Downward plus chosen PDDL validator | requirements level; action/state transition; numeric/temporal extensions | 0 docs / no |
| peg | chosen PEG engine and Ford semantics | ordered choice; greediness and left recursion; capture/error contract | 1 docs / no |
| phix | Phix interpreter/compiler | sequence operations; numeric representation; Euphoria compatibility and FFI | 1 docs / no |
| pig | Apache Pig and compatible Hadoop/local host | bag/tuple/null semantics; logical plan; UDF and distributed execution | 1 docs / no |
| plpgsql | PostgreSQL PL/pgSQL engine | function/procedure version; exceptions and transactions; SQL plan and record state | 1 docs / no |
| pointless | Pointless upstream interpreter identity to resolve | collection/value model; function evaluation; language-revision disambiguation | 0 docs / no |
| pony | Pony compiler | reference capabilities; actor isolation; message ordering and garbage collection | 1 docs / no |
| portugol | Portugol Studio or Portugol Webstudio | Portuguese educational dialect; numeric I/O; arrays and library selection | 0 docs / no |
| postgresql | PostgreSQL isolated database | SQL release/extensions; MVCC/isolation; types/collation and optimizer-visible effects | 1 docs / no |
| pov | POV-Ray | scene description evaluation; geometry/materials; renderer settings and numeric/image tolerances | 0 docs / no |
| powershell | PowerShell 7 versus Windows PowerShell separately | object pipelines; scope/coercion; .NET cmdlets and platform effects | 1 docs / no |
| praat | Praat batch interpreter | object selection and script state; sound-processing operations; sampling/measurement tolerances | 1 docs / no |
| promql | Prometheus engine | instant/range vectors; staleness/lookback; label matching and time-series evaluation | 0 docs / no |
| prql | PRQL compiler plus chosen SQL engine | relational pipeline lowering; null/order; generated dialect and database semantics | 1 docs / no |
| ptx | NVIDIA ptxas plus compatible CUDA GPU | PTX/SM version; address spaces; atomics, barriers and device behavior | 1 docs / no |
| puppet | Puppet parser/catalog compiler and isolated agent | resource graph; Hiera/functions; idempotent state and provider behavior | 1 docs / no |
| python2 | CPython 2.7 historical host | Unicode versus byte strings; integer division; obsolete extension ABI | 1 docs / no |
| q | authorized kdb+ q host | typed nulls/infinities; table/query semantics; temporal and IPC behavior | 1 docs / no |
| qbasic | QB64-PE versus historical QBasic host | dialect choice; fixed strings; numeric and device behavior | 0 docs / no |
| qlik | Qlik script/engine authorized host | load/association model; set analysis; dual values and aggregation context | 1 docs / no |
| qml | Qt QML engine | property bindings; object ownership; Qt/JavaScript event and GUI behavior | 1 docs / no |
| qvto | Eclipse QVTo with EMF | model extent and object identity; mapping resolution; transformation transactions | 1 docs / no |
| ragel-d | Ragel D backend plus compatible D1/D2 compiler | known generated-D1 versus installed-D2 mismatch; machine actions; input indexing | 1 docs / no |
| rd | R tools::parse_Rd and Rd2HTML | Rd macros and conditional sections; escaping and embedded R; documentation render/check contract | 1 docs / no |
| reasonml | Reason parser and exact OCaml/ReScript target | syntax versus language identity; variant and module lowering; target ABI | 1 docs / no |
| rebol | REBOL 2 or Rebol 3 separately | evaluation and words; series positions; dialecting and host ports | 1 docs / no |
| red | Red toolchain | Red versus Red/System; series and contexts; GUI/platform library boundary | 1 docs / no |
| redcode | pMARS with chosen ICWS profile | addressing modifiers; process queue; circular memory and tournament rules | 0 docs / no |
| registry | Windows reg import/parser in isolated hive | registry types/encoding; path/deletion rules; 32/64-bit view effects | 0 docs / no |
| rego | Open Policy Agent | Rego v0/v1; undefined versus false; built-in and policy evaluation behavior | 1 docs / no |
| rell | Chromia Rell compiler and node | entity/database typing; transactions; deterministic blockchain execution | 0 docs / no |
| resourcebundle | ICU genrb/derb and ResourceBundle API | ICU typed resource syntax; locale/alias fallback; binary bundle generation and lookup | 1 docs / no |
| ride | Waves RIDE evaluator/node | script version and complexity; blockchain context; deterministic value/transaction rules | 0 docs / no |
| rita | zaibacu rita-dsl Python compiler | pattern compilation; entity/match ordering; selected regex or NLP target behavior | 1 docs / no |
| roboconf-graph | Roboconf model parser | component/facet inheritance; runtime imports; deployment dependency graph | 1 docs / no |
| roboconf-instances | Roboconf instance parser | instance hierarchy; graph conformance; deployment lifecycle/state | 1 docs / no |
| robotframework | Robot Framework | keyword resolution; variables and scopes; library calls and pass/fail control | 1 docs / no |
| rql | Logilab Relation Query Language and CubicWeb host | entity/relation schema; variable binding and existential queries; permission-aware result and query translation | 0 docs / no |
| rsl | RAISE RSL tools | algebraic specification and types; partiality and proof obligations; executable subset versus specification-only clauses | 0 docs / no |
| sarl | SARL compiler and SRE | agent/event/capacity semantics; scheduling; generated Java and SRE version | 1 docs / no |
| sas | authorized SAS host | DATA step program data vector; missing values; procedures and dataset formats | 0 docs / no |
| savi | Savi compiler | reference capabilities; inference; ownership and runtime ABI | 1 docs / no |
| scaml | Scalate Scaml and Scala | indentation and filters; generated Scala; HTML escaping and attributes | 1 docs / no |
| scilab | Scilab | matrix indexing and types; polynomial/state-space objects; numerics and toolbox ABI | 1 docs / no |
| shen | Shen implementation and selected host | sequent calculus types; pattern rules; Klambda lowering and host semantics | 1 docs / no |
| shexc | ShExC parser and ShEx validator | shape recursion; cardinalities and negation; RDF graph and entailment | 1 docs / no |
| sieve | Pigeonhole Sieve interpreter | extension capabilities; mail envelope versus headers; action conflicts and delivery effects | 0 docs / no |
| silver | Viper Silver parser and Silicon/Carbon verifier | permissions and heap separation; inhale/exhale and contracts; verification backend/solver assumptions | 1 docs / no |
| singularity | Apptainer definition builder on authorized host | section ordering; bootstrap source; filesystem and container execution | 0 docs / no |
| slash | Slash language upstream runtime | template/code boundary; dynamic dispatch; web request host | 1 docs / no |
| slim | Slim Ruby engine | indentation/attribute grammar; embedded Ruby; escaping and output | 1 docs / no |
| slurm | Slurm sbatch parser plus chosen shell and isolated scheduler | SBATCH directive parsing; shell-script execution; job resources, environment and scheduler effects | 0 docs / no |
| smali | smali/baksmali and Android ART host | DEX revision; register verification; Android runtime methods and exceptions | 1 docs / no |
| smalltalk | GNU Smalltalk or Squeak/Pharo separately | image/dialect choice; live object identity; method lookup and block unwind | 0 docs / no |
| smithy | Smithy CLI and selected model/target runtime | model version; trait validation; protocol serialization and code generation | 1 docs / no |
| snobol | CSNOBOL4 | pattern success/failure; dynamic labels; string and external function rules | 1 docs / no |
| snowball | Snowball compiler and chosen generated target | backward/forward string matching; among/substring; Unicode and stemming fixtures | 1 docs / no |
| solidity | Solidity compiler and EVM host | compiler/EVM revision; storage layout; gas/revert and external call semantics | 0 docs / no |
| sophia | Aeternity Sophia compiler and FATE host | contract types/state; call/revert semantics; gas and chain context | 0 docs / no |
| sp | SourcePawn compiler plus SourceMod host | cell/tag rules; handles; game-plugin callback and native APIs | 1 docs / no |
| spec | RPM rpmspec/rpmbuild in isolated root | macro expansion; conditionals; build sections/package metadata | 1 docs / no |
| spice | ngspice versus selected SPICE dialect | netlist and device models; initial conditions; transient/nonlinear solver tolerances | 1 docs / no |
| squidconf | Squid parser and isolated proxy | ACL order; directive context; proxy/cache/network request behavior | 1 docs / no |
| srcinfo | makepkg metadata generator/checker | package/base split; architecture fields; PKGBUILD metadata consistency | 1 docs / no |
| ssp | Scalate SSP engine and Scala | template-to-Scala lowering; binding scope; HTML escaping and servlet behavior | 1 docs / no |
| stan | stanc3 plus CmdStan | constraint transforms; log density/autodiff; sampling diagnostics and RNG versions | 1 docs / no |
| stata | authorized Stata host | dataset/missing-value rules; command state; estimation and licensed procedures | 0 docs / no |
| supercollider | sclang and scsynth | language scheduling; synth graph/rates; OSC and audio device/server behavior | 1 docs / no |
| swift | Swift compiler | ownership/value semantics; async actor isolation; standard library and platform ABI | 1 docs / no |
| swig | SWIG plus chosen C/C++ and target runtime | typemap rules; ownership/lifetimes; exceptions and target-language ABI | 0 docs / no |
| tablegen | LLVM TableGen matching LLVM release | record inheritance; multiclass and DAG values; selected emitter backend | 1 docs / no |
| tact | Tact compiler and TON emulator | messages and storage; generated FunC/TVM; gas/serialization and actor ordering | 0 docs / no |
| tads3 | TADS 3 compiler and VM | object/property dispatch; parser library; story I/O and VM behavior | 1 docs / no |
| tal | Uxntal assembler and Uxn VM if identity confirmed | TAL dialect; opcode stack effects; device ports and virtual machine | 1 docs / no |
| tasm | Borland Turbo Assembler authorized legacy host | MASM/Ideal modes; CPU/object format; DOS/Windows execution host | 0 docs / no |
| tea | TeaTrove compiler on JVM | template evaluation; static types; Java method and context exposure | 1 docs / no |
| teal | Algorand go-algorand TEAL assembler/evaluator | AVM version and typed stack; transaction/global state; opcode cost and approval behavior | 0 docs / no |
| teratermmacro | Tera Term TTL on Windows | command parsing; variable types; terminal/session I/O and timeouts | 0 docs / no |
| termcap | ncurses termcap parser | escape/capability syntax; inheritance; terminal expansion behavior | 0 docs / no |
| terminfo | ncurses tic/infocmp/tparm | binary format; parameter stack; capability expansion and terminal behavior | 0 docs / no |
| ti | ThingsDB query/script engine | collection and thing identity; closures and stored procedures; change/event and cluster behavior | 0 docs / no |
| tid | TiddlyWiki host | tiddler field and wikitext syntax; transclusion/widgets; store and browser effects | 0 docs / no |
| tlb | TON TL-B parser/code generator and cell runtime | constructor tags; dependent field sizes and constraints; bit/ref cell serialization | 0 docs / no |
| tls | TLS presentation language RFC profile and codec | protocol-version structures; vector length and discriminants; wire parsing and limits | 1 docs / no |
| tnt | Typographical Number Theory verifier candidate | formal alphabet and inference rules; arithmetic interpretation; proof validation contract | 1 docs / no |
| todotxt | todo.txt parser and CLI profile | date/priority/project/context rules; stable rewrite; task ordering and extensions | 0 docs / no |
| trac-wiki | Trac wiki renderer | macro/plugin set; link resolution; HTML sanitization and rendering | 1 docs / no |
| trafficscript | authorized Ivanti/Pulse TrafficScript host | request/response stage; connection state; traffic-manager built-ins | 1 docs / no |
| treetop | Treetop and Ruby | PEG ordered choice; semantic nodes/actions; generated Ruby runtime | 1 docs / no |
| tsql | SQL Server or qualified Azure SQL host | TSQL release; collation/types; transaction/error and stored procedure behavior | 1 docs / no |
| typoscript | TYPO3 host | configuration tree and object evaluation; conditions/includes; frontend rendering state | 1 docs / no |
| typoscriptcssdata | TYPO3 with CSS embedding | TypoScript context; CSS boundary/escaping; generated stylesheet | 1 docs / no |
| typoscripthtmldata | TYPO3 with HTML embedding | TypoScript context; HTML boundary/escaping; generated markup | 1 docs / no |
| ucode | Icon compiler/interpreter intermediate ucode tools | Icon intermediate instruction identity; linker/runtime representation; goal-directed control flow | 0 docs / no |
| unicon | Unicon compiler | goal-directed objects; coexpressions; Icon compatibility and native APIs | 0 docs / no |
| unixconfig | passwd/group/shadow-compatible parser and isolated NSS fixture | colon-separated record identity; empty/special fields and permissions; lookup semantics without touching live account files | 0 docs / no |
| urbiscript | Urbi SDK host | reactive scheduling; tags and events; robot/network device bindings | 1 docs / no |
| usd | OpenUSD tools | layer composition and paths; schema metadata; time samples and scene interoperability | 0 docs / no |
| vala | Vala compiler with GLib | ownership/refcount annotations; signals/async; generated C and GObject ABI | 1 docs / no |
| vb.net | Roslyn Visual Basic and .NET | Option Strict/Infer/Compare; late binding; CLR exceptions/events and libraries | 1 docs / no |
| vbscript | Windows Script Host or qualified Wine host | Variant coercion; On Error; COM and filesystem objects | 1 docs / no |
| vcl | Varnish compiler and isolated cache | VCL version; subroutine return actions; HTTP/cache/backend state | 1 docs / no |
| vclsnippets | Varnish complete program harness | snippet context; variable availability; compiled full VCL request behavior | 1 docs / no |
| verifpal | Verifpal analyzer | symbolic attacker and primitives; query semantics; computational security limits | 0 docs / no |
| vgl | authorized Thermo Scientific SampleManager VGL host | LIMS object and database model; procedure/control semantics; vendor API and workflow effects | 0 docs / no |
| visualprolog | Visual Prolog compiler on authorized Windows host | typed predicate determinism; objects and cut; native library/ABI | 1 docs / no |
| visualprologgrammar | Visual Prolog grammar tools on licensed host | grammar dialect identity; typed predicates; generated parser and Windows runtime | 1 docs / no |
| vue | Vue compiler and browser/SSR host | Vue 2/3 identity; reactivity/lifecycle; SFC script/style/template boundaries | 1 docs / no |
| vyper | Vyper compiler and EVM host | version-specific type/storage rules; bounded loops; external calls/reverts and gas | 0 docs / no |
| webidl | WebIDL parser and binding generator | overload resolution; conversion and exceptions; ECMAScript/host binding behavior | 1 docs / no |
| wgsl | Tint or Naga plus WebGPU implementation | WGSL revision; address/access rules; shader stage and device behavior | 1 docs / no |
| whiley | Whiley compiler and verifier | flow-sensitive types; contracts; verification conditions and executable backend | 1 docs / no |
| wowtoc | World of Warcraft addon manifest host | client version; metadata/dependencies; file load order and addon environment | 0 docs / no |
| wren | Wren VM | fiber suspension; class dispatch; embedding and foreign methods | 1 docs / no |
| x10 | X10 compiler plus native/JVM runtime | places and activities; finish/async/at; distributed memory and atomics | 1 docs / no |
| xml+evoque | Evoque plus XML parser | well-formedness and namespaces; entity/attribute escaping; template output | 0 docs / no |
| xml+lasso | Lasso plus XML parser | embedded evaluation; XML namespace/escaping; generated well-formed document | 0 docs / no |
| xml+myghty | Myghty plus XML parser | component evaluation; XML namespace/escaping; generated document | 0 docs / no |
| xorg.conf | Xorg parser with virtual display | section references; driver/options; server input/display behavior | 0 docs / no |
| xpp | authorized Microsoft Dynamics AX/365 X++ host | X++ classes and extensions; transactional database access; Dynamics platform APIs | 1 docs / no |
| xtend | Eclipse Xtend and Java | active annotations; extension methods; Java lowering and runtime library | 0 docs / no |
| xul+mozpreproc | Mozilla preprocessor and versioned XUL host | preprocessor environment; XUL element model; obsolete platform APIs | 1 docs / no |
| zeek | Zeek interpreter | event scheduling; protocol/packet types; network state, policy and logs | 1 docs / no |
| zephir | Zephir compiler plus exact PHP SDK | static/dynamic types; Zend extension ABI; generated memory management | 0 docs / no |
| zig | Zig compiler | comptime; pointer/allocator/error unions; target ABI and safety mode | 1 docs / no |

Run `python scope_all.py --source-root /path/to/usl-base --inspect ID` for the complete per-ID contract and hash-linked evidence. No planning record promotes qualification. Native installs and language implementation remain distinct work.
