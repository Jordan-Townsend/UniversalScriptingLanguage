"""Materialize the manually audited RFC 8259 clause and grammar ledger.

This inventories actual rules in the pinned source. It does not turn inventory,
test-vector construction, or document retrieval into an implementation claim.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

from independent_cases import all_cases

ROOT = Path(__file__).resolve().parent

GRAMMAR = [
    ("JSON-text", "2", "ws value ws", "Exactly one serialized value; top-level scalar is allowed."),
    ("begin-array", "2", "ws %x5B ws", "Opening square bracket, optional surrounding JSON whitespace."),
    ("begin-object", "2", "ws %x7B ws", "Opening curly bracket, optional surrounding JSON whitespace."),
    ("end-array", "2", "ws %x5D ws", "Closing square bracket, optional surrounding JSON whitespace."),
    ("end-object", "2", "ws %x7D ws", "Closing curly bracket, optional surrounding JSON whitespace."),
    ("name-separator", "2", "ws %x3A ws", "Exactly one colon between string name and value."),
    ("value-separator", "2", "ws %x2C ws", "Exactly one comma between members/elements; no trailing comma."),
    ("ws", "2", "*(%x20 / %x09 / %x0A / %x0D)", "Only space, tab, LF and CR; zero or more."),
    ("value", "3", "false / null / true / object / array / number / string", "All seven alternatives, with no additional literal names."),
    ("false", "3", "%x66.61.6c.73.65", "Lowercase false; numeric hex case is notation only."),
    ("null", "3", "%x6e.75.6c.6c", "Lowercase null; no quotes required."),
    ("true", "3", "%x74.72.75.65", "Lowercase true."),
    ("object", "4", "begin-object [ member *( value-separator member ) ] end-object", "Zero or more string-name/value members; duplicates are grammar-valid."),
    ("member", "4", "string name-separator value", "Name is a string; value can be any value kind."),
    ("array", "5", "begin-array [ value *( value-separator value ) ] end-array", "Zero or more heterogeneous ordered values."),
    ("number", "6", "[ minus ] int [ frac ] [ exp ]", "Exact decimal syntax; no NaN/Infinity/hex/unary plus."),
    ("decimal-point", "6", "%x2E", "ASCII full stop."),
    ("digit1-9", "6", "%x31-39", "ASCII 1 through 9; not Unicode digit classes."),
    ("e", "6", "%x65 / %x45", "Lowercase or uppercase ASCII exponent marker."),
    ("exp", "6", "e [ minus / plus ] 1*DIGIT", "Exponent digits required; leading exponent zero allowed."),
    ("frac", "6", "decimal-point 1*DIGIT", "Fraction digits required; leading fractional zeros allowed."),
    ("int", "6", "zero / ( digit1-9 *DIGIT )", "A single zero, or a nonzero digit followed by any digits."),
    ("minus", "6", "%x2D", "ASCII hyphen-minus."),
    ("plus", "6", "%x2B", "ASCII plus; permitted only in exponent."),
    ("zero", "6", "%x30", "ASCII zero."),
    ("string", "7", "quotation-mark *char quotation-mark", "Zero or more JSON chars within quotes; local char rule is not core CHAR."),
    ("char", "7", "unescaped / escape ( %x22 / %x5C / %x2F / %x62 / %x66 / %x6E / %x72 / %x74 / %x75 4HEXDIG )", "Exactly nine escape alternatives; lowercase u followed by exactly four ASCII hex digits."),
    ("escape", "7", "%x5C", "ASCII reverse solidus."),
    ("quotation-mark", "7", "%x22", "ASCII double quote."),
    ("unescaped", "7", "%x20-21 / %x23-5B / %x5D-10FFFF", "Published RFC range; allows raw solidus and DEL/C1 controls, excludes U+0000..001F, quote and reverse solidus."),
]

# Every operative uppercase BCP 14 statement in the RFC; §1.1's keyword
# definitions are metalinguistic and are deliberately excluded from this count.
NORMATIVE = [
    ("N01", "3", "MUST", "A JSON value MUST be an object, array, number, or string, or one of the following three literal names:",
     "Parse all seven value alternatives.", ["null", "true", "false", "top-level-scalar", "mixed-array"]),
    ("N02", "3", "MUST", "The literal names MUST be lowercase. No other literal names are allowed.",
     "Strict generation uses false/null/true; this implementation elects no parser extensions.", ["uppercase-true", "uppercase-false", "uppercase-null", "undefined"]),
    ("N03", "4", "SHOULD", "The names within an object SHOULD be unique.",
     "Parser preserves all members. Generator rejects duplicates by default; explicit lossless preservation must document its deliberate interoperability exception.", ["duplicate-members-preserved", "escaped-duplicate-members"]),
    ("N04", "7", "MUST", "All Unicode characters may be placed within the quotation marks, except for the characters that MUST be escaped: quotation mark, reverse solidus, and the control characters (U+0000 through U+001F).",
     "String generator escapes mandatory characters; parser recognizes raw/escaped grammar exactly.", ["all-short-escapes", "raw-nul-string", "raw-newline-string"]),
    ("N05", "8.1", "MUST", "JSON text exchanged between systems that are not part of a closed ecosystem MUST be encoded using UTF-8 [RFC3629].",
     "Public interchange API accepts strict UTF-8 bytes and emits UTF-8; reject overlongs, CESU-8, surrogate byte sequences, >U+10FFFF and truncation.", ["utf8-network", "utf8-overlong-two", "utf8-surrogate-cesu8", "utf8-beyond-max", "utf16-input"]),
    ("N06", "8.1", "MUST NOT", "Implementations MUST NOT add a byte order mark (U+FEFF) to the beginning of a networked-transmitted JSON text.",
     "Generator never prefixes UTF-8 BOM.", ["generator-no-bom"]),
    ("N07", "8.1", "MAY", "In the interests of interoperability, implementations that parse JSON texts MAY ignore the presence of a byte order mark rather than treating it as an error.",
     "Either parser policy is permitted; chosen profile ignores an initial optional input BOM; generator never adds one.", ["network-bom-ignored-by-policy"]),
    ("N08", "9", "MUST", "A JSON parser MUST accept all texts that conform to the JSON grammar.",
     "All grammar alternatives are implemented within explicitly published size/depth/string/node/number limits allowed by §9; limits do not reclassify larger inputs as invalid JSON.", ["top-level-scalar", "mixed-array", "escaped-surrogate-pair"]),
    ("N09", "9", "MAY", "A JSON parser MAY accept non-JSON forms or extensions.",
     "Profile elects no extensions. Rejection of comments/NaN/trailing comma is a declared strict policy, not an RFC mandate for all possible parsers.", ["nan", "line-comment", "array-trailing-comma"]),
    ("N10", "10", "MUST", "A JSON generator produces JSON text. The resulting text MUST strictly conform to the JSON grammar.",
     "Generation is total only over validated supported IR with resource limits; invalid IR/number lexemes/types are rejected.", ["generator-valid-grammar", "generator-reject-invalid-ir"]),
]

CONTEXT = [
    ("P01", "1", "data_model", "Four primitive types and two structured types; object is unordered, array ordered. Preserving object source order is an observable representation choice, not normative order semantics."),
    ("P02", "1.1", "interpretation", "Only uppercase BCP14 words carry their specified force. Interpret grammar with RFC5234; DIGIT=%x30-39 and HEXDIG is ASCII 0-9/A-F/a-f."),
    ("P03", "1.2", "version_scope", "Target the exact published RFC8259 text. ECMA404 is normatively cited for aligned JSON-text grammar, not an instruction to implement ECMAScript."),
    ("P04", "2", "grammar", "Complete input must contain exactly one ws value ws; top-level primitive values are legal."),
    ("P05", "4", "interoperability_guidance", "Duplicate object names have unpredictable receiver behavior; record preservation is a profile policy and does not guarantee other implementations preserve duplicates."),
    ("P06", "4", "interoperability_guidance", "Applications must not assume object ordering interoperability. Preserve order for lossless syntax representation without making it object semantic equality."),
    ("P07", "5", "data_model", "Array elements may have different types and their ordering is meaningful."),
    ("P08", "6", "grammar", "Leading zero restriction applies to the integer component, not fractional/exponent digits. 0.001, 0E00 and 1E01 are legal; 01 is not."),
    ("P09", "6", "grammar", "NaN and Infinity cannot be generated as JSON numbers. Exact lexemes avoid host overflow/rounding without claiming IEEE754 equivalence."),
    ("P10", "6", "permitted_limit", "Implementations may limit number range/precision. This profile limits lexeme length and preserves exact decimal text, including -0 and huge exponents."),
    ("P11", "6", "interoperability_guidance", "Binary64 is interoperability guidance; exact agreement for integers is promised only in [-(2**53)+1,(2**53)-1] among compatible receivers. No general exact binary64 promise."),
    ("P12", "7", "grammar", "Any character may be escaped; ordinary raw solidus is allowed in the published text. Optional short escapes and four-hex-digit escapes are supported."),
    ("P13", "7", "grammar", "A non-BMP escaped character uses a UTF16 surrogate pair; recognize valid pairs as one code point without deleting unpaired surrogates."),
    ("P14", "8.1", "encoding", "UTF8 parser rejects malformed byte sequences, rather than decoding with replacement or implicitly treating UTF16/UTF32 as the network encoding."),
    ("P15", "8.2", "interoperability_guidance", "Escaped unpaired UTF16 surrogates are admitted by the grammar; their cross-implementation behavior is unpredictable. Profile preserves code points and never emits their invalid raw UTF8 form."),
    ("P16", "8.3", "interoperability_guidance", "Compare decoded strings by code units/code points consistently; a\\b and a\\u005Cb decode alike. Do not normalize canonically equivalent Unicode strings silently."),
    ("P17", "9", "permitted_limit", "Size, maximum nesting depth, number range/precision, string length and character-content limits may be set. Exact limits and error behavior must be visible and boundary-tested."),
    ("P18", "10", "generation", "Generator must not evaluate source text or emit JavaScript expressions. Invalid caller IR must not turn into invalid JSON."),
    ("P19", "11", "media_type", "Registered media type is application/json; no charset parameter is defined. File suffix .json; not an executable file format. HTTP server/media-type handling is a distinct integration gate if claimed."),
    ("P20", "12", "security_guidance", "JSON excludes assignment/invocation. Do not parse through eval; legal JSON includes U+2028/U+2029. Resource checks must precede uncontrolled allocation/recursion."),
    ("P21", "13", "examples", "The full object, nested array-of-objects and scalar examples are acceptance cases, not the complete language definition."),
    ("P22", "14", "dependencies", "Normative reference dependencies, Unicode code point/UTF8 rules and applicable errata are recorded separately; document retrieval alone does not prove implementation correctness."),
]


def build() -> dict:
    text = ROOT.joinpath("rfc8259.txt").read_text()
    normalized = re.sub(r"\s+", " ", text)
    for _, _, _, quote, _, _ in NORMATIVE:
        assert re.sub(r"\s+", " ", quote) in normalized, quote
    actual = re.findall(r"(?m)^\s{6}(\w[\w-]*)\s*=", text)
    # Arrays have three-space indentation rather than six in the source.
    actual += re.findall(r"(?m)^\s{3}(array)\s*=", text)
    assert set(actual) == {r[0] for r in GRAMMAR}, (set(actual), {r[0] for r in GRAMMAR})
    assert len(GRAMMAR) == 30 and len(NORMATIVE) == 10
    cases = all_cases()
    errata = json.loads(ROOT.joinpath("RFC8259_ERRATA_SNAPSHOT.json").read_text())["records"]
    statuses = dict(Counter(row["errata_status_code"] for row in errata))
    result = {
        "schema": "usl.rfc8259.rule_audit.v1",
        "document": "RFC 8259 December 2017, published text",
        "source_sha256": hashlib.sha256(ROOT.joinpath("rfc8259.txt").read_bytes()).hexdigest(),
        "category": "data-interchange format; not a programming language",
        "audit_kind": "manual enumeration checked against source; implementation and universal proof are separate gates",
        "grammar_productions": [{"id": name, "section": section, "abnf": abnf, "meaning": meaning,
                                  "implementation_correspondence": "pending_root_implementation_review"}
                                 for name, section, abnf, meaning in GRAMMAR],
        "uppercase_requirements": [{"id": rid, "section": section, "force": force, "quote": quote,
                                     "profile_obligation": obligation, "test_ids": tests,
                                     "implementation_status": "pending"}
                                    for rid, section, force, quote, obligation, tests in NORMATIVE],
        "prose_and_interoperability": [{"id": rid, "section": section, "kind": kind, "rule": rule}
                                       for rid, section, kind, rule in CONTEXT],
        "declared_limits": {"input_utf8_bytes": 65536, "container_depth": 40, "value_nodes": 10000,
                            "string_codepoints": 8192, "number_lexeme_chars": 1024,
                            "basis": "RFC8259 section9 permits implementation limits"},
        "policies": {"parser_extensions": "none", "parser_bom": "ignore_initial_optional_BOM", "duplicate_parser_members": "preserve",
                     "duplicate_generator_default": "reject", "duplicate_generator_explicit_preserve": "documented SHOULD exception",
                     "numbers": "preserve exact decimal lexeme; no binary64 conversion", "object_order": "preserve source order without claiming semantic ordering",
                     "unpaired_escaped_surrogates": "preserve codepoints; escape on output; interoperability not guaranteed",
                     "raw_unpaired_surrogates": "not representable in strict UTF8 network profile",
                     "string_equality": "decoded sequence; no Unicode normalization"},
        "independent_fixture_counts": {"total": len(cases), "acceptance": sum(c.accepts for c in cases),
                                       "rejection": sum(not c.accepts for c in cases),
                                       "status": "authored_independently; execution_pending"},
        "errata_status_counts": statuses,
        "errata_policy": {
            "published_text_target_explicit": True,
            "verified_ids": [r["errata_id"] for r in errata if r["errata_status_code"] == "Verified"],
            "unresolved": [{"id": "5318", "status_in_retrieved_official_snapshot": "Verified Editorial",
                            "issue": "proposed unescaped production excludes raw solidus; conflicts with published section7 and JSON interoperability",
                            "decision": "retain exact published syntax; do not claim current-errata conformance or silently reject raw solidus"}],
            "reported_or_held": "preserve separately; do not silently apply as approved changes",
        },
        "qualification_gates": [
            {"id": "Q01", "gate": "Pinned complete published specification and actual rule set", "status": "passed_audit"},
            {"id": "Q02", "gate": "Actual frontend implements every grammar alternative within disclosed resource limits", "status": "pending_source_review"},
            {"id": "Q03", "gate": "Lossless typed representation preserves numbers, names, duplicates, strings, arrays and all value kinds", "status": "pending"},
            {"id": "Q04", "gate": "Actual .usl generated-value execution and equality checks", "status": "pending"},
            {"id": "Q05", "gate": "UTF8/noBOM/parser/generator normative requirements and limit-boundary evidence", "status": "pending"},
            {"id": "Q06", "gate": "Independently authored intent/negative tests executed and failures repaired", "status": "pending"},
            {"id": "Q07", "gate": "Independent native parser/generator differential evidence restricted to comparable interoperable inputs", "status": "pending"},
            {"id": "Q08", "gate": "Source-level grammar correspondence, progress/termination/resource-limit argument and generator invariant review", "status": "pending"},
            {"id": "Q09", "gate": "Native platform/runtime/source identities and fresh reproducible run", "status": "pending"},
            {"id": "Q10", "gate": "Universal bounded-domain translation preservation proof requested by user", "status": "not_established_by_fixtures"},
            {"id": "Q11", "gate": "Latest errata policy resolved if latest-errata conformance is claimed", "status": "unresolved_5318; outside_explicit_published_text_target"},
            {"id": "Q12", "gate": "Independent full-standard certification (if claimed)", "status": "not_obtained"},
        ],
        "category_inapplicability": {"program_execution": "JSON has no program execution semantics", "standard_library": "not defined by this standard",
                                     "concurrency_or_ABI": "not defined by this standard", "external_licenses": "none for implementing RFC grammar; preserve RFC document copyright/license notices"},
        "whole_programming_language_qualification": False,
        "whole_standard_qualification": False,
        "reason": "Actual rule set is finished; implementation validation, source correspondence, proof and review remain separate gates.",
    }
    return result


if __name__ == "__main__":
    audit = build()
    ROOT.joinpath("RFC8259_RULE_AUDIT.json").write_text(json.dumps(audit, indent=2, ensure_ascii=True) + "\n")
    print(json.dumps({"grammar_productions": len(audit["grammar_productions"]),
                      "operative_uppercase_statements": len(audit["uppercase_requirements"]),
                      "prose_rules": len(audit["prose_and_interoperability"]),
                      "fixtures": audit["independent_fixture_counts"],
                      "errata": audit["errata_status_counts"],
                      "whole_standard_qualification": audit["whole_standard_qualification"]}, indent=2))
