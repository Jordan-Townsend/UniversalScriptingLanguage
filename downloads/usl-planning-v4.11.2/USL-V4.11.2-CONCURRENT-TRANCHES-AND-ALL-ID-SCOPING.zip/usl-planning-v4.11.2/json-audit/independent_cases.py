"""Independently authored RFC 8259 vectors; this module does not parse JSON.

The expected representation is deliberately lossless: numbers retain source
lexemes, objects retain duplicate members, and strings use integer code points.
The adapter under test is responsible for mapping its own representation here.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class Case:
    id: str
    input: str | bytes
    accepts: bool
    expected: Any = None
    clauses: tuple[str, ...] = ()
    policy: str = "required"


def s(value: str | list[int]) -> list:
    return ["string", [ord(x) for x in value] if isinstance(value, str) else value]


def n(value: str) -> list:
    return ["number", value]


def a(*items: list) -> list:
    return ["array", list(items)]


def o(*items: tuple[str | list[int], list]) -> list:
    return ["object", [[s(key)[1], value] for key, value in items]]


def fixed_cases() -> list[Case]:
    out: list[Case] = []

    def good(label: str, source: str | bytes, expected: list, *clauses: str,
             policy: str = "required") -> None:
        out.append(Case(label, source, True, expected, clauses, policy))

    def bad(label: str, source: str | bytes, *clauses: str,
            policy: str = "strict_no_extensions") -> None:
        out.append(Case(label, source, False, None, clauses, policy))

    good("null", "null", ["null"], "3", "JSON-text")
    good("true", "true", ["boolean", True], "3")
    good("false", "false", ["boolean", False], "3")
    good("empty-string", '""', s(""), "7")
    good("top-level-scalar", "42", n("42"), "2", "9")
    good("all-whitespace", ' \t\r\n[ \t\r\n0 \t\r\n, \t\r\ntrue \t\r\n] \t\r\n',
         a(n("0"), ["boolean", True]), "ws", "array")
    good("empty-object", "{}", o(), "object")
    good("empty-array", "[]", a(), "array")
    good("mixed-array", '[null,true,false,0,"",{},[]]',
         a(["null"], ["boolean", True], ["boolean", False], n("0"), s(""), o(), a()), "5")
    good("nested-object", '{"a":{"b":[-0,1.5e+2]},"z":null}',
         o(("a", o(("b", a(n("-0"), n("1.5e+2"))))), ("z", ["null"])), "4", "5", "6")
    good("duplicate-members-preserved", '{"a":1,"a":2}',
         o(("a", n("1")), ("a", n("2"))), "4", policy="declared_preserve_duplicates")
    good("escaped-duplicate-members", '{"a\\u005Cb":1,"a\\\\b":2}',
         o(("a\\b", n("1")), ("a\\b", n("2"))), "4", "8.3",
         policy="declared_preserve_duplicates")
    good("member-order-preserved", '{"z":1,"a":2}',
         o(("z", n("1")), ("a", n("2"))), "4", policy="declared_preserve_order")
    for label, text in [
        ("zero", "0"), ("negative-zero", "-0"), ("integer", "1234567890"),
        ("negative", "-123"), ("fraction", "0.001"), ("negative-fraction", "-0.0"),
        ("positive-exp", "1e+2"), ("negative-exp", "1E-2"),
        ("zero-exp", "0E00"), ("exp-leading-zero", "1E01"),
        ("precise-decimal", "3.141592653589793238462643383279"),
        ("binary64-overflow", "1E400"), ("large-integer", "9007199254740993"),
        ("safe-int-positive", "9007199254740991"), ("safe-int-negative", "-9007199254740991"),
        ("tiny-exponent", "1e-1000000"),
    ]:
        good(label, text, n(text), "6", policy="declared_exact_number_lexeme")
    good("all-short-escapes", '"\\\"\\\\\\/\\b\\f\\n\\r\\t"',
         s([0x22, 0x5C, 0x2F, 8, 12, 10, 13, 9]), "char")
    good("mixed-case-hex", '"\\uAbCd\\uabcd"', s([0xABCD, 0xABCD]), "char")
    good("escaped-nul", '"\\u0000"', s([0]), "7")
    good("escaped-surrogate-pair", '"\\uD834\\uDD1E"', s([0x1D11E]), "7", "8.3")
    good("raw-supplementary", '"\U0001D11E"', s([0x1D11E]), "7", "8.1")
    good("raw-maximum-codepoint", '"\U0010FFFF"', s([0x10FFFF]), "unescaped")
    good("raw-line-paragraph-separators", '"\u2028\u2029"', s([0x2028, 0x2029]), "7", "12")
    good("raw-del-c1-controls", '"\u007f\u0080\u009f"', s([0x7F, 0x80, 0x9F]), "unescaped")
    good("raw-solidus", '"/"', s("/"), "7", policy="published_rfc8259_not_erratum5318")
    good("no-unicode-normalization", '["\u00e9","e\u0301"]', a(s([0xE9]), s([0x65, 0x301])), "8.3")
    for label, source, expected in [
        ("unpaired-high", '"\\uD800"', [0xD800]),
        ("unpaired-low", '"\\uDEAD"', [0xDEAD]),
        ("high-high-low", '"\\uD800\\uD800\\uDC00"', [0xD800, 0x10000]),
        ("low-high", '"\\uDC00\\uD800"', [0xDC00, 0xD800]),
    ]:
        good(label, source, s(expected), "8.2", policy="declared_preserve_unpaired_surrogates")

    for label, source in [
        ("empty-text", ""), ("whitespace-only", " \r\n\t"),
        ("two-values", "true false"), ("trailing-garbage", "nullx"),
        ("uppercase-true", "True"), ("uppercase-false", "FALSE"), ("uppercase-null", "NULL"),
        ("undefined", "undefined"), ("nan", "NaN"), ("infinity", "Infinity"),
        ("negative-infinity", "-Infinity"), ("plus-prefix", "+1"),
        ("leading-zero", "01"), ("negative-leading-zero", "-01"),
        ("double-zero", "00"), ("hex-number", "0x10"), ("underscore-number", "1_000"),
        ("bare-minus", "-"), ("leading-decimal", ".5"), ("no-fraction-digit", "1."),
        ("no-exponent-digit", "1e"), ("no-plus-exponent-digit", "1e+"),
        ("no-minus-exponent-digit", "1E-"), ("double-minus", "--1"),
        ("unicode-digit", "\u0661"), ("unicode-number-tail", "1\u0662"),
        ("array-trailing-comma", "[1,]"), ("array-leading-comma", "[,1]"),
        ("array-double-comma", "[1,,2]"), ("array-missing-comma", "[1 2]"),
        ("array-missing-close", "[1"), ("extra-close", "[]]"),
        ("object-trailing-comma", '{"a":1,}'), ("object-bare-key", "{a:1}"),
        ("object-single-quoted-key", "{'a':1}"), ("object-missing-colon", '{"a" 1}'),
        ("object-double-colon", '{"a"::1}'), ("object-missing-value", '{"a":}'),
        ("object-missing-comma", '{"a":1 "b":2}'), ("object-missing-close", '{"a":1'),
        ("single-quoted-string", "'a'"), ("unclosed-string", '"a'),
        ("invalid-escape", '"\\x41"'), ("uppercase-u-escape", '"\\U0041"'),
        ("short-hex-escape", '"\\u123"'), ("bad-hex-escape", '"\\u12G4"'),
        ("missing-escape-tail", '"\\'), ("raw-newline-string", '"a\nb"'),
        ("raw-nul-string", '"a\x00b"'), ("formfeed-whitespace", "\fnull"),
        ("vertical-tab-whitespace", "\vnull"), ("nbsp-whitespace", "\u00a0null"),
        ("unicode-line-whitespace", "\u2028null"),
        ("line-comment", "// comment\nnull"), ("block-comment", "/*x*/null"),
        ("javascript-execution", '(function(){return 1})()'),
    ]:
        bad(label, source, "strict-profile", "9", "10")
    for label, raw in [
        ("utf8-invalid-byte", bytes.fromhex("22ff22")),
        ("utf8-overlong-two", bytes.fromhex("22c0af22")),
        ("utf8-overlong-three", bytes.fromhex("22e080af22")),
        ("utf8-surrogate-cesu8", bytes.fromhex("22eda08022")),
        ("utf8-beyond-max", bytes.fromhex("22f490808022")),
        ("utf8-truncated", bytes.fromhex("22e282")),
        ("latin1-input", bytes.fromhex("22e922")),
        ("utf16-input", '"a"'.encode("utf-16-le")),
        ("utf32-input", '"a"'.encode("utf-32-be")),
    ]:
        bad(label, raw, "8.1", "RFC3629", policy="network_utf8")
    good("utf8-network", '"\u20ac\U0001D11E"'.encode("utf-8"), s([0x20AC, 0x1D11E]), "8.1")
    # Both choices are permitted by §8.1. The implemented, disclosed parser
    # elects to ignore an initial BOM; generation must still never add one.
    good("network-bom-ignored-by-policy", bytes.fromhex("efbbbf6e756c6c"), ["null"], "8.1",
         policy="declared_ignore_optional_bom")
    return out


def generated_cases() -> Iterable[Case]:
    """Boundary-covering families with expected results constructed directly."""
    # Every raw disallowed ASCII control, independently of an implementation.
    for cp in range(32):
        yield Case(f"control-raw-{cp:02x}", '"' + chr(cp) + '"', False, clauses=("7",))
        yield Case(f"control-escaped-{cp:02x}", '"\\u%04x"' % cp, True, s([cp]), ("7",))
    # Exhaust all legal raw ASCII and UTF-8 width/surrogate transition boundaries.
    cps = list(range(0x20, 0x80)) + [
        0x80, 0x7FF, 0x800, 0xD7FF, 0xE000, 0xFFFF,
        0x10000, 0x10001, 0x1D11E, 0x10FFFF,
    ]
    for cp in cps:
        if cp not in (0x22, 0x5C):
            yield Case(f"raw-codepoint-{cp:x}", ('"' + chr(cp) + '"').encode("utf-8"),
                       True, s([cp]), ("unescaped", "8.1"),
                       "published_rfc8259_not_erratum5318" if cp == 0x2F else "required")
    for digit in "0123456789":
        for sign in ("", "-"):
            for fraction in ("", ".0", ".001", ".123456789"):
                for exponent in ("", "e0", "E+01", "e-001"):
                    lexeme = sign + digit + fraction + exponent
                    yield Case("number-grid-" + lexeme, lexeme, True, n(lexeme), ("number",))
    # Compound construction checks the parser consumes nested structures and all
    # object member values; it does not use its parser/generator as an oracle.
    for depth in (1, 2, 7, 31, 40):
        expected = ["null"]
        for _ in range(depth):
            expected = a(expected)
        yield Case(f"nesting-{depth}", "[" * depth + "null" + "]" * depth,
                   True, expected, ("5", "9"), "within_declared_depth_limit")


def resource_cases() -> Iterable[Case]:
    """Boundary vectors for the explicitly declared implementation resource limits.

    These are profile checks, not claims that larger well-formed texts cease to
    be JSON. The root array counts as one of the 10,000 permitted value nodes.
    """
    yield Case("depth-limit-41", "[" * 41 + "null" + "]" * 41, False,
               clauses=("9",), policy="declared_depth_limit_40")
    yield Case("string-limit-8192", '"' + "x" * 8192 + '"', True, s("x" * 8192),
               ("9",), "declared_string_limit_8192")
    yield Case("string-limit-8193", '"' + "x" * 8193 + '"', False,
               clauses=("9",), policy="declared_string_limit_8192")
    yield Case("number-limit-1024", "1" * 1024, True, n("1" * 1024),
               ("9",), "declared_number_limit_1024")
    yield Case("number-limit-1025", "1" * 1025, False,
               clauses=("9",), policy="declared_number_limit_1024")
    yield Case("text-limit-65536", " " * (65536 - 4) + "null", True, ["null"],
               ("9",), "declared_text_limit_65536_utf8_bytes")
    yield Case("text-limit-65537", " " * (65537 - 4) + "null", False,
               clauses=("9",), policy="declared_text_limit_65536_utf8_bytes")
    yield Case("node-limit-10000", "[" + ",".join(["null"] * 9999) + "]", True,
               a(*([["null"]] * 9999)), ("9",), "declared_node_limit_10000")
    yield Case("node-limit-10001", "[" + ",".join(["null"] * 10000) + "]", False,
               clauses=("9",), policy="declared_node_limit_10000")


def all_cases(include_resources: bool = True) -> list[Case]:
    return fixed_cases() + list(generated_cases()) + (list(resource_cases()) if include_resources else [])


def run_suite(parse_text: Callable[[str], Any], parse_bytes: Callable[[bytes], Any],
              normalize: Callable[[Any], Any]) -> dict:
    """Apply authored expectations to an adapter; never choose expectations from it.

    Any exception is rejection. Accepted input must normalize exactly to the
    expected lossless value. Callers must separately check exception classes,
    configured limits, generator behavior, and source-level correspondence.
    """
    failures = []
    cases = all_cases()
    for case in cases:
        try:
            parsed = (parse_bytes if isinstance(case.input, bytes) else parse_text)(case.input)
        except Exception as exc:
            if case.accepts:
                failures.append({"id": case.id, "problem": "unexpected_rejection",
                                 "exception": type(exc).__name__, "message": str(exc)[:160]})
            continue
        if not case.accepts:
            failures.append({"id": case.id, "problem": "unexpected_acceptance"})
            continue
        observed = normalize(parsed)
        if observed != case.expected:
            failures.append({"id": case.id, "problem": "incorrect_lossless_value",
                             "expected": case.expected, "observed": observed})
    return {"cases": len(cases), "passed": len(cases) - len(failures), "failures": failures,
            "qualification": "fixture_evidence_only_not_universal_proof"}
