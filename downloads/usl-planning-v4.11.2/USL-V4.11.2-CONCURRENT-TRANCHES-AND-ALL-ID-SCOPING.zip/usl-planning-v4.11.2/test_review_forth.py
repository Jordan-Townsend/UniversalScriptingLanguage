"""Independent adversarial tests for the selected Gforth/USL stack profile."""
import random
from pathlib import Path
import sys
import unittest

sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from forth_semantics import Program, ForthProfileError, frontend, native_batch


def signed(n):
    n %= 1 << 64
    return n if n < (1 << 63) else n - (1 << 64)


class ForthIndependentReview(unittest.TestCase):
    native_cases = 0
    native_processes = 0
    usl_cases = 0

    def compare(self, source, inputs, expected):
        native, receipt = native_batch(source, inputs)
        type(self).native_processes += receipt['native_processes']
        type(self).native_cases += len(native)
        self.assertEqual(native, expected)
        program = Program(source)
        actual = []
        for row in inputs:
            actual.append(program.run(row)[0])
            type(self).usl_cases += 1
        self.assertEqual(actual, expected)

    def test_reject_non_native_separator_classes(self):
        for char in '\x1c\x1d\x1e\x1f\x85\xa0\u1680\u2000\u2028\u2029\u202f\u205f\u3000':
            with self.subTest(codepoint=ord(char)), self.assertRaises(ForthProfileError):
                frontend(': usl-main' + char + '1 ;')

    def test_six_native_ascii_separator_classes(self):
        for char in ' \t\n\r\v\f':
            with self.subTest(codepoint=ord(char)):
                self.compare(': usl-main' + char + '1 ;', [[], [7]], [[1], [7, 1]])

    def test_control_word_dictionary_shadowing_is_rejected(self):
        for word in ['if', 'else', 'then', 'begin', 'while', 'repeat', 'until']:
            with self.subTest(word=word), self.assertRaises(ForthProfileError):
                frontend(': ' + word + ' 42 ; : usl-main ;')

    def test_native_comment_line_endings(self):
        for source, expected in [
            (': usl-main \\ comment\r1 ;', [1]),
            (': usl-main \\ comment\r\n1 ;', [1]),
            (': usl-main \\ comment\n1 ;', [1]),
            (': usl-main \\ comment\v9 ;\n2 ;', [2]),
            (': usl-main ( comment\r9 ) 1 ;', [1]),
            (': usl-main ( comment\r\n9 ) 1 ;', [1]),
        ]:
            with self.subTest(source=source):
                self.compare(source, [[]], [expected])

    def test_native_harness_dictionary_shadowing(self):
        sources = [': decimal 1 ; : usl-main ;', ': pick 42 ; : usl-main ;',
                   ': cr 42 ; : usl-main ;', ': i 42 ; : usl-main ;',
                   ': loop 42 ; : usl-main ;', ': bye begin 0 until ; : usl-main ;']
        for source in sources:
            with self.subTest(source=source):
                self.compare(source, [[], [1, 2], [-8, 9], list(range(64))],
                             [[], [1, 2], [-8, 9], list(range(64))])

    def test_noncanonical_flags_and_nested_control(self):
        values = [-(1 << 63), -99, -1, 0, 1, 2, (1 << 63) - 1]
        self.compare(': usl-main if 12 else -9 then ;', [[n] for n in values],
                     [[-9] if n == 0 else [12] for n in values])
        source = ': usl-main dup 0< if negate dup 3 > if 3 - else 1 + then else dup 2 > if 2 / else 5 + then then ;'
        expected = []
        for n in range(-8, 9):
            expected.append([(-n - 3 if -n > 3 else -n + 1) if n < 0 else (n // 2 if n > 2 else n + 5)])
        self.compare(source, [[n] for n in range(-8, 9)], expected)

    def test_full_declared_call_chain(self):
        source = ': d0 1+ ; ' + ''.join(': d%d d%d ; ' % (n, n-1) for n in range(1, 23)) + ': usl-main d22 ;'
        self.compare(source, [[n] for n in [-(1 << 63), -1, 0, (1 << 63)-1]],
                     [[signed(n+1)] for n in [-(1 << 63), -1, 0, (1 << 63)-1]])

    def test_nontermination_fails_closed_at_real_execution_budget(self):
        from usl_systems.language import LimitExceeded
        with self.assertRaises(LimitExceeded):
            Program(': usl-main begin 0 until ;').run([])

    def test_intermediate_stack_limit_is_enforced(self):
        from usl_systems.language import USLError
        # The native program is valid and returns to depth64. The restricted
        # generated profile must reject its depth65 intermediate state.
        source = ': usl-main dup drop ;'
        values = list(range(64))
        native, receipt = native_batch(source, [values])
        type(self).native_processes += receipt['native_processes']
        type(self).native_cases += 1
        self.assertEqual(native, [values])
        with self.assertRaisesRegex(USLError, 'forth:stack-limit'):
            Program(source).run(values)

    def test_mixed_word_compositions_with_independent_stack_model(self):
        rng = random.Random(4112007)
        values = [-(1 << 63), -(1 << 63)+1, -19, -1, 0, 1, 23, (1 << 63)-2, (1 << 63)-1]
        for program_index in range(20):
            operations = [rng.choice(['+', '-', '*', 'and', 'or', 'xor', 'min', 'max']) for _ in range(16)]
            constants = [rng.choice(values) for _ in operations]
            source = ': usl-main ' + ' '.join(str(n)+' '+op for n, op in zip(constants, operations)) + ' ;'
            expected = []
            for initial in values:
                result = initial
                for n, op in zip(constants, operations):
                    if op == '+': result = signed(result+n)
                    elif op == '-': result = signed(result-n)
                    elif op == '*': result = signed(result*n)
                    elif op == 'and': result = signed(result & n)
                    elif op == 'or': result = signed(result | n)
                    elif op == 'xor': result = signed(result ^ n)
                    elif op == 'min': result = min(result, n)
                    elif op == 'max': result = max(result, n)
                expected.append([55, result])
            with self.subTest(program=program_index):
                self.compare(source, [[55, n] for n in values], expected)


if __name__ == '__main__':
    unittest.main()
