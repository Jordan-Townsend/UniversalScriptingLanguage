"""Concurrent, content-addressed source discovery for all 606 IDs plus USL.

The output is an evidence inventory and an executable route to missing work.
Section indexing does not infer semantics or audit a language standard. Native
observations, effects, normative audits and qualifications are never replayed.
Third-party bodies remain in a private CAS; only headings and provenance enter
the export. Use --fetch-missing to retrieve missing public reference candidates.
"""
from __future__ import annotations

import argparse
import asyncio
import collections
from concurrent.futures import ThreadPoolExecutor
import hashlib
from html.parser import HTMLParser
import ipaddress
import json
import os
from pathlib import Path
import re
import resource
import shutil
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
PREPARATION = Path('/workspace/usl-preparation-v4.11.0/ecosystem-validated/preparation.json')
PRIVATE_CACHE = Path('/workspace/.onboarding/data/v411-public-reference-cache')
MAX_BODY = 4 * 1024**2
SHA = re.compile(r'[0-9a-f]{64}\Z')

# These are same-project official sources, not similarly named replacements.
# Their authority/version and applicability must still be reviewed per ID.
OFFICIAL_REPLACEMENTS = {
    'perl6': ['https://docs.raku.org/language'],
    'irc': ['https://www.rfc-editor.org/rfc/rfc2812.html'],
    'kmsg': ['https://raw.githubusercontent.com/torvalds/linux/v6.12/Documentation/ABI/testing/dev-kmsg'],
    'nginx': ['https://nginx.org/en/docs/beginners_guide.html'],
    'jsx': ['https://raw.githubusercontent.com/reactjs/react.dev/main/src/content/learn/writing-markup-with-jsx.md'],
    'camkes': ['https://raw.githubusercontent.com/seL4/camkes-tool/master/README.md'],
    'dg': ['https://raw.githubusercontent.com/pyos/dg/master/README.rst'],
}


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_object(directory, identity):
    if not isinstance(identity, str) or SHA.fullmatch(identity) is None:
        raise ValueError('Invalid CAS SHA-256')
    body = (Path(directory) / identity).read_bytes()
    if hashlib.sha256(body).hexdigest() != identity:
        raise ValueError('CAS integrity failure: ' + identity)
    return body


def dump(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_bytes(encoded(value) + b'\n')
    temporary.replace(path)


def normalized_text(text, limit=180):
    return ' '.join(text.split())[:limit]


class SectionParser(HTMLParser):
    """Only structural heading/link extraction; script contents are never run."""
    def __init__(self, base_url):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.sections = []
        self.links = {}
        self.heading = None
        self.anchor = None
        self.ignore = 0
        self.title_depth = 0
        self.title_parts = []

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if tag in {'script', 'style'}:
            self.ignore += 1
        if self.ignore:
            return
        if tag == 'title':
            self.title_depth += 1
        if re.fullmatch('h[1-6]', tag):
            self.finish_heading()
            self.heading = {'level': int(tag[1]), 'anchor': attributes.get('id'),
                            'line': self.getpos()[0], 'parts': []}
        if self.heading and not self.heading['anchor']:
            self.heading['anchor'] = attributes.get('id') or attributes.get('name')
        if tag == 'a':
            self.finish_link()
            href = attributes.get('href', '')
            absolute = urllib.parse.urljoin(self.base_url, href)
            parsed = urllib.parse.urlsplit(absolute)
            base = urllib.parse.urlsplit(self.base_url)
            if (parsed.scheme == 'https' and parsed.netloc == base.netloc
                    and not parsed.username and not parsed.password):
                self.anchor = {'url': absolute, 'parts': []}

    def handle_endtag(self, tag):
        if tag in {'script', 'style'}:
            self.ignore = max(0, self.ignore - 1)
            return
        if self.ignore:
            return
        if re.fullmatch('h[1-6]', tag):
            self.finish_heading()
        if tag == 'a':
            self.finish_link()
        if tag == 'title':
            self.title_depth = max(0, self.title_depth - 1)

    def handle_data(self, data):
        if self.ignore:
            return
        if self.heading is not None:
            self.heading['parts'].append(data)
        if self.anchor is not None:
            self.anchor['parts'].append(data)
        if self.title_depth:
            self.title_parts.append(data)

    def finish_heading(self):
        if self.heading is None:
            return
        item = self.heading
        label = normalized_text(' '.join(item.pop('parts')))
        self.heading = None
        if not label:
            return
        ordinal = len(self.sections) + 1
        anchor = item['anchor']
        self.sections.append({**item, 'heading_ordinal': ordinal, 'heading': label,
                              'locator': '#' + anchor if anchor else 'html-heading:' + str(ordinal)})

    def finish_link(self):
        if self.anchor is None:
            return
        item = self.anchor
        self.anchor = None
        label = normalized_text(' '.join(item['parts']), 120)
        self.links.setdefault(item['url'], {'url': item['url'], 'label': label})


def plain_sections(text):
    """Recognize document heading notation, never classify normative meaning."""
    result = []
    lines = text.splitlines()
    for index, line in enumerate(lines):
        heading = None
        level = None
        match = re.match(r'^ {0,3}(#{1,6})\s+(.+?)\s*#*\s*$', line)
        if match:
            level, heading = len(match[1]), match[2]
        elif index + 1 < len(lines) and line.strip():
            under = lines[index + 1].strip()
            if len(under) >= 3 and len(set(under)) == 1 and under[0] in '=~-^"':
                level, heading = (1 if under[0] == '=' else 2), line
        if heading:
            result.append({'heading_ordinal': len(result) + 1, 'heading': normalized_text(heading),
                           'level': level, 'line': index + 1, 'anchor': None,
                           'locator': 'line:' + str(index + 1)})
    return result


def index_document(body, metadata):
    identity = hashlib.sha256(body).hexdigest()
    if identity != metadata['sha256']:
        raise ValueError('Document identity mismatch')
    url = metadata.get('final_url') or metadata['url']
    content_type = metadata.get('content_type', '').lower()
    result = {'body_sha256': identity, 'bytes': len(body), 'source_url': url,
              'content_type': content_type, 'reference_authority_reviewed': False,
              'exact_normative_version_audited': False,
              'semantic_understanding_claimed': False, 'full_body_exported': False,
              'section_inventory_is_structural_only': True, 'sections': [], 'same_origin_links': []}
    if body.startswith(b'%PDF-'):
        result['section_inventory_status'] = 'PDF_outline_or_manually_audited_section_extraction_required'
        return result
    if (body.count(b'\x00') > 3 or
            not ('text/' in content_type or 'html' in content_type or 'xml' in content_type
                 or body.lstrip().startswith((b'<!DOCTYPE', b'<!doctype', b'<html')))):
        result['section_inventory_status'] = 'unsupported_format_requires_specific_document_parser'
        return result
    charset = re.search(r'charset=([^;\s]+)', content_type)
    try:
        text = body.decode(charset[1].strip('"\'') if charset else 'utf-8', errors='replace')
    except LookupError:
        text = body.decode('utf-8', errors='replace')
    if 'html' in content_type or re.search(r'<(?:html|h[1-6])\b', text[:4096], re.I):
        parser = SectionParser(url)
        parser.feed(text)
        parser.close()
        parser.finish_heading()
        parser.finish_link()
        result['sections'] = parser.sections
        result['title'] = normalized_text(' '.join(parser.title_parts)) or metadata.get('title')
        links = sorted(parser.links.values(), key=lambda row: row['url'])
        # This is a bounded discovery frontier, not a claim to crawl every page.
        result['same_origin_link_count'] = len(links)
        result['same_origin_links'] = links[:256]
        result['link_frontier_truncated'] = len(links) > 256
    else:
        result['sections'] = plain_sections(text)
        result['title'] = metadata.get('title')
    result['section_count'] = len(result['sections'])
    result['section_inventory_status'] = 'structural_headings_indexed' if result['sections'] else 'no_structural_headings_found'
    return result


def public_https(url, resolve=None):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme not in {'https', 'http'} or not parsed.hostname or parsed.username
            or parsed.password or parsed.port not in {None, 443}
            or parsed.hostname.lower() in {'localhost', 'localhost.localdomain'}
            or any(c.isspace() for c in url)):
        raise ValueError('Only public, credential-free HTTPS reference URLs are admitted')
    hostname = parsed.hostname
    if resolve is None:
        # In the managed HTTPS proxy environment, the proxy resolves public
        # destinations. Direct container DNS is unavailable; it is not a test
        # of the reference's existence. Literal private IPs remain rejected.
        resolve = not bool(urllib.request.getproxies().get('https'))
    try:
        addresses = [ipaddress.ip_address(hostname)]
    except ValueError:
        addresses = [ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(hostname, 443, type=socket.SOCK_STREAM)] if resolve else []
    if any(not address.is_global for address in addresses):
        raise ValueError('Non-public reference address rejected')
    return urllib.parse.urlunsplit(('https', parsed.netloc, parsed.path or '/', parsed.query, ''))


class PublicRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urllib.parse.urlsplit(newurl).scheme != 'https':
            raise ValueError('HTTPS downgrade redirect rejected')
        return super().redirect_request(req, fp, code, msg, headers, public_https(newurl))


class SnapshotBudget:
    def __init__(self, directory, maximum_bytes):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.maximum_bytes = maximum_bytes
        self.written_bytes = 0
        self.lock = threading.Lock()

    def put(self, body):
        identity = hashlib.sha256(body).hexdigest()
        target = self.directory / identity
        with self.lock:
            if target.exists():
                read_object(self.directory, identity)
                return identity
            if self.written_bytes + len(body) > self.maximum_bytes:
                raise ValueError('Private snapshot disk budget exhausted; reference remains pending')
            # Exclusive create preserves prior snapshots and avoids cross-run overwrite.
            try:
                with target.open('xb') as stream:
                    stream.write(body)
            except FileExistsError:
                read_object(self.directory, identity)
                return identity
            self.written_bytes += len(body)
        return identity


def fetch_reference(url, budget):
    started = time.monotonic()
    outcome = {'url': url, 'retrieved': False, 'normative_standard_audited': False}
    try:
        url = public_https(url)
        opener = urllib.request.build_opener(PublicRedirect())
        with opener.open(urllib.request.Request(url), timeout=10) as response:
            body = response.read(MAX_BODY + 1)
            if len(body) > MAX_BODY:
                raise ValueError('Reference exceeds 4 MiB snapshot allowance; select exact chapters')
            if response.status != 200:
                raise ValueError('Expected complete HTTP 200 document')
            final = public_https(response.url)
            content_type = response.headers.get('Content-Type', '')
        identity = budget.put(body)
        outcome.update(retrieved=True, final_url=final, HTTP_status=200,
                       content_type=content_type, bytes=len(body), sha256=identity,
                       raw_snapshot_in_private_cache_only=True)
    except Exception as error:
        outcome['error'] = type(error).__name__ + ': ' + str(error)[:350]
        if isinstance(error, urllib.error.HTTPError):
            outcome['HTTP_status'] = error.code
    outcome['elapsed_seconds'] = time.monotonic() - started
    return outcome


def resource_admission(jobs, disk_directory):
    """Live memory/FD admission, independent of the number of logical actors."""
    if not isinstance(jobs, int) or jobs < 0:
        raise ValueError('Nonnegative distinct reference job count required')
    total = os.sysconf('SC_PHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
    working = 0
    observed = {}
    root = Path('/sys/fs/cgroup')
    try:
        maximum = (root / 'memory.max').read_text().strip()
        if maximum != 'max':
            total = min(total, int(maximum))
        stats = dict(line.split() for line in (root / 'memory.stat').read_text().splitlines())
        observed = {key: int(stats.get(key, 0)) for key in ['anon', 'kernel', 'shmem', 'file_dirty', 'file_writeback', 'unevictable']}
        working = sum(observed.values())
    except (OSError, ValueError):
        # Fallback uses actual MemAvailable rather than pretending all host RAM is free.
        values = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
        available = int(values['MemAvailable'].split()[0]) * 1024
        working = max(0, total - available)
    reserve = max(512 * 1024**2, total // 8)
    memory_budget = max(0, total - working - reserve)
    # Up to 4 MiB response + decoded/index buffers and ordinary thread stack.
    per_job = 32 * 1024**2
    memory_slots = memory_budget // per_job
    soft, _ = resource.getrlimit(resource.RLIMIT_NOFILE)
    descriptors_now = len(list(Path('/proc/self/fd').iterdir()))
    fd_slots = max(0, (soft - descriptors_now - 32) // 4) if soft != resource.RLIM_INFINITY else jobs
    admitted = min(jobs, memory_slots, fd_slots)
    disk = shutil.disk_usage(disk_directory).free
    return {'distinct_reference_jobs': jobs, 'thread_slots': admitted,
            'fixed_rounds': False, 'memory_maximum_bytes': total,
            'non_reclaimable_observations': observed, 'memory_budget_bytes': memory_budget,
            'per_fetch_reservation_bytes': per_job, 'file_descriptor_slots': fd_slots,
            'private_snapshot_budget_bytes': max(0, min(32 * 1024**2, disk // 4)),
            'physical_capacity_created_by_virtualization': False}


def route(task, policy_source=None):
    from usl_systems.language import Interpreter
    source = policy_source if policy_source is not None else (ROOT / 'semantic_records.usl').read_text()
    execution = Interpreter(capabilities={'semantic_record_inputs': lambda: task}, timeout=2, max_ops=4000).run(source)
    answer = execution.variables['decision']
    expected = {
        'reference_action': 'pin_version_and_audit_document_authority' if task['verified_document_count'] else 'retrieve_correct_upstream_reference',
        'syntax_action': ('extend_exact_scoped_frontend_with_missing_rules' if task['prior_scope'] else
                          'audit_parser_schema_then_implement_semantic_lowering' if task['parser_available'] else
                          'audit_highlighter_inventory_then_implement_frontend' if task['lexer_available'] else
                          'implement_versioned_lexical_and_parser_rules'),
        'semantic_action': ('audit_indexed_sections_and_write_clause_bound_semantic_rules' if task['document_section_count'] else
                            'retrieve_and_map_normative_semantic_clauses'),
        'host_action': ('retain_external_host_dependency_and_continue_independent_source_work' if task['external_dependency'] else
                        'identify_and_qualify_exact_native_host'),
        'library_action': 'inventory_exact_version_library_and_host_contracts',
        'work_kind': 'category_processing_contracts_and_applicability_audit' if task['category_processing'] else 'source_language_semantics',
        'full_semantic_record_complete': False, 'full_standard_qualified': False,
        'execute_native_program_from_documentation': False, 'blocked_host_blocks_source_audit': False}
    if answer != expected:
        raise ValueError('USL semantic record route disagrees with independent gate check')
    return answer, {'source': 'semantic_records.usl', 'sha256': hashlib.sha256(source.encode()).hexdigest(),
                    'operations': execution.operations, 'actual_USL_execution': True,
                    'independently_cross_checked': True}


def blocker(identifier, kind, evidence_hash, reason, action):
    value = {'catalog_id': identifier, 'kind': kind, 'evidence_sha256': evidence_hash,
             'reason': reason, 'next_action': action, 'resolved': False}
    return {'blocker_sha256': digest(value), **value}


def validate_rows(catalog):
    rows = catalog['entries']
    if len(rows) != 607 or len({row['catalog_id'] for row in rows}) != 607:
        raise ValueError('Expected exactly 607 unique catalog IDs')
    if sum(bool(row['original_catalog']) for row in rows) != 606:
        raise ValueError('Expected all 606 original IDs plus the USL host')
    if not any(row['catalog_id'] == 'usl' and not row['original_catalog'] for row in rows):
        raise ValueError('USL host ID missing')
    return rows


async def execute(output, catalog_path=ROOT / 'inputs/catalog.json', reference_path=ROOT / 'inputs/reference_status.json',
                  preparation_path=PREPARATION, cache_directory=PRIVATE_CACHE, fetch_missing=False):
    started_at = time.monotonic()
    paths = {'catalog': Path(catalog_path), 'reference_status': Path(reference_path),
             'preparation': Path(preparation_path), 'pipeline': ROOT / 'semantic_records.py',
             'USL_policy': ROOT / 'semantic_records.usl'}
    identities = {name: file_sha(path) for name, path in paths.items()}
    rows = validate_rows(json.loads(paths['catalog'].read_text()))
    references = json.loads(paths['reference_status'].read_text())['records']
    preparation = json.loads(paths['preparation'].read_text())
    prepared = {record['catalog_id']: record for record in preparation['records']}
    if set(prepared) != {row['catalog_id'] for row in rows}:
        raise ValueError('Preparation/catalog ID join is not exact')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    cache_directory = Path(cache_directory)
    ref_by_id = collections.defaultdict(list)
    for reference in references:
        for identifier in reference['catalog_ids']:
            ref_by_id[identifier].append(reference)
    distinct_urls = {reference['url'] for reference in references
                     if not reference.get('retrieved') or not (cache_directory / (reference.get('chosen') or {}).get('sha256', 'missing')).is_file()}
    admission = resource_admission(len(distinct_urls), output)
    budget = SnapshotBudget(cache_directory, admission['private_snapshot_budget_bytes'])
    pool = ThreadPoolExecutor(max_workers=max(1, admission['thread_slots'])) if fetch_missing and admission['thread_slots'] else None
    semaphore = asyncio.Semaphore(admission['thread_slots']) if pool else None
    policy_source = paths['USL_policy'].read_text()
    syntax_objects = {}
    document_objects = {}
    obligation_objects = {}
    reference_jobs = {}
    document_jobs = {}
    attempts = []
    release = asyncio.Event()
    live = 0
    peak = 0
    started_workers = 0
    cache_hits = 0
    syntax_requests = 0
    document_requests = 0
    doc_parse_count = 0
    fetches_started = 0
    fetches_live = 0
    fetches_peak = 0

    async def fetch_once(url):
        nonlocal fetches_started, fetches_live, fetches_peak
        if pool is None:
            return {'url': url, 'retrieved': False, 'error': 'Fresh retrieval not enabled or no admitted resources'}
        if url not in reference_jobs:
            async def perform():
                nonlocal fetches_started, fetches_live, fetches_peak
                async with semaphore:
                    fetches_started += 1
                    fetches_live += 1
                    fetches_peak = max(fetches_peak, fetches_live)
                    try:
                        result = await asyncio.get_running_loop().run_in_executor(pool, fetch_reference, url, budget)
                        attempts.append(result)
                        return result
                    finally:
                        fetches_live -= 1
            reference_jobs[url] = asyncio.create_task(perform())
        return await reference_jobs[url]

    async def document_once(metadata):
        nonlocal document_requests, cache_hits, doc_parse_count
        document_requests += 1
        # Parsing is pure in these exact bytes plus URL/content-type/encoding.
        # A shared body at a different URL has a different link-resolution base.
        index_key = digest({'body_sha256': metadata['sha256'], 'url': metadata.get('final_url') or metadata['url'],
                            'content_type': metadata.get('content_type', ''), 'indexer': identities['pipeline']})
        if index_key not in document_jobs:
            async def build():
                nonlocal cache_hits, doc_parse_count
                body = read_object(cache_directory, metadata['sha256'])
                cache_hits += 1
                artifact = index_document(body, metadata)
                artifact['index_input_identity'] = index_key
                key = digest(artifact)
                document_objects[key] = artifact
                doc_parse_count += 1
                return key
            document_jobs[index_key] = asyncio.create_task(build())
        return await document_jobs[index_key]

    async def worker(row):
        nonlocal live, peak, started_workers, syntax_requests
        live += 1
        peak = max(peak, live)
        started_workers += 1
        await release.wait()
        identifier = row['catalog_id']
        original = prepared[identifier]
        raw = read_object(paths['preparation'].parent / 'objects', original['evidence_sha256'])
        record = json.loads(raw)
        if record != original['record']:
            raise ValueError('Preparation CAS record mismatch for ' + identifier)
        syntax = {}
        for kind, value in [('lexer', record['lexer']), ('parser_schema', record['parser_schema'])]:
            if value is not None:
                syntax_requests += 1
                key = digest(value)
                if key in syntax_objects and syntax_objects[key] != value:
                    raise ValueError('Syntax identity collision')
                syntax_objects.setdefault(key, value)
                syntax[kind] = key
        obligation = {'ordered_steps': row['ordered_steps'], 'obligation_dimensions': row['obligation_dimensions']}
        obligation_hash = digest(obligation)
        obligation_objects.setdefault(obligation_hash, obligation)
        source_refs = ref_by_id.get(identifier, [])
        observations = []
        docs = []
        for reference in source_refs:
            chosen = reference.get('chosen') or {}
            if reference.get('retrieved') and chosen.get('sha256') and (cache_directory / chosen['sha256']).is_file():
                # Missing/corrupt advertised snapshots fail closed, not a fresh pass.
                read_object(cache_directory, chosen['sha256'])
                observation = {'reference_url': reference['url'], 'retrieved': True,
                               'source': 'prior_hash_verified_snapshot', 'chosen': chosen}
            else:
                result = await fetch_once(reference['url'])
                observation = {'reference_url': reference['url'], 'retrieved': result['retrieved'],
                               'source': 'fresh_public_retrieval' if pool else 'pending', 'chosen': result if result['retrieved'] else None,
                               'fresh_error': result.get('error')}
                # A 503 does not establish a dead URL. Replacements are retained
                # separately with their own identity and require an authority audit.
                if not observation['retrieved'] and pool:
                    for replacement in OFFICIAL_REPLACEMENTS.get(identifier, []):
                        if replacement == reference['url']:
                            continue
                        alternative = await fetch_once(replacement)
                        if alternative['retrieved']:
                            observation.update(retrieved=True, chosen=alternative,
                                               source='fresh_official_project_alternative', replaced_url=reference['url'])
                            break
            observations.append(observation)
            if observation['retrieved']:
                docs.append(await document_once(observation['chosen']))
        docs = list(dict.fromkeys(docs))
        section_count = sum(len(document_objects[key]['sections']) for key in docs)
        inputs = {'verified_document_count': len(docs), 'document_section_count': section_count,
                  'lexer_available': 'lexer' in syntax, 'parser_available': 'parser_schema' in syntax,
                  'prior_scope': bool(row['scoped']), 'category_processing': row['profile_kind'] == 'category_processing',
                  'external_dependency': bool(row['external_dependencies']),
                  'normative_rules_audited': False, 'full_conformance_passed': False}
        decision, receipt = route(inputs, policy_source)
        blockers = [blocker(identifier, 'exact_version_semantic_audit', identities['catalog'],
                            'No reviewed exact-version normative rule-to-implementation-to-test map is supplied',
                            'Pin standard/dialect/platform; review each applicable clause and attach syntax, static/dynamic rules and independent cases'),
                    blocker(identifier, 'full_library_abi_and_conformance', identities['catalog'],
                            'Current scoped evidence does not qualify all libraries, ABI, native behavior and full conformance',
                            'Inventory required APIs; implement remaining typed IR behavior; run native/differential/intent/upstream conformance and obtain independent review')]
        if not docs:
            blockers.append(blocker(identifier, 'reference_body_unavailable', identities['reference_status'],
                                    'No hash-verified upstream reference body is currently bound to this ID',
                                    'Find a live correct official reference, pin its exact version and retain content SHA-256'))
        if not syntax:
            blockers.append(blocker(identifier, 'syntax_inventory_missing', original['evidence_sha256'],
                                    'No usable lexer or parser inventory is supplied',
                                    'Extract syntax from the exact language specification and implement independent positive/negative frontend cases'))
        for dependency in row['external_dependencies']:
            blockers.append(blocker(identifier, 'external_host_dependency', digest(dependency), dependency['requires'], dependency['next_action']))
        packet = {'catalog_id': identifier, 'original_catalog': row['original_catalog'], 'family': row['family'],
                  'prior_scoped_profile': row['scoped'], 'profile_kind': row['profile_kind'], 'known_scoped_behavior': row['scope'],
                  'preparation_record_sha256': original['evidence_sha256'], 'syntax_objects': syntax,
                  'document_objects': docs, 'indexed_document_sections': section_count,
                  'upstream_reference_observations': observations,
                  'obligation_object_sha256': obligation_hash,
                  'ordered_step_count': len(row['ordered_steps']), 'obligation_dimension_count': len(row['obligation_dimensions']),
                  'native_host': {'requirement': row['host_requirement'], 'tool_requirement': row['original_tool_requirement'],
                                  'external_dependencies': row['external_dependencies'], 'fresh_execution_claimed': False},
                  'semantic_records': {'exact_version_identity': {'audited': False, 'candidate_profile': record['specification_profile']},
                                       'normative_rule_records': [], 'standard_library_contracts': [],
                                       'normative_feature_coverage_complete': False, 'library_inventory_complete': False,
                                       'complete': False, 'scope': 'structural syntax/reference inventory; per-clause semantic audit still required'},
                  'decision': decision, 'USL_execution': receipt, 'unresolved_blockers': blockers}
        live -= 1
        return packet

    try:
        tasks = [asyncio.create_task(worker(row)) for row in rows]
        await asyncio.sleep(0)
        if started_workers != len(rows) or peak != len(rows):
            raise ValueError('All 607 logical semantic discovery workers must start before release')
        release.set()
        packets = await asyncio.gather(*tasks)
    finally:
        if pool:
            pool.shutdown(wait=True, cancel_futures=True)
    final_identities = {name: file_sha(path) for name, path in paths.items()}
    if final_identities != identities:
        raise ValueError('Source or input changed during semantic record discovery')
    # Lossless joins are verified after factoring; sharing never supplies another
    # ID with missing normative evidence or manufactured runtime observations.
    for packet in packets:
        for identity in packet['syntax_objects'].values():
            if digest(syntax_objects[identity]) != identity:
                raise ValueError('Syntax artifact join failed')
        for identity in packet['document_objects']:
            if digest(document_objects[identity]) != identity:
                raise ValueError('Document artifact join failed')
        identity = packet['obligation_object_sha256']
        if digest(obligation_objects[identity]) != identity:
            raise ValueError('Obligation artifact join failed')
    originals = [packet for packet in packets if packet['original_catalog']]
    summary = {'schema': 'usl.semantic-discovery-records.v1', 'passed': True,
               'all_ids': len(packets), 'original_ids': len(originals), 'USL_extra': 1,
               'logical_workers_started_together': started_workers, 'peak_live_logical_workers': peak,
               'fixed_rounds': False, 'elapsed_seconds': time.monotonic() - started_at,
               'prior_scoped_originals': sum(packet['prior_scoped_profile'] for packet in originals),
               'originals_without_scope': sum(not packet['prior_scoped_profile'] for packet in originals),
               'full_semantic_records_complete': 0, 'full_standards_qualified': 0,
               'all_IDs_missing_exact_version_normative_audit': len(packets),
               'IDs_with_verified_reference_bodies': sum(bool(packet['document_objects']) for packet in packets),
               'IDs_with_indexed_sections': sum(bool(packet['indexed_document_sections']) for packet in packets),
               'IDs_with_lexer_inventory': sum('lexer' in packet['syntax_objects'] for packet in packets),
               'IDs_with_parser_schema': sum('parser_schema' in packet['syntax_objects'] for packet in packets),
               'all_ID_ordered_steps_preserved': sum(packet['ordered_step_count'] for packet in packets),
               'all_ID_obligation_dimensions_preserved': sum(packet['obligation_dimension_count'] for packet in packets),
               'unique_document_objects': len(document_objects), 'indexed_section_count': sum(len(doc['sections']) for doc in document_objects.values()),
               'document_requests': document_requests, 'pure_document_index_builds': doc_parse_count,
               'duplicate_document_index_builds_avoided': document_requests - doc_parse_count,
               'syntax_requests': syntax_requests, 'unique_syntax_objects': len(syntax_objects),
               'duplicate_syntax_serializations_avoided': syntax_requests - len(syntax_objects),
               'unique_obligation_objects': len(obligation_objects), 'all_factored_joins_hash_verified': True,
               'source_identities': identities, 'source_unchanged_during_run': True,
               'actual_USL_route_executions': len(packets), 'USL_routes_independently_checked': True,
               'native_execution_replayed': False, 'new_native_executions': 0,
               'fetch_missing_enabled': fetch_missing, 'fresh_distinct_HTTP_attempts': fetches_started,
               'fresh_successful_HTTP_attempts': sum(item['retrieved'] for item in attempts),
               'peak_admitted_HTTP_jobs': fetches_peak, 'private_snapshot_bytes_added': budget.written_bytes,
               'resource_admission': admission,
               'interpretation': 'Source discovery inventory, not complete language semantics or a qualification. Virtual workers share real host resources.'}
    report = {'summary': summary, 'records': sorted(packets, key=lambda item: item['catalog_id'])}
    for name, value in [('SEMANTIC_RECORDS.json', report), ('SEMANTIC_RECORD_SUMMARY.json', summary),
                        ('SYNTAX_OBJECTS.json', syntax_objects), ('DOCUMENT_OBJECTS.json', document_objects),
                        ('OBLIGATION_OBJECTS.json', obligation_objects), ('REFERENCE_ATTEMPTS.json', attempts)]:
        dump(output / name, value)
    manifest = {path.name: {'sha256': file_sha(path), 'bytes': path.stat().st_size} for path in sorted(output.iterdir())
                if path.is_file() and path.name in {'SEMANTIC_RECORDS.json', 'SEMANTIC_RECORD_SUMMARY.json',
                                                  'SYNTAX_OBJECTS.json', 'DOCUMENT_OBJECTS.json', 'OBLIGATION_OBJECTS.json', 'REFERENCE_ATTEMPTS.json'}}
    dump(output / 'RECORD_MANIFEST.json', manifest)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('semantic-records'))
    parser.add_argument('--catalog', type=Path, default=ROOT / 'inputs/catalog.json')
    parser.add_argument('--references', type=Path, default=ROOT / 'inputs/reference_status.json')
    parser.add_argument('--preparation', type=Path, default=PREPARATION)
    parser.add_argument('--private-cache', type=Path, default=PRIVATE_CACHE)
    parser.add_argument('--fetch-missing', action='store_true')
    arguments = parser.parse_args()
    sys.path.insert(0, str(arguments.source_root.resolve()))
    report = asyncio.run(execute(arguments.output, arguments.catalog, arguments.references, arguments.preparation,
                                 arguments.private_cache, arguments.fetch_missing))
    print(json.dumps(report['summary'], indent=2))
