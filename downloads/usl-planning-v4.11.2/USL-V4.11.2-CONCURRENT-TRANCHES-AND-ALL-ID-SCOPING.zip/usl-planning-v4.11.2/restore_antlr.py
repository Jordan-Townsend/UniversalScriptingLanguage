"""Restore pinned ANTLR C++/Python runtimes alongside the existing Java tool.

The Java ANTLR 4.9.2 generator and its dependencies come from the v4.11 setup.
Only two small Debian packages and one Python source archive are added here.
"""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
DEFAULT_PREFIX = Path('/workspace/.onboarding/antlr-v4112')
PYTHON_RUNTIME = {
    'filename': 'antlr4-python3-runtime-4.9.2.tar.gz',
    'url': 'https://files.pythonhosted.org/packages/04/9c/d5ef93dc1e5a862cae004a64d15425c2a1ae8ba967a08f03dfb11aedf7bf/antlr4-python3-runtime-4.9.2.tar.gz',
    'size': 117220,
    'sha256': '31f5abdc7faf16a1a6e9bf2eb31565d004359b821b09944436a34361929ae85a',
    'metadata_origin': 'https://pypi.org/pypi/antlr4-python3-runtime/4.9.2/json',
}


def restore(destination=DEFAULT_PREFIX):
    destination = Path(destination).resolve(); destination.mkdir(parents=True, exist_ok=True)
    archives = destination / 'archives'; archives.mkdir(exist_ok=True)
    metadata = json.loads((ROOT / 'inputs/antlr4-debian.json').read_text())
    packages = [p for p in metadata['packages'] if p['Package'] in {'libantlr4-runtime-dev', 'libantlr4-runtime4.9'}]
    if len(packages) != 2: raise ValueError('Both pinned C++ runtime packages are required')
    records = [{'filename': Path(p['Filename']).name,
                'url': 'https://deb.debian.org/debian/' + urllib.parse.quote(p['Filename'], safe='/+'),
                'size': int(p['Size']), 'sha256': p['SHA256'], 'package': p['Package']} for p in packages]
    records.append(dict(PYTHON_RUNTIME))

    def obtain(record):
        path = archives / record['filename']
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
            with urllib.request.urlopen(record['url'], timeout=45) as response: data = response.read()
            if len(data) != record['size'] or hashlib.sha256(data).hexdigest() != record['sha256']:
                raise ValueError('Download hash/size mismatch: ' + record['filename'])
            path.write_bytes(data)
        return path

    with ThreadPoolExecutor(max_workers=len(records)) as pool: paths = list(pool.map(obtain, records))
    for path in paths[:-1]: subprocess.run(['dpkg-deb', '--extract', str(path), str(destination)], check=True)
    python_root = destination / 'python'; python_root.mkdir(exist_ok=True)
    # Copy only regular package members; never extract links, setup.py or traversal.
    with tarfile.open(paths[-1], 'r:gz') as archive:
        for member in archive.getmembers():
            parts = Path(member.name).parts
            if len(parts) >= 3 and parts[1] == 'src' and parts[2] == 'antlr4' and member.isfile():
                relative = Path(*parts[2:])
                if '..' in relative.parts or relative.is_absolute(): raise ValueError('Unsafe archive member')
                target = python_root / relative; target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(member).read())
    if not (python_root / 'antlr4/__init__.py').exists(): raise ValueError('Missing Python runtime package')
    report = {'passed': True, 'prefix': str(destination), 'archives_hash_verified': records,
              'Java_generator_dependency': 'Existing ANTLR 4.9.2 generator from v4.11 setup',
              'native_binaries_shipped_in_addon': False}
    (destination / 'restore-report.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, default=DEFAULT_PREFIX)
    print(json.dumps(restore(parser.parse_args().destination), indent=2))
