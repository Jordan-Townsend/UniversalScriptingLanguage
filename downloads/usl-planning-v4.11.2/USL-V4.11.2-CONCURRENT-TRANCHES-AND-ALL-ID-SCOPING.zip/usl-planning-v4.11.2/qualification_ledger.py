"""Join exact, tested scoped receipts while retaining every full-profile gate."""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes(records):
    if not records:raise ValueError('Missing source identity bindings')
    for name,identity in records.items():
        path=(ROOT/name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file() or sha(path)!=identity:
            raise ValueError('Changed or missing qualification source: '+name)


def validate_forth(path):
    from forth_semantics import emit_usl
    from qualify_forth import cases
    report=json.loads(Path(path).read_text())
    if (report.get('schema')!='usl.forth.selected-stack-profile.v1' or report.get('catalog_id')!='forth'
            or report.get('passed') is not True or report.get('full_standard_qualified') is not False
            or report.get('native_execution_evidence_replayed') is not False or report.get('failures')):
        raise ValueError('Forth qualification gates did not pass')
    source_hashes(report['source_sha256'])
    expected={g['name']:g for g in cases()};observed={g['name']:g for g in report['groups']}
    if len(observed)!=len(report['groups']) or set(observed)!=set(expected):raise ValueError('Forth program group coverage changed')
    count=0
    for name,contract in expected.items():
        group=observed[name]
        if group.get('source')!=contract['source'] or group.get('contract')!=contract['contract']:
            raise ValueError('Forth independent contract/source changed')
        if len(group['records'])!=len(contract['cases']):raise ValueError('Missing Forth intent cases')
        generated=hashlib.sha256(emit_usl(contract['source']).encode()).hexdigest()
        for name,expected_hash in [(group['source_file'],hashlib.sha256(contract['source'].encode()).hexdigest()),(group['generated_file'],generated)]:
            artifact=(Path(path).parent/name).resolve()
            if not artifact.is_relative_to(Path(path).parent.resolve()) or sha(artifact)!=expected_hash:raise ValueError('Changed Forth source/generated artifact')
        for i,(record,case) in enumerate(zip(group['records'],contract['cases'])):
            receipt=record['USL_receipt']
            if (record.get('input')!=case['input'] or record.get('expected')!=case['expected']
                    or record.get('native')!=case['expected'] or record.get('generated_USL')!=case['expected']
                    or record.get('passed') is not True or receipt.get('actual_USL_execution') is not True
                    or receipt.get('generated_sha256')!=generated
                    or (i==0 and record.get('uncached_syntax_crosscheck')!=case['expected'])):
                raise ValueError('Forth counterexample, changed intent, or incomplete execution receipt')
            count+=1
        native=group['native_identity']
        if native.get('fresh_native_evaluations')!=len(contract['cases']) or native.get('native_execution_evidence_replayed') is not False:
            raise ValueError('Invalid Forth native accounting')
    if report['independent_intent_cases']!=count or report['fresh_native_processing_cases']!=count:
        raise ValueError('Forth summary is inconsistent')
    return [{'catalog_id':'forth','profile_kind':'code_expression','scope':report['scope'],
             'scoped_receipt_sha256':sha(path),'independent_intent_cases':count}]


def validate_antlr(path):
    from antlr_semantics import emit_usl
    from qualify_antlr import GRAMMARS,cases_for
    report=json.loads(Path(path).read_text())
    if (report.get('schema')!='usl.antlr4.scoped-qualification.v1' or report.get('passed') is not True
            or report.get('native_execution_evidence_replayed') is not False
            or report.get('full_standard_qualified') is not False):
        raise ValueError('ANTLR qualification gates did not pass')
    source_hashes(report['implementation_sha256'])
    for name,metadata in report['source_files'].items():
        candidate=(Path(path).parent/name).resolve()
        if not candidate.is_relative_to(Path(path).parent.resolve()) or sha(candidate)!=metadata['sha256'] or candidate.stat().st_size!=metadata['bytes']:
            raise ValueError('Changed ANTLR grammar or generated source')
    expected={}
    generated={g['id']:hashlib.sha256(emit_usl(g['source']).encode()).hexdigest() for g in GRAMMARS}
    for backend in ['python','cpp']:
        for grammar in GRAMMARS:
            for i,case in enumerate(cases_for(grammar)):
                expected[backend+':'+grammar['id']+':'+str(i)]=(backend,grammar['id'],case)
    observed={r['case_id']:r for r in report['cases']}
    if len(observed)!=len(report['cases']) or set(observed)!=set(expected):raise ValueError('ANTLR case set changed')
    if report['native_evaluations']!=len(expected):raise ValueError('ANTLR native accounting changed')
    for key,(backend,grammar,case) in expected.items():
        record=observed[key];receipt=record['USL_execution_receipt'];intent=case['independent_expected']
        if (record['backend']!=backend or record['grammar_id']!=grammar or record['input_text']!=case['input_text']
                or record['independent_expected'] is not intent or record['native_observed'] is not intent
                or record['generated_USL_observed'] is not intent or record['passed'] is not True
                or receipt.get('actual_USL_execution') is not True or receipt.get('generated_sha256')!=generated[grammar]):
            raise ValueError('ANTLR counterexample, changed intent, or missing execution evidence')
    proofs=report['symbolic_predicate_proofs']
    if set(proofs)!=set(generated) or not all(p['passed'] and p['solver_result']=='unsat' and p['generated_sha256']==generated[k] for k,p in proofs.items()):
        raise ValueError('ANTLR predicate proof gate failed')
    profiles=report['profiles']
    if {p['catalog_id'] for p in profiles}!={'antlr-python','antlr-cpp'} or len(profiles)!=2:
        raise ValueError('ANTLR profile join changed')
    output=[]
    for profile in profiles:
        if not profile['passed'] or profile['full_standard_qualified'] is not False or profile['complete_language_rule_set'] is not False:
            raise ValueError('Invalid ANTLR profile qualification status')
        backend='python' if profile['catalog_id']=='antlr-python' else 'cpp'
        if profile['native_evaluations']!=sum(r['backend']==backend for r in observed.values()):raise ValueError('ANTLR profile accounting changed')
        output.append({'catalog_id':profile['catalog_id'],'profile_kind':'category_processing','scope':profile['profile'],
                       'scoped_receipt_sha256':sha(path),'independent_intent_cases':profile['native_evaluations']})
    return output


def join(output):
    from planner import apply_scoped_receipt,validate_catalog
    document=json.loads((ROOT/'inputs/catalog.json').read_text())
    apply_scoped_receipt(document,ROOT/'semantic-final/brainfuck/qualification.json')
    additions=validate_forth(ROOT/'forth-results/qualification.json')+validate_antlr(ROOT/'antlr-results/qualification.json')
    rows={r['catalog_id']:r for r in document['entries']}
    if len({p['catalog_id'] for p in additions})!=len(additions):raise ValueError('Duplicate scope promotion')
    for profile in additions:
        row=rows[profile['catalog_id']]
        if row['scoped']:raise ValueError('Scope already in base; not a new promotion')
        row.update(profile,scoped=True,full_standard_qualified=False,normative_preparation_complete=False)
    originals=[r for r in rows.values() if r['original_catalog']]
    count=sum(r['scoped'] for r in originals)
    code_kinds={'closed_source_subset','function_fragment','embedded_source_subset','program_expression_subset','stack_expression_subset','code_expression'}
    processing_kinds={'template_processing','document_processing','transcript_processing','schema_processing','grammar_processing','query_processing','configuration_processing','configuration_validation','text_transformation','category_processing'}
    for row in originals:
        if row['scoped']:
            if row['profile_kind'] not in code_kinds|processing_kinds:raise ValueError('Unclassified qualified profile kind')
            row['profile_category']='code_expression' if row['profile_kind'] in code_kinds else 'category_processing'
    document['summary'].update(original_scoped=count,original_without_scope=606-count,
        new_scoped=len(additions),base_v4110_new_scoped=60,
        code_expression_profiles=sum(r['scoped'] and r['profile_category']=='code_expression' for r in originals),
        category_processing_profiles=sum(r['scoped'] and r['profile_category']=='category_processing' for r in originals))
    validate_catalog(document)
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    (output/'catalog.json').write_text(json.dumps(document,indent=2)+'\n')
    report={'passed':True,'summary':document['summary'],'new_scoped_profiles':additions,
            'source_receipts':{name:sha(ROOT/name) for name in ['semantic-final/brainfuck/qualification.json','forth-results/qualification.json','antlr-results/qualification.json']},
            'full_standards_qualified':0,'complete_entity_tracks':0,'scoping_records_promoted_to_executable_profiles':False}
    (output/'qualification-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report));return document


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--output',type=Path,default=Path('joined-results'))
    args=parser.parse_args();sys.path.insert(0,str(args.source_root.resolve()));join(args.output)
