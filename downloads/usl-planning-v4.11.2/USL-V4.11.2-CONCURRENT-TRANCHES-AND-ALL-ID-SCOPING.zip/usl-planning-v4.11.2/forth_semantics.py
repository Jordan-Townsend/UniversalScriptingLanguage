"""Gforth 0.7.3 selected-word frontend, pure stack IR, and actual USL execution.

This is an explicitly scoped profile, not a complete Forth implementation.
64-bit signed cell representation; arithmetic wraps; division is floored.
Definitions, calls, if/else/then, begin/until and begin/while/repeat are supported.
I/O, dictionary mutation, addresses, return-stack words and recursion are excluded.
"""
from __future__ import annotations

import ast
import hashlib
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time

MINIMUM = -(1 << 63)
MODULUS = 1 << 64
MAXIMUM = (1 << 63) - 1
DEFAULT_PREFIX = Path('/workspace/.onboarding/forth-v4112')
BINARY = {'+': 'b+a', '-': 'b-a', '*': 'b*a', '/': 'b//a', 'mod': 'b%a',
          'min': 'min(b,a)', 'max': 'max(b,a)', '=': '-1 if b==a else 0', '<>': '-1 if b!=a else 0',
          '<': '-1 if b<a else 0', '>': '-1 if b>a else 0', '<=': '-1 if b<=a else 0', '>=': '-1 if b>=a else 0'}
UNARY = {'negate': '-a', 'abs': 'abs(a)', '1+': 'a+1', '1-': 'a-1', '2*': 'a*2', '2/': 'a//2',
         '0=': '-1 if a==0 else 0', '0<': '-1 if a<0 else 0', '0>': '-1 if a>0 else 0',
         '0<>': '-1 if a!=0 else 0', 'invert': '-1-a'}
SPECIAL = ['dup', 'drop', 'swap', 'over', 'rot', '-rot', 'nip', 'tuck', '2dup', '2drop', '2swap', 'depth',
           '/mod', 'and', 'or', 'xor', 'lshift', 'rshift', 'true', 'false']
WORDS = list(BINARY) + list(UNARY) + SPECIAL
NAMES = {word: 'primitive' + str(i) for i, word in enumerate(WORDS)}
CONTROL = {'if', 'else', 'then', 'begin', 'until', 'while', 'repeat'}


class ForthProfileError(ValueError):
    pass


def cell(value):
    return (value - MINIMUM) % MODULUS + MINIMUM


def tokens(source):
    if not isinstance(source, str) or len(source) > 65536:
        raise ForthProfileError('Source must be at most65536 characters')
    if not source.isascii(): raise ForthProfileError('This profile requires entirely ASCII source')
    output = [];position = 0
    while position < len(source):
        while position < len(source) and source[position] in ' \t\n\r\v\f': position += 1
        if position == len(source): break
        match = re.match(r'[^ \t\n\r\v\f]+', source[position:]);word = match.group();position += len(word)
        if word == '\\':
            endings = [n for n in [source.find('\n', position), source.find('\r', position)] if n >= 0]
            position = min(endings) + 1 if endings else len(source)
        elif word == '(':
            end = source.find(')', position)
            if end < 0: raise ForthProfileError('Unclosed comment')
            position = end + 1
        else:
            if any(ord(c) > 127 for c in word): raise ForthProfileError('ASCII source words required by this profile')
            output.append(word.lower())
    return output


def frontend(source):
    stream = tokens(source);position = 0;definitions = {};order = []

    def sequence(stops, depth=0):
        nonlocal position
        if depth > 24: raise ForthProfileError('Control nesting exceeds24')
        nodes = []
        while position < len(stream) and stream[position] not in stops:
            word = stream[position];position += 1
            if word == 'if':
                yes, close = sequence({'else', 'then'}, depth + 1);no = []
                if close == 'else': no, close = sequence({'then'}, depth + 1)
                if close != 'then': raise ForthProfileError('Unclosed if')
                nodes.append(['if', yes, no])
            elif word == 'begin':
                body, close = sequence({'while', 'until'}, depth + 1)
                if close == 'until': nodes.append(['until', body])
                elif close == 'while':
                    tail, close = sequence({'repeat'}, depth + 1)
                    if close != 'repeat': raise ForthProfileError('Unclosed while')
                    nodes.append(['while', body, tail])
                else: raise ForthProfileError('Unclosed begin')
            elif word in NAMES: nodes.append(['primitive', word])
            elif word in definitions: nodes.append(['call', word])
            elif re.fullmatch(r'[+-]?[0-9]+', word):
                value = int(word)
                if not MINIMUM <= value <= MAXIMUM: raise ForthProfileError('Literal outside signed cell profile')
                nodes.append(['literal', value])
            else: raise ForthProfileError('Unsupported or undefined word: ' + word)
        close = stream[position] if position < len(stream) else None
        if close is not None: position += 1
        return nodes, close

    while position < len(stream):
        if stream[position] != ':': raise ForthProfileError('Only colon definitions are allowed at source top level')
        position += 1
        if position >= len(stream): raise ForthProfileError('Missing definition name')
        name = stream[position];position += 1
        if not re.fullmatch(r'[a-z][a-z0-9_-]*', name) or name in definitions or name in NAMES or name in CONTROL:
            raise ForthProfileError('Invalid or redefined name')
        body, close = sequence({';'})
        if close != ';': raise ForthProfileError('Unclosed definition')
        definitions[name] = body;order.append(name)
        if len(order) > 64: raise ForthProfileError('Definition limit64')
    if 'usl-main' not in definitions: raise ForthProfileError('Entry word usl-main is required')
    def calls(nodes):
        for node in nodes:
            if node[0] == 'call': yield node[1]
            elif node[0] in {'if', 'while'}:
                yield from calls(node[1]);yield from calls(node[2])
            elif node[0] == 'until': yield from calls(node[1])
    depths = {}
    for name in order:
        depths[name] = 1 + max((depths[target] for target in calls(definitions[name])), default=0)
        if depths[name] > 24: raise ForthProfileError('Definition call depth exceeds24')
    return {'schema': 'usl.forth.stack-IR.v1', 'entry': 'usl-main', 'definitions': definitions, 'order': order,
            'maximum_definition_call_depth': max(depths.values())}


def prelude():
    lines = [f'function signedcell(n):\n    return (n + {-MINIMUM}) % {MODULUS} - {-MINIMUM}',
             'function guard(stack):\n    let cursor = stack\n    let depth = 0\n    while len(cursor) != 0:\n        assert len(cursor) == 2\n        depth = depth + 1\n        assert depth <= 64, "forth:stack-limit"\n        cursor = cursor[1]\n    return stack',
             'function bitop(a,b,mode):\n    a = a % 18446744073709551616\n    b = b % 18446744073709551616\n    let value = 0\n    let place = 1\n    for bit in range(64):\n        let x = a % 2\n        let y = b % 2\n        let take = (x == 1 and y == 1) if mode == 0 else ((x == 1 or y == 1) if mode == 1 else x != y)\n        if take:\n            value = value + place\n        a = a // 2\n        b = b // 2\n        place = place * 2\n    return signedcell(value)']
    need = lambda count: ['assert len(stack) == 2, "forth:stack-underflow"'] if count == 1 else ['assert len(stack) == 2 and len(stack[1]) == 2, "forth:stack-underflow"']
    for word in WORDS:
        body = []
        if word in UNARY:
            body = need(1) + ['let a = stack[0]', f'stack = [signedcell({UNARY[word]}),stack[1]]']
        elif word in BINARY or word in {'/mod', 'and', 'or', 'xor', 'lshift', 'rshift'}:
            body = need(2) + ['let a = stack[0]', 'let b = stack[1][0]', 'let rest = stack[1][1]']
            if word in {'/', 'mod', '/mod'}:
                body += ['assert a != 0, "forth:division-by-zero"', f'assert not (b == {MINIMUM} and a == -1), "forth:division-overflow"']
            if word in {'lshift', 'rshift'}:
                body += ['assert a >= 0 and a < 64, "forth:shift-domain"']
            if word == '/mod': body += ['stack = [signedcell(b//a),[signedcell(b%a),rest]]']
            elif word in {'and', 'or', 'xor'}: body += [f'stack = [bitop(b,a,{["and","or","xor"].index(word)}),rest]']
            elif word == 'lshift': body += ['stack = [signedcell((b%18446744073709551616)*(2**a)),rest]']
            elif word == 'rshift': body += ['stack = [signedcell((b%18446744073709551616)//(2**a)),rest]']
            else: body += [f'stack = [signedcell({BINARY[word]}),rest]']
        elif word in {'true', 'false'}: body = [f'stack = [{-1 if word=="true" else 0},stack]']
        elif word == 'depth':
            body = ['let cursor = stack', 'let size = 0', 'while len(cursor) != 0:', '    size = size + 1', '    cursor = cursor[1]', 'stack = [size,stack]']
        else:
            counts = {'dup':1,'drop':1,'swap':2,'over':2,'rot':3,'-rot':3,'nip':2,'tuck':2,'2dup':2,'2drop':2,'2swap':4}
            count = counts[word];body = [];names = ['a','b','c','d'][:count]
            for name in reversed(names): body += need(1) + [f'let {name} = stack[0]', 'stack = stack[1]']
            permutations = {'dup':['a','a'],'drop':[],'swap':['b','a'],'over':['a','b','a'],
                            'rot':['b','c','a'],'-rot':['c','a','b'],'nip':['b'],'tuck':['b','a','b'],
                            '2dup':['a','b','a','b'],'2drop':[],'2swap':['c','d','a','b']}
            for name in permutations[word]: body += [f'stack = [{name},stack]']
        body += ['return guard(stack)']
        lines.append('function ' + NAMES[word] + '(stack):\n' + '\n'.join('    ' + line for line in body))
    return '\n\n'.join(lines) + '\n\n'


def emit_usl(source):
    ir = frontend(source);names = {word:'definition'+str(index) for index,word in enumerate(ir['order'])}
    lines = [prelude()]

    def emit(nodes, depth):
        indentation = '    ' * depth
        if not nodes: lines.append(indentation + 'pass')
        for node in nodes:
            kind = node[0]
            if kind == 'literal': lines.append(indentation + f'stack = guard([{node[1]},stack])')
            elif kind in {'primitive','call'}:
                name = NAMES[node[1]] if kind=='primitive' else names[node[1]]
                lines.append(indentation + 'stack = ' + name + '(stack)')
            elif kind == 'if':
                lines.extend(indentation + line for line in ['assert len(stack) == 2, "forth:stack-underflow"','let condition = stack[0]','stack = stack[1]','if condition != 0:'])
                emit(node[1],depth+1);lines.append(indentation+'else:');emit(node[2],depth+1)
            else:
                lines.append(indentation+'while True:');emit(node[1],depth+1)
                lines.extend(indentation+'    '+line for line in ['assert len(stack) == 2, "forth:stack-underflow"','let condition = stack[0]','stack = stack[1]'])
                lines.append(indentation+'    '+('if condition != 0:' if kind=='until' else 'if condition == 0:'))
                lines.append(indentation+'        break')
                if kind=='while':emit(node[2],depth+1)
    for word in ir['order']:
        lines.append('function '+names[word]+'(stack):');emit(ir['definitions'][word],1);lines.append('    return guard(stack)')
    lines += ['let stack = forth_input_stack()', 'stack = ' + names['usl-main'] + '(stack)']
    return '\n'.join(lines)+'\n'


class Program:
    def __init__(self, source):
        from usl_systems.language import parse
        self.source = source;self.generated = emit_usl(source);self.tree = parse(self.generated)
        self.artifact_sha256 = hashlib.sha256(self.generated.encode()).hexdigest()

    def run(self, inputs, cached_syntax=True):
        from usl_systems.language import Interpreter
        if len(inputs)>64 or any(type(n) is not int or not MINIMUM<=n<=MAXIMUM for n in inputs):
            raise ForthProfileError('Input stack exceeds declared cell/depth profile')
        stack = []
        for value in inputs: stack = [value, stack]
        interpreter = Interpreter(capabilities={'forth_input_stack':lambda:stack},timeout=3,max_ops=2_000_000)
        if cached_syntax:
            interpreter.start=time.monotonic();interpreter.statements(self.tree.body,interpreter.env)
            value=interpreter.env['stack'];operations=interpreter.operations
        else:
            result=interpreter.run(self.generated);value=result.variables['stack'];operations=result.operations
        output=[]
        while value:
            if len(value)!=2 or len(output)>=64: raise ForthProfileError('Malformed output stack')
            output.append(value[0]);value=value[1]
        return list(reversed(output)),{'actual_USL_execution':True,'operations':operations,'cached_pure_syntax_only':cached_syntax,'generated_sha256':self.artifact_sha256}


def native_batch(source, inputs, prefix=DEFAULT_PREFIX):
    ir=frontend(source)
    prefix=Path(prefix);image=prefix/'usr/lib/x86_64-linux-gnu/gforth/0.7.3/gforth.fi'
    binary=prefix/'usr/bin/gforth-0.7.3'
    paths=str(prefix/'usr/share/gforth/0.7.3')+':'+str(image.parent)
    marker='harnessreset'+hashlib.sha256(source.encode()).hexdigest()[:16]
    while any(marker+suffix in ir['definitions'] for suffix in ['', 'display', 'exit']): marker+='x'
    display=marker+'display'
    exit_word=marker+'exit'
    # Bind host harness words before user dictionary additions can shadow them.
    harness='decimal\n: '+marker+' depth 0 ?do drop loop ;\n: '+display+' ." <" depth 0 .r ." > " depth 0 ?do depth i - 1- pick . loop cr ;\n: '+exit_word+' bye ;\n'+source+'\n'
    for values in inputs:
        if len(values)>64 or any(type(n)is not int or not MINIMUM<=n<=MAXIMUM for n in values):raise ForthProfileError('Native input outside profile')
        harness+=' '.join(str(n) for n in values)+' usl-main '+display+' '+marker+'\n'
    harness+=exit_word+'\n'
    with tempfile.TemporaryDirectory(prefix='usl-forth-') as temporary:
        script=Path(temporary)/'program.fs';script.write_text(harness)
        result=subprocess.run([str(binary),'-i',str(image),'-p',paths,str(script)],capture_output=True,timeout=10)
    if result.returncode:raise ForthProfileError('Native Gforth failed: '+result.stderr.decode(errors='replace')[:500])
    lines=result.stdout.decode('ascii').splitlines();outputs=[]
    for line in lines:
        match=re.fullmatch(r'\s*<(\d+)>\s*(.*?)\s*',line)
        if not match:raise ForthProfileError('Unexpected native output: '+line[:150])
        values=[int(n) for n in match[2].split()]
        if len(values)!=int(match[1]):raise ForthProfileError('Native stack serialization truncated')
        outputs.append(values)
    if len(outputs)!=len(inputs):raise ForthProfileError('Native case count mismatch')
    return outputs,{'native_runtime':'Gforth0.7.3','native_processes':1,'fresh_native_evaluations':len(outputs),
                    'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),
                    'native_execution_evidence_replayed':False,'stderr':result.stderr.decode(errors='replace')}
