"""Execute the lossless JSON -> USL -> JSON processing path."""
import argparse
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--emit-usl', type=Path)
    parser.add_argument('--duplicate-policy', choices=['reject', 'preserve'], default='reject')
    args = parser.parse_args();sys.path.insert(0, str(args.source_root.resolve()))
    from json_semantics import emit_usl, generate_json, parse_json, run_usl
    original = parse_json(args.input.read_bytes())
    executed = run_usl(original)
    encoded = generate_json(executed, duplicate_policy=args.duplicate_policy)
    if parse_json(encoded) != original:
        raise ValueError('Lossless processing contract failed')
    if args.emit_usl:
        args.emit_usl.write_text(emit_usl(original))
    args.output.write_bytes(encoded)


if __name__ == '__main__':
    main()
