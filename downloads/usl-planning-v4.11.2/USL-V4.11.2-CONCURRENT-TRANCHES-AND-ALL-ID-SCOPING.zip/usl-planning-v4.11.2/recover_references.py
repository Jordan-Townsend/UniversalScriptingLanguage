"""Concurrent official/upstream reference recovery for 137 initially missing IDs.

Retrieved content is documentation/source evidence only. It is never executed or
treated as a complete specification, semantic understanding or qualification.
"""
from __future__ import annotations

import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
MAX_BODY = 2 * 1024**2
MAX_NEW_CACHE = 20 * 1024**2
DISK_RESERVE = 96 * 1024**2
PRIVATE_CACHE = Path('/workspace/.onboarding/data/v411-public-reference-cache')

# IDs on one line deliberately share the same upstream component. Such sharing
# is reference discovery only, not a claim that dialects or semantics coincide.
# main/master are moving discovery snapshots; every observed body is SHA-pinned.
FALLBACKS = r'''
abap|https://raw.githubusercontent.com/SAP-samples/abap-cheat-sheets/main/README.md|https://help.sap.com/doc/abapdocu_latest_index_htm/latest/en-US/index.htm
actionscript|https://raw.githubusercontent.com/apache/flex-sdk/master/README|https://raw.githubusercontent.com/apache/flex-sdk/master/README.md
agda literate-agda|https://raw.githubusercontent.com/agda/agda/master/doc/user-manual/language/lexical-structure.rst|https://raw.githubusercontent.com/agda/agda/master/README.md
alloy|https://raw.githubusercontent.com/AlloyTools/org.alloytools.alloy/master/README.md|https://alloytools.org/documentation.html
ampl|https://dev.ampl.com/ampl/reference/index.html|https://raw.githubusercontent.com/ampl/amplpy/master/README.md
ansys|https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/ans_cmd/Hlp_C_CmdTOC.html|https://raw.githubusercontent.com/ansys/pymapdl/main/README.rst
apl|https://www.gnu.org/software/apl/|https://raw.githubusercontent.com/ilovezfs/gnu-apl/master/README
arduino|https://raw.githubusercontent.com/arduino/docs-content/main/content/learn/01.starting-guide/00.whats-arduino/whats-arduino.md|https://raw.githubusercontent.com/arduino/ArduinoCore-avr/master/README.md
arturo|https://raw.githubusercontent.com/arturo-lang/arturo/master/README.md|https://raw.githubusercontent.com/arturo-lang/arturo/main/README.md
aspectj|https://raw.githubusercontent.com/eclipse-aspectj/aspectj/master/README.md|https://eclipse.dev/aspectj/doc/released/progguide/index.html
asymptote|https://raw.githubusercontent.com/vectorgraphics/asymptote/master/README.md|https://raw.githubusercontent.com/vectorgraphics/asymptote/master/README
autohotkey|https://raw.githubusercontent.com/AutoHotkey/AutoHotkeyDocs/v2/docs/Language.htm|https://raw.githubusercontent.com/AutoHotkey/AutoHotkey/v2.0/README.md
basemake|https://pubs.opengroup.org/onlinepubs/9799919799/utilities/make.html|https://www.gnu.org/software/make/manual/html_node/Introduction.html
batch|https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cmd|https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/for
bdd|https://raw.githubusercontent.com/cucumber/gherkin/main/README.md|https://cucumber.io/docs/gherkin/reference/
befunge|https://raw.githubusercontent.com/catseye/Befunge-93/master/doc/Befunge-93.markdown|https://raw.githubusercontent.com/catseye/Befunge-93/master/README.markdown
blitzbasic|https://raw.githubusercontent.com/blitz-research/blitz3d/master/README.md|https://blitzresearch.itch.io/blitz3d
blitzmax|https://raw.githubusercontent.com/bmx-ng/bmx-ng/master/README.md|https://blitzmax.org/docs/en/language/
bnf|https://www.rfc-editor.org/rfc/rfc5234.txt|https://www.w3.org/TR/REC-xml/#sec-notation
boa|https://raw.githubusercontent.com/boalang/compiler/master/README.md|https://boa.cs.iastate.edu/docs/language-overview.php
bugs|https://www.openbugs.net/Manuals/ModelSpecification.html|https://www.openbugs.net/Manuals/Manual.html
capdl|https://raw.githubusercontent.com/seL4/capdl/master/README.md|https://raw.githubusercontent.com/seL4/capdl/master/capDL-tool/README.md
cbmbas|https://www.c64-wiki.com/wiki/BASIC|https://www.pagetable.com/c64ref/c64programmersref.pdf
ceylon|https://raw.githubusercontent.com/eclipse-archived/ceylon/master/README.md|https://raw.githubusercontent.com/ceylon/ceylon/master/README.md
cfengine3|https://raw.githubusercontent.com/cfengine/core/master/README.md|https://docs.cfengine.com/latest/reference-language-concepts.html
charmci|https://raw.githubusercontent.com/UIUC-PPL/charm/main/README.md|https://charm.readthedocs.io/en/latest/charm++/manual.html
comal|https://www.c64-wiki.com/wiki/COMAL|https://archive.org/details/Comal80Version2.01Manual
componentpascal|https://blackboxframework.org/index.php?cID=home,en|https://raw.githubusercontent.com/gpcp/gpcp/master/README.md
croc minid|https://raw.githubusercontent.com/jaricom/croc/master/README.md|https://jfbillingsley.com/croc/docs/
cryptol literate-cryptol|https://raw.githubusercontent.com/GaloisInc/cryptol/master/README.md|https://cryptol.net/files/ProgrammingCryptol.pdf
css+lasso html+lasso javascript+lasso lasso xml+lasso|https://www.lassoguide.com/language/index.html|https://www.lassoguide.com/language/inline.html
css+myghty html+myghty javascript+myghty myghty xml+myghty|https://raw.githubusercontent.com/zzzeek/myghty/master/README|https://raw.githubusercontent.com/zzzeek/myghty/master/README.txt
cypher|https://raw.githubusercontent.com/opencypher/openCypher/master/README.adoc|https://neo4j.com/docs/cypher-manual/current/introduction/
dasm16|https://raw.githubusercontent.com/itsapi/dcpu16/master/README.md|https://raw.githubusercontent.com/dcpu16/specifications/master/dcpu16.txt
dg|https://raw.githubusercontent.com/pyos/dg/master/README.rst|https://raw.githubusercontent.com/pyos/dg/master/README.md
docker|https://raw.githubusercontent.com/moby/buildkit/master/frontend/dockerfile/docs/reference.md|https://docs.docker.com/reference/dockerfile/
easytrieve|https://techdocs.broadcom.com/us/en/ca-mainframe-software/devops/ca-easytrieve-report-generator/11-6.html|https://www.broadcom.com/products/mainframe/application-development/easytrieve-report-generator
ecl|https://raw.githubusercontent.com/hpcc-systems/HPCC-Platform/master/README.md|https://hpccsystems.com/wp-content/uploads/2022/12/ECLLanguageReference-9.0.0-1.pdf
emacs-lisp|https://www.gnu.org/software/emacs/manual/html_node/elisp/Introduction.html|https://raw.githubusercontent.com/emacs-mirror/emacs/master/etc/README
evoque html+evoque xml+evoque|https://raw.githubusercontent.com/marrow/evoque/master/README.rst|https://gizmojo.org/evoque/
extempore|https://raw.githubusercontent.com/digego/extempore/master/README.md|https://extemporelang.github.io/docs/
ezhil|https://raw.githubusercontent.com/Ezhil-Language-Foundation/Ezhil-Lang/master/README.md|https://ezhillang.org/
fan|https://raw.githubusercontent.com/fantom-lang/fantom/master/readme.md|https://fantom.org/doc/docLang/
felix|https://raw.githubusercontent.com/felix-lang/felix/master/README.md|https://felix-lang.github.io/felix/
forth|https://forth-standard.org/standard/usage|https://www.complang.tuwien.ac.at/forth/gforth/Docs-html/Introduction.html
func|https://raw.githubusercontent.com/ton-blockchain/ton/master/crypto/func/README.md|https://docs.ton.org/v3/documentation/smart-contracts/func/overview
gdscript|https://raw.githubusercontent.com/godotengine/godot-docs/master/tutorials/scripting/gdscript/gdscript_basics.rst|https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/gdscript_basics.html
glsl|https://raw.githubusercontent.com/KhronosGroup/GLSL/main/README.adoc|https://raw.githubusercontent.com/KhronosGroup/GLSL/main/extensions/README.md
golo|https://raw.githubusercontent.com/eclipse-archived/golo-lang/master/README.md|https://raw.githubusercontent.com/eclipse/golo-lang/master/README.md
gooddata-cl|https://raw.githubusercontent.com/gooddata/GoodData-CL/master/README.md|https://raw.githubusercontent.com/gooddata/GoodData-CL/master/README
gsql|https://docs.tigergraph.com/gsql-ref/current/intro|https://raw.githubusercontent.com/tigergraph/gsql-graph-algorithms/master/README.md
haxeml|https://raw.githubusercontent.com/HaxeFoundation/HaxeManual/master/website-content/09-compiler-usage.md|https://haxe.org/manual/compiler-usage-hxml.html
hsail|https://raw.githubusercontent.com/HSAFoundation/HSAIL-Tools/master/README.md|https://raw.githubusercontent.com/HSAFoundation/HSAIL-Tools/master/README
html+ng2 ng2|https://angular.dev/guide/templates|https://raw.githubusercontent.com/angular/angular/main/adev/src/content/guide/templates.md
i6t inform7|https://raw.githubusercontent.com/ganelson/inform/master/README.md|https://ganelson.github.io/inform/
icon ucode unicon|https://raw.githubusercontent.com/uniconproject/unicon/master/README.md|https://www2.cs.arizona.edu/icon/uguide.htm
idl|https://www.nv5geospatialsoftware.com/docs/idl.html|https://www.nv5geospatialsoftware.com/docs/idl_programming.html
jcl|https://www.ibm.com/docs/en/zos/3.1.0?topic=language-jcl-statements|https://www.ibm.com/docs/en/zos/3.1.0?topic=concepts-job-control-language-jcl
literate-idris|https://raw.githubusercontent.com/idris-lang/Idris2/main/docs/source/reference/literate.rst|https://raw.githubusercontent.com/idris-lang/Idris2/main/README.md
logos|https://raw.githubusercontent.com/theos/logos/master/README.md|https://theos.dev/docs/logos
luau|https://raw.githubusercontent.com/luau-lang/luau/master/README.md|https://luau.org/syntax
macaulay2|https://raw.githubusercontent.com/Macaulay2/M2/master/README.md|https://macaulay2.com/doc/Macaulay2/share/doc/Macaulay2/Macaulay2Doc/html/index.html
mason|https://raw.githubusercontent.com/houseabsolute/HTML-Mason/master/README|https://metacpan.org/pod/HTML::Mason
mcfunction|https://learn.microsoft.com/en-us/minecraft/creator/documents/functionsintroduction?view=minecraft-bedrock-stable|https://minecraft.wiki/w/Function_(Java_Edition)
mips|https://raw.githubusercontent.com/qemu/qemu/master/target/mips/README|https://www.linux-mips.org/wiki/Instruction_Set_Architecture
mojo|https://raw.githubusercontent.com/modular/modular/main/mojo/README.md|https://docs.modular.com/mojo/manual/
monte|https://raw.githubusercontent.com/monte-language/monte/master/README.md|https://monte.readthedocs.io/en/latest/
moonscript|https://raw.githubusercontent.com/leafo/moonscript/master/README.md|https://moonscript.org/reference/
mql|https://www.mql5.com/en/docs/basis|https://docs.mql4.com/basis
mxml|https://raw.githubusercontent.com/apache/flex-sdk/master/frameworks/projects/framework/src/mx/core/UIComponent.as|https://flex.apache.org/doc/flex/using/flx_mxml_fi.html
nemerle|https://raw.githubusercontent.com/rsdn/nemerle/master/README.md|https://nemerle.org/About/
nesc|https://raw.githubusercontent.com/tinyos/nesc/master/README.md|https://raw.githubusercontent.com/tinyos/nesc/master/README
newlisp|https://newlisp.org/downloads/newlisp_manual.html|https://raw.githubusercontent.com/kosh04/newlisp/master/README
nimrod|https://raw.githubusercontent.com/nim-lang/Nim/version-2-2/doc/manual.md|https://nim-lang.org/docs/manual.html
nsis|https://raw.githubusercontent.com/NSIS-Dev/nsis/master/README|https://nsis.sourceforge.io/Docs/Chapter4.html
numba_ir|https://raw.githubusercontent.com/numba/numba/main/docs/source/developer/architecture.rst|https://numba.readthedocs.io/en/stable/developer/architecture.html
objective-j|https://raw.githubusercontent.com/cappuccino/cappuccino/master/README.md|https://www.cappuccino.dev/learn/objective-j.html
octave|https://raw.githubusercontent.com/gnu-octave/octave/default/README|https://docs.octave.org/latest/
openedge|https://documentation.progress.com/output/ua/OpenEdge_latest/index.html#page/gsabl/what-is-abl.html|https://docs.progress.com/category/openedge-abl
pacmanconf|https://raw.githubusercontent.com/archlinux/pacman/master/doc/pacman.conf.5.asciidoc|https://pacman.archlinux.page/pacman.conf.5.html
pddl|https://planning.wiki/ref/pddl|https://raw.githubusercontent.com/aibasel/downward/main/README.md
pointless|https://raw.githubusercontent.com/pointless-lang/pointless/master/README.md|https://ptls.dev/
portugol|https://raw.githubusercontent.com/DesignLiquido/visualg/master/README.md|https://www.apoioinformatica.inf.br/produtos/visualg
pov|https://raw.githubusercontent.com/POV-Ray/povray/master/README.md|https://www.povray.org/documentation/3.7.0/
promql|https://raw.githubusercontent.com/prometheus/prometheus/main/docs/querying/basics.md|https://prometheus.io/docs/prometheus/latest/querying/basics/
qbasic|https://raw.githubusercontent.com/QB64-Phoenix-Edition/QB64pe/main/README.md|https://qb64phoenix.com/qb64wiki/index.php/Keyword_Reference_-_Alphabetical
redcode|https://raw.githubusercontent.com/mbarbon/pMARS/master/README|https://corewar.co.uk/standards/icws94.htm
registry|https://learn.microsoft.com/en-us/windows/win32/sysinfo/registry-value-types|https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/reg-import
rell|https://raw.githubusercontent.com/ChromiaProject/rell/master/README.md|https://docs.chromia.com/rell/language-features/
ride|https://raw.githubusercontent.com/wavesplatform/Waves/master/README.md|https://docs.waves.tech/en/ride/structures-and-operators/
rql|https://forge.extranet.logilab.fr/cubicweb/RQL/-/raw/default/README.rst|https://pypi.org/project/rql/
rsl|https://raisetools.github.io/|https://raw.githubusercontent.com/raisetools/rsltc/master/README
sas|https://documentation.sas.com/doc/en/pgmsascdc/9.4_3.5/lestmtsref/titlepage.htm|https://support.sas.com/documentation/cdl/en/basess/58133/PDF/default/basess.pdf
sieve|https://www.rfc-editor.org/rfc/rfc5228.txt|https://doc.dovecot.org/main/core/config/sieve.html
singularity|https://apptainer.org/docs/user/latest/definition_files.html|https://raw.githubusercontent.com/apptainer/apptainer/main/README.md
slurm|https://slurm.schedmd.com/sbatch.html|https://raw.githubusercontent.com/SchedMD/slurm/master/doc/man/man1/sbatch.1
smalltalk|https://www.gnu.org/software/smalltalk/manual/html_node/Language.html|https://raw.githubusercontent.com/gnu-smalltalk/smalltalk/master/README
solidity|https://raw.githubusercontent.com/ethereum/solidity/develop/docs/grammar.rst|https://docs.soliditylang.org/en/latest/grammar.html
sophia|https://raw.githubusercontent.com/aeternity/aesophia/master/README.md|https://docs.aeternity.com/aesophia/
stata|https://www.stata.com/manuals/p.pdf|https://www.stata.com/manuals/u18.pdf
swig|https://raw.githubusercontent.com/swig/swig/master/Doc/Manual/SWIG.html|https://www.swig.org/Doc4.3/SWIG.html
tact|https://raw.githubusercontent.com/tact-lang/tact/main/README.md|https://docs.tact-lang.org/book/types/
tasm|https://bitsavers.org/pdf/borland/turbo_assembler/Turbo_Assembler_Users_Guide_Version_5_1996.pdf|https://docwiki.embarcadero.com/RADStudio/Athens/en/Turbo_Assembler
teal|https://raw.githubusercontent.com/algorand/go-algorand/master/data/transactions/logic/README.md|https://dev.algorand.co/reference/algorand-teal/opcodes/
teratermmacro|https://raw.githubusercontent.com/TeraTermProject/teraterm/main/doc/en/html/macro/syntax/index.html|https://teratermproject.github.io/manual/5/en/macro/syntax/index.html
termcap|https://www.gnu.org/software/termutils/manual/termcap-1.3/html_node/termcap_toc.html|https://invisible-island.net/ncurses/man/termcap.5.html
terminfo|https://invisible-island.net/ncurses/man/terminfo.5.html|https://raw.githubusercontent.com/mirror/ncurses/master/man/terminfo.head
ti|https://raw.githubusercontent.com/thingsdb/ThingsDB/master/README.md|https://docs.thingsdb.io/v1/overview/
tid|https://raw.githubusercontent.com/TiddlyWiki/TiddlyWiki5/master/readme.md|https://tiddlywiki.com/static/WikiText.html
tlb|https://docs.ton.org/v3/documentation/data-formats/tlb/overview|https://raw.githubusercontent.com/ton-blockchain/ton/master/crypto/tl/boc.tlb
todotxt|https://raw.githubusercontent.com/todotxt/todo.txt/master/README.md|https://github.com/todotxt/todo.txt
unixconfig|https://man7.org/linux/man-pages/man5/passwd.5.html|https://man7.org/linux/man-pages/man5/group.5.html
usd|https://raw.githubusercontent.com/PixarAnimationStudios/OpenUSD/release/README.md|https://openusd.org/release/intro.html
verifpal|https://raw.githubusercontent.com/symbolicsoft/verifpal/master/README.md|https://verifpal.com/res/pdf/manual.pdf
vgl|https://www.thermofisher.com/us/en/home/digital-solutions/lab-informatics/samplemanager-lims.html|https://www.thermofisher.com/blog/connectedlab/what-is-vgl/
vyper|https://raw.githubusercontent.com/vyperlang/vyper/master/README.md|https://docs.vyperlang.org/en/stable/
wowtoc|https://warcraft.wiki.gg/wiki/TOC_format|https://warcraft.wiki.gg/wiki/AddOn_tutorial
xorg.conf|https://www.x.org/releases/current/doc/man/man5/xorg.conf.5.xhtml|https://www.x.org/archive/X11R7.0/doc/html/xorg.conf.5.html
xtend|https://raw.githubusercontent.com/eclipse-xtext/xtext-xtend/main/README.md|https://eclipse.dev/xtend/documentation/203_xtend_expressions.html
zephir|https://raw.githubusercontent.com/zephir-lang/zephir/master/README.md|https://docs.zephir-lang.com/latest/en/language/
'''

# RFC5234 ABNF is not original BNF; retain as a related contrast, not an exact
# normative replacement. Similar cross-dialect sources carry explicit caveats.
CAVEATS = {
    'bnf': 'RFC5234 specifies ABNF, not all BNF dialects; W3C EBNF notation is another profile. Choose/audit exact BNF dialect before implementation.',
    'actionscript': 'Apache Flex targets AS3; this is upstream family context, not proof of AS1/AS2 semantics or an AVM1 host.',
    'cbmbas': 'C64-wiki is a community reference; original Commodore programmer manual requires provenance and dialect audit.',
    'comal': 'Community/archive sources need original manual, release and license provenance review.',
    'pddl': 'planning.wiki is a community reference; Fast Downward supports a bounded subset, not all PDDL versions.',
    'portugol': 'Visualg is a Pascal-like Portugol profile; C-like Portugol Studio is not interchangeable.',
    'qbasic': 'QB64-PE is a compatible modern implementation candidate, not historical Microsoft QBasic qualification.',
    'nimrod': 'Modern Nim is not an exact historical Nimrod release; preserve version boundary.',
    'minid': 'Croc is the renamed successor; historical MiniD identity and semantics still require an exact release.',
    'ucode': 'Unicon documentation is related Icon-family context; original Icon ucode instruction and linker rules still need exact version audit.',
    'mips': 'An emulator source/reference is not the original MIPS ISA standard; pin ISA, endian and ABI separately.',
    'mxml': 'UIComponent source is upstream implementation evidence, not the complete MXML language specification.',
    'vgl': 'Vendor product context does not disclose the complete VGL grammar/semantics; licensed manual/API access remains open.',
    'ansys': 'PyMAPDL is an upstream API client; its README is not the APDL specification.',
    'ampl': 'amplpy is an upstream API client; its README is not the AMPL specification.',
    'gsql': 'An upstream algorithms README is an example/library source, not the full GSQL reference.',
    'idl': 'GNU Data Language is an IDL compatibility implementation; it is not NV5 vendor conformance evidence.',
    'jcl': 'IBM sample repository is upstream example/tooling context, not the complete z/OS JCL reference.',
    'sas': 'SASPy is an upstream SAS interface; its README is not the SAS language specification.',
    'openedge': 'ADE source is upstream tool/framework implementation evidence, not the complete ABL reference.',
}

ADDITIONAL_FALLBACKS = {
    'ansys': ['https://raw.githubusercontent.com/ansys/pymapdl/main/README.md'],
    'basemake': ['https://raw.githubusercontent.com/mirror/make/master/README'],
    'cbmbas': ['https://raw.githubusercontent.com/mist64/c64ref/main/README.md', 'https://raw.githubusercontent.com/mist64/c64ref/master/README.md'],
    'componentpascal': ['https://raw.githubusercontent.com/BlackBoxCenter/blackbox/master/README.md', 'https://raw.githubusercontent.com/k-john-gough/gpcp/master/README.md'],
    'croc': ['https://raw.githubusercontent.com/jfbillingsley/croc/master/README.md', 'https://raw.githubusercontent.com/jfbillingsley/croc/master/README.rst'],
    'minid': ['https://raw.githubusercontent.com/jfbillingsley/croc/master/README.md', 'https://raw.githubusercontent.com/jfbillingsley/croc/master/README.rst'],
    'css+lasso': ['https://raw.githubusercontent.com/lassosoft/LassoGuide/master/README.md'],
    'html+lasso': ['https://raw.githubusercontent.com/lassosoft/LassoGuide/master/README.md'],
    'javascript+lasso': ['https://raw.githubusercontent.com/lassosoft/LassoGuide/master/README.md'],
    'lasso': ['https://raw.githubusercontent.com/lassosoft/LassoGuide/master/README.md'],
    'xml+lasso': ['https://raw.githubusercontent.com/lassosoft/LassoGuide/master/README.md'],
    'css+myghty': ['https://raw.githubusercontent.com/zzzeek/myghty/master/README.rst', 'https://raw.githubusercontent.com/zzzeek/myghty/master/myghty/__init__.py'],
    'html+myghty': ['https://raw.githubusercontent.com/zzzeek/myghty/master/README.rst', 'https://raw.githubusercontent.com/zzzeek/myghty/master/myghty/__init__.py'],
    'javascript+myghty': ['https://raw.githubusercontent.com/zzzeek/myghty/master/README.rst', 'https://raw.githubusercontent.com/zzzeek/myghty/master/myghty/__init__.py'],
    'myghty': ['https://raw.githubusercontent.com/zzzeek/myghty/master/README.rst', 'https://raw.githubusercontent.com/zzzeek/myghty/master/myghty/__init__.py'],
    'xml+myghty': ['https://raw.githubusercontent.com/zzzeek/myghty/master/README.rst', 'https://raw.githubusercontent.com/zzzeek/myghty/master/myghty/__init__.py'],
    'dasm16': ['https://raw.githubusercontent.com/dcpu16/specifications/master/README.md', 'https://raw.githubusercontent.com/mappum/DCPU-16/master/README.md'],
    'gooddata-cl': ['https://raw.githubusercontent.com/gooddata/GoodData-CL/master/README.markdown', 'https://raw.githubusercontent.com/gooddata/GoodData-CL/master/pom.xml'],
    'html+ng2': ['https://raw.githubusercontent.com/angular/angular/main/adev/src/content/guide/templates/binding.md', 'https://raw.githubusercontent.com/angular/angular/main/README.md'],
    'ng2': ['https://raw.githubusercontent.com/angular/angular/main/adev/src/content/guide/templates/binding.md', 'https://raw.githubusercontent.com/angular/angular/main/README.md'],
    'idl': ['https://raw.githubusercontent.com/gnudatalanguage/gdl/master/README.md'],
    'mason': ['https://raw.githubusercontent.com/houseabsolute/HTML-Mason/master/README.md', 'https://raw.githubusercontent.com/houseabsolute/HTML-Mason/master/lib/HTML/Mason.pm'],
    'mips': ['https://raw.githubusercontent.com/qemu/qemu/master/target/mips/tcg/translate.c'],
    'mojo': ['https://raw.githubusercontent.com/modular/modular/main/README.md', 'https://raw.githubusercontent.com/modular/mojo/main/README.md'],
    'nsis': ['https://raw.githubusercontent.com/NSIS-Dev/nsis/master/README.md', 'https://raw.githubusercontent.com/kichik/nsis/master/README'],
    'pacmanconf': ['https://raw.githubusercontent.com/devkitPro/pacman/master/doc/pacman.conf.5.asciidoc'],
    'termcap': ['https://raw.githubusercontent.com/mirror/ncurses/master/man/termcap.5'],
    'unixconfig': ['https://raw.githubusercontent.com/shadow-maint/shadow/master/man/passwd.5.xml', 'https://raw.githubusercontent.com/shadow-maint/shadow/master/man/group.5.xml'],
    'wowtoc': ['https://raw.githubusercontent.com/Gethe/wow-ui-source/live/Interface/AddOns/Blizzard_APIDocumentation/Blizzard_APIDocumentation.toc'],
    'xorg.conf': ['https://raw.githubusercontent.com/freedesktop/xorg-xserver/master/hw/xfree86/man/xorg.conf.man', 'https://raw.githubusercontent.com/XQuartz/xorg-server/master/hw/xfree86/man/xorg.conf.man'],
    'xtend': ['https://raw.githubusercontent.com/eclipse-xtext/xtext/main/README.md', 'https://raw.githubusercontent.com/eclipse/xtext-xtend/master/README.md'],
}

MYGHTY_SOURCE = 'https://files.pythonhosted.org/packages/c2/bd/5943691a8b5c6f4fd46636b4ee126d58c0ee4add83e5d2ec991801b55abf/Myghty-1.1.tar.gz'
SOURCE_HASHES = {MYGHTY_SOURCE: '41bcf9f53c5752faff10cdce21770f41311fd38a6075d4a46f6b67cd1ae31689'}
for _identifier in ['myghty', 'html+myghty', 'css+myghty', 'javascript+myghty', 'xml+myghty']:
    ADDITIONAL_FALLBACKS[_identifier].append(MYGHTY_SOURCE)
    CAVEATS[_identifier] = 'The Myghty1.1 upstream PyPI source distribution is SHA-checked; its documentation/source must be inspected as inert data and the embedded target profile audited separately.'
ADDITIONAL_FALLBACKS['basemake'].append('https://raw.githubusercontent.com/mirror/make/master/README.md')
ADDITIONAL_FALLBACKS['termcap'].append('https://raw.githubusercontent.com/mirror/ncurses/master/man/curs_termcap.3x')
ADDITIONAL_FALLBACKS['jcl'] = ['https://raw.githubusercontent.com/IBM/zopeneditor-sample/main/README.md']
ADDITIONAL_FALLBACKS['sas'] = ['https://raw.githubusercontent.com/sassoftware/saspy/master/README.md']
ADDITIONAL_FALLBACKS['openedge'] = ['https://raw.githubusercontent.com/progress/ADE-Source/master/README.md']


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_bytes(encoded(value) + b'\n')


def fallback_table():
    result = {}
    for line in FALLBACKS.strip().splitlines():
        identifiers, *urls = line.split('|')
        for identifier in identifiers.split():
            if identifier in result:
                raise ValueError('Duplicate fallback ID: ' + identifier)
            result[identifier] = urls
    for identifier, urls in ADDITIONAL_FALLBACKS.items():
        result[identifier] = list(result[identifier]) + urls
    return result


def missing_rows():
    ledger = json.loads((ROOT / 'scope-all-results/ALL_IDS.json').read_text())
    return [r for r in ledger['records'] if r['remaining_unscoped_at_snapshot'] and not r['source_documents']]


def check_coverage(rows, table):
    identifiers = {r['catalog_id'] for r in rows}
    if len(rows) != 137 or len(identifiers) != 137:
        raise ValueError('Expected exactly the 137 initially missing original IDs')
    if identifiers != set(table):
        raise ValueError('Fallback coverage mismatch: ' + str(identifiers.symmetric_difference(table)))
    return identifiers


def fetch(url, budget):
    from semantic_records import PublicRedirect, public_https
    started = time.perf_counter()
    result = {'url': url, 'retrieved': False, 'exact_version_and_authority_audited': False,
              'normative_semantics_understood': False, 'full_standard_qualified': False}
    try:
        if urllib.parse.urlsplit(url).scheme != 'https':
            raise ValueError('Public HTTPS source required')
        url = public_https(url)
        opener = urllib.request.build_opener(PublicRedirect())
        with opener.open(urllib.request.Request(url, headers={'User-Agent': 'USL-reference-inventory/4.11.2'}), timeout=10) as response:
            body = response.read(MAX_BODY + 1)
            if response.status != 200:
                raise ValueError('Complete HTTP200 body required')
            if len(body) > MAX_BODY:
                raise ValueError('Body exceeds 2MiB allowance; use specific chapters')
            final = public_https(response.url)
            content_type = response.headers.get('Content-Type', '')
        # Only content bytes, headers and identities are stored. No evaluation.
        if url in SOURCE_HASHES and hashlib.sha256(body).hexdigest() != SOURCE_HASHES[url]:
            raise ValueError('Upstream package metadata SHA256 mismatch')
        identity = budget.put(body)
        result.update(retrieved=True, final_url=final, HTTP_status=200, sha256=identity,
                      bytes=len(body), content_type=content_type, raw_body_in_private_cache_only=True)
        if not body.strip():
            result['content_review_warning'] = 'Empty body; successful retrieval does not establish useful reference content'
        if url in SOURCE_HASHES:
            result['package_provenance'] = {'metadata_url': 'https://pypi.org/pypi/Myghty/1.1/json',
                'upstream_published_sha256': SOURCE_HASHES[url], 'source_package_archive_not_executed_or_extracted': True}
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)[:350]
        if isinstance(error, urllib.error.HTTPError):
            result['HTTP_status'] = error.code
    result['seconds'] = time.perf_counter() - started
    return result


async def recover(args):
    from semantic_records import SnapshotBudget, resource_admission, read_object
    started = time.perf_counter()
    rows = missing_rows(); table = fallback_table(); check_coverage(rows, table)
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    initial_hashes = {str(path.relative_to(ROOT)): sha(path) for path in (ROOT / 'scope-all-results').iterdir() if path.is_file()}
    disk = shutil.disk_usage(args.private_cache).free
    urls = {url for values in table.values() for url in values}
    admission = resource_admission(len(urls), output)
    slots = admission['thread_slots']
    executor = ThreadPoolExecutor(max_workers=max(1, slots)); semaphore = asyncio.Semaphore(max(1, slots))
    loop = asyncio.get_running_loop(); flights = {}; start = asyncio.Event(); ready = 0; active = 0; peak = 0
    previous = {}
    if args.resume and (output / 'HTTP_ATTEMPTS.json').is_file():
        manifest = json.loads((output / 'MANIFEST.json').read_text())
        if sha(output / 'HTTP_ATTEMPTS.json') != manifest['HTTP_ATTEMPTS.json']['sha256']:
            raise ValueError('Prior HTTP attempt ledger integrity failure')
        previous = json.loads((output / 'HTTP_ATTEMPTS.json').read_text())
    retained_body_sizes = {item['sha256']: item['bytes'] for item in previous.values() if item['retrieved']}
    # Every prior cache addition belongs to this set. Counting pre-existing CAS
    # bodies too gives a conservative, auditable upper bound across resumed runs.
    retained_body_bytes = sum(retained_body_sizes.values())
    cache_limit = max(0, min(MAX_NEW_CACHE - retained_body_bytes, disk - DISK_RESERVE))
    budget = SnapshotBudget(args.private_cache, cache_limit)
    pipeline_sha = sha(__file__)

    async def get_url(url):
        nonlocal active, peak
        if url not in flights:
            async def once():
                nonlocal active, peak
                if url in previous:
                    prior = dict(previous[url])
                    if prior['retrieved']:
                        read_object(args.private_cache, prior['sha256'])
                    prior['fresh_HTTP_this_run'] = False
                    prior['prior_HTTP_observation_retained_without_retry'] = True
                    return prior
                if not slots:
                    return {'url': url, 'retrieved': False, 'error': 'No resources admitted', 'full_standard_qualified': False}
                async with semaphore:
                    active += 1; peak = max(peak, active)
                    try:
                        result = await loop.run_in_executor(executor, fetch, url, budget)
                        result['fresh_HTTP_this_run'] = True
                        return result
                    finally:
                        active -= 1
            flights[url] = asyncio.create_task(once())
        return await flights[url]

    async def actor(row):
        nonlocal ready
        ready += 1
        if ready == len(rows): start.set()
        await start.wait()
        identifier = row['catalog_id']; attempts = []; selected = None
        for url in table[identifier]:
            attempt = await get_url(url); attempts.append(attempt)
            if attempt['retrieved']:
                # A fresh integrity read verifies every selected observation.
                read_object(args.private_cache, attempt['sha256'])
                selected = attempt
                break
        return {'catalog_id': identifier, 'candidate_language_identity': row['candidate'],
                'prior_missing_reference_at_snapshot': True,
                'historical_reference_candidates': row['next_action']['network_reference_candidates'],
                'fallback_candidates': table[identifier], 'attempts': attempts,
                'selected': selected, 'reference_body_recovered': selected is not None,
                'scope_all_record_sha256': digest(row),
                'identity_caveat': CAVEATS.get(identifier),
                'semantic_readiness': {'complete_rule_set': False, 'version_authority_and_applicability_audit_required': True,
                                       'native_host_executed': False, 'full_standard_qualified': False},
                'next_action': 'Inspect retrieved content for exact language/version/category; reject unrelated, navigation-only or incomplete material; extract reviewed clause-to-implementation-to-intent-test obligations'}

    try:
        records = await asyncio.gather(*(actor(row) for row in rows))
    finally:
        executor.shutdown(wait=True)
    records.sort(key=lambda row: row['catalog_id'])
    attempts = {url: task.result() for url, task in flights.items()}
    summary = {'schema': 'usl.reference-recovery.v1', 'passed': True, 'all_initially_missing_ids_retained': len(records),
               'logical_ID_actors_started_together': len(rows), 'fixed_batches_or_actor_cap': False,
               'recovered_ID_reference_bodies': sum(r['reference_body_recovered'] for r in records),
               'IDs_still_without_recovered_body': sum(not r['reference_body_recovered'] for r in records),
               'distinct_HTTP_attempts': len(attempts), 'successful_HTTP_attempts': sum(a['retrieved'] for a in attempts.values()),
               'fresh_HTTP_attempts_this_run': sum(a.get('fresh_HTTP_this_run', True) for a in attempts.values()),
               'prior_HTTP_observations_retained_without_retry': sum(not a.get('fresh_HTTP_this_run', True) for a in attempts.values()),
               'duplicate_exact_URL_requests_avoided': sum(len(r['attempts']) for r in records) - len(attempts),
               'distinct_recovered_body_hashes': len({a['sha256'] for a in attempts.values() if a['retrieved']}),
               'peak_admitted_HTTP_jobs': peak, 'resource_admission': admission,
               'per_body_maximum_bytes': MAX_BODY, 'maximum_new_cache_bytes': MAX_NEW_CACHE,
               'actual_admitted_new_cache_bytes': cache_limit, 'new_cache_bytes_written': budget.written_bytes,
               'retained_body_bytes_upper_bound_before_run': retained_body_bytes,
               'cumulative_new_cache_bytes_upper_bound': retained_body_bytes + budget.written_bytes,
               'disk_reserve_bytes': DISK_RESERVE,
               'initial_scope_outputs_unchanged': all(sha(ROOT / name) == identity for name, identity in initial_hashes.items()),
               'full_rule_sets_completed': 0, 'new_native_qualifications': 0, 'full_standards_qualified': 0,
               'seconds': time.perf_counter() - started,
               'pipeline_sha256': pipeline_sha, 'pipeline_unchanged_during_run': sha(__file__) == pipeline_sha,
               'interpretation': 'Successful retrieval is evidence availability, not audited semantics, useful-content approval, execution or qualification'}
    dump(output / 'RECOVERED_REFERENCES.json', {'source_scope_ledger_sha256': sha(ROOT / 'scope-all-results/ALL_IDS.json'),
                                              'initial_scope_hashes': initial_hashes, 'records': records})
    dump(output / 'HTTP_ATTEMPTS.json', attempts); dump(output / 'SUMMARY.json', summary)
    table_lines = ['# Reference recovery', '', 'Retrieved bodies remain private. Content usefulness, authority, exact release and normative coverage still need review.', '',
                   '| ID | Recovered | Selected URL / final error |', '|---|---|---|']
    for row in records:
        detail = row['selected']['final_url'] if row['selected'] else row['attempts'][-1].get('error', 'not attempted')
        table_lines.append('| ' + row['catalog_id'] + ' | ' + str(row['reference_body_recovered']) + ' | ' + detail.replace('|', '\\|') + ' |')
    (output / 'RECOVERY_TABLE.md').write_text('\n'.join(table_lines) + '\n')
    dump(output / 'MANIFEST.json', {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in output.iterdir() if p.is_file() and p.name != 'MANIFEST.json'})
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=Path('/workspace/usl-v4.10.0-clean-test'))
    parser.add_argument('--private-cache', type=Path, default=PRIVATE_CACHE)
    parser.add_argument('--output', type=Path, default=ROOT / 'reference-recovery-results')
    parser.add_argument('--resume', action='store_true', help='Retain hash-verified prior HTTP observations; attempt only newly authored candidates')
    args = parser.parse_args(); sys.path.insert(0, str(args.source_root))
    print(json.dumps(asyncio.run(recover(args)), sort_keys=True))


if __name__ == '__main__':
    main()
