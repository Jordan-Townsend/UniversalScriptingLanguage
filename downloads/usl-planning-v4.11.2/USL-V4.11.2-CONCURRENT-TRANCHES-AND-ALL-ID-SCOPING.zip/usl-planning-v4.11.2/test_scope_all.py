import asyncio
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

if not any(Path(path, 'usl_systems').is_dir() for path in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')

from scope_all import (ROOT, IDENTITY_CORRECTIONS, apply_receipts, candidate_table,
                       check_complete, digest, file_sha, probe_names, route,
                       verify_document)


class AllScopingTests(unittest.TestCase):
    def baseline(self):
        return apply_receipts(json.loads((ROOT / 'inputs/catalog.json').read_text())['entries'],
                              [ROOT / 'semantic-final/brainfuck/qualification.json'])[0]

    def test_every_remaining_id_has_a_distinct_authored_plan(self):
        candidates = candidate_table()
        missing = check_complete(self.baseline(), candidates)
        self.assertEqual(len(missing), 362)
        self.assertEqual(set(candidates), missing)
        for identifier in missing:
            self.assertGreaterEqual(len(candidates[identifier]['semantic_focus']), 3, identifier)
            self.assertFalse(candidates[identifier]['candidate_is_qualified'])
        self.assertEqual(len({tuple(c['semantic_focus']) for c in candidates.values()}), 362)

    def test_omitted_id_or_candidate_is_rejected(self):
        entries = self.baseline()
        with self.assertRaises(ValueError):
            check_complete(entries[:-1], candidate_table())
        candidates = candidate_table()
        del candidates['forth']
        with self.assertRaises(ValueError):
            check_complete(entries, candidates)

    def test_similarly_named_languages_are_kept_distinct(self):
        candidates = candidate_table()
        required = {'teal': 'Algorand', 'ucode': 'Icon', 'ti': 'ThingsDB', 'tlb': 'TON',
                    'cadl': 'OpenEHR', 'xpp': 'Dynamics', 'bdd': 'Behave', 'gst': 'Gosu',
                    'rd': 'R tools', 'resourcebundle': 'ICU', 'silver': 'Viper', 'mql': 'MetaTrader'}
        for identifier, expected in required.items():
            self.assertIn(expected, candidates[identifier]['upstream_host_candidate'])
            self.assertIn(identifier, IDENTITY_CORRECTIONS)

    def test_document_objects_and_bodies_both_require_integrity(self):
        body = b'published bytes'
        key = hashlib.sha256(body).hexdigest()
        obj = {'body_sha256': key, 'source_url': 'https://example.org/spec'}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, key)
            missing = verify_document(digest(obj), obj, directory)
            self.assertFalse(missing['body_available_and_hash_verified_now'])
            path.write_bytes(body)
            self.assertTrue(verify_document(digest(obj), obj, directory)['body_available_and_hash_verified_now'])
            path.write_bytes(b'corrupted')
            with self.assertRaises(ValueError):
                verify_document(digest(obj), obj, directory)
            with self.assertRaises(ValueError):
                verify_document('0' * 64, obj, directory)

    def test_usl_routes_keep_all_combinations_unqualified(self):
        policy = (ROOT / 'scope_all.usl').read_text()
        for references in [0, 100]:
            for external in [False, True]:
                for prior in [False, True]:
                    decision, receipt = route({'full_gate_passed': False, 'reference_count': references,
                                               'external_dependency': external, 'qualified_scope': prior}, policy)
                    self.assertFalse(decision['full_standard_qualified'])
                    self.assertFalse(decision['planning_record_is_execution_evidence'])
                    self.assertTrue(receipt['actual_USL_execution'])
                    self.assertTrue(receipt['independently_checked'])
        with self.assertRaises(Exception):
            route({'full_gate_passed': True, 'reference_count': 100, 'external_dependency': False,
                   'qualified_scope': True}, policy)

    def test_invalid_receipts_cannot_promote_scopes(self):
        entries = json.loads((ROOT / 'inputs/catalog.json').read_text())['entries']
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, 'receipt.json')
            for receipt in [{'catalog_id': 'forth', 'passed': False, 'scope': 'fake', 'full_standard_qualified': False},
                            {'catalog_id': 'forth', 'passed': True, 'scope': 'fake', 'full_standard_qualified': False},
                            {'catalog_id': 'forth', 'passed': True, 'scope': 'fake', 'full_standard_qualified': True},
                            {'catalog_id': 'missing-id', 'passed': True, 'scope': 'fake', 'full_standard_qualified': False}]:
                path.write_text(json.dumps(receipt))
                with self.assertRaises(ValueError):
                    apply_receipts(entries, [path])

    def test_export_is_complete_hash_linked_and_not_promoted(self):
        output = ROOT / 'scope-all-results'
        ledger = json.loads((output / 'ALL_IDS.json').read_text())
        rows = ledger['records']
        remaining = json.loads((output / 'REMAINING_IDS.json').read_text())
        summary = json.loads((output / 'SUMMARY.json').read_text())
        self.assertEqual(len(rows), 607)
        self.assertEqual(sum(row['original_catalog'] for row in rows), 606)
        self.assertEqual(len(remaining['catalog_ids']), 362)
        self.assertEqual(remaining['all_id_ledger_sha256'], file_sha(output / 'ALL_IDS.json'))
        self.assertEqual(set(remaining['catalog_ids']), {r['catalog_id'] for r in rows if r['remaining_unscoped_at_snapshot']})
        self.assertTrue(all(not row['full_standard_qualified'] and not row['normative_semantic_scope_complete'] for row in rows))
        self.assertEqual(summary['peak_live_logical_actors'], 607)
        self.assertEqual(summary['new_native_qualifications'], 0)
        self.assertEqual(summary['all_original_obligation_dimensions_preserved'], 10908)
        families = json.loads((output / 'FAMILY_SHARED_WORK.json').read_text())
        for identity, family in families.items():
            self.assertEqual(identity, digest({'family': family['family'], 'category': family['category'],
                                              'contracts': family['shareable_work']}))
            self.assertFalse(family['semantic_qualification_transferred_between_ids'])
        self.assertTrue(all(row['family_shared_artifact_key'] in families for row in rows))
        family_ids = [identifier for family in families.values() for identifier in family['catalog_ids']]
        self.assertEqual(sorted(family_ids), sorted(row['catalog_id'] for row in rows))
        for path, observation in json.loads((output / 'MANIFEST.json').read_text()).items():
            self.assertEqual(file_sha(output / path), observation['sha256'], path)
        self.assertEqual(ledger['source_hashes']['pipeline'], file_sha(ROOT / 'scope_all.py'))

    def test_tool_probe_table_does_not_assert_runtime_qualification(self):
        probes = probe_names()
        self.assertIn('goal', probes['teal'])
        self.assertIn('icont', probes['ucode'])
        inventory = json.loads((ROOT / 'scope-all-results/TOOL_INVENTORY.json').read_text())
        self.assertFalse(inventory['execution_or_language_compatibility_claimed'])
        self.assertTrue(all(not item['native_compatibility_qualified'] for item in inventory['tools'].values()))


if __name__ == '__main__':
    unittest.main()
