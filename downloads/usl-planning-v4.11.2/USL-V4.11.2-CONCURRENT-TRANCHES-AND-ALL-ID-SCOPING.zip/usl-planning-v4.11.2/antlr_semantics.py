"""Typed ANTLR 4.9.2 literal-choice grammar -> USL and real native parsers.

Qualified source form: grammar NAME; document: ('word' | 'other') EOF;
Literals are nonempty printable ASCII excluding quote/backslash, at most 64
characters, with at most 64 alternatives. This is a bounded processing profile,
not the ANTLR grammar language, target-language actions, or its full standard.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

from restore_antlr import DEFAULT_PREFIX

DEFAULT_JARS = Path('/workspace/.onboarding/expansion-v411/sysroot/usr/share/java')
JAR_NAMES = ('antlr4-4.9.2.jar', 'antlr4-runtime-4.9.2.jar', 'antlr3-runtime-3.5.3.jar',
             'treelayout.jar', 'stringtemplate4-4.3.3.jar', 'icu4j-60.2.jar', 'javax.json-1.1.2.jar')


class AntlrProfileError(ValueError): pass


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@dataclass(frozen=True)
class LiteralGrammar:
    grammar_name: str
    alternatives: tuple[str, ...]
    schema: str = 'usl.antlr4.literal-choice.IR.v1'


def frontend(source):
    if not isinstance(source, str) or len(source) > 16384:
        raise AntlrProfileError('Source limit is 16384 characters')
    literal = r"'[^'\\\r\n]+'"
    pattern = (r'\s*grammar\s+([A-Z][A-Za-z0-9_]*)\s*;\s*document\s*:\s*\(\s*('
               + literal + r'(?:\s*\|\s*' + literal + r')*)\s*\)\s+EOF\s*;\s*')
    # ANTLR grammar-source whitespace is space/tab/CR/LF, not Python's broader
    # ASCII isspace set (which additionally accepts vertical tab/form feed).
    pattern = pattern.replace(r'\s', r'[ \t\r\n]')
    match = re.fullmatch(pattern, source, re.ASCII)
    if not match: raise AntlrProfileError('Unsupported grammar; explicit literal alternatives and EOF required')
    if len(match[1]) > 64: raise AntlrProfileError('Grammar identifier limit64 characters')
    words = tuple(re.findall(literal, match[2]))
    words = tuple(word[1:-1] for word in words)
    if len(words) > 64 or len(set(words)) != len(words):
        raise AntlrProfileError('At most64 distinct literal alternatives are allowed')
    if any(not 1 <= len(word) <= 64 or any(not 32 <= ord(c) <= 126 for c in word) for word in words):
        raise AntlrProfileError('Literals must contain1..64 printable ASCII characters')
    return LiteralGrammar(match[1], words)


def emit_usl(source):
    ir = frontend(source)
    expression = ' or '.join('text == ' + json.dumps(word) for word in ir.alternatives)
    return 'function accepts(text):\n    return ' + expression + '\nlet result = accepts(antlr_input())\n'


def check_text(text):
    if not isinstance(text, str) or len(text.encode('utf-8')) > 65536:
        raise AntlrProfileError('Input must be valid scalar UTF-8, at most65536 bytes')


class Program:
    def __init__(self, source):
        from usl_systems.language import parse
        self.ir = frontend(source); self.source = source; self.generated = emit_usl(source)
        self.tree = parse(self.generated); self.generated_sha256 = hashlib.sha256(self.generated.encode()).hexdigest()

    def run(self, text, cached_syntax=True):
        from usl_systems.language import Interpreter
        try: check_text(text)
        except UnicodeEncodeError as error: raise AntlrProfileError('Unpaired surrogates are outside scalar UTF-8 profile') from error
        interpreter = Interpreter(capabilities={'antlr_input': lambda: text}, timeout=2, max_ops=10000)
        if cached_syntax:
            interpreter.start = time.monotonic(); interpreter.statements(self.tree.body, interpreter.env)
            value = interpreter.env['result']; operations = interpreter.operations
        else:
            result = interpreter.run(self.generated); value = result.variables['result']; operations = result.operations
        if type(value) is not bool: raise AntlrProfileError('Generated predicate returned a non-Boolean')
        return value, {'actual_USL_execution': True, 'operations': operations,
                       'cached_pure_syntax_only': cached_syntax, 'generated_sha256': self.generated_sha256}

    def prove_predicate(self, independent_words):
        """Encode the actual generated return AST, not a replacement predicate.

        This all-Z3-string proof relates the generated equality/OR expression to
        the supplied intent set. It is not a proof of ANTLR or the interpreter.
        Scalar UTF-8 inputs are a subset of the compared symbolic string domain.
        """
        import z3
        variable = z3.String('input_text')
        def encode(node):
            if isinstance(node, ast.BoolOp) and isinstance(node.op, ast.Or): return z3.Or(*map(encode, node.values))
            if (isinstance(node, ast.Compare) and isinstance(node.left, ast.Name) and node.left.id == 'text'
                    and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq)
                    and isinstance(node.comparators[0], ast.Constant) and isinstance(node.comparators[0].value, str)):
                return variable == z3.StringVal(node.comparators[0].value)
            raise AntlrProfileError('Proof encoder rejects generated AST outside equality/OR profile')
        function = self.tree.body[0]
        if not isinstance(function, ast.FunctionDef) or len(function.body) != 1 or not isinstance(function.body[0], ast.Return):
            raise AntlrProfileError('Unexpected generated function AST')
        implementation = encode(function.body[0].value)
        expected = z3.Or(*[variable == z3.StringVal(word) for word in independent_words])
        solver = z3.Solver(); solver.add(implementation != expected); verdict = solver.check()
        return {'passed': verdict == z3.unsat, 'solver_result': str(verdict), 'solver': 'Z3 ' + z3.get_version_string(),
                'generated_AST_encoded': True, 'generated_sha256': self.generated_sha256,
                'claim': 'Generated equality/OR predicate equals independently supplied finite intent set for all symbolic strings',
                'excludes': ['ANTLR generator/runtime correctness', 'USL interpreter correctness', 'whole-language semantics'],
                'counterexample': str(solver.model()) if verdict == z3.sat else None}


PYTHON_ADAPTER = r'''import json,sys
from antlr4 import InputStream,CommonTokenStream
from antlr4.error.ErrorListener import ErrorListener
from antlr4.error.ErrorStrategy import BailErrorStrategy
from {name}Lexer import {name}Lexer
from {name}Parser import {name}Parser
class Strict(ErrorListener):
    def syntaxError(self,recognizer,offendingSymbol,line,column,msg,e): raise ValueError(msg)
out=[]
for text in json.load(sys.stdin):
    try:
        lexer={name}Lexer(InputStream(text));lexer.removeErrorListeners();lexer.addErrorListener(Strict())
        parser={name}Parser(CommonTokenStream(lexer));parser.removeErrorListeners();parser.addErrorListener(Strict())
        parser._errHandler=BailErrorStrategy();parser.document();out.append(True)
    except Exception: out.append(False)
json.dump(out,sys.stdout)
'''

CPP_ADAPTER = r'''#include "antlr4-runtime.h"
#include "{name}Lexer.h"
#include "{name}Parser.h"
#include <iostream>
#include <sstream>
#include <stdexcept>
class Strict: public antlr4::BaseErrorListener {{
 void syntaxError(antlr4::Recognizer*,antlr4::Token*,size_t,size_t,const std::string &message,std::exception_ptr) override {{throw std::runtime_error(message);}}
}};
int main() {{
 std::string line;Strict listener;
 while(std::getline(std::cin,line)) {{
  std::string text;
  if(line.size()%2) return 2;
  for(size_t i=0;i<line.size();i+=2) {{unsigned int byte;std::istringstream part(line.substr(i,2));part>>std::hex>>byte;if(part.fail())return 3;text.push_back(char(byte));}}
  try {{
   antlr4::ANTLRInputStream input(text);{name}Lexer lexer(&input);
   lexer.removeErrorListeners();lexer.addErrorListener(&listener);
   antlr4::CommonTokenStream tokens(&lexer);{name}Parser parser(&tokens);
   parser.removeErrorListeners();parser.addErrorListener(&listener);
   parser.setErrorHandler(std::make_shared<antlr4::BailErrorStrategy>());
   parser.document();std::cout<<"1\n";
  }}catch(const std::exception&) {{std::cout<<"0\n";}}
 }}
}}
'''


def native_identity(prefix=DEFAULT_PREFIX, jars=DEFAULT_JARS):
    prefix, jars = Path(prefix), Path(jars)
    jar_hashes = {name: sha(jars / name) for name in JAR_NAMES}
    cpp = prefix / 'usr/lib/x86_64-linux-gnu/libantlr4-runtime.so.4.9'
    python_files = prefix / 'python/antlr4'
    py_hashes = {str(path.relative_to(python_files)): sha(path) for path in sorted(python_files.rglob('*.py'))}
    compiler = Path(shutil.which('g++') or '/missing-g++').resolve()
    java = Path(shutil.which('java') or '/missing-java').resolve()
    headers_root = prefix / 'usr/include/antlr4-runtime'
    header_hashes = {str(path.relative_to(headers_root)): sha(path) for path in sorted(headers_root.rglob('*')) if path.is_file()}
    if not header_hashes: raise AntlrProfileError('Missing pinned C++ runtime headers')
    compiler_components = {}
    for name in ['cc1plus', 'collect2', 'as', 'ld']:
        component = subprocess.check_output([str(compiler), '-print-prog-name=' + name], text=True).strip()
        path = Path(component) if Path(component).is_absolute() else Path(shutil.which(component) or '/missing-' + name)
        compiler_components[name] = {'path': str(path.resolve()), 'sha256': sha(path)}
    return {'generator': 'ANTLR4.9.2 Java tool', 'java_jars_sha256': jar_hashes,
            'C++_runtime': 'ANTLR4.9 Debian4.9+dfsg-3+b3', 'C++_runtime_sha256': sha(cpp),
            'C++_runtime_headers_sha256': header_hashes, 'compiler_components': compiler_components,
            'Python_runtime': 'antlr4-python3-runtime4.9.2', 'Python_runtime_source_sha256': py_hashes,
            'compiler': str(compiler), 'compiler_sha256': sha(compiler),
            'java': str(java), 'java_sha256': sha(java), 'Python_host': sys.version,
            'Python_host_sha256': sha(Path(sys.executable).resolve())}


def build_native(source, backend, prefix=DEFAULT_PREFIX, jars=DEFAULT_JARS):
    ir = frontend(source)
    if backend not in {'python', 'cpp'}: raise AntlrProfileError('Unknown native target')
    prefix, jars = Path(prefix), Path(jars); identity = native_identity(prefix, jars)
    adapter = (PYTHON_ADAPTER if backend == 'python' else CPP_ADAPTER).format(name=ir.grammar_name)
    key = hashlib.sha256(json.dumps({'source': source, 'backend': backend, 'adapter': adapter,
                                    'toolchain': identity}, sort_keys=True).encode()).hexdigest()
    artifacts = prefix / 'artifacts'; artifacts.mkdir(parents=True, exist_ok=True)
    directory = artifacts / key
    # Cross-thread/process single-flight admission applies only to creation of
    # pure generated/compiled artifacts. Native evaluation remains outside it.
    with (artifacts / (key + '.lock')).open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        reused, files = materialize_native(directory, key, source, backend, ir, adapter, prefix, jars)
    return directory, {'artifact_sha256': key, 'pure_artifact_reused': reused, 'single_flight_build': True,
                       'artifact_files_sha256': files, 'toolchain': identity,
                       'generator_compile_processes': 0 if reused else (1 if backend == 'python' else 2),
                       'toolchain_identity_query_processes': 4,
                       'native_execution_evidence_reused': False}


def materialize_native(directory, key, source, backend, ir, adapter, prefix, jars):
    manifest = directory / 'artifact-manifest.json'
    reused = False
    if manifest.exists():
        records = json.loads(manifest.read_text())
        required = {ir.grammar_name + '.g4', 'native.py' if backend == 'python' else 'native'}
        reused = (records.get('key') == key and required <= records.get('files', {}).keys()
                  and all(Path(name).name == name and (directory / name).is_file()
                          and sha(directory / name) == value for name, value in records['files'].items()))
    if not reused:
        directory.mkdir(parents=True, exist_ok=True)
        grammar = directory / (ir.grammar_name + '.g4'); grammar.write_text(source)
        target = 'Python3' if backend == 'python' else 'Cpp'
        command = ['java', '-Dfile.encoding=UTF-8', '-cp', os.pathsep.join(str(jars / name) for name in JAR_NAMES),
                   'org.antlr.v4.Tool', '-Dlanguage=' + target, '-no-listener', '-no-visitor', grammar.name]
        result = subprocess.run(command, cwd=directory, capture_output=True, text=True, timeout=40)
        if result.returncode: raise AntlrProfileError('ANTLR native generation failed: ' + result.stderr[:1000])
        adapter_file = directory / ('native.py' if backend == 'python' else 'native.cpp'); adapter_file.write_text(adapter)
        if backend == 'cpp':
            command = ['g++', '-std=c++17', '-O1', '-I' + str(prefix / 'usr/include/antlr4-runtime'),
                       ir.grammar_name + 'Lexer.cpp', ir.grammar_name + 'Parser.cpp', 'native.cpp',
                       '-L' + str(prefix / 'usr/lib/x86_64-linux-gnu'), '-lantlr4-runtime',
                       '-Wl,-rpath,' + str(prefix / 'usr/lib/x86_64-linux-gnu'), '-o', 'native']
            result = subprocess.run(command, cwd=directory, capture_output=True, text=True, timeout=90)
            if result.returncode: raise AntlrProfileError('C++ generated parser compile failed: ' + result.stderr[:2000])
        files = {path.name: sha(path) for path in sorted(directory.iterdir()) if path.is_file() and path.name != manifest.name}
        manifest.write_text(json.dumps({'key': key, 'files': files}, sort_keys=True, indent=2) + '\n')
    return reused, json.loads(manifest.read_text())['files']


def native_batch(source, texts, backend, prefix=DEFAULT_PREFIX, jars=DEFAULT_JARS):
    for text in texts: check_text(text)
    directory, artifact = build_native(source, backend, prefix, jars)
    env = dict(os.environ)
    env['PYTHONPATH'] = str(Path(prefix) / 'python') + os.pathsep + str(directory) + os.pathsep + env.get('PYTHONPATH', '')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    if backend == 'python': command = [sys.executable, str(directory / 'native.py')]; data = json.dumps(texts).encode()
    else: command = [str(directory / 'native')]; data = ''.join(text.encode().hex() + '\n' for text in texts).encode()
    result = subprocess.run(command, input=data, capture_output=True, timeout=25, env=env)
    if result.returncode: raise AntlrProfileError('Native parser host failed: ' + result.stderr.decode(errors='replace')[:1000])
    if backend == 'python': values = json.loads(result.stdout)
    else:
        lines = result.stdout.decode('ascii').splitlines()
        if any(line not in {'0', '1'} for line in lines): raise AntlrProfileError('Unexpected C++ protocol output')
        values = [line == '1' for line in lines]
    if len(values) != len(texts) or any(type(v) is not bool for v in values): raise AntlrProfileError('Native output count/type mismatch')
    return values, dict(artifact, native_backend=backend, native_processes=1, fresh_native_evaluations=len(values),
                        each_case_fresh_lexer_parser=True, stderr=result.stderr.decode(errors='replace'))
