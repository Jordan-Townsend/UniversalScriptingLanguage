"""Run regressions, concurrent native tranches, and the joined all-ID scoping pass."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent


def run(source_root,output):
    source_root=Path(source_root).resolve();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter();env=dict(os.environ)
    env['PYTHONPATH']=str(source_root)+os.pathsep+env.get('PYTHONPATH','')
    env['PYTHONDONTWRITEBYTECODE']='1'
    source_files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.py','.usl'} and '__pycache__' not in p.parts}
    def command(name,arguments):
        target=output/(name+'.log')
        with target.open('w') as log:
            result=subprocess.run([sys.executable]+arguments,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
        if result.returncode:raise RuntimeError(name+' failed; inspect '+str(target))
        return {'passed':True,'log_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    regression=command('unit-tests',['-m','unittest','discover'])
    count=re.search(r'Ran ([0-9]+) tests?',(output/'unit-tests.log').read_text())
    if not count or int(count[1])<1:raise ValueError('No completed regression tests observed')
    regression['tests_run']=int(count[1])
    # These are all currently implemented independent native tranches, released
    # together. Each tranche admits its own jobs using the measured resources.
    tranches={name:[script,'--source-root',str(source_root),'--output',str(output/name)] for name,script in [('forth','qualify_forth.py'),('antlr','qualify_antlr.py')]}
    with ThreadPoolExecutor(max_workers=len(tranches)) as pool:
        futures={name:pool.submit(command,name,args) for name,args in tranches.items()}
        native={name:future.result() for name,future in futures.items()}
    for name in tranches:
        data=json.loads((output/name/'qualification.json').read_text())
        if data['passed'] is not True or data['full_standard_qualified'] is not False:raise ValueError('Native tranche gate failed')
        native[name].update(qualification_sha256=hashlib.sha256((output/name/'qualification.json').read_bytes()).hexdigest(),
                           fresh_native_cases=data.get('fresh_native_processing_cases',data.get('native_evaluations')))
    scope=command('all-ID-scoping',['scope_all.py','--source-root',str(source_root),'--output',str(output/'scope'),
        '--scoped-receipt',str(ROOT/'semantic-final/brainfuck/qualification.json'),
        '--scoped-receipt',str(output/'forth/qualification.json'),'--scoped-receipt',str(output/'antlr/qualification.json')])
    scoped=json.loads((output/'scope/SUMMARY.json').read_text())
    if (scoped['all_ids'],scoped['existing_qualified_original_scopes'],scoped['remaining_original_ids_with_distinct_plans'])!=(607,247,359):raise ValueError('Joined all-ID scoping counts changed')
    if any(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=identity for name,identity in source_files.items()):raise ValueError('Source changed during qualification')
    report={'passed':True,'unit_regressions':regression,'independent_native_tranches_run_concurrently':list(tranches),
            'native_tranches':native,'joined_scoping':scope,'all_ID_actors':607,'validated_profiles':247,
            'remaining_without_validated_profile':359,'full_standards_qualified':0,'native_execution_evidence_replayed':False,
            'source_unchanged_during_verification':True,'source_sha256':source_files,'seconds':time.perf_counter()-started}
    (output/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}));return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('/tmp/usl-v4112-verification'))
    a=p.parse_args();run(a.source_root,a.output)
