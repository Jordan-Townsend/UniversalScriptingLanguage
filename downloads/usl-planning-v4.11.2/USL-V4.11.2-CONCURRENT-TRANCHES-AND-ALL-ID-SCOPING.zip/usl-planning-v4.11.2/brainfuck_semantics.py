"""A real, bounded Brainfuck-to-USL frontend with independent native checks.

Profile: eight commands, unsigned byte cells, 30000 cells indexed 0..29999,
initially zero, configurable EOF zero/eof/same, non-command text ignored.
Pointer escape and resource exhaustion are outside the qualified profile.
"""
from __future__ import annotations

import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
COMMANDS = frozenset('><+-.,[]')


class ProfileError(ValueError):
    pass


@lru_cache(maxsize=None)
def lower(source):
    """Pure immutable IR; validate bracket grammar before native execution."""
    if not isinstance(source, str) or len(source) > 100000:
        raise ProfileError('Expected source text of at most 100000 characters')
    if '!' in source:
        raise ProfileError('Inline !/shebang extensions are outside this profile')
    nodes, stack = [], []
    current = nodes
    for offset, command in enumerate(source):
        if command not in COMMANDS:
            continue
        if command == '[':
            if len(stack) >= 40:
                raise ProfileError('Loop nesting exceeds the declared 40-level profile')
            body = []
            current.append(('loop', body, offset))
            stack.append(current)
            current = body
        elif command == ']':
            if not stack:
                raise ProfileError(f'Unmatched ] at source offset {offset}')
            current = stack.pop()
        else:
            current.append((command, None, offset))
    if stack:
        raise ProfileError('Unmatched [')

    def freeze(items):
        return tuple((op, freeze(body) if body is not None else None, offset) for op, body, offset in items)
    return freeze(nodes)


def emit_usl(source):
    lines = ['// Generated from validated Brainfuck IR; explicit bounded memory and I/O capabilities.', 'let pointer = 0']

    def emit(items, depth):
        indent = '    ' * depth
        for operation, body, offset in items:
            lines.append(indent + f'// source offset {offset}')
            lines.append(indent + 'budget_tick()')
            if operation == 'loop':
                lines.append(indent + 'while read_cell(pointer) != 0:')
                lines.append(indent + '    budget_tick()')
                emit(body, depth + 1)
            elif operation in '><':
                sign = '+' if operation == '>' else '-'
                lines.append(indent + f'pointer = pointer {sign} 1')
                lines.append(indent + 'check_pointer(pointer)')
            elif operation in '+-':
                lines.append(indent + f'write_cell(pointer, (read_cell(pointer) {operation} 1) % 256)')
            elif operation == ',':
                lines.append(indent + 'write_cell(pointer, read_input(read_cell(pointer)))')
            elif operation == '.':
                lines.append(indent + 'emit_byte(read_cell(pointer))')
    emit(lower(source), 0)
    return '\n'.join(lines) + '\n'


def run_generated(source, data=b'', eof='same', max_ops=200000):
    from usl_systems.language import Interpreter
    if not isinstance(data, bytes) or len(data) > 100000:
        raise ProfileError('Input must be at most 100000 raw bytes')
    if eof not in {'zero', 'eof', 'same'}:
        raise ProfileError('Unknown EOF mode')
    if eof != 'same' and b'\xff' in data:
        raise ProfileError('FF input with EOF-zero/255 has no qualified independent native host')
    tape = bytearray(30000)
    output = bytearray()
    consumed = 0
    ticks = 0

    def check(pointer):
        if type(pointer) is not int or not 0 <= pointer < len(tape):
            raise ProfileError('Pointer outside qualified 30000-cell tape')

    def read(pointer):
        check(pointer)
        return tape[pointer]

    def write(pointer, value):
        check(pointer)
        if not 0 <= value <= 255:
            raise ProfileError('Non-byte output from generated code')
        tape[pointer] = value

    def input_byte(previous):
        nonlocal consumed
        if consumed < len(data):
            value = data[consumed]
            consumed += 1
            return value
        return {'zero': 0, 'eof': 255, 'same': previous}[eof]

    def emit(value):
        if len(output) >= 100000:
            raise ProfileError('Output budget exceeded')
        output.append(value)

    def tick():
        nonlocal ticks
        ticks += 1
        if ticks > max_ops:
            raise ProfileError('Execution budget exceeded; termination is unknown')

    generated = emit_usl(source)
    result = Interpreter(capabilities={'check_pointer': check, 'read_cell': read, 'write_cell': write,
                         'read_input': input_byte, 'emit_byte': emit, 'budget_tick': tick},
                         max_ops=max_ops * 40 + 1000, timeout=3).run(generated)
    return bytes(output), {'actual_USL_execution': True, 'USL_operations': result.operations,
                          'generated_source_sha256': hashlib.sha256(generated.encode()).hexdigest(),
                          'input_bytes_consumed': consumed}


def reference_machine(source, data=b'', eof='same', step_limit=200000):
    """Separate flat-PC model, not the frontend AST or generated USL executor."""
    code = ''.join(c for c in source if c in '><+-.,[]')
    jumps, opening = {}, []
    for index, op in enumerate(code):
        if op == '[':
            opening.append(index)
        if op == ']':
            if not opening:
                raise ProfileError('Unmatched close bracket')
            first = opening.pop()
            jumps[first], jumps[index] = index, first
    if opening:
        raise ProfileError('Unmatched open bracket')
    memory, pointer, pc, position, steps, output = {}, 0, 0, 0, 0, []
    while pc < len(code):
        steps += 1
        if steps > step_limit:
            raise ProfileError('Reference step budget exceeded')
        op = code[pc]
        value = memory.get(pointer, 0)
        if op == '>': pointer += 1
        elif op == '<': pointer -= 1
        elif op == '+': memory[pointer] = (value + 1) & 255
        elif op == '-': memory[pointer] = (value - 1) & 255
        elif op == '.': output.append(value)
        elif op == ',':
            if position < len(data):
                memory[pointer] = data[position];position += 1
            else:
                memory[pointer] = {'zero': 0, 'eof': 255, 'same': value}[eof]
        elif op == '[' and value == 0: pc = jumps[pc]
        elif op == ']' and value != 0: pc = jumps[pc]
        if pointer < 0 or pointer >= 30000:
            raise ProfileError('Reference pointer outside qualified profile')
        pc += 1
    return bytes(output)


def native_beef(source, data, eof):
    # The console g_print path escapes invalid UTF-8. Explicit binary files
    # exercise Beef's raw byte I/O. 0xFF input remains a retained host bug.
    with tempfile.TemporaryDirectory(prefix='usl-beef-') as temporary:
        root = Path(temporary);input_path = root / 'input.bin';output_path = root / 'output.bin'
        input_path.write_bytes(data)
        result = subprocess.run(['beef', '-s', eof, '-p', source, '-i', str(input_path), '-o', str(output_path)], capture_output=True, timeout=3)
        if result.returncode != 0:
            raise ProfileError('Native Beef rejected case: ' + result.stderr.decode(errors='replace')[:300])
        return output_path.read_bytes(), result.stderr


@lru_cache(maxsize=None)
def ebfc_compiled(source, compiler, directory):
    key = hashlib.sha256(source.encode()).hexdigest()
    root = Path(directory);root.mkdir(parents=True, exist_ok=True)
    program = root / (key + '.b');executable = root / key
    program.write_text(source)
    result = subprocess.run([compiler, '-o', str(executable), str(program)], capture_output=True, timeout=10)
    if result.returncode != 0:
        raise ProfileError('Native ebfc compile failure: ' + result.stderr.decode(errors='replace')[:300])
    return executable


def native_ebfc(source, data, compiler, directory):
    executable = ebfc_compiled(source, compiler, str(directory))
    result = subprocess.run([str(executable)], input=data, capture_output=True, timeout=3)
    if result.returncode != 0:
        raise ProfileError('Native ebfc program failed')
    return result.stdout, result.stderr


def intent_cases():
    # Expected bytes are independently authored contracts, not derived by translation.
    for byte in range(256):
        yield {'name': f'byte-increment-{byte}', 'source': ',+.', 'input': bytes([byte]), 'eof': 'same', 'expected': bytes([(byte + 1) % 256]), 'contract': 'all byte inputs increment modulo 256'}
    for a in range(9):
        for b in range(9):
            yield {'name': f'add-{a}-{b}', 'source': ',>,<[->+<]>.', 'input': bytes([a, b]), 'eof': 'same', 'expected': bytes([a + b]), 'contract': 'two byte inputs sum modulo 256'}
            yield {'name': f'multiply-{a}-{b}', 'source': ',>,<[>[->+>+<<]>>[-<<+>>]<<<-]>>.', 'input': bytes([a, b]), 'eof': 'same', 'expected': bytes([a * b]), 'contract': 'two bounded inputs multiply'}
    for mode, expected in [('zero', 0), ('eof', 255), ('same', 1)]:
        yield {'name': 'EOF-' + mode, 'source': '+,.', 'input': b'', 'eof': mode, 'expected': bytes([expected]), 'contract': 'explicit EOF mode after cell set to one'}
    for name, source, expected in [('wrap-decrement', '-.', b'\xff'), ('zero-skip', '[+,.].', b'\0'), ('clear', '+++[-].', b'\0'),
                                   ('comments', 'ignore this text + .', b'\x01'),
                                   ('hello', '++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.', b'Hello World!\n')]:
        yield {'name': name, 'source': source, 'input': b'', 'eof': 'zero', 'expected': expected, 'contract': 'independent fixed output'}


def qualify(output, compiler=None):
    output = Path(output);output.mkdir(parents=True, exist_ok=True)
    executable = shutil.which('beef')
    if not executable:
        raise ProfileError('Install the public Beef 1.2 interpreter before qualification')
    compiler = compiler or shutil.which('ebfc') or '/workspace/.onboarding/providers/ebfc-ad2dff5/ebfc'
    if not Path(compiler).is_file():
        raise ProfileError('Run restore_ebfc.py and supply its native compiler')
    source_identity = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    compiler_identity = hashlib.sha256(Path(compiler).read_bytes()).hexdigest()
    started = time.perf_counter();records = []
    for case in intent_cases():
        emitted, receipt = run_generated(case['source'], case['input'], case['eof'])
        model = reference_machine(case['source'], case['input'], case['eof'])
        observations = []
        # ebfc preserves a cell on EOF; the explicit EOF-zero/255 cases use
        # Beef. No native claim combines Beef's unsupported FF input with EOF.
        if case['name'] not in {'EOF-zero', 'EOF-eof'}:
            actual, stderr = native_ebfc(case['source'], case['input'], compiler, output / 'native-artifacts')
            observations.append({'runtime': 'ebfc-2.0', 'output_hex': actual.hex(), 'stderr_hex': stderr.hex()})
        if b'\xff' not in case['input']:
            actual, stderr = native_beef(case['source'], case['input'], case['eof'])
            observations.append({'runtime': 'beef-1.2.0-binary-file-IO', 'output_hex': actual.hex(), 'stderr_hex': stderr.hex()})
        passed = emitted == model == case['expected'] and bool(observations) and all(r['output_hex'] == case['expected'].hex() for r in observations)
        record = {**{k: v for k, v in case.items() if k not in {'input', 'expected'}}, 'input_hex': case['input'].hex(),
                  'expected_hex': case['expected'].hex(), 'native_observations': observations,
                  'generated_USL_output_hex': emitted.hex(), 'reference_output_hex': model.hex(), 'USL_receipt': receipt, 'passed': passed}
        records.append(record)
        if not passed:
            (output / 'counterexample.json').write_text(json.dumps(record, indent=2) + '\n')
            raise ProfileError('Semantic counterexample: ' + case['name'])
    examples = output / 'generated';examples.mkdir(exist_ok=True)
    for case in intent_cases():
        if case['name'] in {'multiply-8-8', 'hello', 'EOF-same'}:
            (examples / (case['name'] + '.usl')).write_text(emit_usl(case['source']))
    native_path = Path('/workspace/.onboarding/sysroot/usr/bin/beef')
    identity = {'invocation_executable': executable, 'invocation_sha256': hashlib.sha256(Path(executable).read_bytes()).hexdigest()}
    if native_path.is_file():
        identity['native_binary_sha256'] = hashlib.sha256(native_path.read_bytes()).hexdigest()
    if source_identity != hashlib.sha256(Path(__file__).read_bytes()).hexdigest() or compiler_identity != hashlib.sha256(Path(compiler).read_bytes()).hexdigest():
        raise ProfileError('Frontend or native compiler changed during validation')
    identity['ebfc_binary_sha256'] = compiler_identity
    identity['ebfc_upstream_commit'] = 'ad2dff5e18a16668fe730ef317e67432404889d0'
    report = {'schema': 'usl.brainfuck.scoped-semantic-validation.v1', 'passed': True, 'catalog_id': 'brainfuck',
              'scope': '8 commands; uint8 wrapping cells; 30000-cell nonnegative tape; EOF same for full-byte inputs via ebfc; three EOF modes via Beef for input bytes 0..254; 40 nesting levels; bounded resources; debugger, inline ! input and shebang extensions excluded',
              'fresh_native_executions': sum(len(r['native_observations']) for r in records), 'fresh_generated_USL_executions': len(records), 'independent_intent_cases': len(records),
              'all_256_byte_inputs_increment_contract_exhausted': True, 'arbitrary_program_equivalence_proved': False,
              'full_standard_qualified': False, 'outstanding': ['independent external review', 'native library full provenance qualification', 'unbounded tape/termination and other dialects outside scope', 'EOF-zero/255 after input containing FF lacks a qualified independent native host', 'all-ID conformance ledger promotion'],
              'source_sha256': source_identity, 'source_unchanged_during_run': True, 'native_identity': identity,
              'native_observation_cache_used': False, 'seconds': time.perf_counter() - started, 'records': records}
    (output / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'records'}))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('brainfuck-results'))
    parser.add_argument('--ebfc', type=Path)
    parser.add_argument('--program', type=Path, help='Translate and execute this Brainfuck source instead of qualifying fixtures')
    parser.add_argument('--input', type=Path, help='Raw input bytes for --program')
    parser.add_argument('--eof', choices=['same', 'zero', 'eof'], default='same')
    parser.add_argument('--emit-usl', type=Path)
    parser.add_argument('--run-output', type=Path)
    args = parser.parse_args();sys.path.insert(0, str(args.source_root.resolve()))
    if args.program:
        source = args.program.read_text()
        generated = emit_usl(source)
        if args.emit_usl:
            args.emit_usl.write_text(generated)
        result, receipt = run_generated(source, args.input.read_bytes() if args.input else b'', args.eof)
        if args.run_output:
            args.run_output.write_bytes(result)
        else:
            sys.stdout.buffer.write(result)
    else:
        qualify(args.output, str(args.ebfc) if args.ebfc else None)
