"""Bind the selected stack rules to the hash-pinned Gforth implementation source.

This records implementation-rule correspondence, not an audited Forth standard.
It exports locators and our rule descriptions, not third-party source bodies.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from forth_semantics import BINARY, UNARY, SPECIAL, WORDS, DEFAULT_PREFIX

ROOT=Path(__file__).resolve().parent


def audit(prefix):
    prefix=Path(prefix);metadata=json.loads((ROOT/'inputs/forth-debian.json').read_text())
    package=next(r for r in metadata['packages'] if r['Package']=='gforth-common')
    archive=prefix/'archives'/Path(package['Filename']).name
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=package['SHA256']:raise ValueError('Native implementation source archive changed')
    names=['prim','kernel/basics.fs','kernel/vars.fs','kernel/cond.fs']
    paths={name:'usr/share/gforth/0.7.3/'+name for name in names}
    # Check installed reference sources against the exact authenticated package.
    raw=subprocess.check_output(['dpkg-deb','--fsys-tarfile',str(archive)])
    sources={}
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tar:
        for name,path in paths.items():
            body=(prefix/path).read_bytes();packed=tar.extractfile('./'+path).read()
            if body!=packed:raise ValueError('Installed source differs from pinned archive: '+path)
            sources[name]={'sha256':hashlib.sha256(body).hexdigest(),'lines':body.decode().splitlines(),'package_path':path}
    def locator(name,pattern):
        source=sources[name]
        for i,line in enumerate(source['lines'],1):
            if re.search(pattern,line,re.IGNORECASE):return {'package_path':source['package_path'],'source_sha256':source['sha256'],'line':i}
        raise ValueError('Missing source clause: '+name+' '+pattern)
    def primitive(word):return locator('prim',r'^'+re.escape(word)+r'\s+\(')
    special={
        'dup':'(a -- a a)','drop':'(a -- )','swap':'(a b -- b a)','over':'(a b -- a b a)',
        'rot':'(a b c -- b c a)','-rot':'(a b c -- c a b)','nip':'(a b -- b)','tuck':'(a b -- b a b)',
        '2dup':'(a b -- a b a b)','2drop':'(a b -- )','2swap':'(a b c d -- c d a b)',
        'depth':'(... -- ... stack-depth-before-operation)','/mod':'(b a -- b % a floor(b/a))',
        'and':'(b a -- signed64(uint64(b) bit-and uint64(a)))',
        'or':'(b a -- signed64(uint64(b) bit-or uint64(a)))',
        'xor':'(b a -- signed64(uint64(b) bit-xor uint64(a)))',
        'lshift':'(b a -- signed64(uint64(b) * 2**a))','rshift':'(b a -- signed64(floor(uint64(b)/2**a)))',
        'true':'( -- -1)','false':'( -- 0)'}
    rules=[]
    comparison={'=','<>','<','>','<=','>=','0=','0<>','0<','0>'}
    for word in WORDS:
        if word in comparison:
            base=word[1:] if word.startswith('0') else word
            refs=[locator('prim',r'^\$1'+re.escape(base)+r'\s+\('),locator('prim',r'^comparisons\('+('0,' if word.startswith('0') else ','))]
        elif word in {'true','false'}:refs=[locator('kernel/vars.fs',r'constant\s+'+word+r'\b')]
        elif word=='depth':refs=[locator('kernel/basics.fs',r'^:\s+depth\s')]
        else:refs=[primitive(word)]
        rule=('(b a -- signed64('+BINARY[word]+'))' if word in BINARY else
              '(a -- signed64('+UNARY[word]+'))' if word in UNARY else special[word])
        domain=['Entire program stays within declared live-stack, call, control and execution budgets']
        if word in {'/','mod','/mod'}:domain+=['a != 0','not (b == -2**63 and a == -1)','Native division environment is observed floored']
        if word in {'lshift','rshift'}:domain+=['0 <= a < 64']
        rules.append({'word':word,'operational_rule':rule,'preconditions':domain,'implementation_source_locators':refs,
                      'independent_case_group':'word-'+word,'full_standard_rule_qualified':False})
    controls={word:locator('kernel/cond.fs',r'^:\s+'+word+r'\s') for word in ['if','else','then','begin','until','while','repeat']}
    return {'schema':'usl.forth.selected-implementation-rule-inventory.v1','catalog_id':'forth',
            'runtime':'Gforth0.7.3 Debianamd64 signed64/floored profile','selected_primitive_rules':len(rules),
            'scope_complete_for_all_Forth':False,'normative_standard_audit_complete':False,
            'source_archive_sha256':package['SHA256'],'source_package':package['Package'],'rules':rules,
            'control_implementation_locators':controls,
            'frontend_rules':['ASCII source only, exact space/tab/CR/LF/VT/FF word separators','decimal signed64 literals','case-insensitive ASCII words','parenthesized comments terminate at first right parenthesis','backslash comments terminate at first CR or LF','only colon definitions at top level; prior definitions callable; entry usl-main required','no control/primitive redefinition, recursion or forward calls','unknown words and unsupported syntax reject'],
            'representation':'Stack cells serialize as signed64; bit operations operate on uint64 bit patterns; signed64(z) reduces modulo2**64 into [-2**63,2**63-1]',
            'remaining':['all other standard words, libraries and environment dependencies','complete dialect/version normative audit','universal implementation proof and external qualification decision']}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prefix',type=Path,default=DEFAULT_PREFIX);p.add_argument('--output',type=Path,default=Path('forth-results/rule-inventory.json'))
    a=p.parse_args();result=audit(a.prefix);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':True,'selected_rule_count':len(result['rules']),'control_locators':len(result['control_implementation_locators']),'all_Forth_complete':False}))
