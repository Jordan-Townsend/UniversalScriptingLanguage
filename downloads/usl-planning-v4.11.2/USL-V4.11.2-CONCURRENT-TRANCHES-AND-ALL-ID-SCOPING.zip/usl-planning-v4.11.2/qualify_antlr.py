"""Run all scoped ANTLR Python/C++ native and USL intent cases concurrently.

Every case is a logical actor. Native program jobs are admitted using observed
memory/FD capacity and fresh parsers are constructed per case. Only pure build
artifacts and parsed USL syntax may be reused; observations are freshly made.
"""
from __future__ import annotations
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time
import urllib.request

from antlr_semantics import DEFAULT_JARS, DEFAULT_PREFIX, Program, native_batch, sha
from semantic_records import resource_admission

ROOT = Path(__file__).resolve().parent
GRAMMARS = [
    {'id': 'two_words', 'source': "grammar UslWords; document: ('ab' | 'ba') EOF;", 'intent_words': ['ab', 'ba']},
    {'id': 'prefix_and_punctuation',
     'source': "grammar UslChoice; document: ('a' | 'ab' | 'b b' | '[]' | 'x;y' | '{z}') EOF;",
     'intent_words': ['a', 'ab', 'b b', '[]', 'x;y', '{z}']},
]
REFERENCES = [
    'https://raw.githubusercontent.com/antlr/antlr4/4.9.2/doc/grammars.md',
    'https://raw.githubusercontent.com/antlr/antlr4/4.9.2/doc/parser-rules.md',
    'https://raw.githubusercontent.com/antlr/antlr4/4.9.2/doc/lexer-rules.md',
    'https://raw.githubusercontent.com/antlr/antlr4/4.9.2/doc/targets.md',
]


def cases_for(grammar):
    # Independently declared contract: exact whole-input membership, with no
    # whitespace skip rule, error recovery, prefix acceptance or ignored bytes.
    words = frozenset(grammar['intent_words'])
    inputs = {''.join(chars) for length in range(6) for chars in itertools.product('abx ', repeat=length)}
    inputs.update(words)
    for word in words:
        inputs.update([word + '\n', '\n' + word, word + '\r\n', word + '\t', '\t' + word,
                       word + '\0', '\0' + word, word + 'x', 'x' + word, word + word,
                       word + '\u00e9', '\U0001f600' + word, word[:-1]])
    inputs.update(['\u00e9', '\U0001f600', '\u2028', '\u200b', '\ufffd', '\0', '\r', '\t', '\n', 'a' * 65536])
    return [{'input_text': text, 'independent_expected': text in words} for text in sorted(inputs)]


def reference_records():
    records = []
    for url in REFERENCES:
        try:
            with urllib.request.urlopen(url, timeout=20) as response:
                body = response.read(1024 * 1024)
                records.append({'url': url, 'final_url': response.url, 'retrieved': True,
                                'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body),
                                'authority': 'Upstream ANTLR repository, tag4.9.2',
                                'full_normative_audit_complete': False})
        except Exception as error:
            records.append({'url': url, 'retrieved': False, 'error': str(error),
                            'full_normative_audit_complete': False})
    return records


async def execute(output, prefix=DEFAULT_PREFIX, jars=DEFAULT_JARS):
    started = time.monotonic(); output = Path(output); output.mkdir(parents=True, exist_ok=True)
    programs = {grammar['id']: Program(grammar['source']) for grammar in GRAMMARS}
    proofs = {grammar['id']: programs[grammar['id']].prove_predicate(grammar['intent_words']) for grammar in GRAMMARS}
    if not all(proof['passed'] for proof in proofs.values()): raise AssertionError('Independent intent proof failed')
    case_groups = {grammar['id']: cases_for(grammar) for grammar in GRAMMARS}
    for grammar in GRAMMARS:
        (output / (grammar['id'] + '.g4')).write_text(grammar['source'])
        (output / (grammar['id'] + '.usl')).write_text(programs[grammar['id']].generated)
    jobs = [(backend, grammar) for backend in ('python', 'cpp') for grammar in GRAMMARS]
    admission = resource_admission(len(jobs), output)
    # ANTLR Java generation/C++ compilation needs more than a small HTTP fetch.
    per_job = 256 * 1024**2
    slots = min(len(jobs), admission['memory_budget_bytes'] // per_job, admission['file_descriptor_slots'])
    if slots < 1: raise RuntimeError('No memory/FD-admitted native job slot available')
    admission.update(native_jobs=len(jobs), thread_slots=slots, per_native_job_reservation_bytes=per_job)
    executor = ThreadPoolExecutor(max_workers=slots); loop = asyncio.get_running_loop()
    start = asyncio.Event(); started_actors = 0; active = 0; peak = 0
    native_results = {}; native_metadata = {}; fresh_syntax_crosschecks = []

    async def native_job(backend, grammar):
        await start.wait()
        texts = [item['input_text'] for item in case_groups[grammar['id']]]
        values, metadata = await loop.run_in_executor(executor, native_batch, grammar['source'], texts, backend, prefix, jars)
        key = backend + ':' + grammar['id']; native_results[key] = values; native_metadata[key] = metadata
        return values

    futures = {(backend, grammar['id']): asyncio.create_task(native_job(backend, grammar)) for backend, grammar in jobs}

    async def case_actor(backend, grammar, index, case):
        nonlocal started_actors, active, peak
        started_actors += 1; active += 1; peak = max(peak, active)
        try:
            await start.wait()
            values = await futures[backend, grammar['id']]
            generated, receipt = programs[grammar['id']].run(case['input_text'])
            native = values[index]; expected = case['independent_expected']
            return {'case_id': backend + ':' + grammar['id'] + ':' + str(index), 'backend': backend,
                    'grammar_id': grammar['id'], **case, 'native_observed': native,
                    'generated_USL_observed': generated, 'USL_execution_receipt': receipt,
                    'passed': native == expected and generated == expected}
        finally: active -= 1

    tasks = [asyncio.create_task(case_actor(backend, grammar, index, case))
             for backend, grammar in jobs for index, case in enumerate(case_groups[grammar['id']])]
    await asyncio.sleep(0)
    all_actors_started_before_release = started_actors == len(tasks)
    start.set()
    try: records = await asyncio.gather(*tasks)
    finally: executor.shutdown(wait=True)
    for grammar in GRAMMARS:
        for text in grammar['intent_words'] + ['not-a-word']:
            value, receipt = programs[grammar['id']].run(text, cached_syntax=False)
            fresh_syntax_crosschecks.append({'grammar_id': grammar['id'], 'input_text': text,
                                             'independent_expected': text in frozenset(grammar['intent_words']),
                                             'observed': value, 'receipt': receipt})
    passed = all(record['passed'] for record in records) and all(
        item['observed'] == item['independent_expected'] for item in fresh_syntax_crosschecks)
    profile_records = []
    for backend, catalog_id in [('python', 'antlr-python'), ('cpp', 'antlr-cpp')]:
        relevant = [record for record in records if record['backend'] == backend]
        profile_records.append({'catalog_id': catalog_id, 'category': 'processing', 'passed': all(r['passed'] for r in relevant),
                                'profile': 'ANTLR4.9.2 literal-choice grammar with explicit EOF -> ' + backend + ' parser and USL Boolean predicate',
                                'native_evaluations': len(relevant), 'generated_USL_executions': len(relevant),
                                'full_standard_qualified': False, 'complete_language_rule_set': False,
                                'native_hosts': [backend + ':' + grammar['id'] for grammar in GRAMMARS]})
    file_names = [grammar['id'] + extension for grammar in GRAMMARS for extension in ('.g4', '.usl')]
    scope = {
        'source_version': 'ANTLR4.9.2', 'category': 'grammar processing',
        'implemented_rules': ['combined grammar declaration with ASCII identifier', 'one parser rule named document',
                              'parenthesized distinct nonempty literal alternatives', 'whole input through explicit EOF',
                              'implicit exact-case literal tokens with longest native lexer match',
                              'no whitespace skipping: spaces/newlines/extra bytes must match literals exactly',
                              'any native lexer/parser error rejects input; recovery is disabled',
                              'fresh lexer/parser and fresh USL execution state for every input'],
        'limits': {'source_characters': 16384, 'grammar_identifier_characters': 64, 'alternatives': 64, 'literal_characters': 64,
                   'input_UTF8_bytes': 65536, 'literal_alphabet': 'printable ASCII except single quote and backslash',
                   'input_alphabet': 'Unicode scalar UTF-8'},
        'excluded': ['escaped literals', 'empty alternatives', 'named lexer rules', 'actions', 'predicates', 'imports',
                     'lexer modes', 'channels', 'options', 'quantifiers', 'recursive rules', 'multiple parser rules',
                     'parse tree translation', 'general ANTLR frontend', 'other ANTLR versions/targets', 'libraries/ABI'],
        'complete_normative_candidate_inventory': False, 'full_standard_qualified': False,
    }
    report = {'schema': 'usl.antlr4.scoped-qualification.v1', 'passed': passed,
              'catalog_ids': ['antlr-python', 'antlr-cpp'], 'profiles': profile_records, 'scope': scope,
              'source_grammars': [dict(grammar, IR=asdict(programs[grammar['id']].ir),
                                      source_sha256=hashlib.sha256(grammar['source'].encode()).hexdigest(),
                                      generated_USL_sha256=programs[grammar['id']].generated_sha256) for grammar in GRAMMARS],
              'source_files': {name: {'sha256': sha(output / name), 'bytes': (output / name).stat().st_size} for name in file_names},
              'implementation_sha256': {name: sha(ROOT / name) for name in ['antlr_semantics.py', 'qualify_antlr.py', 'restore_antlr.py']},
              'toolchain_metadata_sha256': sha(ROOT / 'inputs/antlr4-debian.json'),
              'native_hosts': native_metadata, 'cases': records, 'symbolic_predicate_proofs': proofs,
              'fresh_full_USL_parse_crosschecks': fresh_syntax_crosschecks,
              'native_evaluations': len(records), 'generated_USL_executions': len(records) + len(fresh_syntax_crosschecks),
              'native_processes': len(jobs), 'full_standard_qualified': False, 'complete_language_rule_sets': 0,
              'native_processes_kind': 'Fresh parser host processes, each constructing a fresh lexer/parser per input',
              'generator_compile_processes': sum(item['generator_compile_processes'] for item in native_metadata.values()),
              'toolchain_identity_query_processes': sum(item['toolchain_identity_query_processes'] for item in native_metadata.values()),
              'all_logical_case_workers_started_concurrently': all_actors_started_before_release,
              'logical_case_workers': started_actors, 'peak_live_logical_case_workers': peak,
              'actual_interpreter_execution_threads': 1, 'resource_admission': admission, 'fixed_rounds': False,
              'native_execution_evidence_replayed': False, 'references': reference_records(),
              'elapsed_seconds': time.monotonic() - started}
    (output / 'qualification.json').write_text(json.dumps(report, indent=2, ensure_ascii=True) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'antlr-results')
    parser.add_argument('--prefix', type=Path, default=DEFAULT_PREFIX)
    parser.add_argument('--java-jars', type=Path, default=DEFAULT_JARS)
    args = parser.parse_args(); sys.path.insert(0, str(args.source_root.resolve()))
    report = asyncio.run(execute(args.output, args.prefix, args.java_jars))
    print(json.dumps({key: report[key] for key in ['passed', 'catalog_ids', 'native_evaluations', 'generated_USL_executions',
                                                  'native_processes', 'logical_case_workers', 'full_standard_qualified', 'elapsed_seconds']}, indent=2))
    if not report['passed']: raise SystemExit(1)
