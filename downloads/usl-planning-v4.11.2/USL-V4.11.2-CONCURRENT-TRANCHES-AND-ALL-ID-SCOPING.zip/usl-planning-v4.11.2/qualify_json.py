"""Independent suite, native parser, generated USL and roundtrip checks."""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def native_batch(records):
    payload = [{'id': key, 'base64': base64.b64encode(data).decode()} for key, data in records]
    result = subprocess.run([sys.executable, '-I', str(ROOT / 'json_native_reference.py')], input=json.dumps(payload).encode(), capture_output=True, timeout=30)
    if result.returncode:
        raise ValueError('Independent native reference failed: ' + result.stderr.decode(errors='replace')[:400])
    output = json.loads(result.stdout)
    if [r['id'] for r in output] != [key for key, data in records]:
        raise ValueError('Native evidence missing/reordered')
    return {r['id']: r for r in output}


def qualify(suite, output):
    from json_semantics import JSONResourceLimit, JSONRuleError, LIMITS, STANDARD, generate_json, parse_json, run_usl
    started = time.perf_counter();output = Path(output);output.mkdir(parents=True, exist_ok=True)
    suite = Path(suite).resolve()
    commit = subprocess.check_output(['git', '-C', str(suite), 'rev-parse', 'HEAD'], text=True).strip()
    if commit != '1ef36fa01286573e846ac449e8683f8833c5b26a':
        raise ValueError('Unexpected JSONTestSuite commit')
    files = sorted((suite / 'test_parsing').glob('*.json'))
    originals = [(path.name, path.read_bytes()) for path in files]
    native_originals = native_batch(originals)
    records, generated = [], []
    for name, data in originals:
        expected = True if name.startswith('y_') else False if name.startswith('n_') else None
        record = {'file': name, 'source_sha256': hashlib.sha256(data).hexdigest(), 'suite_expectation': expected,
                  'native_original': native_originals[name]}
        try:
            value = parse_json(data)
            record.update(accepted=True, IR=value)
        except JSONResourceLimit as error:
            record.update(accepted=None, permitted_resource_limit=str(error))
        except JSONRuleError as error:
            record.update(accepted=False, error=str(error))
        if record['accepted'] is not None and expected is not None and record['accepted'] != expected:
            record['passed'] = False
        elif record['accepted'] is True:
            translated = run_usl(record['IR'])
            encoded = generate_json(translated, duplicate_policy='preserve')
            generated.append((name, encoded))
            record.update(generated_USL_matches=translated == record['IR'], generated_json_sha256=hashlib.sha256(encoded).hexdigest(),
                          roundtrip_matches=parse_json(encoded) == record['IR'])
            native = record['native_original']
            record['passed'] = native['accepted'] is True and native['IR'] == record['IR'] and record['generated_USL_matches'] and record['roundtrip_matches']
        elif record['accepted'] is False:
            record['passed'] = native_originals[name]['accepted'] is False
        else:
            record['passed'] = True  # allowed limit recorded, never called acceptance/conformance evidence
        records.append(record)
    native_generated = native_batch(generated)
    for record in records:
        if record['accepted'] is True:
            native = native_generated[record['file']]
            record['native_generated'] = native
            record['passed'] = record['passed'] and native['accepted'] is True and native['IR'] == record['IR']
    failures = [r for r in records if not r['passed']]
    report = {'schema': 'usl.JSON.published-RFC8259-candidate.v1', 'passed': not failures, 'standard_profile': STANDARD,
              'resource_limits': LIMITS, 'suite': 'nst/JSONTestSuite', 'suite_commit': commit, 'suite_cases': len(records),
              'accepted_cases': sum(r['accepted'] is True for r in records), 'rejected_cases': sum(r['accepted'] is False for r in records),
              'permitted_resource_limits': sum(r['accepted'] is None for r in records),
              'fresh_native_processing_cases': len(originals) + len(generated), 'fresh_USL_translation_cases': len(generated),
              'source_identities': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ['json_semantics.py', 'json_native_reference.py', 'qualify_json.py']},
              'native_runtime': sys.version, 'full_standard_qualified': False,
              'not_proved': ['arbitrary source implementation correctness', 'all possible inputs beyond tested/structurally reviewed domains'],
              'gates_open': ['independent normative audit/review final decision', 'published text versus current errata conflict resolution', 'requested whole-profile formal correctness evidence'],
              'native_observations_replayed': False, 'seconds': time.perf_counter() - started, 'records': records}
    (output / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'records'}))
    if failures:
        print(json.dumps({'counterexamples': [{k: v for k, v in r.items() if k not in {'IR', 'native_original'}} for r in failures]}, indent=2))
        raise ValueError(f'{len(failures)} semantic counterexamples')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--suite', type=Path, default=Path('/workspace/.onboarding/providers/JSONTestSuite'))
    parser.add_argument('--output', type=Path, default=Path('json-results'))
    args = parser.parse_args();sys.path.insert(0, str(args.source_root.resolve()))
    qualify(args.suite, args.output)
