"""Intent, boundary and rejection tests for the actual new frontend."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
if not any(Path(p, 'usl_systems').is_dir() for p in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from brainfuck_semantics import ProfileError, emit_usl, lower, reference_machine, run_generated


class SemanticsTests(unittest.TestCase):
    def test_nested_loop_multiplication_independent_intent(self):
        program = ',>,<[>[->+>+<<]>>[-<<+>>]<<<-]>>.'
        for a, b in [(0, 3), (7, 8), (16, 17)]:
            observed, receipt = run_generated(program, bytes([a, b]))
            self.assertEqual(observed, bytes([a * b % 256]))
            self.assertEqual(reference_machine(program, bytes([a, b])), observed)
            self.assertTrue(receipt['actual_USL_execution'])

    def test_loop_pointer_movement_and_zero_skip(self):
        # Condition must be re-read at the final pointer, not the opening cell.
        observed, _ = run_generated('+[>].')
        self.assertEqual(observed, b'\0')
        observed, _ = run_generated('[,].', b'A')
        self.assertEqual(observed, b'\0')

    def test_EOF_modes_and_real_byte_boundaries(self):
        for eof, expected in [('zero', 0), ('same', 1), ('eof', 255)]:
            self.assertEqual(run_generated('+,.', eof=eof)[0], bytes([expected]))
        self.assertEqual(run_generated(',-.', b'\0')[0], b'\xff')
        self.assertEqual(run_generated(',+.', b'\xff')[0], b'\0')

    def test_unbalanced_and_overdeep_source_rejected(self):
        for source in ['[', ']', '][', '[' * 41 + ']' * 41, '+!input', '#!/usr/bin/beef\n+.']:
            with self.assertRaises(ProfileError):
                lower(source)

    def test_native_counterexample_boundary_remains_rejected(self):
        for mode in ['zero', 'eof']:
            with self.assertRaises(ProfileError):
                run_generated(',+.', b'\xff', eof=mode)

    def test_pointer_escape_rejected_without_claiming_host_failure(self):
        # Beef has a dynamically sized tape; this frontend states a narrower profile.
        with self.assertRaises(Exception) as raised:
            run_generated('<')
        self.assertIn('Pointer outside qualified', str(raised.exception))

    def test_nontermination_keeps_unknown_instead_of_success(self):
        with self.assertRaises(Exception) as raised:
            run_generated('+[]', max_ops=20)
        self.assertIn('termination is unknown', str(raised.exception))

    def test_independent_intent_detects_corrupt_translation(self):
        source = emit_usl(',+.').replace('+ 1) % 256', '- 1) % 256')
        with patch('brainfuck_semantics.emit_usl', return_value=source):
            incorrect, _ = run_generated(',+.', b'\x05')
        self.assertNotEqual(incorrect, b'\x06')
        self.assertEqual(reference_machine(',+.', b'\x05'), b'\x06')


if __name__ == '__main__':
    unittest.main()
