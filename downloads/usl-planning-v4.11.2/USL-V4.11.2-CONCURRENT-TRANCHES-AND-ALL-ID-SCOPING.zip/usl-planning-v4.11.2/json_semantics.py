"""Complete published RFC 8259 grammar with explicit permitted resource limits.

Lossless IR retains number spellings, duplicate members, order and lone escaped
surrogates. This implementation is a qualification candidate, not certification.
"""
from __future__ import annotations

import re
from usl_systems.language import Interpreter

STANDARD = 'RFC8259-published-December2017'
LIMITS = {'input_bytes': 65536, 'depth': 40, 'nodes': 10000, 'string_codepoints': 8192, 'number_characters': 1024}
NUMBER = re.compile(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?')
WS = frozenset(' \t\r\n')
HEX = frozenset('0123456789ABCDEFabcdef')


class JSONRuleError(ValueError):
    pass


class JSONResourceLimit(JSONRuleError):
    pass


def parse_json(data):
    if isinstance(data, str):
        try:
            data = data.encode('utf-8')
        except UnicodeEncodeError as error:
            raise JSONRuleError('Raw Unicode surrogate cannot be encoded as UTF-8') from error
    if not isinstance(data, bytes):
        raise JSONRuleError('Expected UTF-8 bytes or Unicode text')
    if len(data) > LIMITS['input_bytes']:
        raise JSONResourceLimit('RFC9 input-size limit')
    try:
        text = data.decode('utf-8')
    except UnicodeDecodeError as error:
        raise JSONRuleError('RFC8.1 network JSON must use UTF-8') from error
    if text.startswith('\ufeff'):
        text = text[1:]  # RFC8.1 explicitly permits parsers to ignore a BOM.
    parser = Parser(text)
    value = parser.value(0)
    parser.whitespace()
    if parser.position != len(text):
        raise JSONRuleError(f'Trailing content at offset {parser.position}')
    return value


class Parser:
    def __init__(self, text):
        self.text = text
        self.position = 0
        self.nodes = 0

    def whitespace(self):
        while self.position < len(self.text) and self.text[self.position] in WS:
            self.position += 1

    def take(self, token):
        if not self.text.startswith(token, self.position):
            raise JSONRuleError(f'Expected {token!r} at offset {self.position}')
        self.position += len(token)

    def value(self, depth):
        if depth > LIMITS['depth']:
            raise JSONResourceLimit('RFC9 nesting-depth limit')
        self.nodes += 1
        if self.nodes > LIMITS['nodes']:
            raise JSONResourceLimit('RFC9 node-count limit')
        self.whitespace()
        if self.position >= len(self.text):
            raise JSONRuleError('Expected a JSON value')
        character = self.text[self.position]
        if character == '"':
            return ['string', self.string()]
        if character == '{':
            self.position += 1;self.whitespace();pairs = []
            if self.position < len(self.text) and self.text[self.position] == '}':
                self.position += 1;return ['object', pairs]
            while True:
                self.whitespace();key = self.string();self.whitespace();self.take(':')
                pairs.append([key, self.value(depth + 1)])
                self.whitespace()
                if self.position < len(self.text) and self.text[self.position] == '}':
                    self.position += 1;return ['object', pairs]
                self.take(',')
        if character == '[':
            self.position += 1;self.whitespace();items = []
            if self.position < len(self.text) and self.text[self.position] == ']':
                self.position += 1;return ['array', items]
            while True:
                items.append(self.value(depth + 1));self.whitespace()
                if self.position < len(self.text) and self.text[self.position] == ']':
                    self.position += 1;return ['array', items]
                self.take(',')
        for spelling, result in [('true', ['boolean', True]), ('false', ['boolean', False]), ('null', ['null'])]:
            if self.text.startswith(spelling, self.position):
                self.position += len(spelling)
                return result
        match = NUMBER.match(self.text, self.position)
        if not match:
            raise JSONRuleError(f'Invalid JSON token at offset {self.position}')
        spelling = match.group()
        if len(spelling) > LIMITS['number_characters']:
            raise JSONResourceLimit('RFC9 numeric-lexeme length limit; no rounding performed')
        self.position = match.end()
        return ['number', spelling]

    def hex_quad(self):
        digits = self.text[self.position:self.position + 4]
        if len(digits) != 4 or any(c not in HEX for c in digits):
            raise JSONRuleError('Expected four hexadecimal escape digits')
        self.position += 4
        return int(digits, 16)

    def string(self):
        self.take('"');points = []
        escapes = {'"': 34, '\\': 92, '/': 47, 'b': 8, 'f': 12, 'n': 10, 'r': 13, 't': 9}
        while self.position < len(self.text):
            character = self.text[self.position];self.position += 1
            if character == '"':
                return points
            if character == '\\':
                if self.position >= len(self.text):
                    raise JSONRuleError('Unterminated escape')
                escape = self.text[self.position];self.position += 1
                if escape == 'u':
                    point = self.hex_quad()
                    if 0xD800 <= point <= 0xDBFF and self.text.startswith('\\u', self.position):
                        candidate = self.text[self.position + 2:self.position + 6]
                        if len(candidate) == 4 and all(c in HEX for c in candidate) and 0xDC00 <= int(candidate, 16) <= 0xDFFF:
                            self.position += 2
                            point = 0x10000 + (point - 0xD800) * 0x400 + self.hex_quad() - 0xDC00
                    points.append(point)
                elif escape in escapes:
                    points.append(escapes[escape])
                else:
                    raise JSONRuleError('Invalid escape')
            else:
                if ord(character) < 32:
                    raise JSONRuleError('Unescaped control character')
                points.append(ord(character))
            if len(points) > LIMITS['string_codepoints']:
                raise JSONResourceLimit('RFC9 string-length limit')
        raise JSONRuleError('Unterminated string')


def quote(points):
    if not isinstance(points, list) or len(points) > LIMITS['string_codepoints']:
        raise JSONRuleError('Invalid/oversized IR string')
    out = ['"']
    previous = None
    for point in points:
        if type(point) is not int or not 0 <= point <= 0x10FFFF:
            raise JSONRuleError('Invalid IR code point')
        if previous is not None and 0xD800 <= previous <= 0xDBFF and 0xDC00 <= point <= 0xDFFF:
            raise JSONRuleError('IR must combine adjacent surrogate pairs into one code point')
        previous = point
        if point in (34, 92):
            out.append('\\' + chr(point))
        elif point < 32 or 0xD800 <= point <= 0xDFFF:
            out.append('\\u' + format(point, '04x'))
        else:
            out.append(chr(point))
    out.append('"')
    return ''.join(out)


def generate_json(value, duplicate_policy='reject'):
    if duplicate_policy not in {'reject', 'preserve'}:
        raise JSONRuleError('Unknown duplicate generation policy')
    nodes = 0

    def emit(node, depth):
        nonlocal nodes
        if depth > LIMITS['depth']:
            raise JSONResourceLimit('RFC9 nesting-depth limit')
        nodes += 1
        if nodes > LIMITS['nodes']:
            raise JSONResourceLimit('RFC9 node-count limit')
        if not isinstance(node, list) or not node:
            raise JSONRuleError('Expected tagged JSON IR')
        kind = node[0]
        if kind == 'null' and len(node) == 1:
            return 'null'
        if len(node) != 2:
            raise JSONRuleError('Incorrect IR arity')
        value = node[1]
        if kind == 'boolean' and type(value) is bool:
            return 'true' if value else 'false'
        if kind == 'number' and isinstance(value, str) and len(value) <= LIMITS['number_characters'] and NUMBER.fullmatch(value):
            return value
        if kind == 'string':
            return quote(value)
        if kind == 'array' and isinstance(value, list):
            return '[' + ','.join(emit(item, depth + 1) for item in value) + ']'
        if kind == 'object' and isinstance(value, list):
            seen = set();members = []
            for pair in value:
                if not isinstance(pair, list) or len(pair) != 2 or not isinstance(pair[0], list):
                    raise JSONRuleError('Invalid member pair')
                key = quote(pair[0]);identity = tuple(pair[0])
                if identity in seen and duplicate_policy == 'reject':
                    raise JSONRuleError('RFC4 names SHOULD be unique; explicit preserve policy required for lossless duplicate input')
                seen.add(identity)
                members.append(key + ':' + emit(pair[1], depth + 1))
            return '{' + ','.join(members) + '}'
        raise JSONRuleError('Invalid JSON IR kind/value')

    # Raw Unicode scalars use UTF-8; lone surrogates remain escaped. No BOM.
    return emit(value, 0).encode('utf-8')


def emit_usl(value):
    # Category translation materializes a typed data tree; JSON is not code.
    # The validated literal contains only tags, lexemes, codepoint integers and booleans.
    generate_json(value, duplicate_policy='preserve')
    return '// Lossless RFC8259 data translation into USL IR.\nlet document = ' + repr(value) + '\n'


def run_usl(value):
    generated = emit_usl(value)
    result = Interpreter(timeout=5, max_ops=2_000_000).run(generated)
    return result.variables['document']
