"""Join the complete preparation ledger with separately validated profiles."""
import argparse
import collections
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def integrate(output):
    scope_path=ROOT/'scope-all-results/ALL_IDS.json';catalog_path=ROOT/'joined-results/catalog.json'
    ledger=json.loads(scope_path.read_text());catalog=json.loads(catalog_path.read_text())
    recovery_path=ROOT/'reference-recovery-results/RECOVERED_REFERENCES.json'
    recovered={}
    if recovery_path.exists():
        recovery=json.loads(recovery_path.read_text())
        if recovery['source_scope_ledger_sha256']!=sha(scope_path):raise ValueError('Recovery applies to a different scoping ledger')
        recovered={r['catalog_id']:r for r in recovery['records']}
        if len(recovered)!=137 or len(recovered)!=len(recovery['records']):raise ValueError('Recovery ID coverage changed')
    plans={r['catalog_id']:r for r in ledger['records']};qualified={r['catalog_id']:r for r in catalog['entries']}
    if set(plans)!=set(qualified) or len(plans)!=607:raise ValueError('Scoping/catalog join lost or added IDs')
    records=[]
    for identifier,row in sorted(qualified.items()):
        plan=plans[identifier]
        if not plan['planning_record_complete']:raise ValueError('Incomplete preparation record: '+identifier)
        candidate=recovered.get(identifier,{}).get('selected')
        if candidate and recovered[identifier]['reference_body_recovered']:
            identity=candidate['sha256']
            if len(identity)!=64 or any(c not in '0123456789abcdef' for c in identity):raise ValueError('Invalid recovered body identity')
            body=Path('/workspace/.onboarding/data/v411-public-reference-cache')/identity
            if body.exists() and sha(body)!=identity:raise ValueError('Recovered candidate body is corrupt')
            recovered_candidate={'url':candidate['url'],'final_url':candidate['final_url'],'sha256':identity,
                                 'authority_version_and_applicability_audit_complete':False,
                                 'body_present_and_hash_verified_now':body.exists()}
        else:recovered_candidate=None
        records.append({'catalog_id':identifier,'original_catalog':row['original_catalog'],'family':row['family'],
            'scoping_plan_present':True,'validated_bounded_profile':row['scoped'],'full_standard_qualified':False,
            'exact_version_normative_semantic_audit_complete':False,
            'qualified_profile_description':row['scope'] if row['scoped'] else None,
            'profile_receipt_sha256':row.get('scoped_receipt_sha256'),
            'host_candidate':plan['candidate']['upstream_host_candidate'],
            'specific_semantic_focus':plan['candidate']['semantic_focus'],
            'available_reference_body_objects':sum(bool(r['body_available_and_hash_verified_now']) for r in plan['reference_body_checks']),
            'recovered_candidate_reference':recovered_candidate,
            'next_implementation_step':('extend_profile_and_complete_normative_semantic_audit' if row['scoped'] else
                 'pin_exact_specification_and_audit_semantic_clauses' if recovered_candidate or any(r['body_available_and_hash_verified_now'] for r in plan['reference_body_checks']) else
                 'recover_correct_upstream_reference_and_continue_independent_host_inventory'),
            'external_dependencies':row['external_dependencies'],'family_shared_artifact_key':plan['family_shared_artifact_key'],
            'full_plan_locator':{'file':'../scope-all-results/ALL_IDS.json','catalog_id':identifier,
                 'record_sha256':hashlib.sha256(json.dumps(plan,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()}})
    originals=[r for r in records if r['original_catalog']];remaining=[r for r in originals if not r['validated_bounded_profile']]
    summary={'all_IDs_with_preparation_records':len(records),'original_IDs':len(originals),
             'initial_uncovered_IDs_with_distinct_plans':362,'initial_uncovered_without_plans':0,
             'validated_bounded_profiles':sum(r['validated_bounded_profile'] for r in originals),
             'remaining_without_validated_profile':len(remaining),'full_standards_qualified':0,'complete_entity_tracks':0,
             'remaining_with_existing_reference_bodies':sum(r['available_reference_body_objects']>0 for r in remaining),
             'remaining_still_needing_reference_bodies':sum(r['available_reference_body_objects']==0 for r in remaining),
             'remaining_with_retrieved_reference_candidates_after_recovery':sum(r['available_reference_body_objects']>0 or r['recovered_candidate_reference'] is not None for r in remaining),
             'remaining_without_retrieved_reference_candidate_after_recovery':sum(r['available_reference_body_objects']==0 and r['recovered_candidate_reference'] is None for r in remaining),
             'full_rule_sets_finished_for_all':False,'full_project_ETA_seconds':None}
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    value={'schema':'usl.scoping-and-executable-progress.v1','summary':summary,
           'source_ledger_sha256':sha(scope_path),'validated_catalog_sha256':sha(catalog_path),
           'reference_recovery_sha256':sha(recovery_path) if recovery_path.exists() else None,'records':records}
    (output/'CURRENT_SCOPE.json').write_text(json.dumps(value,indent=2)+'\n')
    ready={'all_eligible_IDs_enqueued_together':len(remaining),'fixed_rounds':False,'ready_actions':[
        {'catalog_id':r['catalog_id'],'next_action':r['next_implementation_step'],'family_shared_artifact_key':r['family_shared_artifact_key'],
         'external_dependencies':r['external_dependencies'],'complete_semantics_or_execution_claimed':False} for r in remaining]}
    (output/'NEXT_READY_WORK.json').write_text(json.dumps(ready,indent=2)+'\n')
    counts=collections.Counter(r['family'] for r in remaining)
    lines=['# Current language preparation and executable coverage','',
        f"All 362 initially uncovered IDs have distinct preparation plans. {summary['validated_bounded_profiles']} of606 original IDs have validated bounded profiles; {len(remaining)} still need one. Full standards qualified:0.",'',
        f"After recovery, {summary['remaining_with_retrieved_reference_candidates_after_recovery']} of{len(remaining)} remaining IDs have retrieved reference candidates; {summary['remaining_without_retrieved_reference_candidate_after_recovery']} still need a body. All exact version/authority and complete normative-semantic audits remain open.",'',
        'The full plans retain host/version candidates, semantic questions, source locators, category-specific native/intent contracts, dependencies and every original obligation. Normative audits and full rule implementations remain open.','',
        '| Family | Remaining profiles |','|---|---:|',*[f'| {family} | {count} |' for family,count in sorted(counts.items())],'',
        '| ID | Candidate host | Specific semantic work | Reference candidate | Next action |','|---|---|---|---|---|']
    for r in remaining:
        references='retrieved fallback; audit open' if r['recovered_candidate_reference'] else 'existing objects; audit open' if r['available_reference_body_objects'] else 'body missing'
        cells=[r['catalog_id'],r['host_candidate'],'; '.join(r['specific_semantic_focus']),references,r['next_implementation_step']]
        lines.append('| '+' | '.join(str(c).replace('|','\\|').replace('\n',' ') for c in cells)+' |')
    (output/'CURRENT_SCOPE.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary));return value


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=Path('current-scope-results'))
    integrate(p.parse_args().output)
