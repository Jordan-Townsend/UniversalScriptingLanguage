import ast
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import tempfile
import unittest

if not any((Path(item) / 'usl_systems').is_dir() for item in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from antlr_semantics import AntlrProfileError, DEFAULT_PREFIX, Program, frontend, native_batch

SOURCE = "grammar UslWords; document: ('ab' | 'ba') EOF;"


class AntlrSemanticsTests(unittest.TestCase):
    def test_rejects_unsupported_or_ambiguous_source(self):
        for source in ["grammar UslWords; document: 'ab' | 'ba' EOF;", SOURCE + ' token: x;',
                       SOURCE.replace("'ab'", "'a\\n'"), SOURCE.replace("'ba'", "'ab'"),
                       SOURCE.replace("'ab'", "''"), SOURCE.replace("'ab'", "'é'"),
                       SOURCE.replace(' EOF', ''), SOURCE.replace('document', 'start'),
                       SOURCE + ' /*comment*/', SOURCE.replace('grammar ', 'grammar\v'),
                       SOURCE.replace('UslWords', 'A' * 65)]:
            with self.subTest(source=source), self.assertRaises(AntlrProfileError): frontend(source)

    def test_generated_actual_USL_requires_exact_whole_input(self):
        program = Program(SOURCE)
        for text, expected in [('ab', True), ('ba', True), ('', False), ('aba', False),
                               ('ab\n', False), ('ab\0', False), ('é', False), ('😀', False)]:
            with self.subTest(text=text):
                result, receipt = program.run(text)
                self.assertEqual(result, expected); self.assertTrue(receipt['actual_USL_execution'])
                self.assertEqual(program.run(text, cached_syntax=False)[0], expected)
        with self.assertRaises(AntlrProfileError): program.run('\ud800')
        with self.assertRaises(AntlrProfileError): program.run('x' * 65537)

    def test_actual_generated_AST_proof_detects_intent_and_code_counterexamples(self):
        program = Program(SOURCE)
        self.assertTrue(program.prove_predicate(['ab', 'ba'])['passed'])
        wrong_intent = program.prove_predicate(['ab'])
        self.assertFalse(wrong_intent['passed']); self.assertIsNotNone(wrong_intent['counterexample'])
        program.tree.body[0].body[0].value.values[0].comparators[0].value = 'different'
        changed_code = program.prove_predicate(['ab', 'ba'])
        self.assertFalse(changed_code['passed']); self.assertIsNotNone(changed_code['counterexample'])

    @unittest.skipUnless((DEFAULT_PREFIX / 'python/antlr4/__init__.py').is_file(), 'Run restore_antlr.py for native runtimes')
    def test_native_targets_reject_error_recovery_and_trailing_data(self):
        texts = ['ab', 'ba', '', 'abx', 'xab', 'ab\0', 'ab\n', 'é', '😀', '\0', 'a b', 'abab']
        expected = [True, True] + [False] * (len(texts) - 2)
        for backend in ['python', 'cpp']:
            with self.subTest(backend=backend):
                observed, metadata = native_batch(SOURCE, texts, backend)
                self.assertEqual(observed, expected)
                self.assertEqual(metadata['fresh_native_evaluations'], len(texts))
                self.assertFalse(metadata['native_execution_evidence_reused'])

    @unittest.skipUnless((DEFAULT_PREFIX / 'python/antlr4/__init__.py').is_file(), 'Run restore_antlr.py for native runtimes')
    def test_single_flight_shares_only_artifact_and_executes_distinct_inputs_freshly(self):
        with tempfile.TemporaryDirectory(prefix='usl-antlr-single-flight-') as temporary:
            prefix = Path(temporary)
            (prefix / 'usr').symlink_to(DEFAULT_PREFIX / 'usr', target_is_directory=True)
            (prefix / 'python').symlink_to(DEFAULT_PREFIX / 'python', target_is_directory=True)
            with ThreadPoolExecutor(max_workers=2) as executor:
                tasks = [executor.submit(native_batch, SOURCE, texts, 'python', prefix)
                         for texts in [['ab'], ['abx']]]
                results = [task.result() for task in tasks]
            self.assertEqual([result[0] for result in results], [[True], [False]])
            self.assertEqual(sum(not result[1]['pure_artifact_reused'] for result in results), 1)
            self.assertTrue(all(result[1]['single_flight_build'] for result in results))
            self.assertTrue(all(not result[1]['native_execution_evidence_reused'] for result in results))


if __name__ == '__main__': unittest.main()
