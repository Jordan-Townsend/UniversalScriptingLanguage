import sys
from pathlib import Path
import unittest
sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
from forth_semantics import Program, ForthProfileError, MINIMUM, MAXIMUM, frontend, native_batch


class ForthTests(unittest.TestCase):
    def test_reject_unsupported_and_bad_structure(self):
        for source in [': usl-main recurse ;',': usl-main @ ;',': usl-main if 1 ;',': usl-main begin 1 ;',
                       ': usl-main 1 ; : usl-main 2 ;',': usl-main later ; : later 1 ;',': usl-main 9223372036854775808 ;']:
            with self.subTest(source=source),self.assertRaises(ForthProfileError):frontend(source)

    def test_call_depth_bound(self):
        source=': d0 1 ; '+''.join(': d%d d%d ; '%(n,n-1) for n in range(1,24))+': usl-main d23 ;'
        with self.assertRaises(ForthProfileError):frontend(source)

    def test_numeric_boundaries_and_stack_prefix(self):
        p=Program(': usl-main + ;')
        self.assertEqual(p.run([7,MAXIMUM,1])[0],[7,MINIMUM])
        self.assertEqual(Program(': usl-main /mod ;').run([-7,3])[0],[2,-3])
        self.assertEqual(Program(': usl-main rshift ;').run([-1,63])[0],[1])
        self.assertEqual(Program(': usl-main rshift ;').run([-1,0])[0],[-1])

    def test_resources_fail_closed(self):
        for source,inputs in [(': usl-main drop ;',[]),(': usl-main / ;',[2,0]),(': usl-main lshift ;',[1,64]),(': usl-main dup ;',list(range(64)))]:
            with self.subTest(source=source),self.assertRaises(Exception):Program(source).run(inputs)

    def test_max_stack_native_not_truncated(self):
        values=list(range(64));actual,_=native_batch(': usl-main ;',[values])
        self.assertEqual(actual,[values])
        self.assertEqual(Program(': usl-main ;').run(values)[0],values)

    def test_immutable_syntax_fresh_environment(self):
        p=Program(': square dup * ; : usl-main square ;')
        self.assertEqual(p.run([3])[0],[9]);self.assertEqual(p.run([-7])[0],[49])
        self.assertEqual(p.run([3],cached_syntax=False)[0],[9])


if __name__=='__main__':unittest.main()
