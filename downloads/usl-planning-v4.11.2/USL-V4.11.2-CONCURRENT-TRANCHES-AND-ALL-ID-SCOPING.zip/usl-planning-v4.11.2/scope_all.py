"""All-ID, evidence-linked scoping proposals, distinct from implemented semantics.

The explicitly authored candidate/focus table below covers every currently
unscoped ID. Candidates are research leads, not installed-tool or version claims.
Pure input objects are hash-verified and shared; execution evidence is not reused.
"""
from __future__ import annotations

import argparse
import asyncio
import collections
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parent
PRIVATE_CACHE = Path('/workspace/.onboarding/data/v411-public-reference-cache')

# id | candidate upstream implementation/host | ID-specific semantic audit focus
# No release is silently chosen. Legacy dialects and similarly named languages
# stay separate until their specification, implementation and target are pinned.
CANDIDATES = r'''
abap|SAP ABAP application server|internal tables; field symbols; Open SQL and transactions
bbcbasic|BBC BASIC SDL edition or Brandy|BBC dialect differences; numeric formats; graphics and OS calls
blitzbasic|legacy BlitzBasic Windows host|BASIC dialect; graphics loop; Windows runtime ABI
blitzmax|BlitzMax NG|object and module rules; garbage collection; native linking
cbmbas|VICE Commodore BASIC host|machine model; tokenized lines; PEEK/POKE and screen state
comal|OpenCOMAL candidate|line and block syntax; numeric model; procedure parameter passing
componentpascal|BlackBox Component Builder or Gardens Point Component Pascal|module visibility; extensible records; runtime and platform bindings
easytrieve|authorized Broadcom Easytrieve host|record layouts; report processing; file and mainframe facilities
eiffel|Gobo Eiffel or EiffelStudio|contracts; inheritance and rename/select; exception and void safety
ezhil|Ezhil interpreter|Tamil tokenization; value conversions; Python-host library boundary
foxpro|authorized Visual FoxPro host|xBase records; work areas and indexes; Windows COM behavior
openedge|authorized Progress OpenEdge ABL host|transaction scope; record locking; database schema and session state
qbasic|QB64-PE versus historical QBasic host|dialect choice; fixed strings; numeric and device behavior
xpp|authorized Microsoft Dynamics AX/365 X++ host|X++ classes and extensions; transactional database access; Dynamics platform APIs
actionscript|Apache Flex ASC or historical AVM1 host|ActionScript 1/2 identity; AVM1 coercions; Flash display and event model
actionscript3|Apache Flex compiler and AVM2 host|ECMA-357 and AS3 types; prototype versus sealed classes; AVM2 events
ambienttalk|AmbientTalk interpreter on JVM|actor isolation; eventual references; offline service discovery
arturo|Arturo interpreter|stack/evaluation rules; symbol binding; native built-ins and modules
berry|Berry interpreter|compact VM types; class dispatch; embedded host bindings
boa|Boa compiler and dataset host|aggregator semantics; input dataset schema; distributed query execution
chaiscript|ChaiScript C++ embedding|dynamic dispatch; boxed values; C++ registration and ownership
croc|Croc compiler/runtime|closures and coroutines; classes; native API and garbage collection
dart|Dart SDK|null safety; isolates and futures; package and platform libraries
dg|pyos/dg compiler on compatible Python|prefix grammar; Python-version lowering; closures and macro-like constructs
dylan|Open Dylan|generic method dispatch; type constraints; libraries and native FFI
earl-grey|Earl Grey compiler on Node|macro expansion; lexical bindings; generated JavaScript behavior
fancy|Fancy on compatible Rubinius|message sends; blocks and classes; Rubinius-version dependencies
gdscript|Godot headless|Godot 3 versus 4; Variant and typed values; scene and signal lifecycle
hybris|Hybris upstream interpreter identity to resolve|language identity; object behavior; extension/module interface
icon|University of Arizona Icon or Unicon compatibility mode|goal-directed evaluation; generators and failure; string scanning
io|Io VM|prototype lookup; message evaluation; coroutine and collector behavior
ioke|Ioke JVM or CLR implementation|prototype cells; restart conditions; message-chain evaluation
kal|Kaffeine/Kal upstream identity to resolve|lexer identity; language revision; continuation and JavaScript lowering
kuin|Kuin compiler and supported host|language release; arrays and class ownership; Windows library behavior
lsl|OpenSimulator LSL scripting host|event state machine; vector/rotation arithmetic; simulator-specific APIs
luau|Luau CLI|gradual types; Lua compatibility boundaries; sandbox and library differences
minid|MiniD legacy runtime versus renamed Croc|historical version; class and closure semantics; embedding ABI
miniscript|MiniScript interpreter|intrinsic calls; map/prototype semantics; numeric and host behavior
monkey|Monkey X compiler|target backend selection; modules and GC; graphics and target libraries
monte|Monte language upstream implementation|object capability scope; guards and auditors; eventual-send semantics
moonscript|MoonScript compiler and Lua|indentation lowering; expression returns; Lua-version metatables and libraries
newspeak|Newspeak VM|nested classes and mixins; module instantiation; message-send rules
nit|Nit compiler|nullability; class refinements; separate compilation and FFI
numba_ir|Numba with exact Python/LLVM versions|IR stage identity; SSA blocks and typing; lowered call and exception rules
objective-j|Cappuccino Objective-J compiler on Node/browser|Objective-J message dispatch; class protocols; browser framework effects
pawn|Pawn compiler plus chosen game/embedding host|cell width; tags and arrays; native callback ABI
phix|Phix interpreter/compiler|sequence operations; numeric representation; Euphoria compatibility and FFI
pointless|Pointless upstream interpreter identity to resolve|collection/value model; function evaluation; language-revision disambiguation
portugol|Portugol Studio or Portugol Webstudio|Portuguese educational dialect; numeric I/O; arrays and library selection
python2|CPython 2.7 historical host|Unicode versus byte strings; integer division; obsolete extension ABI
rebol|REBOL 2 or Rebol 3 separately|evaluation and words; series positions; dialecting and host ports
red|Red toolchain|Red versus Red/System; series and contexts; GUI/platform library boundary
savi|Savi compiler|reference capabilities; inference; ownership and runtime ABI
slash|Slash language upstream runtime|template/code boundary; dynamic dispatch; web request host
smalltalk|GNU Smalltalk or Squeak/Pharo separately|image/dialect choice; live object identity; method lookup and block unwind
snobol|CSNOBOL4|pattern success/failure; dynamic labels; string and external function rules
tea|TeaTrove compiler on JVM|template evaluation; static types; Java method and context exposure
teal|Algorand go-algorand TEAL assembler/evaluator|AVM version and typed stack; transaction/global state; opcode cost and approval behavior
ucode|Icon compiler/interpreter intermediate ucode tools|Icon intermediate instruction identity; linker/runtime representation; goal-directed control flow
unicon|Unicon compiler|goal-directed objects; coexpressions; Icon compatibility and native APIs
urbiscript|Urbi SDK host|reactive scheduling; tags and events; robot/network device bindings
vbscript|Windows Script Host or qualified Wine host|Variant coercion; On Error; COM and filesystem objects
wren|Wren VM|fiber suspension; class dispatch; embedding and foreign methods
zephir|Zephir compiler plus exact PHP SDK|static/dynamic types; Zend extension ABI; generated memory management
adl|OpenEHR ADL tools or correct catalog ADL host after identity audit|ADL identity; constraint semantics; model and terminology dependencies
antlr-actionscript|ANTLR 3 ActionScript target plus AVM2 host|ANTLR target revision; token/lexer behavior; generated AS runtime
antlr-csharp|ANTLR 3/4 CSharp target audited separately|ANTLR generation version; prediction/recovery; matching CSharp runtime
antlr-cpp|ANTLR 4 tool and C++ runtime|target version match; lexer/prediction/recovery; generated C++ API and ABI
antlr-objc|ANTLR 3 Objective-C target|legacy target availability; token ownership; Cocoa runtime/platform dependency
antlr-perl|ANTLR 3 Perl target|target support status; token streams; generated Perl runtime behavior
antlr-python|ANTLR 3 Python or ANTLR 4 Python3 separately|generator/runtime version match; lexer/prediction/recovery; Unicode and EOF
antlr-ruby|ANTLR 3 Ruby target|target revision; tree construction; generated Ruby runtime compatibility
bare|BARE upstream implementation plus chosen target language|schema grammar; integer/union encoding; canonical and invalid message behavior
bnf|chosen BNF dialect and parser generator|metasyntax identity; ambiguity and recursion; parse-result contract
cadl|OpenEHR cADL constraint parser|ADL 1.4 versus ADL 2; complex object/attribute constraints; archetype and reference model validation
camkes|seL4 CAmkES toolchain|component/connector composition; capability generation; seL4 ABI and configuration
capdl|seL4 capDL toolchain|capability graph validity; kernel object sizes; target-architecture loader behavior
cddl|CDDL RFC 8610 validator|group/type choices; control operators; CBOR/JSON data and extension RFCs
jsgf|CMU Sphinx JSGF parser|rule imports; alternatives and weights; recognizer interpretation
mcschema|Minecraft schema provider identity to audit|schema dialect; game-version fields; validation target and processing contract
mxml|Apache Flex SDK|XML namespaces and binding; component initialization; ActionScript generated target
omg-idl|omniORB or TAO IDL compiler|OMG version; type and interface mapping; CDR and target ABI
pddl|Fast Downward plus chosen PDDL validator|requirements level; action/state transition; numeric/temporal extensions
peg|chosen PEG engine and Ford semantics|ordered choice; greediness and left recursion; capture/error contract
ragel-d|Ragel D backend plus compatible D1/D2 compiler|known generated-D1 versus installed-D2 mismatch; machine actions; input indexing
shexc|ShExC parser and ShEx validator|shape recursion; cardinalities and negation; RDF graph and entailment
smithy|Smithy CLI and selected model/target runtime|model version; trait validation; protocol serialization and code generation
swig|SWIG plus chosen C/C++ and target runtime|typemap rules; ownership/lifetimes; exceptions and target-language ABI
tablegen|LLVM TableGen matching LLVM release|record inheritance; multiclass and DAG values; selected emitter backend
tlb|TON TL-B parser/code generator and cell runtime|constructor tags; dependent field sizes and constraints; bit/ref cell serialization
tls|TLS presentation language RFC profile and codec|protocol-version structures; vector length and discriminants; wire parsing and limits
treetop|Treetop and Ruby|PEG ordered choice; semantic nodes/actions; generated Ruby runtime
visualprologgrammar|Visual Prolog grammar tools on licensed host|grammar dialect identity; typed predicates; generated parser and Windows runtime
webidl|WebIDL parser and binding generator|overload resolution; conversion and exceptions; ECMAScript/host binding behavior
agda|Agda compiler with GHC|dependent typing; termination/positivity; backend erasure and standard library
clean|Clean compiler|uniqueness types; lazy graph reduction; world/file effects
cryptol|Cryptol REPL and SMT solver|bitvector widths; sequence polymorphism; totality and solver assumptions
elm|Elm compiler and JavaScript host|type inference; Elm architecture effects; package and browser runtime
fsharp|.NET FSharp compiler|computation expressions; CLR representation; async/task exceptions and libraries
fstar|F* and supported SMT solver|refinement/effect checking; extraction target; trusted code and solver assumptions
futhark|Futhark compiler and selected C/OpenCL/CUDA backend|uniqueness and size types; array fusion; floating/parallel reduction order
idris|Idris 1 versus Idris 2 separately|dependent elaboration; totality; erasure and selected backend runtime
koka|Koka compiler|effect rows and handlers; reference counting; C/JS backend behavior
literate-agda|Agda literate frontend|markup/code extraction; source positions; exact Agda elaborator/backend
literate-cryptol|Cryptol literate frontend|literate extraction; bitvector rules; proof/test correspondence
literate-idris|Idris literate frontend|Bird/Markdown dialect; extraction positions; elaboration and backend version
opa|Opa compiler and supported JS/server runtime|distributed client/server placement; records; database and web effects
reasonml|Reason parser and exact OCaml/ReScript target|syntax versus language identity; variant and module lowering; target ABI
aheui|aheui upstream interpreter|Hangul instruction decoding; storage selection; direction and integer/I/O rules
befunge|Befunge-93 or Funge-98 host separately|playfield dimensions; self-modifying space; stack and nondeterministic direction
redcode|pMARS with chosen ICWS profile|addressing modifiers; process queue; circular memory and tournament rules
alloy|Alloy Analyzer|relational bounds; integer bitwidth; SAT scope versus unbounded claims
bdd|Behave/Cucumber-compatible scenario runner after dialect audit|Given/When/Then bindings; scenario outlines and examples; actual step effects and assertions
boogie|Boogie and supported Z3|verification condition generation; heap/map axioms; solver/trusted assumptions
cplint|cplint on SWI-Prolog|probabilistic clause independence; inference mode; sampling seeds and evidence
elpi|ELPI interpreter|lambda-Prolog binding; higher-order unification; constraints and host API
hspec|Hspec on GHC|test DSL embedding; exception/failure semantics; random property seeds
isabelle|Isabelle distribution|object logic/session identity; proof kernel; code generation and trusted tools
lean|Lean 3 historical toolchain|Lean 3 versus 4 separation; elaboration and kernel; metaprograms and libraries
lean4|Lean 4 toolchain|kernel and elaborator; executable extraction; Lake/native ABI and libraries
logtalk|Logtalk with chosen Prolog backend|object categories/protocols; event handling; backend-specific predicates
nusmv|NuSMV or nuXmv with exact dialect|transition relation; fairness and temporal logic; finite-state/model assumptions
rego|Open Policy Agent|Rego v0/v1; undefined versus false; built-in and policy evaluation behavior
coq|Coq/Rocq pinned historical/current profile|kernel and universes; tactics versus proof terms; extraction and axioms
silver|Viper Silver parser and Silicon/Carbon verifier|permissions and heap separation; inhale/exhale and contracts; verification backend/solver assumptions
tnt|Typographical Number Theory verifier candidate|formal alphabet and inference rules; arithmetic interpretation; proof validation contract
verifpal|Verifpal analyzer|symbolic attacker and primitives; query semantics; computational security limits
visualprolog|Visual Prolog compiler on authorized Windows host|typed predicate determinism; objects and cut; native library/ABI
amdgpu|LLVM AMDGPU assembler/backend plus compatible GPU|target ISA and wavefront; address spaces; barriers and device execution
cuda|NVIDIA CUDA toolkit and compatible device|host/device separation; memory model; SIMT/barriers and numeric behavior
glsl|glslang plus Vulkan/OpenGL implementation|GLSL version/stage; layout and precision; shader pipeline execution
hlsl|DXC plus Direct3D/Vulkan implementation|shader model and stage; resource binding; wave/memory and floating behavior
hsail|HSAIL tools and compatible historical HSA runtime|ISA revision; memory ordering; executable device/runtime availability
modelica|OpenModelica|equation flattening; initialization/events; DAE solver tolerances and libraries
spice|ngspice versus selected SPICE dialect|netlist and device models; initial conditions; transient/nonlinear solver tolerances
wgsl|Tint or Naga plus WebGPU implementation|WGSL revision; address/access rules; shader stage and device behavior
ampl|authorized AMPL plus solver|algebraic model expansion; data/sets; solver status and numeric tolerance
ansys|authorized ANSYS APDL host|parameter and command state; element/material models; solver and license dependencies
arrow|py-arrow-lang interpreter|Arrow package version; function/control evaluation; value types and Python host boundary
asymptote|Asymptote compiler|numeric geometry; module imports; graphics output and TeX dependencies
csound-document|Csound unified document processor|CSD sections; options/orchestra/score composition; render configuration
csound|Csound orchestra compiler|audio/control/init rates; opcode state; sample/block timing and plugin versions
csound-score|Csound score processor|event timing; carry and tempo; instrument/render coupling
flatline|BigML Flatline expression interpreter/API|Lisp-like expression evaluation; field/missing-value rules; BigML data and model bindings
floscript|ioflo FloScript parser/runtime|framer/frame transitions; deed and share resolution; scheduling and external actor effects
func|TON FunC compiler and TVM|cell/slice and integer semantics; TVM exceptions; gas and blockchain state
inform6|Inform 6 compiler and Z-machine/Glulx interpreter|object/property lookup; target word sizes; story I/O and virtual machine
inform7|Inform 7 compiler and story VM|rulebook ordering; world model; generated Inform 6 and story interpreter
lilypond|LilyPond plus Guile|music expressions; timing and layout; Scheme embedding and rendered output
mcfunction|Minecraft Java/Bedrock dedicated host separately|edition/version commands; execution context; tick/world effects
moocode|LambdaMOO server|verb permissions; object inheritance; task scheduling and persistent database
mosel|authorized FICO Xpress Mosel|model execution; solver calls; data modules and optimization outcomes
mozhashpreproc|Mozilla preprocessor implementation|hash directives; include variables; conditional expansion and source locations
mozpercentpreproc|Mozilla percent preprocessor implementation|percent directive dialect; include/conditional expansion; embedding target
mscgen|mscgen renderer|message-chart grammar; attribute resolution; deterministic SVG/render contract
openscad|OpenSCAD CLI|CSG/geometry semantics; module/function scoping; tessellation and geometry comparison
pov|POV-Ray|scene description evaluation; geometry/materials; renderer settings and numeric/image tolerances
praat|Praat batch interpreter|object selection and script state; sound-processing operations; sampling/measurement tolerances
qml|Qt QML engine|property bindings; object ownership; Qt/JavaScript event and GUI behavior
qvto|Eclipse QVTo with EMF|model extent and object identity; mapping resolution; transformation transactions
rell|Chromia Rell compiler and node|entity/database typing; transactions; deterministic blockchain execution
ride|Waves RIDE evaluator/node|script version and complexity; blockchain context; deterministic value/transaction rules
rita|zaibacu rita-dsl Python compiler|pattern compilation; entity/match ordering; selected regex or NLP target behavior
robotframework|Robot Framework|keyword resolution; variables and scopes; library calls and pass/fail control
rsl|RAISE RSL tools|algebraic specification and types; partiality and proof obligations; executable subset versus specification-only clauses
sieve|Pigeonhole Sieve interpreter|extension capabilities; mail envelope versus headers; action conflicts and delivery effects
snowball|Snowball compiler and chosen generated target|backward/forward string matching; among/substring; Unicode and stemming fixtures
solidity|Solidity compiler and EVM host|compiler/EVM revision; storage layout; gas/revert and external call semantics
sophia|Aeternity Sophia compiler and FATE host|contract types/state; call/revert semantics; gas and chain context
sp|SourcePawn compiler plus SourceMod host|cell/tag rules; handles; game-plugin callback and native APIs
supercollider|sclang and scsynth|language scheduling; synth graph/rates; OSC and audio device/server behavior
tact|Tact compiler and TON emulator|messages and storage; generated FunC/TVM; gas/serialization and actor ordering
tads3|TADS 3 compiler and VM|object/property dispatch; parser library; story I/O and VM behavior
ti|ThingsDB query/script engine|collection and thing identity; closures and stored procedures; change/event and cluster behavior
trafficscript|authorized Ivanti/Pulse TrafficScript host|request/response stage; connection state; traffic-manager built-ins
vgl|authorized Thermo Scientific SampleManager VGL host|LIMS object and database model; procedure/control semantics; vendor API and workflow effects
vyper|Vyper compiler and EVM host|version-specific type/storage rules; bounded loops; external calls/reverts and gas
zeek|Zeek interpreter|event scheduling; protocol/packet types; network state, policy and logs
ng2|Angular template compiler and browser/SSR host|Angular version; binding/change detection; directives and DOM/event context
aspx-cs|ASP.NET Framework with CSharp on authorized compatible host|page lifecycle; CSharp code-behind; HTTP/session and server controls
aspx-vb|ASP.NET Framework with Visual Basic on authorized compatible host|page lifecycle; VB code-behind; HTTP/session and server controls
cfs|Lucee or Adobe ColdFusion CFScript|CFML engine/dialect; scopes/coercions; database/web effects
cfc|Lucee or Adobe ColdFusion component host|component inheritance and access; CFML scopes; serialization and remote calls
cfm|Lucee or Adobe ColdFusion page host|tag/script integration; variable scope; HTTP/database output effects
css+lasso|Lasso engine plus CSS parser|template escape context; generated stylesheet; Lasso runtime/coercions
css+mozpreproc|Mozilla preprocessor plus CSS parser|directive expansion; CSS tokens; generated stylesheet equivalence
css+myghty|Myghty plus historical Python and CSS parser|component calls; escaping/context; generated CSS and Python version
duel|DUEL compiler plus Java/JavaScript hosts|view/code split; data binding; client/server rendering correspondence
evoque|Evoque template engine on compatible Python|template scoping; quoting/escaping; includes and Python host behavior
gst|Gosu template engine and JVM|Gosu interpolation and directives; template parameters/scope; JVM-backed rendered output and escaping
haml|Haml Ruby engine|indentation and filters; interpolation escaping; Ruby code and HTML output
html+ng2|Angular compiler and browser/SSR host|HTML parse boundaries; binding/type checking; DOM and hydration effects
html+evoque|Evoque plus HTML processing|HTML escape context; template scoping; include and rendering behavior
html+lasso|Lasso plus HTML processing|embedded code boundaries; request scopes; HTML escaping and rendering
html+myghty|Myghty plus historical Python and HTML processing|component/argument rules; HTML escaping; Python host state
i6t|Inform 6 template preprocessor and Inform 7 toolchain|template directives; insertion order; generated story VM semantics
jsp|Apache Tomcat/Jasper and Java|page translation lifecycle; expression language; request/session and tag libraries
javascript+lasso|Lasso plus JavaScript host|string/code escaping; server evaluation; generated JS execution
javascript+mozpreproc|Mozilla preprocessor plus JavaScript host|directive environment; JS token boundaries; generated execution
javascript+myghty|Myghty plus JavaScript host|template scoping; JavaScript escaping; generated execution
lasso|Lasso runtime|tag versus modern syntax; type/coercion rules; request/database APIs
mask|MaskJS compiler and JavaScript/DOM host|template component scopes; expression binding; render and event behavior
mason|HTML::Mason or Mason 2 separately|component inheritance; request/subrequest scope; Perl interpolation and escaping
myghty|Myghty with compatible Python|component dispatch; argument scope and caching; web request effects
ssp|Scalate SSP engine and Scala|template-to-Scala lowering; binding scope; HTML escaping and servlet behavior
scaml|Scalate Scaml and Scala|indentation and filters; generated Scala; HTML escaping and attributes
slim|Slim Ruby engine|indentation/attribute grammar; embedded Ruby; escaping and output
vue|Vue compiler and browser/SSR host|Vue 2/3 identity; reactivity/lifecycle; SFC script/style/template boundaries
xml+evoque|Evoque plus XML parser|well-formedness and namespaces; entity/attribute escaping; template output
xml+lasso|Lasso plus XML parser|embedded evaluation; XML namespace/escaping; generated well-formed document
xml+myghty|Myghty plus XML parser|component evaluation; XML namespace/escaping; generated document
xul+mozpreproc|Mozilla preprocessor and versioned XUL host|preprocessor environment; XUL element model; obsolete platform APIs
apacheconf|Apache httpd configuration checker and test server|directive context/merge; module set; request routing and permissions
augeas|Augeas augtool and lens compiler|lens bidirectionality; tree paths; file roundtrip and error contracts
basemake|POSIX make subset with selected GNU/BSD host|base rules versus preprocessing extensions; dependency/recipe execution; filesystem timestamps and errors
blueprint|GNOME Blueprint compiler|UI widget/type references; XML UI lowering; GTK version
cfengine3|CFEngine Community|promise evaluation; classes/variables; idempotent managed-state convergence
crmsh|crmsh with Pacemaker test cluster|CIB schema; resource/constraint meaning; cluster quorum and side effects
devicetree|Device Tree Compiler plus target binding schemas|cell sizes/phandles; overlays; binding validation and device ABI
docker|Dockerfile frontend and authorized container host|build stages/context; cache semantics; runtime/image and filesystem effects
dylan-lid|Open Dylan library builder|build descriptor keys; library/module resolution; native link outputs
haxeml|Haxe compiler HXML input|flag accumulation; target and defines; build/run semantics
jcl|IBM z/OS JES host or qualified emulator|job/step expansion; DD datasets; return codes and mainframe resources
kconfig|Linux Kconfig conf tool|tristate/select/dependencies; defaults/visibility; resulting configuration
ldapconf|OpenLDAP client configuration host|option precedence; URI/TLS rules; directory lookup behavior
lighttpd|lighttpd configuration checker and test server|condition scopes; module/directive merging; request routing
nixos|Nix evaluator and NixOS module system|lazy attrsets; module merge priorities; derivation/build and activation effects
nsis|NSIS compiler and compatible Windows execution host|installer variables and stack; plugins; filesystem/registry and uninstall behavior
pacmanconf|pacman parser in isolated root|repository/option precedence; signature policy; package database effects
pan|Quattor Pan compiler|template inclusion; typed paths; configuration tree generation
puppet|Puppet parser/catalog compiler and isolated agent|resource graph; Hiera/functions; idempotent state and provider behavior
registry|Windows reg import/parser in isolated hive|registry types/encoding; path/deletion rules; 32/64-bit view effects
resourcebundle|ICU genrb/derb and ResourceBundle API|ICU typed resource syntax; locale/alias fallback; binary bundle generation and lookup
roboconf-graph|Roboconf model parser|component/facet inheritance; runtime imports; deployment dependency graph
roboconf-instances|Roboconf instance parser|instance hierarchy; graph conformance; deployment lifecycle/state
spec|RPM rpmspec/rpmbuild in isolated root|macro expansion; conditionals; build sections/package metadata
singularity|Apptainer definition builder on authorized host|section ordering; bootstrap source; filesystem and container execution
slurm|Slurm sbatch parser plus chosen shell and isolated scheduler|SBATCH directive parsing; shell-script execution; job resources, environment and scheduler effects
androidbp|Android Soong|module/property typing; dependency variants; generated build graph and Android tree
squidconf|Squid parser and isolated proxy|ACL order; directive context; proxy/cache/network request behavior
srcinfo|makepkg metadata generator/checker|package/base split; architecture fields; PKGBUILD metadata consistency
termcap|ncurses termcap parser|escape/capability syntax; inheritance; terminal expansion behavior
terminfo|ncurses tic/infocmp/tparm|binary format; parameter stack; capability expansion and terminal behavior
unixconfig|passwd/group/shadow-compatible parser and isolated NSS fixture|colon-separated record identity; empty/special fields and permissions; lookup semantics without touching live account files
vcl|Varnish compiler and isolated cache|VCL version; subroutine return actions; HTTP/cache/backend state
vclsnippets|Varnish complete program harness|snippet context; variable availability; compiled full VCL request behavior
wowtoc|World of Warcraft addon manifest host|client version; metadata/dependencies; file load order and addon environment
xorg.conf|Xorg parser with virtual display|section references; driver/options; server input/display behavior
apl|GNU APL or Dyalog separately|array rank/shape; origin/tolerance; dialect primitives and nested arrays
bqn|CBQN|array rank/fill; modifiers and trains; numeric/Unicode and system functions
bugs|OpenBUGS or WinBUGS separately|stochastic graph construction; distributions; sampler settings and convergence
dax|Power BI/Analysis Services DAX host|row/filter context; relationships; blank and aggregation semantics
freefem|FreeFEM|finite element spaces; variational assembly; solver tolerance and mesh behavior
idl|NV5 IDL versus GDL compatibility|array indexing/order; numeric promotion; graphics and proprietary routines
igor|authorized Igor Pro host|wave data/types; operation/function distinction; analysis and graph state
j|Jsoftware J engine|rank/agreement; trains/modifiers; numeric precision and locales
jags|JAGS|BUGS dialect; distribution parametrization; MCMC adaptation and stochastic evidence
julia|Julia distribution|multiple dispatch; type/array semantics; tasks and native library ABI
k|Kona K3 versus commercial K separately|K dialect; atomic extension; adverb and dictionary semantics
macaulay2|Macaulay2|ring/type identity; polynomial algorithms; exact algebra and external packages
maple|authorized Maple host|symbolic evaluation levels; assumptions; numeric and package behavior
mathematica|Wolfram Engine or Mathematica authorized host|held/evaluated expressions; rewrite ordering; exact/symbolic and numeric kernels
matlab|authorized MATLAB host|column-major indexing; array expansion; toolbox and numeric behavior
mupad|authorized historical MuPAD host|symbolic domain dispatch; assumptions; version and MATLAB embedding
ncl|NCAR Command Language|missing values; array metadata; NetCDF/graphics and numeric behavior
octave|GNU Octave|MATLAB compatibility boundaries; arrays/indexing; numeric libraries and packages
q|authorized kdb+ q host|typed nulls/infinities; table/query semantics; temporal and IPC behavior
sas|authorized SAS host|DATA step program data vector; missing values; procedures and dataset formats
scilab|Scilab|matrix indexing and types; polynomial/state-space objects; numerics and toolbox ABI
stan|stanc3 plus CmdStan|constraint transforms; log density/autodiff; sampling diagnostics and RNG versions
stata|authorized Stata host|dataset/missing-value rules; command state; estimation and licensed procedures
applescript|macOS osascript host|application dictionaries; object specifiers; Apple events and permissions
autohotkey|AutoHotkey v1/v2 separately on Windows|syntax/version split; hotkey and GUI event loop; Windows APIs
autoit|AutoIt on Windows|Variant coercions; GUI/COM and process automation; exact Windows runtime
batch|Windows cmd.exe|percent/delayed expansion; quoting and errorlevel; filesystem/process effects
execline|skarnet execline tools|argv transformation; environment scoping; Unix process/exit semantics
powershell|PowerShell 7 versus Windows PowerShell separately|object pipelines; scope/coercion; .NET cmdlets and platform effects
teratermmacro|Tera Term TTL on Windows|command parsing; variable types; terminal/session I/O and timeouts
arduino|arduino-cli and selected board toolchain|board/core identity; setup/loop timing; pin/peripheral libraries and device ABI
carbon|Carbon explorer/toolchain|experimental revision; generics and value categories; C++ interoperability
chapel|Chapel compiler|locale and task semantics; array domains; distributed runtime and reductions
charmci|Charm++ charmxi and C++|interface messages; entry methods; migration and distributed object ordering
clay|Clay compiler pinned historical LLVM|overload/static evaluation; value and reference rules; LLVM/ABI compatibility
ec|Ecere SDK eC compiler|class/property semantics; reflection; C ABI and framework effects
felix|Felix compiler with C++|typed control flow; coroutines; generated C++ and native FFI
hare|Hare toolchain|tagged unions and slices; allocation/errors; Unix ABI and target support
limbo|Inferno Limbo compiler and Dis VM|channels/processes; module loading; Dis representation and Styx host
logos|Theos Logos preprocessor and Objective-C toolchain|hook expansion; runtime method dispatch; Apple platform/jailbreak dependencies
modula2|GNU Modula-2 or exact PIM/ISO compiler|PIM versus ISO; module/type checking; sets/ranges/exceptions and ABI
mojo|Mojo SDK with authorized platform|release-evolving syntax; ownership/lifetimes; Python interoperability and accelerator host
nesc|nesC compiler and TinyOS target|component wiring; async/atomic and race analysis; MCU runtime and hardware
nimrod|historical Nimrod versus renamed Nim toolchain|rename/version grammar; macros and templates; memory management and C backend
odin|Odin compiler|context/allocator semantics; arrays/slices; explicit ownership and native ABI
ooc|rock ooc compiler and C toolchain|cover/class types; generics; generated C and runtime ownership
parasail|ParaSail compiler|pointer-free ownership; implicit parallel evaluation; contracts and runtime scheduling
pony|Pony compiler|reference capabilities; actor isolation; message ordering and garbage collection
swift|Swift compiler|ownership/value semantics; async actor isolation; standard library and platform ABI
vala|Vala compiler with GLib|ownership/refcount annotations; signals/async; generated C and GObject ABI
whiley|Whiley compiler and verifier|flow-sensitive types; contracts; verification conditions and executable backend
zig|Zig compiler|comptime; pointer/allocator/error unions; target ABI and safety mode
aspectj|AspectJ compiler and JVM|joinpoint/pointcut matching; advice precedence; weaving and bytecode effects
ceylon|Ceylon toolchain with compatible JVM|union/intersection types; module resolution; JVM/JS backend semantics
fan|Fantom SDK|nullable types and mixins; pods; JVM/CLR/JS backend distinction
golo|Golo JVM compiler|dynamic invocation; closures; JVM type/library interoperation
gosu|Gosu compiler and JVM|enhancements and type loaders; properties; Java interoperability
sarl|SARL compiler and SRE|agent/event/capacity semantics; scheduling; generated Java and SRE version
x10|X10 compiler plus native/JVM runtime|places and activities; finish/async/at; distributed memory and atomics
xtend|Eclipse Xtend and Java|active annotations; extension methods; Java lowering and runtime library
boo|Boo compiler and compatible CLR|duck/static typing; macros; CLR assemblies and exception behavior
nemerle|Nemerle compiler and compatible CLR|macro expansion; type inference; CLR lowering and legacy runtime
vb.net|Roslyn Visual Basic and .NET|Option Strict/Infer/Compare; late binding; CLR exceptions/events and libraries
bst|BibTeX style interpreter|stack primitives; bibliography sorting; entry/global state and output formatting
trac-wiki|Trac wiki renderer|macro/plugin set; link resolution; HTML sanitization and rendering
rd|R tools::parse_Rd and Rd2HTML|Rd macros and conditional sections; escaping and embedded R; documentation render/check contract
tid|TiddlyWiki host|tiddler field and wikitext syntax; transclusion/widgets; store and browser effects
todotxt|todo.txt parser and CLI profile|date/priority/project/context rules; stable rewrite; task ordering and extensions
typoscript|TYPO3 host|configuration tree and object evaluation; conditions/includes; frontend rendering state
typoscriptcssdata|TYPO3 with CSS embedding|TypoScript context; CSS boundary/escaping; generated stylesheet
typoscripthtmldata|TYPO3 with HTML embedding|TypoScript context; HTML boundary/escaping; generated markup
usd|OpenUSD tools|layer composition and paths; schema metadata; time samples and scene interoperability
ca65|cc65 ca65 assembler and target emulator|CPU dialect/addressing; relocations; linked machine behavior
dasm16|DCPU-16 assembler and emulator|ISA revision; instruction/operand encoding; word wrap and device interrupts
jasmin|Jasmin assembler plus JVM|classfile version; stack/local verification; JVM instruction and exception behavior
llvm-mir|LLVM llc matching MIR release|YAML/MIR dialect; register/liveness invariants; target instruction selection
llvm-mir-body|LLVM MIR containing-program harness|body scope/register declarations; CFG and target ops; machine verifier
mips|GNU binutils or LLVM and QEMU MIPS|ISA/endian/ABI; delay slots; relocation and system-call environment
ptx|NVIDIA ptxas plus compatible CUDA GPU|PTX/SM version; address spaces; atomics, barriers and device behavior
smali|smali/baksmali and Android ART host|DEX revision; register verification; Android runtime methods and exceptions
tal|Uxntal assembler and Uxn VM if identity confirmed|TAL dialect; opcode stack effects; device ports and virtual machine
tasm|Borland Turbo Assembler authorized legacy host|MASM/Ideal modes; CPU/object format; DOS/Windows execution host
cirru|Cirru parser plus chosen evaluator|tree syntax versus evaluator identity; indentation; data/semantic host contract
clojurescript|ClojureScript compiler and JavaScript host|persistent values; macros and protocols; JS interop and async semantics
cpsa|CPSA analyzer|strand algebra; penetrator assumptions; shape analysis and protocol claims
emacs-lisp|Emacs batch|dynamic/lexical binding; buffer/current state; reader and host primitives
janet|Janet interpreter|mutable/immutable data; fibers; macro expansion and C embedding
newlisp|newLISP interpreter|context/value model; destructive list operations; native/library boundary
shen|Shen implementation and selected host|sequent calculus types; pattern rules; Klambda lowering and host semantics
extempore|Extempore runtime and LLVM|Scheme versus xtlang boundary; temporal scheduling; native/audio bindings
codeql|CodeQL CLI and language extractor|database schema; relational fixpoints; library and extraction provenance
cypher|Neo4j or openCypher host|dialect/revision; graph/path matching; null/order and transaction behavior
ecl|HPCC ECL compiler and cluster host|lazy dataset transformations; distribution; record layouts and cluster actions
gooddata-cl|GoodData CloudConnect/CL identity to audit|catalog dialect; dimensional/metric model; service query and license host
googlesql|BigQuery GoogleSQL or ZetaSQL reference engine|service versus core dialect; null/types; aggregation/time and remote features
gsql|TigerGraph GSQL host|graph schema; accumulators; parallel traversal and service behavior
jslt|JSLT Java implementation|JSON transformations; null/missing; function and extension behavior
juttle|Juttle runtime and adapters|stream time windows; reducer semantics; external adapter behavior
kql|Kusto Query Language engine or Kusto emulator|tabular pipeline and scalar semantics; schema/types and nulls; time windows, joins and engine limits
maql|GoodData MAQL host|metric context; dimensional aggregation; null and service semantics
mql|MetaTrader MQL4/MQL5 compiler and strategy tester separately|MQL4 versus MQL5; event model; trading host and numeric behavior
mysql|MySQL server isolated database|SQL mode and release; collation/null/transactions; stored routines and protocol
pig|Apache Pig and compatible Hadoop/local host|bag/tuple/null semantics; logical plan; UDF and distributed execution
plpgsql|PostgreSQL PL/pgSQL engine|function/procedure version; exceptions and transactions; SQL plan and record state
postgresql|PostgreSQL isolated database|SQL release/extensions; MVCC/isolation; types/collation and optimizer-visible effects
promql|Prometheus engine|instant/range vectors; staleness/lookback; label matching and time-series evaluation
prql|PRQL compiler plus chosen SQL engine|relational pipeline lowering; null/order; generated dialect and database semantics
qlik|Qlik script/engine authorized host|load/association model; set analysis; dual values and aggregation context
rql|Logilab Relation Query Language and CubicWeb host|entity/relation schema; variable binding and existential queries; permission-aware result and query translation
tsql|SQL Server or qualified Azure SQL host|TSQL release; collation/types; transaction/error and stored procedure behavior
factor|Factor distribution|stack effect inference; combinators; vocabulary/image and native FFI
fift|TON Fift interpreter|stack and dictionary words; cell/builder/slice values; TVM serialization and libraries
forth|Gforth or chosen Forth standard host|cell and division model; dictionary/immediate words; stacks, I/O and memory
gleam|Gleam with Erlang or JavaScript backend|typed immutable values; BEAM/JS differences; runtime libraries and interoperation
'''

# Executable names are probes only. A hit does not establish dialect compatibility
# or successful native execution. Reusing an installed tool's file hash is pure
# inventory sharing, not evidence that another language has been implemented.
PROBES = r'''
antlr-actionscript antlr-csharp antlr-cpp antlr-objc antlr-perl antlr-python antlr-ruby|java antlr4 antlr3
adl cadl|adl2_validator
bare|bare
bnf peg|pest pegjs
camkes|camkes
capdl|parse-capDL
cddl|cddl
jsgf|sphinx_jsgf2fsg
mxml actionscript actionscript3|mxmlc asc
omg-idl|omniidl tao_idl
pddl|fast-downward validate
ragel-d|ragel ldc2 dmd
smithy|smithy
swig|swig
tablegen|llvm-tblgen
tlb fift func tact|fift func tact
treetop|tt ruby
webidl|webidl2
agda literate-agda|agda ghc
clean|clm
cryptol literate-cryptol|cryptol
elm|elm
fsharp|dotnet fsharpc
fstar|fstar.exe z3
futhark|futhark
idris literate-idris|idris idris2
koka|koka
opa|opa
reasonml|refmt ocamlc
aheui|aheui
befunge|cfunge
redcode|pmars
alloy|alloy java
bdd|behave cucumber
boogie|boogie z3
cplint logtalk|swipl logtalk
elpi|elpi
hspec|ghc runhaskell
isabelle|isabelle
lean|lean
lean4|lean lake
nusmv|NuSMV nuXmv
rego|opa
coq|coqc rocq
silver|silicon carbon
verifpal|verifpal
amdgpu hsail|llvm-mc llc
cuda ptx|nvcc ptxas nvidia-smi
glsl|glslangValidator
hlsl|dxc
modelica|omc
spice|ngspice
wgsl|tint naga
ampl|ampl
asymptote|asy
csound csound-document csound-score|csound
inform6|inform6
inform7 i6t|inform7 ni
lilypond|lilypond
mcfunction|java
moocode|moo
mscgen|mscgen
openscad|openscad
pov|povray
praat|praat
qml|qml qmlscene
robotframework|robot
sieve|sievec sieve-test
snowball|snowball
solidity|solc
sophia|aesophia_cli
sp|spcomp
supercollider|sclang scsynth
tads3|t3make frob
ti|thingsdb
vyper|vyper
zeek|zeek
ng2 html+ng2|ng node
aspx-cs aspx-vb|dotnet mono
cfs cfc cfm|lucee java
duel|java node
gst gosu|gosu java
haml|haml ruby
jsp|java catalina.sh
mask|mask node
mason|perl mason
myghty css+myghty html+myghty javascript+myghty xml+myghty|python2 python
ssp scaml|scala java
slim|slimrb ruby
vue|vue node
apacheconf|apache2 httpd
augeas|augtool augparse
basemake|make bmake
blueprint|blueprint-compiler
cfengine3|cf-promises cf-agent
crmsh|crm
devicetree|dtc
docker|docker podman
dylan dylan-lid|dylan-compiler
haxeml|haxe
jcl|hercules
kconfig|conf
ldapconf|ldapsearch
lighttpd|lighttpd
nixos|nix nix-instantiate
nsis|makensis
pacmanconf|pacman-conf
pan|panc
puppet|puppet
registry batch vbscript|wine cmd.exe cscript.exe
resourcebundle|genrb derb
spec|rpmspec rpmbuild
singularity|apptainer singularity
slurm|sbatch bash
androidbp|soong_build
squidconf|squid
srcinfo|makepkg
termcap terminfo|tic infocmp
vcl vclsnippets|varnishd varnishtest
xorg.conf|Xorg Xvfb
apl|apl
bqn|bqn cbqn
freefem|FreeFem++
idl|gdl idl
j|ijconsole jconsole
jags|jags
julia|julia
k|k kona
macaulay2|M2
maple|maple
mathematica|wolframscript math
matlab|matlab
ncl|ncl
octave|octave-cli octave
q|q
sas|sas
scilab|scilab-cli
stan|stanc
stata|stata stata-se stata-mp
applescript|osascript
autohotkey|AutoHotkey.exe wine
autoit|AutoIt3.exe wine
execline|execlineb
powershell|pwsh powershell.exe
arduino|arduino-cli
carbon|carbon carbon-explorer
chapel|chpl
charmci|charmxi charmc
clay|clay
ec|ecc
felix|flx
hare|hare
limbo|limbo emu
logos|logos.pl clang
modula2|gm2
mojo|mojo
nesc|nescc
nimrod|nim nimrod
odin|odin
ooc|rock
parasail|parasail_main
pony|ponyc
swift|swift swiftc
vala|valac
whiley|wyc
zig|zig
aspectj|ajc java
ceylon|ceylon
fan|fan
golo|golo
sarl|sarlc
x10|x10c x10c++
xtend|java
boo|booc
nemerle|ncc
vb.net|dotnet vbnc
bst|bibtex
trac-wiki|trac-admin
rd|R Rscript
tid|tiddlywiki node
usd|usdcat usdchecker
ca65|ca65 ld65
dasm16|dcpu16
jasmin|jasmin java
llvm-mir llvm-mir-body|llc
mips|mips-linux-gnu-as qemu-mips
smali|smali dalvikvm
tal|uxnasm uxncli
tasm|tasm dosbox
cirru|cirru
clojurescript|clojure node
cpsa|cpsa
emacs-lisp|emacs
janet|janet
newlisp|newlisp
shen|shen
extempore|extempore
codeql|codeql
cypher|cypher-shell neo4j
ecl|eclcc
googlesql|bq
gsql|gsql
jslt|java
juttle|juttle
kql|Kusto.Cli
mysql|mysql mariadb
pig|pig
plpgsql postgresql|psql postgres
promql|promtool prometheus
prql|prqlc
rql|cubicweb-ctl
tsql|sqlcmd
factor|factor
forth|gforth
gleam|gleam erl node
bbcbasic|brandy bbcsdl
blitzmax|bmk
cbmbas|x64sc x64
eiffel|gec ec
ezhil|ezhil
qbasic|qb64
arturo|arturo
berry|berry
chaiscript|chai
croc minid|croc
dart|dart
earl-grey|eg node
fancy|fancy rbx
gdscript|godot godot4
icon ucode|icont iconx
io|io
ioke|ioke
kal|kal node
lsl|opensim
luau|luau luau-analyze
miniscript|miniscript
monkey|transcc
moonscript|moonc lua
nit|nitc
numba_ir|python
objective-j|objj node
pawn|pawncc
phix|p p64
python2|python2 python2.7
rebol|rebol r3
red|red
savi|savi
smalltalk|gst squeak pharo
snobol|snobol4
tea|java
teal|goal tealdbg
urbiscript|urbi
wren|wren
zephir|zephir php
'''

IDENTITY_CORRECTIONS = {
    'xpp': 'Catalog lexer XppLexer identifies Microsoft X++; Xbase++ is a different language.',
    'teal': 'Catalog TealLexer identifies Algorand TEAL; the typed-Lua project Teal is a different language.',
    'ucode': 'Catalog UcodeLexer identifies Icon ucode; OpenWrt ucode is a different language.',
    'cadl': 'Catalog CadlLexer identifies openEHR constraint ADL; historical TypeSpec/Cadl is a different language.',
    'tlb': 'Catalog TlbLexer identifies TON TL-B; COM type libraries are a different format.',
    'bdd': 'Catalog BddLexer identifies behavior-driven development scenarios; binary decision diagrams are a different subject.',
    'ti': 'Catalog ThingsDBLexer identifies ThingsDB; TI calculator BASIC is a different language.',
    'rd': 'Catalog RdLexer identifies R documentation; Ruby RDTool is a different format.',
    'gst': 'Catalog GosuTemplateLexer identifies Gosu templates; Genshi text templates are a different language.',
    'resourcebundle': 'Catalog ResourceLexer identifies ICU resource bundles; Java properties are a different format.',
    'silver': 'Catalog SilverLexer and upstream URL identify Viper Silver; the Silver attribute grammar language is separate.',
    'mql': 'Catalog MqlLexer identifies MetaTrader MQL4/MQL5; the historical isocpp.org reference is unrelated and must be replaced.',
}

CORRECT_REFERENCE_CANDIDATES = {
    'mql': ['https://www.mql5.com/en/docs', 'https://docs.mql4.com/'],
    'teal': ['https://developer.algorand.org/docs/get-details/dapps/avm/teal/'],
    'ti': ['https://docs.thingsdb.io/'],
    'tlb': ['https://docs.ton.org/v3/documentation/data-formats/tlb/overview'],
    'xpp': ['https://learn.microsoft.com/en-us/dynamics365/fin-ops-core/dev-itpro/dev-ref/xpp-language-reference'],
}


def probe_names():
    result = {}
    for line in PROBES.strip().splitlines():
        ids, executables = line.split('|')
        for identifier in ids.split():
            if identifier in result:
                raise ValueError('Duplicate tool probe: ' + identifier)
            result[identifier] = executables.split()
    return result


def tool_inventory(names):
    result = {}
    for name in sorted(names):
        found = shutil.which(name)
        item = {'executable_name': name, 'found_on_PATH': bool(found), 'native_compatibility_qualified': False}
        if found:
            path = Path(found).resolve()
            item.update({'path': found, 'resolved_path': str(path), 'sha256': file_sha(path), 'bytes': path.stat().st_size})
            if name == 'factor':
                item['identity_warning'] = 'GNU coreutils factor is not the Factor language VM; inspect provider identity before use'
            if name == 'jconsole':
                item['identity_warning'] = 'JDK jconsole is not the J language console; inspect provider identity before use'
        result[name] = item
    return result


def encode(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def digest(value):
    return hashlib.sha256(encode(value)).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_bytes(encode(value) + b'\n')


def candidate_table():
    result = {}
    for line in CANDIDATES.strip().splitlines():
        identifier, host, focus = line.split('|')
        if identifier in result:
            raise ValueError('Duplicate authored candidate: ' + identifier)
        result[identifier] = {'upstream_host_candidate': host, 'semantic_focus': focus.split('; '),
                              'candidate_is_qualified': False}
    return result


def category(entry):
    if entry['catalog_id'] in {'bdd', 'robotframework'}:
        return 'proof_or_analysis'
    if entry['catalog_id'] in {'floscript'}:
        return 'configuration_or_build'
    if entry['catalog_id'] in {'mql', 'teal', 'ucode', 'ti'}:
        return 'source_program'
    family = entry['family']
    if family == 'Grammars, interfaces and schemas':
        return 'grammar_schema_or_interface'
    if family == 'Templates and composite sources':
        return 'composite_template'
    if family == 'Configuration, build and deployment':
        return 'configuration_or_build'
    if family == 'Markup, documents and styles':
        return 'document_processing'
    if family == 'SQL and query languages':
        return 'query'
    if family == 'Logic, proof and verification':
        return 'proof_or_analysis'
    if family == 'HDL, shaders and compute':
        return 'device_or_simulation'
    if family == 'Assembly and intermediate representations':
        return 'assembly_or_ir'
    return 'source_program'


CATEGORY_CONTRACTS = {
    'grammar_schema_or_interface': [
        'Reject invalid grammars/schemas using independently authored negative cases',
        'Compare accepted/rejected messages and parse/model structures, not only tool exit status',
        'Run generated target code with matching target runtime; retain recovery, encoding and ABI behavior'],
    'composite_template': [
        'Check host-language boundaries, includes, scope and escaping in every output context',
        'Run native rendering and compare parsed output plus observable host effects',
        'Type/check and execute generated embedded code with the exact embedded runtime'],
    'configuration_or_build': [
        'Check invalid directives, includes, precedence and dependency resolution with native checker',
        'Execute isolated configuration/build and compare resulting graph, state and diagnostics',
        'Check idempotence and declared filesystem/process/network effects with controlled fixtures'],
    'document_processing': [
        'Check invalid syntax, encoding, escaping, names and format-specific semantics',
        'Compare native parse/render/roundtrip result under an explicitly declared equivalence contract',
        'Separate byte-preserving requirements from structural or tolerance-based output requirements'],
    'query': [
        'Pin schema, collation, timezone, null/missing values and transaction/isolation settings',
        'Compare native/generated result multisets, declared ordering, errors and database effects',
        'Use independent fixtures with duplicates, empty relations, nulls and boundary values'],
    'proof_or_analysis': [
        'Separate parsing/elaboration from checking valid proofs or verification conditions',
        'Record trusted kernel, axioms, solver version, finite bounds and probabilistic assumptions',
        'Retain rejected proofs/countermodels; do not interpret bounded success as universal proof'],
    'device_or_simulation': [
        'Pin language/ISA revision, target device or simulator and execution configuration',
        'Compare outputs, state, ordering and numeric tolerances using independent kernels/models',
        'Keep compilation, simulation and real-device execution as distinct evidence gates'],
    'assembly_or_ir': [
        'Pin ISA/IR version, target triple, endian, object format and calling convention',
        'Compare encoding/verification, linked execution, state and observable traps',
        'Validate relocations, register/stack/memory invariants and ABI against native tools'],
    'source_program': [
        'Check binding, types, evaluation order, values, exceptions and resource behavior',
        'Run original/native and generated USL with independently authored intent contracts',
        'Include boundary/invalid cases, state/effects, libraries and ABI in the declared profile'],
}


def apply_receipts(entries, paths):
    rows = {entry['catalog_id']: dict(entry) for entry in entries}
    evidence = []
    for path in paths:
        receipt = json.loads(Path(path).read_text())
        identifier = receipt.get('catalog_id')
        if receipt.get('passed') is not True:
            raise ValueError('Unrecognized or failed scoped receipt: ' + str(path))
        if receipt.get('full_standard_qualified') is not False:
            raise ValueError('This ledger does not accept full-standard promotion')
        # A passed flag is not an execution receipt: validate the actual source,
        # independent case identities and native/generated outcomes first.
        if receipt.get('schema') == 'usl.brainfuck.scoped-semantic-validation.v1':
            from planner import apply_scoped_receipt
            base = json.loads((ROOT / 'inputs/catalog.json').read_text())
            validated = apply_scoped_receipt(base, path)
            qualified = [r for r in validated['entries'] if r['catalog_id'] == 'brainfuck']
        elif receipt.get('schema') == 'usl.forth.selected-stack-profile.v1':
            from qualification_ledger import validate_forth
            qualified = validate_forth(path)
        elif receipt.get('schema') == 'usl.antlr4.scoped-qualification.v1':
            from qualification_ledger import validate_antlr
            qualified = validate_antlr(path)
        else:
            raise ValueError('Unrecognized qualification schema; plain passed flags cannot promote scope')
        for profile in qualified:
            identifier = profile['catalog_id']
            if identifier not in rows: raise ValueError('Qualification ID not in exact catalog')
            rows[identifier]['scoped'] = True
            rows[identifier]['scope'] = profile['scope']
            rows[identifier]['scoped_receipt_sha256'] = file_sha(path)
            evidence.append({'catalog_id': identifier, 'path': str(path), 'sha256': file_sha(path)})
    return list(rows.values()), evidence


def check_complete(entries, candidates):
    ids = {entry['catalog_id'] for entry in entries}
    if len(entries) != 607 or len(ids) != 607 or sum(e['original_catalog'] for e in entries) != 606:
        raise ValueError('All 606 original IDs plus USL must remain present')
    missing = {e['catalog_id'] for e in entries if e['original_catalog'] and not e['scoped']}
    if missing - candidates.keys():
        raise ValueError('Missing distinct authored candidates: ' + ', '.join(sorted(missing - candidates.keys())))
    return missing


def route(task, policy):
    from usl_systems.language import Interpreter
    run = Interpreter(capabilities={'scope_inputs': lambda: task}, max_ops=1000, timeout=2).run(policy)
    decision = run.variables['decision']
    expected = {'reference_route': 'audit_version_and_clause_map' if task['reference_count'] else 'retrieve_exact_upstream_reference',
                'native_route': 'retain_external_host_and_prepare_offline_cases' if task['external_dependency'] else 'probe_candidate_then_pin_install',
                'track': 'expand_profile_and_full_conformance' if task['qualified_scope'] else 'implement_scoped_profile',
                'full_standard_qualified': False, 'planning_record_is_execution_evidence': False}
    if decision != expected:
        raise ValueError('USL scope decision disagrees with independent gate check')
    return decision, {'actual_USL_execution': True, 'operations': run.operations,
                      'policy_sha256': hashlib.sha256(policy.encode()).hexdigest(), 'independently_checked': True}


def verify_document(identity, obj, cache):
    if digest(obj) != identity:
        raise ValueError('Document object hash mismatch: ' + identity)
    path = Path(cache) / obj['body_sha256']
    # Published exports retain immutable identities even outside the private CAS.
    # Missing bodies remain an explicit retrieval task; never infer verified bytes.
    if not path.is_file():
        return {'document_object_sha256': identity, 'body_sha256': obj['body_sha256'],
                'body_available_and_hash_verified_now': False, 'reason': 'private CAS body unavailable'}
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            h.update(chunk)
    if h.hexdigest() != obj['body_sha256']:
        raise ValueError('Reference body hash mismatch: ' + str(path))
    return {'document_object_sha256': identity, 'body_sha256': obj['body_sha256'],
            'body_available_and_hash_verified_now': True, 'body_bytes': path.stat().st_size}


def select_sections(obj, focus):
    # This is search ranking of structural headings, never normative interpretation.
    terms = set(re.findall(r'[a-z]{4,}', ' '.join(focus).lower()))
    terms |= {'syntax', 'grammar', 'type', 'types', 'reference', 'semantics', 'language'}
    sections = obj.get('sections', [])
    ranked = sorted(sections, key=lambda s: (-len(terms & set(re.findall(r'[a-z]{4,}', s['heading'].lower()))), s['heading_ordinal']))
    return [{**section, 'url': obj['source_url'].split('#')[0] + section['locator'] if section['locator'].startswith('#') else obj['source_url'],
             'selection_is_structural_search_only': True} for section in ranked[:8]]


def next_command(identifier, references, prefix):
    # A real, safe and portable next diagnostic action. Native install/version
    # choices remain blocked on review; this does not execute documentation text.
    command = ['python', 'scope_all.py', '--source-root', str(prefix), '--inspect', identifier]
    return {'argv': command, 'purpose': 'Print the exact candidate, source locators, host gates and ID-specific implementation contracts',
            'network_reference_candidates': references, 'implements_language': False}


async def build(args):
    from semantic_records import resource_admission
    started = time.perf_counter()
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    paths = {'catalog': ROOT / 'inputs/catalog.json', 'records': ROOT / 'semantic-records-final/SEMANTIC_RECORDS.json',
             'documents': ROOT / 'semantic-records-final/DOCUMENT_OBJECTS.json',
             'syntax': ROOT / 'semantic-records-final/SYNTAX_OBJECTS.json', 'policy': ROOT / 'scope_all.usl',
             'pipeline': Path(__file__)}
    source_hashes = {name: file_sha(path) for name, path in paths.items()}
    entries, receipt_evidence = apply_receipts(json.loads(paths['catalog'].read_text())['entries'], args.scoped_receipt)
    candidates = candidate_table(); missing = check_complete(entries, candidates)
    probes = probe_names()
    tools = tool_inventory({name for names in probes.values() for name in names})
    write_json(output / 'TOOL_INVENTORY.json', {'kind': 'fresh_file_identity_and_PATH_observation_only',
               'execution_or_language_compatibility_claimed': False, 'tools': tools})
    tool_inventory_hash = file_sha(output / 'TOOL_INVENTORY.json')
    records = {row['catalog_id']: row for row in json.loads(paths['records'].read_text())['records']}
    if set(records) != {e['catalog_id'] for e in entries}:
        raise ValueError('Semantic-record IDs do not exactly match catalog IDs')
    documents = json.loads(paths['documents'].read_text())
    syntax = json.loads(paths['syntax'].read_text())
    for identity, obj in syntax.items():
        if digest(obj) != identity:
            raise ValueError('Syntax object hash mismatch')
    policy = paths['policy'].read_text()
    document_ids = {key for record in records.values() for key in record['document_objects']}
    admission = resource_admission(len(document_ids), output)
    thread_slots = admission['thread_slots']
    # asyncio creates all finite ID actors before admission. Only real CAS I/O is
    # admitted to threads. No batches or round-number actor limits are used.
    executor = ThreadPoolExecutor(max_workers=max(1, thread_slots))
    semaphore = asyncio.Semaphore(max(1, thread_slots))
    flight = {}; object_results = {}; active = 0; peak = 0
    loop = asyncio.get_running_loop()

    async def get_document(identity):
        nonlocal active, peak
        if identity not in flight:
            async def perform():
                nonlocal active, peak
                if not thread_slots:
                    return {'document_object_sha256': identity, 'body_sha256': documents[identity]['body_sha256'],
                            'body_available_and_hash_verified_now': False, 'reason': 'no admitted IO resources'}
                async with semaphore:
                    active += 1; peak = max(peak, active)
                    try:
                        answer = await loop.run_in_executor(executor, verify_document, identity, documents[identity], args.private_cache)
                        object_results[identity] = answer
                        return answer
                    finally:
                        active -= 1
            flight[identity] = asyncio.create_task(perform())
        return await flight[identity]

    start = asyncio.Event(); ready = 0; live = 0; peak_live = 0
    async def actor(entry):
        nonlocal ready, live, peak_live
        ready += 1; live += 1; peak_live = max(peak_live, live)
        if ready == len(entries): start.set()
        await start.wait()
        identifier = entry['catalog_id']; prior = records[identifier]
        proposal = candidates.get(identifier, {'upstream_host_candidate': entry['original_tool_requirement'] or 'Retain the exact native provider from the existing scoped receipt; re-audit full-profile dependencies',
                                                'semantic_focus': ['Extend existing scope: ' + entry['scope']], 'candidate_is_qualified': False})
        doc_receipts = await asyncio.gather(*(get_document(key) for key in prior['document_objects']))
        sources = []
        for key in prior['document_objects']:
            obj = documents[key]
            sources.append({'document_object_sha256': key, 'body_sha256': obj['body_sha256'],
                            'source_url': obj['source_url'], 'title': obj.get('title'),
                            'exact_version_and_authority_audited': False,
                            'selected_section_locators': select_sections(obj, proposal['semantic_focus']),
                            'additional_same_origin_link_candidates': obj.get('same_origin_links', [])[:6],
                            'all_sections_and_frontier_retained_in': 'semantic-records-final/DOCUMENT_OBJECTS.json'})
        refs = sorted({obs['reference_url'] for obs in prior['upstream_reference_observations']})
        correct_candidates = CORRECT_REFERENCE_CANDIDATES.get(identifier, [])
        task = {'full_gate_passed': False, 'reference_count': len(sources), 'external_dependency': bool(entry['external_dependencies']), 'qualified_scope': entry['scoped']}
        decision, usl_receipt = route(task, policy)
        kind = category(entry)
        syntax_refs = {kind_: {'object_sha256': key, 'provider': syntax[key].get('provider'), 'version': syntax[key].get('version'),
                              'class': syntax[key].get('class'), 'module': syntax[key].get('module'),
                              'structural_inventory_only': True} for kind_, key in prior['syntax_objects'].items()}
        blockers = [{'kind': 'exact_version_dialect_category_audit', 'resolved': False,
                     'reason': 'Candidates and structural headings have not been reviewed as a complete normative specification'},
                    {'kind': 'full_rule_implementation_and_conformance', 'resolved': False,
                     'reason': 'Per-clause semantics, native execution, libraries, ABI and independent intent evidence are still required'}]
        if not sources:
            blockers.append({'kind': 'reference_body_missing', 'resolved': False, 'candidate_urls': refs})
        if sources and not all(r['body_available_and_hash_verified_now'] for r in doc_receipts):
            blockers.append({'kind': 'reference_body_not_locally_available', 'resolved': False})
        blockers.extend({'kind': 'external_dependency', 'resolved': False, **dep} for dep in entry['external_dependencies'])
        plan = {'catalog_id': identifier, 'original_catalog': entry['original_catalog'], 'family': entry['family'],
                'category_proposal': kind, 'category_audit_complete': False,
                'existing_qualified_scope': entry['scoped'], 'existing_scope_description': entry['scope'],
                'scoped_receipt_sha256': entry.get('scoped_receipt_sha256'), 'remaining_unscoped_at_snapshot': identifier in missing,
                'planning_record_complete': True, 'normative_semantic_scope_complete': False, 'full_standard_qualified': False,
                'candidate': proposal,
                'catalog_identity_review_note': IDENTITY_CORRECTIONS.get(identifier),
                'additional_correct_reference_candidates_not_retrieved_by_this_run': correct_candidates,
                'version_identity': {'selected_normative_version': None, 'resolved': False,
                                     'candidate_document_titles': [s['title'] for s in sources if s['title']],
                                     'required_pin': ['language release/standard revision', 'dialect/extensions', 'target/host', 'standard library and native provider versions']},
                'source_documents': sources, 'reference_body_checks': doc_receipts,
                'syntax_inventory': syntax_refs,
                'host_plan': {'candidate': proposal['upstream_host_candidate'], 'installed_or_native_tested_by_this_scoping_run': False,
                              'original_requirement': entry['original_tool_requirement'], 'external_dependencies': entry['external_dependencies'],
                              'tool_probe_names': probes.get(identifier, []),
                              'tools_found_on_PATH': [name for name in probes.get(identifier, []) if tools[name]['found_on_PATH']],
                              'tool_inventory_sha256': tool_inventory_hash,
                              'tool_identity_hits_are_not_native_execution_evidence': True,
                              'additional_platform_or_license_review_required': any(word in proposal['upstream_host_candidate'].lower() for word in ['authorized', 'windows', 'macos', 'legacy', 'historical']),
                              'install_action': 'Review upstream identity, supported platform/license and provenance; probe existing binary; install a pinned public-compatible provider where available; otherwise retain exact external-host requirement'},
                'id_specific_work': [{'focus': focus, 'status': 'needs_normative_clause_audit_and_implementation',
                                      'acceptance': 'Author independent valid/invalid/boundary cases for ' + focus + '; compare native and generated results/effects; retain counterexamples'} for focus in proposal['semantic_focus']],
                'validation_contracts': CATEGORY_CONTRACTS[kind],
                'family_shared_artifact_key': digest({'family': entry['family'], 'category': kind, 'contracts': CATEGORY_CONTRACTS[kind]}),
                'id_specific_obligations_not_collapsed': ['exact dialect/version and authority', 'rule-to-implementation-to-test map', 'standard libraries and host APIs',
                    'ABI/platform/effects applicability', 'independent intent contract', 'upstream conformance/review'],
                'original_obligation_dimensions': entry['obligation_dimensions'],
                'original_ordered_steps': entry['ordered_steps'], 'blockers': blockers,
                'USL_decision': decision, 'USL_receipt': usl_receipt,
                'next_action': next_command(identifier, correct_candidates + refs, args.source_root),
                'source_evidence': {'catalog_entry_sha256': digest(entry), 'prior_semantic_record_sha256': digest(prior),
                                    'catalog_file_sha256': source_hashes['catalog'], 'record_file_sha256': source_hashes['records']}}
        live -= 1
        return plan

    try:
        rows = await asyncio.gather(*(actor(entry) for entry in entries))
    finally:
        executor.shutdown(wait=True)
    rows.sort(key=lambda row: row['catalog_id'])
    families = {}
    for row in rows:
        key = row['family_shared_artifact_key']
        families.setdefault(key, {'family': row['family'], 'category': row['category_proposal'],
                                   'shareable_work': CATEGORY_CONTRACTS[row['category_proposal']],
                                   'artifact_reuse_requires_exact_content_and_version_identity': True,
                                   'semantic_qualification_transferred_between_ids': False, 'catalog_ids': []})['catalog_ids'].append(row['catalog_id'])
    all_record = {'schema': 'usl.all-id-scoping-ledger.v1', 'interpretation': 'Actionable scoping proposals, not complete normative semantics or execution qualification',
                  'source_hashes': source_hashes, 'scoped_receipt_overlays': receipt_evidence, 'records': rows}
    write_json(output / 'ALL_IDS.json', all_record)
    write_json(output / 'FAMILY_SHARED_WORK.json', families)
    write_json(output / 'REFERENCE_BODY_CHECKS.json', object_results)
    remaining = [row for row in rows if row['remaining_unscoped_at_snapshot']]
    # IDs are referenced into the one all-ID ledger rather than duplicating all
    # large records. The hash binds this lossless join to the source artifact.
    write_json(output / 'REMAINING_IDS.json', {'catalog_ids': [r['catalog_id'] for r in remaining],
               'all_id_ledger': 'ALL_IDS.json', 'all_id_ledger_sha256': file_sha(output / 'ALL_IDS.json'),
               'every_ID_has_distinct_authored_candidate_and_focus': True})
    counts = collections.Counter(row['family'] for row in remaining)
    table = ['# All-ID scoping ledger', '',
             'Every remaining ID has a candidate host, specific semantic questions, source locators where available, native/intent contracts, and unresolved gates. These are implementation plans; exact normative rule sets and full-standard qualification remain open.', '',
             '| Family | Remaining IDs |', '|---|---:|']
    table.extend('| ' + family + ' | ' + str(count) + ' |' for family, count in sorted(counts.items()))
    table += ['', '| ID | Candidate host | Specific semantic work | References / parser |', '|---|---|---|---|']
    for row in remaining:
        cell = lambda text: str(text).replace('|', '\\|').replace('\n', ' ')
        table.append('| ' + ' | '.join([row['catalog_id'], cell(row['candidate']['upstream_host_candidate']), cell('; '.join(row['candidate']['semantic_focus'])),
                     str(len(row['source_documents'])) + ' docs / ' + ('yes' if 'parser' in row['syntax_inventory'] else 'no')]) + ' |')
    table += ['', 'Run `python scope_all.py --source-root /path/to/usl-base --inspect ID` for the complete per-ID contract and hash-linked evidence. No planning record promotes qualification. Native installs and language implementation remain distinct work.']
    (output / 'SCOPING_TABLE.md').write_text('\n'.join(table) + '\n')
    requests = sum(len(r['source_documents']) for r in rows)
    summary = {'passed': True, 'all_ids': len(rows), 'original_ids': sum(r['original_catalog'] for r in rows),
               'existing_qualified_original_scopes': sum(r['existing_qualified_scope'] and r['original_catalog'] for r in rows),
               'remaining_original_ids_with_distinct_plans': len(remaining), 'remaining_original_ids_without_plan': 0,
               'normative_semantic_scopes_completed_by_this_run': 0, 'new_native_qualifications': 0,
               'full_standards_qualified': 0, 'logical_actors_started_together': len(rows), 'peak_live_logical_actors': peak_live,
               'all_ID_USL_policy_executions': len(rows), 'all_policy_decisions_independently_checked': True,
               'fixed_rounds_or_worker_count_cap': False, 'actual_IO_resource_admission': admission,
               'peak_admitted_reference_IO_jobs': peak, 'reference_object_requests': requests,
               'distinct_reference_objects_singleflight': len(flight), 'pure_duplicate_reference_checks_avoided': requests - len(flight),
               'available_reference_bodies_freshly_hash_checked': sum(r['body_available_and_hash_verified_now'] for r in object_results.values()),
               'remaining_ids_with_reference_objects': sum(bool(r['source_documents']) for r in remaining),
               'remaining_ids_with_missing_reference_objects': sum(not r['source_documents'] for r in remaining),
               'remaining_ids_with_external_dependencies': sum(bool(r['host_plan']['external_dependencies']) for r in remaining),
               'remaining_ids_with_additional_platform_or_license_review': sum(r['host_plan']['additional_platform_or_license_review_required'] for r in remaining),
               'distinct_executable_names_probed': len(tools), 'executable_name_hits_on_PATH': sum(t['found_on_PATH'] for t in tools.values()),
               'catalog_identity_corrections_recorded': len(IDENTITY_CORRECTIONS),
               'family_contract_artifacts': len(families), 'all_original_obligation_dimensions_preserved': sum(len(r['original_obligation_dimensions']) for r in rows if r['original_catalog']),
               'source_unchanged_during_run': all(file_sha(paths[k]) == v for k, v in source_hashes.items()),
               'seconds': time.perf_counter() - started, 'project_completion_ETA_seconds': None,
               'ETA_reason': 'Scope-preparation duration does not estimate semantic implementation, host acquisition or qualification throughput'}
    write_json(output / 'SUMMARY.json', summary)
    write_json(output / 'MANIFEST.json', {p.name: {'sha256': file_sha(p), 'bytes': p.stat().st_size} for p in output.iterdir() if p.is_file() and p.name != 'MANIFEST.json'})
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=Path('/workspace/usl-v4.10.0-clean-test'))
    parser.add_argument('--output', type=Path, default=ROOT / 'scope-all-results')
    parser.add_argument('--private-cache', type=Path, default=PRIVATE_CACHE)
    parser.add_argument('--scoped-receipt', action='append', type=Path)
    parser.add_argument('--inspect', metavar='ID')
    args = parser.parse_args()
    sys.path.insert(0, str(args.source_root))
    if args.scoped_receipt is None:
        args.scoped_receipt = [ROOT / 'semantic-final/brainfuck/qualification.json']
    if args.inspect:
        records = json.loads((args.output / 'ALL_IDS.json').read_text())['records']
        matching = [row for row in records if row['catalog_id'] == args.inspect]
        if not matching:
            parser.error('Unknown ID: ' + args.inspect)
        print(json.dumps(matching[0], ensure_ascii=False, indent=2))
    else:
        print(json.dumps(asyncio.run(build(args)), sort_keys=True))


if __name__ == '__main__':
    main()
