"""Restore the exact public upstream compiler sources; no binaries are shipped."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parent


def restore(destination):
    manifest = json.loads((ROOT / 'inputs/ebfc_upstream.json').read_text())
    destination = Path(destination).resolve();destination.mkdir(parents=True, exist_ok=True)

    def one(row):
        path = destination / row['file']
        if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']:
            return
        with urllib.request.urlopen(row['url'], timeout=30) as response:
            body = response.read()
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('Upstream source identity mismatch: ' + row['file'])
        path.write_bytes(body)

    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(one, manifest['files']))
    subprocess.run(['make', '-j4', 'ebfc'], cwd=destination, check=True)
    print(json.dumps({'passed': True, 'compiler': str(destination / 'ebfc'), 'source_files_hash_verified': len(manifest['files']), 'commit': manifest['commit']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, default=Path('providers/ebfc'))
    args = parser.parse_args();restore(args.destination)
