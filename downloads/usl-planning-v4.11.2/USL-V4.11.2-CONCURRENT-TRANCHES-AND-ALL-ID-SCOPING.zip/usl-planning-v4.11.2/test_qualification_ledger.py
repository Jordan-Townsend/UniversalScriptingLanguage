import json
import shutil
from pathlib import Path
import tempfile
import unittest
from qualification_ledger import ROOT, join, validate_forth, validate_antlr


class LedgerTests(unittest.TestCase):
    def test_join_retains_every_id_and_historical_profile_category(self):
        with tempfile.TemporaryDirectory() as d:catalog=join(d)
        summary=catalog['summary']
        self.assertEqual((summary['original_scoped'],summary['original_without_scope']),(247,359))
        self.assertEqual((summary['code_expression_profiles'],summary['category_processing_profiles']),(84,163))
        self.assertEqual(len(catalog['entries']),607)
        self.assertTrue(all(r['full_standard_qualified'] is False for r in catalog['entries']))

    def test_forth_tampered_native_result_is_rejected(self):
        report=json.loads((ROOT/'forth-results/qualification.json').read_text())
        report['groups'][0]['records'][0]['native']=[123456]
        with tempfile.TemporaryDirectory() as d:
            shutil.copytree(ROOT/'forth-results/generated',Path(d)/'generated')
            path=Path(d)/'forged.json';path.write_text(json.dumps(report))
            with self.assertRaises(ValueError):validate_forth(path)

    def test_missing_native_or_stale_source_not_promoted(self):
        report=json.loads((ROOT/'forth-results/qualification.json').read_text())
        for broken in ['source','coverage']:
            value=json.loads(json.dumps(report))
            if broken=='source':value['source_sha256']['forth_semantics.py']='0'*64
            else:value['groups'].pop()
            with tempfile.TemporaryDirectory() as d:
                path=Path(d)/'forged.json';path.write_text(json.dumps(value))
                with self.subTest(broken=broken),self.assertRaises(ValueError):validate_forth(path)


if __name__=='__main__':unittest.main()
