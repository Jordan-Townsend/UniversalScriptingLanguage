import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

if not any(Path(p, 'usl_systems').is_dir() for p in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from semantic_records import SectionParser, public_https, read_object, route, validate_rows


class RecordTests(unittest.TestCase):
    def test_document_scripts_are_not_executed_or_semantics(self):
        parser = SectionParser('https://example.org/spec')
        parser.feed('<script>throw new Error("no")</script><h2 id="types">Types &amp; values</h2>')
        parser.close()
        parser.finish_heading()
        self.assertNotIn('throw', str(parser.sections))
        self.assertEqual(parser.sections[0]['heading'], 'Types & values')

    def test_managed_proxy_resolves_public_DNS_without_accepting_private_literals(self):
        with patch('semantic_records.urllib.request.getproxies', return_value={'https': 'http://proxy.example'}), patch('semantic_records.socket.getaddrinfo', side_effect=AssertionError('Direct DNS must not be required')):
            self.assertEqual(public_https('https://example.org/spec'), 'https://example.org/spec')
            with self.assertRaises(ValueError):
                public_https('https://127.0.0.1/spec')

    def test_corrupt_reference_CAS_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            key = hashlib.sha256(b'original').hexdigest()
            Path(directory, key).write_bytes(b'modified')
            with self.assertRaises(ValueError):
                read_object(directory, key)

    def test_syntax_or_documents_never_qualify_full_semantics(self):
        task = {'verified_document_count': 5, 'document_section_count': 100, 'prior_scope': True,
                'parser_available': True, 'lexer_available': True, 'external_dependency': False,
                'category_processing': False, 'normative_rules_audited': False, 'full_conformance_passed': False}
        decision, receipt = route(task)
        self.assertFalse(decision['full_semantic_record_complete'])
        self.assertFalse(decision['full_standard_qualified'])
        self.assertFalse(decision['execute_native_program_from_documentation'])
        self.assertTrue(receipt['actual_USL_execution'])

    def test_missing_ID_and_fake_qualification_are_rejected(self):
        with self.assertRaises(ValueError):
            validate_rows({'entries': []})
        task = {'normative_rules_audited': True, 'full_conformance_passed': True}
        with self.assertRaises(Exception):
            route(task)


if __name__ == '__main__':
    unittest.main()
