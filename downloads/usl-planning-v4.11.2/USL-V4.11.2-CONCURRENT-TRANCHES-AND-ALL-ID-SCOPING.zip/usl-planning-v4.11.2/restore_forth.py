"""Install signed-index/hash-pinned public Gforth packages in a local prefix."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent


def restore(destination):
    destination = Path(destination).resolve();destination.mkdir(parents=True, exist_ok=True)
    metadata = json.loads((ROOT / 'inputs/forth-debian.json').read_text())
    packages = metadata['packages']
    archives = destination / 'archives';archives.mkdir(exist_ok=True)

    def obtain(record):
        path = archives / Path(record['Filename']).name
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != record['SHA256']:
            url = 'https://deb.debian.org/debian/' + urllib.parse.quote(record['Filename'], safe='/+')
            with urllib.request.urlopen(url, timeout=30) as response:
                data = response.read()
            if len(data) != int(record['Size']) or hashlib.sha256(data).hexdigest() != record['SHA256']:
                raise ValueError('Package identity mismatch: ' + record['Package'])
            path.write_bytes(data)
        return path

    # One task per actually needed package, without a fixed-size download round.
    with ThreadPoolExecutor(max_workers=len(packages)) as pool:
        paths = list(pool.map(obtain, packages))
    for path in paths:
        subprocess.run(['dpkg-deb', '--extract', str(path), str(destination)], check=True)
    print(json.dumps({'passed': True, 'packages_hash_verified': len(paths), 'prefix': str(destination)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, default=Path('/workspace/.onboarding/forth-v4112'))
    restore(parser.parse_args().destination)
