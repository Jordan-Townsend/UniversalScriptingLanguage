import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

if not any(Path(path, 'usl_systems').is_dir() for path in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')

from recover_references import (ROOT, MAX_BODY, MAX_NEW_CACHE, check_coverage,
                                fallback_table, fetch, missing_rows, sha)
from semantic_records import SnapshotBudget, read_object


class Response:
    status = 200
    url = 'https://example.org/reference'
    headers = {'Content-Type': 'text/plain'}
    def __init__(self, body): self.body = body
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, count): return self.body[:count]


class RecoveryTests(unittest.TestCase):
    def test_all137_initial_missing_ids_have_individual_fallbacks(self):
        rows = missing_rows(); table = fallback_table()
        self.assertEqual(len(check_coverage(rows, table)), 137)
        self.assertTrue(all(len(urls) >= 2 for urls in table.values()))
        del table['mql']
        with self.assertRaises(ValueError): check_coverage(rows, table)

    def test_shared_composite_upstream_is_deduplicable_without_identity_merge(self):
        table = fallback_table()
        self.assertEqual(table['myghty'], table['html+myghty'])
        self.assertNotEqual('myghty', 'html+myghty')
        self.assertTrue(all(url.startswith('https://') for urls in table.values() for url in urls))
        self.assertNotIn('https://isocpp.org/', table['mql'])

    def test_document_code_is_only_stored_never_executed(self):
        body = b'import os; raise RuntimeError("document text must not run")'
        with tempfile.TemporaryDirectory() as directory:
            budget = SnapshotBudget(directory, 1024)
            opener = unittest.mock.Mock()
            opener.open.return_value = Response(body)
            with patch('recover_references.urllib.request.build_opener', return_value=opener):
                result = fetch('https://example.org/reference', budget)
            self.assertTrue(result['retrieved'])
            self.assertFalse(result['normative_semantics_understood'])
            self.assertFalse(result['full_standard_qualified'])
            self.assertEqual(read_object(directory, result['sha256']), body)

    def test_oversized_body_is_rejected_without_cache_write(self):
        with tempfile.TemporaryDirectory() as directory:
            budget = SnapshotBudget(directory, MAX_NEW_CACHE)
            opener = unittest.mock.Mock()
            opener.open.return_value = Response(b'x' * (MAX_BODY + 1))
            with patch('recover_references.urllib.request.build_opener', return_value=opener):
                result = fetch('https://example.org/reference', budget)
            self.assertFalse(result['retrieved'])
            self.assertEqual(budget.written_bytes, 0)

    def test_plain_http_and_tampered_body_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            budget = SnapshotBudget(directory, 1024)
            self.assertFalse(fetch('http://example.org/reference', budget)['retrieved'])
            identity = budget.put(b'reference')
            Path(directory, identity).write_bytes(b'tamper')
            with self.assertRaises(ValueError): read_object(directory, identity)

    def test_export_preserves_all_failures_and_no_qualification(self):
        output = ROOT / 'reference-recovery-results'
        ledger = json.loads((output / 'RECOVERED_REFERENCES.json').read_text())
        records = ledger['records']; summary = json.loads((output / 'SUMMARY.json').read_text())
        self.assertEqual({r['catalog_id'] for r in records}, {r['catalog_id'] for r in missing_rows()})
        self.assertEqual(len(records), 137)
        self.assertEqual(ledger['source_scope_ledger_sha256'], sha(ROOT / 'scope-all-results/ALL_IDS.json'))
        self.assertTrue(summary['initial_scope_outputs_unchanged'])
        self.assertEqual(summary['full_standards_qualified'], 0)
        self.assertLessEqual(summary['new_cache_bytes_written'], MAX_NEW_CACHE)
        self.assertLessEqual(summary['cumulative_new_cache_bytes_upper_bound'], MAX_NEW_CACHE)
        self.assertEqual(summary['pipeline_sha256'], sha(ROOT / 'recover_references.py'))
        self.assertTrue(summary['pipeline_unchanged_during_run'])
        attempts = json.loads((output / 'HTTP_ATTEMPTS.json').read_text())
        for row in records:
            self.assertTrue(row['attempts'])
            self.assertFalse(row['semantic_readiness']['complete_rule_set'])
            self.assertFalse(row['semantic_readiness']['full_standard_qualified'])
            self.assertTrue(all(a['url'] in attempts for a in row['attempts']))
            if row['selected']:
                self.assertTrue(row['selected']['retrieved'])
                self.assertLessEqual(row['selected']['bytes'], MAX_BODY)
        for name, item in json.loads((output / 'MANIFEST.json').read_text()).items():
            self.assertEqual(item['sha256'], sha(output / name))


if __name__ == '__main__':
    unittest.main()
