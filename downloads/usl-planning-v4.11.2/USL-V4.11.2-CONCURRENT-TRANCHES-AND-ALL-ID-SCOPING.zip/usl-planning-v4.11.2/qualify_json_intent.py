"""Run the independently authored RFC vectors through the full data path."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def run(output):
    sys.path.insert(0, str(ROOT / 'json-audit'))
    from independent_cases import all_cases, run_suite
    from json_semantics import JSONResourceLimit, JSONRuleError, generate_json, parse_json, run_usl
    from qualify_json import native_batch
    output = Path(output);output.mkdir(exist_ok=True, parents=True)
    cases = all_cases()
    result = run_suite(parse_json, parse_json, lambda value: value)
    if result['failures']:
        raise ValueError('Independent parser intent counterexample: ' + str(result['failures'][:3]))
    originals = [(case.id, case.input.encode('utf-8') if isinstance(case.input, str) else case.input) for case in cases]
    native_original = native_batch(originals)
    generated = [];records = []
    for case in cases:
        row = {'case': case.id, 'clauses': case.clauses, 'policy': case.policy, 'expected_acceptance': case.accepts}
        try:
            observed = parse_json(case.input)
        except JSONResourceLimit:
            row.update(resource_limited=True, passed=not case.accepts)
        except JSONRuleError:
            row.update(resource_limited=False, passed=not case.accepts and native_original[case.id]['accepted'] is False)
        else:
            executed = run_usl(observed)
            encoded = generate_json(executed, duplicate_policy='preserve')
            fresh_native = native_original[case.id]
            row.update(passed=case.accepts and executed == case.expected and fresh_native['accepted'] is True and fresh_native['IR'] == case.expected
                       and parse_json(encoded) == case.expected,
                       generated_sha256=hashlib.sha256(encoded).hexdigest())
            generated.append((case.id, encoded))
        records.append(row)
    native_generated = native_batch(generated)
    expected = {case.id: case.expected for case in cases}
    for row in records:
        if row.get('generated_sha256'):
            native = native_generated[row['case']]
            row['passed'] = row['passed'] and native['accepted'] is True and native['IR'] == expected[row['case']]
    report = {'passed': all(row['passed'] for row in records), 'independent_intent_vectors': len(cases),
              'fresh_generated_USL_executions': len(generated), 'fresh_native_processing_cases': len(cases) + len(generated),
              'source_identities': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ['json_semantics.py', 'json_native_reference.py', 'qualify_json_intent.py', 'json-audit/independent_cases.py']},
              'prior_BOM_policy_mismatch_resolved': 'RFC8.1 permits both policies; fixtures now check the disclosed ignore-input-BOM policy. Generator no-BOM invariant remains required.',
              'universal_program_correctness_proved': False, 'records': records}
    (output / 'independent-intent.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'records'}))
    if not report['passed']:
        raise ValueError('Independent end-to-end intent failure: ' + str([r for r in records if not r['passed']][:3]))
    return report


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('json-results'))
    args = parser.parse_args();sys.path.insert(0, str(args.source_root.resolve()))
    run(args.output)
