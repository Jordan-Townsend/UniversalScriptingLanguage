"""All-ID concurrent discovery/implementation packets with scoped receipts.

These finite workers route known work, not general-purpose autonomous minds.
They preserve missing implementations rather than manufacturing completion.
"""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent


async def execute(output, references, fresh_brainfuck=False, compiler=None):
    from usl_systems.language import Interpreter
    from planner import validate_catalog
    catalog = json.loads((ROOT / 'inputs/catalog.json').read_text())
    rows = validate_catalog(catalog)
    output = Path(output);output.mkdir(parents=True, exist_ok=True)
    refs = json.loads(Path(references).read_text())
    by_id = {identifier: record for record in refs['records'] for identifier in record['catalog_ids']}
    active = 0;maximum = 0;started = 0
    release = asyncio.Event()
    native_task = None
    if fresh_brainfuck:
        from brainfuck_semantics import qualify
        native_task = asyncio.create_task(asyncio.to_thread(qualify, output / 'brainfuck', compiler))
    source = (ROOT / 'semantic_worker.usl').read_text()

    async def worker(row):
        nonlocal active, maximum, started
        active += 1;started += 1;maximum = max(active, maximum)
        await release.wait()
        reference = by_id.get(row['catalog_id'])
        chosen = (reference or {}).get('chosen') or {}
        available = bool(reference and reference['retrieved'])
        receipt = await native_task if row['catalog_id'] == 'brainfuck' and native_task else None
        if receipt and (not receipt['passed'] or receipt['source_sha256'] != hashlib.sha256((ROOT / 'brainfuck_semantics.py').read_bytes()).hexdigest()):
            raise ValueError('Fresh scoped validation identity mismatch')
        task = {'reference_available': available, 'scoped_implementation': row['scoped'],
                'fresh_scoped_validation': bool(receipt), 'whole_standard_passed': False}
        result = Interpreter(capabilities={'semantic_task': lambda: task}, timeout=2, max_ops=2000).run(source)
        packet = {'catalog_id': row['catalog_id'], 'family': row['family'], 'prior_scope': row['scoped'],
                  'fresh_Brainfuck_scope': bool(receipt), 'decision': result.variables['decision'],
                  'reference': {'URL': chosen.get('final_url') or chosen.get('url') or (reference or {}).get('url'),
                                'body_sha256': chosen.get('sha256'), 'retrieved': available,
                                'authoritative_specification_audited': False},
                  'steps': row['ordered_steps'], 'dimensions': row['obligation_dimensions'],
                  'external_dependencies': row['external_dependencies'],
                  'discovery_status': 'chapter/feature/library semantics still require exact-version audit',
                  'native_validation_receipt': {'path': 'brainfuck/qualification.json', 'fresh_native_executions': receipt['fresh_native_executions']} if receipt else None,
                  'USL_decision_operations': result.operations}
        active -= 1
        return packet

    tasks = [asyncio.create_task(worker(row)) for row in rows]
    await asyncio.sleep(0)
    if started != 606 or maximum != 606:
        raise ValueError('All semantic workers must be started before release')
    release.set()
    packets = await asyncio.gather(*tasks)
    existing = sum(r['prior_scope'] for r in packets)
    new = sum(r['fresh_Brainfuck_scope'] and not r['prior_scope'] for r in packets)
    report = {'schema': 'usl.all-ID.semantic-worker-packets.v1', 'all_original_IDs': 606, 'logical_workers_started_together': started,
              'maximum_live_logical_workers': maximum, 'fixed_rounds': False, 'scoped_originals_with_addon': existing + new,
              'originals_without_scope_with_addon': 606 - existing - new, 'new_scoped_IDs': new,
              'full_standards_qualified': 0, 'normative_steps_preserved': sum(len(r['steps']) for r in packets),
              'normative_dimensions_preserved': sum(len(r['dimensions']) for r in packets),
              'reference_available_IDs': sum(r['reference']['retrieved'] for r in packets),
              'all_missing_semantics_discovered': False, 'automatic_general_semantic_synthesis_backend_installed': False,
              'unimplemented_IDs_are_not_marked_done': True, 'USL_policy_sha256': hashlib.sha256(source.encode()).hexdigest(),
              'packets': packets}
    (output / 'SEMANTIC_WORKERS.json').write_text(json.dumps(report, separators=(',', ':')) + '\n')
    summary = {k: v for k, v in report.items() if k != 'packets'}
    (output / 'SEMANTIC_WORKER_SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('semantic-results'))
    parser.add_argument('--references', type=Path, default=ROOT / 'inputs/reference_status.json')
    parser.add_argument('--fresh-brainfuck', action='store_true')
    parser.add_argument('--ebfc')
    args = parser.parse_args();sys.path.insert(0, str(args.source_root.resolve()))
    asyncio.run(execute(args.output, args.references, args.fresh_brainfuck, args.ebfc))
