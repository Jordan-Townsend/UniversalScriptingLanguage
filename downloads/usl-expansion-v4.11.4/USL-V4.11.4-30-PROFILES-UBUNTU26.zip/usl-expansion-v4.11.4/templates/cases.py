"""Independently authored rendering contracts; expectations do not use frontend IR."""
from html import escape


def cases():
    fixtures=[]
    def add(name,haml,slim,mask,bindings,expected):
        for language,source in [('haml',haml),('slim',slim),('mask',mask)]:
            fixtures.append({'id':language+':'+name,'language':language,'source':source,'bindings':bindings.copy(),'expected_HTML':expected,'kind':'valid'})
    add('nested','%section.card#main\n  %h1 Hello\n  %p World\n','section.card#main\n  h1 Hello\n  p World\n',"section.card#main { h1 > 'Hello'; p > 'World'; }",{},'<section class="card" id="main"><h1>Hello</h1><p>World</p></section>')
    add('classes','%div.one.two\n  %span Inner\n','div.one.two\n  span Inner\n',"div.one.two { span > 'Inner'; }",{},'<div class="one two"><span>Inner</span></div>')
    values=['plain','<script>alert(1)</script>','&copy; &#39;','"double" and \'single\'','', ' ', 'snowman ☃ and 𝄞','line\nnext','a&b<c>d','\\ path','\t tab','zero 0','False','x=1;print(9)']
    for index,value in enumerate(values):
        add('binding-'+str(index),'%p= title\n','p= title\n',"p > '~[title]';",{'title':value},'<p>'+escape(value,quote=True)+'</p>')
        add('interpolation-'+str(index),'%p Hello #{title} end\n','p Hello #{title} end\n',"p > 'Hello ~[title] end';",{'title':value},'<p>Hello '+escape(value,quote=True)+' end</p>')
    for show in [False,True]:
        add('condition-'+str(show),'%div\n  - if show\n    %p= title\n  - else\n    %p Hidden\n','div\n  - if show\n    p= title\n  - else\n    p Hidden\n',"div { if (show) { p > '~[title]'; } else { p > 'Hidden'; } }",{'show':show,'title':'visible <&'},'<div><p>'+('visible &lt;&amp;' if show else 'Hidden')+'</p></div>')
    for index,items in enumerate([[],['one'],['<two>','a&b','"q"'],['a']*16]):
        add('loop-'+str(index),'%ul\n  - items.each do |item|\n    %li= item\n','ul\n  - items.each do |item|\n    li= item\n',"ul { for (item of items) { li > '~[item]'; } }",{'items':items},'<ul>'+''.join('<li>'+escape(value,quote=True)+'</li>' for value in items)+'</ul>')
    for index,title in enumerate(['hello','<&"\'','𝄞']):
        add('dynamic-attribute-'+str(index),'%a(href=url title=title) Link\n','a href=url title=title Link\n',"a href='~[url]' title='~[title]' > 'Link';",{'url':'/path?q="quoted"','title':title.replace('&','and')},'<a href="'+escape('/path?q="quoted"',quote=True)+'" title="'+escape(title.replace('&','and'),quote=True)+'">Link</a>')
    add('condition-loop','%section\n  - if show\n    %ol\n      - items.each do |item|\n        %li Item #{item}\n','section\n  - if show\n    ol\n      - items.each do |item|\n        li Item #{item}\n',"section { if (show) { ol { for (item of items) { li > 'Item ~[item]'; } } } }",{'show':True,'items':['<&','two']},'<section><ol><li>Item &lt;&amp;</li><li>Item two</li></ol></section>')
    add('literal-attribute','%button(title="Click here") Go\n','button title="Click here" Go\n',"button title='Click here' > 'Go';",{},'<button title="Click here">Go</button>')
    for language,source in [('haml','%p(title="unterminated) text\n'),('slim','p title="unterminated text\n'),('mask',"p > 'unterminated")]:
        fixtures.append({'id':language+':invalid-literal','language':language,'source':source,'bindings':{},'kind':'native-negative'})
    return fixtures


def unsupported():
    return [
      ('haml','%p= dangerous()\n',{}),('slim','p= dangerous()\n',{}),('mask',"p > '~[dangerous()]';",{}),
      ('haml','%script= title\n',{'title':'x'}),('slim','script= title\n',{'title':'x'}),('mask',"script > '~[title]';",{'title':'x'}),
      ('haml','%p= absent\n',{}),('slim','p= absent\n',{}),('mask',"p > '~[absent]';",{}),
      ('haml','- if show\n  %p yes\n',{'show':'truthy'}),('slim','- if show\n  p yes\n',{'show':'truthy'}),('mask',"if (show) { p > 'yes'; }",{'show':'truthy'}),
      ('haml','%p= title\n',{'title':1}),('slim','p= title\n',{'title':1}),('mask',"p > '~[title]';",{'title':1}),
      ('mask',"a href='~[url]' > 'Link';",{'url':'&copy;'}),
      ('mask',"ul { for (item of items) { a href='~[item]' > 'Link'; } }",{'items':['&copy;']}),
    ]
