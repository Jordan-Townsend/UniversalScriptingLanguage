const fs = require('fs');
const mask = require(process.argv[2] + '/maskjs/package');
const records=JSON.parse(fs.readFileSync(0,'utf8'));
let errors=[];
mask.on('error', error => errors.push(String(error)));
const observations=records.map(record=>{
 errors=[];
 try {
  const tree=mask.parse(record.source);
  const observed=mask.render(tree,record.bindings);
  if(errors.length) return {id:record.id,accepted:false,diagnostics:errors};
  return {id:record.id,accepted:true,output:observed};
 } catch(error) {return {id:record.id,accepted:false,error:String(error)};}
});
process.stdout.write(JSON.stringify({observations,toolchain:{Node:process.version,native_executable:process.execPath,maskjs:mask.version},
 native_diagnostic_policy:'Any native error/warning diagnostic fails the scoped strict processing contract; recovered output is not accepted'}));
