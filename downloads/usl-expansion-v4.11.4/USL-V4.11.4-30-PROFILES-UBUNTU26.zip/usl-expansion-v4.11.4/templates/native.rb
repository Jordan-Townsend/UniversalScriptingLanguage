require 'json'
gem 'temple', '0.10.4'
gem 'tilt', '2.6.1'
gem 'thor', '1.4.0'
gem 'haml', '6.3.0'
gem 'slim', '5.2.1'
require 'haml'
require 'slim'
out = JSON.parse(STDIN.read).map do |record|
  begin
    locals = record['bindings'].transform_keys(&:to_sym)
    template = record['language'] == 'haml' ? Haml::Template : Slim::Template
    observed = template.new { record['source'] }.render(Object.new, locals)
    {'id'=>record['id'], 'accepted'=>true, 'output'=>observed}
  rescue Exception => error
    {'id'=>record['id'], 'accepted'=>false, 'error_class'=>error.class.to_s, 'error'=>error.message[0,500]}
  end
end
STDOUT.write(JSON.generate({'observations'=>out, 'toolchain'=>{'Ruby'=>RUBY_DESCRIPTION, 'native_executable'=>File.readlink('/proc/self/exe'), 'haml'=>Haml::VERSION, 'slim'=>Slim::VERSION,
  'gems'=>Gem.loaded_specs.transform_values{|s| s.version.to_s}}}))
