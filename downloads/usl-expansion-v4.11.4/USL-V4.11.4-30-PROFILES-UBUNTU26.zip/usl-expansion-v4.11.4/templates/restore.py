"""Install pinned pure-Ruby and MaskJS providers into a local prefix."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parent
DEFAULT_PREFIX = Path('/workspace/.onboarding/templates-v4114')
GEMS = {
 'haml': ('6.3.0','8e6eb87d869639e348852009e74a2a1663d79663ed7e7dbcb38beb1f12bcdd97'),
 'slim': ('5.2.1','72351dff7e2ff20e2d5c393cfc385bb9142cef5db059141628fd7163ac3c13e7'),
 'temple': ('0.10.4','b7a1e94b6f09038ab0b6e4fe0126996055da2c38bec53a8a336f075748fff72c'),
 'tilt': ('2.6.1','35a99bba2adf7c1e362f5b48f9b581cce4edfba98117e34696dde6d308d84770'),
 'thor': ('1.4.0','8763e822ccb0f1d7bee88cde131b19a65606657b847cc7b7b4b82e772bcd8a3d')}
MASK_INTEGRITY = 'oMSZ0C2BHrDS2vTAzHHPXO/YC2IYce7qjWfwKsyWnkdStKRANH33Bhn2wXJE9yJuL5sHNwcYD4UmjPti/9ucsA=='


def download(url, path, algorithm, expected):
    data = urllib.request.urlopen(url, timeout=40).read()
    observed = hashlib.new(algorithm, data).digest()
    if observed != expected:
        raise ValueError('Provider hash mismatch: ' + url)
    path.write_bytes(data)
    return {'url': url, 'bytes': len(data), algorithm: observed.hex()}


def restore(prefix=DEFAULT_PREFIX):
    prefix = Path(prefix); prefix.mkdir(parents=True, exist_ok=True)
    cache = prefix / 'downloads'; cache.mkdir(exist_ok=True)
    def fetch(item):
        name, (version, checksum) = item
        path = cache / f'{name}-{version}.gem'
        record = download(f'https://rubygems.org/downloads/{name}-{version}.gem', path, 'sha256', bytes.fromhex(checksum))
        return name, path, record
    with ThreadPoolExecutor(max_workers=len(GEMS)) as pool:
        downloaded = list(pool.map(fetch, GEMS.items()))
    records = {}
    for name, path, record in downloaded:
        result = subprocess.run(['gem', 'install', '--local', '--ignore-dependencies', '--no-document', '--install-dir', str(prefix / 'gems'), str(path)], capture_output=True, text=True)
        if result.returncode:
            raise ValueError('Local gem install failed: ' + result.stderr[:300])
        records[name] = record
    target = cache / 'maskjs-0.73.3.tgz'
    records['maskjs'] = download('https://registry.npmjs.org/maskjs/-/maskjs-0.73.3.tgz', target, 'sha512', base64.b64decode(MASK_INTEGRITY))
    package = prefix / 'maskjs'; package.mkdir(exist_ok=True)
    with tarfile.open(target) as archive:
        archive.extractall(package, filter='data')
    report = {'providers': records, 'Ruby_versions': {name: version for name, (version, identity) in GEMS.items()},
              'maskjs_version': '0.73.3', 'native_binaries_shipped': False}
    (prefix / 'PROVENANCE.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--prefix', type=Path, default=DEFAULT_PREFIX)
    print(json.dumps(restore(parser.parse_args().prefix)))
