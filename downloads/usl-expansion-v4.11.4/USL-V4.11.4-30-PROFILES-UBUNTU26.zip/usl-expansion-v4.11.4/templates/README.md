This tranche adds three **bounded, native-tested template translation profiles**: Haml 6.3.0, Slim 5.2.1 and MaskJS 0.73.3. Each source frontend builds actual structured template IR and emits runnable `.usl`. Rendering, conditionals, loops and HTML escaping run in USL; the only host capability supplies already validated input data.

Supported constructs are nested allowlisted HTML elements; class/id shortcuts; literal and dynamically bound attributes; escaped text bindings and interpolation; exact-Boolean if/else; and bounded string-list loops with lexical aliases. Independent fixtures cover injection-shaped text, quotes, ampersands, Unicode, empty and whitespace strings, empty/maximal loops, nested controls, negative syntax and unsupported features. Source expressions beyond plain identifiers fail closed.

The native engines perform 126 fresh processing cases in three fresh processes, and generated USL performs 123 fresh executions. Each engine has 41 positive rendering contracts and one negative syntax/diagnostic case. Seventeen additional unsupported-source/input cases are rejected without calling them invalid in the complete upstream language. Seven unit tests include the fixture family and adversarial scope, resource, source-separator and parser-boundary checks.

The comparison is an explicit structural HTML contract: element/tag structure, decoded text and decoded attributes agree. Attribute order, formatting-only whitespace between elements or in structural containers (`root`, `div`, `section`, `article`, `ul`, `ol`) are ignored. Leaf text whitespace is retained. Mask's generated SSR comments and `x-compo-id` hydration metadata are excluded. This does not qualify byte-identical HTML, browser layout, client reactivity or hydration semantics.

Mask's server renderer can reinterpret an ampersand entity in an attribute. This profile rejects ampersands in Mask attribute values, including aliases in loops. It also rejects model strings containing the SSR comment terminator `-->`. Text ampersands remain supported and tested. Haml and Slim retain their own native attribute escaping. Sources use ASCII spaces and CRLF/LF only; alternative separators and unsupported tag/attribute suffixes are rejected.

Install the small pinned public providers into the local prefix, then validate:

```bash
source /workspace/.onboarding/activate-usl.sh
python restore.py
python -m unittest test_templates -v
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

Use `--prefix` on both install and qualification commands to choose another local provider directory. `restore.py` checks SHA-256 for the Ruby gems and SHA-512 for the dependency-free MaskJS tarball. No native binaries are distributed. The compatible activated environment supplies Ruby and Node; a separate host must supply those tools and the pinned USL source runtime.

The pinned Ruby providers are Haml 6.3.0, Slim 5.2.1, Temple 0.10.4, Tilt 2.6.1 and Thor 1.4.0. Origins are `https://rubygems.org/downloads/NAME-VERSION.gem`; their public version metadata comes from the RubyGems v2 API. MaskJS comes from `https://registry.npmjs.org/maskjs/-/maskjs-0.73.3.tgz`. Installed provider trees, their included upstream documentation/license files, runtime executables and every qualification source are hashed in `results/results.json`.

All ready case actors start together. Native concurrency is admitted from the actual number of engine jobs and observed memory/file-descriptor capacity. These virtual actors do not create hardware capacity. Native outputs are fresh and never replayed from a cache.

The complete Haml, Slim and Mask grammars, arbitrary Ruby/JavaScript expressions, raw/safe output modes, whitespace modes, includes, helpers, filters, components, library/platform interoperability, normative audits and universal correctness remain open. Vue/Angular, Mason, ColdFusion and JSP need separate pinned hosts and implementations; this tranche awards them no coverage. Full-standard qualifications remain **zero**.
