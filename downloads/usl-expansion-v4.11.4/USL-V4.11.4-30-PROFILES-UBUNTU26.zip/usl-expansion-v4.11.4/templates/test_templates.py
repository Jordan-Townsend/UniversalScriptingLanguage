import sys
import unittest
sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
from cases import cases,unsupported
from template_semantics import ProfileError,frontend,html_tree,run_usl,validate_bindings


class ScopedTemplateTests(unittest.TestCase):
    def test_independent_full_fixture_contracts(self):
        for case in cases():
            if case['kind']=='valid':
                with self.subTest(id=case['id']):
                    observed,receipt=run_usl(case['source'],case['language'],case['bindings'])
                    self.assertEqual(html_tree(observed),html_tree(case['expected_HTML']))
                    self.assertTrue(receipt['actual_USL_execution'])

    def test_unsupported_constructs_and_bad_binding_types_fail_closed(self):
        for language,source,bindings in unsupported():
            with self.subTest(source=source),self.assertRaises(ProfileError):
                validate_bindings(frontend(source,language),bindings,language)

    def test_alias_scope_and_shadowing_are_explicit(self):
        for language,source in [('haml','- items.each do |item|\n  %p= item\n%p= item\n'),('slim','- items.each do |item|\n  p= item\np= item\n'),('mask',"for (item of items) { p > '~[item]'; } p > '~[item]';")]:
            with self.subTest(language=language),self.assertRaises(ProfileError):run_usl(source,language,{'items':['a']})
        with self.assertRaises(ProfileError):run_usl('- items.each do |item|\n  p= item\n','slim',{'items':['a'],'item':'outer'})

    def test_missing_or_invalid_indentation_and_mask_delimiters_rejected(self):
        for language,source in [('haml','%p text\n  %span child\n'),('slim','div\n   p wrong\n'),('slim','- else\n  p wrong\n'),('mask',"section { p > 'missing';"),('mask',"if (show) {}")]:
            with self.subTest(source=source),self.assertRaises(ProfileError):frontend(source,language)

    def test_mask_entity_attribute_counterexample_is_excluded(self):
        for value in ['&copy;','x&y','&#39;']:
            with self.subTest(value=value),self.assertRaises(ProfileError):run_usl("a href='~[url]' > 'Link';",'mask',{'url':value})

    def test_unparsed_tag_suffix_and_non_native_source_separators_rejected(self):
        for language,source in [('haml','%p{title: name} text\n'),('slim','pHello\n'),('haml','%p/title\n'),('slim','p\x85text'),('haml','%p\rtext')]:
            with self.subTest(source=source),self.assertRaises(ProfileError):frontend(source,language)

    def test_expansion_and_ssr_comment_injection_limits(self):
        source='- outer.each do |a|\n  - middle.each do |b|\n    - inner.each do |c|\n      p= a\n'
        with self.assertRaisesRegex(ProfileError,'Expanded template'):
            run_usl(source,'slim',{'outer':['x']*16,'middle':['y']*16,'inner':['z']*16})
        with self.assertRaisesRegex(ProfileError,'model-comment'):
            run_usl("ul { for (item of items) { li > '~[item]'; } }",'mask',{'items':['--> <script>']})


if __name__=='__main__':unittest.main()
