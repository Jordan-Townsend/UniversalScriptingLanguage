"""Fresh native/USL qualification for scoped Haml, Slim and Mask templates."""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

from cases import cases,unsupported
from restore import DEFAULT_PREFIX
from template_semantics import ProfileError,frontend,html_tree,run_usl,validate_bindings

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def resource_admission(distinct_jobs):
    def number(path,default):
        try:return int(Path(path).read_text().strip())
        except (OSError,ValueError):return default
    maximum=number('/sys/fs/cgroup/memory.max',1<<30);used=number('/sys/fs/cgroup/memory.current',0)
    available=max(0,maximum-used);descriptors=resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    descriptor_jobs=distinct_jobs if descriptors==resource.RLIM_INFINITY else max(1,descriptors//8)
    slots=max(1,min(distinct_jobs,max(1,available//(64<<20)),descriptor_jobs))
    return {'distinct_native_jobs':distinct_jobs,'admitted_native_threads':slots,'memory_limit_bytes':maximum,
      'observed_memory_current_bytes':used,'native_job_reservation_bytes':64<<20,'reservation_is_scheduler_estimate':True,
      'fixed_worker_cap':None,'virtual_workers_create_physical_capacity':False}


def providers(prefix):
    prefix=Path(prefix);record=json.loads((prefix/'PROVENANCE.json').read_text())
    identities={}
    for folder in ['gems/gems/haml-6.3.0','gems/gems/slim-5.2.1','gems/gems/temple-0.10.4','gems/gems/tilt-2.6.1','gems/gems/thor-1.4.0','maskjs/package']:
        files={str(path.relative_to(prefix)):sha(path) for path in sorted((prefix/folder).rglob('*')) if path.is_file()}
        if not files:raise ValueError('Installed native provider missing: '+folder)
        identities[folder]={'source_tree_sha256':digest(files),'files':files}
    return {'pinned_upstream_artifacts':record,'installed_source_trees':identities}


def native_batch(language,rows,prefix):
    env=os.environ.copy();gems=str(Path(prefix)/'gems');env['GEM_HOME']=gems;env['GEM_PATH']=gems
    command=['node',str(ROOT/'native.js'),str(prefix)] if language=='mask' else ['ruby',str(ROOT/'native.rb')]
    payload=[{key:row[key] for key in ['id','language','source','bindings']} for row in rows]
    result=subprocess.run(command,input=json.dumps(payload).encode(),capture_output=True,timeout=30,env=env)
    if result.returncode:raise ValueError('Native host failed: '+result.stderr.decode(errors='replace')[:400])
    evidence=json.loads(result.stdout)
    if [row['id'] for row in evidence['observations']]!=[row['id'] for row in rows]:raise ValueError('Native host omitted/reordered cases')
    path=Path(evidence['toolchain']['native_executable'])
    evidence['execution_receipt']={'fresh_native_processes':1,'fresh_native_evaluations':len(rows),'native_executions_replayed':False,
      'command':command,'stdin_sha256':hashlib.sha256(json.dumps(payload).encode()).hexdigest(),'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
      'native_executable_sha256':sha(path),'exit_status':0,'stderr_hex':result.stderr.hex()}
    return evidence


async def execute(source_root,output,prefix):
    sys.path.insert(0,str(Path(source_root).resolve()));output=Path(output);output.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter();fixtures=cases();identities={name:sha(ROOT/name) for name in ['template_semantics.py','cases.py','run.py','restore.py','native.rb','native.js','test_templates.py']}
    toolchains=providers(prefix);ready=asyncio.Event();actors_started=active=peak=0
    languages=sorted({row['language'] for row in fixtures});admission=resource_admission(len(languages))
    loop=asyncio.get_running_loop();executor=ThreadPoolExecutor(max_workers=admission['admitted_native_threads'])
    async def native_job(language):
        await ready.wait();return await loop.run_in_executor(executor,native_batch,language,[row for row in fixtures if row['language']==language],prefix)
    jobs={language:asyncio.create_task(native_job(language)) for language in languages}
    async def actor(case):
        nonlocal actors_started,active,peak
        actors_started+=1;active+=1;peak=max(peak,active)
        try:
            await ready.wait();native=next(row for row in (await jobs[case['language']])['observations'] if row['id']==case['id'])
            row=dict(case,native=native,full_standard_qualified=False)
            try:
                observed,receipt=run_usl(case['source'],case['language'],case['bindings'])
            except ProfileError as error:
                if case['kind']!='native-negative' or native['accepted'] is not False:raise
                row.update(passed=True,frontend_rejected=True,error=str(error),actual_USL_execution=False)
            else:
                if case['kind']!='valid' or not native['accepted']:raise ValueError('Unexpected native acceptance/rejection '+case['id']+':'+str(native))
                expected=html_tree(case['expected_HTML']);actual=html_tree(observed);native_tree=html_tree(native['output'],mask=case['language']=='mask')
                if expected!=actual or native_tree!=expected:raise ValueError('Intent/native/USL counterexample '+case['id']+':'+repr((expected,actual,native_tree)))
                generated=receipt.pop('generated_source');key=hashlib.sha256(generated.encode()).hexdigest();folder=output/'generated';folder.mkdir(exist_ok=True);(folder/(key+'.usl')).write_text(generated)
                row.update(passed=True,observed_USL_output=observed,independent_expected_tree=expected,native_observed_tree=native_tree,
                    actual_USL_execution=True,USL_receipt=receipt,generated_source_sha256=key)
            return row
        finally:active-=1
    tasks=[asyncio.create_task(actor(case)) for case in fixtures]
    try:
        await asyncio.sleep(0);all_started=actors_started==len(fixtures);ready.set();records=await asyncio.gather(*tasks)
        native={language:await job for language,job in jobs.items()}
    finally:executor.shutdown(wait=True)
    rejection_records=[]
    for language,source,bindings in unsupported():
        try:
            nodes=frontend(source,language);validate_bindings(nodes,bindings,language)
        except ProfileError as error:rejection_records.append({'language':language,'source':source,'bindings':bindings,'profile_rejected':True,'reason':str(error),'native_language_invalid_claim':False})
        else:raise ValueError('Unsupported construct accepted')
    if any(sha(ROOT/name)!=identity for name,identity in identities.items()):raise ValueError('Qualification source changed during execution')
    if providers(prefix)!=toolchains:raise ValueError('Installed native provider source changed during execution')
    profiles=[]
    for language in ['haml','slim','mask']:
        selected=[row for row in records if row['language']==language]
        profile={'catalog_id':language,'scoped_profile_validated':all(row['passed'] for row in selected),'full_standard_qualified':False,
          'exact_profile':{'engine':{'haml':'Haml6.3.0/Ruby3.3.8','slim':'Slim5.2.1/Ruby3.3.8','mask':'MaskJS0.73.3/Node24.19.0'}[language],
            'semantics':['nested allowlisted HTML elements','class/id shortcuts','literal and dynamic attributes','escaped text bindings and interpolation','Boolean if/else','bounded string-list loops with lexical aliases'],
            'comparison':'HTML element/attribute/text tree; attribute order and formatting-only whitespace between elements or in empty structural containers(root/div/section/article/ul/ol) ignored; Mask SSR comments and x-compo-id hydration attributes excluded',
            'limits':{'source_UTF8_bytes':65536,'indentation_levels':16,'input_string_characters':4096,'loop_items':16,
              'expanded_IR_nodes':4096,'USL_operations':2_000_000,'USL_timeout_seconds':4,'USL_string_characters':100000},
            'source_whitespace':'ASCII space and CRLF/LF only; lone CR and alternative whitespace separators rejected',
            'Mask_dynamic_attribute_ampersands':'Rejected to avoid native entity interpretation; literal/text binding ampersands supported'},
          'cases':len(selected),'native_executions':len(selected),'native_processes':1,'usl_executions':sum(row['actual_USL_execution'] for row in selected),
          'source_sha256':identities,'toolchain':native[language]['toolchain'],'native_execution_receipt':native[language]['execution_receipt'],
          'provider_identities':toolchains,'reference_hashes':{name:data['source_tree_sha256'] for name,data in toolchains['installed_source_trees'].items()},
          'open_obligations':['Entire upstream language grammar and Ruby/JavaScript expression semantics','partials/includes, filters, helpers, components, dynamic tags and arbitrary code','Raw/safe output, full escaping/context and whitespace modes','Mask reactive bindings/client hydration and server metadata semantics','All standard/upstream library, interoperability/platform, normative audit, universal correctness and independent full review gates'],
          'records':selected}
        profile['profile_contract']=profile['exact_profile']
        profile['exact_profile']=profile['profile_contract']['engine']+'; '+', '.join(profile['profile_contract']['semantics'])+'; '+profile['profile_contract']['comparison']
        profiles.append(profile)
    summary={'scoped_profile_validated':all(p['scoped_profile_validated'] for p in profiles),'new_original_catalog_IDs':3,'native_processing_cases':len(records),
      'fresh_native_processes':3,'fresh_USL_executions':sum(row['actual_USL_execution'] for row in records),'all_logical_case_actors_started_before_release':all_started,
      'peak_live_logical_case_actors':peak,'native_job_threads':admission['admitted_native_threads'],'distinct_native_jobs':len(languages),'fixed_rounds':False,'all_unsupported_cases_rejected':len(rejection_records),
      'full_standards_qualified':0,'native_execution_evidence_replayed':False,'seconds':time.perf_counter()-started}
    report={'schema':'usl.templates.three-native-engine-scoped-profiles.v1','summary':summary,'resource_admission':admission,'records':profiles,'unsupported_rejections':rejection_records}
    (output/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary));return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--output',type=Path,default=Path('results'));parser.add_argument('--prefix',type=Path,default=DEFAULT_PREFIX)
    args=parser.parse_args();asyncio.run(execute(args.source_root,args.output,args.prefix))
