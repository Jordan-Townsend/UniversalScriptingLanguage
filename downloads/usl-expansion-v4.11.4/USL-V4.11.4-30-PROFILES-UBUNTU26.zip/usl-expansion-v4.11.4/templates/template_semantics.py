"""Restricted Haml/Slim/Mask frontends lowering real template semantics to USL."""
from __future__ import annotations
import ast
from html.parser import HTMLParser
import json
import re

TAGS = {'div','section','article','ul','ol','li','p','span','strong','em','h1','h2','a','label','button'}
ATTRIBUTES = {'href','title','data-note','aria-label'}
NAME = r'[a-z][a-z0-9_]*'
RESERVED = {'if','else','end','do','for','in','of','class','def','module','true','false','nil','return','while','break','next','yield','self','super','case','when','unless','until','begin','rescue','ensure','then'}


class ProfileError(ValueError): pass


def need(condition, message):
    if not condition: raise ProfileError(message)


def name(text):
    need(re.fullmatch(NAME,text) is not None and text not in RESERVED,'Unsupported binding identifier')
    return text


def parts(text, language):
    expression = r'#\{('+NAME+r')\}' if language in {'haml','slim'} else r'~\[('+NAME+r')\]'
    result=[];cursor=0
    for match in re.finditer(expression,text):
        if match.start()>cursor: result.append(['literal',text[cursor:match.start()]])
        result.append(['binding',name(match[1])]);cursor=match.end()
    if cursor<len(text):result.append(['literal',text[cursor:]])
    for kind,value in result:
        if kind=='literal': need(not any(token in value for token in ['<','>','&','#{','~[']),'Static text outside literal markup-free profile')
    return result


def tag_header(text, language):
    if language=='haml': need(text.startswith('%'),'Expected Haml tag');text=text[1:]
    match=re.match(r'([a-z][a-z0-9]*)([.#][A-Za-z][A-Za-z0-9_-]*(?:[.#][A-Za-z][A-Za-z0-9_-]*)*)?',text)
    need(match is not None and match[1] in TAGS,'Unsupported or unsafe HTML tag')
    tag=match[1];rest=text[match.end():];attrs=[];classes=[];identity=None
    need(not rest or rest[0] in (' ','=') or (language=='haml' and rest[0]=='('),'Unsupported tag suffix or missing separator')
    for shortcut in re.findall(r'[.#][A-Za-z][A-Za-z0-9_-]*',match[2] or ''):
        if shortcut[0]=='.':classes.append(shortcut[1:])
        else:need(identity is None,'Duplicate id');identity=shortcut[1:]
    if classes:attrs.append(['class',['literal',' '.join(classes)]])
    if identity:attrs.append(['id',['literal',identity]])
    attrtext=''
    if language=='haml' and rest.startswith('('):
        close=rest.find(')');need(close>=0,'Unclosed Haml attribute wrapper');attrtext=rest[1:close];rest=rest[close+1:]
    elif language=='slim':
        cursor=0
        pattern=r'''\s+([a-z][a-z0-9_-]*)=("[^"\\]*"|'[^'\\]*'|[a-z][a-z0-9_]*)'''
        while (matched:=re.match(pattern,rest[cursor:])):
            cursor+=matched.end()
        attrtext=rest[:cursor];rest=rest[cursor:]
    if attrtext:
        pattern=r'''\s*([a-z][a-z0-9_-]*)=("[^"\\]*"|'[^'\\]*'|[a-z][a-z0-9_]*)''';cursor=0
        while cursor<len(attrtext):
            matched=re.match(pattern,attrtext[cursor:]);need(matched is not None,'Unsupported attribute expression')
            key,value=matched[1],matched[2];need(key in ATTRIBUTES and key not in {a[0] for a in attrs},'Unsupported or duplicate attribute')
            if value[0] in '\"\'':
                value=ast.literal_eval(value);need(not any(t in value for t in ['#{','~[','(',')']),'Attribute interpolation outside profile')
                expression=['literal',value]
            else:expression=['binding',name(value)]
            attrs.append([key,expression]);cursor+=matched.end()
        need(cursor==len(attrtext),'Trailing attribute syntax')
    rest=rest.strip()
    if language=='slim':need(re.match(r'[a-z][a-z0-9_-]*\s*=',rest) is None,'Malformed or unsupported Slim attribute')
    if rest.startswith('='): content=[['binding',name(rest[1:].strip())]]
    else:content=parts(rest,language)
    return {'kind':'element','tag':tag,'attributes':attrs,'parts':content,'children':[]}


def indent_frontend(source,language):
    lines=[]
    for raw in source.splitlines():
        need('\t' not in raw,'Tabs outside indentation profile')
        if not raw.strip():continue
        depth=len(raw)-len(raw.lstrip(' '));need(depth%2==0 and depth<=32,'Indentation must use two spaces')
        lines.append((depth,raw.strip()))
    need(len(lines)<=1000,'Template line budget')
    def block(index,indent):
        result=[]
        while index<len(lines) and lines[index][0]>=indent:
            actual,text=lines[index];need(actual==indent,'Unexpected indentation');index+=1
            if text=='- else':raise ProfileError('Unmatched else')
            matched=re.fullmatch(r'- if ('+NAME+r')',text)
            each=re.fullmatch(r'- ('+NAME+r')\.each do \|('+NAME+r')\|',text)
            if matched:
                node={'kind':'if','binding':name(matched[1]),'yes':[],'no':[]}
            elif each:
                node={'kind':'each','binding':name(each[1]),'alias':name(each[2]),'children':[]}
            elif text.startswith('='):
                node={'kind':'text','parts':[['binding',name(text[1:].strip())]]}
            else:node=tag_header(text,language)
            if index<len(lines) and lines[index][0]>indent:
                need(lines[index][0]==indent+2 and node['kind']!='text' and not node.get('parts'),'Illegal nested content')
                children,index=block(index,indent+2)
                node['yes' if node['kind']=='if' else 'children']=children
            if node['kind'] in {'if','each'}:need(bool(node['yes' if node['kind']=='if' else 'children']),'Control construct requires body')
            if node['kind']=='if' and index<len(lines) and lines[index]==(indent,'- else'):
                index+=1;need(index<len(lines) and lines[index][0]==indent+2,'Else needs body');node['no'],index=block(index,indent+2)
            result.append(node)
            if index<len(lines) and lines[index]==(indent,'- else'):break
        return result,index
    result,index=block(0,0);need(index==len(lines),'Trailing unmatched control syntax');return result


class MaskParser:
    def __init__(self,source):self.source=source;self.position=0
    def whitespace(self):
        while self.position<len(self.source) and self.source[self.position].isspace():self.position+=1
    def take(self,pattern):
        self.whitespace();match=re.match(pattern,self.source[self.position:]);need(match is not None,'Unexpected Mask syntax');self.position+=match.end();return match
    def quoted(self):
        match=self.take(r'''("[^"\\]*"|'[^'\\]*')''');return ast.literal_eval(match[1])
    def block(self,closing=False,depth=0):
        need(depth<=16,'Mask nesting limit');out=[]
        while True:
            self.whitespace()
            if self.position==len(self.source):need(not closing,'Unclosed Mask block');return out
            if self.source[self.position]=='}':need(closing,'Unmatched Mask brace');self.position+=1;return out
            control=re.match(r'(if|for)\s*\(',self.source[self.position:])
            if control:
                if control[1]=='if':
                    match=self.take(r'if\s*\(\s*('+NAME+r')\s*\)\s*\{');node={'kind':'if','binding':name(match[1]),'yes':self.block(True,depth+1),'no':[]}
                    self.whitespace()
                    if self.source.startswith('else',self.position):self.take(r'else\s*\{');node['no']=self.block(True,depth+1)
                else:
                    match=self.take(r'for\s*\(\s*('+NAME+r')\s+of\s+('+NAME+r')\s*\)\s*\{');node={'kind':'each','binding':name(match[2]),'alias':name(match[1]),'children':self.block(True,depth+1)}
                need(bool(node['yes' if node['kind']=='if' else 'children']),'Mask control construct needs body')
                out.append(node);continue
            header=self.take(r'([a-z][a-z0-9]*)([.#][A-Za-z][A-Za-z0-9_-]*(?:[.#][A-Za-z][A-Za-z0-9_-]*)*)?')
            node=tag_header(header[0],'slim')
            while True:
                self.whitespace()
                if re.match(r'[a-z][a-z0-9_-]*\s*=',self.source[self.position:]):
                    key=self.take(r'([a-z][a-z0-9_-]*)\s*=')[1];value=self.quoted()
                    need(key in ATTRIBUTES and key not in {a[0] for a in node['attributes']},'Unsupported Mask attribute')
                    matched=re.fullmatch(r'~\[('+NAME+r')\]',value)
                    expression=['binding',name(matched[1])] if matched else ['literal',value]
                    need(expression[0]=='binding' or '~[' not in value,'Unsupported Mask attribute interpolation')
                    node['attributes'].append([key,expression]);continue
                break
            self.whitespace();need(self.position<len(self.source),'Mask tag needs explicit body or terminator')
            marker=self.source[self.position];self.position+=1
            if marker=='{':node['children']=self.block(True,depth+1)
            elif marker=='>':node['parts']=parts(self.quoted(),'mask');self.whitespace();self.take(';')
            elif marker!=';':raise ProfileError('Unsupported Mask tag suffix')
            out.append(node)


def frontend(source,language):
    need(language in {'haml','slim','mask'} and type(source) is str and len(source.encode())<=65536,'Unsupported language/source limit')
    need(all(not char.isspace() or char in ' \n\r' for char in source),'Only ASCII spaces and CRLF/LF source whitespace supported')
    need('\r' not in source.replace('\r\n',''),'Lone carriage returns outside source profile')
    source=source.replace('\r\n','\n')
    return MaskParser(source).block() if language=='mask' else indent_frontend(source,language)


def validate_bindings(nodes,bindings,language):
    need(type(bindings) is dict and all(type(k) is str for k in bindings),'Expected plain binding map')
    if language=='mask':
        for value in bindings.values():
            values=value if type(value) is list else [value]
            need(all(type(item) is not str or '-->' not in item for item in values),'Mask SSR model-comment termination outside safe profile')
    def reference(expression,scope,attribute=False):
        kind,key=expression
        if kind=='literal':values=[key]
        else:
            need(key in scope or key in bindings,'Missing required binding: '+key)
            values=scope[key] if key in scope else [bindings[key]]
        for value in values:
            need(type(value) is str and len(value)<=4096,'Text/attribute binding must be a bounded exact string')
            if language=='mask' and attribute:need('&' not in value,'Mask native attributes do not preserve ampersand entities; outside profile')
    def walk(items,scope):
        for node in items:
            kind=node['kind']
            if kind in {'text','element'}:
                for item in node['parts']:reference(item,scope)
            if kind=='element':
                for key,expression in node['attributes']:reference(expression,scope,True)
                walk(node['children'],scope)
            elif kind=='if':
                need(node['binding'] in bindings and type(bindings[node['binding']]) is bool,'Condition requires exact Boolean external binding')
                walk(node['yes'],scope);walk(node['no'],scope)
            elif kind=='each':
                need(node['binding'] in bindings,'Missing list binding')
                values=bindings[node['binding']];need(type(values) is list and len(values)<=16 and all(type(v) is str and len(v)<=4096 for v in values),'Loop requires bounded list of exact strings')
                alias=node['alias'];need(alias not in bindings and alias not in scope,'Loop alias must not shadow existing bindings')
                walk(node['children'],scope|{alias:values})
    walk(nodes,{})
    expanded_nodes=0
    def expansion(items):
        nonlocal expanded_nodes
        for node in items:
            expanded_nodes+=1;need(expanded_nodes<=4096,'Expanded template node budget exceeded')
            if node['kind']=='element':expansion(node['children'])
            elif node['kind']=='if':expansion(node['yes']);expansion(node['no'])
            elif node['kind']=='each':
                for item in bindings[node['binding']]:expansion(node['children'])
    expansion(nodes)


def emit_usl(nodes):
    lines=['function escape_html(value):','    let escaped = ""','    for character in value:',
           '        if character == "&":','            escaped = escaped + "&amp;"',
           '        elif character == "<":','            escaped = escaped + "&lt;"',
           '        elif character == ">":','            escaped = escaped + "&gt;"',
           '        elif character == "\\\"":','            escaped = escaped + "&quot;"',
           '        elif character == "\'":','            escaped = escaped + "&#39;"',
           '        else:','            escaped = escaped + character','    return escaped','let rendered = ""']
    count=0
    def expression(value,scope):
        kind,data=value
        return repr(data) if kind=='literal' else scope.get(data,'template_binding('+repr(data)+')')
    def append(value,depth):lines.append('    '*depth+'rendered = rendered + '+value)
    def walk(items,scope,depth):
        nonlocal count
        for node in items:
            kind=node['kind']
            if kind=='element':
                append(repr('<'+node['tag']),depth)
                for key,value in node['attributes']:
                    append(repr(' '+key+'="'),depth);append('escape_html('+expression(value,scope)+')',depth);append(repr('"'),depth)
                append(repr('>'),depth)
                for item in node['parts']:append(expression(item,scope) if item[0]=='literal' else 'escape_html('+expression(item,scope)+')',depth)
                walk(node['children'],scope,depth);append(repr('</'+node['tag']+'>'),depth)
            elif kind=='text':
                for item in node['parts']:append('escape_html('+expression(item,scope)+')',depth)
            elif kind=='if':
                lines.append('    '*depth+'if template_binding('+repr(node['binding'])+'):');walk(node['yes'],scope,depth+1)
                if node['no']:lines.append('    '*depth+'else:');walk(node['no'],scope,depth+1)
            elif kind=='each':
                local='template_item'+str(count);count+=1;lines.append('    '*depth+'for '+local+' in template_binding('+repr(node['binding'])+'):')
                walk(node['children'],scope|{node['alias']:local},depth+1)
    walk(nodes,{},0);return '\n'.join(lines)+'\n'


def run_usl(source,language,bindings):
    from usl_systems.language import Interpreter
    nodes=frontend(source,language);validate_bindings(nodes,bindings,language);generated=emit_usl(nodes)
    execution=Interpreter(capabilities={'template_binding':lambda key:bindings[key]},timeout=4,max_ops=2_000_000).run(generated)
    return execution.variables['rendered'],{'actual_USL_execution':True,'operations':execution.operations,'generated_source':generated}


class HTMLTree(HTMLParser):
    def __init__(self,mask=False):super().__init__(convert_charrefs=True);self.root=['root',[],[]];self.stack=[self.root];self.mask=mask
    def handle_starttag(self,tag,attrs):
        need(tag in TAGS,'Unexpected native output element')
        attrs=sorted((key,value) for key,value in attrs if not(self.mask and key=='x-compo-id'))
        node=[tag,attrs,[]];self.stack[-1][2].append(node);self.stack.append(node)
    def handle_endtag(self,tag):need(len(self.stack)>1 and self.stack[-1][0]==tag,'Native HTML tag mismatch');self.stack.pop()
    def handle_data(self,data):
        children=self.stack[-1][2]
        if children and type(children[-1]) is str:children[-1]+=data
        else:children.append(data)
    def tree(self):
        need(len(self.stack)==1,'Unclosed rendered HTML')
        def clean(node):
            children=node[2];contains_elements=any(type(c) is list for c in children)
            return [node[0],node[1],[clean(c) if type(c) is list else c for c in children if type(c) is list or c.strip() or (not contains_elements and node[0] not in {'root','div','section','article','ul','ol'})]]
        return clean(self.root)


def html_tree(text,mask=False):
    parser=HTMLTree(mask);parser.feed(text);parser.close();return parser.tree()
