"""Independent adversarial review of the all-359 bounded-profile join.

Fixtures execute harmless local Python children. They do not qualify a language.
"""
import asyncio
import json
import os
from pathlib import Path
import signal
import tempfile
import textwrap
import unittest
from unittest.mock import patch

import coordinator


SOURCE = Path(os.environ.get('USL_SOURCE_ROOT', '/workspace/usl-v4.10.0-clean-test'))


def alive(pid):
    try:
        state = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[0]
        return state != 'Z'
    except FileNotFoundError:
        return False


class IndependentValidationTests(unittest.TestCase):
    def record(self):
        return {'catalog_id': 'example', 'scoped_profile_validated': True,
                'full_standard_qualified': False, 'exact_profile': 'Finite reviewed data profile',
                'cases': 1, 'native_executions': 1, 'usl_executions': 1,
                'open_obligations': ['Normative library coverage remains open']}

    def test_obligations_must_describe_actual_open_work(self):
        for field, value in [('open_obligations', [None]), ('open_obligations', ['']),
                             ('open_obligations', ['  ']), ('exact_profile', '  ')]:
            item = self.record(); item[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                coordinator.validate_records({'records': [item]}, ['example'])

    def test_nonrecord_or_nonstring_catalog_identity_is_rejected(self):
        for bad in [None, [], 1, 'example']:
            with self.subTest(record=bad), self.assertRaises(ValueError):
                coordinator.validate_records({'records': [bad]}, ['example'])
        item = self.record(); item['catalog_id'] = True
        with self.assertRaises(ValueError):
            coordinator.validate_records({'records': [item]}, [1])

    def test_all_executed_helper_source_extensions_are_pinned(self):
        helpers = ['native.rb', 'native.cjs', 'host.lua', 'host.R', 'source.agda', 'sample.lagda']
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in helpers: (root / name).write_text('original helper source\n')
            (root / 'dos_prefix.py').write_text('MZ = 1\nprint(MZ)\n')
            before = coordinator.source_files(root)
            self.assertTrue(set(helpers).issubset(before), sorted(set(helpers) - set(before)))
            self.assertIn('dos_prefix.py', before, 'A normal source identifier was mistaken for a PE executable')
            for name in helpers:
                (root / name).write_text('changed helper source\n')
                self.assertNotEqual(before[name], coordinator.source_files(root)[name])


class IndependentAsyncReview(unittest.IsolatedAsyncioTestCase):
    def fixture(self, base):
        root = base / 'source'; root.mkdir()
        previous = base / 'previous'; (previous / 'current-scope-results').mkdir(parents=True)
        for name in ['coordinator.py', 'coordinator.usl']:
            (root / name).write_bytes((Path(coordinator.__file__).parent / name).read_bytes())
        records = [{'catalog_id': f'lang-{i:03d}', 'family': 'fixture',
                    'original_catalog': True, 'validated_bounded_profile': False,
                    'full_plan_locator': 'fixture', 'next_implementation_step': 'Implement semantics',
                    'specific_semantic_focus': ['Review authoritative semantics'], 'external_dependencies': []}
                   for i in range(359)]
        baseline = previous / 'current-scope-results/CURRENT_SCOPE.json'
        baseline.write_text(json.dumps({'records': records, 'summary': {'validated_bounded_profiles': 247}}))
        registry = {'baseline_scope_sha256': coordinator.sha(baseline), 'families': []}
        return root, previous, registry

    async def test_invalid_output_path_has_no_source_side_effect(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / 'source'; root.mkdir()
            forbidden = root / 'must-not-be-created'
            with patch.object(coordinator, 'ROOT', root), self.assertRaises(ValueError):
                await coordinator.run(Path(temporary) / 'missing', SOURCE, forbidden)
            self.assertFalse(forbidden.exists(), 'Rejected output path mutated the immutable source tree')

    async def test_output_cannot_mutate_frozen_runtime_or_previous_release(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); root, previous, registry = self.fixture(base)
            source_root = base / 'runtime'; source_root.mkdir()
            (root / 'REGISTERED_FAMILIES.json').write_text(json.dumps(registry))
            for protected in [source_root, previous]:
                forbidden = protected / 'must-not-be-created'
                with self.subTest(protected=protected), patch.object(coordinator, 'ROOT', root), self.assertRaises(ValueError):
                    await coordinator.run(previous, source_root, forbidden)
                self.assertFalse(forbidden.exists(), 'Rejected output mutated an immutable input release')

    async def test_registry_cannot_execute_outside_registered_source_root(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); root, previous, registry = self.fixture(base)
            escaped = base / 'escaped'; escaped.mkdir(); (escaped / 'run.py').write_text('raise RuntimeError("outside root")\n')
            for directory in ['../escaped', str(escaped.resolve())]:
                registry['families'] = [{'directory': directory, 'catalog_ids': ['lang-000'],
                                         'source_sha256': coordinator.source_files(escaped)}]
                (root / 'REGISTERED_FAMILIES.json').write_text(json.dumps(registry))
                with self.subTest(directory=directory), patch.object(coordinator, 'ROOT', root), \
                        patch.object(asyncio, 'create_subprocess_exec', side_effect=AssertionError('Unsafe registry reached execution')), \
                        self.assertRaises(ValueError):
                    await coordinator.run(previous, SOURCE, base / 'output')

    async def test_registry_rejects_duplicate_directories_and_empty_assignments(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); root, previous, registry = self.fixture(base)
            family = root / 'family'; family.mkdir(); (family / 'run.py').write_text('pass\n')
            identity = coordinator.source_files(family)
            scenarios = [[{'directory': 'family', 'catalog_ids': [], 'source_sha256': identity}],
                         [{'directory': 'family', 'catalog_ids': ['lang-000'], 'source_sha256': identity},
                          {'directory': 'family', 'catalog_ids': ['lang-001'], 'source_sha256': identity}]]
            for jobs in scenarios:
                registry['families'] = jobs
                (root / 'REGISTERED_FAMILIES.json').write_text(json.dumps(registry))
                with self.subTest(jobs=jobs), patch.object(coordinator, 'ROOT', root), \
                        patch.object(asyncio, 'create_subprocess_exec', side_effect=AssertionError('Malformed registry reached execution')), \
                        self.assertRaises(ValueError):
                    await coordinator.run(previous, SOURCE, base / 'output')

    async def test_preexisting_output_symlink_cannot_redirect_logs_into_source(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); root, previous, registry = self.fixture(base)
            family = root / 'family'; family.mkdir(); (family / 'run.py').write_text('pass\n')
            registry['families'] = [{'directory': 'family', 'catalog_ids': ['lang-000'],
                                     'source_sha256': coordinator.source_files(family)}]
            (root / 'REGISTERED_FAMILIES.json').write_text(json.dumps(registry))
            output = base / 'output'; output.mkdir(); (output / 'family').symlink_to(family, target_is_directory=True)
            with patch.object(coordinator, 'ROOT', root), \
                    patch.object(asyncio, 'create_subprocess_exec', side_effect=AssertionError('Output symlink reached execution')), \
                    self.assertRaises(ValueError):
                await coordinator.run(previous, SOURCE, output)
            self.assertFalse((family / 'tests.log').exists(), 'Log write escaped output into immutable source')

    async def test_failure_cancels_and_reaps_sibling_process_group(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); root, previous, registry = self.fixture(base)
            parent_pid_file = base / 'parent.pid'; grandchild_pid_file = base / 'grandchild.pid'
            slow = root / 'slow'; slow.mkdir()
            (slow / 'test_slow.py').write_text('import unittest\nclass Test(unittest.TestCase):\n def test_ok(self): self.assertTrue(True)\n')
            (slow / 'run.py').write_text(textwrap.dedent(f'''\
                import os, pathlib, subprocess, sys, time
                pathlib.Path({str(parent_pid_file)!r}).write_text(str(os.getpid()))
                child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])
                pathlib.Path({str(grandchild_pid_file)!r}).write_text(str(child.pid))
                time.sleep(60)
                '''))
            broken = root / 'broken'; broken.mkdir()
            (broken / 'test_broken.py').write_text(textwrap.dedent(f'''\
                import pathlib, time, unittest
                class Test(unittest.TestCase):
                    def test_failure_after_sibling_started(self):
                        deadline = time.monotonic() + 10
                        while not pathlib.Path({str(grandchild_pid_file)!r}).exists() and time.monotonic() < deadline:
                            time.sleep(0.01)
                        self.fail('deliberate independent cleanup fixture')
                '''))
            (broken / 'run.py').write_text('raise RuntimeError("must not execute")\n')
            registry['families'] = [{'directory': name, 'catalog_ids': [f'lang-{i:03d}'],
                                     'source_sha256': coordinator.source_files(root / name)}
                                    for i, name in enumerate(['slow', 'broken'])]
            (root / 'REGISTERED_FAMILIES.json').write_text(json.dumps(registry))
            children = []
            original_spawn = asyncio.create_subprocess_exec
            async def tracked_spawn(*args, **kwargs):
                child = await original_spawn(*args, **kwargs); children.append(child); return child
            try:
                with patch.object(coordinator, 'ROOT', root), \
                        patch.object(coordinator, 'admission', return_value={'native_family_slots': 2}), \
                        patch.object(asyncio, 'create_subprocess_exec', tracked_spawn), \
                        self.assertRaises(ValueError):
                    await coordinator.run(previous, SOURCE, base / 'output')
                await asyncio.sleep(0.1)
                self.assertTrue(parent_pid_file.exists() and grandchild_pid_file.exists(), 'Cleanup fixture did not start its descendants')
                survivors = [int(path.read_text()) for path in [parent_pid_file, grandchild_pid_file]
                             if alive(int(path.read_text()))]
                self.assertEqual(survivors, [], 'Sibling cancellation left real descendant processes alive')
            finally:
                for pid_path in [parent_pid_file, grandchild_pid_file]:
                    if pid_path.exists():
                        try: os.kill(int(pid_path.read_text()), signal.SIGKILL)
                        except ProcessLookupError: pass
                for child in children:
                    if child.returncode is None:
                        try: child.kill()
                        except ProcessLookupError: pass
                    await child.wait()


if __name__ == '__main__':
    unittest.main()
