import sys
import unittest
from pathlib import Path
sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
from frontend import BOUND, ProfileError, emit, parse
import rd
from cases import language_cases, syntax
from run import native


class TypedNativeTests(unittest.TestCase):
    def test_actual_native_and_usl_heldout_intents(self):
        from usl_systems.language import Interpreter
        for language in ['wren','berry','moonscript']:
            for case in language_cases(language):
                if not case['heldout'] or case['expected_native_error']:continue
                with self.subTest(language=language,case=case['name']):
                    observed=native(language,case['source'])
                    generated=Interpreter().run(emit(parse(case['source'],language))).output.splitlines()
                    self.assertEqual(observed['returncode'],0)
                    self.assertEqual(observed['stdout'].splitlines(),case['expected_stdout'])
                    self.assertEqual(generated,case['expected_stdout'])

    def test_binding_types_and_observation_shadowing(self):
        for language in ['wren','berry','moonscript']:
            for source in [syntax(language,[('x',1)],['x = true'],['x']),syntax(language,[('print',2)],[],['3']),
                           syntax(language,[],[],['missing + 1']),syntax(language,[('System',2)],[],['3'])]:
                with self.subTest(language=language,source=source),self.assertRaises(ProfileError):parse(source,language)

    def test_line_separators_and_surface_syntax_fail_closed(self):
        bad={'wren':['var x = 1 var y = 2\nSystem.print(y)\n','var x = 1;\nSystem.print(x)\n'],
             'berry':['var x = 1 var y = 2\nprint(y)\n'],
             'moonscript':['var x = 1\nprint x\n','System.print(3)\n','x = 1 y = 2\nprint y\n','x = 1\vprint x\n']}
        for language,sources in bad.items():
            for source in sources:
                with self.subTest(language=language,source=source),self.assertRaises(ProfileError):parse(source,language)

    def test_only_bools_control_loops_and_branches(self):
        for language,source in [('wren','if (1) {\nSystem.print(3)\n}\n'),('berry','if 1\nprint(3)\nend\n'),('moonscript','if 1\n  print 3\n')]:
            with self.subTest(language=language),self.assertRaises(ProfileError):parse(source,language)

    def test_live_numeric_domain_guard(self):
        from usl_systems.language import Interpreter,USLError
        for language in ['wren','berry','moonscript']:
            with self.subTest(language=language),self.assertRaisesRegex(USLError,'profile:integer-domain'):
                Interpreter().run(emit(parse(syntax(language,[('x',BOUND)],[],['x + 1']),language)))

    def test_nontermination_rejected_by_actual_usl_budget(self):
        from usl_systems.language import Interpreter,LimitExceeded
        source='var x = 1\nwhile (true) {\nx = x + 0\n}\n'
        with self.assertRaises(LimitExceeded):Interpreter(max_ops=1000).run(emit(parse(source,'wren')))

    def test_rd_duplicate_nested_and_escaped_metadata_rejected(self):
        base='\\name{x}\n\\alias{x}\n\\title{T}\n\\description{D}\n'
        for source in [base+'\\name{y}\n',base+'\\alias{x}\n',base.replace('{D}','{\\strong{D}}'),base.replace('{D}','{A%comment\nD}')]:
            with self.subTest(source=source),self.assertRaises(ProfileError):rd.parse(source)


if __name__=='__main__':unittest.main()
