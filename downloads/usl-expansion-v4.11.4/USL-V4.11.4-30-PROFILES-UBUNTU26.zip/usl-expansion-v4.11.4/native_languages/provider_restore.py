"""Restore pinned public toolchains locally; no system or environment mutation."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import urllib.request

ROOT=Path(__file__).resolve().parent
PROVIDERS={
    'wren-build':('https://github.com/wren-lang/wren.git','4a18fc489f9ea3d253b20dd40f4cdad0d6bb40eb',{'src','LICENSE','README.md'}),
    'berry-build':('https://github.com/berry-lang/berry.git','65fce31732a9bdb91cb42cfc86e2b40f16c57514',{'src','default','tools','Makefile','LICENSE','README.md'}),
    'moon-build':('https://github.com/leafo/moonscript.git','c3f4e511c21afa7d2f9b6257f9d3805da65b0313',{'moonscript','LICENSE','README.md'}),
}
LPEG_SHA='429524c005adaa110a6381b77469b7c0047fe085e86929af3b2406d48e41d907'


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_identity():
    manifest=json.loads((ROOT/'provider-source-hashes.json').read_text());result={}
    for name,(_,commit,keep) in PROVIDERS.items():
        expected={rel:sha for rel,sha in manifest[name].items()
                  if Path(rel).parts[0] in keep and Path(rel).suffix not in {'.o','.d'}}
        for rel,sha in expected.items():
            path=ROOT/name/rel
            if not path.is_file() or digest(path)!=sha:raise ValueError('Pinned source identity mismatch: '+str(path))
        result[name]={'commit':commit,'verified_source_files':len(expected),'manifest_sha256':digest(ROOT/'provider-source-hashes.json')}
    return result


def ensure_sources():
    for name,(url,commit,keep) in PROVIDERS.items():
        target=ROOT/name
        if target.exists():continue
        with tempfile.TemporaryDirectory(prefix='usl-provider-',dir=ROOT) as temporary:
            path=Path(temporary)/'source'
            subprocess.run(['git','init','-q',str(path)],check=True)
            subprocess.run(['git','-C',str(path),'fetch','-q','--depth','1',url,commit],check=True)
            subprocess.run(['git','-C',str(path),'checkout','-q','--detach','FETCH_HEAD'],check=True)
            actual=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
            if actual!=commit:raise ValueError('Upstream commit identity mismatch')
            for item in path.iterdir():
                if item.name not in keep:shutil.rmtree(item) if item.is_dir() else item.unlink()
            shutil.move(str(path),str(target))
    return source_identity()


def main():
    identities=ensure_sources()
    subprocess.run(['gcc','-std=c99','-O2','-DWREN_OPT_META=0','-DWREN_OPT_RANDOM=0',
                    '-Iwren-build/src/include','-Iwren-build/src/vm','wren_host.c',
                    *[str(p.relative_to(ROOT)) for p in sorted((ROOT/'wren-build/src/vm').glob('*.c'))],
                    '-lm','-o','wren'],cwd=ROOT,check=True)
    # This build fits the admitted machine's available CPUs; it creates no
    # language-worker limit and is independent from the logical actor count.
    jobs=len(os.sched_getaffinity(0))
    try:
        quota,period=Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if quota!='max':jobs=min(jobs,max(1,int(quota)//int(period)))
    except (OSError,ValueError):pass
    subprocess.run(['make','-j'+str(jobs),'CFLAGS=-std=c99 -O2','LIBS=-lm -ldl'],cwd=ROOT/'berry-build',check=True)
    shared=ROOT/'lpeg/usr/lib/x86_64-linux-gnu/liblua5.4-lpeg.so.2.0.0'
    if not shared.is_file() or digest(shared)!='d58b3761f3acf86a94620638bf9028ed48207cfaa13dba05570519bd0b9e6e41':
        url='https://deb.debian.org/debian/pool/main/l/lua-lpeg/lua-lpeg_1.0.2-2_amd64.deb'
        data=urllib.request.urlopen(url,timeout=30).read()
        if hashlib.sha256(data).hexdigest()!=LPEG_SHA:raise ValueError('LPeg archive SHA256 mismatch')
        with tempfile.TemporaryDirectory(prefix='usl-lpeg-',dir=ROOT) as temporary:
            archive=Path(temporary)/'lpeg.deb';archive.write_bytes(data)
            subprocess.run(['dpkg-deb','-x',str(archive),str(ROOT/'lpeg')],check=True)
    identity={'source':identities,'LPeg_debian_archive_sha256':LPEG_SHA,'LPeg_shared_object_sha256':digest(shared),
              'wren_binary_sha256':digest(ROOT/'wren'),'berry_binary_sha256':digest(ROOT/'berry-build/berry'),
              'compiler_version':subprocess.check_output(['gcc','--version'],text=True).splitlines()[0],
              'externally_required':['installed Lua5.4 native host','installed R with tools package','C compiler, make, git, dpkg-deb and Python'],
              'platform':'Linux amd64; actual execution evidence must be rerun after restoration'}
    provider_output=ROOT/'providers';provider_output.mkdir(exist_ok=True)
    (provider_output/'provider-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    print(json.dumps(identity))


if __name__=='__main__':main()
