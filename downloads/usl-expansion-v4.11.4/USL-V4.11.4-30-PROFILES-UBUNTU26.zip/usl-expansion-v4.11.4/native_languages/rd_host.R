args <- commandArgs(trailingOnly=TRUE)
options(warn=2)
if (length(args)!=1L) stop('one Rd source path required')
document <- tools::parse_Rd(args[[1]], fragment=FALSE, warningCalls=FALSE)
if (length(attr(document,'parseStatus')) && attr(document,'parseStatus') != 0L) stop('invalid Rd syntax')
hex <- function(text) paste(sprintf('%02x',as.integer(charToRaw(enc2utf8(text)))),collapse='')
tags <- vapply(document,function(part) { t<-attr(part,'Rd_tag'); if(is.null(t)) '' else t },character(1))
for(required in c('\\name','\\title','\\description')) if(sum(tags==required)!=1L) stop('missing or duplicate required field')
if(sum(tags=='\\alias')<1L) stop('at least one alias required by this profile')
for (part in document) {
  tag <- attr(part,'Rd_tag')
  if (!is.null(tag) && tag %in% c('\\name','\\alias','\\title','\\description')) {
    if (!all(vapply(part,is.character,logical(1)))) stop('non-text Rd metadata outside profile')
    cat(substring(tag,2), '\t', hex(paste(unlist(part),collapse='')), '\n', sep='')
  }
}
