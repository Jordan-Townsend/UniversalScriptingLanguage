local base = require('moonscript.base')
local fn, err = base.loadfile(arg[1], { implicitly_return_root = false })
if not fn then io.stderr:write(tostring(err), '\n'); os.exit(1) end
local ok, value = pcall(fn)
if not ok then io.stderr:write(tostring(value), '\n'); os.exit(1) end
