#include <stdio.h>
#include <stdlib.h>
#include "wren.h"
static void write_text(WrenVM* vm, const char* text) {(void)vm; fputs(text, stdout);}
static void error_text(WrenVM* vm, WrenErrorType type, const char* module, int line, const char* text) {
  (void)vm; fprintf(stderr,"%d:%s:%d:%s\n",(int)type,module?module:"",line,text);
}
int main(int argc, char** argv) {
  if(argc!=2) return 64;
  FILE* f=fopen(argv[1],"rb"); if(!f) return 65;
  fseek(f,0,SEEK_END); long n=ftell(f); rewind(f);
  if(n<0 || n>65536) return 66;
  char* source=malloc((size_t)n+1); if(!source) return 67;
  if(fread(source,1,(size_t)n,f)!=(size_t)n) return 68;
  source[n]=0; fclose(f);
  WrenConfiguration config; wrenInitConfiguration(&config);
  config.writeFn=write_text; config.errorFn=error_text;
  WrenVM* vm=wrenNewVM(&config); WrenInterpretResult r=wrenInterpret(vm,"main",source);
  wrenFreeVM(vm); free(source); return r==WREN_RESULT_SUCCESS?0:1;
}
