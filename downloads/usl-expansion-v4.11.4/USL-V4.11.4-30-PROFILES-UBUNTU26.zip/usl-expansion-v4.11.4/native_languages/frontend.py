"""Actual parsers and typed lowering for three deliberately restricted profiles.

Each source uses its own original native syntax. Sharing occurs only after
parsing into a typed IR. Values are booleans or exact integers; every literal
and intermediate integer must lie in [-2**26,2**26]. No calls except the native
print operation, no imports, strings, objects, functions, or arbitrary effects.
"""
from pathlib import Path
import re
from lark import Lark, Transformer

BOUND = 2**26
RESERVED = set('as and break class construct continue def do elif else elseif end except export extends false for foreign from global if import in is local nil not null or raise return static super switch then this true try unless using var when while with System print'.split())


class ProfileError(ValueError):
    pass


EXPRESSIONS = r'''
?expr: sum (COMP sum)? -> comparison
?sum: product (ADD product)* -> chain
?product: unary (MUL unary)* -> chain
?unary: "-" unary -> negative
      | atom
?atom: NUMBER -> number
     | "true" -> true
     | "false" -> false
     | NAME -> variable
     | "(" expr ")"
COMP: "==" | "!=" | ">=" | "<=" | ">" | "<"
ADD: "+" | "-"
MUL: "*"
NUMBER: /[0-9]+/
NAME: /[a-zA-Z_][a-zA-Z_0-9]*/
_NL: /\r?\n/
%import common.WS_INLINE
%ignore WS_INLINE
'''

WREN = r'''
start: _NL* (statement _NL+)*
?statement: "var" NAME "=" expr -> declare
          | NAME "=" expr -> assign
          | _PRINT "(" expr ")" -> output
          | "if" "(" expr ")" block ("else" block)? -> condition
          | "while" "(" expr ")" block -> loop
block: "{" _NL+ (statement _NL+)* "}"
_PRINT.2: "System.print"
'''

BERRY = r'''
start: _NL* (statement _NL+)*
?statement: "var" NAME "=" expr -> declare
          | NAME "=" expr -> assign
          | "print" "(" expr ")" -> output
          | "if" expr block ("else" block)? "end" -> condition
          | "while" expr block "end" -> loop
block: _NL+ (statement _NL+)*
'''


class Tree(Transformer):
    def start(self, rows): return list(rows)
    def block(self, rows): return list(rows)
    def number(self, args): return ('constant', int(args[0]))
    def true(self, args): return ('constant', True)
    def false(self, args): return ('constant', False)
    def variable(self, args): return ('variable', str(args[0]))
    def negative(self, args): return ('negative', args[0])
    def chain(self, args):
        node = args[0]
        for i in range(1, len(args), 2): node = ('binary', str(args[i]), node, args[i+1])
        return node
    def comparison(self, args):
        return args[0] if len(args)==1 else ('compare', str(args[1]), args[0], args[2])
    def declare(self, args): return ('declare', str(args[0]), args[1])
    def assign(self, args): return ('assign', str(args[0]), args[1])
    def output(self, args): return ('output', args[0])
    def condition(self, args): return ('condition', args[0], args[1], args[2] if len(args)>2 else [])
    def loop(self, args): return ('loop', args[0], args[1])


PARSERS = {name:Lark(grammar+EXPRESSIONS,parser='lalr',transformer=Tree())
           for name,grammar in [('wren',WREN),('berry',BERRY)]}


def moon_surface(source):
    """Tokenize the selected indentation syntax, retaining expression text."""
    if any(c in source for c in '\v\f\x1c\x1d\x1e\x1f') or '\r' in source.replace('\r\n',''):
        raise ProfileError('MoonScript profile requires LF or CRLF line endings')
    output=[];opened=0;previous_header=False
    for line in source.splitlines():
        if not line.strip(): continue
        if '\t' in line: raise ProfileError('MoonScript profile requires spaces, not tabs')
        indent=len(line)-len(line.lstrip(' '))
        if indent%2: raise ProfileError('MoonScript indentation must use exact two-space levels')
        level=indent//2
        if level>opened or (previous_header and level!=opened):
            raise ProfileError('Missing or unexpected indented body')
        while opened>level: output.append('}');opened-=1
        text=line.strip();previous_header=False
        if text.startswith('if ') or text.startswith('while '):
            keyword,condition=text.split(' ',1)
            output.append(keyword+' ('+condition+') {');opened+=1;previous_header=True
        elif text=='else':
            if not output or output[-1]!='}':raise ProfileError('Orphan else')
            output[-1]+=' else {';opened+=1;previous_header=True
        elif text.startswith('print '): output.append('System.print('+text[6:]+')')
        elif re.match(r'^[A-Za-z_][A-Za-z_0-9]*\s*=(?!=)',text): output.append(text)
        else: raise ProfileError('Unsupported MoonScript statement syntax')
    if previous_header: raise ProfileError('Missing indented body')
    output+=['}']*opened
    return '\n'.join(output)+'\n'


def parse(source, language):
    if not isinstance(source,str) or len(source)>16384 or not source.isascii():
        raise ProfileError('ASCII source up to16384 characters required')
    if language not in {'wren','berry','moonscript'}: raise ProfileError('Unsupported dialect')
    try:
        normalized=moon_surface(source) if language=='moonscript' else source+'\n'
        nodes=PARSERS['wren' if language=='moonscript' else language].parse(normalized)
    except ProfileError: raise
    except Exception as error: raise ProfileError('Source syntax outside exact profile: '+str(error)[:160]) from error
    return lower(nodes, language)


def lower(nodes, language):
    bindings={};typed=[]
    def expression(node):
        kind=node[0]
        if kind=='constant':
            value=node[1]
            if type(value) is int and abs(value)>BOUND: raise ProfileError('Literal outside bounded exact-integer profile')
            return {'kind':'literal','type':'Bool' if type(value) is bool else 'ExactInt','value':value}
        if kind=='variable':
            if node[1] not in bindings: raise ProfileError('Unbound variable: '+node[1])
            name,typ=bindings[node[1]]
            return {'kind':'variable','type':typ,'name':name}
        if kind=='negative':
            value=expression(node[1])
            if value['type']!='ExactInt': raise ProfileError('Numeric negation requires ExactInt')
            return {'kind':'negative','type':'ExactInt','operand':value}
        left,right=expression(node[2]),expression(node[3])
        if left['type']!=right['type']: raise ProfileError('Mixed comparison or arithmetic types')
        if kind=='binary' and left['type']!='ExactInt': raise ProfileError('Arithmetic requires ExactInt')
        if kind=='compare' and node[1] not in {'==','!='} and left['type']!='ExactInt':
            raise ProfileError('Ordering requires ExactInt')
        return {'kind':kind,'type':'Bool' if kind=='compare' else 'ExactInt','operator':node[1],'left':left,'right':right}
    def statements(rows, depth=0):
        if depth>12: raise ProfileError('Control nesting limit12')
        result=[]
        for row in rows:
            kind=row[0]
            if kind in {'declare','assign'}:
                name=row[1];value=expression(row[2]);declaration=kind=='declare' or language=='moonscript' and name not in bindings
                if name in RESERVED: raise ProfileError('Reserved syntax or observation binding: '+name)
                if declaration:
                    if depth: raise ProfileError('Nested declarations excluded; blocks may update existing bindings')
                    if name in bindings: raise ProfileError('Duplicate declaration')
                    bindings[name]=('v'+str(len(bindings)),value['type'])
                    if len(bindings)>32: raise ProfileError('Binding limit32')
                if name not in bindings: raise ProfileError('Assignment requires an existing binding')
                target,typ=bindings[name]
                if typ!=value['type']: raise ProfileError('Assignment changes declared type')
                result.append({'kind':'declare' if declaration else 'assign','name':target,'type':typ,'value':value})
            elif kind=='output':result.append({'kind':'output','value':expression(row[1])})
            else:
                condition=expression(row[1])
                if condition['type']!='Bool': raise ProfileError('Control requires Bool')
                result.append({'kind':kind,'condition':condition,'body':statements(row[2],depth+1),
                               'otherwise':statements(row[3],depth+1) if kind=='condition' else []})
        return result
    typed=statements(nodes)
    return {'schema':'usl.bounded-imperative.typed-IR.v1','language':language,'numeric_domain':[-BOUND,BOUND],
            'maximum_live_bindings':32,'maximum_control_nesting':12,'statements':typed}


def emit(ir):
    lines=['function exact(n):','    assert abs(n) <= '+str(BOUND)+', "profile:integer-domain"','    return n']
    def expression(row):
        kind=row['kind']
        if kind=='literal':return repr(row['value'])
        if kind=='variable':return row['name']
        if kind=='negative':return 'exact(-('+expression(row['operand'])+'))'
        text='('+expression(row['left'])+' '+row['operator']+' '+expression(row['right'])+')'
        return 'exact('+text+')' if kind=='binary' else text
    def statements(rows,depth=0):
        if not rows:lines.append('    '*depth+'pass')
        for row in rows:
            prefix='    '*depth;kind=row['kind']
            if kind in {'declare','assign'}:lines.append(prefix+('let ' if kind=='declare' else '')+row['name']+' = '+expression(row['value']))
            elif kind=='output':
                value=expression(row['value'])
                lines.append(prefix+'print('+('("true" if '+value+' else "false")' if row['value']['type']=='Bool' else value)+')')
            else:
                lines.append(prefix+('if ' if kind=='condition' else 'while ')+expression(row['condition'])+':')
                statements(row['body'],depth+1)
                if kind=='condition' and row['otherwise']:
                    lines.append(prefix+'else:');statements(row['otherwise'],depth+1)
    statements(ir['statements'])
    return '\n'.join(lines)+'\n'
