"""Restricted Rd metadata processing contract, not executable R code."""
import re
from frontend import ProfileError


def parse(source):
    if not isinstance(source,str) or not source.isascii() or len(source)>16384:
        raise ProfileError('Rd profile requires ASCII metadata up to16384 characters')
    position=0;result={'name':None,'aliases':[],'title':None,'description':None}
    while position<len(source):
        whitespace=re.match(r'[ \t\r\n]*',source[position:]);position+=len(whitespace[0])
        if position==len(source):break
        command=re.match(r'\\(name|alias|title|description)\{',source[position:])
        if not command:raise ProfileError('Unsupported Rd macro or malformed metadata')
        position+=len(command[0]);end=source.find('}',position)
        if end<0:raise ProfileError('Unclosed Rd metadata argument')
        text=source[position:end];position=end+1;tag=command[1]
        if any(c in text for c in '{}\\%') or any(ord(c)<32 and c not in '\t\r\n' for c in text):
            raise ProfileError('Nested macros, escapes and comments excluded from plain-text metadata profile')
        if not text.strip():raise ProfileError('Empty metadata field excluded')
        if tag in {'name','alias'} and not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.]*',text):
            raise ProfileError('Name and alias must be plain Rd identifiers')
        if tag=='alias':
            if text in result['aliases']:raise ProfileError('Duplicate alias')
            result['aliases'].append(text)
        elif result[tag] is not None:raise ProfileError('Duplicate metadata singleton')
        else:result[tag]=text
    if any(result[k] is None for k in ['name','title','description']) or not result['aliases']:
        raise ProfileError('Profile requires name, title, description and at least one alias')
    return {'schema':'usl.rd.plain-metadata-IR.v1','type':'RdDocumentMetadata','fields':result}


def emit(ir):
    return 'let result = '+repr(ir['fields'])+'\n'
