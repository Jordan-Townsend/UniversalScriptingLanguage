This tranche adds four restricted, native-validated profiles: `wren`, `berry`,
`moonscript`, and the `rd` documentation-processing format. It adds no full
standard qualifications.

Activate the existing USL environment, then run:

```bash
source /workspace/.onboarding/activate-usl.sh
python provider_restore.py
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
python -m unittest discover -s . -p 'test_*.py'
```

Wren 0.4.0, Berry 1.1.0 and MoonScript 0.5.0 use pinned public upstream commits.
Their independent source parsers lower into a shared typed IR and executable
`.usl`. Native originals and generated USL check polynomial arithmetic,
precedence, signed boundaries, Boolean comparisons, mutable bindings, if/else,
while-loop summation, unchanged sibling bindings and canonical output. Separate
negative cases exercise syntax, undefined names and type errors. Reserved
observation bindings cannot shadow the actual native print operation.

The executable profiles accept ASCII source up to 16,384 characters, one statement
per line, two-space MoonScript indentation, at most 32 top-level bindings and 12
control nesting levels. Blocks update existing bindings; nested declarations are
excluded. Every literal and intermediate integer must remain within ±2²⁶, which
is exact in all three native number representations. Generated execution rejects
domain violations and terminates at its real operation/time budgets. A domain
rejection is not presented as a native language error. Optional Wren meta/random
modules are disabled in the embedded host.

The Rd profile uses actual `tools::parse_Rd` from installed R. It preserves the
name, ordered aliases, title and multiline description in typed metadata and
generated USL data. This contract requires those fields and excludes other
sections, escapes, nested macros and comments. It processes documentation; it
does not execute Rd as a programming language.

`results/results.json` retains native return codes, stdout/stderr, independent
expected results, typed IR, generated source, operation counts, tool/source and
reference hashes, heldout membership and open obligations. No execution evidence
is replayed. `provider_restore.py` verifies pinned source hashes before local
builds and a SHA256-pinned Debian LPeg archive before extraction. Installed Lua
5.4, R/tools, compiler/make/git/dpkg-deb and the existing USL dependencies remain
host prerequisites. Linux amd64 is the qualified platform.

Full grammars, functions, closures, objects, libraries, general numeric/string
behavior, modules, effects, exceptions, concurrency, ABI/platform matrices,
upstream conformance, universal intent proofs and independent profile review
remain open. The small tests establish these precise profiles and inputs only.
