"""Fresh native and generated-USL validation for Wren, Berry, MoonScript and Rd."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

from cases import language_cases, rd_cases, syntax
from frontend import BOUND, ProfileError, emit, parse
import rd

ROOT=Path(__file__).resolve().parent


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(language, path):
    env=dict(os.environ)
    env['LUA_PATH']=str(ROOT/'moon-build/?.lua')+';'+str(ROOT/'moon-build/?/init.lua')+';;'
    env['LUA_CPATH']=str(ROOT/'lpeg/usr/lib/x86_64-linux-gnu/lua/5.4/?.so')+';;'
    commands={'wren':[str(ROOT/'wren'),str(path)],'berry':[str(ROOT/'berry-build/berry'),str(path)],
              'moonscript':['lua',str(ROOT/'moon_host.lua'),str(path)],'rd':['Rscript',str(ROOT/'rd_host.R'),'--args',str(path)]}
    return commands[language],env


def native(language, source, timeout=4):
    with tempfile.TemporaryDirectory(prefix='usl-language-') as directory:
        path=Path(directory)/('document.Rd' if language=='rd' else 'program.'+language)
        path.write_text(source,encoding='ascii')
        argv,env=command(language,path)
        result=subprocess.run(argv,capture_output=True,text=True,env=env,timeout=timeout)
    return {'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
            'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'fresh_native_execution':True}


def tool_identity(language):
    paths={'wren':[ROOT/'wren',ROOT/'wren-build/src/include/wren.h'],
           'berry':[ROOT/'berry-build/berry',ROOT/'berry-build/src/berry.h',ROOT/'berry-build/default/berry_conf.h'],
           'moonscript':[Path(shutil.which('lua')).resolve(),ROOT/'moon-build/moonscript/parse.lua',ROOT/'lpeg/usr/lib/x86_64-linux-gnu/liblua5.4-lpeg.so.2.0.0'],
           'rd':[Path('/workspace/.onboarding/sysroot/usr/lib/R/bin/exec/R'),Path('/workspace/.onboarding/sysroot/usr/lib/R/library/tools/R/tools.rdb')]}[language]
    return {str(p):digest(p) for p in paths}


def qualify_language(language, output):
    from usl_systems.language import Interpreter, USLError
    rows=[]
    for case in language_cases(language):
        observed=native(language,case['source']);row={**case,'native':observed}
        try:
            ir=parse(case['source'],language);generated=emit(ir)
            target=Interpreter(max_ops=200000,timeout=2).run(generated)
            row.update({'typed_IR':ir,'generated_USL':generated,'generated_USL_sha256':hashlib.sha256(generated.encode()).hexdigest(),
                        'generated_stdout':target.output.splitlines(),'USL_operations':target.operations,'USL_executions':1})
        except (ProfileError,USLError) as error:row.update({'frontend_or_USL_error':type(error).__name__+': '+str(error),'USL_executions':0})
        row['passed']=(observed['returncode']!=0 and 'frontend_or_USL_error' in row) if case['expected_native_error'] else \
            observed['returncode']==0 and row.get('generated_stdout')==observed['stdout'].splitlines()==case['expected_stdout']
        rows.append(row)
    # These are restricted-domain rejections, not assertions of native errors.
    restrictions=[]
    for name,source in [
        ('outside-literal-domain',syntax(language,[('x',BOUND+1)],[],['x'])),
        ('type-changing-assignment',syntax(language,[('x',1)],['x = true'],['x'])),
        ('observation-binding-shadow',syntax(language,[('print',2)],[],['3'])),
    ]:
        try:parse(source,language);restrictions.append({'name':name,'passed':False})
        except ProfileError as error:restrictions.append({'name':name,'passed':True,'profile_rejection':str(error)})
    overflow_source=syntax(language,[('x',BOUND)],[],['x + 1'])
    overflow_native=native(language,overflow_source)
    try:
        Interpreter(max_ops=200000,timeout=2).run(emit(parse(overflow_source,language)))
        overflow_rejected=False
    except USLError as error:overflow_rejected='profile:integer-domain' in str(error)
    restrictions.append({'name':'intermediate-domain-bound','passed':overflow_rejected and overflow_native['returncode']==0,
                         'native_outside_contract':overflow_native,'native_output_does_not_extend_qualified_domain':True})
    record={'catalog_id':language,'scoped_profile_validated':all(r['passed'] for r in rows+restrictions),'full_standard_qualified':False,
            'profile_kind':'code-expression','exact_profile':{
                'host':{'wren':'Wren0.4.0 embedded C host; optional meta/random modules disabled','berry':'Berry1.1.0 commit65fce317; default64-bit integer configuration',
                        'moonscript':'MoonScript0.5.0 commitc3f4e511 with installed Lua5.4 and LPeg1.0.2'}[language],
                'semantics':['ASCII source','Bool and exact bounded integers','declarations and existing-binding assignment','+,-,* and unary negation','==,!=,<,<=,>,>=','if/else and while','canonical native text output'],
                'limits':{'source_characters':16384,'literal_and_every_intermediate_integer':[-BOUND,BOUND],'live_bindings':32,'control_nesting':12,'USL_operations':200000,'USL_seconds':2,'native_process_seconds':4},
                'scope':'Top-level lexical bindings only; blocks may update existing bindings. Original syntax parsed separately before common typedIR. Unsupported source rejected; loops remain subject to execution resource limits.'},
            'cases':len(rows),'native_executions':len(rows)+1,'usl_executions':sum(r['USL_executions'] for r in rows)+1,
            'independent_intent_cases':len(rows),'heldout_cases':sum(r['heldout'] for r in rows),
            'tool_hashes':tool_identity(language),'reference_hashes':json.loads((ROOT/'references.json').read_text())[language+'_reference'],
            'open_obligations':['complete grammar and type/dynamic semantics','functions, closures, objects, modules and libraries','remaining number/string/container behavior and native ABI','effects, exceptions, concurrency and platform matrix','upstream conformance and universal intent/equivalence proofs','independent profile review'],
            'records':rows,'profile_restrictions':restrictions}
    record['profile_contract']=record['exact_profile']
    record['exact_profile']=record['profile_contract']['host']+'; '+', '.join(record['profile_contract']['semantics'])+'; '+record['profile_contract']['scope']
    output.mkdir(parents=True,exist_ok=True);(output/(language+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    return record


def qualify_rd(output):
    from usl_systems.language import Interpreter
    rows=[]
    for case in rd_cases():
        observed=native('rd',case['source']);row={**case,'native':observed,'USL_executions':0}
        try:
            ir=rd.parse(case['source']);generated=rd.emit(ir)
            result=Interpreter().run(generated).variables['result'];native_fields={'name':None,'aliases':[],'title':None,'description':None}
            if observed['returncode']==0:
                for line in observed['stdout'].splitlines():
                    tag,value=line.split('\t');text=bytes.fromhex(value).decode('utf8')
                    if tag=='alias':native_fields['aliases'].append(text)
                    else:native_fields[tag]=text
            row.update({'typed_IR':ir,'generated_USL':generated,'generated_fields':result,'native_fields':native_fields,'USL_executions':1})
        except ProfileError as error:row['frontend_error']=str(error)
        row['passed']=(observed['returncode']!=0 and 'frontend_error' in row) if case['expected_native_error'] else \
            observed['returncode']==0 and row.get('generated_fields')==row.get('native_fields')==case['expected']
        rows.append(row)
    record={'catalog_id':'rd','scoped_profile_validated':all(r['passed'] for r in rows),'full_standard_qualified':False,'profile_kind':'category-processing',
            'exact_profile':'Installed R tools::parse_Rd with warnings treated as errors; plain ASCII name, ordered aliases, title and multiline description. No nested macros, escapes, comments or other sections. This processes documentation; it is not an executable-language claim.',
            'cases':len(rows),'native_executions':len(rows),'usl_executions':sum(r['USL_executions'] for r in rows),
            'independent_intent_cases':len(rows),'heldout_cases':sum(r['heldout'] for r in rows),
            'tool_hashes':tool_identity('rd'),'reference_hashes':json.loads((ROOT/'references.json').read_text())['rd_reference'],
            'open_obligations':['remaining Rd macros and complete grammar','escaping, encodings and conditional sections','R code examples and package linking','full format validation and version matrix','universal contract equivalence and independent review'],'records':rows}
    output.mkdir(parents=True,exist_ok=True);(output/'rd.json').write_text(json.dumps(record,indent=2)+'\n')
    return record


def admission():
    cpus=len(os.sched_getaffinity(0))
    try:
        quota,period=Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if quota!='max':cpus=min(cpus,max(1,math.ceil(int(quota)/int(period))))
    except (OSError,ValueError):pass
    return {'cpu_admitted_tranche_jobs':cpus,'ready_language_tranches':4,'fixed_virtual_worker_cap':None}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();sys.path.insert(0,str(args.source_root.resolve()))
    args.output.mkdir(parents=True,exist_ok=True);started=time.perf_counter();resources=admission()
    with ThreadPoolExecutor(max_workers=min(4,resources['cpu_admitted_tranche_jobs'])) as workers:
        futures=[workers.submit(qualify_language,language,args.output) for language in ['wren','berry','moonscript']]
        futures.append(workers.submit(qualify_rd,args.output))
        records=[f.result() for f in futures]
    report={'schema':'usl.native-language-tranche.v1','passed':all(r['scoped_profile_validated'] for r in records),
            'records':records,'source_sha256':{p.name:digest(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.py','.lua','.R','.c','.json'}},
            'resource_admission':resources,'seconds':time.perf_counter()-started,'full_standard_qualifications':0,'execution_evidence_replayed':False}
    (args.output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'seconds':report['seconds'],'records':[{k:r[k] for k in ['catalog_id','scoped_profile_validated','cases','native_executions','usl_executions']} for r in records]}))
    if not report['passed']:raise SystemExit(1)


if __name__=='__main__':main()
