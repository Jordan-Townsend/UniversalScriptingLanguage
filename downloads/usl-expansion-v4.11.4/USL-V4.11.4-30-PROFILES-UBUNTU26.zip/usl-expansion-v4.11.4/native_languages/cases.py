"""Independent intent inputs and contracts; never import frontend expressions."""


def syntax(language, declarations, body, outputs):
    lines=[]
    for name,value in declarations:
        lines.append(('' if language=='moonscript' else 'var ')+name+' = '+str(value))
    for row in body:
        lines.append(row)
    for expression in outputs:
        lines.append('System.print('+expression+')' if language=='wren' else 'print('+expression+')' if language=='berry' else 'print '+expression)
    return '\n'.join(lines)+'\n'


def language_cases(language):
    cases=[]
    def add(name,source,expected,contract,heldout=False):
        cases.append({'name':name,'source':source,'expected_stdout':[str(x).lower() if type(x)is bool else str(x) for x in expected],
                      'intent_contract':contract,'heldout':heldout,'expected_native_error':False})
    numbers=[-31,-7,-1,0,1,2,9,17,31]
    for n in numbers:
        add('polynomial-'+str(n),syntax(language,[('x',n)],[],['x * x + 3 * x - 2']),
            [n*n+3*n-2],'For input x, print x²+3x−2 using ordinary integer arithmetic')
        add('precedence-'+str(n),syntax(language,[('x',n)],[],['-(x + 2) * 3','x - 2 * 3']),
            [-(n+2)*3,n-6],'Parentheses and unary negation bind before multiplication; multiplication before subtraction')
        add('comparison-'+str(n),syntax(language,[('x',n)],[],['x < 0','x == 0','x != 0','x >= 2']),
            [n<0,n==0,n!=0,n>=2],'Typed Boolean comparisons print canonical native true/false text')
    for n in range(14):
        body={'wren':['while (n > 0) {','total = total + n','n = n - 1','}'],
              'berry':['while n > 0','total = total + n','n = n - 1','end'],
              'moonscript':['while n > 0','  total = total + n','  n = n - 1']}[language]
        add('triangular-'+str(n),syntax(language,[('n',n),('total',0)],body,['total','n']),
            [n*(n+1)//2,0],'Loop sums integers1..n; closed-form sum and final counter checked independently',n in {8,11,13})
    for n in range(-12,13):
        body={'wren':['if (x < 0) {','x = -x','} else {','x = x + 5','}'],
              'berry':['if x < 0','x = -x','else','x = x + 5','end'],
              'moonscript':['if x < 0','  x = -x','else','  x = x + 5']}[language]
        add('branch-'+str(n),syntax(language,[('x',n),('unchanged',47)],body,['x','unchanged']),
            [-n if n<0 else n+5,47],'Exactly one branch updates x; independent sibling binding remains47',n in {-11,-5,4,12})
    for n in [-(2**26),-(2**26)+1,2**26-1,2**26]:
        add('exact-boundary-'+str(n),syntax(language,[('x',n)],[],['x','-x','x == x']),
            [n,-n,True],'Endpoint literals and negation remain exact within the declared integer domain')
    for name,expression in [('unbound','missing + 1'),('type-error','true + 1'),('syntax-error','(1 +')]:
        cases.append({'name':name,'source':syntax(language,[],[],[expression]),'expected_native_error':True,
                      'intent_contract':'Original native host and frontend must reject '+name,'heldout':True})
    return cases


def rd_cases():
    cases=[]
    for n in range(16):
        name='example'+str(n);aliases=[name,'alias.'+str(n)]
        title='Independent metadata '+str(n);description='Line one '+str(n)+'.\nLine two with ordinary text.'
        fields=[('name',name),('alias',aliases[0]),('alias',aliases[1]),('title',title),('description',description)]
        if n%2: fields=[fields[3],fields[0],fields[4],fields[1],fields[2]]
        source='\n'.join('\\'+key+'{'+value+'}' for key,value in fields)+'\n'
        cases.append({'name':'metadata-'+str(n),'source':source,'expected':{'name':name,'aliases':aliases,'title':title,'description':description},
                      'expected_native_error':False,'heldout':n in {7,11,15},
                      'intent_contract':'Recover exact named metadata, alias order and multiline text regardless of singleton section order'})
    cases += [
        {'name':'unclosed-brace','source':'\\name{broken\n','expected_native_error':True,'heldout':True,'intent_contract':'Reject unclosed macro argument'},
        {'name':'required-fields','source':'\\name{incomplete}\n','expected_native_error':True,'heldout':True,'intent_contract':'Reject missing title, description and aliases under this processing contract'}]
    return cases
