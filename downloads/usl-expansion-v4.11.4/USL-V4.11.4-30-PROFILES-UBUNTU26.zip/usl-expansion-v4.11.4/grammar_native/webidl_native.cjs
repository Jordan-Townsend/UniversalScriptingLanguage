const fs = require('fs');
const path = require('path');
const webidl = require('./_tools/webidl2/dist/webidl2.js');
const conversions = require('./_tools/webidl-conversions/lib/index.js');
const cases = JSON.parse(fs.readFileSync(0, 'utf8'));
const result = [];
for (const item of cases) {
  try {
    const tree = webidl.parse(item.source);
    const problems = webidl.validate(tree);
    if (problems.length) throw new TypeError('WebIDL validation: ' + problems.map(p => p.ruleName).join(','));
    const arg = tree[0].members[0].arguments[0];
    const typ = arg.idlType.idlType;
    const attrs = arg.extAttrs.map(a => a.name);
    let value = item.value;
    if (value && typeof value === 'object' && value.special) value = {nan: NaN, infinity: Infinity, '-infinity': -Infinity}[value.special];
    const converted = conversions[typ](value, {clamp: attrs.includes('Clamp'), enforceRange: attrs.includes('EnforceRange')});
    const observed = typeof converted === 'string' ? Array.from({length: converted.length}, (_, i) => converted.charCodeAt(i)) : converted;
    result.push({accepted: true, observed, type: typ, attributes: attrs, parsedDefinitions: tree.length});
  } catch (error) {
    result.push({accepted: false, error: error.name + ': ' + error.message});
  }
}
process.stdout.write(JSON.stringify(result));
