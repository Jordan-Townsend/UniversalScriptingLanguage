#!/usr/bin/env python3
"""Scope-boundary and precedence regressions; run.py supplies native integration."""
import argparse,pathlib,sys,unittest
import bst_profile,peg_profile,swig_profile,webidl_profile
from run import BST_HEADER,SWIG_SOURCE

Interpreter=None
USLError=None

class ScopeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        global Interpreter,USLError
        from usl_systems.language import Interpreter,USLError

    def evaluate(self,source):
        return Interpreter(max_ops=500000,timeout=8,max_output=10000,max_depth=50).run(source).variables['result']

    def test_peg_lookahead_repetition_precedence(self):
        for grammar,text,expected in [
            ('start = &"a"* "a"*','',True),
            ('start = &"a"* "a"*','aaa',True),
            ('start = &"a"* "a"*','b',False),
            ('start = !"a"? "b"*','',False),
            ('start = &"a"? "b"*','bbb',True),
        ]:
            with self.subTest(grammar=grammar,text=text):
                self.assertIs(self.evaluate(peg_profile.translate(grammar,text)),expected)

    def test_peg_rejects_unqualified_and_nonterminating_grammars(self):
        for grammar in ['start = start','start = next\nnext = start','start = ""*','start = ("a"?)+','start = absent','start = ~"[a-z]"','start = "é"']:
            with self.subTest(grammar=grammar),self.assertRaises(peg_profile.Unsupported):peg_profile.parse(grammar)
        with self.assertRaises(peg_profile.Unsupported):peg_profile.translate('start = "a"*','a'*129)

    def test_bst_rejects_unsupported_input_before_generation(self):
        entry={'cite':'item','type':'misc','fields':{'title':'valid'}}
        for suffix in ['FUNCTION {cycle} { cycle }\nREAD','FUNCTION {bad} { absent }\nREAD']:
            with self.subTest(suffix=suffix),self.assertRaises(bst_profile.Unsupported):bst_profile.translate(BST_HEADER+suffix,[entry])
        for title in ['x'*41,'brace{','TeX\\name','nonasciié']:
            with self.subTest(title=title),self.assertRaises(bst_profile.Unsupported):
                bst_profile.translate(BST_HEADER+'READ',[{**entry,'fields':{'title':title}}])

    def test_swig_rejects_overflow_and_unsupported_bindings(self):
        for args in [[1.5,2],['1',2],[1_000_001,0],[0],[]]:
            with self.subTest(args=args),self.assertRaises((swig_profile.Unsupported,TypeError)):
                swig_profile.translate(SWIG_SOURCE,'add',args)
        for source in ['%module x %inline %{ long f(long x) { return x*x*x; } %}',
                       '%module x %inline %{ long f(long *x) { return x; } %}',
                       '%module x %inline %{ long f(long x) { return x / 2; } %}']:
            with self.subTest(source=source),self.assertRaises(swig_profile.Unsupported):swig_profile.parse(source)

    def test_webidl_nonfinite_and_scalar_domain_boundaries(self):
        def source(typ,attribute=''):
            return '[Exposed=Window] interface Converter { '+typ+' convert('+attribute+typ+' value); };'
        for value,expected in [(float('nan'),0),(float('inf'),127),(-float('inf'),-128)]:
            self.assertEqual(self.evaluate(webidl_profile.translate(source('byte','[Clamp] '),value)),expected)
            self.assertEqual(self.evaluate(webidl_profile.translate(source('byte'),value)),0)
            with self.assertRaises(USLError):self.evaluate(webidl_profile.translate(source('byte','[EnforceRange] '),value))
        for declaration,value in [(source('long'),2**40+1),(source('long'),'123'),(source('DOMString'),'x'*129),(source('boolean'),{}),(source('long long'),0),(source('boolean','[Clamp] '),1)]:
            with self.subTest(declaration=declaration,value=value),self.assertRaises(webidl_profile.Unsupported):webidl_profile.translate(declaration,value)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source-root',required=True);args=parser.parse_args()
    sys.path.insert(0,str(pathlib.Path(args.source_root).resolve()))
    from usl_systems.language import Interpreter,USLError
    unittest.main(argv=[sys.argv[0]],verbosity=2)
