#!/usr/bin/env python3
"""Restore pinned family providers without changing frozen source/provenance.

System BibTeX, GCC, Node, CPython headers and regex are retained prerequisites.
Downloaded files and the new restore receipt live only under _tools/.
"""
from __future__ import annotations
import argparse,base64,hashlib,json,lzma,os,pathlib,shutil,subprocess,sys,sysconfig,tarfile,tempfile,time,urllib.request

ROOT=pathlib.Path(__file__).resolve().parent
INDEX_SHA256='7778d3e3f303b7ddb8ce0fe7c8d57473a076c6bf2e8f241f75421d2396352498'
INDEX_SIZE=9678380
INDEX_URL='https://deb.debian.org/debian/dists/trixie/main/binary-amd64/by-hash/SHA256/'+INDEX_SHA256

def digest(path,algorithm='sha256'):
    h=hashlib.new(algorithm)
    with pathlib.Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def command(args):
    p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    if p.returncode:raise RuntimeError(f'command failed: {args!r}\n{p.stderr}')
    return {'command':args,'stdout':p.stdout,'stderr':p.stderr,'returncode':p.returncode}

def fetch(url,path,sha256,size):
    if path.exists() and path.stat().st_size==size and digest(path)==sha256:return
    part=path.with_name(path.name+'.part')
    try:
        with urllib.request.urlopen(url,timeout=45) as response,part.open('wb') as output:
            count=0
            while chunk:=response.read(1024*1024):
                count+=len(chunk)
                if count>size:raise ValueError('download exceeds pinned length: '+url)
                output.write(chunk)
        if part.stat().st_size!=size or digest(part)!=sha256:raise ValueError('download identity mismatch: '+url)
        part.replace(path)
    finally:part.unlink(missing_ok=True)

def verify_debian(destination,packages):
    frozen=json.loads((ROOT/'DEBIAN_SIGNATURE_RECEIPT.json').read_text())
    release=ROOT/'references/debian-trixie-InRelease'
    keyring=pathlib.Path(frozen['keyring'])
    if digest(release)!=frozen['inrelease_sha256']:raise ValueError('frozen InRelease changed')
    if digest(keyring)!=frozen['keyring_sha256']:raise ValueError('retained Debian archive keyring differs from frozen verification host')
    with tempfile.TemporaryDirectory(prefix='grammar-gpg-',dir=destination) as home:
        os.chmod(home,0o700)
        verification=command([shutil.which('gpg'),'--batch','--homedir',home,'--no-default-keyring','--keyring',str(keyring),'--status-fd','1','--verify',str(release)])
    if '[GNUPG:] VALIDSIG ' not in verification['stdout']:raise ValueError('no valid Debian archive signature')
    section=release.read_text().split('\nSHA256:\n',1)[1].split('\n-----BEGIN PGP SIGNATURE-----',1)[0]
    identities={line.split()[2]:(line.split()[0],int(line.split()[1])) for line in section.splitlines() if len(line.split())==3}
    if identities.get('main/binary-amd64/Packages.xz')!=(INDEX_SHA256,INDEX_SIZE):raise ValueError('pinned compressed index absent from signed release')
    if identities.get('main/binary-amd64/Packages')!=(frozen['packages_sha256'],frozen['packages_size']):raise ValueError('uncompressed index identity changed')
    index=destination/'debian-Packages.xz';fetch(INDEX_URL,index,INDEX_SHA256,INDEX_SIZE)
    # Stream the full authenticated index, retaining just the selected stanzas.
    h=hashlib.sha256();size=0;paragraph=[];found={}
    def inspect(lines):
        data={}
        for raw in lines:
            line=raw.decode('utf8').rstrip('\n')
            if line and not line.startswith(' ') and ': ' in line:
                key,value=line.split(': ',1);data[key]=value
        for item in packages:
            if data.get('SHA256')==item['sha256']:
                if data.get('Filename')!=item['url'].split('/debian/',1)[1] or int(data.get('Size','0'))!=item['size']:
                    raise ValueError('Debian package stanza mismatch')
                found[item['name']]=data
    with lzma.open(index,'rb') as stream:
        for line in stream:
            h.update(line);size+=len(line)
            if line==b'\n':inspect(paragraph);paragraph=[]
            else:paragraph.append(line)
        if paragraph:inspect(paragraph)
    if h.hexdigest()!=frozen['packages_sha256'] or size!=frozen['packages_size']:raise ValueError('full Debian Packages identity mismatch')
    if set(found)!={p['name'] for p in packages}:raise ValueError('pinned provider absent from authenticated Packages')
    return {'index_url':INDEX_URL,'compressed_sha256':INDEX_SHA256,'packages_sha256':h.hexdigest(),'inrelease_sha256':digest(release),'keyring_sha256':digest(keyring),'gpg':verification,'selected_packages':found}

def extract_npm(archive,target):
    if target.exists():shutil.rmtree(target)
    target.mkdir()
    with tarfile.open(archive,'r:gz') as bundle:
        for member in bundle.getmembers():
            path=pathlib.PurePosixPath(member.name)
            if not path.parts or path.parts[0]!='package' or '..' in path.parts or member.issym() or member.islnk():raise ValueError('unsafe npm archive entry')
            relative=pathlib.Path(*path.parts[1:])
            if not relative.parts:continue
            output=target/relative
            if member.isdir():output.mkdir(parents=True,exist_ok=True)
            elif member.isfile():
                output.parent.mkdir(parents=True,exist_ok=True)
                with bundle.extractfile(member) as source,output.open('wb') as dest:shutil.copyfileobj(source,dest)
            else:raise ValueError('non-file npm archive entry')

def prerequisites():
    required=['bibtex','gcc','node','gpg','dpkg-deb']
    missing=[name for name in required if not shutil.which(name)]
    if not (pathlib.Path(sysconfig.get_paths()['include'])/'Python.h').is_file():missing.append('CPython development headers')
    try:import regex
    except ImportError:missing.append('regex Python package')
    if missing:raise RuntimeError('Activate the retained USL environment; missing prerequisites: '+', '.join(missing))
    if sys.platform!='linux' or os.uname().machine!='x86_64':raise RuntimeError('only retained Linux x86_64 host is qualified')
    version=command([shutil.which('bibtex'),'--version'])['stdout']
    if 'BibTeX 0.99d' not in version:raise RuntimeError('BibTeX 0.99d required')
    if not pathlib.Path('/usr/share/texlive/texmf-dist/bibtex/bst/base/plain.bst').is_file():raise RuntimeError('retained texlive-base reference style missing')
    return {'python':sys.version,'python_executable':sys.executable,'python_include':sysconfig.get_paths()['include'],'regex_version':regex.__version__,'bibtex':version,'gcc':command([shutil.which('gcc'),'--version'])['stdout'],'node':command([shutil.which('node'),'--version'])['stdout']}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.parse_args()
    started=time.perf_counter();retained=prerequisites();destination=ROOT/'_tools';destination.mkdir(exist_ok=True)
    manifest_path=ROOT/'TOOL_PROVENANCE.json';manifest_sha=digest(manifest_path)
    manifest=json.loads(manifest_path.read_text());debian=[p for p in manifest if p['name'] in ['swig','parsimonious']]
    verification=verify_debian(destination,debian);artifacts=[]
    for item in manifest:
        npm='integrity' in item;archive=destination/(item['name']+('.tgz' if npm else '.deb'))
        fetch(item['url'],archive,item['sha256'],item['size'])
        if npm:
            algorithm,expected=item['integrity'].split('-',1)
            actual=base64.b64encode(bytes.fromhex(digest(archive,algorithm))).decode('ascii')
            if actual!=expected:raise ValueError('npm SRI mismatch: '+item['name'])
            extract_npm(archive,destination/item['name'])
        else:command([shutil.which('dpkg-deb'),'-x',str(archive),str(destination)])
        artifacts.append({'name':item['name'],'sha256':digest(archive),'bytes':archive.stat().st_size})
    # Verify the restored providers can actually load/run on the retained host.
    native_env=dict(os.environ);native_env['SWIG_LIB']=str(destination/'usr/share/swig/4.3.0')
    swig=subprocess.run([str(destination/'usr/bin/swig'),'-version'],env=native_env,text=True,capture_output=True,timeout=10)
    if swig.returncode or 'Version 4.3.0' not in swig.stdout:raise RuntimeError('restored SWIG cannot run: '+swig.stderr)
    sys.path.insert(0,str(destination/'usr/lib/python3/dist-packages'))
    from parsimonious.grammar import Grammar
    Grammar('start = "ready"').parse('ready')
    probe=command([shutil.which('node'),'-e',"const w=require('./_tools/webidl2/dist/webidl2.js');const c=require('./_tools/webidl-conversions/lib/index.js');if(w.parse('interface X {};').length!==1||c.octet(257)!==1)process.exit(1)"])
    if digest(manifest_path)!=manifest_sha:raise AssertionError('restoration mutated frozen provenance')
    receipt={'schema':'usl.grammar-native.restore.v1','artifacts':artifacts,'debian_authentication':verification,'retained_prerequisites':retained,'swig_version':swig.stdout,'npm_probe':probe,'elapsed_seconds':time.perf_counter()-started,'provenance_sha256':manifest_sha}
    (destination/'restore_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'restored':[a['name'] for a in artifacts],'tools_dir':str(destination),'elapsed_seconds':receipt['elapsed_seconds']},indent=2))

if __name__=='__main__':
    # Node's relative package load should be independent of the caller's cwd.
    os.chdir(ROOT)
    main()
