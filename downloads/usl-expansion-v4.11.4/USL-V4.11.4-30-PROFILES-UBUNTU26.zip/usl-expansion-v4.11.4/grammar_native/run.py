#!/usr/bin/env python3
"""Fresh native processing and independently contracted USL execution, four IDs."""
from __future__ import annotations
import argparse,ctypes,hashlib,importlib,importlib.util,itertools,json,math,os,pathlib,platform,shutil,subprocess,sys,sysconfig,tempfile,time
ROOT=pathlib.Path(__file__).resolve().parent
import bst_profile,peg_profile,swig_profile,webidl_runner

def sha(data):return hashlib.sha256(data.encode() if isinstance(data,str) else data).hexdigest()
def file_sha(p):return sha(pathlib.Path(p).read_bytes())
def write(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(data if isinstance(data,str) else json.dumps(data,indent=2,ensure_ascii=True)+'\n')
def exact(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
    return a==b

def host_run(command,cwd,env=None):
    start=time.perf_counter();p=subprocess.run(command,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
    return {'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'elapsed_seconds':time.perf_counter()-start}

def usl(source,Interpreter):
    p=Interpreter(max_ops=500000,timeout=8,max_output=10000,max_depth=50).run(source)
    return p.variables['result'],{'operations':p.operations,'elapsed_ms':p.elapsed_ms}

def peg_cases():
    # Oracles are independent language predicates, never results copied from either parser.
    gs=[
     ('literal', 'start = "ab"',lambda s:s=='ab'),
     ('ordered-short', 'start = ("a" / "ab") "c"',lambda s:s=='ac'),
     ('ordered-long', 'start = ("ab" / "a") "c"',lambda s:s in {'ac','abc'}),
     ('dag', 'start = head tail\nhead = "a" / "b"\ntail = "b"*',lambda s:len(s)>=1 and s[0] in 'ab' and set(s[1:])<=set('b')),
     ('one-or-more', 'start = ("ab")+',lambda s:len(s)>=2 and len(s)%2==0 and s=='ab'*(len(s)//2)),
     ('optional-is-greedy','start = "a"? "a"',lambda s:s=='aa'),
     ('star-is-greedy','start = "a"* "a"',lambda s:False),
     ('negative-lookahead','start = !"b" ("a" / "b")*',lambda s:not s or (s[0]=='a' and set(s)<=set('ab'))),
     ('positive-lookahead','start = &"a" ("a" / "b")+',lambda s:bool(s) and s[0]=='a' and set(s)<=set('ab')),
     ('empty-literal','start = ""',lambda s:s==''),
     ('positive-optional', 'start = "a" "b"? "c"',lambda s:s in {'ac','abc'}),
     ('lookahead-star-precedence', 'start = &"a"* "a"*',lambda s:set(s)<=set('a')),
     ('negative-optional-precedence', 'start = !"a"? "b"*',lambda s:False),
     ('positive-optional-precedence', 'start = &"a"? "b"*',lambda s:set(s)<=set('b')),
    ]
    words=[''.join(p) for n in range(5) for p in itertools.product('abc',repeat=n)]+['a'*64,'ab'*32,'b'*64]
    for name,grammar,predicate in gs:
        yield name,grammar,[(s,bool(predicate(s))) for s in words]

def run_peg(out,Interpreter):
    sys.path.insert(0,str(ROOT/'_tools/usr/lib/python3/dist-packages'))
    from parsimonious.grammar import Grammar
    from parsimonious.exceptions import ParseError
    records=[];total=0;native=0;u=0
    for name,source,cases in peg_cases():
        grammar=Grammar(source);write(out/'peg'/name/'original.peg',source+'\n')
        for index,(text,expected) in enumerate(cases):
            try:grammar.parse(text);observed=True
            except ParseError:observed=False
            native+=1
            generated=peg_profile.translate(source,text);value,cost=usl(generated,Interpreter);u+=1
            ok=exact(observed,expected) and exact(value,expected)
            if not ok:raise AssertionError(('peg',name,text,expected,observed,value))
            path=out/'peg'/name/(str(index)+'.usl');write(path,generated)
            records.append({'grammar':name,'input':text,'expected':expected,'native':observed,'usl':value,'source_sha256':sha(source),'generated_sha256':sha(generated),'generated_file':str(path.relative_to(out)),**cost});total+=1
    receipts={'python':sys.version,'upstream_host':'Parsimonious 0.10.0','upstream_module_sha256':file_sha(sys.modules['parsimonious.grammar'].__file__),'regex_module_sha256':file_sha(sys.modules['regex'].__file__)}
    return profile('peg','Parsimonious 0.10.0 ASCII nonrecursive named-rule DAG PEG recognizer; literals, ordered choice, sequence, grouping, optional, *, +, & and !; complete-input acceptance; <=32 rules, <=8192 grammar bytes, <=128 input characters; nullable repetition and recursive rules rejected',records,native,u,receipts,['Unicode and regex terminals','recursive/left-recursive PEGs','parse-tree capture/error-location contract','all grammar engine/version conformance','termination and USL interpreter correctness proofs','catalog PEG exact normative-dialect applicability review'])

BST_HEADER='''ENTRY { title year } {} {}
INTEGERS { count n }
STRINGS { scratch }
FUNCTION {book} { skip$ }
FUNCTION {article} { skip$ }
FUNCTION {misc} { skip$ }
'''

def bst_cases():
    entries=[{'cite':'gamma','type':'book','fields':{'title':'Gamma','year':'2001'}},{'cite':'alpha','type':'article','fields':{'title':'Alpha','year':'1999'}},{'cite':'beta','type':'misc','fields':{'title':'Beta'}}]
    yield 'sorting-entry-state',BST_HEADER+'''
FUNCTION {init} { #0 'count := }
FUNCTION {presort} { title 'sort.key$ := }
FUNCTION {emit} { count #1 + 'count := count int.to.str$ ":" * cite$ * ":" * title * ":" * write$
 year missing$ { "unknown" } { year } if$ write$ newline$ }
READ
EXECUTE {init}
ITERATE {presort}
SORT
ITERATE {emit}
''',entries,'1:alpha:Alpha:1999\n2:beta:Beta:unknown\n3:gamma:Gamma:2001\n'
    yield 'reverse-sort',BST_HEADER+'''
FUNCTION {presort} { title 'sort.key$ := }
FUNCTION {emit} { cite$ ":" * type$ * write$ newline$ }
READ ITERATE {presort} SORT REVERSE {emit}
''',entries,'gamma:book\nbeta:misc\nalpha:article\n'
    for a,b in [(-20,-3),(-1,0),(0,0),(1,7),(2147483600,40),(-2147483600,-40),(20,-30)]:
        source=BST_HEADER+f'''FUNCTION {{calc}} {{ #{a} #{b} + int.to.str$ write$ "," write$ #{a} #{b} - int.to.str$ write$ newline$ }}
READ EXECUTE {{calc}}
'''
        yield 'arithmetic-'+str(a)+'-'+str(b),source,entries,f'{a+b},{a-b}\n'
    for title,expected in [('', 'empty\n'),('   ','empty\n'),('A','A\n'),('Hello world','Hello world\n')]:
        source=BST_HEADER+'''FUNCTION {emit} { title duplicate$ empty$ { pop$ "empty" } { skip$ } if$ write$ newline$ }
READ ITERATE {emit}
'''
        yield 'empty-'+str(len(title)),source,[{'cite':'item','type':'misc','fields':{'title':title}}],expected
    for n in [0,1,2,8,20]:
        source=BST_HEADER+f'''FUNCTION {{run}} {{ #{n} 'n := {{ n #0 > }} {{ n int.to.str$ write$ "." write$ n #1 - 'n := }} while$ newline$ }}
READ EXECUTE {{run}}
'''
        yield 'while-'+str(n),source,entries,''.join(str(i)+'.' for i in range(n,0,-1))+'\n'
    yield 'stack-length-equality',BST_HEADER+'''FUNCTION {emit} { title text.length$ int.to.str$ write$ ":" write$ #9 #4 swap$ - int.to.str$ write$ ":" write$ "same" "same" = { "yes" } { "no" } if$ write$ newline$ }
READ ITERATE {emit}
''',[{'cite':'item','type':'misc','fields':{'title':'Alpha'}}],'5:-5:yes\n'
    yield 'string-global-state',BST_HEADER+'''FUNCTION {init} { "prefix" 'scratch := }
FUNCTION {emit} { scratch ":" * cite$ * write$ newline$ }
READ EXECUTE {init} ITERATE {emit}
''',entries,'prefix:gamma\nprefix:alpha\nprefix:beta\n'
    # Type errors must be rejected by both native host and typed USL machine.
    for name,body in [('underflow','pop$'),('wrong-write-type','#3 write$'),('wrong-assign-type','"str" \'count :='),('unknown-word','not.defined')]:
        yield 'invalid-'+name,BST_HEADER+'FUNCTION {bad} { '+body+' }\nREAD EXECUTE {bad}\n',entries,None

def run_bst(out,Interpreter):
    records=[];native=0;u=0
    for name,source,entries,expected in bst_cases():
        folder=out/'bst'/name;folder.mkdir(parents=True,exist_ok=True)
        # Semantic invalid-unknown-word is rejected at frontend resolution; all
        # other error cases reach real USL type/stack checks.
        try:generated,bib=bst_profile.translate(source,entries);front_error=None
        except bst_profile.Unsupported as exc:
            if expected is not None:raise
            generated=None;bib,_=bst_profile.bibliography(entries,['title','year']);front_error=str(exc)
        write(folder/'style.bst',source);write(folder/'db.bib',bib)
        write(folder/'test.aux','\\relax\n\\citation{*}\n\\bibstyle{style}\n\\bibdata{db}\n')
        receipt=host_run([shutil.which('bibtex'),'-terse','test'],folder);native+=1
        observed=(folder/'test.bbl').read_text() if (folder/'test.bbl').exists() else ''
        value=None;error=front_error;cost={}
        if generated is not None:
            write(folder/'generated.usl',generated)
            try:value,cost=usl(generated,Interpreter)
            except Exception as exc:error=type(exc).__name__+': '+str(exc)
            u+=1
        if expected is None:ok=receipt['returncode']!=0 and error is not None
        else:ok=receipt['returncode']==0 and observed==expected and value==expected and error is None
        if not ok:raise AssertionError(('bst',name,expected,observed,value,error,receipt))
        records.append({'case':name,'expected':expected,'native_output':observed,'native_receipt':receipt,'usl_output':value,'usl_error':error,'source_sha256':sha(source),'bibliography_sha256':sha(bib),'generated_sha256':sha(generated) if generated else None,'passed':True,**cost})
    version=host_run([shutil.which('bibtex'),'--version'],ROOT)
    receipts={'host_version':version['stdout'],'host_binary_sha256':file_sha(shutil.which('bibtex')),'reference_style_sha256':file_sha('/usr/share/texlive/texmf-dist/bibtex/bst/base/plain.bst')}
    return profile('bst','BibTeX 0.99d plain-ASCII .bst profile: ENTRY with title/year, global integer/string variables, READ/EXECUTE/ITERATE/REVERSE/SORT, function quotes, typed stack primitives, +/-/integer comparisons/string concat, if$/while$, missing$/empty$, text.length$, cite$/type$, write$/newline$. <=32 entries, <=40-character plain fields, signed32 bounded arithmetic; no entry-local variables except sort.key$; unique sort keys and <=79-character lines',records,native,u,receipts,['all BibTeX builtins and TeX brace/name purification semantics','ENTRY-local variables and complete .bib parser/macros/crossrefs','complete style-language syntax/ordering and native buffer/overflow behavior','sort tie/collation rules outside ASCII unique keys','all normative/toolchain/version/platform and library qualification gates','original-intent and full translation correctness proofs'])

SWIG_SOURCE='''%module arithmetic
%inline %{
enum { RED = 3, BLUE = 9 };
long add(long a, long b) { return a + b; }
long affine(long x, long scale, long bias) { return x * scale + bias; }
long enum_shift(long x) { return x + BLUE - RED; }
long polynomial(long x) { return x * x - 2 * x + 1; }
double blend(double x, double y) { return x * 0.25 + y * 0.75; }
double centered(double x, double offset) { return (x - offset) * 0.5; }
%}
'''
def swig_cases():
    numbers=[-1000000,-71,-1,0,1,9,1000000]
    for a,b in itertools.product(numbers,repeat=2):yield 'add',[a,b],a+b
    for x,scale,bias in itertools.product([-101,0,100],[0,1,-3],[0,7,-50]):yield 'affine',[x,scale,bias],x*scale+bias
    for x in numbers:
        yield 'enum_shift',[x],x+6
        yield 'polynomial',[x],(x-1)*(x-1)
    for x,y in itertools.product([-10000.25,-1.0,0.0,3.5,10000.75],repeat=2):
        yield 'blend',[x,y],(x+3*y)/4
        yield 'centered',[x,y],(x-y)/2
    for fn,args,expected in [('add',[True,False],1),('blend',[True,False],0.25),('add',[1.5,2],None),('add',['1',2],None),('blend',[None,2],None),('blend',['1',2],None)]:yield fn,args,expected

def run_swig(out,Interpreter):
    folder=out/'swig';folder.mkdir(parents=True,exist_ok=True);write(folder/'arithmetic.i',SWIG_SOURCE)
    tool=ROOT/'_tools/usr/bin/swig';env=dict(os.environ);env['SWIG_LIB']=str(ROOT/'_tools/usr/share/swig/4.3.0')
    swig=host_run([str(tool),'-python','-o','arithmetic_wrap.c','arithmetic.i'],folder,env)
    if swig['returncode']:raise AssertionError(swig)
    include=sysconfig.get_paths()['include'];suffix=sysconfig.get_config_var('EXT_SUFFIX');extension=folder/('_arithmetic'+suffix)
    gcc=host_run([shutil.which('gcc'),'-fPIC','-shared','-O1','-I'+include,'arithmetic_wrap.c','-o',str(extension)],folder)
    if gcc['returncode']:raise AssertionError(gcc)
    spec=importlib.util.spec_from_file_location('_arithmetic',extension);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    assert module.RED==3 and module.BLUE==9 and ctypes.sizeof(ctypes.c_long)==8
    records=[];native=u=0
    for index,(fn,args,expected) in enumerate(swig_cases()):
        observed=None;nerror=None
        try:observed=getattr(module,fn)(*args)
        except (TypeError,OverflowError) as exc:nerror=type(exc).__name__+': '+str(exc)
        native+=1
        value=None;error=None;generated=None;cost={}
        try:
            generated=swig_profile.translate(SWIG_SOURCE,fn,args);value,cost=usl(generated,Interpreter);u+=1
        except (TypeError,swig_profile.Unsupported) as exc:error=type(exc).__name__+': '+str(exc)
        if expected is None:ok=nerror is not None and error is not None
        elif type(expected) is float:ok=type(observed) is float and type(value) is float and math.isclose(observed,expected,rel_tol=1e-14,abs_tol=1e-12) and math.isclose(value,expected,rel_tol=1e-14,abs_tol=1e-12)
        else:ok=exact(observed,expected) and exact(value,expected)
        if not ok:raise AssertionError(('swig',fn,args,expected,observed,value,nerror,error))
        if generated:write(folder/(str(index)+'.usl'),generated)
        records.append({'function':fn,'arguments':args,'expected':expected,'native':observed,'native_error':nerror,'usl':value,'usl_error':error,'source_sha256':sha(SWIG_SOURCE),'generated_sha256':sha(generated) if generated else None,'passed':True,**cost})
    receipts={'host_version':host_run([str(tool),'-version'],ROOT)['stdout'],'host_binary_sha256':file_sha(tool),'compiler_version':host_run([shutil.which('gcc'),'--version'],ROOT)['stdout'],'compiler_binary_sha256':file_sha(shutil.which('gcc')),'python':sys.version,'C_long_bits':ctypes.sizeof(ctypes.c_long)*8,'extension_sha256':file_sha(extension),'wrapper_sha256':file_sha(folder/'arithmetic_wrap.c'),'swig_receipt':swig,'gcc_receipt':gcc}
    return profile('swig','SWIG 4.3.0 Python/C %module + %inline binding of explicit small enum constants and pure homogeneous long/double single-return +,-,* arithmetic functions. Native compiled CPython extension, generated USL functions, exact signed64 host identity, integer finite +/-1e6 input domain, <=8 parameters; static expression bound <=2^53; floating comparison tolerance rel1e-14 abs1e-12',records,native,u,receipts,['all SWIG directives/typemaps/targets and C/C++ frontend behavior','pointers/structs/ownership/lifetimes and exceptions','platform/ABI/compiler version portability','nonfinite, overflow and out-of-domain conversions','complete generated-wrapper and underlying C semantic proofs','all normative/version/library/conformance/review gates'])

def profile(catalog_id,description,records,native,usl_calls,tools,remaining):
    return {'catalog_id':catalog_id,'scoped_profile_validated':True,'full_standard_qualified':False,'exact_profile':description,'cases':len(records),'native_executions':native,'usl_executions':usl_calls,'records':records,'tools':tools,'open_obligations':remaining,'proof_claim':'Fresh bounded differential and independently authored intent evidence only; no full-standard or universal-translation proof.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-root',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    out=pathlib.Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(pathlib.Path(args.source_root).resolve()))
    # A failed rerun must not leave a stale success receipt for the coordinator.
    (out/'results.json').unlink(missing_ok=True)
    from usl_systems.language import Interpreter
    start=time.perf_counter();profiles=[]
    for function in [run_peg,run_bst,run_swig]:profiles.append(function(out,Interpreter))
    profiles.append(webidl_runner.run(out,Interpreter,(write,sha,file_sha,host_run,usl,exact,profile,ROOT)))
    files={p.name:file_sha(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in ['.py','.usl','.cjs']}
    result={'schema':'usl.remaining-ids.grammar-native-profile-evidence.v1','profiles':profiles,'catalog_ids':[p['catalog_id'] for p in profiles],'new_scoped_profile_count':len(profiles),'full_standards_qualified':0,'cases':sum(p['cases'] for p in profiles),'native_executions':sum(p['native_executions'] for p in profiles),'usl_executions':sum(p['usl_executions'] for p in profiles),'elapsed_seconds':time.perf_counter()-start,'source_sha256':files,'runtime_sha256':file_sha(pathlib.Path(args.source_root)/'usl_systems/language.py'),'host':platform.platform(),'concurrency':'Host runner sequential; all four IDs independently executable. Logical workers do not manufacture CPU resources.'}
    write(out/'evidence.json',result)
    fields=['catalog_id','scoped_profile_validated','full_standard_qualified','exact_profile','cases','native_executions','usl_executions','open_obligations']
    summary={k:v for k,v in result.items() if k not in ['profiles','source_sha256']}
    write(out/'results.json',{**summary,'records':[{k:p[k] for k in fields} for p in profiles]})
    write(out/'summary.json',summary)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
