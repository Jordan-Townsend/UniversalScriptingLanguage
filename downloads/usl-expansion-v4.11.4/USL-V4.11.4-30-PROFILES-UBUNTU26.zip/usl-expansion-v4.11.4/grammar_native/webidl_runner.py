"""Independently authored scalar-conversion contracts; native WebIDL2 + jsdom algorithms."""
import itertools,json,math,sys
from decimal import Decimal,ROUND_HALF_EVEN
from pathlib import Path
import webidl_profile

def declaration(typ,mode='wrap'):
    return '[Exposed=Window] interface Converter { '+typ+' convert('+('['+mode+'] ' if mode!='wrap' else '')+typ+' value); };'

def cases():
    values=[None,False,True,-2**40,-2**32-1,-65537,-32769,-257,-256,-129,-128,-3.5,-2.5,-1.5,-0.5,-0.0,0,0.5,1.5,2.5,3.5,127,128,255,256,32767,32768,65535,65536,2**31-1,2**31,2**32-1,2**32,2**40]
    # Independent arithmetic oracle uses quotient/floor reduction and Decimal
    # half-even rounding, rather than the generated modulo/round expressions.
    for typ,(bits,signed) in webidl_profile.INT_TYPES.items():
        low=-2**(bits-1) if signed else 0;high=2**(bits-1)-1 if signed else 2**bits-1;m=2**bits
        for mode in ['wrap','Clamp','EnforceRange']:
            for value in values:
                n=0 if value is None else int(value) if type(value) is bool else value;t=math.trunc(n)
                if mode=='wrap':
                    expected=t-m*math.floor(t/m)
                    if signed and expected>high:expected-=m
                elif mode=='Clamp':expected=int(Decimal(str(min(high,max(low,n)))).quantize(Decimal('1'),rounding=ROUND_HALF_EVEN))
                else:expected=t if low<=t<=high else None
                yield {'source':declaration(typ,mode),'value':value,'expected':expected,'expected_error':expected is None,'contract':'independent integer conversion'}
            for special in ['nan','infinity','-infinity']:
                expected=0 if mode=='wrap' or special=='nan' else high if special=='infinity' else low
                yield {'source':declaration(typ,mode),'value':{'special':special},'expected':None if mode=='EnforceRange' else expected,'expected_error':mode=='EnforceRange','contract':'nonfinite integer conversion'}
    for value,expected in [(None,False),(False,False),(True,True),(0,False),(-0.0,False),(1,True),(-4,True),(0.25,True),('',False),('false',True),('0',True),('x',True)]:
        yield {'source':declaration('boolean'),'value':value,'expected':expected,'expected_error':False,'contract':'scalar ECMAScript truthiness'}
    pairs=[('',[]),('A',[65]),('a\x00b',[97,0,98]),('é',[233]),('ÿ',[255]),('Ā',[256]),('😀',[55357,56832]),('\ud800',[55296]),('\udc00',[56320]),('\ud800X\udc00',[55296,88,56320]),('\ud800\udc00',[55296,56320]),('\ud800\ud800\udc00',[55296,55296,56320]),(True,[116,114,117,101]),(False,[102,97,108,115,101]),(None,[110,117,108,108]),(-123,[45,49,50,51])]
    for typ in ['DOMString','ByteString','USVString']:
        for value,units in pairs:
            if typ=='ByteString':expected_error=any(x>255 for x in units);expected=None if expected_error else units
            elif typ=='USVString':
                expected_error=False
                # Separate expected vectors for malformed UTF16 samples.
                replacements={'\ud800':[65533],'\udc00':[65533],'\ud800X\udc00':[65533,88,65533],'\ud800\ud800\udc00':[65533,55296,56320]}
                expected=replacements.get(value,units) if type(value) is str else units
            else:expected_error=False;expected=units
            yield {'source':declaration(typ),'value':value,'expected':expected,'expected_error':expected_error,'contract':'independent explicit UTF16 unit vector'}
    for source in ['[Exposed=Window] interface Converter { long convert(long value) }','[Exposed=Window] interface Converter { impossible convert(impossible value); };','[Exposed=Window] interface Converter { long convert(long); };']:
        yield {'source':source,'value':1,'expected':None,'expected_error':True,'contract':'invalid source rejection'}

def run(out,Interpreter,helpers):
    write,sha,file_sha,host_run,usl,exact,profile,ROOT=helpers
    folder=out/'webidl';folder.mkdir(parents=True,exist_ok=True);samples=list(cases());write(folder/'inputs.json',samples)
    import subprocess,shutil,time
    start=time.perf_counter();process=subprocess.run([shutil.which('node'),str(ROOT/'webidl_native.cjs')],input=json.dumps(samples),text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
    receipt={'command':[shutil.which('node'),str(ROOT/'webidl_native.cjs')],'returncode':process.returncode,'stderr':process.stderr,'elapsed_seconds':time.perf_counter()-start,'stdout_sha256':sha(process.stdout)}
    if process.returncode:raise AssertionError(receipt)
    observations=json.loads(process.stdout);assert len(observations)==len(samples);records=[];count=0
    for i,(sample,native) in enumerate(zip(samples,observations)):
        error=None;generated=None;value=None;cost={}
        try:
            generated=webidl_profile.translate(sample['source'],sample['value']);count+=1;value,cost=usl(generated,Interpreter)
        except Exception as exc:error=type(exc).__name__+': '+str(exc)
        if sample['expected_error']:ok=not native['accepted'] and error is not None
        else:ok=native['accepted'] and exact(native['observed'],sample['expected']) and exact(value,sample['expected']) and error is None
        if not ok:raise AssertionError(('webidl',i,sample,native,value,error))
        if generated:write(folder/(str(i)+'.usl'),generated)
        records.append({**sample,'native':native,'usl':value,'usl_error':error,'source_sha256':sha(sample['source']),'generated_sha256':sha(generated) if generated else None,'passed':True,**cost})
    tools={'WebIDL2':'24.5.0','webidl-conversions':'7.0.0','webidl2_sha256':file_sha(ROOT/'_tools/webidl2/dist/webidl2.js'),'conversions_sha256':file_sha(ROOT/'_tools/webidl-conversions/lib/index.js'),'node_binary_sha256':file_sha(shutil.which('node')),'node_version':host_run([shutil.which('node'),'--version'],ROOT)['stdout'],'native_process_count':1,'native_case_processing_calls':len(samples),'native_receipt':receipt}
    return profile('webidl','WebIDL2 24.5.0 validation + webidl-conversions 7.0.0 scalar argument binding profile: single exposed Converter interface/convert method; byte,octet,short,unsigned short,long,unsigned long wrapping/[Clamp]/[EnforceRange] conversion, finite scalars and tagged NaN/infinities; boolean finite scalar truthiness; DOMString/ByteString/USVString UTF16-unit preservation, rejection and unpaired-surrogate repair. Numeric magnitude <=2^40, input strings <=128 chars. Typed source frontend + generated USL conversion algorithms; no browser object binding',records,len(samples),count,tools,['all WebIDL interfaces/members/overloading, objects/callbacks/promises/iterables/dictionaries/sequences','full ECMAScript ToNumber/ToPrimitive/ToString and BigInt/Symbol/object coercion','WebIDL normative dependency/version audit and true browser platform integration','remaining scalar types, unrestricted/nonfinite float/double and 64-bit integer edge cases','parser/validator/conversion algorithm correctness and generated-USL refinement proofs','all full-standard conformance/platform/library/review gates'])
