# Grammar native profiles

Four bounded translation profiles are implemented here. Each case checks both a
real upstream provider and generated USL against an independently authored
expected result. These are scoped implementation results; **none of the four
IDs is qualified for its full standard**. Each result retains explicit open
obligations.

| Catalog ID | Native provider | Cases | Native evaluations | USL evaluations |
| --- | --- | ---: | ---: | ---: |
| `peg` | Parsimonious 0.10.0 | 1,736 | 1,736 | 1,736 |
| `bst` | BibTeX 0.99d | 24 | 24 | 23 |
| `swig` | SWIG 4.3.0 and freshly compiled CPython C extension | 146 | 146 | 142 |
| `webidl` | WebIDL2 24.5.0 and webidl-conversions 7.0.0 under Node | 729 | 729 | 726 |
| Total | | 2,635 | 2,635 | 2,627 |

Eight expected failures are rejected by the translation frontend and do not
execute USL: one unknown BibTeX word, four SWIG argument type errors, and three
invalid WebIDL declarations. Other expected runtime rejection cases execute
generated USL assertions. Native evaluation counts mean individual parser,
conversion, compiled function, or BibTeX case evaluations; WebIDL batches its
729 evaluations into one Node process. The runner performs actual native work
on every invocation and never substitutes saved observations.

## Run and restore

Use the retained Linux x86_64 host and the existing USL environment:

```bash
source /workspace/.onboarding/activate-usl.sh
cd /workspace/usl-expansion-v4.11.4/grammar_native
python restore.py
python test_profiles.py --source-root /workspace/usl-v4.10.0-clean-test
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output /tmp/grammar-native-results
```

`--source-root` selects the existing USL runtime. `--output` selects the fresh
evidence directory. All four profiles run sequentially in approximately four
seconds on the retained host. No services or credentials are required.

The source archive omits `_tools/`, provider executables, and generated native
extensions. `restore.py` downloads the four small pinned family providers into
`_tools/`. It checks archive length and SHA256 for every artifact, npm SHA512
SRI for both npm archives, and the complete Debian package index against the
signed, frozen InRelease. It verifies that signature with the retained Debian
archive keyring before accepting the SWIG and Parsimonious package identities.
TLS, package signatures, and checksums remain enabled. It rejects archive path
traversal and links, runs provider smoke checks, and writes a new receipt only
inside `_tools/`. It leaves source files, `TOOL_PROVENANCE.json`, the frozen
signature receipt, and reference metadata unchanged. Running it again verifies
cached archives and refreshes the extracted providers.

Required retained prerequisites are CPython 3.12 with matching `Python.h`,
`regex` 2026.9.29, BibTeX 0.99d from texlive-binaries
2024.20240313.70630+ds-6, the texlive-base reference style, GCC 14.2.0, Node,
`dpkg-deb`, GnuPG, and the Debian archive keyring whose hash is recorded in
`DEBIAN_SIGNATURE_RECEIPT.json`. The current host has glibc 2.41 and 64-bit
`long`. Restore checks the prerequisites needed for its operations; every
native run records the actual Python, compiler, Node, module, and binary
identities. These retained system dependencies are not bundled or installed
by this directory. Other operating systems, ABIs, runtime versions, and fresh
hosts without these prerequisites remain unqualified.

Network destinations for restoration are `deb.debian.org` and
`registry.npmjs.org`. Provider archives total 1,616,414 bytes; authenticated
Debian metadata adds a 9,678,380-byte compressed index. Debian restoration
also streams the 56,620,099-byte uncompressed index to validate its identity;
it does not retain the uncompressed index. Public package availability is a
reproduction dependency. No network access is needed for subsequent tests.

## Scope and evidence

The exact enforced translation domains and remaining obligations appear in
each compact result. The principal profiles are:

- PEG: ASCII literals, named nonrecursive rule DAGs, ordered choice,
  sequences, grouping, greedy repetition, optional terms, and lookahead.
  Recognition requires complete input. Recursive grammars and nullable
  repetition are rejected. Native regressions cover lookahead/repetition
  precedence as well as greediness and ordered choice.
- BibTeX: a plain ASCII `.bst` stack machine, typed globals, entry fields,
  iteration, unique-key sorting, output, conditionals, bounded loops,
  arithmetic, comparisons, and selected string/entry primitives. General
  `.bib` parsing, TeX names/braces, all builtins, and complete style semantics
  remain open.
- SWIG: `%module` and `%inline` bindings of small enums and pure single-return
  `long`/`double` arithmetic functions. Native validation regenerates the C
  wrapper, compiles the extension with GCC, loads it, and calls it. General
  C/C++, typemaps, ownership, other targets, and ABI portability remain open.
- WebIDL: a single exposed `Converter` interface and scalar argument binding.
  It covers signed/unsigned 8/16/32-bit wrap, Clamp and EnforceRange,
  boolean scalar truthiness, and DOMString/ByteString/USVString UTF16 units,
  including unpaired surrogate repair. The native path parses and validates
  with WebIDL2, then performs conversions with webidl-conversions. Browser
  object binding, full ECMAScript coercion, other members/types, and normative
  dependency audits remain open.

`results.json` is the coordinator's object with a `records` array of four compact
records and aggregate metadata. Every record
has a nonempty exact profile, positive case/native/USL counts,
`scoped_profile_validated: true`, `full_standard_qualified: false`, and a
nonempty `open_obligations` list. `evidence.json` preserves all per-case inputs,
expected/native/USL observations, failures, source hashes, runtime costs, and
tool receipts. `summary.json` records aggregate counts and elapsed time.
Subdirectories contain generated USL, original source inputs, BibTeX logs and
outputs, and generated SWIG C source. Native extensions are disposable build
outputs.

`test_profiles.py` adds five scope and regression tests covering PEG precedence
and termination boundaries, BibTeX input restrictions, SWIG argument/overflow
boundaries, and WebIDL nonfinite conversion and scalar restrictions. It uses
the selected USL runtime. The native comparisons in `run.py` remain the
integration evidence. Neither finite tests nor differential agreement proves
universal translation correctness or complete standards conformance.

`SOURCE_SHA256.json` freezes the source and reference file identities (excluding
itself and disposable output/tool directories). Those source files are read
only after final validation. `results/source_only_restore.json` records a
successful restore, regression suite, and native run from a temporary copy
containing source files only, including confirmation that source bytes did
not change.
