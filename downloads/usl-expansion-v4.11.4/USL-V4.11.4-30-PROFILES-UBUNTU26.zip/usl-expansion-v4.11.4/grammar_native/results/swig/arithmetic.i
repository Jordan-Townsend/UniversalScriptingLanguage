%module arithmetic
%inline %{
enum { RED = 3, BLUE = 9 };
long add(long a, long b) { return a + b; }
long affine(long x, long scale, long bias) { return x * scale + bias; }
long enum_shift(long x) { return x + BLUE - RED; }
long polynomial(long x) { return x * x - 2 * x + 1; }
double blend(double x, double y) { return x * 0.25 + y * 0.75; }
double centered(double x, double offset) { return (x - offset) * 0.5; }
%}
