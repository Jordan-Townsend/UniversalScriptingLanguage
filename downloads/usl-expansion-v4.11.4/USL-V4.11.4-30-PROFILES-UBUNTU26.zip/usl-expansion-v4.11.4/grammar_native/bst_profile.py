"""BibTeX 0.99d ASCII style/entry subset translated to a typed USL stack machine."""
from __future__ import annotations
import re
from pathlib import Path
class Unsupported(ValueError):pass
BUILTINS={'+','-','=','>','<','*',':=','if$','while$','skip$','write$','newline$','pop$','duplicate$','swap$','int.to.str$','empty$','missing$','text.length$','cite$','type$'}

def tokens(source):
    if type(source) is not str or len(source)>16384 or any(ord(c)>127 for c in source):raise Unsupported('ASCII style <=16384')
    out=[];i=0
    while i<len(source):
        c=source[i]
        if c.isspace():i+=1;continue
        if c=='%':
            at=source.find('\n',i);i=len(source) if at<0 else at+1;continue
        if c in '{}':out.append(c);i+=1;continue
        if c=='"':
            end=source.find('"',i+1)
            if end<0:raise Unsupported('unterminated string')
            value=source[i+1:end]
            if any(ord(ch)<32 or ch in '{}\\\r\n' for ch in value):raise Unsupported('plain ASCII string only')
            out.append(['s',value]);i=end+1;continue
        if c=='#':
            m=re.match(r'#(-?\d+)',source[i:])
            if not m:raise Unsupported('integer literal')
            n=int(m[1]);i+=len(m[0])
            if not -2147483648<=n<=2147483647:raise Unsupported('signed32 integer literal')
            out.append(['i',n]);continue
        if c=="'":
            m=re.match(r"'([A-Za-z][A-Za-z0-9.$_-]*)",source[i:])
            if not m:raise Unsupported('quoted identifier')
            out.append(['q',m[1]]);i+=len(m[0]);continue
        m=re.match(r':=|[+*=<>-]|[A-Za-z][A-Za-z0-9.$_-]*',source[i:])
        if not m:raise Unsupported('unsupported style token '+source[i:i+20])
        out.append(m[0]);i+=len(m[0])
    return out

def parse(source):
    ts=tokens(source);at=0;fields=[];integers=[];strings=['sort.key$'];functions={};commands=[]
    def group():
        nonlocal at
        if at>=len(ts) or ts[at]!='{':raise Unsupported('expected {')
        at+=1;out=[]
        while at<len(ts) and ts[at]!='}':
            if ts[at]=='{':out.append(['f',group()])
            else:
                value=ts[at];at+=1;out.append(['w',value] if isinstance(value,str) else value)
        if at==len(ts):raise Unsupported('unclosed {')
        at+=1;return out
    def names(items):
        if any(t[0]!='w' or not re.fullmatch('[A-Za-z][A-Za-z0-9.$_-]*',t[1]) for t in items):raise Unsupported('identifier list')
        return [t[1] for t in items]
    saw_entry=False;saw_read=False
    while at<len(ts):
        cmd=ts[at];at+=1
        if cmd=='ENTRY':
            if saw_entry or saw_read:raise Unsupported('ENTRY declaration order')
            fields=names(group());ei=names(group());es=names(group())
            if ei or es:raise Unsupported('entry-local variables outside profile; sort.key$ is supported')
            saw_entry=True
        elif cmd in ['INTEGERS','STRINGS']:
            if saw_read:raise Unsupported('declaration after READ')
            (integers if cmd=='INTEGERS' else strings).extend(names(group()))
        elif cmd=='FUNCTION':
            name=names(group())
            if len(name)!=1 or name[0] in functions:raise Unsupported('function declaration')
            functions[name[0]]=group()
        elif cmd=='READ':
            if not saw_entry or saw_read:raise Unsupported('READ order')
            saw_read=True;commands.append(['READ',''])
        elif cmd in ['EXECUTE','ITERATE','REVERSE']:
            name=names(group())
            if len(name)!=1 or (cmd!='EXECUTE' and not saw_read):raise Unsupported('command order/arity')
            commands.append([cmd,name[0]])
        elif cmd=='SORT':
            if not saw_read:raise Unsupported('SORT before READ')
            commands.append([cmd,''])
        else:raise Unsupported('unsupported top-level command '+repr(cmd))
    if not saw_read:raise Unsupported('missing READ')
    allnames=integers+strings
    if len(set(allnames+fields+list(functions)))!=len(allnames+fields+list(functions)):raise Unsupported('duplicate symbol')
    if any(n in BUILTINS for n in allnames+fields+list(functions)):raise Unsupported('builtin shadowing')
    if any(cmd in ['ITERATE','REVERSE','EXECUTE'] and n not in functions for cmd,n in commands):raise Unsupported('undefined top-level function')
    def refs(body):
        result=set()
        for kind,v in body:
            if kind=='f':result|=refs(v)
            elif kind in ['w','q']:
                if v not in BUILTINS and v not in allnames and v not in fields and v not in functions:raise Unsupported('unknown identifier '+v)
                if v in functions:result.add(v)
        return result
    dependencies={n:refs(b) for n,b in functions.items()};active=set();done=set()
    def visit(n):
        if n in active:raise Unsupported('recursive function')
        if n in done:return
        active.add(n)
        for r in dependencies[n]:visit(r)
        active.remove(n);done.add(n)
    for n in functions:visit(n)
    return {'fields':fields,'integers':integers,'strings':strings,'names':{n:i for i,n in enumerate(allnames)},'functions':functions,'commands':commands}

def bibliography(entries,fields):
    if type(entries) is not list or not 1<=len(entries)<=32:raise Unsupported('one to32 entries')
    bodies=[];ir=[];seen=set()
    for e in entries:
        if set(e)!={'cite','type','fields'} or not re.fullmatch('[A-Za-z][A-Za-z0-9-]*',e['cite']) or e['cite'] in seen:raise Unsupported('citation identity')
        seen.add(e['cite'])
        if e['type'] not in ['article','book','misc']:raise Unsupported('entry type')
        if type(e['fields']) is not dict or not e['fields'].keys()<=set(fields):raise Unsupported('field set')
        for name,value in e['fields'].items():
            if type(value) is not str or len(value)>40 or any(ord(c)<32 or ord(c)>126 or c in '{}\\"' for c in value):raise Unsupported('plain ASCII field')
        bodies.append('@'+e['type']+'{'+e['cite']+',\n'+',\n'.join(' '+k+' = {'+v+'}' for k,v in e['fields'].items())+'\n}\n')
        ir.append([{f:['s',e['fields'][f]] if f in e['fields'] else ['m',''] for f in fields},e['cite'],e['type']])
    return '\n'.join(bodies),ir

def translate(source,entries):
    p=parse(source);bib,ir=bibliography(entries,p['fields'])
    # BibTeX stores no type-function identity for undefined entry types, so type$
    # yields the empty string until that entry type has a FUNCTION definition.
    for entry in ir:
        if entry[2] not in p['functions']:entry[2]=''
    names=p['names'];initial=[['i',0] for _ in p['integers']]+[['s',''] for _ in p['strings']]
    source=Path(__file__).with_name('bst_runtime.usl').read_text()
    source+='\nlet functions = '+repr(p['functions'])+'\nlet names = '+repr(names)+'\nlet entries = '+repr(ir)+'\nlet state = [[], "", '+repr(initial)+']\nlet order = '+repr(list(range(len(entries))))+'\nlet keys = '+repr(['']*len(entries))+'\n'
    empty=[{f:['m',''] for f in p['fields']},'','']
    for cmd,name in p['commands']:
        if cmd=='READ':continue
        if cmd=='EXECUTE':source+='let state = bst(functions['+repr(name)+'], state, '+repr(empty)+', functions, names)\n'
        elif cmd=='SORT':
            source+='let pairs = []\nfor index in order:\n    let pairs = pairs + [[keys[index], index]]\nlet pairs = sorted(pairs)\nlet order = []\nfor pair in pairs:\n    let order = order + [pair[1]]\n'
        else:
            source+='let traversal = order\n'
            if cmd=='REVERSE':source+='let traversal = []\nfor j in range(len(order)):\n    let traversal = traversal + [order[len(order) - 1 - j]]\n'
            source+='for index in traversal:\n    let state = [state[0], state[1], put(state[2], names["sort.key$"], ["s", keys[index]])]\n    let state = bst(functions['+repr(name)+'], state, entries[index], functions, names)\n    let keys = put(keys, index, state[2][names["sort.key$"]][1])\n'
    source+='assert len(state[0]) == 0\nlet result = state[1]\n'
    return source,bib
