"""WebIDL scalar interface argument conversion -> USL, explicitly scoped host binding."""
from __future__ import annotations
import math,re
class Unsupported(ValueError):pass
INT_TYPES={'byte':(8,True),'octet':(8,False),'short':(16,True),'unsigned short':(16,False),'long':(32,True),'unsigned long':(32,False)}

def parse(source):
    if type(source) is not str or len(source)>2048:raise Unsupported('interface source')
    m=re.fullmatch(r'\s*\[Exposed=Window\]\s*interface\s+Converter\s*\{\s*([A-Za-z ]+)\s+convert\s*\(\s*(?:\[(Clamp|EnforceRange)\]\s*)?([A-Za-z ]+)\s+value\s*\)\s*;\s*\}\s*;\s*',source)
    if not m:raise Unsupported('single scalar conversion interface contract')
    returned,mode,typ=(m[1].strip(),m[2] or 'wrap',m[3].strip())
    if typ not in set(INT_TYPES)|{'boolean','DOMString','ByteString','USVString'} or typ!=returned:raise Unsupported('conversion type')
    if mode!='wrap' and typ not in INT_TYPES:raise Unsupported('integer attribute applicability')
    return {'type':typ,'mode':mode}

def utf16(text):
    raw=text.encode('utf-16-le',errors='surrogatepass')
    return [raw[j]+256*raw[j+1] for j in range(0,len(raw),2)]

def translate(source,value):
    p=parse(source);typ=p['type'];mode=p['mode'];is_special=type(value) is dict and set(value)=={'special'} and value['special'] in ['nan','infinity','-infinity']
    if typ in INT_TYPES:
        if value is None:n=0
        elif type(value) in [bool,int,float]:n=float(value)
        elif is_special:n=float('nan') if value['special']=='nan' else float('inf') if value['special']=='infinity' else -float('inf')
        else:raise Unsupported('numeric scalar input only')
        if math.isfinite(n) and abs(n)>2**40:raise Unsupported('finite numeric magnitude <=2^40')
        nonfinite=not math.isfinite(n);bits,signed=INT_TYPES[typ];lower=-(2**(bits-1)) if signed else 0;upper=2**(bits-1)-1 if signed else 2**bits-1
        if mode=='Clamp' and nonfinite:
            n=0 if math.isnan(n) else upper if n>0 else lower
            nonfinite=False
        body='let value = '+repr(n if not nonfinite else 0.0)+'\nlet nonfinite = '+repr(nonfinite)+'\n'
        if mode=='EnforceRange':body+='assert not nonfinite\nlet result = int(value)\nassert result >= '+str(lower)+' and result <= '+str(upper)+'\n'
        elif mode=='Clamp':body+='let result = int(round(min('+str(upper)+', max('+str(lower)+', value))))\n'
        else:
            body+='let result = 0 if nonfinite else int(value) % '+str(2**bits)+'\n'
            if signed:body+='if result >= '+str(2**(bits-1))+':\n    let result = result - '+str(2**bits)+'\n'
        return body
    if typ=='boolean':
        if type(value) not in [type(None),bool,int,float,str] or (type(value) in [int,float] and not math.isfinite(value)):raise Unsupported('finite scalar boolean inputs')
        return 'let value = '+repr(value)+'\nlet result = bool(value)\n'
    if type(value) is str:
        if len(value)>128:raise Unsupported('string input length')
        units=utf16(value)
    elif value is None:units=utf16('null')
    elif type(value) is bool:units=utf16('true' if value else 'false')
    elif type(value) is int and abs(value)<=1000000:units=utf16(str(value))
    else:raise Unsupported('string conversion input domain')
    body='let units = '+repr(units)+'\nlet result = []\n'
    if typ=='DOMString':return body+'let result = units\n'
    if typ=='ByteString':return body+'for unit in units:\n    assert unit <= 255\nlet result = units\n'
    return body+'''let i = 0
while i < len(units):
    let current = units[i]
    if current >= 55296 and current <= 56319:
        if i + 1 < len(units) and units[i + 1] >= 56320 and units[i + 1] <= 57343:
            let result = result + [current, units[i + 1]]
            let i = i + 2
        else:
            let result = result + [65533]
            let i = i + 1
    elif current >= 56320 and current <= 57343:
        let result = result + [65533]
        let i = i + 1
    else:
        let result = result + [current]
        let i = i + 1
'''
