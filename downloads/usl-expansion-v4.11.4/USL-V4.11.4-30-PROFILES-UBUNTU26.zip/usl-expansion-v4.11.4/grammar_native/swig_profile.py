"""SWIG 4.3.0 Python/C inline pure arithmetic interface -> bounded typed USL."""
from __future__ import annotations
import ast,re,math
class Unsupported(ValueError):pass
INPUT_LIMIT=1_000_000

def parse(source):
    if type(source) is not str or len(source)>8192:raise Unsupported('interface input')
    m=re.fullmatch(r'\s*%module\s+([A-Za-z][A-Za-z0-9_]*)\s+%inline\s*%\{(.*?)%\}\s*',source,re.S)
    if not m:raise Unsupported('exact %module and %inline interface required')
    module=m[1];body=m[2];enums={};functions=[]
    def enum(match):
        for piece in match[1].split(','):
            v=re.fullmatch(r'\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*(-?\d+)\s*',piece)
            if not v or v[1] in enums:raise Unsupported('explicit enum member')
            enums[v[1]]=int(v[2])
            if not -1000<=enums[v[1]]<=1000:raise Unsupported('bounded enum')
        return ''
    body=re.sub(r'enum\s*\{([^{}]*)\}\s*;',enum,body)
    fn=re.compile(r'\s*(long|double)\s+([A-Za-z][A-Za-z0-9_]*)\s*\(([^()]*)\)\s*\{\s*return\s+([^;{}]+);\s*\}')
    pos=0
    while body[pos:].strip():
        f=fn.match(body,pos)
        if not f:raise Unsupported('only single-return long/double functions')
        pos=f.end();rtype,name,args,expr=f.groups();params=[]
        for a in args.split(',') if args.strip() else []:
            p=re.fullmatch(r'\s*(long|double)\s+([A-Za-z][A-Za-z0-9_]*)\s*',a)
            if not p:raise Unsupported('parameter declaration')
            params.append([p[1],p[2]])
        if len(params)>8 or len(set(n for t,n in params))!=len(params):raise Unsupported('parameters')
        if not params or any(t!=rtype for t,n in params):raise Unsupported('homogeneous nonempty typed parameters')
        if name in enums or any(n['name']==name for n in functions):raise Unsupported('duplicate declaration')
        if not re.fullmatch(r'[A-Za-z0-9_+*(). \t-]+',expr):raise Unsupported('C expression tokens')
        try:tree=ast.parse(expr.strip(),mode='eval')
        except SyntaxError as exc:raise Unsupported('C expression') from exc
        if len(list(ast.walk(tree)))>64:raise Unsupported('expression size')
        variables={n for t,n in params}
        def check(node,depth=0):
            if depth>8:raise Unsupported('expression nesting')
            if isinstance(node,ast.Name):
                if node.id not in variables and node.id not in enums:raise Unsupported('unbound expression identifier')
                limit=INPUT_LIMIT if node.id in variables else abs(enums[node.id]);return(-limit,limit)
            if isinstance(node,ast.Constant):
                if type(node.value) not in [int,float] or not math.isfinite(node.value) or abs(node.value)>1000 or (rtype=='long' and type(node.value) is not int):raise Unsupported('typed bounded constant')
                return(node.value,node.value)
            if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
                a,b=check(node.operand,depth+1);return(a,b) if isinstance(node.op,ast.UAdd) else(-b,-a)
            if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult)):
                a,b=check(node.left,depth+1);c,d=check(node.right,depth+1)
                if isinstance(node.op,ast.Add):bounds=(a+c,b+d)
                elif isinstance(node.op,ast.Sub):bounds=(a-d,b-c)
                else:bounds=(min(a*c,a*d,b*c,b*d),max(a*c,a*d,b*c,b*d))
                if max(abs(x) for x in bounds)>2**53:raise Unsupported('bounded exact-integer/no-overflow arithmetic domain')
                return bounds
            raise Unsupported('C operation outside expression profile')
        bounds=check(tree.body)
        functions.append({'name':name,'return':rtype,'params':params,'expression':ast.unparse(tree.body),'bounds':list(bounds)})
    if not functions:raise Unsupported('missing function')
    return {'module':module,'enums':enums,'functions':functions}

def translate(source,function,args):
    ir=parse(source);declarations={f['name']:f for f in ir['functions']}
    if function not in declarations:raise Unsupported('function')
    f=declarations[function]
    if type(args) is not list or len(args)!=len(f['params']):raise Unsupported('arity')
    converted=[]
    for a,(typ,name) in zip(args,f['params']):
        if typ=='long':
            if type(a) not in [bool,int]:raise TypeError('SWIG long argument must be integer')
            value=int(a)
        else:
            if type(a) not in [bool,int,float]:raise TypeError('SWIG double argument must be numeric')
            value=float(a)
        if not math.isfinite(value) or abs(value)>INPUT_LIMIT:raise Unsupported('argument outside declared finite magnitude profile')
        converted.append(value)
    usl='// SWIG inline C arithmetic profile; native ABI and broader C are not modeled.\n'
    for n,v in ir['enums'].items():usl+='let '+n+' = '+repr(v)+'\n'
    for g in ir['functions']:
        usl+='function '+g['name']+'('+', '.join(n for t,n in g['params'])+'):\n    return '+g['expression']+'\n'
    usl+='let result = '+function+'('+', '.join(repr(a) for a in converted)+')\n'
    return usl
