"""Launch the prepared Ubuntu26 image with exact retained toolchains mounted."""
import argparse
import json
import os
import re
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from platform_check import check_file, toolchain_files


def container_command(workspace, runtime_root, image, command, interactive=False, godot_root='/opt/godot', user=None):
    workspace = Path(workspace).resolve()
    runtime_root = Path(runtime_root).resolve()
    godot_root = Path(godot_root).resolve()
    if any(',' in str(path) for path in [workspace, runtime_root, godot_root]):
        raise ValueError('Docker bind paths cannot contain commas')
    if not image or any(c.isspace() for c in image) or image.startswith('-'):
        raise ValueError('Invalid Docker image reference')
    user=user or str(os.getuid())+':'+str(os.getgid())
    if not re.fullmatch(r'[0-9]+:[0-9]+',user):raise ValueError('Docker user must be numeric UID:GID')
    arguments = ['docker', 'run', '--rm', '--platform', 'linux/amd64',
                 '--mount', 'type=bind,src=' + str(workspace) + ',dst=/workspace',
                 '--mount', 'type=bind,src=' + str(runtime_root) + ',dst=/opt/codex/runtimes,readonly',
                 '--mount', 'type=bind,src=' + str(godot_root) + ',dst=/opt/godot,readonly',
                 '--workdir', '/workspace/usl-expansion-v4.11.4',
                 '--env', 'PYTHONDONTWRITEBYTECODE=1', '--user', user]
    if interactive:
        arguments.append('-it')
    return arguments + [image, 'bash', 'ubuntu/inside.sh'] + list(command or ['check'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', default='/workspace')
    parser.add_argument('--runtime-root', default='/opt/codex/runtimes')
    parser.add_argument('--godot-root', default='/opt/godot')
    default_user=os.environ.get('SUDO_UID',str(os.getuid()))+':'+os.environ.get('SUDO_GID',str(os.getgid()))
    parser.add_argument('--user',default=default_user,help='numeric UID:GID; defaults to invoking host user, including sudo origin')
    parser.add_argument('--image', default='usl-ubuntu26:retained')
    parser.add_argument('--interactive', action='store_true')
    parser.add_argument('--print-command', action='store_true')
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if platform.machine() != 'x86_64':
        parser.error('This retained toolchain requires an x86_64 host')
    manifest = json.loads((ROOT / 'TOOLCHAINS.json').read_text())
    toolchain_files(manifest, args.runtime_root)
    check_file(Path(args.godot_root)/manifest['godot']['relative_path'],manifest['godot']['sha256'])
    workspace = Path(args.workspace)
    for required in ['.onboarding/activate-usl.sh', 'usl-v4.10.0-clean-test/usl_systems/language.py',
                     'usl-expansion-v4.11.4/ubuntu/inside.sh']:
        if not (workspace / required).is_file():
            parser.error('Missing retained workspace input: ' + str(workspace / required))
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    arguments = container_command(workspace, args.runtime_root, args.image, command, args.interactive, args.godot_root, args.user)
    if args.print_command:
        print(json.dumps(arguments))
        return 0
    if shutil.which('docker') is None:
        parser.error('Install Docker Engine on the host before launching')
    subprocess.run(['docker', 'info'], check=True, stdout=subprocess.DEVNULL)
    return subprocess.run(arguments).returncode


if __name__ == '__main__':
    raise SystemExit(main())
