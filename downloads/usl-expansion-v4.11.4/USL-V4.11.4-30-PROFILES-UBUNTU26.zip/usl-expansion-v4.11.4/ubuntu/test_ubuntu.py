"""Portable launcher/platform regressions; no Docker or package mutations."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import subprocess

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from launch import container_command
from platform_check import parse_os_release, require_ubuntu26, toolchain_files


class UbuntuPlatformTests(unittest.TestCase):
    def test_parse_real_os_release_syntax(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'os-release'
            path.write_text('# a comment\nID=ubuntu\nVERSION_ID="26.04"\nPRETTY_NAME="Ubuntu 26.04 LTS"\n')
            release = parse_os_release(path)
        self.assertEqual(release['PRETTY_NAME'], 'Ubuntu 26.04 LTS')
        require_ubuntu26(release, 'x86_64')

    def test_debian_cannot_be_reported_as_ubuntu(self):
        with self.assertRaisesRegex(ValueError, 'Ubuntu 26.04'):
            require_ubuntu26({'ID': 'debian', 'VERSION_ID': '13'}, 'x86_64')

    def test_older_ubuntu_is_outside_scope(self):
        with self.assertRaises(ValueError):
            require_ubuntu26({'ID': 'ubuntu', 'VERSION_ID': '24.04'}, 'x86_64')

    def test_arm_is_outside_retained_binary_scope(self):
        with self.assertRaisesRegex(ValueError, 'x86_64'):
            require_ubuntu26({'ID': 'ubuntu', 'VERSION_ID': '26.04'}, 'aarch64')

    def test_toolchain_hash_mismatch_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            (path / 'python').write_bytes(b'python')
            (path / 'node').write_bytes(b'changed node')
            manifest = {name: {'relative_path': name, 'sha256': hashlib.sha256(name.encode()).hexdigest()}
                        for name in ['python', 'node']}
            with self.assertRaisesRegex(ValueError, 'Pinned file identity mismatch'):
                toolchain_files(manifest, path)

    def test_recorded_retained_toolchains_are_present_and_exact(self):
        manifest = json.loads((ROOT / 'TOOLCHAINS.json').read_text())
        observations = toolchain_files(manifest, '/opt/codex/runtimes')
        self.assertEqual(set(observations), {'python', 'node'})


class DockerCommandTests(unittest.TestCase):
    def test_exact_readonly_runtime_mount_and_fixed_container_paths(self):
        command = container_command('/tmp/user workspace', '/tmp/retained runtimes', 'test:ubuntu26', ['check'])
        self.assertIn('type=bind,src=/tmp/user workspace,dst=/workspace', command)
        self.assertIn('type=bind,src=/tmp/retained runtimes,dst=/opt/codex/runtimes,readonly', command)
        self.assertIn('type=bind,src=/opt/godot,dst=/opt/godot,readonly',command)
        self.assertEqual(command[-4:], ['test:ubuntu26', 'bash', 'ubuntu/inside.sh', 'check'])
        self.assertIn('linux/amd64', command)

    def test_user_command_remains_literal_arguments(self):
        user_command = ['python', '-c', 'print("$(touch /tmp/forbidden)")']
        command = container_command('/tmp/work', '/tmp/runtime', 'test:ubuntu26', user_command)
        self.assertEqual(command[-3:], user_command)
        self.assertNotIn('sh', command)

    def test_bind_paths_with_docker_separator_are_rejected(self):
        with self.assertRaises(ValueError):
            container_command('/tmp/path,readonly', '/tmp/runtime', 'image', [])

    def test_invalid_image_cannot_become_docker_option(self):
        for image in ['--privileged', 'image with spaces', '']:
            with self.subTest(image=image), self.assertRaises(ValueError):
                container_command('/tmp/work', '/tmp/runtime', image, [])

    def test_output_ownership_uses_literal_host_uid_and_gid(self):
        command=container_command('/tmp/work','/tmp/runtime','image',[],user='1234:4321')
        self.assertEqual(command[command.index('--user')+1],'1234:4321')
        self.assertFalse(any(argument.startswith('HOME=') for argument in command))
        with self.assertRaises(ValueError):
            container_command('/tmp/work','/tmp/runtime','image',[],user='1234:4321 --privileged')

    def test_interactive_is_explicit(self):
        ordinary = container_command('/tmp/work', '/tmp/runtime', 'image', [])
        interactive = container_command('/tmp/work', '/tmp/runtime', 'image', ['bash'], True)
        self.assertNotIn('-it', ordinary)
        self.assertIn('-it', interactive)

    def test_dockerfile_and_manifest_share_exact_base_digest(self):
        manifest = json.loads((ROOT / 'TOOLCHAINS.json').read_text())
        dockerfile = (ROOT / 'Dockerfile').read_text()
        self.assertEqual(dockerfile.splitlines()[0], 'FROM ' + manifest['base_image'])
        self.assertFalse(manifest['qualification']['fresh_ubuntu_install_validated'])
        self.assertFalse(manifest['qualification']['all359_native_profiles_qualified'])


class CompatibilityRestoreTests(unittest.TestCase):
    def test_system_prefixes_cannot_be_overwritten(self):
        import restore_compat
        for path in ['/','/usr/local','/lib','/lib64','/bin','/sbin','/etc']:
            with self.subTest(path=path), self.assertRaises(ValueError):
                restore_compat.private_prefix(path)

    def test_exact_icu_archive_and_public_keyring_are_pinned(self):
        manifest=json.loads((ROOT/'COMPAT_PROVIDERS.json').read_text())
        self.assertEqual(manifest['packages'][0]['Version'],'76.1-4')
        self.assertEqual(manifest['packages'][0]['SHA256'],'c1bf762996de9ecba9b9d871e4928a8090f023a3e9e7fa3240b3d90f892a01dc')
        keyring=ROOT/manifest['keyring']['path']
        self.assertEqual(hashlib.sha256(keyring.read_bytes()).hexdigest(),manifest['keyring']['sha256'])

    def test_public_keyring_install_preserves_ubuntu_trust(self):
        with tempfile.TemporaryDirectory() as directory:
            destination=Path(directory)/'debian-archive-keyring.pgp'
            ubuntu=Path(directory)/'ubuntu-archive-keyring.gpg';ubuntu.write_bytes(b'unchanged Ubuntu trust')
            subprocess.run(['bash',str(ROOT/'install_keyring.sh'),str(ROOT/'keys/debian-archive-keyring.pgp'),str(destination)],check=True)
            self.assertEqual(destination.read_bytes(),(ROOT/'keys/debian-archive-keyring.pgp').read_bytes())
            self.assertEqual(ubuntu.read_bytes(),b'unchanged Ubuntu trust')

    def test_corrupt_public_keyring_cannot_be_installed(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)/'corrupt.pgp';source.write_bytes(b'wrong public keyring')
            destination=Path(directory)/'debian.pgp'
            result=subprocess.run(['bash',str(ROOT/'install_keyring.sh'),str(source),str(destination)],capture_output=True)
            self.assertNotEqual(result.returncode,0)
            self.assertFalse(destination.exists())

    def test_corrupt_cached_index_fails_after_real_signature_verification(self):
        import restore_compat
        with tempfile.TemporaryDirectory() as directory:
            index=Path(directory)/'Packages';index.write_text('Package: malicious\n')
            with self.assertRaisesRegex(ValueError,'Authenticated Debian index integrity failure'):
                restore_compat.authenticate(index)

    def test_corrupt_package_never_reaches_dpkg_extraction(self):
        import restore_compat
        helper=restore_compat.helpers();run=subprocess.run
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(restore_compat,'helpers',return_value=helper), patch.object(helper,'fetch',return_value=b'corrupt archive'), patch.object(restore_compat.subprocess,'run',wraps=run) as calls:
                with self.assertRaisesRegex(ValueError,'Private compatibility package integrity failure'):
                    restore_compat.restore(directory)
            self.assertTrue(calls.call_args_list)
            self.assertTrue(all(call.args[0][0]=='sqv' for call in calls.call_args_list))


if __name__ == '__main__':
    unittest.main()
