#!/usr/bin/env bash
# Install Ubuntu core build/runtime dependencies; retained providers stay external.
set -euo pipefail
source /etc/os-release
[[ "$ID" == ubuntu && "$VERSION_ID" == 26.04 ]] || { echo 'Requires Ubuntu 26.04' >&2; exit 1; }
[[ "$(dpkg --print-architecture)" == amd64 ]] || { echo 'Requires Ubuntu amd64' >&2; exit 1; }
[[ "$EUID" == 0 ]] || { echo 'Run this bootstrap as root inside the development container' >&2; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install --yes --no-install-recommends \
    ca-certificates build-essential git pkg-config file xz-utils unzip curl gnupg \
    sqv libldap2 libyaml-0-2 libgmp10 ncurses-bin libncurses6 libedit2 libpcre2-8-0 \
    libstdc++6 libffi8 libssl3t64 liblzma5 libbz2-1.0 libsqlite3-0 \
    libreadline8t64 libncursesw6 zlib1g \
    libnuma1 libfftw3-double3 libgsl28 libtirpc3t64 libglew2.2 libgl1 \
    libx11-6 libxxf86vm1 libxi6 libboost-filesystem1.83.0 libblas3 libdeflate0 \
    openscad texlive-binaries texlive-base

usl_ubuntu_bootstrap_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$usl_ubuntu_bootstrap_dir/install_keyring.sh" ]]; then
    bash "$usl_ubuntu_bootstrap_dir/install_keyring.sh"
else
    bash /usr/local/lib/usl-ubuntu26-install-keyring.sh /usr/local/share/usl-ubuntu26/debian-archive-keyring.pgp
fi
