"""Check the actual Ubuntu userspace and exact retained Python/Node inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def parse_os_release(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        key, value = line.split('=', 1)
        pieces = shlex.split(value)
        result[key] = pieces[0] if pieces else ''
    return result


def require_ubuntu26(release, architecture):
    if release.get('ID') != 'ubuntu' or release.get('VERSION_ID') != '26.04':
        raise ValueError('Requires Ubuntu 26.04 userspace; observed ' + repr(release))
    if architecture != 'x86_64':
        raise ValueError('Requires x86_64; observed ' + architecture)


def check_file(path, expected):
    observed = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if observed != expected:
        raise ValueError('Pinned file identity mismatch: ' + str(path))
    return observed


def toolchain_files(manifest, runtime_root):
    observations = {}
    for name in ['python', 'node']:
        item = manifest[name]
        path = Path(runtime_root) / item['relative_path']
        observations[name] = {'path': str(path), 'sha256': check_file(path, item['sha256'])}
    return observations


def probe(runtime_root='/opt/codex/runtimes', workspace='/workspace'):
    manifest = json.loads((ROOT / 'TOOLCHAINS.json').read_text())
    release = parse_os_release('/etc/os-release')
    require_ubuntu26(release, platform.machine())
    observations = toolchain_files(manifest, runtime_root)
    if Path(sys.executable).resolve() != Path(observations['python']['path']).resolve():
        raise ValueError('Run with the pinned retained CPython or its virtual environment')
    if platform.python_version() != manifest['python']['version']:
        raise ValueError('Unexpected running Python version')
    version = subprocess.run([observations['node']['path'], '--version'], check=True,
                             capture_output=True, text=True).stdout.strip()
    if version != manifest['node']['version']:
        raise ValueError('Unexpected Node version: ' + version)
    godot=Path('/opt/godot')/manifest['godot']['relative_path']
    if not godot.exists():godot=Path('/usr/local/bin/godot')
    if godot.exists():observations['godot']={'path':str(godot),'sha256':check_file(godot,manifest['godot']['sha256'])}
    runtime = Path(workspace) / manifest['usl_runtime']['relative_path']
    runtime_hash = check_file(runtime, manifest['usl_runtime']['sha256'])
    sys.path.insert(0, str(runtime.parents[1]))
    from usl_systems.language import Interpreter
    value = Interpreter().run('let result = (6 * 7)\n').variables['result']
    if value != 42:
        raise RuntimeError('USL interpreter smoke check failed')
    return {'schema': 'usl.ubuntu26.platform-check.v1', 'os_release': release,
            'architecture': platform.machine(), 'libc': platform.libc_ver(),
            'toolchains': observations, 'node_version': version,
            'python_version': platform.python_version(), 'usl_runtime_sha256': runtime_hash,
            'usl_smoke_result': value, 'ubuntu_userspace_check_passed': True,
            'all359_native_profiles_qualified': False,
            'fresh_ubuntu_install_validated': False,
            'scope': 'Ubuntu26.04 x86_64 userspace with retained mounted toolchains and USL source'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-root', default='/opt/codex/runtimes')
    parser.add_argument('--workspace', default='/workspace')
    args = parser.parse_args()
    print(json.dumps(probe(args.runtime_root, args.workspace), indent=2))


if __name__ == '__main__':
    main()
