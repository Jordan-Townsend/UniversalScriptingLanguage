"""Restore exact authenticated ICU76 privately, without replacing Ubuntu ICU78."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import platform
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
CONFIGURATION = ROOT.parent / 'configuration'
DEFAULT_PREFIX = Path('/workspace/.onboarding/ubuntu26-compat')


def helpers():
    spec = importlib.util.spec_from_file_location('usl_configuration_restore', CONFIGURATION / 'restore.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def authenticate(index=None):
    helper = helpers()
    manifest = json.loads((ROOT / 'COMPAT_PROVIDERS.json').read_text())
    keyring = ROOT / manifest['keyring']['path']
    if helper.sha(keyring.read_bytes()) != manifest['keyring']['sha256']:
        raise ValueError('Pinned Debian public keyring mismatch')
    signed = CONFIGURATION / 'DEBIAN_INRELEASE.asc'
    if helper.sha(signed.read_bytes()) != manifest['signed_release_sha256']:
        raise ValueError('Pinned signed Debian release mismatch')
    with tempfile.TemporaryDirectory(prefix='usl-ubuntu26-auth-') as directory:
        cleartext = Path(directory) / 'release'
        subprocess.run(['sqv', '--keyring', str(keyring), '--cleartext', '--output',
                        str(cleartext), str(signed)], check=True, capture_output=True)
        body = cleartext.read_bytes()
    if helper.sha(body) != manifest['release_sha256']:
        raise ValueError('Authenticated Debian release mismatch')
    release = body.decode()
    expected, size = helper.release_item(release, 'main/binary-amd64/Packages')
    if expected != manifest['index_sha256']:
        raise ValueError('Frozen index pin mismatch')
    index = Path(index) if index is not None else helper.APT_LISTS / helper.INDEX_NAME
    if index.is_file():
        index_bytes = index.read_bytes()
    else:
        compressed_hash, compressed_size = helper.release_item(release, 'main/binary-amd64/Packages.xz')
        compressed = helper.fetch('https://deb.debian.org/debian/dists/trixie/main/binary-amd64/by-hash/SHA256/' + compressed_hash)
        helper.check_bytes(compressed, compressed_hash, compressed_size, 'Compressed Debian index')
        index_bytes = lzma.decompress(compressed)
    helper.check_bytes(index_bytes, expected, size, 'Authenticated Debian index')
    expected_packages = {row['Package']: row for row in manifest['packages']}
    if set(expected_packages) != {'libicu76'}:
        raise ValueError('Unexpected private compatibility provider set')
    found = {}
    for block in index_bytes.decode().split('\n\n'):
        data = dict(line.split(': ', 1) for line in block.splitlines() if ': ' in line and not line.startswith(' '))
        if data.get('Package') in expected_packages:
            row = {key: data[key] for key in helper.FIELDS}
            if row != expected_packages[row['Package']]:
                raise ValueError('Exact compatibility package pin mismatch')
            found[row['Package']] = row
    if set(found) != set(expected_packages):
        raise ValueError('Missing authenticated compatibility package')
    return manifest


def private_prefix(prefix):
    prefix = Path(prefix).resolve()
    if prefix == Path('/') or any(prefix.is_relative_to(Path(root)) for root in ['/usr', '/lib', '/lib64', '/bin', '/sbin', '/etc']):
        raise ValueError('Compatibility providers require a private non-system prefix')
    return prefix


def restore(prefix=DEFAULT_PREFIX, index=None):
    prefix = private_prefix(prefix)
    manifest = authenticate(index)
    helper = helpers()
    prefix.mkdir(parents=True, exist_ok=True)
    for row in manifest['packages']:
        body = helper.fetch('https://deb.debian.org/debian/' + row['Filename'])
        helper.check_bytes(body, row['SHA256'], row['Size'], 'Private compatibility package')
        with tempfile.TemporaryDirectory(prefix='usl-ubuntu26-icu-') as directory:
            package = Path(directory) / 'libicu76.deb'
            package.write_bytes(body)
            subprocess.run(['dpkg-deb', '-x', str(package), str(prefix)], check=True, capture_output=True)
    library_dir = prefix / 'usr/lib/x86_64-linux-gnu'
    required = ['libicuuc.so.76', 'libicudata.so.76', 'libicui18n.so.76']
    observed = {name: helper.sha((library_dir / name).read_bytes()) for name in required}
    receipt = {'schema': 'usl.ubuntu26.private-compatibility-restore.v1',
               'prefix': str(prefix), 'library_directory': str(library_dir),
               'packages': manifest['packages'], 'library_sha256': observed,
               'signed_release_verified': True, 'index_sha256_verified': True,
               'package_sha256_verified': True, 'system_libraries_replaced': False,
               'restore_host': platform.platform(),
               'consumer_platform': 'Ubuntu26.04 x86_64 with retained exact-ABI providers',
               'all359_native_profiles_qualified': False}
    (prefix / 'RESTORE_RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', type=Path, default=DEFAULT_PREFIX)
    parser.add_argument('--index', type=Path)
    args = parser.parse_args()
    print(json.dumps(restore(args.prefix, args.index), indent=2))


if __name__ == '__main__':
    main()
