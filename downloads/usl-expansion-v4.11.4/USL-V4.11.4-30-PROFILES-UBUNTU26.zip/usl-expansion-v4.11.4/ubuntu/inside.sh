#!/usr/bin/env bash
set -euo pipefail
cd /workspace/usl-expansion-v4.11.4
source /workspace/.onboarding/activate-usl.sh
export PATH="/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:$PATH"
if [[ -d /workspace/.onboarding/ubuntu26-compat/usr/lib/x86_64-linux-gnu ]]; then
    export USL_COMPAT_LIBDIR=/workspace/.onboarding/ubuntu26-compat/usr/lib/x86_64-linux-gnu
    export LD_LIBRARY_PATH="$USL_COMPAT_LIBDIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi
if [[ -x /opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64 ]]; then
    export PATH="/workspace/usl-expansion-v4.11.4/ubuntu/bin:$PATH"
fi
python ubuntu/platform_check.py
if [[ "${1:-check}" == check ]]; then
    exit 0
fi
exec "$@"
