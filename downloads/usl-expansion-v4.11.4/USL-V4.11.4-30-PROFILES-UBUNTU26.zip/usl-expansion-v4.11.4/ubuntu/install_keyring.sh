#!/usr/bin/env bash
# Install only the pinned public Debian signing certificates used by providers.
set -euo pipefail
usl_keyring_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
usl_keyring_source="${1:-$usl_keyring_script_dir/keys/debian-archive-keyring.pgp}"
usl_keyring_destination="${2:-/usr/share/keyrings/debian-archive-keyring.pgp}"
usl_keyring_expected_sha256=506b815cbb32d9b6066b4a2aa524071e071761e7e7f68c3ac74f3061ba852017
printf '%s  %s\n' "$usl_keyring_expected_sha256" "$usl_keyring_source" | sha256sum --check --status
install -d "$(dirname "$usl_keyring_destination")"
install -m 0644 "$usl_keyring_source" "$usl_keyring_destination"
printf '%s  %s\n' "$usl_keyring_expected_sha256" "$usl_keyring_destination" | sha256sum --check --status
