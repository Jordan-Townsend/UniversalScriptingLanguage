# Mozilla preprocessing tranche

This addon implements executable, scoped profiles for five original catalog IDs:
`mozhashpreproc`, `mozpercentpreproc`, `css+mozpreproc`,
`javascript+mozpreproc`, and `xul+mozpreproc`.

The independent frontend parses directives and expressions into a typed IR. It
generates actual `.usl` code for mutable macro state, numeric/string distinctions,
expression evaluation, nested branches, expansion and filtering. The only USL
host capability supplies initial macro data. Preprocessing never delegates to a
native host callback.

Implemented directives are `define`, `undef`, `if`, `ifdef`, `ifndef`, `elif`,
`elifdef`, `elifndef`, `else`, `endif`, `expand`, `literal`, `filter`, `unfilter`
and `error`. The expression grammar covers decimal integer literals, variable
lookup, `defined(name)`, one unary `!`, `==`, `!=`, `&&` and `||` with upstream
precedence and operand-returning behavior. A final string-valued `if` result is
false. An undefined identifier evaluates to its own name. Empty definitions are
present even though their values are false. Numeric definitions accept signed
decimal values and valid digit separators through the pinned Python semantics.

The four filters are `attemptSubstitution`, `dumbComments`, `emptyLines` and
`substitution`, applied in the upstream sorted order. Unknown attempted
substitutions remain unchanged; strict unknown substitutions fail. Definitions
are filtered before numeric conversion. Expansion honors upstream greedy
`__NAME__` matching and replaces unknown expanded names with empty strings.

The native reference is unmodified Mozilla `gecko-dev` source pinned to commit
`5836a062726f715fda621338a17b51aff30d0a8c`. `UPSTREAM.json` records HTTPS locations,
file hashes and commit resolution. The three native modules and upstream test
source are retained under `upstream/`, with their MPL 2.0 notice and license.
Upstream tests are reference material; this addon does not claim to have run
Mozilla's complete test suite or build system.

Run in the configured environment:

```bash
source /workspace/.onboarding/activate-usl.sh
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
python -m unittest test_preprocessor -v
```

Elsewhere, provide the existing USL source/runtime, Python 3.12 with `tinycss2`,
and Node. No new binary installation is required in this environment. The
included native reference modules use Python's standard library.

`results/results.json` retains every input, initial binding, independent expected
result, fresh native observation, generated-USL observation, actual execution
receipt and hash-bound source/USL artifact. Each original ID has its own record,
case IDs, source/tool/reference hashes and outstanding obligations. Reused data
consists only of immutable generated code and parsed syntax. Each USL run has
fresh state; each native reference evaluation constructs a new processor.

The suite has 494 hash-marker and 494 percent-marker cases, plus 13 CSS, 13
JavaScript and 7 XUL/XML composite cases. All four-filter combinations and nested
macro-mutation truth tables are included. Separate negative boundaries reject
unsupported source before translation. Six regression tests cover independent
intent, native agreement, fresh concurrent state, errors, boundaries and real
downstream host checks. All ready case actors start together. Native reference
evaluations are batched sequentially in one fresh process to avoid launching a
process for every pure in-memory evaluation. Downstream host pairs use observed
memory admission without a fixed worker round.

The composite contracts validate actual downstream behavior:

- CSS: `tinycss2` parses qualified rules and declarations, including conditional
  colors, widths and optional selectors; malformed declarations are rejected.
- JavaScript: Node executes generated source containing loops and conditionals;
  JSON observations must match independent arithmetic and Boolean contracts.
- XUL: ElementTree validates the XML namespace, element/attribute tree and
  conditional markup. A Mozilla XUL widget, event or rendering host is still
  required to qualify application behavior.

These are scoped processing profiles. Full-standard qualifications and complete
normative rule sets remain zero. The profile requires ASCII source with LF line
endings and a bounded ASCII macro namespace. Filesystem includes, dependency
files, Mozilla build configuration, `FILE`/`LINE`/`DIRECTORY` expansion, JavaScript
line-map insertion, Unicode source, other native versions and complete embedded
language semantics remain open. Metadata expansions are rejected, including
dynamically assembled expansions. Resource limits are explicit in the report;
exhausting a limit cannot qualify an unsupported input. Differential and intent
tests establish the listed contracts; they do not constitute universal proof of
the preprocessor, USL runtime or downstream language implementations.
