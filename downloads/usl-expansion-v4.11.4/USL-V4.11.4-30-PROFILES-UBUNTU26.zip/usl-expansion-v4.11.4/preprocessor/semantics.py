"""Independent Mozilla preprocessor frontend and executable USL translation.

This deliberately versioned profile handles ASCII/LF in-memory source, scalar
integer/string defines, the upstream expression grammar, nested conditional
directives, expansion, literal output and four output filters. Filesystem
includes, line-map metadata and Mozilla application hosts are outside scope.
"""
from __future__ import annotations
import hashlib
import json
import re
import time


class ProfileError(ValueError): pass


NAME = re.compile(r'[A-Za-z_][A-Za-z_0-9]{0,31}\Z')
RESERVED = {'FILE', 'LINE', 'DIRECTORY'}
FILTERS = ['attemptSubstitution', 'dumbComments', 'emptyLines', 'substitution']
DIRECTIVES = {'define', 'undef', 'if', 'ifdef', 'ifndef', 'else', 'endif', 'elif', 'elifdef', 'elifndef', 'filter', 'unfilter', 'expand', 'literal', 'error'}


def metadata_expansion(text):
    return any('@' + key + '@' in text or '__' + key + '__' in text for key in RESERVED)


def name(value):
    if not NAME.fullmatch(value) or value in RESERVED: raise ProfileError('Unsupported/reserved macro name: ' + value)
    return value


class Expression:
    """A separate recursive-descent parser; no native parser/evaluator calls."""
    def __init__(self, source):
        if len(source) > 512: raise ProfileError('Expression limit512')
        self.source = source; self.position = 0
        self.tree = self.logical('||', self.and_expression)
        self.space()
        if self.position != len(source): raise ProfileError('Expression trailing tokens')
        def depth(tree): return 1 + max([depth(value) for value in tree[1:] if isinstance(value, list)] or [0])
        if depth(self.tree) > 16: raise ProfileError('Expression nesting limit16')

    def space(self):
        while self.position < len(self.source) and self.source[self.position] in ' \t': self.position += 1

    def take(self, text):
        self.space()
        if self.source.startswith(text, self.position): self.position += len(text); return True
        return False

    def logical(self, operator, lower):
        left = lower()
        if self.take(operator): return [operator, left, self.logical(operator, lower)]
        return left

    def and_expression(self): return self.logical('&&', self.equality)

    def equality(self):
        left = self.unary()
        for operator in ['==', '!=']:
            if self.take(operator): return [operator, left, self.unary()]
        return left

    def unary(self):
        negate = self.take('!'); value = self.value()
        return ['!', value] if negate else value

    def value(self):
        self.space(); rest = self.source[self.position:]
        defined = re.match(r'defined[ \t]*\([ \t]*([A-Za-z_][A-Za-z_0-9]{0,31})[ \t]*\)', rest)
        if defined: self.position += defined.end(); return ['defined', name(defined[1])]
        integer = re.match(r'[0-9]+', rest)
        if integer: self.position += integer.end(); return ['integer', int(integer[0])]
        identifier = re.match(r'[A-Za-z_][A-Za-z_0-9]{0,31}', rest)
        if identifier: self.position += identifier.end(); return ['variable', name(identifier[0])]
        raise ProfileError('Expected integer, name or defined(name)')


def expression_usl(tree):
    op = tree[0]
    if op == 'integer': return '[0,' + str(tree[1]) + ']'
    if op == 'variable': return 'lookup(context,' + json.dumps(tree[1]) + ')'
    if op == 'defined': return '[0,exists(context,' + json.dumps(tree[1]) + ')]'
    if op == '!': return '[0,not bool(' + expression_usl(tree[1]) + '[1])]'
    if op in {'==', '!='}: return 'equal(' + expression_usl(tree[1]) + ',' + expression_usl(tree[2]) + ',' + str(op == '!=') + ')'
    return ('logicaland' if op == '&&' else 'logicalor') + '(' + expression_usl(tree[1]) + ',' + expression_usl(tree[2]) + ')'


def frontend(source, marker='#'):
    if marker not in {'#', '%'}: raise ProfileError('Only hash and percent markers are qualified')
    if not isinstance(source, str) or len(source) > 16384 or any(c not in '\n\t' and not 32 <= ord(c) <= 126 for c in source):
        raise ProfileError('Profile requires at most16384 ASCII characters with LF/tab')
    if metadata_expansion(source): raise ProfileError('Native file/line/directory expansion tokens are outside profile')
    lines = source.splitlines(keepends=True)
    if len(lines) > 512: raise ProfileError('Line limit512')
    tokens = []
    for line in lines:
        text = line[:-1] if line.endswith('\n') else line
        trimmed = text.lstrip(' \t')
        if trimmed.startswith(marker):
            suffix = trimmed[1:]
            if suffix and suffix[0] in ' \t':
                possible = re.fullmatch(r'[ \t]+([a-z]+)(?:[ \t]+.*?)?[ \t]*', suffix)
                if possible and possible[1] in DIRECTIVES:
                    raise ProfileError('Ambiguous whitespace after directive marker')
                if text.startswith(marker): tokens.append(['comment']); continue
            match = re.fullmatch(r'([a-z]+)(?:[ \t]+(.*?))?[ \t]*', suffix)
            if match:
                command, args = match[1], match[2]
                if command not in DIRECTIVES:
                    raise ProfileError('Unsupported directive: ' + command)
                if command in {'else', 'endif'}:
                    if args: raise ProfileError('No arguments allowed for ' + command)
                    tokens.append([command]); continue
                if args is None: raise ProfileError('Directive requires arguments: ' + command)
                if command == 'define':
                    parts = args.split(' ', 1)
                    key = name(parts[0]); value = parts[1] if len(parts) == 2 else ''
                    if len(value) > 1024: raise ProfileError('Define value limit1024 characters')
                    tokens.append(['define', key, value])
                elif command in {'undef', 'ifdef', 'ifndef', 'elifdef', 'elifndef'}: tokens.append([command, name(args)])
                elif command in {'if', 'elif'}: tokens.append([command, Expression(args).tree])
                elif command in {'filter', 'unfilter'}:
                    selected = args.split(' ')
                    if any(item not in FILTERS for item in selected): raise ProfileError('Only four audited filters are supported')
                    tokens.append([command, selected])
                else: tokens.append([command, args])
                continue
            if text.startswith(marker): tokens.append(['comment']); continue
        tokens.append(['text', line])
    position = 0

    def block(stops, depth):
        nonlocal position
        if depth > 12: raise ProfileError('Conditional nesting limit12')
        result = []
        while position < len(tokens) and tokens[position][0] not in stops:
            token = tokens[position]; position += 1; command = token[0]
            if command in {'else', 'endif', 'elif', 'elifdef', 'elifndef'}: raise ProfileError('Unmatched conditional directive')
            if command in {'if', 'ifdef', 'ifndef'}:
                branches = []
                while True:
                    condition = token[1] if token[0] in {'if', 'elif'} else ['defined', token[1]]
                    if token[0] in {'ifndef', 'elifndef'}: condition = ['!', condition]
                    body = block({'elif', 'elifdef', 'elifndef', 'else', 'endif'}, depth + 1)
                    branches.append([condition, body])
                    if len(branches) > 8: raise ProfileError('At most8 if/elif branches per conditional')
                    if position >= len(tokens): raise ProfileError('Unclosed conditional')
                    token = tokens[position]; position += 1
                    if token[0] in {'elif', 'elifdef', 'elifndef'}: continue
                    otherwise = []
                    if token[0] == 'else':
                        otherwise = block({'endif'}, depth + 1)
                        if position >= len(tokens): raise ProfileError('Unclosed else')
                        position += 1
                    result.append(['conditional', branches, otherwise]); break
            elif command != 'comment': result.append(token)
        return result
    body = block(set(), 0)
    return {'schema': 'usl.mozilla.preprocessor.IR.v1', 'marker': marker, 'body': body}


PRELUDE = '''function lookup(context,key):
    for item in context:
        if item[0] == key:
            return item[1]
    return [1,key]
function exists(context,key):
    for item in context:
        if item[0] == key:
            return True
    return False
function remove(context,key):
    let result = []
    for item in context:
        if item[0] != key:
            result = result + [item]
    return result
function put(context,key,value):
    return remove(context,key) + [[key,value]]
function equal(a,b,negate):
    let same = a[0] == b[0] and a[1] == b[1]
    return [0,not same if negate else same]
function logicaland(a,b):
    return b if bool(a[1]) else a
function logicalor(a,b):
    return a if bool(a[1]) else b
function condition(value):
    return value[0] == 0 and bool(value[1])
function segment(text,start,end):
    let value = ""
    for i in range(start,end):
        value = value + text[i]
    return value
function word(c):
    return c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
function substitute(text,context,attempt):
    let result = ""
    let i = 0
    while i < len(text):
        if text[i] == "@":
            let end = i + 1
            while end < len(text) and word(text[end]):
                end = end + 1
            if end > i + 1 and end < len(text) and text[end] == "@":
                let key = segment(text,i+1,end)
                assert key not in ["FILE","LINE","DIRECTORY"], "moz:PROFILE_METADATA"
                if exists(context,key):
                    result = result + str(lookup(context,key)[1])
                else:
                    assert attempt, "moz:UNDEFINED_VAR"
                    result = result + segment(text,i,end+1)
                i = end + 1
                continue
        result = result + text[i]
        i = i + 1
    return result
function expand(text,context):
    let result = ""
    let i = 0
    while i < len(text):
        if i + 1 < len(text) and text[i] == "_" and text[i+1] == "_":
            let end = i + 2
            while end < len(text) and word(text[end]):
                end = end + 1
            let close = end - 2
            while close > i + 2:
                if text[close] == "_" and text[close+1] == "_":
                    break
                close = close - 1
            if close > i + 2:
                let key = segment(text,i+2,close)
                assert key not in ["FILE","LINE","DIRECTORY"], "moz:PROFILE_METADATA"
                if exists(context,key):
                    result = result + str(lookup(context,key)[1])
                i = close + 2
                continue
        result = result + text[i]
        i = i + 1
    return result
function filtered(text,context,flags):
    if flags[0]:
        text = substitute(text,context,True)
    if flags[1]:
        let i = 0
        while i < len(text) and text[i] in " \\t\\n":
            i = i + 1
        if i + 1 < len(text) and text[i] == "/" and text[i+1] == "/":
            text = "\\n" if len(text) > 0 and text[len(text)-1] == "\\n" else ""
    if flags[2] and text == "\\n":
        text = ""
    if flags[3]:
        text = substitute(text,context,False)
    return text
function setfilter(flags,index,value):
    let result = []
    for i in range(4):
        result = result + [value if i == index else flags[i]]
    return result
function typedvalue(text):
    let trimmed = text
    let begin = 0
    let end = len(text)
    while begin < end and text[begin] in " \\t\\n":
        begin = begin + 1
    while end > begin and text[end-1] in " \\t\\n":
        end = end - 1
    let i = begin
    if i < end and text[i] in "+-":
        i = i + 1
    let first = i
    let prior = False
    let valid = i < end
    while i < end:
        let digit = text[i] in "0123456789"
        if not digit and not (text[i] == "_" and prior and i+1 < end and text[i+1] in "0123456789"):
            valid = False
        prior = digit
        i = i + 1
    if valid and first < end and prior:
        return [0,int(text)]
    return [1,text]
let context = macro_inputs()
let flags = [False,False,False,False]
let output = ""
'''


def emit_usl(source, marker='#'):
    ir = frontend(source, marker); lines = [PRELUDE]
    def emit(nodes, depth=0):
        if depth > 48: raise ProfileError('Generated conditional nesting limit48')
        prefix = '    ' * depth
        if not nodes: lines.append(prefix + 'pass')
        for node in nodes:
            op = node[0]
            if op == 'conditional':
                for index, (condition, body) in enumerate(node[1]):
                    # Nested else/if gives ordinary USL syntax and preserves the
                    # native rule that a string-valued final #if is false.
                    branch_prefix = prefix + '    ' * index
                    if index: lines.append(prefix + '    ' * (index - 1) + 'else:')
                    lines.append(branch_prefix + 'if condition(' + expression_usl(condition) + '):')
                    emit(body, depth + index + 1)
                lines.append(prefix + '    ' * (len(node[1]) - 1) + 'else:')
                emit(node[2], depth + len(node[1]))
            elif op == 'define': lines.append(prefix + 'context = put(context,' + json.dumps(node[1]) + ',typedvalue(filtered(' + json.dumps(node[2]) + ',context,flags)))')
            elif op == 'undef': lines.append(prefix + 'context = remove(context,' + json.dumps(node[1]) + ')')
            elif op in {'filter', 'unfilter'}:
                for selected in node[1]: lines.append(prefix + 'flags = setfilter(flags,' + str(FILTERS.index(selected)) + ',' + str(op == 'filter') + ')')
            elif op == 'error': lines.append(prefix + 'assert False, "moz:ERROR"')
            else:
                text = json.dumps(node[1])
                if op == 'expand': text = 'expand(' + text + ',context) + "\\n"'
                elif op == 'literal': text += ' + "\\n"'
                lines.append(prefix + 'output = output + filtered(' + text + ',context,flags)')
    emit(ir['body']); return '\n'.join(lines) + '\n'


class Program:
    def __init__(self, source, marker='#'):
        from usl_systems.language import parse
        self.source = source; self.ir = frontend(source, marker); self.generated = emit_usl(source, marker)
        self.tree = parse(self.generated); self.sha256 = hashlib.sha256(self.generated.encode()).hexdigest()

    def run(self, defines=None, fresh_parse=False):
        from usl_systems.language import Interpreter, USLError
        defines = dict(defines or {})
        if len(defines) > 64: raise ProfileError('At most64 initial macro bindings')
        context = []
        for key, value in sorted(defines.items()):
            name(key)
            if type(value) not in {int, str} or (isinstance(value, str) and (len(value) > 1024 or any(c not in '\t\n' and not 32 <= ord(c) <= 126 for c in value))):
                raise ProfileError('Only integer or ASCII string macro inputs')
            if isinstance(value, str) and metadata_expansion(value): raise ProfileError('Metadata expansion in input macro value is outside profile')
            if isinstance(value, int) and abs(value) > 10**30: raise ProfileError('Initial integer magnitude limit10**30')
            context.append([key, [0 if type(value) is int else 1, value]])
        interpreter = Interpreter(capabilities={'macro_inputs': lambda: context}, timeout=4, max_ops=2000000)
        try:
            if fresh_parse: value = interpreter.run(self.generated).variables['output']
            else:
                interpreter.start = time.monotonic(); interpreter.statements(self.tree.body, interpreter.env); value = interpreter.env['output']
            outcome = {'status': 'ok', 'output': value}
        except USLError as error:
            text = str(error)
            if 'moz:UNDEFINED_VAR' in text: outcome = {'status': 'error', 'key': 'UNDEFINED_VAR'}
            elif 'moz:ERROR' in text: outcome = {'status': 'error', 'key': 'Error: '} # native do_error key
            elif 'moz:PROFILE_METADATA' in text: raise ProfileError('Dynamically assembled metadata expansion is outside profile') from error
            else: raise
        return outcome, {'actual_USL_execution': True, 'operations': interpreter.operations,
                         'generated_sha256': self.sha256, 'only_pure_syntax_reused': not fresh_parse,
                         'fresh_execution_state': True, 'native_execution_evidence_replayed': False}
