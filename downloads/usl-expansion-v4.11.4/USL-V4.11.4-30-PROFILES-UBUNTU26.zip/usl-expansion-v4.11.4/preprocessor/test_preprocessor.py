from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
import unittest

sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from semantics import ProfileError, Program
from run import composite_cases, host_run, plain_cases

ROOT = Path(__file__).resolve().parent


def native(source, defines=None, marker='#'):
    result = subprocess.run([sys.executable, str(ROOT / 'native_adapter.py')],
                            input=json.dumps([{'source': source, 'defines': defines or {}, 'marker': marker}]),
                            capture_output=True, text=True, check=True, timeout=5)
    return json.loads(result.stdout)[0]


class PreprocessorTests(unittest.TestCase):
    def assert_three(self, source, expected, defines=None, marker='#'):
        program = Program(source, marker)
        self.assertEqual(program.run(defines)[0], expected)
        self.assertEqual(program.run(defines, fresh_parse=True)[0], expected)
        self.assertEqual(native(source, defines, marker), expected)

    def test_string_final_truth_is_distinct_from_operand_returning_logical_expression(self):
        source = '#if A\nwrong\n#else\nstring-false\n#endif\n#if A && 1\nlogical-true\n#endif\n#if A == text\nequal\n#endif\n'
        self.assert_three(source, {'status': 'ok', 'output': 'string-false\nlogical-true\nequal\n'}, {'A': 'text'})

    def test_filter_order_and_definition_conversion(self):
        source = '#define A @B@\n#define B 1_000\n#filter substitution attemptSubstitution\n#define C @A@\n#if C == 1000\n#expand value=__C__\n#endif\n'
        self.assert_three(source, {'status': 'ok', 'output': 'value=1000\n'})

    def test_percent_marker_preserves_css_hash_and_defines_empty_as_present(self):
        source = '%define FLAG\n%ifdef FLAG\n#literal-CSS-color\n%endif\n%if FLAG\nwrong\n%endif\n'
        self.assert_three(source, {'status': 'ok', 'output': '#literal-CSS-color\n'}, marker='%')

    def test_errors_are_native_and_generated_not_successfully_replayed(self):
        for source, key in [('#error expected\n', 'Error: '), ('#filter substitution\n@MISSING@\n', 'UNDEFINED_VAR')]:
            self.assert_three(source, {'status': 'error', 'key': key})
        source = '#if A\n#literal yes\n#else\n#literal no\n#endif\n'
        program = Program(source)
        with ThreadPoolExecutor(max_workers=2) as executor:
            values = list(executor.map(lambda value: program.run({'A': value})[0], [0, 1]))
        self.assertEqual(values, [{'status': 'ok', 'output': 'no\n'}, {'status': 'ok', 'output': 'yes\n'}])

    def test_unsupported_source_is_rejected_before_translation(self):
        for source in ['#include x\n', '#if A > 1\nx\n#endif\n', '#if !!A\nx\n#endif\n', '#if 1\nx\n',
                       '#else\n', '# define\tA 1\n', '#\tdefine\tA 1\n', '#define LINE 3\n',
                       '#filter substitution\n@FILE@\n', '#expand __DIRECTORY__\n', '#define A\r\n']:
            with self.subTest(source=source), self.assertRaises(ProfileError): Program(source)
        with self.assertRaises(ProfileError): Program('#if 1\n' * 14 + '#endif\n' * 14)
        with self.assertRaises(ProfileError): Program('#literal x\n').run({'A': '@LINE@'})
        # An expansion token can be assembled from otherwise valid ASCII macro
        # values. Detect this runtime boundary instead of fabricating metadata.
        source = '#define A @FI\n#define B LE@\n#filter attemptSubstitution substitution\n@A@@B@\n'
        with self.assertRaises(ProfileError): Program(source).run()

    def test_each_composite_contract_and_invalid_syntax_reaches_real_host(self):
        cases = composite_cases()
        for host in ['css', 'javascript', 'xul']:
            for case in [next(case for case in cases if case['host'] == host),
                         next(case for case in cases if case['host'] == host and case['host_expected']['status'] == 'error')]:
                with self.subTest(host=host, name=case['name']):
                    program = Program(case['source'], case['marker'])
                    generated = program.run(case['defines'])[0]
                    self.assertEqual(generated, case['expected'])
                    self.assertEqual(native(case['source'], case['defines'], case['marker']), case['expected'])
                    self.assertEqual(host_run(host, generated['output']), case['host_expected'])


if __name__ == '__main__': unittest.main()
