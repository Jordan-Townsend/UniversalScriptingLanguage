"""Fresh downstream parser contracts; no browser or rendering emulation."""
import json
import sys
import xml.etree.ElementTree as ET


def css(text):
    import tinycss2
    result = []
    for node in tinycss2.parse_stylesheet(text, skip_comments=True, skip_whitespace=True):
        if node.type != 'qualified-rule': raise ValueError('Only qualified CSS rules in this profile')
        declarations = []
        for declaration in tinycss2.parse_declaration_list(node.content, skip_comments=True, skip_whitespace=True):
            if declaration.type != 'declaration': raise ValueError('Invalid CSS declaration')
            if any(token.type == 'error' for token in declaration.value): raise ValueError('Invalid CSS value tokens')
            declarations.append([declaration.name, tinycss2.serialize(declaration.value).strip(), declaration.important])
        result.append({'selector': tinycss2.serialize(node.prelude).strip(), 'declarations': declarations})
    return result


def xml(text):
    if '<!DOCTYPE' in text or '<!ENTITY' in text: raise ValueError('DTD/entities outside this profile')
    def node(element):
        return {'tag': element.tag, 'attributes': dict(sorted(element.attrib.items())),
                'text': (element.text or '').strip(), 'children': [node(child) for child in element]}
    return node(ET.fromstring(text))


if __name__ == '__main__':
    request = json.load(sys.stdin)
    try:
        value = css(request['text']) if request['host'] == 'css' else xml(request['text'])
        result = {'status': 'ok', 'value': value}
    except (ValueError, ET.ParseError): result = {'status': 'error'}
    json.dump(result, sys.stdout)
