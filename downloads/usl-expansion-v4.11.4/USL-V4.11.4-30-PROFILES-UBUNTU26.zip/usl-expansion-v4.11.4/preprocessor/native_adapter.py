"""Execute unmodified hash-pinned Mozilla source, one new processor per case."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parent


def load_native():
    records = json.loads((ROOT / 'UPSTREAM.json').read_text())
    for item in records['files']:
        if hashlib.sha256((ROOT / 'upstream' / item['local']).read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('Upstream source identity changed: ' + item['local'])
    for package in ['mozpack', 'mozbuild']:
        module = types.ModuleType(package); module.__path__ = []; sys.modules[package] = module
    for module_name, filename in [('mozpack.path', 'path.py'), ('mozbuild.makeutil', 'makeutil.py'), ('mozbuild.preprocessor', 'preprocessor.py')]:
        spec = importlib.util.spec_from_file_location(module_name, ROOT / 'upstream' / filename)
        module = importlib.util.module_from_spec(spec); sys.modules[module_name] = module; spec.loader.exec_module(module)
    return sys.modules['mozbuild.preprocessor'].Preprocessor


def main():
    processor_class = load_native(); cases = json.load(sys.stdin); results = []
    for case in cases:
        pp = processor_class(defines=case.get('defines', {}), marker=case.get('marker', '#'))
        pp.out = io.StringIO(); stream = io.StringIO(case['source']); stream.name = 'usl-memory.txt'
        try:
            pp.do_include(stream, False)
            results.append({'status': 'ok', 'output': pp.out.getvalue()})
        except processor_class.Error as error:
            results.append({'status': 'error', 'key': error.key})
    json.dump(results, sys.stdout)


if __name__ == '__main__': main()
