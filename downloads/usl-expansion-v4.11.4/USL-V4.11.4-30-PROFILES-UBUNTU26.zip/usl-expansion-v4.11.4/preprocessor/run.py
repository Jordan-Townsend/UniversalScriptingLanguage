"""Qualify exact Mozilla preprocessing and composite processing profiles."""
from __future__ import annotations
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from semantics import Expression, ProfileError, Program, emit_usl, frontend

ROOT = Path(__file__).resolve().parent
CATALOG_IDS = ['mozhashpreproc', 'mozpercentpreproc', 'css+mozpreproc', 'javascript+mozpreproc', 'xul+mozpreproc']


def file_sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def missing_value(bindings, key): return bindings[key] if key in bindings else key


def condition_value(value): return bool(value) if type(value) in {int, bool} else False


def plain_cases(marker):
    # Independent intent functions are not derived from source ASTs or native
    # observations. In particular strings are false as final #if results, while
    # logical &&/|| retain their ordinary operand-returning behavior.
    expressions = [
        ('0', lambda d: False), ('1', lambda d: True),
        ('A', lambda d: condition_value(missing_value(d, 'A'))),
        ('!A', lambda d: not bool(missing_value(d, 'A'))),
        ('defined(A)', lambda d: 'A' in d), ('!defined(A)', lambda d: 'A' not in d),
        ('A == B', lambda d: missing_value(d, 'A') == missing_value(d, 'B')),
        ('A != B', lambda d: missing_value(d, 'A') != missing_value(d, 'B')),
        ('A == 0', lambda d: missing_value(d, 'A') == 0),
        ('A != 1', lambda d: missing_value(d, 'A') != 1),
        ('A && B', lambda d: condition_value(missing_value(d, 'A') and missing_value(d, 'B'))),
        ('A || B', lambda d: condition_value(missing_value(d, 'A') or missing_value(d, 'B'))),
        ('defined(A) && A', lambda d: condition_value(('A' in d) and missing_value(d, 'A'))),
        ('A == 1 || B == 0 && defined(A)', lambda d: missing_value(d, 'A') == 1 or (missing_value(d, 'B') == 0 and 'A' in d)),
        ('!A == B', lambda d: (not bool(missing_value(d, 'A'))) == missing_value(d, 'B')),
        ('A == A && B != missing', lambda d: missing_value(d, 'B') != 'missing'),
    ]
    sentinel = object(); cases = []
    for expression, intent in expressions:
        for a, b in itertools.product([sentinel, 0, 1, 2, '', 'text', '0'], [sentinel, 0, 1, 'text']):
            bindings = {key: value for key, value in [('A', a), ('B', b)] if value is not sentinel}
            source = marker + 'if ' + expression + '\nyes\n' + marker + 'else\nno\n' + marker + 'endif\n'
            cases.append({'name': 'expression:' + expression, 'marker': marker, 'source': source, 'defines': bindings,
                          'expected': {'status': 'ok', 'output': 'yes\n' if intent(bindings) else 'no\n'}})
    literal_cases = [
        ('state-and-nested', '#define A 3\n#ifdef A\n#if A == 3\n#expand a=__A__\n#endif\n#endif\n#undef A\n#ifndef A\nremoved\n#endif\n', 'a=3\nremoved\n'),
        ('elif-chain', '#if 0\nwrong\n#elif 0\nwrong\n#elif 2\nselected\n#else\nwrong\n#endif\n', 'selected\n'),
        ('elifdef', '#define A\n#if 0\nwrong\n#elifdef A\nselected\n#else\nwrong\n#endif\n', 'selected\n'),
        ('elifndef', '#if 0\nwrong\n#elifndef A\nselected\n#else\nwrong\n#endif\n', 'selected\n'),
        ('inactive-effects', '#if 0\n#define A 2\n#error hidden\n#if 1\nhidden\n#endif\n#else\nvisible\n#endif\n#ifdef A\nwrong\n#endif\n', 'visible\n'),
        ('literal-and-expand', '#define NAME world\n#literal hello __NAME__\n#expand hello __NAME__ __UNKNOWN__!\n', 'hello __NAME__\nhello world !\n'),
        ('greedy-expand', '#define A aa\n#define B bb\n#expand __A____B__ tail\n', ' tail\n'),
        ('empty-name-value', '#define A\n#ifdef A\npresent\n#endif\n#if A\nwrong\n#endif\n#expand [__A__]\n', 'present\n[]\n'),
        ('substitution', '#define A one\n#filter substitution\n@A@ @A@\n#unfilter substitution\n@A@\n', 'one one\n@A@\n'),
        ('attempt-leaves-unknown', '#define A 7\n#filter attemptSubstitution\n@A@ @B@\n', '7 @B@\n'),
        ('filter-sorted-composition', '#define A @B@\n#define B 9\n#filter substitution attemptSubstitution\n@A@\n', '9\n'),
        ('filtered-definition', '#define A 12\n#filter substitution\n#define B @A@\n#if B == 12\ninteger\n#endif\n', 'integer\n'),
        ('empty-lines', '#filter emptyLines\n\n \ntext\n\n', ' \ntext\n'),
        ('comments', '#filter dumbComments\n  // comment\nnot // comment\n', '\nnot // comment\n'),
        ('comments-and-empty', '#filter emptyLines dumbComments\n  // comment\n\nkeep\n', 'keep\n'),
        ('marker-comment', '# comment here\nplain\n# not_a_directive\n', 'plain\n'),
        ('indented-directive', '  #define A 5\n\t#if A == 5\nyes\n  #endif\n', 'yes\n'),
        ('preserve-last-line', '#define A 1\nlast line', 'last line'),
        ('numeric-definitions', '#define A -7\n#define B +7\n#define C 1_000\n#if A != B && C == 1000\n#expand __A__,__B__,__C__\n#endif\n', '-7,7,1000\n'),
    ]
    for label, source, expected in literal_cases:
        if marker == '%': source = source.replace('#', '%')
        cases.append({'name': label, 'source': source, 'marker': marker, 'defines': {}, 'expected': {'status': 'ok', 'output': expected}})
    nested_source = '#if A\n#define VALUE 2\n#if B\n#define VALUE 3\n#else\n#undef C\n#endif\n#else\n#define VALUE 4\n#endif\n#if defined(C)\n#expand keep=__VALUE__\n#elif B\n#expand branch=__VALUE__\n#else\n#expand fall=__VALUE__\n#endif\n'
    if marker == '%': nested_source = nested_source.replace('#', '%')
    for a, b, c in itertools.product([0, 1], repeat=3):
        bindings = {'A': a, 'B': b}
        if c: bindings['C'] = 0
        value = (3 if b else 2) if a else 4
        c_remains = bool(c) and not (a and not b)
        prefix = 'keep=' if c_remains else ('branch=' if b else 'fall=')
        cases.append({'name': 'Nested state mutation truth table', 'source': nested_source, 'marker': marker,
                      'defines': bindings, 'expected': {'status': 'ok', 'output': prefix + str(value) + '\n'}})
    for attempt, comments, empty, strict in itertools.product([False, True], repeat=4):
        filters = [filter_name for enabled, filter_name in [(strict, 'substitution'), (empty, 'emptyLines'),
                                                           (comments, 'dumbComments'), (attempt, 'attemptSubstitution')] if enabled]
        source = (marker + 'filter ' + ' '.join(filters) + '\n' if filters else '') + '\n // comment\n@KNOWN@ @MISSING@\n'
        if strict: expected = {'status': 'error', 'key': 'UNDEFINED_VAR'}
        else:
            prefix = '' if empty else '\n'
            prefix += ('' if empty else '\n') if comments else ' // comment\n'
            expected = {'status': 'ok', 'output': prefix + ('VALUE' if attempt else '@KNOWN@') + ' @MISSING@\n'}
        cases.append({'name': 'All four-filter enablement combinations', 'source': source, 'marker': marker,
                      'defines': {'KNOWN': 'VALUE'}, 'expected': expected})
    for source, key in [('#error requested\n', 'Error: '), ('#filter substitution\n@UNKNOWN@\n', 'UNDEFINED_VAR'),
                        ('#filter substitution\n#define A @UNKNOWN@\n', 'UNDEFINED_VAR')]:
        if marker == '%': source = source.replace('#', '%')
        cases.append({'name': 'expected-error:' + key, 'source': source, 'marker': marker, 'defines': {}, 'expected': {'status': 'error', 'key': key}})
    return cases


NS = 'http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul'


def composite_cases():
    cases = []
    css_source = '%if DARK\n%define COLOR #223344\n%else\n%define COLOR #ddeeff\n%endif\n%filter substitution\n:root { color: @COLOR@; width: @WIDTH@px; }\n%ifdef EXTRA\n.note { opacity: 1; }\n%endif\n'
    for dark, width, extra in itertools.product([0, 1], [0, 1, 7], [False, True]):
        color = '#223344' if dark else '#ddeeff'; bindings = {'DARK': dark, 'WIDTH': width}
        if extra: bindings['EXTRA'] = 0
        text = ':root { color: ' + color + '; width: ' + str(width) + 'px; }\n' + ('.note { opacity: 1; }\n' if extra else '')
        value = [{'selector': ':root', 'declarations': [['color', color, False], ['width', str(width) + 'px', False]]}]
        if extra: value.append({'selector': '.note', 'declarations': [['opacity', '1', False]]})
        cases.append({'catalog_id': 'css+mozpreproc', 'name': 'CSS conditional declarations', 'host': 'css',
                      'source': css_source, 'marker': '%', 'defines': bindings, 'expected': {'status': 'ok', 'output': text},
                      'host_expected': {'status': 'ok', 'value': value}})
    js_source = '#if FEATURE == 1\n#define BASE 10\n#else\n#define BASE 4\n#endif\n#filter substitution\nconst count = @COUNT@;\nconst active = @ACTIVE@;\nfunction total(n) { let s = 0; for (let i=0;i<n;i++) { s += i; } return s; }\nconsole.log(JSON.stringify({value: total(count)+@BASE@, enabled: active}));\n'
    for feature, count, active in itertools.product([0, 1], [0, 1, 5], [False, True]):
        base = 10 if feature else 4; active_text = 'true' if active else 'false'
        text = 'const count = ' + str(count) + ';\nconst active = ' + active_text + ';\nfunction total(n) { let s = 0; for (let i=0;i<n;i++) { s += i; } return s; }\nconsole.log(JSON.stringify({value: total(count)+' + str(base) + ', enabled: active}));\n'
        cases.append({'catalog_id': 'javascript+mozpreproc', 'name': 'JavaScript loop and observable', 'host': 'javascript',
                      'source': js_source, 'marker': '#', 'defines': {'FEATURE': feature, 'COUNT': count, 'ACTIVE': active_text},
                      'expected': {'status': 'ok', 'output': text},
                      'host_expected': {'status': 'ok', 'value': {'value': count * (count - 1) // 2 + base, 'enabled': active}}})
    xul_source = '#define NS ' + NS + '\n#filter substitution\n<window xmlns="@NS@" id="main">\n#if ENABLED\n  <button id="action" label="@LABEL@" />\n#else\n  <description id="message" value="@LABEL@" />\n#endif\n</window>\n'
    for enabled, label in itertools.product([0, 1], ['Run', 'Stop', 'Hello world']):
        child_text = ('  <button id="action" label="' + label + '" />\n' if enabled else '  <description id="message" value="' + label + '" />\n')
        text = '<window xmlns="' + NS + '" id="main">\n' + child_text + '</window>\n'
        child = {'tag': '{' + NS + '}' + ('button' if enabled else 'description'),
                 'attributes': {'id': 'action' if enabled else 'message', 'label' if enabled else 'value': label}, 'text': '', 'children': []}
        value = {'tag': '{' + NS + '}window', 'attributes': {'id': 'main'}, 'text': '', 'children': [child]}
        cases.append({'catalog_id': 'xul+mozpreproc', 'name': 'XUL XML namespace tree', 'host': 'xul', 'source': xul_source,
                      'marker': '#', 'defines': {'ENABLED': enabled, 'LABEL': label}, 'expected': {'status': 'ok', 'output': text},
                      'host_expected': {'status': 'ok', 'value': value}})
    for catalog_id, host, marker, text in [('css+mozpreproc', 'css', '%', ':root { color }\n'),
                                          ('javascript+mozpreproc', 'javascript', '#', 'const = ;\n'),
                                          ('xul+mozpreproc', 'xul', '#', '<window><button></window>\n')]:
        cases.append({'catalog_id': catalog_id, 'name': 'Invalid downstream syntax', 'host': host, 'source': text,
                      'marker': marker, 'defines': {}, 'expected': {'status': 'ok', 'output': text}, 'host_expected': {'status': 'error'}})
    return cases


def host_run(host, text):
    if host == 'javascript':
        result = subprocess.run(['node', '-e', text], capture_output=True, text=True, timeout=5)
        if result.returncode: return {'status': 'error'}
        return {'status': 'ok', 'value': json.loads(result.stdout)}
    result = subprocess.run([sys.executable, str(ROOT / 'host_adapter.py')], input=json.dumps({'host': host, 'text': text}),
                            capture_output=True, text=True, timeout=5)
    if result.returncode: raise RuntimeError('Native CSS/XML host failure: ' + result.stderr)
    return json.loads(result.stdout)


def run_host_pair(case, native, generated):
    return {'native_output_host_observed': host_run(case['host'], native['output']),
            'USL_output_host_observed': host_run(case['host'], generated['output']), 'fresh_host_processes': 2}


def admission(jobs):
    total = os.sysconf('SC_PHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
    cgroup = Path('/sys/fs/cgroup'); working = 0
    try:
        cap = (cgroup / 'memory.max').read_text().strip()
        if cap != 'max': total = min(total, int(cap))
        stats = dict(line.split() for line in (cgroup / 'memory.stat').read_text().splitlines())
        working = sum(int(stats.get(key, 0)) for key in ['anon', 'kernel', 'shmem', 'file_dirty', 'file_writeback', 'unevictable'])
    except (OSError, ValueError): pass
    budget = max(0, total - working - max(512 * 1024**2, total // 8)); per_job = 256 * 1024**2
    slots = min(jobs, budget // per_job)
    if slots == 0: raise RuntimeError('No memory-admitted host slot')
    return {'actual_jobs': jobs, 'slots': slots, 'memory_budget_bytes': budget, 'per_pair_reservation_bytes': per_job,
            'fixed_rounds': False, 'physical_capacity_created_by_virtualization': False}


async def execute(output):
    output = Path(output); output.mkdir(parents=True, exist_ok=True); started = time.monotonic()
    groups = [('mozhashpreproc', plain_cases('#')), ('mozpercentpreproc', plain_cases('%'))]
    all_cases = [dict(case, catalog_id=catalog_id) for catalog_id, cases in groups for case in cases] + composite_cases()
    programs = {}; artifacts = {}; compiled = output / 'programs'; compiled.mkdir(exist_ok=True)
    for case in all_cases:
        key = hashlib.sha256(json.dumps([case['source'], case['marker']]).encode()).hexdigest()
        case['program_id'] = key
        if key not in programs:
            program = Program(case['source'], case['marker']); programs[key] = program
            source_path = compiled / (key + '.txt'); usl_path = compiled / (key + '.usl')
            source_path.write_text(case['source']); usl_path.write_text(program.generated)
            artifacts[key] = {'source_file': str(source_path.relative_to(output)), 'source_sha256': file_sha(source_path),
                              'generated_USL_file': str(usl_path.relative_to(output)), 'generated_USL_sha256': file_sha(usl_path),
                              'marker': case['marker'], 'typed_IR': program.ir}
    native_process = subprocess.run([sys.executable, str(ROOT / 'native_adapter.py')], input=json.dumps(all_cases),
                                    capture_output=True, text=True, timeout=30)
    if native_process.returncode: raise RuntimeError('Mozilla native reference failed: ' + native_process.stderr)
    observed = json.loads(native_process.stdout)
    if len(observed) != len(all_cases): raise AssertionError('Native case count mismatch')
    host_jobs = sum('host' in case for case in all_cases); admitted = admission(host_jobs)
    executor = ThreadPoolExecutor(max_workers=admitted['slots']); loop = asyncio.get_running_loop(); start = asyncio.Event()
    actors = 0; active = 0; peak = 0
    async def actor(index, case):
        nonlocal actors, active, peak
        actors += 1; active += 1; peak = max(peak, active)
        try:
            await start.wait()
            generated, receipt = programs[case['program_id']].run(case['defines'])
            native = observed[index]; passed = generated == case['expected'] and native == case['expected']
            extra = {}
            if 'host' in case:
                extra = await loop.run_in_executor(executor, run_host_pair, case, native, generated)
                passed = passed and extra['native_output_host_observed'] == case['host_expected'] and extra['USL_output_host_observed'] == case['host_expected']
            return dict(case, case_id='mozilla:' + str(index), native_observed=native,
                        generated_USL_observed=generated, USL_receipt=receipt, passed=passed, **extra)
        finally: active -= 1
    tasks = [asyncio.create_task(actor(index, case)) for index, case in enumerate(all_cases)]
    await asyncio.sleep(0); all_started = actors == len(tasks); start.set()
    try: cases = await asyncio.gather(*tasks)
    finally: executor.shutdown(wait=True)
    rejected = []
    for source in ['#include private.txt\n', '#includesubst @FILE@\n', '#pragma x\n', '#if A > 2\nx\n#endif\n',
                   '#if (A)\nx\n#endif\n', '#if !!A\nx\n#endif\n', '#if 1\nx\n', '#else\nx\n',
                   '#filter unsupported\n', '#define LINE 3\n', '#define café 1\n', '#define A\r\n', '# define A 1\n']:
        try: Program(source); rejected.append({'source': source, 'rejected': False})
        except ProfileError as error: rejected.append({'source': source, 'rejected': True, 'reason': str(error)})
    crosschecks = []
    for key, program in programs.items():
        sample = next(case for case in all_cases if case['program_id'] == key)
        value, receipt = program.run(sample['defines'], fresh_parse=True)
        crosschecks.append({'program_id': key, 'passed': value == sample['expected'], 'receipt': receipt})
    import tinycss2
    import _elementtree
    tool_hashes = {'Python_binary': file_sha(Path(sys.executable).resolve()),
                   'Node_binary': file_sha(Path(shutil.which('node')).resolve()),
                   'tinycss2_init': file_sha(tinycss2.__file__),
                   'ElementTree_extension': file_sha(getattr(_elementtree, '__file__', Path(sys.executable).resolve()))}
    source_identities = {path.name: file_sha(path) for path in [ROOT / name for name in ['semantics.py', 'run.py', 'native_adapter.py', 'host_adapter.py']]}
    reference_identities = {item['local']: item['sha256'] for item in json.loads((ROOT / 'UPSTREAM.json').read_text())['files']}
    records = []
    for catalog_id in CATALOG_IDS:
        own = [case for case in cases if case['catalog_id'] == catalog_id]
        host_note = {'css+mozpreproc': 'tinycss2 qualified-rule and declaration IR; no browser layout or CSS cascade',
                     'javascript+mozpreproc': 'Node JavaScript execution with independently expected JSON observations',
                     'xul+mozpreproc': 'ElementTree XML namespace/attribute/child-tree contract; no Mozilla XUL rendering or widget host'}
        records.append({'catalog_id': catalog_id, 'scoped_profile_validated': all(case['passed'] for case in own),
                        'full_standard_qualified': False, 'exact_profile': 'Mozilla gecko-dev pinned in-memory ASCII/LF preprocessing with conditionals, defines, expansion and four filters' + ('; ' + host_note[catalog_id] if catalog_id in host_note else ''),
                        'cases': len(own), 'native_executions': len(own), 'usl_executions': len(own),
                        'case_ids': [case['case_id'] for case in own],
                        'implementation_sha256': source_identities, 'reference_sha256': reference_identities,
                        'tool_sha256': tool_hashes,
                        'native_reference_commit': json.loads((ROOT / 'UPSTREAM.json').read_text())['commit'],
                        'downstream_native_executions': sum(case.get('fresh_host_processes', 0) for case in own),
                        'open_obligations': ['Complete normative/dialect audit', 'Unicode and host filesystem/include semantics', 'FILE/LINE/DIRECTORY and JavaScript line mapping', 'Whole-language semantic translation and proof', 'Complete host/library/ABI/platform qualification'] + ({
                            'css+mozpreproc': ['Full CSS value/cascade/layout semantics and browser host'],
                            'javascript+mozpreproc': ['General JavaScript semantic translation, modules, effects and APIs'],
                            'xul+mozpreproc': ['Actual Mozilla XUL application/widget/event/rendering host'],
                        }.get(catalog_id, []))})
    report = {'schema': 'usl.mozilla-preprocessor.scoped.v1', 'passed': all(case['passed'] for case in cases) and all(item['rejected'] for item in rejected) and all(item['passed'] for item in crosschecks),
              'records': records, 'cases': cases, 'programs': artifacts, 'unsupported_boundary_tests': rejected,
              'fresh_parse_crosschecks': crosschecks, 'upstream': json.loads((ROOT / 'UPSTREAM.json').read_text()),
              'source_sha256': source_identities,
              'toolchain': {'Python': sys.version, 'Python_binary_sha256': file_sha(Path(sys.executable).resolve()),
                            'Node_binary_sha256': file_sha(Path(shutil.which('node')).resolve()),
                            'Node_version': subprocess.check_output(['node', '--version'], text=True).strip(),
                            'tinycss2_version': tinycss2.__version__, 'tinycss2_init_sha256': file_sha(tinycss2.__file__),
                            'XML_host': 'Python stdlib ElementTree, namespace-aware parse and structural extraction',
                            'ElementTree_extension_origin': _elementtree.__spec__.origin,
                            'ElementTree_hash_note': 'Built-in extension uses the Python binary hash; otherwise its extension file is hashed',
                            'ElementTree_extension_sha256': tool_hashes['ElementTree_extension']},
              'profile_limits': {'source_ASCII_characters': 16384, 'physical_LF_lines': 512, 'macro_name_characters': 32,
                                 'initial_macro_bindings': 64, 'initial_string_characters': 1024, 'define_value_characters': 1024,
                                 'initial_integer_magnitude': '10**30', 'expression_characters': 512, 'expression_AST_depth': 16,
                                 'conditional_depth': 12, 'if_elif_branches': 8, 'generated_conditional_depth': 48,
                                 'interpreter_operations': 2000000, 'interpreter_timeout_seconds': 4,
                                 'source_alphabet': 'Printable ASCII plus tab and LF; CR/Unicode excluded',
                                 'macro_namespace': 'ASCII identifier, excluding FILE/LINE/DIRECTORY'},
              'complete_normative_rule_sets': 0,
              'batch_execution': 'One new unmodified Mozilla Preprocessor object per input, sequentially evaluated in one fresh native process; independent downstream host jobs run concurrently',
              'native_evaluations': len(cases), 'fresh_Mozilla_reference_processes': 1,
              'fresh_downstream_processes': sum(case.get('fresh_host_processes', 0) for case in cases),
              'generated_USL_executions': len(cases) + len(crosschecks), 'full_standard_qualifications': 0,
              'logical_workers': actors, 'peak_live_logical_workers': peak, 'all_actors_started_before_release': all_started,
              'interpreter_execution_threads': 1, 'resource_admission': admitted, 'native_execution_evidence_replayed': False,
              'claim': 'Scoped fresh native/USL/intent agreement on listed test contracts; not universal equivalence or full-standard qualification',
              'elapsed_seconds': time.monotonic() - started}
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'results'); args = parser.parse_args()
    sys.path.insert(0, str(args.source_root.resolve())); report = asyncio.run(execute(args.output))
    summary = {key: report[key] for key in ['passed', 'native_evaluations', 'generated_USL_executions', 'elapsed_seconds']}
    summary['records'] = [{key: record[key] for key in ['catalog_id', 'scoped_profile_validated', 'cases', 'native_executions', 'usl_executions']} for record in report['records']]
    print(json.dumps(summary, indent=2))
    if not report['passed']: raise SystemExit(1)
