"""Fresh registered family jobs joined across all359 original unimplemented IDs.

The finite bounded-profile decision trusts the registered runner implementations
and their independent tests. No full-standard verifier is supplied by this tool.
"""
from __future__ import annotations
import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import sys
import time

ROOT=Path(__file__).resolve().parent
DEFAULT_PREVIOUS=Path('/workspace/usl-planning-v4.11.2')
DEFAULT_SOURCE=Path('/workspace/usl-v4.10.0-clean-test')
RUNTIME_SHA='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path,data):
    Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=True)+'\n')


def require(value,reason):
    if not value:raise ValueError(reason)


def source_files(root):
    root=Path(root).resolve();identities={}
    for p in sorted(root.rglob('*')):
        relative=p.relative_to(root)
        if any(part in {'__pycache__','results','native-results','upstream','vendor','node_modules','host','providers','_tools','lpeg'}
               or part.endswith('-build') for part in relative.parts):continue
        if p.is_file():
            require(p.resolve().is_relative_to(root),'Source symlink escapes registered family')
            with p.open('rb') as stream:magic=stream.read(4)
            # Native host executables are dependency identities in each fresh
            # receipt, not portable source files in the addon registry/archive.
            if magic.startswith(b'\x7fELF'):continue
            identities[relative.as_posix()]=sha(p)
    return identities


def validate_records(document,expected_ids):
    require(type(document) is dict and type(document.get('records')) is list,'Missing family record set')
    require(type(expected_ids) is list and all(type(n) is str and n.strip() for n in expected_ids),'Expected catalog identities must be strings')
    records=document['records']
    require(all(type(r) is dict and type(r.get('catalog_id')) is str and r['catalog_id'].strip() for r in records),'Malformed family record identity')
    names=[r['catalog_id'] for r in records]
    require(len(names)==len(set(names)) and set(names)==set(expected_ids),'Omitted, duplicate or unexpected family ID')
    for r in records:
        require(r.get('scoped_profile_validated') is True,'Family profile did not validate')
        require(r.get('full_standard_qualified') is False,'Full standard cannot be promoted by a bounded runner')
        require(type(r.get('exact_profile')) is str and bool(r['exact_profile'].strip()),'Missing exact bounded profile')
        for key in ['cases','native_executions','usl_executions']:
            require(type(r.get(key)) is int and r[key]>0,'Missing positive fresh '+key)
        require(type(r.get('open_obligations')) is list and len(r['open_obligations'])>0
                and all(type(o) is str and o.strip() for o in r['open_obligations']),'Full-language obligations erased')
    return records


def admission(job_count):
    def integer(path,default):
        try:return int(Path(path).read_text().strip())
        except (OSError,ValueError):return default
    maximum=integer('/sys/fs/cgroup/memory.max',1<<30)
    current=integer('/sys/fs/cgroup/memory.current',0)
    available=max(0,maximum-current);reservation=256<<20
    descriptors=resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    slots=min(job_count,max(1,available//reservation),job_count if descriptors==resource.RLIM_INFINITY else max(1,descriptors//12))
    return {'native_family_slots':slots,'distinct_family_jobs':job_count,'memory_limit_bytes':maximum,
            'memory_current_bytes':current,'estimated_family_reservation_bytes':reservation,
            'estimate_is_not_a_proved_peak_memory_bound':True,'fixed_batches_or_round_caps':False}


async def run(previous,source_root,output):
    started=time.perf_counter();output=Path(output).resolve()
    source_root=Path(source_root).resolve();previous=Path(previous).resolve()
    require(not any(output.is_relative_to(root) for root in [ROOT.resolve(),source_root,previous]),'Output must be outside immutable source, runtime and baseline')
    if output.exists():
        require(not any(p.is_symlink() for p in output.rglob('*')),'Fresh output cannot contain symlink paths')
    output.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(source_root))
    import usl_systems.language as runtime
    require(sha(runtime.__file__)==RUNTIME_SHA,'Unexpected USL runtime')
    registry_path=ROOT/'REGISTERED_FAMILIES.json'
    registry=json.loads(registry_path.read_text());registration_sha=sha(registry_path)
    baseline_path=previous/'current-scope-results/CURRENT_SCOPE.json'
    require(sha(baseline_path)==registry['baseline_scope_sha256'],'Baseline scope identity changed')
    baseline=json.loads(baseline_path.read_text());all_rows=baseline['records']
    pending={r['catalog_id']:r for r in all_rows if r['original_catalog'] and not r['validated_bounded_profile']}
    require(len(pending)==359,'Baseline remaining set changed')
    require(type(registry) is dict and type(registry.get('families')) is list and registry['families'],'Missing registered families')
    jobs=registry['families'];claimed={};directories=set()
    for job in jobs:
        require(type(job) is dict,'Malformed family registration')
        directory=job.get('directory')
        require(type(directory) is str and re.fullmatch(r'[a-z][a-z0-9_]*',directory) is not None,'Unsafe family directory')
        require(directory not in directories,'Duplicate registered family directory')
        directories.add(directory)
        family_root=(ROOT/directory).resolve()
        require(family_root.is_relative_to(ROOT.resolve()) and family_root.is_dir(),'Family escapes source root or is absent')
        require(type(job.get('catalog_ids')) is list and job['catalog_ids'] and all(type(n) is str for n in job['catalog_ids']),'Empty or malformed family assignment')
        require(type(job.get('source_sha256')) is dict and job['source_sha256'],'Missing source identity set')
        for name in job['catalog_ids']:
            require(name in pending and name not in claimed,'Unexpected or multiply assigned ID')
            claimed[name]=job['directory']
        require(source_files(ROOT/job['directory'])==job['source_sha256'],'Registered runner source changed: '+job['directory'])
    observed_admission=admission(len(jobs));semaphore=asyncio.Semaphore(observed_admission['native_family_slots'])
    gate=asyncio.Event();actors_started=0;live=0;peak=0
    own_sources={name:sha(ROOT/name) for name in ['coordinator.py','coordinator.usl']}
    env=dict(os.environ);env['PYTHONPATH']=str(source_root)+os.pathsep+env.get('PYTHONPATH','');env['PYTHONDONTWRITEBYTECODE']='1'

    async def command(directory,label,arguments):
        await gate.wait()
        result_dir=output/directory;result_dir.mkdir(parents=True,exist_ok=True)
        log=result_dir/(label+'.log')
        with log.open('wb') as stream:
            child=await asyncio.create_subprocess_exec(sys.executable,*arguments,cwd=ROOT/directory,env=env,stdout=stream,stderr=asyncio.subprocess.STDOUT,start_new_session=True)
            def kill_group():
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            try:
                code=await asyncio.wait_for(child.wait(),180)
            except BaseException:
                kill_group()
                await asyncio.shield(child.wait())
                raise
            if code!=0:
                kill_group()
        require(code==0,directory+' '+label+' failed; see '+str(log))
        return {'exit_status':code,'log_sha256':sha(log)}

    async def family(job):
        await gate.wait()
        async with semaphore:
            directory=job['directory']
            regression=await command(directory,'tests',['-m','unittest','discover','-v'])
            match=re.search(r'Ran (\d+) tests?',(output/directory/'tests.log').read_text())
            require(match is not None and int(match[1])>0,'No completed family regression suite')
            regression['tests_run']=int(match[1])
            execution=await command(directory,'native',['run.py','--source-root',str(source_root),'--output',str(output/directory/'fresh')])
            result_path=output/directory/'fresh/results.json'
            require(result_path.is_file(),'Family omitted results.json')
            records=validate_records(json.loads(result_path.read_text()),job['catalog_ids'])
            require(source_files(ROOT/directory)==job['source_sha256'],'Family source changed during execution')
            return {'records':{r['catalog_id']:r for r in records},'regression':regression,
                    'execution':execution,'result_sha256':sha(result_path),'source_sha256':job['source_sha256'],
                    'fresh_native_receipts_replayed':False}

    futures={j['directory']:asyncio.create_task(family(j)) for j in jobs}

    async def actor(name):
        nonlocal actors_started,live,peak
        actors_started+=1;live+=1;peak=max(peak,live)
        try:
            await gate.wait()
            old=pending[name];record={'catalog_id':name,'family':old['family'],
                'initially_without_bounded_profile':True,'full_standard_qualified':False,
                'baseline_record_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),
                'source_plan_locator':old['full_plan_locator'],'evidence_checked':False,
                'full_standard_obligations_remain_open':True}
            if name in claimed:
                fresh=await futures[claimed[name]]
                record.update(evidence_checked=True,new_bounded_profile=fresh['records'][name],
                              trusted_runner_directory=claimed[name],fresh_receipt_sha256=fresh['result_sha256'])
            else:
                record.update(next_implementation_step=old['next_implementation_step'],specific_semantic_focus=old['specific_semantic_focus'],
                              external_dependencies=old['external_dependencies'],status='implementation_still_required')
            return record
        finally:live-=1

    tasks=[asyncio.create_task(actor(name)) for name in sorted(pending)]
    await asyncio.sleep(0);require(actors_started==359,'Not all catalog actors started before release');gate.set()
    try:
        rows=await asyncio.gather(*tasks)
        completed_jobs={name:await future for name,future in futures.items()}
    except BaseException:
        for future in futures.values():future.cancel()
        await asyncio.gather(*futures.values(),return_exceptions=True)
        for task in tasks:
            if not task.done():task.cancel()
        await asyncio.gather(*tasks,return_exceptions=True)
        raise
    historical=baseline['summary']['validated_bounded_profiles']
    variables={'rows':rows,'historical_bounded':historical,'original_total':606,'initial_remaining':359}
    policy=runtime.Interpreter(timeout=10,max_ops=1_000_000)
    policy.env.update(variables)
    usl=policy.run((ROOT/'coordinator.usl').read_text()).variables
    added=sum(r['evidence_checked'] for r in rows)
    require((usl['added'],usl['bounded_originals'],usl['remaining_originals'],usl['full_standards_qualified'])==(added,historical+added,359-added,0),'USL/Python independent status accounting mismatch')
    require(sha(registry_path)==registration_sha and all(sha(ROOT/name)==identity for name,identity in own_sources.items()),'Coordinator changed during execution')
    summary={'passed':True,'all_initially_remaining_original_IDs':359,'all_logical_actors_started_together':True,
        'peak_live_logical_actors':peak,'family_jobs_executed':len(jobs),'resource_admission':observed_admission,
        'new_validated_bounded_profiles':added,'historical_bounded_profiles_preserved':historical,
        'bounded_original_profiles':historical+added,'original_IDs_without_bounded_profile':359-added,
        'full_standards_qualified':0,'complete_entity_tracks':0,'fresh_family_regression_tests':sum(j['regression']['tests_run'] for j in completed_jobs.values()),
        'fresh_native_work_by_family':{job['directory']:{'reported_units':sum(r['native_executions'] for r in completed_jobs[job['directory']]['records'].values()),
            'unit':job['native_unit'],'case_records':sum(r['cases'] for r in completed_jobs[job['directory']]['records'].values())} for job in jobs},
        'fresh_USL_executions':sum(r['new_bounded_profile']['usl_executions'] for r in rows if r['evidence_checked']),
        'native_observations_replayed':False,'source_unchanged_during_run':True,'full_project_ETA_seconds':None}
    write(output/'ALL359_PROGRESS.json',{'schema':'usl.all359.fresh-implementation-progress.v1','summary':summary,'records':rows})
    write(output/'FAMILY_RECEIPTS.json',completed_jobs)
    lines=['# Remaining original-ID implementation work','','Bounded profiles below do not close full-standard gates. Historical247 bounded profiles are retained, not freshly requalified by this run.','','| ID | New bounded profile | Still required |','|---|---|---|']
    for r in rows:
        scope=r.get('new_bounded_profile',{}).get('exact_profile','No validated bounded implementation')
        work='; '.join(r.get('new_bounded_profile',{}).get('open_obligations',r.get('specific_semantic_focus',[])))
        lines.append('| '+r['catalog_id']+' | '+scope.replace('|','\\|').replace('\n',' ')+' | '+work.replace('|','\\|').replace('\n',' ')+' |')
    (output/'ALL359_PROGRESS.md').write_text('\n'.join(lines)+'\n')
    summary['seconds_through_primary_join_and_exports']=time.perf_counter()-started
    summary['cost_excludes']=['Writing final summary and cost metadata','Console reporting and process shutdown']
    write(output/'SUMMARY.json',summary)
    print(json.dumps(summary));return summary


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--previous',type=Path,default=DEFAULT_PREVIOUS);p.add_argument('--source-root',type=Path,default=DEFAULT_SOURCE);p.add_argument('--output',type=Path,default=Path('/tmp/usl-v4114-coordinator'));p.add_argument('--timeout-seconds',type=float,default=240)
    a=p.parse_args()
    if a.timeout_seconds<=0:p.error('Timeout must be positive')
    asyncio.run(asyncio.wait_for(run(a.previous,a.source_root,a.output),a.timeout_seconds))
