import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
from audit import digest,sha,usl_route,validate_ids
from native_profiles import translate,translate_robot,execute_usl,wrap


class All359Tests(unittest.TestCase):
 def test_exact_remaining_catalog_and_lossless_obligation_join(self):
  previous=Path('/workspace/usl-planning-v4.11.2')
  current=json.loads((previous/'current-scope-results/CURRENT_SCOPE.json').read_text())
  plans={r['catalog_id']:r for r in json.loads((previous/'scope-all-results/ALL_IDS.json').read_text())['records']}
  expected=validate_ids(current,plans)
  output=ROOT/'results';rows=json.loads((output/'ALL359.json').read_text())['records']
  self.assertEqual({r['catalog_id'] for r in rows},{r['catalog_id'] for r in expected})
  dims=json.loads((output/'OBLIGATION_OBJECTS.json').read_text());steps=json.loads((output/'STEP_OBJECTS.json').read_text())
  for row in rows:
   identifier=row['catalog_id'];join=row['lossless_original_obligation_join']
   self.assertEqual(dims[join['dimensions_sha256']],plans[identifier]['original_obligation_dimensions'])
   self.assertEqual(steps[join['steps_sha256']],plans[identifier]['original_ordered_steps'])
   self.assertEqual(digest(dims[join['dimensions_sha256']]),join['dimensions_sha256'])
   self.assertFalse(row['full_standard_qualified'])
   self.assertFalse(row['all_rule_sets_implemented'])
  missing=[r for r in current['records'] if r['catalog_id']!=expected[0]['catalog_id']]
  with self.assertRaises(ValueError):validate_ids({'records':missing},plans)

 def test_all_usl_decision_branches_keep_qualification_open(self):
  policy=(ROOT/'policy.usl').read_text()
  for docs in [0,2]:
   for paths in [0,4]:
    for external in [False,True]:
     decision,receipt=usl_route({'full_semantics_passed':False,'document_count':docs,'tool_paths':paths,'external_dependency':external},policy)
     self.assertTrue(receipt['actual_USL_execution']);self.assertFalse(decision['full_standard_qualified'])
  with self.assertRaises(Exception):usl_route({'full_semantics_passed':True},policy)

 def test_summary_and_all_derived_hashes(self):
  output=ROOT/'results';summary=json.loads((output/'SUMMARY.json').read_text())
  self.assertEqual(summary['actual_USL_policy_executions'],359)
  self.assertEqual(summary['original_obligation_dimensions_preserved'],6462)
  self.assertEqual(summary['original_ordered_steps_preserved'],5385)
  self.assertTrue(summary['source_unchanged_during_run'])
  package=json.loads((output/'PACKAGE_OPTIONS.json').read_text())
  self.assertTrue(package['signature_verified_now'])
  for filename,entry in json.loads((output/'MANIFEST.json').read_text()).items():self.assertEqual(sha(output/filename),entry['sha256'])

 def test_generated_ast_precedence_and_types(self):
  for identifier in ['asymptote','openscad','gdscript']:
   for expr,expected in [('2+3*4',14),('7-3-2',2),('-(2+3)*4',-20),('(-2)<3',True)]:
    artifact=translate(identifier,wrap(identifier,expr));actual,_=execute_usl(artifact)
    self.assertIs(type(actual),type(expected));self.assertEqual(actual,expected)

 def test_arithmetic_rejects_unsupported_and_unsafe_semantics(self):
  for identifier in ['asymptote','openscad','gdscript']:
   for expression in ['4/2','x+1','run(1)','100000','99999+1','1<2<3','(1<2)+1']:
    with self.assertRaises(ValueError,msg=identifier+': '+expression):translate(identifier,wrap(identifier,expression))
   with self.assertRaises(ValueError):translate(identifier,wrap(identifier,'1')+'extra')

 def test_robot_keyword_and_scope_rejections(self):
  valid='*** Variables ***\n${A}    -7\n*** Test Cases ***\nContract\n    Should Be Equal As Integers    ${A}    -7\n'
  artifact=translate_robot(valid);actual,_=execute_usl(artifact);self.assertTrue(actual)
  for source in [valid.replace('${A}    -7','${A}    1.0'),valid.replace('Should Be Equal As Integers','Run'),valid.replace('    ${A}    -7','    ${MISSING}    -7'),valid+'    Unknown Keyword\n']:
   with self.assertRaises(ValueError):translate_robot(source)

 def test_fresh_native_intent_evidence_and_join(self):
  output=ROOT/'native-results';joined=json.loads((output/'results.json').read_text())
  self.assertTrue(joined['passed']);self.assertEqual(len(joined['records']),4)
  self.assertEqual(joined['fresh_native_executions'],742)
  for row in joined['records']:
   path=output/row['qualification_file'];receipt=json.loads(path.read_text())
   self.assertEqual(sha(path),row['qualification_sha256'])
   self.assertTrue(receipt['source_unchanged_during_run']);self.assertTrue(receipt['native_provider_file_unchanged_during_run'])
   self.assertFalse(receipt['arbitrary_program_equivalence_proved']);self.assertFalse(receipt['full_standard_qualified'])
   self.assertEqual(receipt['fresh_native_executions'],len(receipt['records']))
   self.assertTrue(all(c['rejected'] for c in receipt['unsupported_frontend_checks']))
   for case in receipt['records']:
    self.assertTrue(case['passed']);self.assertEqual(case['native_observed'],case['independent_expected'])
    self.assertEqual(case['generated_observed'],case['independent_expected'])
    self.assertTrue(case['native_receipt']['fresh_native_process']);self.assertFalse(case['native_receipt']['observation_cache_used'])
    self.assertTrue(case['USL_receipt']['actual_USL_execution'])

if __name__=='__main__':unittest.main()
