"""Actual bounded scalar frontends for Asymptote, OpenSCAD and GDScript.

One output expression: integer literals, unary signs, +,-,*, comparisons and
parentheses. Every integer intermediate must lie in[-99999,99999]. This avoids
overflow/precision and OpenSCAD's default textual-echo rounding boundary. No
graphics, scenes, state, modules, libraries or device behavior is qualified.
"""
from __future__ import annotations
import ast, hashlib, json, os, re, shutil, subprocess, tempfile
from pathlib import Path

WRAPPERS={
 'asymptote':('write("USL_RESULT:"); write(',');\n'),
 'openscad':('echo("USL_RESULT", ',');\n'),
 'gdscript':('extends SceneTree\nfunc _init():\n\tprint("USL_RESULT:", ',')\n\tquit()\n')}
NATIVE_NAMES={'asymptote':'asy','openscad':'openscad','gdscript':'godot'}
BIN={ast.Add:'+',ast.Sub:'-',ast.Mult:'*'}
CMP={ast.Eq:'==',ast.NotEq:'!=',ast.Lt:'<',ast.LtE:'<=',ast.Gt:'>',ast.GtE:'>='}

def wrap(identifier,expr):
 before,after=WRAPPERS[identifier];return before+expr+after

def translate(identifier,source):
 before,after=WRAPPERS[identifier]
 if not isinstance(source,str) or len(source)>4096 or not source.startswith(before) or not source.endswith(after):
  raise ValueError('Unsupported source wrapper')
 expr=source[len(before):-len(after)]
 if not expr or re.search(r'[^0-9+*<>=!()\s-]',expr):raise ValueError('Unsupported expression token')
 try:tree=ast.parse(expr,mode='eval')
 except SyntaxError as error:raise ValueError('Invalid expression') from error
 def visit(node,depth=0):
  if depth>12:raise ValueError('Expression exceeds depth12')
  if isinstance(node,ast.Constant) and type(node.value) is int:
   value=node.value;code=str(value);kind='int'
  elif isinstance(node,ast.UnaryOp) and type(node.op) in {ast.UAdd,ast.USub}:
   code,kind,value=visit(node.operand,depth+1)
   if kind!='int':raise ValueError('Boolean arithmetic unsupported')
   if isinstance(node.op,ast.USub):code='(-'+code+')';value=-value
   else:code='('+code+')'
  elif isinstance(node,ast.BinOp) and type(node.op) in BIN:
   a,ak,av=visit(node.left,depth+1);b,bk,bv=visit(node.right,depth+1)
   if ak!='int' or bk!='int':raise ValueError('Boolean arithmetic unsupported')
   op=BIN[type(node.op)];code='('+a+' '+op+' '+b+')';kind='int'
   value=av+bv if op=='+' else av-bv if op=='-' else av*bv
  elif isinstance(node,ast.Compare) and len(node.ops)==1 and type(node.ops[0]) in CMP:
   a,ak,av=visit(node.left,depth+1);b,bk,bv=visit(node.comparators[0],depth+1)
   if ak!='int' or bk!='int':raise ValueError('Only integer comparisons supported')
   code='('+a+' '+CMP[type(node.ops[0])]+' '+b+')';kind='bool';value=None
  else:raise ValueError('Unsupported expression semantics')
  if kind=='int' and abs(value)>99999:raise ValueError('Integer intermediate outside qualified printing/exactness domain')
  return code,kind,value
 code,kind,_=visit(tree.body)
 return {'catalog_id':identifier,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
  'typed_IR':{'kind':'bounded_scalar_expression','result_type':kind,'integer_intermediate_bound':99999},
  'generated_USL':'let result = '+code+'\n','scope_complete':False,'full_standard_qualified':False}

def execute_usl(artifact):
 from usl_systems.language import Interpreter
 run=Interpreter(max_ops=2000,timeout=2).run(artifact['generated_USL'])
 return run.variables['result'],{'actual_USL_execution':True,'operations':run.operations,
  'generated_source_sha256':hashlib.sha256(artifact['generated_USL'].encode()).hexdigest()}

def native(identifier,source):
 # Restrict before native execution. No arbitrary source/host capability exposed.
 artifact=translate(identifier,source)
 binary=shutil.which(NATIVE_NAMES[identifier])
 if binary is None:raise RuntimeError('Native host unavailable')
 with tempfile.TemporaryDirectory(prefix='usl-scalar-') as directory:
  root=Path(directory);ext={'asymptote':'asy','openscad':'scad','gdscript':'gd'}[identifier]
  path=root/('input.'+ext);path.write_text(source)
  env=dict(os.environ)
  if identifier=='asymptote':
   env.update(ASYMPTOTE_HOME=directory,ASYMPTOTE_DIR='/workspace/.onboarding/sysroot/usr/share/asymptote')
   command=[binary,'-noV','-tex','none',str(path)]
  elif identifier=='openscad':command=[binary,'-o',str(root/'observed.echo'),str(path)]
  else:
   for sub in ['config','data','cache']:(root/sub).mkdir()
   env.update(XDG_CONFIG_HOME=str(root/'config'),XDG_DATA_HOME=str(root/'data'),XDG_CACHE_HOME=str(root/'cache'))
   command=[binary,'--headless','--path',directory,'--script',str(path)]
  run=subprocess.run(command,capture_output=True,text=True,env=env,cwd=directory,timeout=10)
  if run.returncode:raise RuntimeError(identifier+' failed: '+run.stderr[:1000])
  if identifier=='openscad':
   text=(root/'observed.echo').read_text();match=re.fullmatch(r'ECHO: "USL_RESULT", (.+)\n?',text)
  elif identifier=='asymptote':match=re.fullmatch(r'USL_RESULT:\n(.+)\n?',run.stdout)
  else:match=re.search(r'^USL_RESULT:(.+)$',run.stdout,re.M)
  if not match:raise RuntimeError('Native observation marker missing: '+run.stdout[:500]+run.stderr[:500])
  token=match[1].strip()
  if token.lower() in {'true','false'}:value=token.lower()=='true'
  elif re.fullmatch(r'-?\d+',token):value=int(token)
  else:raise RuntimeError('Native scalar output outside qualified domain: '+token)
  if type(value).__name__!=artifact['typed_IR']['result_type'].replace('bool','bool').replace('int','int'):
   raise ValueError('Native result type disagrees with typed profile')
  return value,{'native_name':NATIVE_NAMES[identifier],'executable':binary,'returncode':run.returncode,
   'stdout':run.stdout,'stderr':run.stderr,'observation_cache_used':False,'fresh_native_process':True}


def translate_robot(source):
 """Selected Robot7.5 suite: integer variables and integer-equality assertions."""
 if not isinstance(source,str) or len(source)>65536:raise ValueError('Source resource limit')
 lines=source.splitlines();variables={};assertions=[];section=None;test_seen=False
 for raw in lines:
  if not raw.strip():continue
  if raw=='*** Variables ***':
   if section is not None:raise ValueError('Variables section must be first')
   section='variables';continue
  if raw=='*** Test Cases ***':section='tests';continue
  if section=='variables':
   m=re.fullmatch(r'\$\{([A-Za-z][A-Za-z0-9_]*)\} {2,}(-?(?:0|[1-9][0-9]*))',raw)
   if not m or m[1] in variables:raise ValueError('Unsupported variable declaration')
   value=int(m[2])
   if abs(value)>99999:raise ValueError('Integer outside qualified domain')
   variables[m[1]]=value
  elif section=='tests':
   if not raw[0].isspace():
    if raw!='Contract' or test_seen:raise ValueError('Exactly one Contract test supported')
    test_seen=True;continue
   if not test_seen:raise ValueError('Keyword precedes test')
   columns=re.split(r' {2,}',raw.strip())
   if len(columns)!=3 or columns[0]!='Should Be Equal As Integers':raise ValueError('Unsupported Robot keyword')
   values=[]
   for item in columns[1:]:
    m=re.fullmatch(r'\$\{([A-Za-z][A-Za-z0-9_]*)\}',item)
    if m:
     if m[1] not in variables:raise ValueError('Unbound Robot variable')
     values.append(variables[m[1]])
    elif re.fullmatch(r'-?(?:0|[1-9][0-9]*)',item) and abs(int(item))<=99999:values.append(int(item))
    else:raise ValueError('Unsupported integer conversion syntax')
   assertions.append(values)
  else:raise ValueError('Unsupported suite structure')
 if not test_seen or not assertions:raise ValueError('No qualified assertion')
 code='let result = '+ ' and '.join('('+str(a)+' == '+str(b)+')' for a,b in assertions)+'\n'
 return {'catalog_id':'robotframework','source_sha256':hashlib.sha256(source.encode()).hexdigest(),
  'typed_IR':{'kind':'integer_assertion_suite','variables':variables,'assertions':assertions,'result_type':'bool'},
  'generated_USL':code,'full_standard_qualified':False}

def native_robot(source):
 import xml.etree.ElementTree as ET
 translate_robot(source)
 with tempfile.TemporaryDirectory(prefix='usl-robot-') as directory:
  root=Path(directory);path=root/'input.robot';path.write_text(source)
  command=[shutil.which('robot'),'--outputdir',directory,'--log','NONE','--report','NONE','--console','none',str(path)]
  run=subprocess.run(command,capture_output=True,text=True,timeout=10,cwd=directory)
  if run.returncode not in {0,1}:raise RuntimeError('Native Robot setup/parse failure: '+run.stderr[:1000])
  tree=ET.parse(root/'output.xml');statuses=tree.findall('.//test/status')
  if len(statuses)!=1:raise ValueError('Native Robot test count mismatch')
  value=statuses[0].attrib['status']=='PASS'
  if value!=(run.returncode==0):raise ValueError('Native status/exit mismatch')
  return value,{'executable':shutil.which('robot'),'returncode':run.returncode,'status':statuses[0].attrib['status'],
   'stdout':run.stdout,'stderr':run.stderr,'fresh_native_process':True,'observation_cache_used':False}
