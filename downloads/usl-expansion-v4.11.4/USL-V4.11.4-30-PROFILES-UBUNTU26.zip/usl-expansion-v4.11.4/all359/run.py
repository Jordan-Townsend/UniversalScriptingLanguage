"""Fresh independent/native/generated validation for four bounded profiles."""
from __future__ import annotations
import argparse, asyncio, hashlib, json, os, shutil, subprocess
from pathlib import Path
import sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent
IDS=['asymptote','openscad','gdscript','robotframework']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,value):Path(path).write_text(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n')

def arithmetic_cases():
 # Independent finite intent oracle uses order-table positions and repeated
 # counting. It does not inspect translation output or call the frontend.
 domain=[-2,-1,0,1,2];cases=[]
 for a in domain:
  for b in domain:
   ab=a+2;bb=b+2
   product=sum(abs(a) for _ in range(abs(b)))
   if (a<0)!=(b<0):product=-product
   expected={'+':sum([a,b]),'-':sum([a,-b]),'*':product,
    '==':ab==bb,'!=':ab!=bb,'<':ab<bb,'<=':ab<=bb,'>':ab>bb,'>=':ab>=bb}
   for op in expected:
    cases.append({'name':'finite-'+str(a)+'-'+op+'-'+str(b),'expression':'('+str(a)+') '+op+' ('+str(b)+')',
     'expected':expected[op],'contract':'Every pair in the declared five-integer domain under this operator'})
 cases.extend({'name':'compound-'+str(i),'expression':expr,'expected':value,'contract':contract}
  for i,(expr,value,contract) in enumerate([
   ('(2+3)*4',20,'parentheses bind before multiplication'),
   ('2+3*4',14,'multiplication binds before addition'),
   ('-(-7)',7,'nested unary negation'),
   ('-(2+3)*4',-20,'unary sign applies to complete parenthesized expression'),
   ('2*(3-8)+7',-3,'nested mixed arithmetic'),
   ('(2+3)*4 == 20',True,'comparison after nested arithmetic'),
   ('7-3-2',2,'subtraction associates left'),
   ('99999-99999',0,'declared upper printing/exactness boundary'),
   ('(-99999) < 99999',True,'signed domain boundaries'),
   ('0 == -0',True,'signed integer zero equality')]))
 return cases

def robot_cases():
 cases=[]
 for a in [-2,-1,0,1,2]:
  for b in [-2,-1,0,1,2]:
   source='*** Test Cases ***\nContract\n    Should Be Equal As Integers    '+str(a)+'    '+str(b)+'\n'
   cases.append({'name':'literal-'+str(a)+'-'+str(b),'source':source,'expected':a==b,'contract':'Equality of independently chosen integer arguments'})
 for a in [-2,-1,0,1,2]:
  for actual,expected in [(a,True),(a+1,False)]:
   source='*** Variables ***\n${A}    '+str(a)+'\n*** Test Cases ***\nContract\n    Should Be Equal As Integers    ${A}    '+str(actual)+'\n'
   cases.append({'name':'variable-'+str(a)+'-'+str(actual),'source':source,'expected':expected,'contract':'Variable substitution preserves the declared integer; unequal literal fails'})
 cases.extend([
  {'name':'conjunction-pass','source':'*** Test Cases ***\nContract\n    Should Be Equal As Integers    7    7\n    Should Be Equal As Integers    -3    -3\n','expected':True,'contract':'All assertions pass'},
  {'name':'conjunction-fail','source':'*** Test Cases ***\nContract\n    Should Be Equal As Integers    7    7\n    Should Be Equal As Integers    -3    3\n','expected':False,'contract':'A later unequal assertion fails the test'}])
 return cases

def execute_case(identifier,case):
 from native_profiles import wrap,translate,translate_robot,execute_usl,native,native_robot
 source=case['source'] if identifier=='robotframework' else wrap(identifier,case['expression'])
 artifact=translate_robot(source) if identifier=='robotframework' else translate(identifier,source)
 observed,native_receipt=native_robot(source) if identifier=='robotframework' else native(identifier,source)
 generated,usl_receipt=execute_usl(artifact)
 passed=type(observed) is type(case['expected']) and type(generated) is type(case['expected']) and observed==case['expected']==generated
 return {'name':case['name'],'source':source,'source_sha256':sha_bytes(source),'typed_IR':artifact['typed_IR'],
  'generated_USL':artifact['generated_USL'],'intent_contract':case['contract'],'independent_expected':case['expected'],
  'native_observed':observed,'native_receipt':native_receipt,'generated_observed':generated,'USL_receipt':usl_receipt,'passed':passed}

def sha_bytes(source):return hashlib.sha256(source.encode()).hexdigest()

def unsupported_checks(identifier):
 from native_profiles import wrap,translate,translate_robot
 if identifier=='robotframework':
  sources=['*** Test Cases ***\nContract\n    Run    ignored    ignored\n',
   '*** Test Cases ***\nContract\n    Should Be Equal As Integers    ${MISSING}    3\n',
   '*** Test Cases ***\nContract\n    Should Be Equal As Integers    1.0    1\n',
   '*** Test Cases ***\nContract\n    Should Be Equal As Integers    100000    100000\n']
  compile_=translate_robot
 else:
  sources=[wrap(identifier,expr) for expr in ['4/2','run(1)','99999+1','1<2<3']]
  compile_=lambda source:translate(identifier,source)
 checks=[]
 for source in sources:
  try:
   compile_(source);checks.append({'source':source,'rejected':False,'contract':'Unsupported semantics must fail before execution'})
  except ValueError as error:checks.append({'source':source,'rejected':True,'error':str(error),'contract':'Unsupported semantics must fail before execution'})
 return checks

def provider_identity(identifier):
 from native_profiles import NATIVE_NAMES
 name='robot' if identifier=='robotframework' else NATIVE_NAMES[identifier]
 binary=shutil.which(name)
 if binary is None:raise RuntimeError('Native provider missing: '+name)
 path=Path(binary).resolve();version=subprocess.run([binary,'--version'],capture_output=True,text=True,timeout=5)
 return {'name':name,'path':binary,'resolved_path':str(path),'sha256':sha(path),
  'version_query_returncode':version.returncode,'version_stdout':version.stdout[:2500],'version_stderr':version.stderr[:2500],
  'version_queried_freshly':True,'full_provider_dependency_provenance_qualified':False}

async def run(args):
 sys.path.insert(0,str(args.source_root));sys.path.insert(0,str(args.previous))
 from semantic_records import resource_admission
 output=args.output;output.mkdir(parents=True,exist_ok=True)
 started=time.perf_counter();source_hashes={p.name:sha(p) for p in [ROOT/'native_profiles.py',ROOT/'run.py']}
 identities={identifier:provider_identity(identifier) for identifier in IDS}
 jobs=[(identifier,case) for identifier in IDS for case in (robot_cases() if identifier=='robotframework' else arithmetic_cases())]
 admission=resource_admission(len(jobs),output)
 cpu=os.cpu_count() or 1
 try:
  quota,period=Path('/sys/fs/cgroup/cpu.max').read_text().split()
  if quota!='max':cpu=max(1,min(cpu,int(quota)//int(period)))
 except (OSError,ValueError):pass
 slots=max(1,min(len(jobs),cpu,admission['thread_slots'] or 1))
 executor=ThreadPoolExecutor(max_workers=slots);loop=asyncio.get_running_loop();gate=asyncio.Event();ready=0;active=0;peak=0
 async def actor(identifier,case):
  nonlocal ready,active,peak
  ready+=1
  if ready==len(jobs):gate.set()
  await gate.wait();active+=1;peak=max(peak,active)
  try:
   result=await loop.run_in_executor(executor,execute_case,identifier,case)
   return identifier,result
  except Exception as error:return identifier,{'name':case['name'],'passed':False,'error':type(error).__name__+': '+str(error)}
  finally:active-=1
 try:results=await asyncio.gather(*(actor(identifier,case) for identifier,case in jobs))
 finally:executor.shutdown(wait=True)
 qualifications=[]
 for identifier in IDS:
  records=[record for found,record in results if found==identifier];directory=output/identifier;directory.mkdir(exist_ok=True)
  rejections=unsupported_checks(identifier)
  scope=('RobotFramework7.5: one Contract test, optional declared canonical signed-decimal integer variables, selected Should Be Equal As Integers assertions and conjunction pass/fail; integers within[-99999,99999]; imports, arbitrary keywords, conversions, loops, libraries and other framework features rejected'
   if identifier=='robotframework' else identifier+': one scalar-output program; signed-decimal integer literals, unary signs, +,-,*, parentheses and one comparison; every integer intermediate within[-99999,99999], depth<=12; no names/calls/division/state/graphics/modules/libraries or effects beyond scalar output')
  provider=identities[identifier]
  provider_unchanged=sha(provider['resolved_path'])==provider['sha256']
  receipt={'schema':'usl.four-existing-native-profiles.v1','catalog_id':identifier,'passed':all(r['passed'] for r in records) and all(c['rejected'] for c in rejections) and provider_unchanged,
   'scope':scope,'full_standard_qualified':False,'arbitrary_program_equivalence_proved':False,
   'independent_intent_cases':len(records),'fresh_native_executions':sum('native_receipt' in r for r in records),
   'fresh_generated_USL_executions':sum('USL_receipt' in r for r in records),'native_observation_cache_used':False,
   'finite_pair_domain_exhausted':[-2,-1,0,1,2],'source_hashes':source_hashes,
   'native_provider_identity':provider,'native_provider_file_unchanged_during_run':provider_unchanged,
   'unsupported_frontend_checks':rejections,
   'source_unchanged_during_run':all(sha(ROOT/name)==identity for name,identity in source_hashes.items()),
   'records':records,'outstanding':['exact full-version normative clause audit','all omitted language/library/effect/platform features','universal translation proof','independent external review']}
  dump(directory/'qualification.json',receipt);qualifications.append({k:v for k,v in receipt.items() if k!='records'})
 summary={'passed':all(r['passed'] for r in qualifications),'qualified_profiles':qualifications,
  'logical_case_actors_started_together':len(jobs),'peak_live_logical_case_actors':peak,'resource_admitted_native_processes':slots,
  'fixed_rounds':False,'resource_admission':admission,'seconds':time.perf_counter()-started,
  'new_full_standard_qualifications':0,'full_project_completed':False}
 dump(output/'SUMMARY.json',summary)
 joined={'schema':'usl.all359.four-profile-join.v1','passed':summary['passed'],'records':[{
  'catalog_id':r['catalog_id'],'scoped_profile_validated':r['passed'],
  'full_standard_qualified':False,'exact_profile':r['scope'],'cases':r['independent_intent_cases'],
  'native_executions':r['fresh_native_executions'],'usl_executions':r['fresh_generated_USL_executions'],
  'open_obligations':r['outstanding'],'qualification_file':r['catalog_id']+'/qualification.json',
  'qualification_sha256':sha(output/r['catalog_id']/'qualification.json'),
  'unsupported_frontend_checks':len(r['unsupported_frontend_checks'])} for r in qualifications],
  'logical_case_actors_started_together':len(jobs),'fresh_native_executions':sum(r['fresh_native_executions'] for r in qualifications),
  'fresh_generated_USL_executions':sum(r['fresh_generated_USL_executions'] for r in qualifications),
  'new_full_standard_qualifications':0}
 dump(output/'results.json',joined)
 dump(output/'MANIFEST.json',{str(p.relative_to(output)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in output.rglob('*.json') if p.name!='MANIFEST.json'})
 return summary

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source-root',type=Path,default=Path('/workspace/usl-v4.10.0-clean-test'));parser.add_argument('--previous',type=Path,default=Path('/workspace/usl-planning-v4.11.2'));parser.add_argument('--output',type=Path,default=ROOT/'native-results')
 args=parser.parse_args();result=asyncio.run(run(args));print(json.dumps(result,sort_keys=True));raise SystemExit(0 if result['passed'] else 1)
if __name__=='__main__':main()
