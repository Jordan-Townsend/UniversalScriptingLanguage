All359 baseline IDs have independently checked USL routing, evidence-linked implementation plans, version/category gaps, source/install candidates, actual tool-file identities, safe version observations, and native/intent/conformance obligations in `results/ALL359.json`. Full original obligations and ordered steps are factored losslessly into separate hash-addressed objects. Inventory does not implement or qualify a language.

`run.py` separately validates four actual bounded frontends: Asymptote3.02, OpenSCAD2021.01, GDScript on Godot4.6.3, and Robot Framework7.5. Native source is parsed before generating executable USL. The first three support one integer/Boolean scalar expression with signed literals, unary signs, arithmetic, parentheses and comparisons; every integer intermediate lies within[-99999,99999]. Robot supports selected integer variable declarations and integer-equality assertion suites, with explicit PASS/FAIL intent contracts. Unsupported features fail before native execution.

Run in the activated USL environment:

```bash
python audit.py --previous /workspace/usl-planning-v4.11.2 --source-root /workspace/usl-v4.10.0-clean-test
python run.py --source-root /workspace/usl-v4.10.0-clean-test --previous /workspace/usl-planning-v4.11.2 --output native-results
python -m unittest test_all359
```

The audit needs the prior evidence/data and existing authenticated Debian metadata. The qualification runner needs the prior resource-admission helper, USL base and already installed native hosts. It ships no native binaries. `native-results/results.json` is the compact integration API; detailed source, generated USL, independent expectations, fresh native observations, provider hashes/version observations and frontend rejection cases remain in each per-ID receipt.

The742 native/USL intent cases exhaust a finite five-integer pair/operator domain and include compound/boundary cases. This is bounded execution evidence. It is not proof of arbitrary program equivalence, complete language standards, graphics/device abilities, all libraries or full entity completion.
