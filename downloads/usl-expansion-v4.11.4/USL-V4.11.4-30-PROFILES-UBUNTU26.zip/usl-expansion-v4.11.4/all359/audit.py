"""Fresh inventory and retained implementation obligations for every359 IDs.

Source/host/reference inventories do not implement any language. The standalone
bounded implementations in this directory, if any, retain separate receipts.
"""
from __future__ import annotations
import argparse, asyncio, collections, csv, hashlib, json, os
from pathlib import Path
import re, resource, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent
PREVIOUS=Path('/workspace/usl-planning-v4.11.2')
BASE=Path('/workspace/usl-v4.10.0-clean-test')
CACHE=Path('/workspace/.onboarding/data/v411-public-reference-cache')
APT=Path('/workspace/.onboarding/apt/lists')

# Explicit binary-package leads, independently joined to authenticated metadata.
# An installed file or a package lead does not establish source-dialect support.
PACKAGE_LEADS='''
agda literate-agda|agda-bin
aspectj|aspectj
asymptote|asymptote
bbcbasic|brandy
befunge|cfunge
blitzmax|blitzmax
bnf peg|peg
bsdmake basemake|bmake make
bugs|openbugs
capdl|python3-capdl
cbmbas|vice
chaiscript|chaiscript
charmci|charm++
clean|clean
componentpascal|gpcp
cryptol literate-cryptol|cryptol
cddl|ruby-cddl
cypher|neo4j
dart|dart
devicetree|device-tree-compiler
docker|docker.io podman
elpi|elpi
elm|elm-compiler
emacs-lisp|emacs-nox
execline|execline
ezhil|ezhil
factor|factor
fsharp|fsharp
fstar|fstar
futhark|futhark
freefem|freefem++
gdscript|godot godot4
glsl|glslang-tools
hspec|libghc-hspec-dev
icon ucode|icont iconx
idl|gnudatalanguage
inform6|inform6-compiler
inform7|inform7
isabelle|isabelle
jags|jags
janet|janet
jasmin|jasmin-sable
julia|julia
kconfig|kconfig-frontends
ldapconf|ldap-utils
lighttpd|lighttpd
lilypond|lilypond
logtalk|logtalk
llvm-mir llvm-mir-body amdgpu|llvm
macaulay2|macaulay2
mips|binutils-mips-linux-gnu qemu-user
modelica|openmodelica
mysql|default-mysql-client default-mysql-server
newlisp|newlisp
nixos|nix-bin
nsis|nsis
numba_ir|python3-numba
octave|octave
openscad|openscad
pacmanconf|pacman-package-manager
pan|panc
pddl|fast-downward
plpgsql postgresql|postgresql
pov|povray
praat|praat
promql|prometheus
puppet|puppet-agent
qml|qml-qt6 qmlscene
rd|r-base-core
reasonml|reason
redcode|pmars
rego|opa
registry batch vbscript|wine
resourcebundle|icu-devtools
robotframework|robotframework python3-robotframework
rql|python3-rql
scilab|scilab-cli
shexc|shex.js
sieve|dovecot-sieve
singularity|apptainer
slurm|slurm-client
smalltalk|gnu-smalltalk
smali|libsmali-java
snowball|snowball
solidity|solidity
spec|rpm
spice|ngspice
squidconf|squid
supercollider|supercollider-language
swig|swig
tablegen|llvm
tads3|frobtads
termcap terminfo|ncurses-bin
tid|node-tiddlywiki
usd|usd-core
vala|valac
vcl vclsnippets|varnish
webidl|node-webidl2
xorg.conf|xserver-xorg-core xvfb
xtend|libeclipse-xtend-java
'''

SAFE_VERSION_ARGS={
 'agda':['--numeric-version'],'asy':['--version'],'glslangValidator':['--version'],
 'godot':['--version'],'godot4':['--version'],'openscad':['--version'],
 'robot':['--version'],'R':['--version'],'Rscript':['--version'],'bibtex':['--version'],
 'bash':['--version'],'erl':['-version'],'ghc':['--numeric-version'],'haxe':['--version'],
 'lua':['-v'],'make':['--version'],'mono':['--version'],'node':['--version'],
 'perl':['-v'],'php':['--version'],'python':['--version'],'ragel':['-v'],
 'ruby':['--version'],'scala':['-version'],'swipl':['--version'],'z3':['--version'],
 'tic':['-V'],'infocmp':['-V'],'docker':['--version'],'factor':['--version']}

def encoded(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def digest(x): return hashlib.sha256(encoded(x)).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as s:
  for b in iter(lambda:s.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):Path(p).write_bytes(encoded(x)+b'\n')

def package_leads():
 result={}
 for line in PACKAGE_LEADS.strip().splitlines():
  ids,packages=line.split('|')
  for identifier in ids.split():result[identifier]=packages.split()
 return result

def package_inventory(output,wanted):
 release=APT/'deb.debian.org_debian_dists_trixie_InRelease'
 packages=APT/'deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages'
 authenticated=output/'AUTHENTICATED_RELEASE.txt'
 command=['sqv','--keyring=/usr/share/keyrings/debian-archive-keyring.pgp','--output='+str(authenticated),'--cleartext',str(release)]
 # Recreate only this tranche's own authentication output; upstream cache stays immutable.
 if authenticated.exists():authenticated.unlink()
 check=subprocess.run(command,capture_output=True,text=True,timeout=20)
 if check.returncode:raise ValueError('Debian metadata signature verification failed: '+check.stderr[:500])
 text=authenticated.read_text(); match=re.search(r'^ ([0-9a-f]{64})\s+(\d+) main/binary-amd64/Packages$',text,re.M)
 if not match or packages.stat().st_size!=int(match[2]) or sha(packages)!=match[1]:raise ValueError('Authenticated package-index hash mismatch')
 found={};fields={}
 with packages.open() as stream:
  for line in stream:
   if not line.strip():
    if fields.get('Package') in wanted:
     keys=['Package','Version','Architecture','Installed-Size','Size','Filename','SHA256','Depends','Pre-Depends','Homepage','Description']
     found[fields['Package']]={k:fields[k] for k in keys if k in fields}
    fields={}
   elif line[0]!=' ' and ': ' in line:
    k,v=line.rstrip('\n').split(': ',1);fields[k]=v
 return {'release_sha256':sha(release),'packages_sha256':match[1],'signature_verified_now':True,
  'trust_keyring_sha256':sha('/usr/share/keyrings/debian-archive-keyring.pgp'),'sqv_stderr':check.stderr[:1000],
  'package_index_is_existing_snapshot_not_fresh_repository_state':True,'packages':found}

def native_file_inventory(names):
 prefixes=[Path('/workspace/.onboarding/expansion-v411/sysroot/usr/bin'),Path('/workspace/.onboarding/expansion-v411/sysroot/usr/sbin'),
  Path('/workspace/.onboarding/forth-v4112/usr/bin')]
 results={}
 for name in sorted(names):
  paths=set()
  if shutil.which(name):paths.add(shutil.which(name))
  paths.update(str(d/name) for d in prefixes if (d/name).is_file())
  entries=[]
  for file in sorted(paths):
   p=Path(file);entries.append({'path':file,'resolved_path':str(p.resolve()),'sha256':sha(p.resolve()),'bytes':p.stat().st_size,
    'executable_bit':os.access(p,os.X_OK),'provider_identity_and_dialect_qualified':False})
  results[name]={'name':name,'paths':entries,'found':bool(entries)}
  if name in {'factor','jconsole'}:results[name]['identity_collision_warning']='GNU factor / JDK jconsole names can collide with language implementations; inspect provider first'
 return results

def version_query(name,entry):
 command=[entry['paths'][0]['path'],*SAFE_VERSION_ARGS[name]]
 start=time.perf_counter()
 try:
  r=subprocess.run(command,capture_output=True,text=True,timeout=5,env={**os.environ,'QT_QPA_PLATFORM':'offscreen'})
  return {'argv':command,'returncode':r.returncode,'stdout':r.stdout[:2500],'stderr':r.stderr[:2500],
   'seconds':time.perf_counter()-start,'fresh_version_query':True,'language_execution_qualification':False}
 except Exception as e:return {'argv':command,'error':str(e),'fresh_version_query':True,'language_execution_qualification':False}

def validate_ids(current,plans):
 rows=[r for r in current['records'] if r['original_catalog'] and not r['validated_bounded_profile']]
 ids={r['catalog_id'] for r in rows}
 if len(rows)!=359 or len(ids)!=359:raise ValueError('All359 original unqualified IDs must be retained')
 if not ids<=plans.keys():raise ValueError('Missing all-ID source plans')
 return rows

def usl_route(task,policy):
 from usl_systems.language import Interpreter
 execution=Interpreter(capabilities={'all359_inputs':lambda:task},max_ops=1000,timeout=2).run(policy)
 expected={'source_route':'audit_retrieved_clause_candidates' if task['document_count'] else 'recover_correct_upstream_body',
  'host_route':'retain_external_host_and_continue_offline_semantic_work' if task['external_dependency'] else
   'verify_provider_version_then_native_contract' if task['tool_paths'] else 'pin_compatible_source_or_install_option',
  'full_standard_qualified':False,'inventory_is_implementation':False}
 if execution.variables['decision']!=expected:raise ValueError('USL audit route disagrees with independent check')
 return expected,{'actual_USL_execution':True,'operations':execution.operations,'policy_sha256':hashlib.sha256(policy.encode()).hexdigest(),'independently_checked':True}

async def audit(args):
 start=time.perf_counter();output=ROOT/'results';output.mkdir(parents=True,exist_ok=True)
 sys.path.insert(0,str(args.previous));sys.path.insert(0,str(args.source_root))
 from scope_all import probe_names
 from semantic_records import resource_admission,read_object
 current_path=args.previous/'current-scope-results/CURRENT_SCOPE.json';plans_path=args.previous/'scope-all-results/ALL_IDS.json'
 current=json.loads(current_path.read_text());plans={r['catalog_id']:r for r in json.loads(plans_path.read_text())['records']}
 rows=validate_ids(current,plans);policy=(ROOT/'policy.usl').read_text()
 inputs={'current_scope_sha256':sha(current_path),'source_plans_sha256':sha(plans_path),'pipeline_sha256':sha(__file__),'policy_sha256':sha(ROOT/'policy.usl')}
 probes=probe_names();tools=native_file_inventory({x for row in rows for x in probes.get(row['catalog_id'],[])})
 leads=package_leads();packages=package_inventory(output,{x for row in rows for x in leads.get(row['catalog_id'],[])})
 dump(output/'TOOL_FILES.json',tools);dump(output/'PACKAGE_OPTIONS.json',packages)
 version_names=[name for name in SAFE_VERSION_ARGS if name in tools and tools[name]['found']]
 physical=resource_admission(len(version_names),output)
 # Version processes consume actual CPU; cgroup quota determines admission.
 cpu=max(1,os.cpu_count() or 1)
 try:
  quota,period=Path('/sys/fs/cgroup/cpu.max').read_text().split()
  if quota!='max':cpu=max(1,min(cpu,int(quota)//int(period)))
 except (OSError,ValueError):pass
 native_slots=max(1,min(len(version_names) or 1,cpu,physical['thread_slots'] or 1))
 executor=ThreadPoolExecutor(max_workers=native_slots);loop=asyncio.get_running_loop()
 try:versions=dict(zip(version_names,await asyncio.gather(*(loop.run_in_executor(executor,version_query,n,tools[n]) for n in version_names))))
 finally:executor.shutdown(wait=True)
 dump(output/'VERSION_OBSERVATIONS.json',versions)
 dimension_objects={};step_objects={};obligation_joins={};reference_flights={};reference_checks={};gate=asyncio.Event();ready=0;peak_live=0;live=0
 references={r['catalog_id']:plans[r['catalog_id']]['source_documents'] for r in rows}
 all_shas={d['body_sha256'] for docs in references.values() for d in docs}
 all_shas|={r['recovered_candidate_reference']['sha256'] for r in rows if r.get('recovered_candidate_reference')}
 admission=resource_admission(len(all_shas),output);io_slots=max(1,admission['thread_slots']);io=ThreadPoolExecutor(max_workers=io_slots);sem=asyncio.Semaphore(io_slots)
 async def verify_ref(identity):
  if identity not in reference_flights:
   async def once():
    async with sem:
     try:
      data=await loop.run_in_executor(io,read_object,args.private_cache,identity)
      answer={'sha256':identity,'body_present_and_hash_verified_now':True,'bytes':len(data),'reference_content_authority_or_semantics_audited':False}
     except (ValueError,OSError) as error:answer={'sha256':identity,'body_present_and_hash_verified_now':False,'error':str(error)}
     reference_checks[identity]=answer;return answer
   reference_flights[identity]=asyncio.create_task(once())
  return await reference_flights[identity]
 async def worker(row):
  nonlocal ready,live,peak_live
  ready+=1;live+=1;peak_live=max(peak_live,live)
  if ready==len(rows):gate.set()
  await gate.wait()
  identifier=row['catalog_id'];plan=plans[identifier];candidate=plan['candidate'];names=probes.get(identifier,[])
  present=[name for name in names if tools.get(name,{}).get('found')];missing=[name for name in names if name not in present]
  sources=[{'url':s['source_url'],'sha256':s['body_sha256'],'kind':'prior_structural_reference',
    'selected_section_locators':s['selected_section_locators']} for s in references[identifier]]
  if row.get('recovered_candidate_reference'):
   source=row['recovered_candidate_reference'];sources.append({'url':source['final_url'],'sha256':source['sha256'],'kind':'recovered_unreviewed_candidate','selected_section_locators':[]})
  checks=await asyncio.gather(*(verify_ref(s['sha256']) for s in sources))
  dims=plan['original_obligation_dimensions'];steps=plan['original_ordered_steps'];dh=digest(dims);sh=digest(steps)
  dimension_objects[dh]=dims;step_objects[sh]=steps;obligation_joins[identifier]={'dimensions_sha256':dh,'steps_sha256':sh}
  dependency=list(plan['host_plan']['external_dependencies'])
  # Keep additional candidate-specific platform/license questions explicit even
  # when historical catalog metadata omitted them. These are review needs.
  if plan['host_plan']['additional_platform_or_license_review_required']:
   dependency.append({'kind':'additional_platform_or_license_audit','requires':candidate['upstream_host_candidate'],
    'resolved':False,'evidence_kind':'authored_candidate_review_question'})
  task={'full_semantics_passed':False,'document_count':sum(c['body_present_and_hash_verified_now'] for c in checks),
   'tool_paths':len(present),'external_dependency':bool(dependency)}
  decision,receipt=usl_route(task,policy)
  options=[]
  for name in leads.get(identifier,[]):
   meta=packages['packages'].get(name)
   options.append({'package_name':name,'found_in_authenticated_debian_snapshot':bool(meta),'metadata':meta,
    'download_url':'https://deb.debian.org/debian/'+meta['Filename'] if meta else None,
    'qualified_for_catalog_dialect':False,'dependency_closure_audited':False,
    'next_argv':['apt-cache','show',name]})
  blockers=[{'kind':'exact_version_and_category','open':True,'next_action':'Choose the exact standard/release/dialect and target. Review source authority and every applicable normative clause.'},
   {'kind':'semantic_implementation','open':True,'specific_missing_features':candidate['semantic_focus']},
   {'kind':'native_differential_intent_conformance','open':True,'next_action':'Implement independently authored contracts, native/generated comparison and upstream/versioned suites; qualify only observed feature sets.'}]
  if not task['document_count']:blockers.append({'kind':'reference_body_missing','open':True})
  if not present:blockers.append({'kind':'compatible_native_provider_unproved','open':True})
  if dependency:blockers.append({'kind':'platform_license_or_device','open':True,'dependencies':dependency})
  concrete=[]
  for name in present:
   if name in SAFE_VERSION_ARGS:concrete.append({'kind':'fresh_safe_version_probe','argv':[tools[name]['paths'][0]['path'],*SAFE_VERSION_ARGS[name]],'does_not_qualify_language':True})
  for source in sources[:2]:concrete.append({'kind':'inspect_hash_pinned_reference','argv':['python',str(ROOT/'audit.py'),'--inspect',identifier],'source_url':source['url'],'sha256':source['sha256']})
  if not concrete:concrete.append({'kind':'inspect_authored_source_install_plan','argv':['python',str(ROOT/'audit.py'),'--inspect',identifier]})
  result={'catalog_id':identifier,'original_catalog':True,'family':row['family'],'category_proposal':plan['category_proposal'],
   'existing_qualified_profile':False,'audit_record_complete':True,'all_rule_sets_implemented':False,'full_standard_qualified':False,
   'identity':plan['version_identity'],'catalog_identity_correction':plan['catalog_identity_review_note'],
   'host_candidate':candidate['upstream_host_candidate'],'candidate_source_urls':plan['next_action']['network_reference_candidates'],
   'references':sources,'reference_integrity_checks':checks,'tool_names_present':present,'tool_names_missing':missing,
   'tool_inventory_locator':'TOOL_FILES.json','native_version_observation_names':[n for n in present if n in versions],
   'install_options':options,'native_install_discovery_complete':False,
   'specific_semantic_features_unimplemented':[{'feature':f,'implementation_complete':False,
    'intent_contract_obligation':'Independently specify valid, invalid and boundary behavior for '+f+'; compare observable values, errors, state and effects.'} for f in candidate['semantic_focus']],
   'proof_obligations':{'category_specific':plan['validation_contracts'],
    'native':'Pin actual source/runtime/library identities. Freshly run original and generated code with declared limits and original errors/effects.',
    'intent':'Author expected behavior independently of the frontend. Preserve holdout inputs and counterexamples. Use solver proofs only with explicit domains and trusted assumptions.',
    'conformance':'Map every applicable normative clause, library/API, ABI, platform and review requirement to independent passing evidence. A bounded profile does not satisfy this gate.'},
   'external_dependencies':dependency,'blockers':blockers,'concrete_next_commands':concrete,
   'lossless_original_obligation_join':{'dimension_count':len(dims),'ordered_step_count':len(steps),'dimensions_sha256':dh,'steps_sha256':sh},
   'source_plan_sha256':digest(plan),'source_current_record_sha256':digest(row),'USL_decision':decision,'USL_execution':receipt}
  live-=1;return result
 try:results=await asyncio.gather(*(worker(row) for row in rows))
 finally:io.shutdown(wait=True)
 results.sort(key=lambda r:r['catalog_id'])
 dump(output/'ALL359.json',{'schema':'usl.all359.actionable-audit.v1','source_identities':inputs,'records':results})
 dump(output/'OBLIGATION_OBJECTS.json',dimension_objects);dump(output/'STEP_OBJECTS.json',step_objects);dump(output/'REFERENCE_CHECKS.json',reference_checks)
 opportunities=[]
 for row in results:
  small=[o for o in row['install_options'] if o['metadata'] and int(o['metadata'].get('Size','999999999'))<10*1024**2]
  if row['tool_names_present'] or small:opportunities.append({'catalog_id':row['catalog_id'],'present_tools':row['tool_names_present'],
   'small_package_options':small,'full_dependency_size_unknown':True,'still_requires_actual_frontend_and_independent_validation':True})
 dump(output/'NATIVE_OPPORTUNITIES.json',opportunities)
 with (output/'ALL359.csv').open('w',newline='') as stream:
  writer=csv.writer(stream);writer.writerow(['ID','Family','Category','Tools present','Missing tool names','References','Package candidates','Specific semantic work','Full standard'])
  for r in results:writer.writerow([r['catalog_id'],r['family'],r['category_proposal'],';'.join(r['tool_names_present']),';'.join(r['tool_names_missing']),len(r['references']),';'.join(x['package_name'] for x in r['install_options']),';'.join(f['feature'] for f in r['specific_semantic_features_unimplemented']),False])
 lines=['# All359 implementation backlog','','These records preserve every remaining original ID. An audit record is not an implemented language. Exact version/category, semantics, libraries, ABI and full conformance remain open.','','| ID | Native tools found | Reference bodies | Specific remaining work |','|---|---|---:|---|']
 for r in results:lines.append('| '+r['catalog_id']+' | '+', '.join(r['tool_names_present'])+' | '+str(len(r['references']))+' | '+'; '.join(f['feature'] for f in r['specific_semantic_features_unimplemented']).replace('|','\\|')+' |')
 (output/'ALL359.md').write_text('\n'.join(lines)+'\n')
 summary={'all_remaining_original_ids':len(results),'logical_USL_workers_started_together':len(results),'peak_live_logical_workers':peak_live,
  'actual_USL_policy_executions':len(results),'all_USL_decisions_independently_checked':True,'fixed_batches_or_round_caps':False,
  'original_obligation_dimensions_preserved':sum(r['lossless_original_obligation_join']['dimension_count'] for r in results),
  'original_ordered_steps_preserved':sum(r['lossless_original_obligation_join']['ordered_step_count'] for r in results),
  'IDs_with_tool_files':sum(bool(r['tool_names_present']) for r in results),'IDs_with_verified_reference_bodies':sum(any(c['body_present_and_hash_verified_now'] for c in r['reference_integrity_checks']) for r in results),
  'unique_reference_bodies_hash_checked':len(reference_checks),'version_queries_executed':len(versions),'native_version_process_admission':native_slots,
  'IO_admission':admission,'new_language_qualifications_from_inventory':0,'full_standards_qualified':0,'seconds':time.perf_counter()-start,
  'source_unchanged_during_run':sha(__file__)==inputs['pipeline_sha256'] and sha(current_path)==inputs['current_scope_sha256'] and sha(plans_path)==inputs['source_plans_sha256']}
 dump(output/'SUMMARY.json',summary)
 dump(output/'MANIFEST.json',{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in output.iterdir() if p.is_file() and p.name!='MANIFEST.json'})
 return summary

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--previous',type=Path,default=PREVIOUS);p.add_argument('--source-root',type=Path,default=BASE);p.add_argument('--private-cache',type=Path,default=CACHE);p.add_argument('--inspect')
 args=p.parse_args()
 if args.inspect:
  records=json.loads((ROOT/'results/ALL359.json').read_text())['records'];match=[r for r in records if r['catalog_id']==args.inspect]
  if not match:p.error('Unknown or already-qualified baseline ID')
  print(json.dumps(match[0],indent=2,ensure_ascii=False))
 else:print(json.dumps(asyncio.run(audit(args)),sort_keys=True))
if __name__=='__main__':main()
