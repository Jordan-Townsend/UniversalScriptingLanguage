"""Independently authored intent cases; expectations are never native outputs."""
import json


def cases():
    out=[]
    def add(kind,name,source,expected=None,reject=False,native_reject=False):
        out.append({'catalog_id':kind,'name':name,'source':source,'expected':expected,
                    'frontend_reject':reject,'native_reject':native_reject})
    make=[
        ('recursive-late','A = first\nRESULT = $(A)\nA = last\n','last'),
        ('immediate-early','A = first\nRESULT := $(A)\nA = last\n','first'),
        ('recursive-append','A = one\nRESULT = $(A)\nRESULT += $(A)\nA = two\n','two two'),
        ('immediate-append','A = one\nRESULT := $(A)\nRESULT += $(A)\nA = two\n','one one'),
        ('conditional-set','RESULT ?= first\nRESULT ?= second\n','first'),
        ('empty-is-defined','RESULT =\nRESULT ?= second\n',''),
        ('undefined-is-empty','RESULT = A$(MISSING)B\n','AB'),
        ('empty-append','RESULT =\nRESULT += value\n','value'),
        ('empty-simple-append','RESULT :=\nRESULT += value\n','value'),
        ('empty-reference-recursive-append','RESULT = $(EMPTY)\nRESULT += value\n',' value'),
        ('empty-reference-simple-append','RESULT := $(EMPTY)\nRESULT += value\n','value'),
        ('comment',' # ignored\nA = x\nRESULT = prefix-$(A)-suffix\n','prefix-x-suffix'),
        ('append-undefined','RESULT += first\nRESULT += second\n','first second'),
    ]
    for name,source,expected in make:add('basemake',name,source,expected)
    for n in [0,1,7,999,32767]:add('basemake','lexeme-'+str(n),f'A = {n}\nRESULT := pre$(A)post\nA = changed\n',f'pre{n}post')
    add('basemake','invalid-syntax','this is not an assignment\n',reject=True,native_reject=True)
    add('basemake','recursive-cycle','A = $(A)\nRESULT = $(A)\n',reject=True,native_reject=True)
    add('basemake','unsafe-shell','RESULT = $(shell touch unsafe)\n',reject=True)
    defaults=[['am',False],['cols',-1],['lines',-1],['clear',None],['cup',None]]
    for kind in ['terminfo','termcap']:
        delim=':' if kind=='termcap' else ','
        co='co' if kind=='termcap' else 'cols';li='li' if kind=='termcap' else 'lines';cl='cl' if kind=='termcap' else 'clear';cm='cm' if kind=='termcap' else 'cup'
        def entry(fields):return 'usltest|isolated profile'+delim+delim.join(fields)+(delim if fields else '')+'\n'
        add(kind,'empty',entry([]),defaults)
        for columns in [0,1,80,32767]:
            for lines in [1,24,32767]:
                add(kind,f'dimensions-{columns}-{lines}',entry(['am',co+'#'+str(columns),li+'#'+str(lines)]),
                    [['am',True],['cols',columns],['lines',lines],['clear',None],['cup',None]])
        for spelling,bytevalues in [('hello',[104,101,108,108,111]),('\\E[H',[27,91,72]),('^A^?',[1,127]),('a\\nb\\t',[97,10,98,9]),('\\033\\177',[27,127])]:
            if kind=='termcap' and spelling=='^A^?':bytevalues=[1,31]
            add(kind,'escape-'+str(len(out)),entry([cl+'='+spelling,cm+'=X']),
                [['am',False],['cols',-1],['lines',-1],['clear',bytevalues],['cup',[88]]])
        add(kind,'cancel-explicit',entry(['am@',co+'@',cl+'@']),defaults)
        add(kind,'unknown-capability',entry(['unimplemented']),reject=True)
        add(kind,'too-large-dimension',entry([co+'#32768']),reject=True)
    for text in ['', 'hello', 'two words', 'quote " and slash \\', 'café', '𝄞', '\n\t']:
        encoded=json.dumps(text,ensure_ascii=True)
        add('resourcebundle','string-'+str(len(out)),'bundle { greeting { '+encoded+' } }', [['greeting','string',text]])
    for n in [-(1<<27),-1,0,1,(1<<27)-1]:
        add('resourcebundle','int-'+str(n),f'bundle {{ count:int {{ {n} }} greeting {{ "ok" }} }}',
            [['count','int',n],['greeting','string','ok']])
    add('resourcebundle','key-order','bundle { z { "last" } a { "first" } }',[['a','string','first'],['z','string','last']])
    add('resourcebundle','duplicate-key','bundle { a { "x" } a { "y" } }',reject=True,native_reject=True)
    add('resourcebundle','truncated','bundle { a { "x" }',reject=True,native_reject=True)
    add('resourcebundle','outside-int28','bundle { a:int { 134217728 } }',reject=True)
    for uid in [0,1,65534,4294967294]:
        source=f'alice:x:{uid}:20:Alice Example:/home/alice:/bin/sh\n'
        add('unixconfig','uid-'+str(uid),source,[['alice','x',uid,20,'Alice Example','/home/alice','/bin/sh']])
    add('unixconfig','ordered-duplicates','user:x:1:2::/:/bin/sh\nuser:!:3:4:second:/tmp:/bin/false\n',
        [['user','x',1,2,'','/','/bin/sh'],['user','!',3,4,'second','/tmp','/bin/false']])
    add('unixconfig','comments-and-malformed','# comment\n\nwrong:field:count\na:x:bad:2::/:/bin/sh\nvalid:x:9:8::/:/bin/sh\n',
        [['valid','x',9,8,'','/','/bin/sh']])
    add('unixconfig','empty-fields','user::1:2:::\n',[['user','',1,2,'','','']])
    add('unixconfig','missing-final-newline','user:x:1:2::/:/bin/sh',[['user','x',1,2,'','/','/bin/sh']])
    add('unixconfig','non-ascii-uid-is-skipped','u:x:١:2::/:/bin/sh\n',[])
    add('unixconfig','leading-zero-id','u:x:01:002::/:/bin/sh\n',[['u','x',1,2,'','/','/bin/sh']])
    add('unixconfig','unsupported-special-uid','user:x:4294967295:2::/:/bin/sh\n',reject=True)
    add('unixconfig','unsupported-nis-record','+user::::::\n',reject=True)
    add('unixconfig','unsupported-colon-shell','u:x:1:2::/:/bin/sh:extra\n',reject=True)
    for gid in [0,1,65534,4294967294]:
        add('unixconfig','group-gid-'+str(gid),f'staff:x:{gid}:alice,bob\n',
            [['staff','x',gid,['alice','bob']]])
    add('unixconfig','group-empty-members','staff::1:\n',[['staff','',1,[]]])
    add('unixconfig','group-ordered-duplicates','staff:x:1:bob,alice\nstaff:!:2:root\n',
        [['staff','x',1,['bob','alice']],['staff','!',2,['root']]])
    add('unixconfig','group-malformed-and-comments','# ignored\nbad:row\ninvalid:x:no:alice\nvalid:x:2:alice\n',
        [['valid','x',2,['alice']]])
    add('unixconfig','group-missing-final-newline','staff:x:01:alice',[['staff','x',1,['alice']]])
    add('unixconfig','group-non-ascii-id-skipped','staff:x:١:alice\n',[])
    add('unixconfig','group-special-id','staff:x:4294967295:alice\n',reject=True)
    add('unixconfig','group-empty-member-token','staff:x:1:alice,,bob\n',reject=True)
    add('unixconfig','mixed-passwd-group','u:x:1:2::/:/bin/sh\nstaff:x:1:u\n',reject=True)
    base=[['BASE',''],['DEREF',0],['SIZELIMIT',0],['TIMELIMIT',0]]
    add('ldapconf','defaults','# no options\n',base)
    for n in [0,1,9,2147483647]:
        add('ldapconf','limits-'+str(n),f'SIZELIMIT {n}\nTIMELIMIT {n}\n',
            [['BASE',''],['DEREF',0],['SIZELIMIT',n],['TIMELIMIT',n]])
    for word,value in [('never',0),('searching',1),('finding',2),('always',3)]:
        add('ldapconf','deref-'+word,'DEREF '+word+'\n',[['BASE',''],['DEREF',value],['SIZELIMIT',0],['TIMELIMIT',0]])
    add('ldapconf','last-value-and-case','base dc=first,dc=example\nBASE dc=last,dc=example\nSIZELIMIT 2\nSIZELIMIT 3\n',
        [['BASE','dc=last,dc=example'],['DEREF',0],['SIZELIMIT',3],['TIMELIMIT',0]])
    add('ldapconf','unsupported-option','TLS_REQCERT never\n',reject=True)
    add('ldapconf','invalid-deref','DEREF unknown\n',reject=True)
    for a in [False,True]:
        for b in [False,True]:
            source=f'config A\n bool "A"\n default {"y" if a else "n"}\nconfig B\n bool "B"\n default {"y" if b else "n"}\n depends on A\n'
            add('kconfig',f'bool-dep-{a}-{b}',source,[['A','bool',a],['B','bool',a and b]])
    for n in [-2147483648,-1,0,2147483647]:
        add('kconfig','int-'+str(n),f'config N\n int "N"\n default {n}\n',[['N','int',n]])
    for text in ['', 'hello world']:
        add('kconfig','string-'+str(len(out)),'config S\n string "S"\n default '+json.dumps(text)+'\n',[['S','string',text]])
    add('kconfig','first-matching-default','config A\n bool\n default y\nconfig B\n int\n default 7 if A\n default 9\n',
        [['A','bool',True],['B','int',7]])
    add('kconfig','forward-dependency','config B\n bool\n depends on A\nconfig A\n bool\n default y\n',reject=True)
    add('kconfig','invalid-native-syntax','nonsense invalid\n',reject=True,native_reject=True)
    for n in [0,1,255,256,65535,4294967295]:
        raw=[n//16777216%256,n//65536%256,n//256%256,n%256]
        add('devicetree','u32-'+str(n),f'/dts-v1/; / {{ value = <{n}>; }};', [['/','value',raw]])
    add('devicetree','multiple-cells','/dts-v1/; / { reg = <1 0xff 65536>; };',
        [['/','reg',[0,0,0,1,0,0,0,255,0,1,0,0]]])
    add('devicetree','strings-and-flag','/dts-v1/; / { compatible = "vendor,device", "generic"; enabled; };',
        [['/','compatible',list(b'vendor,device\0generic\0')],['/','enabled',[]]])
    add('devicetree','child-node','/dts-v1/; / { model = "root"; child { value = <7>; }; };',
        [['/','model',list(b'root\0')],['/child','value',[0,0,0,7]]])
    add('devicetree','invalid-syntax','/dts-v1/; / { value = <1>; ',reject=True,native_reject=True)
    add('devicetree','unsupported-phandle','/dts-v1/; / { value = <&other>; };',reject=True)
    return out
