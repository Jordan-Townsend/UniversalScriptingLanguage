"""Independent intent, exclusion, result-schema, and supply-chain regressions.

Run after a fresh run.py invocation; USL_SOURCE_ROOT selects the runtime checkout.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, os.environ.get('USL_SOURCE_ROOT', '/workspace/usl-v4.10.0-clean-test'))
from usl_systems.language import Interpreter
from cases import cases
from frontends import FRONTENDS, Unsupported
import restore


class IntentTests(unittest.TestCase):
    pass


def make_intent_test(case):
    def test(self):
        if case['frontend_reject']:
            with self.assertRaises((Unsupported, ValueError)):
                FRONTENDS[case['catalog_id']](case['source'])
        else:
            ir, program = FRONTENDS[case['catalog_id']](case['source'])
            observed = Interpreter(timeout=5, max_ops=2_000_000).run(program).variables['result']
            self.assertEqual(observed, case['expected'])
            self.assertIsInstance(ir, dict)
    return test


for case in cases():
    name = 'test_' + case['catalog_id'] + '_' + case['name'].replace('-', '_')
    setattr(IntentTests, name, make_intent_test(case))


class BoundTests(unittest.TestCase):
    def test_every_frontend_rejects_source_limits_and_nul(self):
        for identifier, frontend in FRONTENDS.items():
            for source in ['a' * 65537, '#\n' * 257, '\x00']:
                with self.subTest(identifier=identifier, source_kind=len(source)):
                    with self.assertRaises(Unsupported):
                        frontend(source)

    def test_make_simple_append_cannot_expand_exponentially_without_limit(self):
        with self.assertRaisesRegex(Unsupported, 'Generated assignment limit'):
            FRONTENDS['basemake']('RESULT := start\n' + 'RESULT += x\n' * 20)


class CompatibilityTests(unittest.TestCase):
    def test_private_compatibility_library_identities_are_recorded(self):
        import run
        with tempfile.TemporaryDirectory() as directory:
            private=Path(directory)/'libicuuc.so.76';private.write_bytes(b'identity-test')
            selected=run.tool_paths('resourcebundle',directory)
            self.assertIn(private,selected)
            self.assertIn(Path('/usr/lib/x86_64-linux-gnu/libicudata.so.76'),selected)
            self.assertEqual(run.tool_paths('basemake',directory),[Path('/usr/bin/make')])

    def test_profile_records_actual_ubuntu_library_versions(self):
        import run
        observed={'ncurses':'6.6.20251231','glibc':'2.43'}
        self.assertIn('ncurses6.6.20251231',run.profile_text('termcap',observed))
        self.assertIn('glibc2.43',run.profile_text('unixconfig',observed))
        self.assertNotIn('ncurses6.5',run.profile_text('termcap',observed))

    def test_native_children_receive_private_and_inherited_library_paths(self):
        import native
        observed=[]
        def command(arguments,cwd,env,timeout=10):
            observed.append(env['LD_LIBRARY_PATH'])
            return subprocess.CompletedProcess(arguments,0,b'value',b''),{'returncode':0}
        with patch.dict(os.environ,{'USL_COMPAT_LIBDIR':'/tmp/private-icu','LD_LIBRARY_PATH':'/tmp/inherited-libs'}), patch.object(native,'execute',side_effect=command):
            result=native.process('basemake','RESULT = value\n')
        self.assertTrue(result['accepted'])
        self.assertIn('/tmp/private-icu',observed[0].split(os.pathsep))
        self.assertIn('/tmp/inherited-libs',observed[0].split(os.pathsep))


class SchemaTests(unittest.TestCase):
    def test_all_eight_profiles_have_fresh_native_and_usl_evidence(self):
        result = json.loads((ROOT / 'results/results.json').read_text())
        self.assertTrue(result['all_cases_passed'])
        self.assertEqual(set(result['validated_ids']), set(FRONTENDS))
        self.assertEqual(result['case_count'], len(cases()))
        self.assertEqual(len(result['records']), 8)
        for record in result['records']:
            self.assertIs(record['scoped_profile_validated'], True)
            self.assertIs(record['full_standard_qualified'], False)
            self.assertIsInstance(record['exact_profile'], str)
            self.assertTrue(record['exact_profile'])
            for key in ['cases', 'native_executions', 'usl_executions']:
                self.assertIs(type(record[key]), int)
                self.assertGreater(record[key], 0)
            self.assertEqual(record['cases'], len(record['case_records']))
            self.assertIsInstance(record['open_obligations'], list)
            self.assertTrue(record['open_obligations'])
            for row in record['case_records']:
                self.assertTrue(row['passed'])
                self.assertEqual(row['source_sha256'], hashlib.sha256(row['source'].encode()).hexdigest())
                if row['native_executions']:
                    self.assertEqual(row['native_executions'], len(row['native']['receipts']))
                    self.assertTrue(row['native']['fixture_effects_isolated'])
            for filename, checksum in record['source_hashes'].items():
                self.assertEqual(hashlib.sha256((ROOT / filename).read_bytes()).hexdigest(), checksum)
        self.assertTrue(result['resource_admission']['all_actors_started_before_release'])
        self.assertLessEqual(result['resource_admission']['actual_peak_native_jobs'], result['resource_admission']['native_slots'])

    def test_unixconfig_covers_real_passwd_and_group_fixtures(self):
        row = next(r for r in json.loads((ROOT / 'results/results.json').read_text())['records'] if r['catalog_id'] == 'unixconfig')
        formats = {c['ir']['format'] for c in row['case_records'] if 'ir' in c}
        self.assertEqual(formats, {'glibc-passwd', 'glibc-group'})
        self.assertIn('fgetpwent/fgetgrent', row['exact_profile'])
        self.assertTrue(any(c['name'] == 'group-ordered-duplicates' and c['native_executions'] for c in row['case_records']))


class RestoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='usl-config-test-')
        self.root = Path(self.temporary.name)
        for filename in ['PROVIDERS.json', 'DEBIAN_INRELEASE.asc', 'DEBIAN_RELEASE.txt']:
            shutil.copyfile(ROOT / filename, self.root / filename)

    def tearDown(self):
        self.temporary.cleanup()

    def test_existing_cleartext_never_skips_signature_verification(self):
        run = subprocess.run
        before = {p.name: p.read_bytes() for p in self.root.iterdir()}
        with patch.object(restore.subprocess, 'run', wraps=run) as verifier:
            restore.authenticate(self.root)
            restore.authenticate(self.root)
        self.assertEqual(verifier.call_count, 2)
        for call in verifier.call_args_list:
            self.assertEqual(call.args[0][0], 'sqv')
            self.assertIn('--keyring', call.args[0])
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.root.iterdir()})

    def test_bad_signature_is_rejected_even_if_signed_file_hash_is_replaced(self):
        signed = self.root / 'DEBIAN_INRELEASE.asc'
        signed.write_bytes(signed.read_bytes().replace(b'Origin: Debian', b'Origin: Evilxx', 1))
        manifest = json.loads((self.root / 'PROVIDERS.json').read_text())
        manifest['signed_release_sha256'] = restore.sha(signed.read_bytes())
        (self.root / 'PROVIDERS.json').write_text(json.dumps(manifest))
        with self.assertRaises(subprocess.CalledProcessError):
            restore.authenticate(self.root)

    def test_untrusted_cleartext_cannot_replace_signed_release(self):
        (self.root / 'DEBIAN_RELEASE.txt').write_text('Origin: malicious\n')
        with self.assertRaisesRegex(ValueError, 'provenance mismatch'):
            restore.authenticate(self.root)

    def test_corrupt_index_is_rejected(self):
        index = self.root / 'Packages'
        index.write_text('Package: fake\n')
        with self.assertRaisesRegex(ValueError, 'package index integrity failure'):
            restore.authenticate(self.root, index=index)

    def test_provider_version_cannot_drift(self):
        path = self.root / 'PROVIDERS.json'
        manifest = json.loads(path.read_text())
        manifest['packages'][0]['Version'] += '-changed'
        path.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(ValueError, 'Exact Debian provider pin mismatch'):
            restore.authenticate(self.root)

    def test_bad_package_hash_prevents_extraction(self):
        run = subprocess.run
        with patch.object(restore, 'fetch', return_value=b'tampered package'), patch.object(restore.subprocess, 'run', wraps=run) as commands:
            with self.assertRaisesRegex(ValueError, 'Debian provider .* integrity failure'):
                restore.restore(self.root)
        self.assertTrue(commands.call_args_list)
        self.assertTrue(all(call.args[0][0] == 'sqv' for call in commands.call_args_list))


if __name__ == '__main__':
    unittest.main()
