"""Fresh native processing carriers; all writable effects stay in fixture dirs."""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parent
PREFIX=ROOT/'providers'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def execute(command,cwd,env=None,timeout=10):
    start=time.monotonic()
    p=subprocess.run([str(x) for x in command],cwd=cwd,env=env,capture_output=True,timeout=timeout)
    return p,{'command':[str(x) for x in command],'returncode':p.returncode,
              'stdout':p.stdout.decode('utf-8','replace'),'stderr':p.stderr.decode('utf-8','replace'),
              'wall_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),
              'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}


def child(kind,directory):
    directory=Path(directory)
    if kind=='terminal':
        import curses
        curses.use_env(False)
        curses.setupterm('usltest',fd=1)
        return [['am',bool(curses.tigetflag('am'))],['cols',curses.tigetnum('cols')],
                ['lines',curses.tigetnum('lines')],
                ['clear',None if curses.tigetstr('clear') is None else list(curses.tigetstr('clear'))],
                ['cup',None if curses.tigetstr('cup') is None else list(curses.tigetstr('cup'))]]
    if kind=='resource':
        lib=ctypes.CDLL('libicuuc.so.76')
        def fn(name,restype,args):
            f=getattr(lib,name+'_76');f.restype=restype;f.argtypes=args;return f
        ptr=ctypes.c_void_p;ip=ctypes.POINTER(ctypes.c_int32)
        op=fn('ures_openDirect',ptr,[ctypes.c_char_p,ctypes.c_char_p,ip])
        size=fn('ures_getSize',ctypes.c_int32,[ptr]);get=fn('ures_getByIndex',ptr,[ptr,ctypes.c_int32,ptr,ip])
        key=fn('ures_getKey',ctypes.c_char_p,[ptr]);typ=fn('ures_getType',ctypes.c_int,[ptr])
        string=fn('ures_getString',ctypes.POINTER(ctypes.c_uint16),[ptr,ip,ip])
        integer=fn('ures_getInt',ctypes.c_int32,[ptr,ip]);close=fn('ures_close',None,[ptr])
        status=ctypes.c_int32(0);bundle=op(str(directory).encode(),b'bundle',ctypes.byref(status))
        if status.value>0 or not bundle:raise RuntimeError('ICU open status '+str(status.value))
        result=[]
        try:
            for i in range(size(bundle)):
                resource=get(bundle,i,None,ctypes.byref(status))
                try:
                    name=key(resource).decode('ascii');kind=typ(resource)
                    if kind==0:
                        length=ctypes.c_int32();p=string(resource,ctypes.byref(length),ctypes.byref(status))
                        value=ctypes.string_at(p,length.value*2).decode('utf-16-le');tag='string'
                    elif kind==7:value=integer(resource,ctypes.byref(status));tag='int'
                    else:raise RuntimeError('Unexpected ICU resource type '+str(kind))
                    if status.value>0:raise RuntimeError('ICU resource status '+str(status.value))
                    result.append([name,tag,value])
                finally:close(resource)
        finally:close(bundle)
        return sorted(result)
    if kind in {'passwd','group'}:
        class Passwd(ctypes.Structure):
            _fields_=[('name',ctypes.c_char_p),('password',ctypes.c_char_p),('uid',ctypes.c_uint),
                      ('gid',ctypes.c_uint),('gecos',ctypes.c_char_p),('directory',ctypes.c_char_p),('shell',ctypes.c_char_p)]
        class Group(ctypes.Structure):
            _fields_=[('name',ctypes.c_char_p),('password',ctypes.c_char_p),('gid',ctypes.c_uint),
                      ('members',ctypes.POINTER(ctypes.c_char_p))]
        lib=ctypes.CDLL(None);lib.fopen.restype=ctypes.c_void_p;lib.fopen.argtypes=[ctypes.c_char_p,ctypes.c_char_p]
        lib.fgetpwent.restype=ctypes.POINTER(Passwd);lib.fgetpwent.argtypes=[ctypes.c_void_p]
        lib.fgetgrent.restype=ctypes.POINTER(Group);lib.fgetgrent.argtypes=[ctypes.c_void_p]
        lib.fclose.argtypes=[ctypes.c_void_p]
        f=lib.fopen(str(directory/'input').encode(),b'r')
        if not f:raise RuntimeError('Fixture could not open')
        out=[]
        try:
            while True:
                p=lib.fgetgrent(f) if kind=='group' else lib.fgetpwent(f)
                if not p:break
                v=p.contents
                text=lambda x: x.decode('utf-8') if x else ''
                if kind=='group':
                    members=[];i=0
                    while v.members[i]:members.append(text(v.members[i]));i+=1
                    out.append([text(v.name),text(v.password),v.gid,members])
                else:out.append([text(v.name),text(v.password),v.uid,v.gid,text(v.gecos),text(v.directory),text(v.shell)])
        finally:lib.fclose(f)
        return out
    if kind=='ldap':
        lib=ctypes.CDLL('libldap.so.2');lib.ldap_get_option.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p]
        p=ctypes.c_char_p();r=lib.ldap_get_option(None,0x5009,ctypes.byref(p))
        if r:raise RuntimeError('LDAP BASE get_option failed')
        out=[['BASE',p.value.decode() if p.value else '']]
        for name,key in [('DEREF',2),('SIZELIMIT',3),('TIMELIMIT',4)]:
            v=ctypes.c_int();r=lib.ldap_get_option(None,key,ctypes.byref(v))
            if r:raise RuntimeError('LDAP get_option failed')
            out.append([name,v.value])
        return out
    raise ValueError('Unknown native child')


def process(kind,source):
    receipts=[]
    with tempfile.TemporaryDirectory(prefix='usl-config-') as directory:
        d=Path(directory);(d/'input').write_text(source)
        env=os.environ.copy();env['LC_ALL']='C'
        library_paths=[str(PREFIX/'usr/lib/x86_64-linux-gnu')]
        if env.get('USL_COMPAT_LIBDIR'):library_paths.append(env['USL_COMPAT_LIBDIR'])
        if env.get('LD_LIBRARY_PATH'):library_paths.append(env['LD_LIBRARY_PATH'])
        env['LD_LIBRARY_PATH']=os.pathsep.join(library_paths)
        def run(args):
            p,r=execute(args,d,env);receipts.append(r);return p
        if kind=='basemake':
            env['MAKEFLAGS']='';env['MFLAGS']=''
            (d/'Makefile').write_text(source+'\n.PHONY: all\nall:\n\t@printf \'%s\' \'$(RESULT)\'\n')
            p=run(['/usr/bin/make','--no-print-directory','-rR','-f','Makefile','all'])
            result=p.stdout.decode() if p.returncode==0 else None
        elif kind in {'termcap','terminfo'}:
            db=d/'db';db.mkdir();env['TERMINFO']=str(db);env['TERMINFO_DIRS']=str(db)
            p=run(['/usr/bin/tic','-x','-o',str(db),'input'])
            if p.returncode==0:
                p=run([sys.executable,str(ROOT/'native.py'),'terminal',str(d)])
                result=json.loads(p.stdout) if p.returncode==0 else None
            else:result=None
        elif kind=='resourcebundle':
            (d/'bundle.txt').write_text(source)
            p=run([PREFIX/'usr/bin/genrb','--strict','--encoding','UTF-8','--destdir',d,d/'bundle.txt'])
            if p.returncode==0:
                p=run([sys.executable,ROOT/'native.py','resource',d]);result=json.loads(p.stdout) if p.returncode==0 else None
            else:result=None
        elif kind=='unixconfig':
            # Fixture routing only; libc performs every record parse independently.
            group=any(len(line.split(':'))==4 for line in source.splitlines() if line and not line.startswith('#'))
            p=run([sys.executable,ROOT/'native.py','group' if group else 'passwd',d]);result=json.loads(p.stdout) if p.returncode==0 else None
        elif kind=='ldapconf':
            for key in list(env):
                if key.startswith('LDAP'):del env[key]
            env['LDAPCONF']=str(d/'input');env['LDAPRC']=str(d/'nonexistent-ldaprc')
            p=run([sys.executable,ROOT/'native.py','ldap',d]);result=json.loads(p.stdout) if p.returncode==0 else None
        elif kind=='kconfig':
            env['KCONFIG_CONFIG']=str(d/'.config');env['KCONFIG_OVERWRITECONFIG']='1'
            p=run([PREFIX/'usr/bin/kconfig-conf','--alldefconfig','input'])
            if p.returncode==0:
                data=(d/'.config').read_text();values={}
                for line in data.splitlines():
                    m=re.fullmatch(r'CONFIG_([A-Z][A-Z0-9_]*)=(.*)',line)
                    if m:values[m.group(1)]=m.group(2)
                result=[]
                blocks=re.split(r'(?m)^config ',source)[1:]
                for block in blocks:
                    name=block.splitlines()[0];m=re.search(r'(?m)^\s*(bool|int|string)(?: |$)',block)
                    if not m:raise RuntimeError('Unexpected Kconfig type')
                    k=m.group(1);v=values.get(name,'n' if k=='bool' else ('0' if k=='int' else '""'))
                    result.append([name,k,v=='y' if k=='bool' else (int(v) if k=='int' else json.loads(v))])
            else:result=None
        elif kind=='devicetree':
            p=run([PREFIX/'usr/bin/dtc','-I','dts','-O','dtb','-o',d/'tree.dtb',d/'input'])
            result=[] if p.returncode==0 else None
            if result is not None:
                paths=['/']
                for path in paths:
                    q=run([PREFIX/'usr/bin/fdtget','-l',d/'tree.dtb',path])
                    if q.returncode:raise RuntimeError('fdtget child enumeration failed')
                    paths.extend(path.rstrip('/')+'/'+name for name in q.stdout.decode().split())
                    q=run([PREFIX/'usr/bin/fdtget','-p',d/'tree.dtb',path])
                    if q.returncode:raise RuntimeError('fdtget property enumeration failed')
                    for key in q.stdout.decode().split():
                        q=run([PREFIX/'usr/bin/fdtget','-t','bx',d/'tree.dtb',path,key])
                        if q.returncode:raise RuntimeError('fdtget byte read failed')
                        result.append([path,key,[int(b,16) for b in q.stdout.decode().split()]])
                result.sort(key=lambda row:(row[0],row[1]))
        else:raise ValueError('Unknown native processor '+kind)
        return {'accepted':result is not None,'result':result,'receipts':receipts,
                'native_executions':len(receipts),'fixture_effects_isolated':True}


if __name__=='__main__':
    print(json.dumps(child(sys.argv[1],sys.argv[2]),ensure_ascii=True))
