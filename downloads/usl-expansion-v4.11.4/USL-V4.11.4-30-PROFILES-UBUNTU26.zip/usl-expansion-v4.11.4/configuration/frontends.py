"""Fail-closed, bounded configuration frontends and executable USL lowering."""
import json
import re


class Unsupported(ValueError): pass


def bounded(source):
    if not isinstance(source, str) or len(source.encode('utf-8')) > 65536:
        raise Unsupported('Source limit:65536 UTF-8 bytes')
    if '\x00' in source or len(source.splitlines()) > 256:
        raise Unsupported('NUL or more than256 source lines')


def literal_program(value):
    return '// Category data materialization, not source-program execution.\nlet result = ' + repr(value) + '\n'


def make_program(source):
    bounded(source)
    definitions = {}; expansion_work = 0
    def expression(text, stack=()):
        nonlocal expansion_work
        expansion_work += 1
        if expansion_work > 4096:raise Unsupported('Make lowering expansion-work limit4096')
        if len(stack) > 32: raise Unsupported('Make expansion depth32')
        pieces = []; position = 0
        for match in re.finditer(r'\$\(([A-Z][A-Z0-9_]*)\)', text):
            pieces.append(repr(text[position:match.start()]))
            name = match.group(1)
            if name in stack: raise Unsupported('Recursive make variable')
            flavor, body = definitions.get(name, ('simple', repr('')))
            pieces.append(body if flavor == 'simple' else expression(body, stack + (name,)))
            position = match.end()
        pieces.append(repr(text[position:]))
        code='(' + ' + '.join(pieces) + ')'
        if len(code)>262144:raise Unsupported('Generated expression limit262144')
        return code
    for line in source.splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        match = re.fullmatch(r'([A-Z][A-Z0-9_]*)[ \t]*(\?=|:=|\+=|=)[ \t]*(.*)', line)
        if not match: raise Unsupported('Only bounded variable assignments are supported')
        name, operation, body = match.groups()
        stripped = re.sub(r'\$\([A-Z][A-Z0-9_]*\)', '', body)
        if not re.fullmatch(r'[A-Za-z0-9_ .:/+\-]*', stripped):
            raise Unsupported('Make functions, commands, escapes and metacharacters are outside this profile')
        if operation == '?=' and name in definitions: continue
        if operation == ':=': definitions[name] = ('simple', expression(body))
        elif operation == '+=' and name in definitions:
            flavor, old = definitions[name]
            definitions[name] = (flavor, '(' + old + ' + (' + repr(' ') + ' if '+old+' != '+repr('')+' else '+repr('')+') + ' + expression(body) + ')' if flavor == 'simple' else old + (' ' if old else '') + body)
        else: definitions[name] = ('recursive', body)
        if len(definitions[name][1])>262144:raise Unsupported('Generated assignment limit262144')
    return {'definitions': len(definitions)}, 'let result = ' + expression('$(RESULT)') + '\n'


CAPS = ['am', 'cols', 'lines', 'clear', 'cup']
SHORT = {'am':'am', 'co':'cols', 'li':'lines', 'cl':'clear', 'cm':'cup'}


def cap_bytes(text,termcap=False):
    out = []; i = 0
    while i < len(text):
        c = text[i]; i += 1
        if c == '^':
            if i == len(text): raise Unsupported('Incomplete control escape')
            c = text[i]; i += 1; out.append(127 if c == '?' and not termcap else ord(c) & 31)
        elif c == '\\':
            if i == len(text): raise Unsupported('Incomplete capability escape')
            c = text[i]; i += 1
            if c in '01234567':
                digits = c
                while i < len(text) and len(digits) < 3 and text[i] in '01234567': digits += text[i]; i += 1
                value = int(digits,8)
                if not 1 <= value <= 255: raise Unsupported('NUL/out-of-byte-range escape excluded')
                out.append(value)
            else:
                escapes = {'E':27,'e':27,'n':10,'r':13,'t':9,'b':8,'f':12,'s':32,'\\':92,',':44,':':58,'^':94}
                if c not in escapes: raise Unsupported('Unknown capability escape')
                out.append(escapes[c])
        else:
            if not 32 <= ord(c) <= 126: raise Unsupported('Capability strings use printable ASCII/escapes')
            out.append(ord(c))
    return out


def terminal_program(source, termcap=False):
    bounded(source)
    delimiter = ':' if termcap else ','
    flat = source.replace('\\\n', '').replace('\n','').replace('\t','')
    fields = re.split(r'(?<!\\)' + re.escape(delimiter), flat)
    if not fields or not fields[-1].strip() == '': raise Unsupported('Entry requires final separator')
    if not re.fullmatch(r'usltest(?:\|[A-Za-z0-9 _-]+)*', fields[0].strip()):
        raise Unsupported('Only a single isolated usltest entry is supported')
    rows = []
    for field in fields[1:-1]:
        field = field.strip()
        if not field: continue
        match = re.fullmatch(r'([a-z]+)([@#=]?)(.*)',field)
        if not match: raise Unsupported('Invalid capability')
        name, op, value = match.groups(); name = SHORT.get(name, name) if termcap else name
        if name not in CAPS: raise Unsupported('Capability outside selected profile')
        if any(row[0] == name for row in rows): raise Unsupported('Repeated capabilities excluded')
        if op == '@' and not value: v = False if name == 'am' else (-1 if name in {'cols','lines'} else None)
        elif name == 'am' and not op and not value: v = True
        elif name in {'cols','lines'} and op == '#' and re.fullmatch(r'[0-9]+',value) and int(value) <= 32767: v=int(value)
        elif name in {'clear','cup'} and op == '=': v=cap_bytes(value,termcap)
        else: raise Unsupported('Capability type or numeric bound mismatch')
        rows.append([name,v])
    code = 'let rows = ' + repr(rows) + '\nlet result = []\n'
    for name in CAPS:
        default = False if name == 'am' else (-1 if name in {'cols','lines'} else None)
        code += 'let value = ' + repr(default) + '\nfor row in rows:\n    if row[0] == ' + repr(name) + ':\n        value = row[1]\nresult = result + [[ ' + repr(name) + ', value ]]\n'
    return {'capability_rows': rows, 'entry':'usltest'}, code


def resource_program(source):
    bounded(source)
    match = re.fullmatch(r'\s*bundle\s*\{(.*)\}\s*',source,re.S)
    if not match: raise Unsupported('Root bundle table required')
    body=match.group(1); pos=0; rows=[]
    pattern=re.compile(r'\s*([A-Za-z][A-Za-z0-9_]*)(:int)?\s*\{\s*("(?:[^"\\]|\\.)*"|-?[0-9]+)\s*\}',re.S)
    while pos < len(body):
        if not body[pos:].strip(): break
        match=pattern.match(body,pos)
        if not match: raise Unsupported('Only flat ICU strings and signed28-bit ints supported')
        key, integer, value=match.groups();pos=match.end()
        if any(row[0]==key for row in rows): raise Unsupported('Duplicate ICU key')
        if integer:
            if value.startswith('"') or not -(1<<27)<=int(value)<(1<<27): raise Unsupported('ICU signed28-bit integer')
            decoded=int(value)
        else:
            if not value.startswith('"'): raise Unsupported('String resource requires quoted text')
            decoded=json.loads(value)
            if any(0xD800<=ord(c)<=0xDFFF for c in decoded): raise Unsupported('Unpaired surrogate excluded')
        rows.append([key,'int' if integer else 'string',decoded])
    rows.sort(key=lambda row:row[0])
    return {'resources':rows}, literal_program(rows)


def unix_program(source):
    """Read one passwd or group fixture, selected by its structural row width."""
    bounded(source)
    lines=[line for line in source.splitlines() if line and not line.startswith('#')]
    widths={len(line.split(':')) for line in lines}
    if 4 in widths and 7 in widths:raise Unsupported('Mixed passwd/group fixtures excluded')
    group=4 in widths
    rows=[]
    for line in lines:
        p=line.split(':')
        if line.startswith(('+','-')):raise Unsupported('NIS compatibility records excluded')
        width=4 if group else 7
        if len(p)>width:raise Unsupported('Colon-containing fields excluded')
        numeric=[2] if group else [2,3]
        if len(p)!=width or any(not re.fullmatch(r'[0-9]+',p[i]) for i in numeric):continue
        if not p[0] or any(not 0<=int(p[i])<2**32-1 for i in numeric):raise Unsupported('Name/uid/gid outside qualified range')
        if group:
            if p[3] and not re.fullmatch(r'[A-Za-z0-9_.-]+(?:,[A-Za-z0-9_.-]+)*',p[3]):
                raise Unsupported('Group members require nonempty literal names')
            rows.append([p[0],p[1],int(p[2]),p[3].split(',') if p[3] else []])
        else:rows.append([p[0],p[1],int(p[2]),int(p[3]),p[4],p[5],p[6]])
    # USL materializes typed numeric fields and retains source/member order.
    code='let entries = '+repr(rows)+'\nlet result = []\nfor entry in entries:\n'
    code+='    result = result + [[entry[0],entry[1],int(entry[2]),entry[3]]]\n' if group else '    result = result + [[entry[0],entry[1],int(entry[2]),int(entry[3]),entry[4],entry[5],entry[6]]]\n'
    return {'format':'glibc-group' if group else 'glibc-passwd','records':len(rows)},code


def ldap_program(source):
    bounded(source); values={'BASE':'','SIZELIMIT':0,'TIMELIMIT':0,'DEREF':0}; rows=[]
    for line in source.splitlines():
        line=line.strip()
        if not line or line.startswith('#'): continue
        parts=line.split(None,1)
        if len(parts)!=2: raise Unsupported('LDAP directive requires an argument')
        key,value=parts;key=key.upper()
        if key not in values: raise Unsupported('LDAP directive outside selected profile')
        if key in {'SIZELIMIT','TIMELIMIT'}:
            if not re.fullmatch(r'[0-9]+',value) or int(value)>2147483647: raise Unsupported('LDAP nonnegative signed32 limit')
            value=int(value)
        elif key=='DEREF':
            options={'never':0,'searching':1,'finding':2,'always':3}
            if value.lower() not in options: raise Unsupported('Invalid LDAP DEREF')
            value=options[value.lower()]
        elif not re.fullmatch(r'[A-Za-z0-9 ,=._-]*',value):raise Unsupported('LDAP BASE literal profile')
        rows.append([key,value])
    code='let rows = '+repr(rows)+'\nlet result = []\n'
    for key in sorted(values):
        code+='let value = '+repr(values[key])+'\nfor row in rows:\n    if row[0] == '+repr(key)+':\n        value = row[1]\nresult = result + [['+repr(key)+', value]]\n'
    return {'directives':rows},code


def kconfig_program(source):
    bounded(source);configs=[];current=None
    for line in source.splitlines():
        line=line.strip()
        if not line or line.startswith('#'):continue
        match=re.fullmatch(r'config ([A-Z][A-Z0-9_]*)',line)
        if match:
            if any(row['name']==match.group(1) for row in configs):raise Unsupported('Repeated Kconfig symbol')
            current={'name':match.group(1),'type':None,'defaults':[],'depends':None};configs.append(current);continue
        if current is None:raise Unsupported('Expected config symbol')
        match=re.fullmatch(r'(bool|int|string)(?: "[A-Za-z0-9 _-]*")?',line)
        if match:
            if current['type']:raise Unsupported('Repeated type')
            current['type']=match.group(1);continue
        match=re.fullmatch(r'depends on ([A-Z][A-Z0-9_]*)',line)
        if match:
            if current['depends']:raise Unsupported('One dependency in this profile')
            current['depends']=match.group(1);continue
        match=re.fullmatch(r'default (y|n|-?[0-9]+|"[A-Za-z0-9 _-]*")(?: if ([A-Z][A-Z0-9_]*))?',line)
        if match:current['defaults'].append(list(match.groups()));continue
        raise Unsupported('Unsupported Kconfig construct')
    seen={};code='let result = []\n'
    for row in configs:
        name,kind=row['name'],row['type']
        if not kind:raise Unsupported('Missing Kconfig type')
        dep=row['depends']
        if dep and seen.get(dep)!='bool':raise Unsupported('Dependencies must refer to earlier bool symbols')
        default=False if kind=='bool' else (0 if kind=='int' else '')
        code+='let cfg'+name+' = '+repr(default)+'\nlet chosen = False\n'
        for value,condition in row['defaults']:
            if condition and seen.get(condition)!='bool':raise Unsupported('Default condition must refer to earlier bool')
            if kind=='bool':
                if value not in {'y','n'}:raise Unsupported('Boolean default')
                decoded=value=='y'
            elif kind=='int':
                if not re.fullmatch(r'-?[0-9]+',value) or not -(2**31)<=int(value)<2**31:raise Unsupported('Signed32 default')
                decoded=int(value)
            else:
                if not value.startswith('"'):raise Unsupported('String default')
                decoded=json.loads(value)
            condition_code='True' if condition is None else 'cfg'+condition
            code+='if not chosen and '+condition_code+':\n    cfg'+name+' = '+repr(decoded)+'\n    chosen = True\n'
        if dep:code+='if not cfg'+dep+':\n    cfg'+name+' = '+repr(default)+'\n'
        code+='result = result + [['+repr(name)+','+repr(kind)+',cfg'+name+']]\n';seen[name]=kind
    return {'symbols':configs},code


def dt_program(source):
    bounded(source)
    pattern=re.compile(r'\s*(/dts-v1/|"(?:[^"\\]|\\.)*"|[A-Za-z_#][A-Za-z0-9_,@#.+-]*|0x[0-9a-fA-F]+|[0-9]+|[/{};=<>\[\],])')
    tokens=[];pos=0
    while pos<len(source):
        if not source[pos:].strip():break
        match=pattern.match(source,pos)
        if not match:raise Unsupported('Device-tree token outside selected profile')
        tokens.append(match.group(1));pos=match.end()
    at=0;rows=[]
    def take(wanted=None):
        nonlocal at
        if at==len(tokens):raise Unsupported('Truncated device tree')
        out=tokens[at];at+=1
        if wanted is not None and out!=wanted:raise Unsupported('Expected '+wanted)
        return out
    def node(path,depth=0):
        nonlocal at
        if depth>12:raise Unsupported('Device-tree node depth12')
        take('{');seen=set()
        while at<len(tokens) and tokens[at]!='}':
            key=take()
            if not re.fullmatch(r'[A-Za-z_#][A-Za-z0-9_,@#.+-]*',key) or key in seen:raise Unsupported('Invalid/duplicate node property')
            seen.add(key)
            if at<len(tokens) and tokens[at]=='{':node(path.rstrip('/')+'/'+key,depth+1);continue
            if at<len(tokens) and tokens[at]==';':take(';');rows.append([path,key,'bytes',[]]);continue
            take('=');lead=take();values=[]
            if lead=='<':
                kind='cells'
                while at<len(tokens) and tokens[at]!='>':
                    token=take()
                    try:value=int(token,0) if token.startswith('0x') else int(token,10)
                    except ValueError:raise Unsupported('Device-tree cell integer')
                    if not 0<=value<2**32:raise Unsupported('Unsigned32 cell')
                    values.append(value)
                take('>')
            elif lead.startswith('"'):
                kind='string';strings=[json.loads(lead)]
                while at<len(tokens) and tokens[at]==',':take(',');strings.append(json.loads(take()))
                if any(not s.isascii() or '\x00' in s for s in strings):raise Unsupported('ASCII non-NUL string profile')
                values=[list(s.encode())+[0] for s in strings]
            else:raise Unsupported('Only cells, strings and flag properties are supported')
            take(';');rows.append([path,key,kind,values])
        take('}');take(';')
    take('/dts-v1/');take(';');take('/');node('/')
    if at!=len(tokens):raise Unsupported('Trailing device-tree content')
    code='let rows = '+repr(rows)+'\nlet result = []\nfor row in rows:\n    let data = []\n    if row[2] == "cells":\n        for value in row[3]:\n            data = data + [value // 16777216 % 256, value // 65536 % 256, value // 256 % 256, value % 256]\n    elif row[2] == "string":\n        for stringbytes in row[3]:\n            data = data + stringbytes\n    result = result + [[row[0],row[1],data]]\n'
    return {'properties':rows},code+'result = sorted(result)\n'


FRONTENDS={'basemake':make_program,'terminfo':terminal_program,
           'termcap':lambda s:terminal_program(s,True),'resourcebundle':resource_program,
           'unixconfig':unix_program,'ldapconf':ldap_program,'kconfig':kconfig_program,'devicetree':dt_program}
