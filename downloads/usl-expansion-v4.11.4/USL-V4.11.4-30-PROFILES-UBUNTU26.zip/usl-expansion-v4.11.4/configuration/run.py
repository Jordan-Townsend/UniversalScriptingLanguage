"""Validate all ready configuration cases concurrently with resource admission."""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import time

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':')).encode()).hexdigest()


def admission(count):
    cpus=os.cpu_count() or 1;quota=None
    try:
        q,p=Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if q!='max':quota=float(q)/float(p);cpus=min(cpus,max(1,math.ceil(quota)))
    except (OSError,ValueError):pass
    available=None
    try:
        memory={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines()}
        available=memory['MemAvailable']
        current=int(Path('/sys/fs/cgroup/memory.current').read_text());maximum=Path('/sys/fs/cgroup/memory.max').read_text().strip()
        if maximum!='max':available=min(available,max(0,int(maximum)-current))
    except (OSError,ValueError):pass
    reserve=512*1024**2;job_estimate=64*1024**2
    memory_lanes=count if available is None else max(1,(available-reserve)//job_estimate)
    lanes=max(1,min(count,cpus,memory_lanes))
    return {'logical_case_actors':count,'native_slots':lanes,'cpu_count_observed':os.cpu_count(),
            'cgroup_cpu_equivalents':quota,'memory_available_observed':available,
            'memory_reserve_bytes':reserve,'per_job_memory_estimate_bytes':job_estimate,
            'policy':'All case actors start together; native jobs admitted by measured CPU quota and current memory headroom; no fixed worker cap'}


PROFILES={
 'basemake':'GNU make4.4.1 variable =/:=/+=/?=, late/immediate expansion, undefined variables and assignment order; command/functions/rules excluded except isolated observation harness',
 'termcap':'ncurses6.5.20250216 tic termcap input: single entry, am/co/li/cl/cm, selected byte/control escapes, explicit cancellation; no inheritance/parameter execution',
 'terminfo':'ncurses6.5.20250216 single terminfo entry am/cols/lines/clear/cup, selected byte/control escapes and explicit cancellation; use_env(False), no inheritance/parameter execution',
 'resourcebundle':'ICU76.1 genrb strict flat bundle table of Unicode strings and signed28-bit int resources, native ures lookup; no aliases/arrays/nesting/fallback',
 'unixconfig':'Exact catalog UnixConfigLexer /etc/passwd and /etc/group identity; glibc2.41 fgetpwent/fgetgrent on isolated seven-field passwd or four-field group fixtures, ordered duplicates/members, malformed-row skipping; no mixed formats/shadow/NIS/NSS',
 'ldapconf':'OpenLDAP2.6.10 isolated ldap.conf BASE/DEREF/SIZELIMIT/TIMELIMIT parsing and last-value defaults through ldap_get_option; no network/TLS/authentication processing',
 'kconfig':'kconfig-frontends4.11.0.1 config bool/int/string, ordered defaults, earlier-bool default conditions/dependencies, alldefconfig; no choices/tristate/select/range/source/forward cycles',
 'devicetree':'DTC1.7.2 dts-v1 root/child nodes with flag, ASCII string-list and unsigned32-cell properties; DTB byte comparison; no labels/phandles/includes/overlays/device execution',
}
TOOLS={
 'basemake':['/usr/bin/make'],
 'termcap':['/usr/bin/tic','/usr/lib/x86_64-linux-gnu/libtinfo.so.6'],
 'terminfo':['/usr/bin/tic','/usr/lib/x86_64-linux-gnu/libtinfo.so.6'],
 'resourcebundle':[str(ROOT/'providers/usr/bin/genrb'),'/usr/lib/x86_64-linux-gnu/libicuuc.so.76','/usr/lib/x86_64-linux-gnu/libicudata.so.76'],
 'unixconfig':['/usr/lib/x86_64-linux-gnu/libc.so.6'],
 'ldapconf':['/usr/lib/x86_64-linux-gnu/libldap.so.2'],
 'kconfig':[str(ROOT/'providers/usr/bin/kconfig-conf'),str(ROOT/'providers/usr/lib/x86_64-linux-gnu/libkconfig-parser-4.11.0.so')],
 'devicetree':[str(ROOT/'providers/usr/bin/dtc'),str(ROOT/'providers/usr/bin/fdtget'),str(ROOT/'providers/usr/lib/x86_64-linux-gnu/libfdt.so.1')],
}


def tool_paths(identifier, compat_dir=None):
    """Bind observed identities to the same optional private library directory."""
    compat_dir=compat_dir if compat_dir is not None else os.environ.get('USL_COMPAT_LIBDIR')
    paths=[]
    for original in TOOLS[identifier]:
        candidate=Path(compat_dir)/Path(original).name if compat_dir and '.so' in Path(original).name else None
        paths.append(candidate if candidate is not None and candidate.is_file() else Path(original))
    return paths


def native_versions():
    tinfo=ctypes.CDLL(str(tool_paths('termcap')[1]));tinfo.curses_version.restype=ctypes.c_char_p
    libc=ctypes.CDLL(str(tool_paths('unixconfig')[0]));libc.gnu_get_libc_version.restype=ctypes.c_char_p
    return {'ncurses':tinfo.curses_version().decode('ascii').removeprefix('ncurses '),
            'glibc':libc.gnu_get_libc_version().decode('ascii')}


def profile_text(identifier,versions):
    return PROFILES[identifier].replace('ncurses6.5.20250216','ncurses'+versions['ncurses']).replace('glibc2.41','glibc'+versions['glibc'])


async def validate(args):
    sys.path.insert(0,str(Path(args.source_root).resolve()))
    from usl_systems.language import Interpreter
    from cases import cases
    from frontends import FRONTENDS,Unsupported
    from native import process
    versions=native_versions()
    case_rows=cases();policy=admission(len(case_rows));output=Path(args.output).resolve();output.mkdir(parents=True,exist_ok=True)
    for name in ['generated','cases']:(output/name).mkdir(exist_ok=True)
    references=json.loads((ROOT/'REFERENCES.json').read_text())
    event=asyncio.Event();loop=asyncio.get_running_loop();started=[];counter={'running':0,'peak':0}
    pool=ThreadPoolExecutor(max_workers=policy['native_slots'])
    async def one(case):
        started.append(case['catalog_id']+'/'+case['name']);await event.wait()
        row=dict(case);row['source_sha256']=hashlib.sha256(case['source'].encode()).hexdigest()
        row['independent_intent_sha256']=digest({'expected':case['expected'],'frontend_reject':case['frontend_reject'],'native_reject':case['native_reject']})
        row['usl_executions']=0;row['native_executions']=0;row['passed']=True
        generated=None
        try:
            ir,generated=FRONTENDS[case['catalog_id']](case['source'])
            row['ir']=ir;row['ir_sha256']=digest(ir)
            if case['frontend_reject']:row['passed']=False;row['failure']='Frontend accepted excluded input'
        except (Unsupported,ValueError) as error:
            row['frontend_error']=str(error)
            if not case['frontend_reject']:row['passed']=False;row['failure']='Unexpected frontend rejection'
        if generated is not None and not case['frontend_reject']:
            name=case['catalog_id']+'--'+case['name']+'.usl';(output/'generated'/name).write_text(generated)
            row['generated_source']=str(Path('generated')/name);row['generated_sha256']=hashlib.sha256(generated.encode()).hexdigest()
            try:
                result=Interpreter(timeout=5,max_ops=2_000_000).run(generated)
                row['usl_executions']=1;row['usl_result']=result.variables['result'];row['usl_operations']=result.operations
                if row['usl_result']!=case['expected']:row['passed']=False;row['failure']='USL disagrees with independent intent'
            except Exception as error:row['passed']=False;row['failure']='USL execution failed: '+str(error)
        if not case['frontend_reject'] or case['native_reject']:
            def observed():
                counter['running']+=1;counter['peak']=max(counter['peak'],counter['running'])
                try:return process(case['catalog_id'],case['source'])
                finally:counter['running']-=1
            try:
                native=await loop.run_in_executor(pool,observed);row['native']=native;row['native_executions']=native['native_executions']
                good=(not native['accepted']) if case['native_reject'] else (native['accepted'] and native['result']==case['expected'])
                if not good:row['passed']=False;row['failure']='Native disagrees with independent intent'
            except Exception as error:row['passed']=False;row['failure']='Native execution failed: '+str(error)
        else:row['native_not_run_reason']='Unsupported feature rejected before any native side effect; not classified as upstream syntax-invalid'
        (output/'cases'/(case['catalog_id']+'--'+case['name']+'.json')).write_text(json.dumps(row,indent=2,ensure_ascii=True)+'\n')
        return row
    tasks=[asyncio.create_task(one(case)) for case in case_rows]
    await asyncio.sleep(0)
    if len(started)!=len(case_rows):raise RuntimeError('Not every case actor started before gate release')
    start=time.monotonic();event.set();rows=await asyncio.gather(*tasks);pool.shutdown()
    policy['actual_peak_native_jobs']=counter['peak'];policy['all_actors_started_before_release']=True
    records=[]
    source_hashes={name:sha(ROOT/name) for name in ['frontends.py','native.py','cases.py','run.py','restore.py','PROVIDERS.json']}
    runtime_path=Path(args.source_root)/'usl_systems/language.py'
    for identifier in sorted(FRONTENDS):
        selected=[row for row in rows if row['catalog_id']==identifier]
        records.append({'catalog_id':identifier,'category':'category_processing','scoped_profile_validated':all(row['passed'] for row in selected),
                        'full_standard_qualified':False,'exact_profile':profile_text(identifier,versions),'observed_native_library_versions':versions,
                        'cases':len(selected),'case_records':selected,'native_executions':sum(row['native_executions'] for row in selected),
                        'usl_executions':sum(row['usl_executions'] for row in selected),
                        'source_hashes':source_hashes,'usl_runtime_sha256':sha(runtime_path),
                        'tool_hashes':{str(Path(path).resolve()):sha(path) for path in tool_paths(identifier)},
                        'reference_hashes':[r for r in references if r['catalog_id']==identifier],
                        'open_obligations':['Exact complete specification/version and normative dependency audit','All constructs outside this bounded profile',
                                            'Whole-profile formal preservation and independent review','Complete library/ABI/host/platform coverage',
                                            'General concurrency/cancellation and deployment resource guarantees beyond isolated sequential processing']})
    result={'schema':'usl.configuration.concurrent-native-profiles.v1','records':records,'resource_admission':policy,
            'case_count':len(rows),'validated_ids':[r['catalog_id'] for r in records if r['scoped_profile_validated']],
            'native_executions':sum(r['native_executions'] for r in records),'usl_executions':sum(r['usl_executions'] for r in records),
            'all_cases_passed':all(r['passed'] for r in rows),'full_standards_added':0,'wall_seconds':time.monotonic()-start,
            'observed_native_library_versions':versions,
            'platform':{'system':platform.platform(),'machine':platform.machine(),'libc':platform.libc_ver(),'python':sys.version},
            'artifact_reuse_policy':'Only installed tools are reused; every native observation and USL execution is fresh; no side effects replayed'}
    (output/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=True)+'\n')
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-root',required=True);parser.add_argument('--output',default='results')
    args=parser.parse_args();result=asyncio.run(validate(args))
    print(json.dumps({key:result[key] for key in ['validated_ids','case_count','native_executions','usl_executions','all_cases_passed','wall_seconds']}))
    return 0 if result['all_cases_passed'] else 1


if __name__=='__main__':raise SystemExit(main())
