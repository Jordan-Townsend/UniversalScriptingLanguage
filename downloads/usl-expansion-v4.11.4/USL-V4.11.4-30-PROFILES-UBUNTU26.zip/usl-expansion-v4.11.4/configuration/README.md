# Configuration processing profiles

Eight original catalog IDs have executable source frontends, generated USL, and
fresh native observations compared with independently authored expected values.
These are finite bounded profiles; all full-standard qualifications remain false.

| ID | Exact native carrier and supported processing | Cases | Native / USL executions |
|---|---|---:|---:|
| basemake | GNU make 4.4.1 variable `=`, `:=`, `+=`, `?=`; early/late expansion and assignment order | 21 | 20 / 18 |
| termcap | ncurses 6.5.20250216 `tic`, then native capability queries; `am/co/li/cl/cm`, selected escapes and cancellations | 21 | 38 / 19 |
| terminfo | ncurses 6.5.20250216 `tic`, then native capability queries; `am/cols/lines/clear/cup`, selected escapes and cancellations | 21 | 38 / 19 |
| resourcebundle | ICU 76.1 strict `genrb`, then `ures` lookup of flat Unicode strings and signed 28-bit integers | 16 | 28 / 13 |
| devicetree | DTC 1.7.2 compilation and `fdtget` observation of actual DTB property bytes; nodes, flags, ASCII string lists and unsigned 32-bit cells | 11 | 41 / 9 |
| kconfig | kconfig-frontends 4.11.0.1 `--alldefconfig`; bool/int/string symbols, ordered defaults and earlier bool dependencies | 13 | 12 / 11 |
| ldapconf | OpenLDAP 2.6.10 isolated `ldap.conf`, observed by `ldap_get_option`; BASE, DEREF, SIZELIMIT and TIMELIMIT | 12 | 10 / 10 |
| unixconfig | Exact Pygments UnixConfigLexer `/etc/passwd` and `/etc/group` identities; glibc 2.41 `fgetpwent` and `fgetgrent` on isolated fixtures | 25 | 19 / 19 |

The checked suite has 140 intent cases, 206 native executions, 118 USL executions,
and 153 regression tests. Cases include boundaries, independent positive intent,
upstream syntax errors, and excluded constructs. Excluded features are rejected
before native effects and are not counted as native syntax failures. Each native
subprocess has an actual command, exit status, output hash and isolated temporary
fixture. Native processing never reads or modifies the host passwd/group files.
Each UnixConfig fixture contains one format: seven-field passwd records or
four-field group records. Source order, duplicates and group member order are
retained; malformed numeric/short records are skipped. Mixed formats, NIS/NSS,
shadow data, empty member tokens and the special all-ones uid/gid are excluded.

Run in the prepared x86-64 Linux environment:

```bash
source /workspace/.onboarding/activate-usl.sh
cd /workspace/usl-expansion-v4.11.4/configuration
python restore.py
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
USL_SOURCE_ROOT=/workspace/usl-v4.10.0-clean-test python -m unittest test_configuration -v
```

`run.py` accepts a different output directory for a fresh external receipt. Tests
also verify the retained `results/results.json` schema and source hashes; refresh
that local receipt after an intentional implementation change. The coordinator
runs the same frontend/native suite in its own output directory. Every logical
case actor starts before release; native admission uses observed CPU quota and
memory headroom, with no fixed worker cap. This is measured admission, not a
proved general memory or scheduling bound. Every run performs fresh USL/native
work and retains generated `.usl` files and per-case JSON receipts.

Source archives omit `providers/` and ELF executables. `restore.py` rebuilds this
local provider directory from these exact Debian trixie package pins:

- device-tree-compiler and libfdt1: `1.7.2-2+b1`.
- icu-devtools: `76.1-4`.
- kconfig-frontends: `4.11.0.1+dfsg-6+b1`.

Every restore unconditionally verifies frozen `DEBIAN_INRELEASE.asc` with `sqv`
and the installed Debian archive keyring. It compares the authenticated cleartext
with frozen provenance, authenticates the package index through its signed SHA256
entry, checks each exact package/version/size/SHA256 pin in `PROVIDERS.json`, and
checks downloaded package bytes before extraction. Existing `DEBIAN_RELEASE.txt`
never skips signature verification. No source or provenance file is rewritten.
The prepared authenticated index cache under `/workspace/.onboarding/apt/lists`
is reused; `--index` selects another cache. If absent, the exact compressed index
is fetched by its authenticated hash. An unavailable old index or package fails
closed and requires recovering the pinned artifact, not updating a checksum.
Downloads use `deb.debian.org`; no credentials are required. `RESTORE_TEST.json`
records restoration into a provider-free copy, unchanged source identities and
a second fresh native validation.

The environment must already provide Python 3.12, the retained USL runtime,
`make`, `tic`, `sqv`, `dpkg-deb`, the Debian archive keyring, glibc 2.41,
libtinfo 6, OpenLDAP `libldap.so.2`, and ICU `libicuuc.so.76`/`libicudata.so.76`.
Tool/runtime hashes are recorded in results. These architecture/library versions
are part of the tested domain. Host library compatibility outside it remains an
open obligation.

Frontends reject sources over 65,536 UTF-8 bytes, NULs and over 256 lines. Make
lowering additionally bounds expansion work, depth and generated assignments;
device-tree nesting is bounded. No recipe, shell function, terminal parameter
execution, LDAP networking/authentication, device execution, Kconfig choice/select,
ICU aliases/nesting/fallback, or arbitrary config extension is claimed. Retrieved
reference bodies and exact hashes are retained in `references/` and
`REFERENCES.json`; failed retrievals remain visible. Full normative dependency,
whole-profile preservation, library/ABI/platform, concurrency/cancellation and
complete standard audits remain open in every record.


For Ubuntu26 compatibility, `USL_COMPAT_LIBDIR` can select an isolated directory
containing the exact old-ABI native libraries. The native environment prepends
local providers and this directory while retaining inherited `LD_LIBRARY_PATH`.
The runner records the actual selected library paths and hashes. A missing
private library falls back to the existing system path; no system library is
replaced. `../ubuntu/restore_compat.py` restores the exact authenticated ICU76
package separately. Its use requires a fresh native validation on that OS.

Native ncurses and glibc version strings are read from the selected shared
libraries themselves (`curses_version` / `gnu_get_libc_version`) and retained in
each fresh profile. Profile text uses these actual versions, including ncurses
6.6.20251231 and glibc2.43 when tested inside Ubuntu26.04. The original table
above describes the retained Debian baseline; new OS evidence has its own
platform, exact carrier versions, paths and hashes.
