"""Acquire authoritative profile references with exact observed content hashes."""
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import inspect
import json
from pathlib import Path
import urllib.request

ROOT=Path(__file__).resolve().parent
URLS={
    'basemake':['https://www.gnu.org/software/make/manual/html_node/Flavors.html','https://www.gnu.org/software/make/manual/html_node/Appending.html'],
    'termcap':['https://invisible-island.net/ncurses/man/termcap.5.html'],
    'terminfo':['https://invisible-island.net/ncurses/man/terminfo.5.html'],
    'resourcebundle':['https://unicode-org.github.io/icu/userguide/locale/resources.html'],
    'unixconfig':['https://man7.org/linux/man-pages/man3/fgetpwent.3.html','https://man7.org/linux/man-pages/man5/passwd.5.html',
                  'https://manpages.debian.org/trixie/manpages-dev/fgetgrent.3.en.html',
                  'https://manpages.debian.org/trixie/manpages/group.5.en.html'],
    'ldapconf':['https://raw.githubusercontent.com/openldap/openldap/OPENLDAP_REL_ENG_2_6_10/doc/man/man5/ldap.conf.5'],
    'kconfig':['https://www.kernel.org/doc/html/v4.11/kbuild/kconfig-language.html'],
    'devicetree':['https://devicetree-specification.readthedocs.io/en/stable/devicetree-basics.html'],
}


def collect():
    dest=ROOT/'references';dest.mkdir(exist_ok=True)
    tasks=[(identifier,url) for identifier,urls in URLS.items() for url in urls]
    def fetch(task):
        identifier,url=task
        try:
            request=urllib.request.Request(url,headers={'User-Agent':'USL-profile-reference-audit/4.11.4'})
            with urllib.request.urlopen(request,timeout=20) as response:
                body=response.read(2_000_001)
                if len(body)>2_000_000:raise ValueError('Reference exceeds2MB retrieval budget')
                digest=hashlib.sha256(body).hexdigest();(dest/digest).write_bytes(body)
                return {'catalog_id':identifier,'url':url,'resolved_url':response.url,'sha256':digest,'bytes':len(body),'retrieved':True,'normative_audit_complete':False}
        except Exception as e:return {'catalog_id':identifier,'url':url,'retrieved':False,'error':str(e)}
    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:rows=list(pool.map(fetch,tasks))
    for identifier,name in [('resourcebundle','genrb.1.gz'),('devicetree','dtc.1.gz'),('kconfig','kconfig-conf.1.gz')]:
        p=ROOT/'providers/usr/share/man/man1'/name
        body=gzip.decompress(p.read_bytes());digest=hashlib.sha256(body).hexdigest();(dest/digest).write_bytes(body)
        rows.append({'catalog_id':identifier,'origin':'Signed Debian provider package manual '+name,
                     'sha256':digest,'bytes':len(body),'retrieved':True,'normative_audit_complete':False})
    from pygments.lexers.configs import UnixConfigLexer
    body=inspect.getsource(UnixConfigLexer).encode();digest=hashlib.sha256(body).hexdigest();(dest/digest).write_bytes(body)
    rows.append({'catalog_id':'unixconfig','origin':'Installed Pygments UnixConfigLexer identity definition; semantics still use glibc',
                 'sha256':digest,'bytes':len(body),'retrieved':True,'normative_audit_complete':False})
    (ROOT/'REFERENCES.json').write_text(json.dumps(rows,indent=2)+'\n')
    return rows


if __name__=='__main__':print(json.dumps(collect()))
