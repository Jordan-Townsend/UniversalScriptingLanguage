"""Independent native/parser boundary and actual-artifact proof regressions.

The negative sources are authored independently of run.py's fixture generator.
Every rejection assertion first checks the original source with real Agda.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from agda_frontend import Unsupported, emit, parse
from run import formal_proofs


SOURCE_ROOT = Path('/workspace/usl-v4.10.0-clean-test')
HEADER = 'module Review where\nopen import Agda.Builtin.Nat\nopen import Agda.Builtin.Bool\n'
PRELUDE = 'plus : Nat → Nat → Nat\nplus x y = x + y\nbump : Nat → Nat\nbump x = suc x\n'
RECEIPTS = []


def native_check(source, literate=False):
    with tempfile.TemporaryDirectory(prefix='usl-agda-review-') as directory:
        path = Path(directory) / ('Review.lagda.md' if literate else 'Review.agda')
        path.write_text(source)
        outcome = subprocess.run(['agda', '--no-libraries', '--safe', '-i', directory, str(path)],
                                 capture_output=True, text=True, timeout=30)
        RECEIPTS.append({'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
                         'source_text': source,
                         'literate': literate, 'native_exit_status': outcome.returncode,
                         'diagnostic': outcome.stdout + outcome.stderr})
        return outcome


class IndependentAgdaReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(SOURCE_ROOT))
        import usl_systems.language as language
        cls.runtime = language

    def reject_native_and_frontend(self, body):
        source = HEADER + PRELUDE + body
        outcome = native_check(source)
        self.assertNotEqual(outcome.returncode, 0, outcome.stdout + outcome.stderr)
        with self.assertRaises(Unsupported):
            parse(source)

    def test_application_arguments_are_atoms_not_implicit_nested_calls(self):
        for body in [
            'bad : Nat → Nat\nbad x = suc suc x\n',
            'bad : Nat → Nat → Nat\nbad x y = plus suc x y\n',
            'bad : Nat → Nat\nbad x = suc bump x\n',
            'bad : Nat → Nat → Nat\nbad x y = plus bump x y\n',
        ]:
            with self.subTest(body=body):
                self.reject_native_and_frontend(body)

    def test_agda_names_cannot_be_split_into_operators_or_numeric_arguments(self):
        for body in [
            'bad : Nat → Nat → Nat\nbad x y = x+y\n',
            'bad : Nat → Nat\nbad x = x +1\n',
            'bad : Nat → Nat\nbad x = 1+ x\n',
            'bad : Nat → Nat → Bool\nbad x y = x==y\n',
            'bad : Nat → Nat\nbad x = plus 1x\n',
        ]:
            with self.subTest(body=body):
                self.reject_native_and_frontend(body)

    def test_embedded_double_hyphen_is_not_an_agda_line_comment(self):
        self.reject_native_and_frontend('bad : Nat → Nat\nbad x = x--comment\n')

    def test_declaration_indentation_cannot_be_silently_erased(self):
        for body in ['  bad : Nat → Nat\nbad x = x\n',
                     'bad : Nat → Nat\n  bad x = x\n']:
            with self.subTest(body=body):
                self.reject_native_and_frontend(body)

    def test_version_specific_keywords_are_not_function_or_parameter_names(self):
        for name in ['import', 'opaque', 'unfolding']:
            for body in [name + ' : Nat\n' + name + ' = 1\n',
                         'bad : Nat → Nat\nbad ' + name + ' = ' + name + '\n']:
                with self.subTest(body=body):
                    self.reject_native_and_frontend(body)

    def test_parenthesized_calls_and_separated_comments_have_fresh_native_evidence(self):
        source = HEADER + PRELUDE + (
            'composed : Nat → Nat → Nat\ncomposed x y = plus (bump x) (suc y) -- ordinary comment\n'
            'preserve : Bool → Nat → Bool\npreserve flag x = flag\n'
            'truth : Bool\ntruth = true\n')
        cases = [('composed', [0, 0], 2), ('composed', [10**11, 9], 10**11 + 11),
                 ('preserve', [False, 0], False), ('preserve', [True, 10**11], True),
                 ('truth', [], True)]
        # Ground source-level observations avoid assuming which unused arguments
        # Agda's JavaScript compiler keeps in its curried export ABI.
        for index, (name, arguments, expected) in enumerate(cases):
            source += 'observed' + str(index) + ' : ' + ('Bool' if type(expected) is bool else 'Nat') + '\n'
            source += 'observed' + str(index) + ' = ' + name + ''.join(
                ' ' + ('true' if value else 'false') if type(value) is bool else ' ' + str(value)
                for value in arguments) + '\n'
        _, functions = parse(source)
        generated = emit(functions)
        with tempfile.TemporaryDirectory(prefix='usl-agda-positive-review-') as directory:
            directory = Path(directory)
            path = directory / 'Review.agda'
            path.write_text(source)
            compiled = subprocess.run(['agda', '--no-libraries', '--safe', '--js',
                                       '--compile-dir=' + str(directory / 'js'), '-i', str(directory), str(path)],
                                      capture_output=True, text=True, timeout=60)
            self.assertEqual(compiled.returncode, 0, compiled.stdout + compiled.stderr)
            driver = directory / 'driver.js'
            driver.write_text("const f=require(process.argv[2]); const names=JSON.parse(process.argv[3]); console.log(JSON.stringify(names.map(name=>{const v=f[name];return {type:typeof v,value:typeof v==='bigint'?String(v):v};})));\n")
            encoded = ['observed' + str(index) for index in range(len(cases))]
            environment = dict(os.environ)
            environment['NODE_PATH'] = str(directory / 'js')
            outcome = subprocess.run(['node', str(driver), str(directory / 'js/jAgda.Review.js'), json.dumps(encoded)],
                                     capture_output=True, text=True, timeout=30, env=environment)
            self.assertEqual(outcome.returncode, 0, outcome.stderr)
            native = json.loads(outcome.stdout)
            calls = '\nlet observed = [' + ', '.join('agda_' + name + '(' + ', '.join(repr(v) for v in arguments) + ')'
                                                      for name, arguments, _ in cases) + ']\n'
            observed = self.runtime.Interpreter().run(generated + calls).variables['observed']
            self.assertEqual(len(native), len(cases))
            self.assertEqual(len(observed), len(cases))
            for case, actual, usl in zip(cases, native, observed):
                expected = case[2]
                self.assertEqual(actual['type'], 'boolean' if type(expected) is bool else 'bigint')
                value = actual['value'] if type(expected) is bool else int(actual['value'])
                self.assertIs(type(value), type(expected))
                self.assertEqual(value, expected)
                self.assertIs(type(usl), type(expected))
                self.assertEqual(usl, expected)
            RECEIPTS.append({'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
                             'source_text': source,
                             'native_exit_status': compiled.returncode, 'fresh_native_observations': len(cases),
                             'observations': native, 'USL_observations': observed,
                             'diagnostic': compiled.stdout + compiled.stderr})

    def test_literate_extraction_does_not_hide_invalid_application(self):
        source = '# Review prose\n```agda\n' + HEADER + PRELUDE + 'bad : Nat → Nat\nbad x = suc bump x\n```\n'
        outcome = native_check(source, literate=True)
        self.assertNotEqual(outcome.returncode, 0, outcome.stdout + outcome.stderr)
        with self.assertRaises(Unsupported):
            parse(source, literate=True)

    def test_prover_rejects_mutated_actual_generated_arithmetic(self):
        _, functions = parse(HEADER + 'monus : Nat → Nat → Nat\nmonus x y = x - y\n')
        generated = emit(functions)
        wrong = generated.replace('max((arg_x - arg_y), 0)', '(arg_x - arg_y)')
        self.assertNotEqual(generated, wrong)
        with tempfile.TemporaryDirectory(prefix='usl-agda-proof-review-') as directory:
            with self.assertRaisesRegex(ValueError, 'Translation proof not established') as rejected:
                formal_proofs(functions, wrong, self.runtime, Path(directory))
        RECEIPTS.append({'kind': 'actual_generated_AST_mutation', 'mutation': 'replace saturating subtraction by integer subtraction',
                         'generated_sha256': hashlib.sha256(generated.encode()).hexdigest(),
                         'mutated_sha256': hashlib.sha256(wrong.encode()).hexdigest(), 'rejected': True,
                         'diagnostic': str(rejected.exception)})

    def test_prover_rejects_mutated_actual_generated_boolean(self):
        _, functions = parse(HEADER + 'preserve : Bool → Bool\npreserve flag = flag\n')
        generated = emit(functions)
        wrong = generated.replace('return arg_flag', 'return True')
        self.assertNotEqual(generated, wrong)
        with tempfile.TemporaryDirectory(prefix='usl-agda-proof-review-') as directory:
            with self.assertRaisesRegex(ValueError, 'Translation proof not established') as rejected:
                formal_proofs(functions, wrong, self.runtime, Path(directory))
        RECEIPTS.append({'kind': 'actual_generated_AST_mutation', 'mutation': 'replace Boolean identity by constant True',
                         'generated_sha256': hashlib.sha256(generated.encode()).hexdigest(),
                         'mutated_sha256': hashlib.sha256(wrong.encode()).hexdigest(), 'rejected': True,
                         'diagnostic': str(rejected.exception)})


if __name__ == '__main__':
    unittest.main()
