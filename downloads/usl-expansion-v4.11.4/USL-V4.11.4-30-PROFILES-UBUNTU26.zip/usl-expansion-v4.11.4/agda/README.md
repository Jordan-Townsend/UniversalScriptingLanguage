This tranche implements Agda2.6.4.3 and its Markdown literate frontend for a
first-order, nonrecursive Nat/Bool profile. Actual source is parsed and typed,
then translated into executed USL functions. Selected operations are natural
literals, zero/suc, addition, multiplication, saturating natural subtraction,
equality/order and calls to earlier definitions. Function parameters are renamed
to preserve binding when they share names with USL builtins. Unsupported syntax,
unknown bindings, type mismatches and malformed literate fences fail closed.

Both original programs compile freshly using Agda --no-libraries --safe --js.
The actual generated JavaScript runs under Node with BigInt natural arithmetic.
Ground queries are defined and typechecked in Agda, then Node reads their
compiled exports. The harness does not guess a curried JavaScript ABI: Agda may
erase unused parameters. Application arguments require atoms or parentheses,
operator/comment boundaries follow the selected lexical rules, and declarations
use zero-column layout; unsupported layouts are rejected.
Each frontend has1018 independently specified original/generated/intent case
comparisons, including zero, Boolean types, precedence, monus underflow and
10^12 inputs and unused-argument erasure. These are2036 native case observations across two original-source
compiles and two Node processes, plus two actual USL interpreter runs with1018
observations each. Type/scope/termination controls are separately rejected by
the native Agda checker. Generated sources, compiler diagnostics and byte hashes
are retained. They are never cached as fresh observations.

For each of13 functions per frontend, Z3 checks equality of the typed IR
denotation and the actual emitted return-expression AST for all nonnegative
integer Nat parameters and Boolean parameters. The26 unsat obligations retain
SMT inputs, exact solver version and assumptions. A deliberately wrong ordinary
subtraction lowering must produce a sat counterexample. These checks assume a
correct parser/IR interpretation, solver and modeled USL operator/call behavior.
They do not prove the Agda compiler, USL interpreter, complete frontend or Agda
dependent-type system correct. Finite native inputs and runtime budgets retain
their finite scope; no full-standard qualification is awarded.

```bash
source /workspace/.onboarding/activate-usl.sh
python -m unittest test_agda_frontend -v
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

The retained host dependencies are Agda2.6.4.3, its matching builtin and JS
runtime sources, Node and z3-solver. Exact executable/source hashes are recorded.
Native binaries are not shipped. Full Agda needs dependent types, universes,
records, data families, pattern coverage, recursion/termination, implicit and
instance arguments, modules, libraries, FFI/platform semantics and a complete
normative/code/conformance/proof map. Those obligations remain open.
