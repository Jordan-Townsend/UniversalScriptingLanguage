"""Fresh Agda->JavaScript execution against typed USL and independent intent."""
import argparse
import ast
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

from agda_frontend import emit, parse

ROOT = Path(__file__).resolve().parent
SPECS = [
    ('add', ('Nat', 'Nat'), 'Nat', 'x + y', lambda x, y: x + y),
    ('subtract', ('Nat', 'Nat'), 'Nat', 'x - y', lambda x, y: 0 if x < y else x - y),
    ('multiply', ('Nat', 'Nat'), 'Nat', 'x * y', lambda x, y: x * y),
    ('precedence', ('Nat', 'Nat', 'Nat'), 'Nat', 'x + y * z', lambda x, y, z: x + y * z),
    ('grouping', ('Nat', 'Nat', 'Nat'), 'Nat', '(x + y) * z', lambda x, y, z: (x + y) * z),
    ('nested', ('Nat', 'Nat'), 'Nat', 'add (subtract x y) (multiply y 2)', lambda x, y: max(0, x-y) + y + y),
    ('successor', ('Nat',), 'Nat', 'suc (suc x)', lambda x: x + 2),
    ('equal', ('Nat', 'Nat'), 'Bool', 'x == y', lambda x, y: x == y),
    ('less', ('Nat', 'Nat'), 'Bool', 'x < y', lambda x, y: x < y),
    ('identity', ('Bool',), 'Bool', 'x', lambda x: x),
    ('preserve', ('Bool', 'Nat'), 'Bool', 'x', lambda x,y: x),
    ('dropfirst', ('Nat', 'Bool'), 'Bool', 'y', lambda x,y: y),
    ('constant', (), 'Nat', '42', lambda: 42),
]
VALUES = [0, 1, 2, 7, 31, 1000, 10**12]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=True) + '\n')


def intent_cases():
    cases = []
    for name, arguments, result, expression, oracle in SPECS:
        domains = [VALUES if kind == 'Nat' else [False, True] for kind in arguments]
        for values in itertools.product(*domains):
            expected = oracle(*values)
            assert type(expected) is (int if result == 'Nat' else bool)
            cases.append({'function': name, 'arguments': list(values), 'result_type': result,
                          'expected': expected, 'intent_origin': 'Independent arithmetic/Boolean function in run.py SPECS'})
    return cases


def formal_proofs(functions, generated, runtime, output):
    import z3
    tree = ast.parse(runtime.normalize(generated))
    targets = {node.name: node for node in tree.body}
    def source(node, variables, depth=0):
        if depth > 64:
            raise ValueError('Proof inline depth')
        tag = node[0]
        if tag == 'natural': return z3.IntVal(node[1])
        if tag == 'boolean': return z3.BoolVal(node[1])
        if tag == 'variable': return variables[node[1]]
        if tag == 'suc': return source(node[1], variables, depth+1) + 1
        if tag == 'call':
            function = functions[node[1]]
            args = [source(arg, variables, depth+1) for arg in node[2]]
            return source(function.expression, dict(zip(function.parameters, args)), depth+1)
        a, b = source(node[1], variables, depth+1), source(node[2], variables, depth+1)
        return {'+': lambda: a+b, '*': lambda: a*b, '-': lambda: z3.If(a >= b, a-b, 0),
                '<': lambda: a<b, '==': lambda: a==b}[tag]()
    def target(node, variables, depth=0):
        if depth > 64: raise ValueError('Proof target inline depth')
        if type(node) is ast.Constant:
            if type(node.value) is bool: return z3.BoolVal(node.value)
            if type(node.value) is int and node.value >= 0: return z3.IntVal(node.value)
        if type(node) is ast.Name: return variables[node.id]
        if type(node) is ast.BinOp:
            a,b=target(node.left,variables,depth+1),target(node.right,variables,depth+1)
            if type(node.op) is ast.Add:return a+b
            if type(node.op) is ast.Sub:return a-b
            if type(node.op) is ast.Mult:return a*b
        if type(node) is ast.Compare and len(node.ops)==len(node.comparators)==1:
            a,b=target(node.left,variables,depth+1),target(node.comparators[0],variables,depth+1)
            if type(node.ops[0]) is ast.Lt:return a<b
            if type(node.ops[0]) is ast.Eq:return a==b
        if type(node) is ast.Call and type(node.func) is ast.Name and not node.keywords:
            values=[target(arg,variables,depth+1) for arg in node.args]
            if node.func.id=='max' and len(values)==2:return z3.If(values[0]>=values[1],values[0],values[1])
            f=targets[node.func.id]
            if len(f.body)!=1 or type(f.body[0]) is not ast.Return:raise ValueError('Unexpected generated function body')
            return target(f.body[0].value,dict(zip([p.arg for p in f.args.args],values)),depth+1)
        raise ValueError('Unmodeled generated AST in proof')
    proofs=[]
    for name,function in functions.items():
        symbolic={p:(z3.Int(p) if t=='Nat' else z3.Bool(p)) for p,t in zip(function.parameters,function.argument_types)}
        constraints=[symbolic[p]>=0 for p,t in zip(function.parameters,function.argument_types) if t=='Nat']
        generated_function=targets['agda_'+name]
        actual=target(generated_function.body[0].value,{'arg_'+p:v for p,v in symbolic.items()})
        expected=source(function.expression,symbolic)
        solver=z3.Solver();solver.set(timeout=5000);solver.add(*constraints);solver.add(expected!=actual)
        smt=solver.to_smt2();result=solver.check()
        if result!=z3.unsat:raise ValueError('Translation proof not established: '+name+' '+str(result))
        path=output/(name+'.smt2');path.write_text(smt)
        proofs.append({'function':name,'result':'unsat','SMT_sha256':sha(path),
                       'claim':'Typed IR denotation equals actual emitted return-expression AST for all nonnegative integer Nat arguments and Boolean arguments',
                       'assumptions':['Trusted Z3','Correct source-to-IR parse and selected Nat/Bool interpretation','USL runtime implements the modeled AST operators/calls'],
                       'not_proved':['Agda compiler correctness','USL interpreter correctness','Parser correctness','All Agda or dependent types']})
    # A deliberate wrong monus lowering must have a counterexample.
    x,y=z3.Ints('x y');counter=z3.Solver();counter.add(x>=0,y>=0,z3.If(x>=y,x-y,0)!=x-y)
    if counter.check()!=z3.sat:raise ValueError('Proof negative control failed')
    return {'Z3_version':z3.get_version_string(),'proofs':proofs,'wrong_monus_negative_control':'sat',
            'full_standard_qualified':False}


def run(source_root, output):
    started=time.perf_counter();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(Path(source_root).resolve()))
    import usl_systems.language as runtime
    if sha(runtime.__file__)!='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc':raise ValueError('USL runtime identity differs')
    tool=shutil.which('agda');node=shutil.which('node')
    if not tool or not node:raise ValueError('Agda and Node hosts required')
    version=subprocess.check_output([tool,'--version'],text=True).strip()
    if version!='Agda version 2.6.4.3':raise ValueError('Native Agda version differs')
    datadir=Path(subprocess.check_output([tool,'--print-agda-dir'],text=True).strip())
    identities={'agda_wrapper_sha256':sha(tool),'agda_binary_sha256':sha('/workspace/.onboarding/sysroot/usr/bin/agda') if Path('/workspace/.onboarding/sysroot/usr/bin/agda').exists() else sha(tool),
                'node_binary_sha256':sha(node),'USL_runtime_sha256':sha(runtime.__file__),'source_sha256':{p.name:sha(p) for p in sorted(ROOT.glob('*.py'))},
                'Nat_builtin_sha256':sha(datadir/'lib/prim/Agda/Builtin/Nat.agda'),'Bool_builtin_sha256':sha(datadir/'lib/prim/Agda/Builtin/Bool.agda'),'Agda_JS_runtime_sha256':sha(datadir/'JS/agda-rts.js')}
    cases=intent_cases();records=[]
    negative_receipts=[]
    for module,body in [('BadType','bad : Nat\nbad = true\n'),
                        ('BadScope','bad : Nat\nbad = missing\n'),
                        ('BadTermination','bad : Nat → Nat\nbad x = bad x\n')]:
        directory=output/'native-negative';directory.mkdir(exist_ok=True)
        path=directory/(module+'.agda')
        path.write_text('module '+module+' where\nopen import Agda.Builtin.Nat\nopen import Agda.Builtin.Bool\n'+body)
        outcome=subprocess.run([tool,'--no-libraries','--safe','-i',str(directory),str(path)],capture_output=True,text=True,timeout=30)
        (directory/(module+'.log')).write_text(outcome.stdout+outcome.stderr)
        if outcome.returncode==0:raise ValueError('Native semantic rejection control unexpectedly accepted: '+module)
        negative_receipts.append({'module':module,'source_sha256':sha(path),'exit_status':outcome.returncode,
                                  'diagnostic_sha256':sha(directory/(module+'.log')),'expected_rejection':True})
    for catalog_id,module,literate in [('agda','ClosedNat',False),('literate-agda','LiterateNat',True)]:
        work=output/catalog_id;work.mkdir(exist_ok=True)
        text='module '+module+' where\nopen import Agda.Builtin.Nat\nopen import Agda.Builtin.Bool\n'
        for name,arguments,result,expression,_ in SPECS:
            params=['x','y','z'][:len(arguments)]
            text+=name+' : '+' → '.join(list(arguments)+[result])+'\n'+name+(' '+' '.join(params) if params else '')+' = '+expression+'\n'
        source=('# Literate natural arithmetic\n\n```agda\n'+text+'```\nIgnored prose outside the code.\n') if literate else text
        path=work/(module+('.lagda.md' if literate else '.agda'));path.write_text(source)
        _,functions=parse(source,literate=literate);generated=emit(functions)
        (work/'generated.usl').write_text(generated)
        proofs=formal_proofs(functions,generated,runtime,work)
        # Agda erases unused arguments in the JS ABI. Compile ground queries
        # in Agda itself rather than guessing exported curried arities.
        harness_module=module+'Checks'
        harness='module '+harness_module+' where\nopen import '+module+'\nopen import Agda.Builtin.Nat\nopen import Agda.Builtin.Bool\n'
        for index,case in enumerate(cases):
            arguments=['true' if a is True else 'false' if a is False else str(a) for a in case['arguments']]
            harness+='obs'+str(index)+' : '+case['result_type']+'\nobs'+str(index)+' = '+case['function']+(' '+' '.join(arguments) if arguments else '')+'\n'
        harness_path=work/(harness_module+'.agda');harness_path.write_text(harness)
        compile_command=[tool,'--no-libraries','--safe','--js','--compile-dir='+str(work/'js'),'-i',str(work),str(harness_path)]
        result=subprocess.run(compile_command,capture_output=True,text=True,timeout=60)
        (work/'compile.log').write_text(result.stdout+result.stderr)
        if result.returncode:raise ValueError('Fresh native Agda compilation failed: '+result.stdout+result.stderr)
        payload=['obs'+str(index) for index in range(len(cases))]
        driver="const fs=require('fs'); const f=require(process.argv[2]); const cases=JSON.parse(fs.readFileSync(0,'utf8')); console.log(JSON.stringify(cases.map(name=>{const v=f[name];return typeof v==='bigint'?{kind:'Nat',value:String(v)}:{kind:'Bool',value:v};})));\n"
        (work/'driver.js').write_text(driver);env=dict(os.environ);env['NODE_PATH']=str(work/'js')
        observed=subprocess.run([node,str(work/'driver.js'),str(work/'js'/('jAgda.'+harness_module+'.js'))],input=json.dumps(payload),capture_output=True,text=True,timeout=30,env=env)
        if observed.returncode:raise ValueError('Native compiled JavaScript failed: '+observed.stderr)
        native=json.loads(observed.stdout)
        calls='\nlet observed = ['+', '.join('agda_'+c['function']+'('+', '.join(repr(a) for a in c['arguments'])+')' for c in cases)+']\n'
        observed_usl=runtime.Interpreter(timeout=10,max_ops=1_000_000).run(generated+calls).variables['observed']
        if len(native)!=len(cases) or len(observed_usl)!=len(cases):raise ValueError('Case coverage mismatch')
        receipts=[]
        for case,native_value,usl_value in zip(cases,native,observed_usl):
            expected=case['expected'];actual=int(native_value['value']) if native_value['kind']=='Nat' else native_value['value']
            if native_value['kind']!=case['result_type'] or type(actual) is not type(expected) or actual!=expected or type(usl_value) is not type(expected) or usl_value!=expected:raise ValueError('Native/generated/intent counterexample: '+str(case))
            receipts.append({**case,'native_observed':native_value,'USL_observed':usl_value,'passed':True})
        (work/'executed.usl').write_text(generated+calls)
        write(work/'PROOFS.json',proofs);write(work/'CASES.json',receipts)
        records.append({'catalog_id':catalog_id,'scoped_profile_validated':True,'full_standard_qualified':False,
            'exact_profile':'Agda2.6.4.3 --safe, first-order nonrecursive Nat/Bool definitions; +, saturating -, *, <, ==, suc, constants and calls; Markdown agda fences for literate ID',
            'cases':len(cases),'native_executions':len(cases),'native_processes':2,'usl_executions':1,'USL_case_observations':len(cases),
            'native_version':version,'source_sha256':sha(path),'native_ground_query_harness_sha256':sha(harness_path),
            'native_query_calling_convention':'Compiler-checked Agda ground definitions; no guessed curried JavaScript ABI',
            'generated_USL_sha256':sha(work/'generated.usl'),'native_generated_JS_sha256':{p.name:sha(p) for p in sorted((work/'js').glob('*.js'))},
            'typed_IR_to_emitted_AST_proofs':len(proofs['proofs']),'native_observations_replayed':False,'identities':identities,
            'reference':{'url':'https://agda.readthedocs.io/en/v2.6.4.3/language/built-ins.html','authority_audit_complete':False},
            'open_obligations':['Dependent types, universes, records, data families and pattern coverage','Recursion/termination, modules, implicit and instance arguments','Full standard libraries and FFI/platform model','Complete normative inventory and independent frontend/runtime proof','Full host build/release qualification']})
    result={'schema':'usl.agda.native-and-typed-USL-profile.v1','records':records,'passed':True,'total_native_case_observations':sum(r['cases'] for r in records),
            'native_type_scope_termination_rejection_controls':negative_receipts,
            'full_standards_qualified':0,'seconds':time.perf_counter()-started}
    write(output/'results.json',result);print(json.dumps({k:v for k,v in result.items() if k!='records'}));return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,default=Path('/workspace/usl-v4.10.0-clean-test'));parser.add_argument('--output',type=Path,default=ROOT/'results')
    args=parser.parse_args();run(args.source_root,args.output)
