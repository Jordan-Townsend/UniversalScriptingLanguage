; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (distinct 42 42) true))
(check-sat)
