module ClosedNatChecks where
open import ClosedNat
open import Agda.Builtin.Nat
open import Agda.Builtin.Bool
obs0 : Nat
obs0 = add 0 0
obs1 : Nat
obs1 = add 0 1
obs2 : Nat
obs2 = add 0 2
obs3 : Nat
obs3 = add 0 7
obs4 : Nat
obs4 = add 0 31
obs5 : Nat
obs5 = add 0 1000
obs6 : Nat
obs6 = add 0 1000000000000
obs7 : Nat
obs7 = add 1 0
obs8 : Nat
obs8 = add 1 1
obs9 : Nat
obs9 = add 1 2
obs10 : Nat
obs10 = add 1 7
obs11 : Nat
obs11 = add 1 31
obs12 : Nat
obs12 = add 1 1000
obs13 : Nat
obs13 = add 1 1000000000000
obs14 : Nat
obs14 = add 2 0
obs15 : Nat
obs15 = add 2 1
obs16 : Nat
obs16 = add 2 2
obs17 : Nat
obs17 = add 2 7
obs18 : Nat
obs18 = add 2 31
obs19 : Nat
obs19 = add 2 1000
obs20 : Nat
obs20 = add 2 1000000000000
obs21 : Nat
obs21 = add 7 0
obs22 : Nat
obs22 = add 7 1
obs23 : Nat
obs23 = add 7 2
obs24 : Nat
obs24 = add 7 7
obs25 : Nat
obs25 = add 7 31
obs26 : Nat
obs26 = add 7 1000
obs27 : Nat
obs27 = add 7 1000000000000
obs28 : Nat
obs28 = add 31 0
obs29 : Nat
obs29 = add 31 1
obs30 : Nat
obs30 = add 31 2
obs31 : Nat
obs31 = add 31 7
obs32 : Nat
obs32 = add 31 31
obs33 : Nat
obs33 = add 31 1000
obs34 : Nat
obs34 = add 31 1000000000000
obs35 : Nat
obs35 = add 1000 0
obs36 : Nat
obs36 = add 1000 1
obs37 : Nat
obs37 = add 1000 2
obs38 : Nat
obs38 = add 1000 7
obs39 : Nat
obs39 = add 1000 31
obs40 : Nat
obs40 = add 1000 1000
obs41 : Nat
obs41 = add 1000 1000000000000
obs42 : Nat
obs42 = add 1000000000000 0
obs43 : Nat
obs43 = add 1000000000000 1
obs44 : Nat
obs44 = add 1000000000000 2
obs45 : Nat
obs45 = add 1000000000000 7
obs46 : Nat
obs46 = add 1000000000000 31
obs47 : Nat
obs47 = add 1000000000000 1000
obs48 : Nat
obs48 = add 1000000000000 1000000000000
obs49 : Nat
obs49 = subtract 0 0
obs50 : Nat
obs50 = subtract 0 1
obs51 : Nat
obs51 = subtract 0 2
obs52 : Nat
obs52 = subtract 0 7
obs53 : Nat
obs53 = subtract 0 31
obs54 : Nat
obs54 = subtract 0 1000
obs55 : Nat
obs55 = subtract 0 1000000000000
obs56 : Nat
obs56 = subtract 1 0
obs57 : Nat
obs57 = subtract 1 1
obs58 : Nat
obs58 = subtract 1 2
obs59 : Nat
obs59 = subtract 1 7
obs60 : Nat
obs60 = subtract 1 31
obs61 : Nat
obs61 = subtract 1 1000
obs62 : Nat
obs62 = subtract 1 1000000000000
obs63 : Nat
obs63 = subtract 2 0
obs64 : Nat
obs64 = subtract 2 1
obs65 : Nat
obs65 = subtract 2 2
obs66 : Nat
obs66 = subtract 2 7
obs67 : Nat
obs67 = subtract 2 31
obs68 : Nat
obs68 = subtract 2 1000
obs69 : Nat
obs69 = subtract 2 1000000000000
obs70 : Nat
obs70 = subtract 7 0
obs71 : Nat
obs71 = subtract 7 1
obs72 : Nat
obs72 = subtract 7 2
obs73 : Nat
obs73 = subtract 7 7
obs74 : Nat
obs74 = subtract 7 31
obs75 : Nat
obs75 = subtract 7 1000
obs76 : Nat
obs76 = subtract 7 1000000000000
obs77 : Nat
obs77 = subtract 31 0
obs78 : Nat
obs78 = subtract 31 1
obs79 : Nat
obs79 = subtract 31 2
obs80 : Nat
obs80 = subtract 31 7
obs81 : Nat
obs81 = subtract 31 31
obs82 : Nat
obs82 = subtract 31 1000
obs83 : Nat
obs83 = subtract 31 1000000000000
obs84 : Nat
obs84 = subtract 1000 0
obs85 : Nat
obs85 = subtract 1000 1
obs86 : Nat
obs86 = subtract 1000 2
obs87 : Nat
obs87 = subtract 1000 7
obs88 : Nat
obs88 = subtract 1000 31
obs89 : Nat
obs89 = subtract 1000 1000
obs90 : Nat
obs90 = subtract 1000 1000000000000
obs91 : Nat
obs91 = subtract 1000000000000 0
obs92 : Nat
obs92 = subtract 1000000000000 1
obs93 : Nat
obs93 = subtract 1000000000000 2
obs94 : Nat
obs94 = subtract 1000000000000 7
obs95 : Nat
obs95 = subtract 1000000000000 31
obs96 : Nat
obs96 = subtract 1000000000000 1000
obs97 : Nat
obs97 = subtract 1000000000000 1000000000000
obs98 : Nat
obs98 = multiply 0 0
obs99 : Nat
obs99 = multiply 0 1
obs100 : Nat
obs100 = multiply 0 2
obs101 : Nat
obs101 = multiply 0 7
obs102 : Nat
obs102 = multiply 0 31
obs103 : Nat
obs103 = multiply 0 1000
obs104 : Nat
obs104 = multiply 0 1000000000000
obs105 : Nat
obs105 = multiply 1 0
obs106 : Nat
obs106 = multiply 1 1
obs107 : Nat
obs107 = multiply 1 2
obs108 : Nat
obs108 = multiply 1 7
obs109 : Nat
obs109 = multiply 1 31
obs110 : Nat
obs110 = multiply 1 1000
obs111 : Nat
obs111 = multiply 1 1000000000000
obs112 : Nat
obs112 = multiply 2 0
obs113 : Nat
obs113 = multiply 2 1
obs114 : Nat
obs114 = multiply 2 2
obs115 : Nat
obs115 = multiply 2 7
obs116 : Nat
obs116 = multiply 2 31
obs117 : Nat
obs117 = multiply 2 1000
obs118 : Nat
obs118 = multiply 2 1000000000000
obs119 : Nat
obs119 = multiply 7 0
obs120 : Nat
obs120 = multiply 7 1
obs121 : Nat
obs121 = multiply 7 2
obs122 : Nat
obs122 = multiply 7 7
obs123 : Nat
obs123 = multiply 7 31
obs124 : Nat
obs124 = multiply 7 1000
obs125 : Nat
obs125 = multiply 7 1000000000000
obs126 : Nat
obs126 = multiply 31 0
obs127 : Nat
obs127 = multiply 31 1
obs128 : Nat
obs128 = multiply 31 2
obs129 : Nat
obs129 = multiply 31 7
obs130 : Nat
obs130 = multiply 31 31
obs131 : Nat
obs131 = multiply 31 1000
obs132 : Nat
obs132 = multiply 31 1000000000000
obs133 : Nat
obs133 = multiply 1000 0
obs134 : Nat
obs134 = multiply 1000 1
obs135 : Nat
obs135 = multiply 1000 2
obs136 : Nat
obs136 = multiply 1000 7
obs137 : Nat
obs137 = multiply 1000 31
obs138 : Nat
obs138 = multiply 1000 1000
obs139 : Nat
obs139 = multiply 1000 1000000000000
obs140 : Nat
obs140 = multiply 1000000000000 0
obs141 : Nat
obs141 = multiply 1000000000000 1
obs142 : Nat
obs142 = multiply 1000000000000 2
obs143 : Nat
obs143 = multiply 1000000000000 7
obs144 : Nat
obs144 = multiply 1000000000000 31
obs145 : Nat
obs145 = multiply 1000000000000 1000
obs146 : Nat
obs146 = multiply 1000000000000 1000000000000
obs147 : Nat
obs147 = precedence 0 0 0
obs148 : Nat
obs148 = precedence 0 0 1
obs149 : Nat
obs149 = precedence 0 0 2
obs150 : Nat
obs150 = precedence 0 0 7
obs151 : Nat
obs151 = precedence 0 0 31
obs152 : Nat
obs152 = precedence 0 0 1000
obs153 : Nat
obs153 = precedence 0 0 1000000000000
obs154 : Nat
obs154 = precedence 0 1 0
obs155 : Nat
obs155 = precedence 0 1 1
obs156 : Nat
obs156 = precedence 0 1 2
obs157 : Nat
obs157 = precedence 0 1 7
obs158 : Nat
obs158 = precedence 0 1 31
obs159 : Nat
obs159 = precedence 0 1 1000
obs160 : Nat
obs160 = precedence 0 1 1000000000000
obs161 : Nat
obs161 = precedence 0 2 0
obs162 : Nat
obs162 = precedence 0 2 1
obs163 : Nat
obs163 = precedence 0 2 2
obs164 : Nat
obs164 = precedence 0 2 7
obs165 : Nat
obs165 = precedence 0 2 31
obs166 : Nat
obs166 = precedence 0 2 1000
obs167 : Nat
obs167 = precedence 0 2 1000000000000
obs168 : Nat
obs168 = precedence 0 7 0
obs169 : Nat
obs169 = precedence 0 7 1
obs170 : Nat
obs170 = precedence 0 7 2
obs171 : Nat
obs171 = precedence 0 7 7
obs172 : Nat
obs172 = precedence 0 7 31
obs173 : Nat
obs173 = precedence 0 7 1000
obs174 : Nat
obs174 = precedence 0 7 1000000000000
obs175 : Nat
obs175 = precedence 0 31 0
obs176 : Nat
obs176 = precedence 0 31 1
obs177 : Nat
obs177 = precedence 0 31 2
obs178 : Nat
obs178 = precedence 0 31 7
obs179 : Nat
obs179 = precedence 0 31 31
obs180 : Nat
obs180 = precedence 0 31 1000
obs181 : Nat
obs181 = precedence 0 31 1000000000000
obs182 : Nat
obs182 = precedence 0 1000 0
obs183 : Nat
obs183 = precedence 0 1000 1
obs184 : Nat
obs184 = precedence 0 1000 2
obs185 : Nat
obs185 = precedence 0 1000 7
obs186 : Nat
obs186 = precedence 0 1000 31
obs187 : Nat
obs187 = precedence 0 1000 1000
obs188 : Nat
obs188 = precedence 0 1000 1000000000000
obs189 : Nat
obs189 = precedence 0 1000000000000 0
obs190 : Nat
obs190 = precedence 0 1000000000000 1
obs191 : Nat
obs191 = precedence 0 1000000000000 2
obs192 : Nat
obs192 = precedence 0 1000000000000 7
obs193 : Nat
obs193 = precedence 0 1000000000000 31
obs194 : Nat
obs194 = precedence 0 1000000000000 1000
obs195 : Nat
obs195 = precedence 0 1000000000000 1000000000000
obs196 : Nat
obs196 = precedence 1 0 0
obs197 : Nat
obs197 = precedence 1 0 1
obs198 : Nat
obs198 = precedence 1 0 2
obs199 : Nat
obs199 = precedence 1 0 7
obs200 : Nat
obs200 = precedence 1 0 31
obs201 : Nat
obs201 = precedence 1 0 1000
obs202 : Nat
obs202 = precedence 1 0 1000000000000
obs203 : Nat
obs203 = precedence 1 1 0
obs204 : Nat
obs204 = precedence 1 1 1
obs205 : Nat
obs205 = precedence 1 1 2
obs206 : Nat
obs206 = precedence 1 1 7
obs207 : Nat
obs207 = precedence 1 1 31
obs208 : Nat
obs208 = precedence 1 1 1000
obs209 : Nat
obs209 = precedence 1 1 1000000000000
obs210 : Nat
obs210 = precedence 1 2 0
obs211 : Nat
obs211 = precedence 1 2 1
obs212 : Nat
obs212 = precedence 1 2 2
obs213 : Nat
obs213 = precedence 1 2 7
obs214 : Nat
obs214 = precedence 1 2 31
obs215 : Nat
obs215 = precedence 1 2 1000
obs216 : Nat
obs216 = precedence 1 2 1000000000000
obs217 : Nat
obs217 = precedence 1 7 0
obs218 : Nat
obs218 = precedence 1 7 1
obs219 : Nat
obs219 = precedence 1 7 2
obs220 : Nat
obs220 = precedence 1 7 7
obs221 : Nat
obs221 = precedence 1 7 31
obs222 : Nat
obs222 = precedence 1 7 1000
obs223 : Nat
obs223 = precedence 1 7 1000000000000
obs224 : Nat
obs224 = precedence 1 31 0
obs225 : Nat
obs225 = precedence 1 31 1
obs226 : Nat
obs226 = precedence 1 31 2
obs227 : Nat
obs227 = precedence 1 31 7
obs228 : Nat
obs228 = precedence 1 31 31
obs229 : Nat
obs229 = precedence 1 31 1000
obs230 : Nat
obs230 = precedence 1 31 1000000000000
obs231 : Nat
obs231 = precedence 1 1000 0
obs232 : Nat
obs232 = precedence 1 1000 1
obs233 : Nat
obs233 = precedence 1 1000 2
obs234 : Nat
obs234 = precedence 1 1000 7
obs235 : Nat
obs235 = precedence 1 1000 31
obs236 : Nat
obs236 = precedence 1 1000 1000
obs237 : Nat
obs237 = precedence 1 1000 1000000000000
obs238 : Nat
obs238 = precedence 1 1000000000000 0
obs239 : Nat
obs239 = precedence 1 1000000000000 1
obs240 : Nat
obs240 = precedence 1 1000000000000 2
obs241 : Nat
obs241 = precedence 1 1000000000000 7
obs242 : Nat
obs242 = precedence 1 1000000000000 31
obs243 : Nat
obs243 = precedence 1 1000000000000 1000
obs244 : Nat
obs244 = precedence 1 1000000000000 1000000000000
obs245 : Nat
obs245 = precedence 2 0 0
obs246 : Nat
obs246 = precedence 2 0 1
obs247 : Nat
obs247 = precedence 2 0 2
obs248 : Nat
obs248 = precedence 2 0 7
obs249 : Nat
obs249 = precedence 2 0 31
obs250 : Nat
obs250 = precedence 2 0 1000
obs251 : Nat
obs251 = precedence 2 0 1000000000000
obs252 : Nat
obs252 = precedence 2 1 0
obs253 : Nat
obs253 = precedence 2 1 1
obs254 : Nat
obs254 = precedence 2 1 2
obs255 : Nat
obs255 = precedence 2 1 7
obs256 : Nat
obs256 = precedence 2 1 31
obs257 : Nat
obs257 = precedence 2 1 1000
obs258 : Nat
obs258 = precedence 2 1 1000000000000
obs259 : Nat
obs259 = precedence 2 2 0
obs260 : Nat
obs260 = precedence 2 2 1
obs261 : Nat
obs261 = precedence 2 2 2
obs262 : Nat
obs262 = precedence 2 2 7
obs263 : Nat
obs263 = precedence 2 2 31
obs264 : Nat
obs264 = precedence 2 2 1000
obs265 : Nat
obs265 = precedence 2 2 1000000000000
obs266 : Nat
obs266 = precedence 2 7 0
obs267 : Nat
obs267 = precedence 2 7 1
obs268 : Nat
obs268 = precedence 2 7 2
obs269 : Nat
obs269 = precedence 2 7 7
obs270 : Nat
obs270 = precedence 2 7 31
obs271 : Nat
obs271 = precedence 2 7 1000
obs272 : Nat
obs272 = precedence 2 7 1000000000000
obs273 : Nat
obs273 = precedence 2 31 0
obs274 : Nat
obs274 = precedence 2 31 1
obs275 : Nat
obs275 = precedence 2 31 2
obs276 : Nat
obs276 = precedence 2 31 7
obs277 : Nat
obs277 = precedence 2 31 31
obs278 : Nat
obs278 = precedence 2 31 1000
obs279 : Nat
obs279 = precedence 2 31 1000000000000
obs280 : Nat
obs280 = precedence 2 1000 0
obs281 : Nat
obs281 = precedence 2 1000 1
obs282 : Nat
obs282 = precedence 2 1000 2
obs283 : Nat
obs283 = precedence 2 1000 7
obs284 : Nat
obs284 = precedence 2 1000 31
obs285 : Nat
obs285 = precedence 2 1000 1000
obs286 : Nat
obs286 = precedence 2 1000 1000000000000
obs287 : Nat
obs287 = precedence 2 1000000000000 0
obs288 : Nat
obs288 = precedence 2 1000000000000 1
obs289 : Nat
obs289 = precedence 2 1000000000000 2
obs290 : Nat
obs290 = precedence 2 1000000000000 7
obs291 : Nat
obs291 = precedence 2 1000000000000 31
obs292 : Nat
obs292 = precedence 2 1000000000000 1000
obs293 : Nat
obs293 = precedence 2 1000000000000 1000000000000
obs294 : Nat
obs294 = precedence 7 0 0
obs295 : Nat
obs295 = precedence 7 0 1
obs296 : Nat
obs296 = precedence 7 0 2
obs297 : Nat
obs297 = precedence 7 0 7
obs298 : Nat
obs298 = precedence 7 0 31
obs299 : Nat
obs299 = precedence 7 0 1000
obs300 : Nat
obs300 = precedence 7 0 1000000000000
obs301 : Nat
obs301 = precedence 7 1 0
obs302 : Nat
obs302 = precedence 7 1 1
obs303 : Nat
obs303 = precedence 7 1 2
obs304 : Nat
obs304 = precedence 7 1 7
obs305 : Nat
obs305 = precedence 7 1 31
obs306 : Nat
obs306 = precedence 7 1 1000
obs307 : Nat
obs307 = precedence 7 1 1000000000000
obs308 : Nat
obs308 = precedence 7 2 0
obs309 : Nat
obs309 = precedence 7 2 1
obs310 : Nat
obs310 = precedence 7 2 2
obs311 : Nat
obs311 = precedence 7 2 7
obs312 : Nat
obs312 = precedence 7 2 31
obs313 : Nat
obs313 = precedence 7 2 1000
obs314 : Nat
obs314 = precedence 7 2 1000000000000
obs315 : Nat
obs315 = precedence 7 7 0
obs316 : Nat
obs316 = precedence 7 7 1
obs317 : Nat
obs317 = precedence 7 7 2
obs318 : Nat
obs318 = precedence 7 7 7
obs319 : Nat
obs319 = precedence 7 7 31
obs320 : Nat
obs320 = precedence 7 7 1000
obs321 : Nat
obs321 = precedence 7 7 1000000000000
obs322 : Nat
obs322 = precedence 7 31 0
obs323 : Nat
obs323 = precedence 7 31 1
obs324 : Nat
obs324 = precedence 7 31 2
obs325 : Nat
obs325 = precedence 7 31 7
obs326 : Nat
obs326 = precedence 7 31 31
obs327 : Nat
obs327 = precedence 7 31 1000
obs328 : Nat
obs328 = precedence 7 31 1000000000000
obs329 : Nat
obs329 = precedence 7 1000 0
obs330 : Nat
obs330 = precedence 7 1000 1
obs331 : Nat
obs331 = precedence 7 1000 2
obs332 : Nat
obs332 = precedence 7 1000 7
obs333 : Nat
obs333 = precedence 7 1000 31
obs334 : Nat
obs334 = precedence 7 1000 1000
obs335 : Nat
obs335 = precedence 7 1000 1000000000000
obs336 : Nat
obs336 = precedence 7 1000000000000 0
obs337 : Nat
obs337 = precedence 7 1000000000000 1
obs338 : Nat
obs338 = precedence 7 1000000000000 2
obs339 : Nat
obs339 = precedence 7 1000000000000 7
obs340 : Nat
obs340 = precedence 7 1000000000000 31
obs341 : Nat
obs341 = precedence 7 1000000000000 1000
obs342 : Nat
obs342 = precedence 7 1000000000000 1000000000000
obs343 : Nat
obs343 = precedence 31 0 0
obs344 : Nat
obs344 = precedence 31 0 1
obs345 : Nat
obs345 = precedence 31 0 2
obs346 : Nat
obs346 = precedence 31 0 7
obs347 : Nat
obs347 = precedence 31 0 31
obs348 : Nat
obs348 = precedence 31 0 1000
obs349 : Nat
obs349 = precedence 31 0 1000000000000
obs350 : Nat
obs350 = precedence 31 1 0
obs351 : Nat
obs351 = precedence 31 1 1
obs352 : Nat
obs352 = precedence 31 1 2
obs353 : Nat
obs353 = precedence 31 1 7
obs354 : Nat
obs354 = precedence 31 1 31
obs355 : Nat
obs355 = precedence 31 1 1000
obs356 : Nat
obs356 = precedence 31 1 1000000000000
obs357 : Nat
obs357 = precedence 31 2 0
obs358 : Nat
obs358 = precedence 31 2 1
obs359 : Nat
obs359 = precedence 31 2 2
obs360 : Nat
obs360 = precedence 31 2 7
obs361 : Nat
obs361 = precedence 31 2 31
obs362 : Nat
obs362 = precedence 31 2 1000
obs363 : Nat
obs363 = precedence 31 2 1000000000000
obs364 : Nat
obs364 = precedence 31 7 0
obs365 : Nat
obs365 = precedence 31 7 1
obs366 : Nat
obs366 = precedence 31 7 2
obs367 : Nat
obs367 = precedence 31 7 7
obs368 : Nat
obs368 = precedence 31 7 31
obs369 : Nat
obs369 = precedence 31 7 1000
obs370 : Nat
obs370 = precedence 31 7 1000000000000
obs371 : Nat
obs371 = precedence 31 31 0
obs372 : Nat
obs372 = precedence 31 31 1
obs373 : Nat
obs373 = precedence 31 31 2
obs374 : Nat
obs374 = precedence 31 31 7
obs375 : Nat
obs375 = precedence 31 31 31
obs376 : Nat
obs376 = precedence 31 31 1000
obs377 : Nat
obs377 = precedence 31 31 1000000000000
obs378 : Nat
obs378 = precedence 31 1000 0
obs379 : Nat
obs379 = precedence 31 1000 1
obs380 : Nat
obs380 = precedence 31 1000 2
obs381 : Nat
obs381 = precedence 31 1000 7
obs382 : Nat
obs382 = precedence 31 1000 31
obs383 : Nat
obs383 = precedence 31 1000 1000
obs384 : Nat
obs384 = precedence 31 1000 1000000000000
obs385 : Nat
obs385 = precedence 31 1000000000000 0
obs386 : Nat
obs386 = precedence 31 1000000000000 1
obs387 : Nat
obs387 = precedence 31 1000000000000 2
obs388 : Nat
obs388 = precedence 31 1000000000000 7
obs389 : Nat
obs389 = precedence 31 1000000000000 31
obs390 : Nat
obs390 = precedence 31 1000000000000 1000
obs391 : Nat
obs391 = precedence 31 1000000000000 1000000000000
obs392 : Nat
obs392 = precedence 1000 0 0
obs393 : Nat
obs393 = precedence 1000 0 1
obs394 : Nat
obs394 = precedence 1000 0 2
obs395 : Nat
obs395 = precedence 1000 0 7
obs396 : Nat
obs396 = precedence 1000 0 31
obs397 : Nat
obs397 = precedence 1000 0 1000
obs398 : Nat
obs398 = precedence 1000 0 1000000000000
obs399 : Nat
obs399 = precedence 1000 1 0
obs400 : Nat
obs400 = precedence 1000 1 1
obs401 : Nat
obs401 = precedence 1000 1 2
obs402 : Nat
obs402 = precedence 1000 1 7
obs403 : Nat
obs403 = precedence 1000 1 31
obs404 : Nat
obs404 = precedence 1000 1 1000
obs405 : Nat
obs405 = precedence 1000 1 1000000000000
obs406 : Nat
obs406 = precedence 1000 2 0
obs407 : Nat
obs407 = precedence 1000 2 1
obs408 : Nat
obs408 = precedence 1000 2 2
obs409 : Nat
obs409 = precedence 1000 2 7
obs410 : Nat
obs410 = precedence 1000 2 31
obs411 : Nat
obs411 = precedence 1000 2 1000
obs412 : Nat
obs412 = precedence 1000 2 1000000000000
obs413 : Nat
obs413 = precedence 1000 7 0
obs414 : Nat
obs414 = precedence 1000 7 1
obs415 : Nat
obs415 = precedence 1000 7 2
obs416 : Nat
obs416 = precedence 1000 7 7
obs417 : Nat
obs417 = precedence 1000 7 31
obs418 : Nat
obs418 = precedence 1000 7 1000
obs419 : Nat
obs419 = precedence 1000 7 1000000000000
obs420 : Nat
obs420 = precedence 1000 31 0
obs421 : Nat
obs421 = precedence 1000 31 1
obs422 : Nat
obs422 = precedence 1000 31 2
obs423 : Nat
obs423 = precedence 1000 31 7
obs424 : Nat
obs424 = precedence 1000 31 31
obs425 : Nat
obs425 = precedence 1000 31 1000
obs426 : Nat
obs426 = precedence 1000 31 1000000000000
obs427 : Nat
obs427 = precedence 1000 1000 0
obs428 : Nat
obs428 = precedence 1000 1000 1
obs429 : Nat
obs429 = precedence 1000 1000 2
obs430 : Nat
obs430 = precedence 1000 1000 7
obs431 : Nat
obs431 = precedence 1000 1000 31
obs432 : Nat
obs432 = precedence 1000 1000 1000
obs433 : Nat
obs433 = precedence 1000 1000 1000000000000
obs434 : Nat
obs434 = precedence 1000 1000000000000 0
obs435 : Nat
obs435 = precedence 1000 1000000000000 1
obs436 : Nat
obs436 = precedence 1000 1000000000000 2
obs437 : Nat
obs437 = precedence 1000 1000000000000 7
obs438 : Nat
obs438 = precedence 1000 1000000000000 31
obs439 : Nat
obs439 = precedence 1000 1000000000000 1000
obs440 : Nat
obs440 = precedence 1000 1000000000000 1000000000000
obs441 : Nat
obs441 = precedence 1000000000000 0 0
obs442 : Nat
obs442 = precedence 1000000000000 0 1
obs443 : Nat
obs443 = precedence 1000000000000 0 2
obs444 : Nat
obs444 = precedence 1000000000000 0 7
obs445 : Nat
obs445 = precedence 1000000000000 0 31
obs446 : Nat
obs446 = precedence 1000000000000 0 1000
obs447 : Nat
obs447 = precedence 1000000000000 0 1000000000000
obs448 : Nat
obs448 = precedence 1000000000000 1 0
obs449 : Nat
obs449 = precedence 1000000000000 1 1
obs450 : Nat
obs450 = precedence 1000000000000 1 2
obs451 : Nat
obs451 = precedence 1000000000000 1 7
obs452 : Nat
obs452 = precedence 1000000000000 1 31
obs453 : Nat
obs453 = precedence 1000000000000 1 1000
obs454 : Nat
obs454 = precedence 1000000000000 1 1000000000000
obs455 : Nat
obs455 = precedence 1000000000000 2 0
obs456 : Nat
obs456 = precedence 1000000000000 2 1
obs457 : Nat
obs457 = precedence 1000000000000 2 2
obs458 : Nat
obs458 = precedence 1000000000000 2 7
obs459 : Nat
obs459 = precedence 1000000000000 2 31
obs460 : Nat
obs460 = precedence 1000000000000 2 1000
obs461 : Nat
obs461 = precedence 1000000000000 2 1000000000000
obs462 : Nat
obs462 = precedence 1000000000000 7 0
obs463 : Nat
obs463 = precedence 1000000000000 7 1
obs464 : Nat
obs464 = precedence 1000000000000 7 2
obs465 : Nat
obs465 = precedence 1000000000000 7 7
obs466 : Nat
obs466 = precedence 1000000000000 7 31
obs467 : Nat
obs467 = precedence 1000000000000 7 1000
obs468 : Nat
obs468 = precedence 1000000000000 7 1000000000000
obs469 : Nat
obs469 = precedence 1000000000000 31 0
obs470 : Nat
obs470 = precedence 1000000000000 31 1
obs471 : Nat
obs471 = precedence 1000000000000 31 2
obs472 : Nat
obs472 = precedence 1000000000000 31 7
obs473 : Nat
obs473 = precedence 1000000000000 31 31
obs474 : Nat
obs474 = precedence 1000000000000 31 1000
obs475 : Nat
obs475 = precedence 1000000000000 31 1000000000000
obs476 : Nat
obs476 = precedence 1000000000000 1000 0
obs477 : Nat
obs477 = precedence 1000000000000 1000 1
obs478 : Nat
obs478 = precedence 1000000000000 1000 2
obs479 : Nat
obs479 = precedence 1000000000000 1000 7
obs480 : Nat
obs480 = precedence 1000000000000 1000 31
obs481 : Nat
obs481 = precedence 1000000000000 1000 1000
obs482 : Nat
obs482 = precedence 1000000000000 1000 1000000000000
obs483 : Nat
obs483 = precedence 1000000000000 1000000000000 0
obs484 : Nat
obs484 = precedence 1000000000000 1000000000000 1
obs485 : Nat
obs485 = precedence 1000000000000 1000000000000 2
obs486 : Nat
obs486 = precedence 1000000000000 1000000000000 7
obs487 : Nat
obs487 = precedence 1000000000000 1000000000000 31
obs488 : Nat
obs488 = precedence 1000000000000 1000000000000 1000
obs489 : Nat
obs489 = precedence 1000000000000 1000000000000 1000000000000
obs490 : Nat
obs490 = grouping 0 0 0
obs491 : Nat
obs491 = grouping 0 0 1
obs492 : Nat
obs492 = grouping 0 0 2
obs493 : Nat
obs493 = grouping 0 0 7
obs494 : Nat
obs494 = grouping 0 0 31
obs495 : Nat
obs495 = grouping 0 0 1000
obs496 : Nat
obs496 = grouping 0 0 1000000000000
obs497 : Nat
obs497 = grouping 0 1 0
obs498 : Nat
obs498 = grouping 0 1 1
obs499 : Nat
obs499 = grouping 0 1 2
obs500 : Nat
obs500 = grouping 0 1 7
obs501 : Nat
obs501 = grouping 0 1 31
obs502 : Nat
obs502 = grouping 0 1 1000
obs503 : Nat
obs503 = grouping 0 1 1000000000000
obs504 : Nat
obs504 = grouping 0 2 0
obs505 : Nat
obs505 = grouping 0 2 1
obs506 : Nat
obs506 = grouping 0 2 2
obs507 : Nat
obs507 = grouping 0 2 7
obs508 : Nat
obs508 = grouping 0 2 31
obs509 : Nat
obs509 = grouping 0 2 1000
obs510 : Nat
obs510 = grouping 0 2 1000000000000
obs511 : Nat
obs511 = grouping 0 7 0
obs512 : Nat
obs512 = grouping 0 7 1
obs513 : Nat
obs513 = grouping 0 7 2
obs514 : Nat
obs514 = grouping 0 7 7
obs515 : Nat
obs515 = grouping 0 7 31
obs516 : Nat
obs516 = grouping 0 7 1000
obs517 : Nat
obs517 = grouping 0 7 1000000000000
obs518 : Nat
obs518 = grouping 0 31 0
obs519 : Nat
obs519 = grouping 0 31 1
obs520 : Nat
obs520 = grouping 0 31 2
obs521 : Nat
obs521 = grouping 0 31 7
obs522 : Nat
obs522 = grouping 0 31 31
obs523 : Nat
obs523 = grouping 0 31 1000
obs524 : Nat
obs524 = grouping 0 31 1000000000000
obs525 : Nat
obs525 = grouping 0 1000 0
obs526 : Nat
obs526 = grouping 0 1000 1
obs527 : Nat
obs527 = grouping 0 1000 2
obs528 : Nat
obs528 = grouping 0 1000 7
obs529 : Nat
obs529 = grouping 0 1000 31
obs530 : Nat
obs530 = grouping 0 1000 1000
obs531 : Nat
obs531 = grouping 0 1000 1000000000000
obs532 : Nat
obs532 = grouping 0 1000000000000 0
obs533 : Nat
obs533 = grouping 0 1000000000000 1
obs534 : Nat
obs534 = grouping 0 1000000000000 2
obs535 : Nat
obs535 = grouping 0 1000000000000 7
obs536 : Nat
obs536 = grouping 0 1000000000000 31
obs537 : Nat
obs537 = grouping 0 1000000000000 1000
obs538 : Nat
obs538 = grouping 0 1000000000000 1000000000000
obs539 : Nat
obs539 = grouping 1 0 0
obs540 : Nat
obs540 = grouping 1 0 1
obs541 : Nat
obs541 = grouping 1 0 2
obs542 : Nat
obs542 = grouping 1 0 7
obs543 : Nat
obs543 = grouping 1 0 31
obs544 : Nat
obs544 = grouping 1 0 1000
obs545 : Nat
obs545 = grouping 1 0 1000000000000
obs546 : Nat
obs546 = grouping 1 1 0
obs547 : Nat
obs547 = grouping 1 1 1
obs548 : Nat
obs548 = grouping 1 1 2
obs549 : Nat
obs549 = grouping 1 1 7
obs550 : Nat
obs550 = grouping 1 1 31
obs551 : Nat
obs551 = grouping 1 1 1000
obs552 : Nat
obs552 = grouping 1 1 1000000000000
obs553 : Nat
obs553 = grouping 1 2 0
obs554 : Nat
obs554 = grouping 1 2 1
obs555 : Nat
obs555 = grouping 1 2 2
obs556 : Nat
obs556 = grouping 1 2 7
obs557 : Nat
obs557 = grouping 1 2 31
obs558 : Nat
obs558 = grouping 1 2 1000
obs559 : Nat
obs559 = grouping 1 2 1000000000000
obs560 : Nat
obs560 = grouping 1 7 0
obs561 : Nat
obs561 = grouping 1 7 1
obs562 : Nat
obs562 = grouping 1 7 2
obs563 : Nat
obs563 = grouping 1 7 7
obs564 : Nat
obs564 = grouping 1 7 31
obs565 : Nat
obs565 = grouping 1 7 1000
obs566 : Nat
obs566 = grouping 1 7 1000000000000
obs567 : Nat
obs567 = grouping 1 31 0
obs568 : Nat
obs568 = grouping 1 31 1
obs569 : Nat
obs569 = grouping 1 31 2
obs570 : Nat
obs570 = grouping 1 31 7
obs571 : Nat
obs571 = grouping 1 31 31
obs572 : Nat
obs572 = grouping 1 31 1000
obs573 : Nat
obs573 = grouping 1 31 1000000000000
obs574 : Nat
obs574 = grouping 1 1000 0
obs575 : Nat
obs575 = grouping 1 1000 1
obs576 : Nat
obs576 = grouping 1 1000 2
obs577 : Nat
obs577 = grouping 1 1000 7
obs578 : Nat
obs578 = grouping 1 1000 31
obs579 : Nat
obs579 = grouping 1 1000 1000
obs580 : Nat
obs580 = grouping 1 1000 1000000000000
obs581 : Nat
obs581 = grouping 1 1000000000000 0
obs582 : Nat
obs582 = grouping 1 1000000000000 1
obs583 : Nat
obs583 = grouping 1 1000000000000 2
obs584 : Nat
obs584 = grouping 1 1000000000000 7
obs585 : Nat
obs585 = grouping 1 1000000000000 31
obs586 : Nat
obs586 = grouping 1 1000000000000 1000
obs587 : Nat
obs587 = grouping 1 1000000000000 1000000000000
obs588 : Nat
obs588 = grouping 2 0 0
obs589 : Nat
obs589 = grouping 2 0 1
obs590 : Nat
obs590 = grouping 2 0 2
obs591 : Nat
obs591 = grouping 2 0 7
obs592 : Nat
obs592 = grouping 2 0 31
obs593 : Nat
obs593 = grouping 2 0 1000
obs594 : Nat
obs594 = grouping 2 0 1000000000000
obs595 : Nat
obs595 = grouping 2 1 0
obs596 : Nat
obs596 = grouping 2 1 1
obs597 : Nat
obs597 = grouping 2 1 2
obs598 : Nat
obs598 = grouping 2 1 7
obs599 : Nat
obs599 = grouping 2 1 31
obs600 : Nat
obs600 = grouping 2 1 1000
obs601 : Nat
obs601 = grouping 2 1 1000000000000
obs602 : Nat
obs602 = grouping 2 2 0
obs603 : Nat
obs603 = grouping 2 2 1
obs604 : Nat
obs604 = grouping 2 2 2
obs605 : Nat
obs605 = grouping 2 2 7
obs606 : Nat
obs606 = grouping 2 2 31
obs607 : Nat
obs607 = grouping 2 2 1000
obs608 : Nat
obs608 = grouping 2 2 1000000000000
obs609 : Nat
obs609 = grouping 2 7 0
obs610 : Nat
obs610 = grouping 2 7 1
obs611 : Nat
obs611 = grouping 2 7 2
obs612 : Nat
obs612 = grouping 2 7 7
obs613 : Nat
obs613 = grouping 2 7 31
obs614 : Nat
obs614 = grouping 2 7 1000
obs615 : Nat
obs615 = grouping 2 7 1000000000000
obs616 : Nat
obs616 = grouping 2 31 0
obs617 : Nat
obs617 = grouping 2 31 1
obs618 : Nat
obs618 = grouping 2 31 2
obs619 : Nat
obs619 = grouping 2 31 7
obs620 : Nat
obs620 = grouping 2 31 31
obs621 : Nat
obs621 = grouping 2 31 1000
obs622 : Nat
obs622 = grouping 2 31 1000000000000
obs623 : Nat
obs623 = grouping 2 1000 0
obs624 : Nat
obs624 = grouping 2 1000 1
obs625 : Nat
obs625 = grouping 2 1000 2
obs626 : Nat
obs626 = grouping 2 1000 7
obs627 : Nat
obs627 = grouping 2 1000 31
obs628 : Nat
obs628 = grouping 2 1000 1000
obs629 : Nat
obs629 = grouping 2 1000 1000000000000
obs630 : Nat
obs630 = grouping 2 1000000000000 0
obs631 : Nat
obs631 = grouping 2 1000000000000 1
obs632 : Nat
obs632 = grouping 2 1000000000000 2
obs633 : Nat
obs633 = grouping 2 1000000000000 7
obs634 : Nat
obs634 = grouping 2 1000000000000 31
obs635 : Nat
obs635 = grouping 2 1000000000000 1000
obs636 : Nat
obs636 = grouping 2 1000000000000 1000000000000
obs637 : Nat
obs637 = grouping 7 0 0
obs638 : Nat
obs638 = grouping 7 0 1
obs639 : Nat
obs639 = grouping 7 0 2
obs640 : Nat
obs640 = grouping 7 0 7
obs641 : Nat
obs641 = grouping 7 0 31
obs642 : Nat
obs642 = grouping 7 0 1000
obs643 : Nat
obs643 = grouping 7 0 1000000000000
obs644 : Nat
obs644 = grouping 7 1 0
obs645 : Nat
obs645 = grouping 7 1 1
obs646 : Nat
obs646 = grouping 7 1 2
obs647 : Nat
obs647 = grouping 7 1 7
obs648 : Nat
obs648 = grouping 7 1 31
obs649 : Nat
obs649 = grouping 7 1 1000
obs650 : Nat
obs650 = grouping 7 1 1000000000000
obs651 : Nat
obs651 = grouping 7 2 0
obs652 : Nat
obs652 = grouping 7 2 1
obs653 : Nat
obs653 = grouping 7 2 2
obs654 : Nat
obs654 = grouping 7 2 7
obs655 : Nat
obs655 = grouping 7 2 31
obs656 : Nat
obs656 = grouping 7 2 1000
obs657 : Nat
obs657 = grouping 7 2 1000000000000
obs658 : Nat
obs658 = grouping 7 7 0
obs659 : Nat
obs659 = grouping 7 7 1
obs660 : Nat
obs660 = grouping 7 7 2
obs661 : Nat
obs661 = grouping 7 7 7
obs662 : Nat
obs662 = grouping 7 7 31
obs663 : Nat
obs663 = grouping 7 7 1000
obs664 : Nat
obs664 = grouping 7 7 1000000000000
obs665 : Nat
obs665 = grouping 7 31 0
obs666 : Nat
obs666 = grouping 7 31 1
obs667 : Nat
obs667 = grouping 7 31 2
obs668 : Nat
obs668 = grouping 7 31 7
obs669 : Nat
obs669 = grouping 7 31 31
obs670 : Nat
obs670 = grouping 7 31 1000
obs671 : Nat
obs671 = grouping 7 31 1000000000000
obs672 : Nat
obs672 = grouping 7 1000 0
obs673 : Nat
obs673 = grouping 7 1000 1
obs674 : Nat
obs674 = grouping 7 1000 2
obs675 : Nat
obs675 = grouping 7 1000 7
obs676 : Nat
obs676 = grouping 7 1000 31
obs677 : Nat
obs677 = grouping 7 1000 1000
obs678 : Nat
obs678 = grouping 7 1000 1000000000000
obs679 : Nat
obs679 = grouping 7 1000000000000 0
obs680 : Nat
obs680 = grouping 7 1000000000000 1
obs681 : Nat
obs681 = grouping 7 1000000000000 2
obs682 : Nat
obs682 = grouping 7 1000000000000 7
obs683 : Nat
obs683 = grouping 7 1000000000000 31
obs684 : Nat
obs684 = grouping 7 1000000000000 1000
obs685 : Nat
obs685 = grouping 7 1000000000000 1000000000000
obs686 : Nat
obs686 = grouping 31 0 0
obs687 : Nat
obs687 = grouping 31 0 1
obs688 : Nat
obs688 = grouping 31 0 2
obs689 : Nat
obs689 = grouping 31 0 7
obs690 : Nat
obs690 = grouping 31 0 31
obs691 : Nat
obs691 = grouping 31 0 1000
obs692 : Nat
obs692 = grouping 31 0 1000000000000
obs693 : Nat
obs693 = grouping 31 1 0
obs694 : Nat
obs694 = grouping 31 1 1
obs695 : Nat
obs695 = grouping 31 1 2
obs696 : Nat
obs696 = grouping 31 1 7
obs697 : Nat
obs697 = grouping 31 1 31
obs698 : Nat
obs698 = grouping 31 1 1000
obs699 : Nat
obs699 = grouping 31 1 1000000000000
obs700 : Nat
obs700 = grouping 31 2 0
obs701 : Nat
obs701 = grouping 31 2 1
obs702 : Nat
obs702 = grouping 31 2 2
obs703 : Nat
obs703 = grouping 31 2 7
obs704 : Nat
obs704 = grouping 31 2 31
obs705 : Nat
obs705 = grouping 31 2 1000
obs706 : Nat
obs706 = grouping 31 2 1000000000000
obs707 : Nat
obs707 = grouping 31 7 0
obs708 : Nat
obs708 = grouping 31 7 1
obs709 : Nat
obs709 = grouping 31 7 2
obs710 : Nat
obs710 = grouping 31 7 7
obs711 : Nat
obs711 = grouping 31 7 31
obs712 : Nat
obs712 = grouping 31 7 1000
obs713 : Nat
obs713 = grouping 31 7 1000000000000
obs714 : Nat
obs714 = grouping 31 31 0
obs715 : Nat
obs715 = grouping 31 31 1
obs716 : Nat
obs716 = grouping 31 31 2
obs717 : Nat
obs717 = grouping 31 31 7
obs718 : Nat
obs718 = grouping 31 31 31
obs719 : Nat
obs719 = grouping 31 31 1000
obs720 : Nat
obs720 = grouping 31 31 1000000000000
obs721 : Nat
obs721 = grouping 31 1000 0
obs722 : Nat
obs722 = grouping 31 1000 1
obs723 : Nat
obs723 = grouping 31 1000 2
obs724 : Nat
obs724 = grouping 31 1000 7
obs725 : Nat
obs725 = grouping 31 1000 31
obs726 : Nat
obs726 = grouping 31 1000 1000
obs727 : Nat
obs727 = grouping 31 1000 1000000000000
obs728 : Nat
obs728 = grouping 31 1000000000000 0
obs729 : Nat
obs729 = grouping 31 1000000000000 1
obs730 : Nat
obs730 = grouping 31 1000000000000 2
obs731 : Nat
obs731 = grouping 31 1000000000000 7
obs732 : Nat
obs732 = grouping 31 1000000000000 31
obs733 : Nat
obs733 = grouping 31 1000000000000 1000
obs734 : Nat
obs734 = grouping 31 1000000000000 1000000000000
obs735 : Nat
obs735 = grouping 1000 0 0
obs736 : Nat
obs736 = grouping 1000 0 1
obs737 : Nat
obs737 = grouping 1000 0 2
obs738 : Nat
obs738 = grouping 1000 0 7
obs739 : Nat
obs739 = grouping 1000 0 31
obs740 : Nat
obs740 = grouping 1000 0 1000
obs741 : Nat
obs741 = grouping 1000 0 1000000000000
obs742 : Nat
obs742 = grouping 1000 1 0
obs743 : Nat
obs743 = grouping 1000 1 1
obs744 : Nat
obs744 = grouping 1000 1 2
obs745 : Nat
obs745 = grouping 1000 1 7
obs746 : Nat
obs746 = grouping 1000 1 31
obs747 : Nat
obs747 = grouping 1000 1 1000
obs748 : Nat
obs748 = grouping 1000 1 1000000000000
obs749 : Nat
obs749 = grouping 1000 2 0
obs750 : Nat
obs750 = grouping 1000 2 1
obs751 : Nat
obs751 = grouping 1000 2 2
obs752 : Nat
obs752 = grouping 1000 2 7
obs753 : Nat
obs753 = grouping 1000 2 31
obs754 : Nat
obs754 = grouping 1000 2 1000
obs755 : Nat
obs755 = grouping 1000 2 1000000000000
obs756 : Nat
obs756 = grouping 1000 7 0
obs757 : Nat
obs757 = grouping 1000 7 1
obs758 : Nat
obs758 = grouping 1000 7 2
obs759 : Nat
obs759 = grouping 1000 7 7
obs760 : Nat
obs760 = grouping 1000 7 31
obs761 : Nat
obs761 = grouping 1000 7 1000
obs762 : Nat
obs762 = grouping 1000 7 1000000000000
obs763 : Nat
obs763 = grouping 1000 31 0
obs764 : Nat
obs764 = grouping 1000 31 1
obs765 : Nat
obs765 = grouping 1000 31 2
obs766 : Nat
obs766 = grouping 1000 31 7
obs767 : Nat
obs767 = grouping 1000 31 31
obs768 : Nat
obs768 = grouping 1000 31 1000
obs769 : Nat
obs769 = grouping 1000 31 1000000000000
obs770 : Nat
obs770 = grouping 1000 1000 0
obs771 : Nat
obs771 = grouping 1000 1000 1
obs772 : Nat
obs772 = grouping 1000 1000 2
obs773 : Nat
obs773 = grouping 1000 1000 7
obs774 : Nat
obs774 = grouping 1000 1000 31
obs775 : Nat
obs775 = grouping 1000 1000 1000
obs776 : Nat
obs776 = grouping 1000 1000 1000000000000
obs777 : Nat
obs777 = grouping 1000 1000000000000 0
obs778 : Nat
obs778 = grouping 1000 1000000000000 1
obs779 : Nat
obs779 = grouping 1000 1000000000000 2
obs780 : Nat
obs780 = grouping 1000 1000000000000 7
obs781 : Nat
obs781 = grouping 1000 1000000000000 31
obs782 : Nat
obs782 = grouping 1000 1000000000000 1000
obs783 : Nat
obs783 = grouping 1000 1000000000000 1000000000000
obs784 : Nat
obs784 = grouping 1000000000000 0 0
obs785 : Nat
obs785 = grouping 1000000000000 0 1
obs786 : Nat
obs786 = grouping 1000000000000 0 2
obs787 : Nat
obs787 = grouping 1000000000000 0 7
obs788 : Nat
obs788 = grouping 1000000000000 0 31
obs789 : Nat
obs789 = grouping 1000000000000 0 1000
obs790 : Nat
obs790 = grouping 1000000000000 0 1000000000000
obs791 : Nat
obs791 = grouping 1000000000000 1 0
obs792 : Nat
obs792 = grouping 1000000000000 1 1
obs793 : Nat
obs793 = grouping 1000000000000 1 2
obs794 : Nat
obs794 = grouping 1000000000000 1 7
obs795 : Nat
obs795 = grouping 1000000000000 1 31
obs796 : Nat
obs796 = grouping 1000000000000 1 1000
obs797 : Nat
obs797 = grouping 1000000000000 1 1000000000000
obs798 : Nat
obs798 = grouping 1000000000000 2 0
obs799 : Nat
obs799 = grouping 1000000000000 2 1
obs800 : Nat
obs800 = grouping 1000000000000 2 2
obs801 : Nat
obs801 = grouping 1000000000000 2 7
obs802 : Nat
obs802 = grouping 1000000000000 2 31
obs803 : Nat
obs803 = grouping 1000000000000 2 1000
obs804 : Nat
obs804 = grouping 1000000000000 2 1000000000000
obs805 : Nat
obs805 = grouping 1000000000000 7 0
obs806 : Nat
obs806 = grouping 1000000000000 7 1
obs807 : Nat
obs807 = grouping 1000000000000 7 2
obs808 : Nat
obs808 = grouping 1000000000000 7 7
obs809 : Nat
obs809 = grouping 1000000000000 7 31
obs810 : Nat
obs810 = grouping 1000000000000 7 1000
obs811 : Nat
obs811 = grouping 1000000000000 7 1000000000000
obs812 : Nat
obs812 = grouping 1000000000000 31 0
obs813 : Nat
obs813 = grouping 1000000000000 31 1
obs814 : Nat
obs814 = grouping 1000000000000 31 2
obs815 : Nat
obs815 = grouping 1000000000000 31 7
obs816 : Nat
obs816 = grouping 1000000000000 31 31
obs817 : Nat
obs817 = grouping 1000000000000 31 1000
obs818 : Nat
obs818 = grouping 1000000000000 31 1000000000000
obs819 : Nat
obs819 = grouping 1000000000000 1000 0
obs820 : Nat
obs820 = grouping 1000000000000 1000 1
obs821 : Nat
obs821 = grouping 1000000000000 1000 2
obs822 : Nat
obs822 = grouping 1000000000000 1000 7
obs823 : Nat
obs823 = grouping 1000000000000 1000 31
obs824 : Nat
obs824 = grouping 1000000000000 1000 1000
obs825 : Nat
obs825 = grouping 1000000000000 1000 1000000000000
obs826 : Nat
obs826 = grouping 1000000000000 1000000000000 0
obs827 : Nat
obs827 = grouping 1000000000000 1000000000000 1
obs828 : Nat
obs828 = grouping 1000000000000 1000000000000 2
obs829 : Nat
obs829 = grouping 1000000000000 1000000000000 7
obs830 : Nat
obs830 = grouping 1000000000000 1000000000000 31
obs831 : Nat
obs831 = grouping 1000000000000 1000000000000 1000
obs832 : Nat
obs832 = grouping 1000000000000 1000000000000 1000000000000
obs833 : Nat
obs833 = nested 0 0
obs834 : Nat
obs834 = nested 0 1
obs835 : Nat
obs835 = nested 0 2
obs836 : Nat
obs836 = nested 0 7
obs837 : Nat
obs837 = nested 0 31
obs838 : Nat
obs838 = nested 0 1000
obs839 : Nat
obs839 = nested 0 1000000000000
obs840 : Nat
obs840 = nested 1 0
obs841 : Nat
obs841 = nested 1 1
obs842 : Nat
obs842 = nested 1 2
obs843 : Nat
obs843 = nested 1 7
obs844 : Nat
obs844 = nested 1 31
obs845 : Nat
obs845 = nested 1 1000
obs846 : Nat
obs846 = nested 1 1000000000000
obs847 : Nat
obs847 = nested 2 0
obs848 : Nat
obs848 = nested 2 1
obs849 : Nat
obs849 = nested 2 2
obs850 : Nat
obs850 = nested 2 7
obs851 : Nat
obs851 = nested 2 31
obs852 : Nat
obs852 = nested 2 1000
obs853 : Nat
obs853 = nested 2 1000000000000
obs854 : Nat
obs854 = nested 7 0
obs855 : Nat
obs855 = nested 7 1
obs856 : Nat
obs856 = nested 7 2
obs857 : Nat
obs857 = nested 7 7
obs858 : Nat
obs858 = nested 7 31
obs859 : Nat
obs859 = nested 7 1000
obs860 : Nat
obs860 = nested 7 1000000000000
obs861 : Nat
obs861 = nested 31 0
obs862 : Nat
obs862 = nested 31 1
obs863 : Nat
obs863 = nested 31 2
obs864 : Nat
obs864 = nested 31 7
obs865 : Nat
obs865 = nested 31 31
obs866 : Nat
obs866 = nested 31 1000
obs867 : Nat
obs867 = nested 31 1000000000000
obs868 : Nat
obs868 = nested 1000 0
obs869 : Nat
obs869 = nested 1000 1
obs870 : Nat
obs870 = nested 1000 2
obs871 : Nat
obs871 = nested 1000 7
obs872 : Nat
obs872 = nested 1000 31
obs873 : Nat
obs873 = nested 1000 1000
obs874 : Nat
obs874 = nested 1000 1000000000000
obs875 : Nat
obs875 = nested 1000000000000 0
obs876 : Nat
obs876 = nested 1000000000000 1
obs877 : Nat
obs877 = nested 1000000000000 2
obs878 : Nat
obs878 = nested 1000000000000 7
obs879 : Nat
obs879 = nested 1000000000000 31
obs880 : Nat
obs880 = nested 1000000000000 1000
obs881 : Nat
obs881 = nested 1000000000000 1000000000000
obs882 : Nat
obs882 = successor 0
obs883 : Nat
obs883 = successor 1
obs884 : Nat
obs884 = successor 2
obs885 : Nat
obs885 = successor 7
obs886 : Nat
obs886 = successor 31
obs887 : Nat
obs887 = successor 1000
obs888 : Nat
obs888 = successor 1000000000000
obs889 : Bool
obs889 = equal 0 0
obs890 : Bool
obs890 = equal 0 1
obs891 : Bool
obs891 = equal 0 2
obs892 : Bool
obs892 = equal 0 7
obs893 : Bool
obs893 = equal 0 31
obs894 : Bool
obs894 = equal 0 1000
obs895 : Bool
obs895 = equal 0 1000000000000
obs896 : Bool
obs896 = equal 1 0
obs897 : Bool
obs897 = equal 1 1
obs898 : Bool
obs898 = equal 1 2
obs899 : Bool
obs899 = equal 1 7
obs900 : Bool
obs900 = equal 1 31
obs901 : Bool
obs901 = equal 1 1000
obs902 : Bool
obs902 = equal 1 1000000000000
obs903 : Bool
obs903 = equal 2 0
obs904 : Bool
obs904 = equal 2 1
obs905 : Bool
obs905 = equal 2 2
obs906 : Bool
obs906 = equal 2 7
obs907 : Bool
obs907 = equal 2 31
obs908 : Bool
obs908 = equal 2 1000
obs909 : Bool
obs909 = equal 2 1000000000000
obs910 : Bool
obs910 = equal 7 0
obs911 : Bool
obs911 = equal 7 1
obs912 : Bool
obs912 = equal 7 2
obs913 : Bool
obs913 = equal 7 7
obs914 : Bool
obs914 = equal 7 31
obs915 : Bool
obs915 = equal 7 1000
obs916 : Bool
obs916 = equal 7 1000000000000
obs917 : Bool
obs917 = equal 31 0
obs918 : Bool
obs918 = equal 31 1
obs919 : Bool
obs919 = equal 31 2
obs920 : Bool
obs920 = equal 31 7
obs921 : Bool
obs921 = equal 31 31
obs922 : Bool
obs922 = equal 31 1000
obs923 : Bool
obs923 = equal 31 1000000000000
obs924 : Bool
obs924 = equal 1000 0
obs925 : Bool
obs925 = equal 1000 1
obs926 : Bool
obs926 = equal 1000 2
obs927 : Bool
obs927 = equal 1000 7
obs928 : Bool
obs928 = equal 1000 31
obs929 : Bool
obs929 = equal 1000 1000
obs930 : Bool
obs930 = equal 1000 1000000000000
obs931 : Bool
obs931 = equal 1000000000000 0
obs932 : Bool
obs932 = equal 1000000000000 1
obs933 : Bool
obs933 = equal 1000000000000 2
obs934 : Bool
obs934 = equal 1000000000000 7
obs935 : Bool
obs935 = equal 1000000000000 31
obs936 : Bool
obs936 = equal 1000000000000 1000
obs937 : Bool
obs937 = equal 1000000000000 1000000000000
obs938 : Bool
obs938 = less 0 0
obs939 : Bool
obs939 = less 0 1
obs940 : Bool
obs940 = less 0 2
obs941 : Bool
obs941 = less 0 7
obs942 : Bool
obs942 = less 0 31
obs943 : Bool
obs943 = less 0 1000
obs944 : Bool
obs944 = less 0 1000000000000
obs945 : Bool
obs945 = less 1 0
obs946 : Bool
obs946 = less 1 1
obs947 : Bool
obs947 = less 1 2
obs948 : Bool
obs948 = less 1 7
obs949 : Bool
obs949 = less 1 31
obs950 : Bool
obs950 = less 1 1000
obs951 : Bool
obs951 = less 1 1000000000000
obs952 : Bool
obs952 = less 2 0
obs953 : Bool
obs953 = less 2 1
obs954 : Bool
obs954 = less 2 2
obs955 : Bool
obs955 = less 2 7
obs956 : Bool
obs956 = less 2 31
obs957 : Bool
obs957 = less 2 1000
obs958 : Bool
obs958 = less 2 1000000000000
obs959 : Bool
obs959 = less 7 0
obs960 : Bool
obs960 = less 7 1
obs961 : Bool
obs961 = less 7 2
obs962 : Bool
obs962 = less 7 7
obs963 : Bool
obs963 = less 7 31
obs964 : Bool
obs964 = less 7 1000
obs965 : Bool
obs965 = less 7 1000000000000
obs966 : Bool
obs966 = less 31 0
obs967 : Bool
obs967 = less 31 1
obs968 : Bool
obs968 = less 31 2
obs969 : Bool
obs969 = less 31 7
obs970 : Bool
obs970 = less 31 31
obs971 : Bool
obs971 = less 31 1000
obs972 : Bool
obs972 = less 31 1000000000000
obs973 : Bool
obs973 = less 1000 0
obs974 : Bool
obs974 = less 1000 1
obs975 : Bool
obs975 = less 1000 2
obs976 : Bool
obs976 = less 1000 7
obs977 : Bool
obs977 = less 1000 31
obs978 : Bool
obs978 = less 1000 1000
obs979 : Bool
obs979 = less 1000 1000000000000
obs980 : Bool
obs980 = less 1000000000000 0
obs981 : Bool
obs981 = less 1000000000000 1
obs982 : Bool
obs982 = less 1000000000000 2
obs983 : Bool
obs983 = less 1000000000000 7
obs984 : Bool
obs984 = less 1000000000000 31
obs985 : Bool
obs985 = less 1000000000000 1000
obs986 : Bool
obs986 = less 1000000000000 1000000000000
obs987 : Bool
obs987 = identity false
obs988 : Bool
obs988 = identity true
obs989 : Bool
obs989 = preserve false 0
obs990 : Bool
obs990 = preserve false 1
obs991 : Bool
obs991 = preserve false 2
obs992 : Bool
obs992 = preserve false 7
obs993 : Bool
obs993 = preserve false 31
obs994 : Bool
obs994 = preserve false 1000
obs995 : Bool
obs995 = preserve false 1000000000000
obs996 : Bool
obs996 = preserve true 0
obs997 : Bool
obs997 = preserve true 1
obs998 : Bool
obs998 = preserve true 2
obs999 : Bool
obs999 = preserve true 7
obs1000 : Bool
obs1000 = preserve true 31
obs1001 : Bool
obs1001 = preserve true 1000
obs1002 : Bool
obs1002 = preserve true 1000000000000
obs1003 : Bool
obs1003 = dropfirst 0 false
obs1004 : Bool
obs1004 = dropfirst 0 true
obs1005 : Bool
obs1005 = dropfirst 1 false
obs1006 : Bool
obs1006 = dropfirst 1 true
obs1007 : Bool
obs1007 = dropfirst 2 false
obs1008 : Bool
obs1008 = dropfirst 2 true
obs1009 : Bool
obs1009 = dropfirst 7 false
obs1010 : Bool
obs1010 = dropfirst 7 true
obs1011 : Bool
obs1011 = dropfirst 31 false
obs1012 : Bool
obs1012 = dropfirst 31 true
obs1013 : Bool
obs1013 = dropfirst 1000 false
obs1014 : Bool
obs1014 = dropfirst 1000 true
obs1015 : Bool
obs1015 = dropfirst 1000000000000 false
obs1016 : Bool
obs1016 = dropfirst 1000000000000 true
obs1017 : Nat
obs1017 = constant
