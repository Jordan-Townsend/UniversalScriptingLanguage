; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let ((?x39 (* y 2)))
(let ((?x40 (+ (ite (<= 0 (- x y)) (- x y) 0) ?x39)))
(let ((?x43 (+ (ite (>= x y) (- x y) 0) ?x39)))
(and (distinct ?x43 ?x40) true)))))
(check-sat)
