; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (>= x 0))
(assert
 (let ((?x47 (+ (+ x 1) 1)))
(and (distinct ?x47 ?x47) true)))
(check-sat)
