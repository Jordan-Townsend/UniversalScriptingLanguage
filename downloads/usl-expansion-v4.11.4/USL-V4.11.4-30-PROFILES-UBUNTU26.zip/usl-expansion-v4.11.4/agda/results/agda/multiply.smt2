; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let ((?x38 (* x y)))
(and (distinct ?x38 ?x38) true)))
(check-sat)
