; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let ((?x29 (- x y)))
(let ((?x31 (ite (<= 0 ?x29) ?x29 0)))
(let ((?x33 (ite (>= x y) ?x29 0)))
(and (distinct ?x33 ?x31) true)))))
(check-sat)
