; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Bool)
(assert
 (>= x 0))
(assert
 (and (distinct y y) true))
(check-sat)
