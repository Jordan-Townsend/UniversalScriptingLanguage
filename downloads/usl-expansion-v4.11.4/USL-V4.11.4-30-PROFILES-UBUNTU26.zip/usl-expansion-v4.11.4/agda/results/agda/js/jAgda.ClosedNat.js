var agdaRTS = require("agda-rts");

var z_jAgda_Agda_Builtin_Bool = require("jAgda.Agda.Builtin.Bool");
var z_jAgda_Agda_Builtin_Nat = require("jAgda.Agda.Builtin.Nat");
var z_jAgda_Agda_Primitive = require("jAgda.Agda.Primitive");

exports["add"] = a => b => agdaRTS.uprimIntegerPlus(a,b);
exports["subtract"] = a => b => z_jAgda_Agda_Builtin_Nat["_-_"](a)(b);
exports["multiply"] = a => b => agdaRTS.uprimIntegerMultiply(a,b);
exports["precedence"] = a => b => c => agdaRTS.uprimIntegerPlus(agdaRTS.uprimIntegerMultiply(b,c),a);
exports["grouping"] = a => b => c => agdaRTS.uprimIntegerMultiply(agdaRTS.uprimIntegerPlus(a,b),c);
exports["nested"] = a => b => exports["add"](exports["subtract"](a)(b))(
    exports["multiply"](b)(agdaRTS.primIntegerFromString("2"))
  );
exports["successor"] = a => agdaRTS.uprimIntegerPlus(agdaRTS.primIntegerFromString("2"),a);
exports["equal"] = a => b => agdaRTS.uprimIntegerEqual(a,b);
exports["less"] = a => b => agdaRTS.uprimIntegerLessThan(a,b);
exports["identity"] = a => a;
exports["preserve"] = a => a;
exports["dropfirst"] = a => a;
exports["constant"] = agdaRTS.primIntegerFromString("42");
