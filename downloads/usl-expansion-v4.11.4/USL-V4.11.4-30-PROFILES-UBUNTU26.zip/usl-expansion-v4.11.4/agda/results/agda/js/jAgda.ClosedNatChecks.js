var agdaRTS = require("agda-rts");

var z_jAgda_Agda_Builtin_Bool = require("jAgda.Agda.Builtin.Bool");
var z_jAgda_Agda_Builtin_Nat = require("jAgda.Agda.Builtin.Nat");
var z_jAgda_Agda_Primitive = require("jAgda.Agda.Primitive");
var z_jAgda_ClosedNat = require("jAgda.ClosedNat");

exports["obs0"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs1"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs2"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs3"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs4"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs5"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs6"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs7"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs8"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs9"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs10"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs11"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs12"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs13"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs14"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs15"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs16"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs17"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs18"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs19"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs20"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs21"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs22"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs23"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs24"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs25"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs26"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs27"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs28"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs29"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs30"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs31"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs32"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs33"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs34"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs35"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs36"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs37"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs38"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs39"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs40"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs41"] = z_jAgda_ClosedNat["add"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs42"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs43"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs44"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs45"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs46"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs47"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs48"] = z_jAgda_ClosedNat["add"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs49"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs50"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs51"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs52"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs53"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs54"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs55"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs56"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs57"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs58"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs59"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs60"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs61"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs62"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs63"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs64"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs65"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs66"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs67"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs68"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs69"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs70"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs71"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs72"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs73"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs74"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs75"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs76"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs77"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs78"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs79"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs80"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs81"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs82"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs83"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs84"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs85"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs86"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs87"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs88"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs89"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs90"] = z_jAgda_ClosedNat["subtract"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs91"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs92"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs93"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs94"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs95"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs96"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs97"] = z_jAgda_ClosedNat["subtract"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs98"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs99"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs100"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs101"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs102"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs103"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs104"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs105"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs106"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs107"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs108"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs109"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs110"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs111"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs112"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs113"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs114"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs115"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs116"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs117"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs118"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs119"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs120"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs121"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs122"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs123"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs124"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs125"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs126"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs127"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs128"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs129"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs130"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs131"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs132"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs133"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs134"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs135"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs136"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs137"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs138"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs139"] = z_jAgda_ClosedNat["multiply"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs140"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs141"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs142"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs143"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs144"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs145"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs146"] = z_jAgda_ClosedNat["multiply"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs147"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs148"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs149"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs150"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs151"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs152"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs153"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs154"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs155"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs156"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs157"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs158"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs159"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs160"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs161"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs162"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs163"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs164"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs165"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs166"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs167"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs168"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs169"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs170"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs171"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs172"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs173"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs174"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs175"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs176"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs177"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs178"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs179"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs180"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs181"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs182"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs183"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs184"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs185"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs186"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs187"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs188"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs189"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs190"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs191"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs192"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs193"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs194"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs195"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs196"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs197"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs198"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs199"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs200"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs201"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs202"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs203"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs204"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs205"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs206"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs207"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs208"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs209"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs210"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs211"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs212"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs213"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs214"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs215"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs216"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs217"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs218"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs219"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs220"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs221"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs222"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs223"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs224"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs225"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs226"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs227"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs228"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs229"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs230"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs231"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs232"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs233"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs234"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs235"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs236"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs237"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs238"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs239"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs240"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs241"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs242"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs243"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs244"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs245"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs246"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs247"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs248"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs249"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs250"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs251"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs252"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs253"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs254"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs255"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs256"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs257"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs258"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs259"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs260"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs261"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs262"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs263"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs264"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs265"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs266"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs267"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs268"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs269"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs270"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs271"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs272"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs273"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs274"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs275"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs276"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs277"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs278"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs279"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs280"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs281"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs282"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs283"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs284"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs285"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs286"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs287"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs288"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs289"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs290"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs291"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs292"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs293"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs294"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs295"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs296"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs297"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs298"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs299"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs300"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs301"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs302"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs303"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs304"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs305"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs306"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs307"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs308"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs309"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs310"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs311"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs312"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs313"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs314"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs315"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs316"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs317"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs318"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs319"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs320"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs321"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs322"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs323"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs324"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs325"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs326"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs327"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs328"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs329"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs330"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs331"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs332"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs333"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs334"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs335"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs336"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs337"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs338"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs339"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs340"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs341"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs342"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs343"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs344"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs345"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs346"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs347"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs348"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs349"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs350"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs351"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs352"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs353"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs354"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs355"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs356"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs357"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs358"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs359"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs360"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs361"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs362"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs363"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs364"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs365"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs366"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs367"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs368"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs369"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs370"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs371"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs372"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs373"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs374"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs375"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs376"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs377"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs378"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs379"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs380"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs381"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs382"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs383"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs384"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs385"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs386"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs387"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs388"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs389"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs390"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs391"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs392"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs393"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs394"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs395"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs396"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs397"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs398"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs399"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs400"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs401"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs402"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs403"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs404"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs405"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs406"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs407"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs408"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs409"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs410"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs411"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs412"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs413"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs414"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs415"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs416"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs417"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs418"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs419"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs420"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs421"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs422"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs423"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs424"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs425"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs426"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs427"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs428"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs429"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs430"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs431"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs432"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs433"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs434"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs435"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs436"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs437"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs438"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs439"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs440"] = z_jAgda_ClosedNat["precedence"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs441"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs442"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs443"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs444"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs445"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs446"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs447"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs448"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs449"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs450"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs451"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs452"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs453"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs454"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs455"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs456"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs457"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs458"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs459"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs460"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs461"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs462"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs463"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs464"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs465"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs466"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs467"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs468"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs469"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs470"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs471"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs472"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs473"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs474"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs475"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs476"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs477"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs478"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs479"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs480"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs481"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs482"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs483"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs484"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs485"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs486"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs487"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs488"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs489"] = z_jAgda_ClosedNat["precedence"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs490"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs491"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs492"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs493"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs494"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs495"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs496"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs497"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs498"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs499"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs500"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs501"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs502"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs503"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs504"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs505"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs506"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs507"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs508"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs509"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs510"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs511"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs512"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs513"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs514"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs515"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs516"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs517"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs518"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs519"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs520"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs521"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs522"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs523"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs524"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs525"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs526"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs527"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs528"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs529"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs530"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs531"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs532"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs533"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs534"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs535"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs536"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs537"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs538"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs539"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs540"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs541"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs542"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs543"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs544"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs545"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs546"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs547"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs548"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs549"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs550"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs551"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs552"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs553"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs554"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs555"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs556"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs557"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs558"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs559"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs560"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs561"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs562"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs563"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs564"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs565"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs566"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs567"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs568"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs569"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs570"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs571"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs572"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs573"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs574"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs575"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs576"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs577"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs578"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs579"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs580"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs581"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs582"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs583"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs584"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs585"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs586"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs587"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs588"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs589"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs590"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs591"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs592"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs593"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs594"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs595"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs596"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs597"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs598"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs599"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs600"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs601"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs602"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs603"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs604"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs605"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs606"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs607"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs608"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs609"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs610"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs611"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs612"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs613"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs614"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs615"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs616"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs617"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs618"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs619"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs620"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs621"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs622"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs623"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs624"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs625"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs626"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs627"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs628"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs629"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs630"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs631"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs632"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs633"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs634"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs635"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs636"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs637"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs638"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs639"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs640"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs641"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs642"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs643"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs644"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs645"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs646"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs647"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs648"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs649"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs650"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs651"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs652"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs653"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs654"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs655"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs656"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs657"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs658"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs659"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs660"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs661"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs662"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs663"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs664"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs665"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs666"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs667"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs668"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs669"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs670"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs671"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs672"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs673"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs674"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs675"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs676"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs677"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs678"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs679"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs680"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs681"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs682"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs683"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs684"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs685"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs686"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs687"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs688"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs689"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs690"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs691"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs692"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs693"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs694"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs695"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs696"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs697"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs698"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs699"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs700"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs701"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs702"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs703"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs704"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs705"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs706"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs707"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs708"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs709"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs710"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs711"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs712"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs713"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs714"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs715"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs716"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs717"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs718"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs719"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs720"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs721"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs722"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs723"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs724"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs725"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs726"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs727"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs728"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs729"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs730"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs731"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs732"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs733"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs734"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs735"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs736"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs737"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs738"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs739"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs740"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs741"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs742"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs743"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs744"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs745"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs746"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs747"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs748"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs749"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs750"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs751"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs752"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs753"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs754"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs755"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs756"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs757"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs758"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs759"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs760"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs761"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs762"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs763"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs764"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs765"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs766"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs767"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs768"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs769"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs770"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs771"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs772"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs773"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs774"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs775"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs776"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs777"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs778"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs779"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs780"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs781"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs782"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs783"] = z_jAgda_ClosedNat["grouping"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs784"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs785"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs786"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs787"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs788"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs789"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs790"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs791"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs792"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs793"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs794"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs795"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs796"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs797"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs798"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs799"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs800"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs801"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs802"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs803"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs804"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs805"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs806"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs807"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs808"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs809"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs810"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs811"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs812"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs813"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs814"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs815"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs816"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs817"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs818"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs819"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs820"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs821"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs822"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs823"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs824"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs825"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs826"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs827"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs828"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs829"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs830"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs831"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs832"] = z_jAgda_ClosedNat["grouping"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs833"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs834"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs835"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs836"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs837"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs838"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs839"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs840"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs841"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs842"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs843"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs844"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs845"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs846"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs847"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs848"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs849"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs850"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs851"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs852"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs853"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs854"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs855"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs856"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs857"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs858"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs859"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs860"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs861"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs862"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs863"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs864"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs865"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs866"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs867"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs868"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs869"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs870"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs871"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs872"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs873"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs874"] = z_jAgda_ClosedNat["nested"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs875"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs876"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs877"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs878"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs879"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs880"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs881"] = z_jAgda_ClosedNat["nested"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs882"] = z_jAgda_ClosedNat["successor"](agdaRTS.primIntegerFromString("0"));
exports["obs883"] = z_jAgda_ClosedNat["successor"](agdaRTS.primIntegerFromString("1"));
exports["obs884"] = z_jAgda_ClosedNat["successor"](agdaRTS.primIntegerFromString("2"));
exports["obs885"] = z_jAgda_ClosedNat["successor"](agdaRTS.primIntegerFromString("7"));
exports["obs886"] = z_jAgda_ClosedNat["successor"](agdaRTS.primIntegerFromString("31"));
exports["obs887"] = z_jAgda_ClosedNat["successor"](agdaRTS.primIntegerFromString("1000"));
exports["obs888"] = z_jAgda_ClosedNat["successor"](
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs889"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs890"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs891"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs892"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs893"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs894"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs895"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs896"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs897"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs898"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs899"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs900"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs901"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs902"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs903"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs904"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs905"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs906"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs907"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs908"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs909"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs910"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs911"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs912"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs913"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs914"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs915"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs916"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs917"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs918"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs919"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs920"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs921"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs922"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs923"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs924"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs925"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs926"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs927"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs928"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs929"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs930"] = z_jAgda_ClosedNat["equal"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs931"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs932"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs933"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs934"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs935"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs936"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs937"] = z_jAgda_ClosedNat["equal"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs938"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("0"));
exports["obs939"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1"));
exports["obs940"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("2"));
exports["obs941"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("7"));
exports["obs942"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("31"));
exports["obs943"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(agdaRTS.primIntegerFromString("1000"));
exports["obs944"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("0"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs945"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("0"));
exports["obs946"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1"));
exports["obs947"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("2"));
exports["obs948"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("7"));
exports["obs949"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("31"));
exports["obs950"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(agdaRTS.primIntegerFromString("1000"));
exports["obs951"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs952"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("0"));
exports["obs953"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1"));
exports["obs954"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("2"));
exports["obs955"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("7"));
exports["obs956"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("31"));
exports["obs957"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(agdaRTS.primIntegerFromString("1000"));
exports["obs958"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("2"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs959"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("0"));
exports["obs960"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1"));
exports["obs961"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("2"));
exports["obs962"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("7"));
exports["obs963"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("31"));
exports["obs964"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(agdaRTS.primIntegerFromString("1000"));
exports["obs965"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("7"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs966"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("0"));
exports["obs967"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1"));
exports["obs968"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("2"));
exports["obs969"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("7"));
exports["obs970"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("31"));
exports["obs971"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(agdaRTS.primIntegerFromString("1000"));
exports["obs972"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("31"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs973"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("0"));
exports["obs974"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1"));
exports["obs975"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("2"));
exports["obs976"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("7"));
exports["obs977"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("31"));
exports["obs978"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(agdaRTS.primIntegerFromString("1000"));
exports["obs979"] = z_jAgda_ClosedNat["less"](agdaRTS.primIntegerFromString("1000"))(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs980"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("0"));
exports["obs981"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1"));
exports["obs982"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("2"));
exports["obs983"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("7"));
exports["obs984"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("31"));
exports["obs985"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(agdaRTS.primIntegerFromString("1000"));
exports["obs986"] = z_jAgda_ClosedNat["less"](
    agdaRTS.primIntegerFromString("1000000000000")
  )(
    agdaRTS.primIntegerFromString("1000000000000")
  );
exports["obs987"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs988"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs989"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs990"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs991"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs992"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs993"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs994"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs995"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs996"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs997"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs998"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs999"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1000"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1001"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1002"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1003"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1004"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1005"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1006"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1007"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1008"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1009"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1010"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1011"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1012"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1013"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1014"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1015"] = z_jAgda_Agda_Builtin_Bool["Bool"]["false"];
exports["obs1016"] = z_jAgda_Agda_Builtin_Bool["Bool"]["true"];
exports["obs1017"] = z_jAgda_ClosedNat["constant"];
