; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Bool)
(assert
 (and (distinct x x) true))
(check-sat)
