; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let (($x39 (< x y)))
(and (distinct $x39 $x39) true)))
(check-sat)
