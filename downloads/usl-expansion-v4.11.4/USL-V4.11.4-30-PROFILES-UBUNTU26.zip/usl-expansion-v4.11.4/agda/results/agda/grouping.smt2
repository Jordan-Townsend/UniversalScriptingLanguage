; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(declare-fun z () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (>= z 0))
(assert
 (let ((?x25 (* (+ x y) z)))
(and (distinct ?x25 ?x25) true)))
(check-sat)
