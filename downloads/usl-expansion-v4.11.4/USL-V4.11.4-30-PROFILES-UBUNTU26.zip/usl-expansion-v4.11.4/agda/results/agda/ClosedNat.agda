module ClosedNat where
open import Agda.Builtin.Nat
open import Agda.Builtin.Bool
add : Nat → Nat → Nat
add x y = x + y
subtract : Nat → Nat → Nat
subtract x y = x - y
multiply : Nat → Nat → Nat
multiply x y = x * y
precedence : Nat → Nat → Nat → Nat
precedence x y z = x + y * z
grouping : Nat → Nat → Nat → Nat
grouping x y z = (x + y) * z
nested : Nat → Nat → Nat
nested x y = add (subtract x y) (multiply y 2)
successor : Nat → Nat
successor x = suc (suc x)
equal : Nat → Nat → Bool
equal x y = x == y
less : Nat → Nat → Bool
less x y = x < y
identity : Bool → Bool
identity x = x
preserve : Bool → Nat → Bool
preserve x y = x
dropfirst : Nat → Bool → Bool
dropfirst x y = y
constant : Nat
constant = 42
