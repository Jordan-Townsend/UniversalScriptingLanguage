; benchmark generated from python API
(set-info :status unknown)
(declare-fun y () Int)
(declare-fun x () Bool)
(assert
 (>= y 0))
(assert
 (and (distinct x x) true))
(check-sat)
