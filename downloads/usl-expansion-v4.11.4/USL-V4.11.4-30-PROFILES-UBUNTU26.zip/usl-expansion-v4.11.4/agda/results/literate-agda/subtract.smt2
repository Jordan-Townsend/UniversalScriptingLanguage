; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let ((?x42 (- x y)))
(let ((?x40 (ite (<= 0 ?x42) ?x42 0)))
(let ((?x37 (ite (>= x y) ?x42 0)))
(and (distinct ?x37 ?x40) true)))))
(check-sat)
