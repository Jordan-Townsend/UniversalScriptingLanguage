; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let ((?x8 (* y 2)))
(let ((?x23 (+ (ite (<= 0 (- x y)) (- x y) 0) ?x8)))
(let ((?x48 (+ (ite (>= x y) (- x y) 0) ?x8)))
(and (distinct ?x48 ?x23) true)))))
(check-sat)
