; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(assert
 (>= x 0))
(assert
 (let ((?x45 (+ (+ x 1) 1)))
(and (distinct ?x45 ?x45) true)))
(check-sat)
