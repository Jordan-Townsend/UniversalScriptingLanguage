; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let (($x35 (= x y)))
(and (distinct $x35 $x35) true)))
(check-sat)
