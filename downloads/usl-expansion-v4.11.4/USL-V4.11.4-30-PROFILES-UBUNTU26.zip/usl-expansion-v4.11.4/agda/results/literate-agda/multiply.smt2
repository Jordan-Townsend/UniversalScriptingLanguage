; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (>= y 0))
(assert
 (let ((?x30 (* x y)))
(and (distinct ?x30 ?x30) true)))
(check-sat)
