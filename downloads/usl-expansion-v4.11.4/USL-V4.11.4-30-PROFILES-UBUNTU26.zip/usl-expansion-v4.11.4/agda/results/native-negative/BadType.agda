module BadType where
open import Agda.Builtin.Nat
open import Agda.Builtin.Bool
bad : Nat
bad = true
