module BadTermination where
open import Agda.Builtin.Nat
open import Agda.Builtin.Bool
bad : Nat → Nat
bad x = bad x
