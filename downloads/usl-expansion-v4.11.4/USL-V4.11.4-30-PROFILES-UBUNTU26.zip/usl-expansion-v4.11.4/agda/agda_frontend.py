"""Typed, fail-closed Agda Nat/Bool expression frontend and USL lowering.

This is a deliberately stated first-order pure profile, not complete Agda.
"""
from dataclasses import dataclass
from pathlib import Path
import re


class Unsupported(ValueError):
    pass


@dataclass(frozen=True)
class Function:
    name: str
    parameters: tuple
    argument_types: tuple
    result_type: str
    expression: tuple


NAME = re.compile(r'[a-z][a-zA-Z0-9]*\Z', re.ASCII)
MODULE = re.compile(r'[A-Z][a-zA-Z0-9]*\Z', re.ASCII)
# Agda names can contain operator characters: x+y is one name, not x + y.
# Split only at actual whitespace/parentheses, then recognize exact tokens.
TOKEN = re.compile(r'\s*([()]|[^()\s]+)', re.ASCII)
OPERATORS = {'==': 4, '<': 4, '+': 6, '-': 6, '*': 7}
BUILTINS = {'suc', 'zero', 'true', 'false'}
RESERVED = set('abstract codata coinductive constructor data do eta-equality field forall hiding import in inductive infix infixl infixr instance interleaved let macro module mutual no-eta-equality opaque open overlap pattern postulate primitive private public quote quoteContext quoteGoal quoteTerm record renaming rewrite syntax tactic unfolding unquote unquoteDecl unquoteDef using variable where with'.split())


def markdown_code(source):
    lines = []; active = False
    for line in source.splitlines():
        if line == '```agda':
            if active:
                raise Unsupported('Nested Agda code fence')
            active = True
        elif line == '```':
            if not active:
                raise Unsupported('Only complete Agda fences are supported')
            active = False
        elif line.startswith('```') or line.startswith('~~~'):
            raise Unsupported('Unsupported Markdown fence')
        elif active:
            lines.append(line)
    if active or not lines:
        raise Unsupported('Unclosed or missing Agda code fence')
    return '\n'.join(lines) + '\n'


class ExpressionParser:
    def __init__(self, source, environment, functions):
        self.environment = environment; self.functions = functions; self.tokens = []; self.at = 0
        if len(source) > 4096:
            raise Unsupported('Expression source limit')
        position = 0
        while position < len(source):
            found = TOKEN.match(source, position)
            if not found:
                if source[position:].strip():
                    raise Unsupported('Unsupported expression token')
                break
            self.tokens.append(found[1]); position = found.end()
        if len(self.tokens) > 512:
            raise Unsupported('Expression token limit')

    def take(self):
        if self.at >= len(self.tokens):
            raise Unsupported('Incomplete expression')
        token = self.tokens[self.at]; self.at += 1
        return token

    def expression(self, minimum=0, depth=0, application_argument=False):
        if depth > 40:
            raise Unsupported('Expression recursion limit')
        token = self.take()
        if token == '(':
            node, kind = self.expression(0, depth + 1)
            if self.take() != ')':
                raise Unsupported('Unbalanced parentheses')
        elif token.isascii() and token.isdecimal():
            if len(token) > 12 or (len(token) > 1 and token[0] == '0'):
                raise Unsupported('Noncanonical or excessive Nat literal')
            node, kind = ('natural', int(token)), 'Nat'
        elif token == 'zero':
            node, kind = ('natural', 0), 'Nat'
        elif token in {'true', 'false'}:
            node, kind = ('boolean', token == 'true'), 'Bool'
        elif token in self.environment:
            node, kind = ('variable', token), self.environment[token]
        elif token == 'suc':
            if application_argument:
                raise Unsupported('Function-valued arguments need an explicitly parenthesized application')
            argument, argument_type = self.expression(20, depth + 1, True)
            if argument_type != 'Nat':
                raise Unsupported('suc requires Nat')
            node, kind = ('suc', argument), 'Nat'
        elif token in self.functions:
            function = self.functions[token]; arguments = []
            if application_argument and function.argument_types:
                raise Unsupported('Function-valued arguments are outside the first-order profile')
            for expected in function.argument_types:
                argument, actual = self.expression(20, depth + 1, True)
                if actual != expected:
                    raise Unsupported('Call argument type mismatch')
                arguments.append(argument)
            node, kind = ('call', token, tuple(arguments)), function.result_type
        else:
            raise Unsupported('Unknown binding or unsupported expression: ' + token)
        comparison = False
        while self.at < len(self.tokens):
            operator = self.tokens[self.at]
            precedence = OPERATORS.get(operator, -1)
            if precedence < minimum:
                break
            if precedence == 4 and comparison:
                raise Unsupported('Agda comparison operators are nonassociative')
            self.at += 1
            right, right_kind = self.expression(precedence + 1, depth + 1)
            if kind != 'Nat' or right_kind != 'Nat':
                raise Unsupported('Nat operator applied to non-Nat data')
            node = (operator, node, right)
            kind = 'Bool' if precedence == 4 else 'Nat'
            comparison = precedence == 4
        return node, kind

    def parse(self):
        result = self.expression()
        if self.at != len(self.tokens):
            raise Unsupported('Trailing expression tokens or unsupported application')
        return result


def parse(source, literate=False):
    if type(source) is not str or len(source.encode('utf-8')) > 65_536:
        raise Unsupported('Expected bounded UTF8 source text')
    if literate:
        source = markdown_code(source)
    lines = []
    for raw in source.splitlines():
        # -- begins a comment only at a lexical boundary in this profile.
        line = re.split(r'(?<!\S)--', raw, maxsplit=1)[0]
        if line.strip() and line != line.lstrip():
            raise Unsupported('This declaration profile requires zero-column layout')
        lines.append(line.strip())
    lines = [line for line in lines if line]
    if not lines or not lines[0].startswith('module '):
        raise Unsupported('Expected explicit module header')
    header = lines.pop(0).split()
    if len(header) != 3 or header[0] != 'module' or header[2] != 'where' or not MODULE.fullmatch(header[1]):
        raise Unsupported('Unsupported module identity')
    expected_imports = ['open import Agda.Builtin.Nat', 'open import Agda.Builtin.Bool']
    if lines[:2] != expected_imports:
        raise Unsupported('Exact Nat and Bool builtin imports required')
    lines = lines[2:]; functions = {}
    while lines:
        signature = lines.pop(0)
        if ':' not in signature or not lines:
            raise Unsupported('Expected type signature and one defining equation')
        name, declared = (piece.strip() for piece in signature.split(':', 1))
        if not NAME.fullmatch(name) or name in functions or name in BUILTINS | RESERVED:
            raise Unsupported('Duplicate, reserved or unsupported function name')
        types = tuple(piece.strip() for piece in declared.split('→'))
        if not types or len(types) > 4 or any(kind not in {'Nat', 'Bool'} for kind in types):
            raise Unsupported('Only first-order Nat/Bool signatures of arity0..3 supported')
        equation = lines.pop(0)
        # Split defining equality, keeping == as an expression operator.
        found = re.fullmatch(r'(.+?)\s+=\s+(.+)', equation)
        if not found:
            raise Unsupported('Expected one ordinary defining equation')
        lhs, rhs = found.groups(); bindings = lhs.split()
        if not bindings or bindings[0] != name or len(bindings) != len(types):
            raise Unsupported('Signature/equation argument mismatch')
        parameters = tuple(bindings[1:])
        if len(set(parameters)) != len(parameters) or any(not NAME.fullmatch(p) or p in BUILTINS | RESERVED or p in functions or p == name for p in parameters):
            raise Unsupported('Unsupported argument binding')
        expression, result_type = ExpressionParser(rhs, dict(zip(parameters, types[:-1])), functions).parse()
        if result_type != types[-1]:
            raise Unsupported('Declared result type differs from expression type')
        functions[name] = Function(name, parameters, types[:-1], result_type, expression)
        if len(functions) > 64:
            raise Unsupported('Function count limit')
    if not functions:
        raise Unsupported('No definitions')
    return header[1], functions


def usl_expression(node):
    tag = node[0]
    if tag in {'natural', 'boolean'}:
        return repr(node[1])
    if tag == 'variable':
        return 'arg_' + node[1]
    if tag == 'suc':
        return '(' + usl_expression(node[1]) + ' + 1)'
    if tag == 'call':
        return 'agda_' + node[1] + '(' + ', '.join(usl_expression(arg) for arg in node[2]) + ')'
    left, right = usl_expression(node[1]), usl_expression(node[2])
    if tag == '-':
        return 'max((' + left + ' - ' + right + '), 0)'
    if tag in OPERATORS:
        return '(' + left + ' ' + tag + ' ' + right + ')'
    raise Unsupported('Unknown typed IR operation')


def emit(functions):
    return '\n\n'.join('function agda_' + f.name + '(' + ', '.join('arg_' + p for p in f.parameters) + '):\n    return ' + usl_expression(f.expression) for f in functions.values()) + '\n'
