import unittest
from agda_frontend import Unsupported, emit, markdown_code, parse

HEADER = 'module Example where\nopen import Agda.Builtin.Nat\nopen import Agda.Builtin.Bool\n'


class FrontendTests(unittest.TestCase):
    def test_calls_precedence_and_boolean_types(self):
        module, functions = parse(HEADER + 'plus : Nat → Nat → Nat\nplus x y = x + y\nless : Nat → Nat → Bool\nless x y = plus x (y * 2) < suc y\n')
        self.assertEqual(module, 'Example')
        self.assertEqual(functions['less'].result_type, 'Bool')
        self.assertIn('agda_plus(arg_x, (arg_y * 2))', emit(functions))

    def test_monus_is_saturating_and_bindings_cannot_shadow_USL_builtins(self):
        _, functions = parse(HEADER + 'minus : Nat → Nat → Nat\nminus max sum = max - sum\n')
        self.assertIn('max((arg_max - arg_sum), 0)', emit(functions))

    def test_types_scope_and_unmodeled_features_rejected(self):
        for body in [
            'bad : Nat → Nat\nbad x = true\n',
            'bad : Nat → Nat\nbad x = missing\n',
            'bad : Nat → Nat\nbad x = bad x\n',
            'bad : Nat → Nat\nbad x = x / 2\n',
            'bad : Nat → Nat\nbad x = -1\n',
            'bad : Bool → Nat\nbad x = x + 1\n',
            'bad : Nat → Nat\nbad zero = 1\n',
            'module : Nat\nmodule = 1\n',
            'bad : Nat → Nat\nbad x = 01\n',
            'bad : Nat → Nat\nbad x = (x + 1\n',
        ]:
            with self.subTest(body=body), self.assertRaises(Unsupported):
                parse(HEADER + body)

    def test_argument_count_duplicates_and_multiple_equations_rejected(self):
        for body in ['f : Nat → Nat\nf x x = x\n', 'f : Nat → Nat\nf x = x\nf x = 1\n',
                     'f : Nat → Nat → Nat\nf x x = x\n', 'f : Nat\nf = 1\nf : Nat\nf = 2\n']:
            with self.subTest(body=body), self.assertRaises(Unsupported):
                parse(HEADER + body)

    def test_markdown_profile_extracts_code_and_rejects_open_fences(self):
        code = HEADER + 'answer : Nat\nanswer = 42\n'
        source = '# Prose\n\n```agda\n' + code + '```\nText outside code.\n'
        self.assertEqual(parse(source, literate=True), parse(code))
        for source in ['```agda\n' + code, '```python\nx=1\n```', 'Prose only']:
            with self.subTest(source=source), self.assertRaises(Unsupported):
                markdown_code(source)


if __name__ == '__main__':
    unittest.main()
