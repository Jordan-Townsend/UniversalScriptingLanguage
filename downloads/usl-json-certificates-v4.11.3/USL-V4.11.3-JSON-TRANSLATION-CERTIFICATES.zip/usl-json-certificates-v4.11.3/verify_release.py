"""Fresh JSON execution, checker regression, and pinned source-review reproduction."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
RFC_URL = 'https://www.rfc-editor.org/rfc/rfc8259.txt'
RFC_SHA256 = '61a5378f4255c720beb2a4b4a63b29540147c140f36988bf086291989b4cd2d7'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(input_root, source_root, suite, output, rfc_text=None):
    started = time.perf_counter()
    input_root = Path(input_root).resolve()
    source_root = Path(source_root).resolve()
    suite = Path(suite).resolve()
    output = Path(output).resolve()
    if output == ROOT or output.is_relative_to(ROOT):
        raise ValueError('Fresh verification output must be outside the immutable package')
    output.mkdir(parents=True, exist_ok=True)
    source_names = sorted(p.name for p in ROOT.glob('*.py'))
    source_hashes = {name: sha(ROOT / name) for name in source_names}
    package_manifest = ROOT / 'MANIFEST.json'
    package_checks = 0
    if package_manifest.is_file():
        identities = json.loads(package_manifest.read_text())['files']
        for name, identity in identities.items():
            path = (ROOT / name).resolve()
            if not path.is_relative_to(ROOT) or not path.is_file():
                raise ValueError('Unsafe or missing package file: ' + name)
            if sha(path) != identity['sha256'] or path.stat().st_size != identity['bytes']:
                raise ValueError('Package file changed: ' + name)
            package_checks += 1
    environment = dict(os.environ)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    environment['USL_CERTIFICATE_INPUT_ROOT'] = str(input_root)
    environment['USL_CERTIFICATE_SOURCE_ROOT'] = str(source_root)

    def command(name, arguments):
        path = output / (name + '.log')
        with path.open('w') as stream:
            result = subprocess.run([sys.executable] + arguments, cwd=ROOT, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=90)
        if result.returncode:
            raise ValueError(name + ' failed; see ' + str(path))
        return {'passed': True, 'log_sha256': sha(path)}

    tests = command('checker-tests', ['-m', 'unittest', 'discover', '-v'])
    completed = re.search(r'Ran (\d+) tests?', (output / 'checker-tests.log').read_text())
    if not completed or int(completed[1]) != 17:
        raise ValueError('Expected 17 completed checker/review tests')
    tests['tests_run'] = int(completed[1])
    common = ['--input-root', str(input_root), '--source-root', str(source_root), '--suite', str(suite)]
    native = command('fresh-execution', ['run_certificates.py'] + common + ['--output', str(output / 'fresh')])
    replay = command('saved-certificate-check', ['verify_certificates.py'] + common + ['--output', str(output / 'fresh')])
    if rfc_text is None:
        rfc_text = output / 'rfc8259.txt'
        if not rfc_text.is_file() or sha(rfc_text) != RFC_SHA256:
            with urllib.request.urlopen(RFC_URL, timeout=30) as response:
                body = response.read(100_000)
            if hashlib.sha256(body).hexdigest() != RFC_SHA256:
                raise ValueError('Retrieved RFC bytes differ from pinned published text')
            rfc_text.write_bytes(body)
    if sha(rfc_text) != RFC_SHA256:
        raise ValueError('RFC source bytes differ from pinned published text')
    review = command('source-review', ['json_normative_review.py', '--base', str(input_root),
                     '--rfc-text', str(rfc_text), '--output', str(output / 'source-review')])
    for name in ['JSON_NORMATIVE_REVIEW.json', 'JSON_TARGET_CONTRACT.json']:
        if (ROOT / name).read_bytes() != (output / 'source-review' / name).read_bytes():
            raise ValueError('Pinned source-review reproduction changed: ' + name)
    summary = json.loads((output / 'fresh/SUMMARY.json').read_text())
    required = {'case_actors': 930, 'accepted_case_certificates_checked': 626,
                'fresh_generated_USL_executions': 626, 'fresh_native_processing_cases': 1556,
                'rejected_cases': 296, 'disclosed_resource_limit_cases': 8, 'full_standards_qualified': 0}
    if not summary['passed'] or any(type(summary[key]) is not int or summary[key] != value for key, value in required.items()):
        raise ValueError('Fresh execution partition changed')
    if any(sha(ROOT / name) != identity for name, identity in source_hashes.items()):
        raise ValueError('Package source changed during verification')
    result = {'passed': True, 'package_manifest_files_checked': package_checks, 'checker_tests': tests,
              'fresh_execution': native, 'certificate_recheck': replay, 'pinned_source_review': review,
              **required, 'native_receipts_replayed': False, 'source_unchanged_during_verification': True,
              'source_sha256': source_hashes, 'seconds_through_primary_checks': time.perf_counter() - started,
              'cost_excludes': ['Writing this final verification record', 'Console reporting and shutdown'],
              'claim': 'Concrete data artifact translation validation under recorded trusted assumptions; full-standard obligations remain open'}
    (output / 'VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'source_sha256'}))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, default=Path('/workspace/usl-planning-v4.11.2'))
    parser.add_argument('--source-root', type=Path, default=Path('/workspace/usl-v4.10.0-clean-test'))
    parser.add_argument('--suite', type=Path, default=Path('/workspace/.onboarding/providers/JSONTestSuite'))
    parser.add_argument('--output', type=Path, default=Path('/tmp/usl-json-certificates-v4113-check'))
    parser.add_argument('--rfc-text', type=Path)
    args = parser.parse_args()
    verify(args.input_root, args.source_root, args.suite, args.output, args.rfc_text)
