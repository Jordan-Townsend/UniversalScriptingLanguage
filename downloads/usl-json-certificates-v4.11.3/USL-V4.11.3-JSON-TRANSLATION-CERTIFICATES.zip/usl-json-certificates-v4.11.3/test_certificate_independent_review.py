"""Independent artifact-boundary review; fixtures are not inferred from the emitter."""
import copy
import json
import unittest

from json_certificate import CertificateError, Checker, typed_equal


class IndependentCertificateReview(unittest.TestCase):
    def setUp(self):
        self.checker = Checker()

    def test_boundary_unicode_and_representation_survive_actual_execution(self):
        intended = ['object', [
            [[34, 92, 0], ['string', [0, 10, 34, 92, 0xD800, 97, 0xDFFF, 0x10FFFF]]],
            [[100], ['number', '-0.00E+00']],
            [[100], ['array', [['boolean', False], ['boolean', True], ['number', '1.0']]]],
        ]]
        candidate, runtime = self.checker.dependencies()
        generated = candidate.emit_usl(copy.deepcopy(intended))
        certificate = self.checker.certify(copy.deepcopy(intended), intended, generated)
        self.assertTrue(self.checker.verify(certificate, intended, intended, generated)['verified'])
        observed = runtime.Interpreter(timeout=5, max_ops=2_000_000).run(generated).variables['document']
        self.assertTrue(typed_equal(observed, intended))

    def test_value_equivalent_unmodeled_expressions_do_not_acquire_certificates(self):
        for source in [
            "let document = ['nu' + 'll']\n",
            "let document = [*['null']]\n",
            "let document = list(['null'])\n",
            "let document = [f'null']\n",
            "let document = ['null']; pass\n",
            "let document: list = ['null']\n",
        ]:
            with self.subTest(source=source), self.assertRaises(CertificateError):
                self.checker.certify(['null'], ['null'], source)

    def test_subclass_callbacks_are_rejected_before_iteration_or_representation(self):
        callbacks = []

        class HostileList(list):
            def __iter__(self):
                callbacks.append('iteration')
                return super().__iter__()

            def __repr__(self):
                callbacks.append('representation')
                return super().__repr__()

        for value in [HostileList(['null']), ['array', HostileList([['null']])]]:
            with self.assertRaises(CertificateError):
                self.checker.certify(value, ['null'])
        self.assertEqual(callbacks, [])

    def test_external_contract_retains_duplicate_pair_order_and_number_spelling(self):
        original = ['object', [[[97], ['number', '1']], [[97], ['number', '1.0']]]]
        candidate, _ = self.checker.dependencies()
        source = candidate.emit_usl(original)
        certificate = self.checker.certify(original, copy.deepcopy(original), source)
        variants = [
            ['object', list(reversed(original[1]))],
            ['object', [original[1][0]]],
            ['object', [[[97], ['number', '1e0']], original[1][1]]],
        ]
        for changed in variants:
            with self.subTest(changed=changed), self.assertRaises(CertificateError):
                self.checker.verify(certificate, original, changed, source)

    def test_claim_and_trusted_assumptions_cannot_be_removed_or_strengthened(self):
        source = "let document = ['null']\n"
        certificate = self.checker.certify(['null'], ['null'], source)
        variants = []
        for field, value in [('trusted_assumptions', []), ('excludes', []),
                             ('claim', 'All JSON programs proved correct'),
                             ('full_standard_qualified', True)]:
            changed = copy.deepcopy(certificate)
            changed[field] = value
            variants.append(changed)
        for changed in variants:
            with self.subTest(changed=changed), self.assertRaises(CertificateError):
                self.checker.verify(changed, ['null'], ['null'], source)

    def test_json_transport_preserves_certificate_and_exact_boolean_binding(self):
        source = "let document = ['boolean', True]\n"
        intended = ['boolean', True]
        original = self.checker.certify(intended, intended, source)
        transported = json.loads(json.dumps(original))
        self.assertTrue(self.checker.verify(transported, intended, intended, source)['verified'])
        transported['permits_additional_code_calls_or_effects'] = 0
        with self.assertRaises(CertificateError):
            self.checker.verify(transported, intended, intended, source)


if __name__ == '__main__':
    unittest.main()
