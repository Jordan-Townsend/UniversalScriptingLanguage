"""Translation validation for one concrete JSON IR -> USL literal artifact.

This small, trusted structural checker proves a restricted AST/data proposition.
It is not a proof of the JSON parser, JSON generator, USL interpreter, Python
runtime, complete JSON standard, or fidelity to unformalized natural-language
intent. Certificates must be checked against independently supplied intended IR.
"""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
DEFAULT_INPUT = Path(os.environ.get('USL_CERTIFICATE_INPUT_ROOT', '/workspace/usl-planning-v4.11.2'))
DEFAULT_SOURCE = Path(os.environ.get('USL_CERTIFICATE_SOURCE_ROOT', '/workspace/usl-v4.10.0-clean-test'))
JSON_SOURCE_SHA256 = 'acd176b34c4636c8b937d3795a1d5ce2a55b7f0969a5a8b02644e5a8e52c934c'
RUNTIME_SOURCE_SHA256 = '28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'
LIMITS = {'generated_source_utf8_bytes': 1_048_576, 'literal_nodes': 200_000,
          'literal_depth': 160, 'JSON_value_depth': 40, 'JSON_value_nodes': 10_000,
          'string_codepoints': 8192, 'number_characters': 1024}
NUMBER = re.compile(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?', re.ASCII)


class CertificateError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise CertificateError(message)


def encoded(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode('ascii')


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def typed_equal(left, right):
    """Python equality alone wrongly identifies True with 1 and False with 0."""
    if type(left) is not type(right):
        return False
    if type(left) is list:
        return len(left) == len(right) and all(typed_equal(a, b) for a, b in zip(left, right))
    if type(left) is dict:
        return len(left) == len(right) and {(type(key), key) for key in left} == {(type(key), key) for key in right} and all(typed_equal(left[key], right[key]) for key in left)
    return left == right


def validate_ir(value):
    """Independent exact-shape validation of the existing lossless JSON IR."""
    literal_nodes = 0
    active = set()

    def literal(node, depth):
        nonlocal literal_nodes
        literal_nodes += 1
        require(literal_nodes <= LIMITS['literal_nodes'], 'Literal node budget exceeded')
        require(depth <= LIMITS['literal_depth'], 'Literal depth budget exceeded')
        require(type(node) in (list, str, int, bool), 'Only exact list/string/int/bool literal types allowed')
        if type(node) is list:
            require(id(node) not in active, 'Cyclic IR is outside pure data profile')
            active.add(id(node))
            for child in node:
                literal(child, depth + 1)
            active.remove(id(node))

    literal(value, 0)
    value_nodes = 0

    def points(items):
        require(type(items) is list and len(items) <= LIMITS['string_codepoints'], 'Invalid IR codepoint list')
        previous = None
        for point in items:
            require(type(point) is int and 0 <= point <= 0x10FFFF, 'Invalid IR codepoint; Boolean is not an integer')
            require(not (previous is not None and 0xD800 <= previous <= 0xDBFF and 0xDC00 <= point <= 0xDFFF),
                    'Adjacent surrogate pairs must be combined in canonical IR')
            previous = point

    def node(item, depth):
        nonlocal value_nodes
        value_nodes += 1
        require(depth <= LIMITS['JSON_value_depth'] and value_nodes <= LIMITS['JSON_value_nodes'], 'JSON value resource limit')
        require(type(item) is list and len(item) in (1, 2) and type(item[0]) is str, 'Expected tagged JSON IR node')
        tag = item[0]
        if tag == 'null':
            require(len(item) == 1, 'Null IR has no value')
            return
        require(len(item) == 2, 'Tagged IR arity mismatch')
        data = item[1]
        if tag == 'boolean':
            require(type(data) is bool, 'Boolean IR needs an exact Boolean')
        elif tag == 'number':
            require(type(data) is str and len(data) <= LIMITS['number_characters'] and NUMBER.fullmatch(data) is not None,
                    'Number IR needs an exact RFC8259 lexeme')
        elif tag == 'string':
            points(data)
        elif tag == 'array':
            require(type(data) is list, 'Array IR needs an exact list')
            for child in data:
                node(child, depth + 1)
        elif tag == 'object':
            require(type(data) is list, 'Object IR needs ordered member list')
            for pair in data:
                require(type(pair) is list and len(pair) == 2, 'Object member pair shape mismatch')
                points(pair[0]); node(pair[1], depth + 1)
        else:
            raise CertificateError('Unknown IR tag')
    node(value, 0)
    return {'literal_nodes': literal_nodes, 'JSON_value_nodes': value_nodes}


def literal_value(tree):
    """Establish a concrete structural derivation over List/Constant only."""
    require(type(tree) is ast.Module and len(tree.body) == 1 and not tree.type_ignores,
            'Generated artifact must contain exactly one assignment')
    statement = tree.body[0]
    require(type(statement) is ast.Assign and len(statement.targets) == 1
            and type(statement.targets[0]) is ast.Name and statement.targets[0].id == 'document'
            and type(statement.targets[0].ctx) is ast.Store and statement.type_comment is None,
            'Generated artifact must assign only the document variable')
    counts = {'list_nodes': 0, 'constant_nodes': 0, 'maximum_literal_depth': 0}

    def descend(node, depth):
        require(depth <= LIMITS['literal_depth'], 'AST literal depth budget exceeded')
        counts['maximum_literal_depth'] = max(depth, counts['maximum_literal_depth'])
        if type(node) is ast.List:
            require(type(node.ctx) is ast.Load, 'Literal list must use load context')
            counts['list_nodes'] += 1
            result = [descend(child, depth + 1) for child in node.elts]
        elif type(node) is ast.Constant:
            require(type(node.value) in (str, int, bool), 'Literal constant has unsupported exact type')
            counts['constant_nodes'] += 1
            result = node.value
        else:
            raise CertificateError('Forbidden generated expression: ' + type(node).__name__)
        require(counts['list_nodes'] + counts['constant_nodes'] <= LIMITS['literal_nodes'], 'AST literal node budget exceeded')
        return result
    return descend(statement.value, 0), counts


class Checker:
    def __init__(self, input_root=DEFAULT_INPUT, source_root=DEFAULT_SOURCE):
        self.input_root = Path(input_root).resolve()
        self.source_root = Path(source_root).resolve()
        self._json_module = None

    def dependencies(self):
        require(file_sha(self.input_root / 'json_semantics.py') == JSON_SOURCE_SHA256, 'Pinned JSON translator source changed')
        runtime_path = self.source_root / 'usl_systems/language.py'
        require(file_sha(runtime_path) == RUNTIME_SOURCE_SHA256, 'Pinned USL source runtime changed')
        sys.path.insert(0, str(self.source_root)) if str(self.source_root) not in sys.path else None
        import usl_systems.language as runtime
        require(file_sha(runtime.__file__) == RUNTIME_SOURCE_SHA256, 'Loaded USL runtime differs from pinned source')
        if self._json_module is None:
            spec = importlib.util.spec_from_file_location('_certificate_json_candidate', self.input_root / 'json_semantics.py')
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            self._json_module = module
        return self._json_module, runtime

    def bindings(self):
        candidate, runtime = self.dependencies()
        runtime_tree = ast.parse((self.source_root / 'usl_systems/language.py').read_text())
        interpreter = next(node for node in runtime_tree.body if isinstance(node, ast.ClassDef) and node.name == 'Interpreter')
        val = next(node for node in interpreter.body if isinstance(node, ast.FunctionDef) and node.name == 'val')
        assumed_branches = [node for node in val.body if isinstance(node, ast.If)
                            and any(isinstance(child, ast.Attribute) and child.attr in {'Constant', 'List'} for child in ast.walk(node.test))]
        require(len(assumed_branches) == 2, 'Expected Constant/List runtime branches not present')
        return {'checker_source_sha256': file_sha(__file__), 'JSON_translator_source_sha256': JSON_SOURCE_SHA256,
                'USL_runtime_source_sha256': RUNTIME_SOURCE_SHA256,
                'assumed_Constant_List_branch_AST_sha256': digest([ast.dump(node, include_attributes=False) for node in assumed_branches]),
                'Python_implementation': sys.implementation.name, 'Python_version': sys.version,
                'AST_semantics': 'Python ast.parse; normalized USL assignment, recursively List and Constant only'}

    def certify(self, source_ir, intended_ir, generated_source=None):
        # Snapshot mutable data before any compiler call. An independent oracle
        # remains an explicit input; it is not inferred from generated output.
        source_shape = validate_ir(source_ir); validate_ir(intended_ir)
        require(typed_equal(source_ir, intended_ir), 'Source IR differs from independent intended IR')
        source_ir = json.loads(encoded(source_ir)); intended_ir = json.loads(encoded(intended_ir))
        candidate, runtime = self.dependencies()
        generated_source = candidate.emit_usl(source_ir) if generated_source is None else generated_source
        require(type(generated_source) is str, 'Expected actual generated USL source text')
        try:
            source_bytes = generated_source.encode('utf-8')
        except UnicodeError as error:
            raise CertificateError('Generated source must have a valid UTF8 encoding') from error
        require(len(source_bytes) <= LIMITS['generated_source_utf8_bytes'], 'Generated source byte budget exceeded')
        try:
            normalized = runtime.normalize(generated_source)
            tree = ast.parse(normalized)
        except (SyntaxError, RecursionError, MemoryError) as error:
            raise CertificateError('Generated literal parse failed within resource profile') from error
        actual, derivation = literal_value(tree)
        validate_ir(actual)
        require(typed_equal(actual, source_ir) and typed_equal(actual, intended_ir),
                'Generated AST literal is not exactly the source and intended IR')
        return {'schema': 'usl.JSON.concrete-literal-translation-certificate.v1',
                'claim': 'This concrete generated AST has one document assignment and its pure literal data exactly matches the independently supplied intended IR',
                'source_IR_sha256': digest(source_ir), 'independent_intent_IR_sha256': digest(intended_ir),
                'generated_source_sha256': hashlib.sha256(source_bytes).hexdigest(),
                'normalized_source_sha256': hashlib.sha256(normalized.encode()).hexdigest(),
                'generated_AST_sha256': digest(ast.dump(tree, include_attributes=False)),
                'structural_derivation': derivation, 'source_shape': source_shape,
                'bindings': self.bindings(), 'limits': LIMITS.copy(),
                'preserves_exact_types_number_lexemes_member_order_and_duplicates': True,
                'permits_additional_code_calls_or_effects': False,
                'trusted_assumptions': ['This structural checker executes as supplied',
                    'Python AST parsing and exact List/Constant value semantics are correct',
                    'Loaded functions correspond to their pinned source files; arbitrary runtime tampering is outside this certificate',
                    'The pinned USL normalize/parse/assignment and List/Constant branches have their documented literal semantics',
                    'The external intended IR actually represents the desired data contract'],
                'excludes': ['JSON parser/generator correctness', 'Whole USL interpreter correctness',
                    'Arbitrary source-program correctness', 'Complete JSON-standard qualification',
                    'Natural-language intent correctness'], 'full_standard_qualified': False}

    def verify(self, certificate, source_ir, intended_ir, generated_source):
        # Hashes and passed flags are not accepted as evidence: reparse actual
        # source, validate both externally supplied trees and redo the derivation.
        expected = self.certify(source_ir, intended_ir, generated_source)
        require(type(certificate) is dict and typed_equal(certificate, expected), 'Certificate differs from independently recomputed bindings or derivation')
        return {'verified': True, 'certificate_sha256': digest(expected),
                'verification_kind': 'Recomputed restricted-AST concrete translation validation',
                'full_standard_qualified': False}


_DEFAULT_CHECKER = Checker()


def certify(source_ir, intended_ir, generated_source=None):
    return _DEFAULT_CHECKER.certify(source_ir, intended_ir, generated_source)


def verify(certificate, source_ir, intended_ir, generated_source):
    return _DEFAULT_CHECKER.verify(certificate, source_ir, intended_ir, generated_source)
