"""Fresh end-to-end JSON processing plus concrete generated-artifact certificates."""
from __future__ import annotations
import argparse
import asyncio
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

from json_certificate import (Checker, DEFAULT_INPUT, DEFAULT_SOURCE, CertificateError,
                              digest, encoded, file_sha, require, typed_equal)

ROOT = Path(__file__).resolve().parent
NATIVE_SHA256 = 'd252276cb80863b3881397e93d378a78c60b76ee0c0d95625b9188bcd9ef3b58'
INTENT_SHA256 = 'f450c71456c9ed28d2e5ca88f8312c8f7e6f50a053c0a2549f60d42acd0e75f1'
SUITE_COMMIT = '1ef36fa01286573e846ac449e8683f8833c5b26a'


def write(path, data):
    Path(path).write_bytes(encoded(data) + b'\n')


def admission(distinct_jobs):
    def number(path, default):
        try:
            return int(Path(path).read_text().strip())
        except (OSError, ValueError):
            return default
    maximum = number('/sys/fs/cgroup/memory.max', 1 << 30)
    used = number('/sys/fs/cgroup/memory.current', 0)
    budget = max(1, maximum - used)
    descriptor_limit = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    descriptor_slots = max(1, int(descriptor_limit // 8)) if descriptor_limit != resource.RLIM_INFINITY else distinct_jobs
    slots = max(1, min(distinct_jobs, max(1, budget // (64 << 20)), descriptor_slots))
    return {'distinct_native_jobs_per_phase': distinct_jobs, 'native_thread_slots': slots,
            'memory_limit_bytes': maximum, 'observed_memory_current_bytes': used,
            'native_job_reservation_bytes': 64 << 20, 'fixed_rounds_or_worker_cap': False,
            'logical_case_actors_are_not_physical_CPUs': True}


def native_batch(input_root, items):
    native = Path(input_root) / 'json_native_reference.py'
    require(file_sha(native) == NATIVE_SHA256, 'Independent native reference source changed')
    payload = [{'id': name, 'base64': base64.b64encode(raw).decode('ascii')} for name, raw in items]
    started = time.perf_counter()
    result = subprocess.run([sys.executable, '-I', str(native)], input=encoded(payload), capture_output=True, timeout=30)
    require(result.returncode == 0, 'Fresh native reference failed: ' + result.stderr.decode(errors='replace')[:200])
    observations = json.loads(result.stdout)
    require([row['id'] for row in observations] == [name for name, raw in items], 'Native reference omitted or reordered observations')
    return {'observations': observations, 'identity': {
        'command': [sys.executable, '-I', 'json_native_reference.py'], 'reference_source_sha256': NATIVE_SHA256,
        'Python_binary_sha256': file_sha(sys.executable), 'Python_version': sys.version,
        'input_protocol_sha256': hashlib.sha256(encoded(payload)).hexdigest(),
        'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_hex': result.stderr.hex(),
        'exit_status': result.returncode, 'fresh_native_processing_cases': len(items),
        'fresh_native_processes': 1, 'native_observations_replayed': False,
        'seconds': time.perf_counter() - started}}


def load_cases(input_root, suite):
    input_root = Path(input_root); suite = Path(suite)
    intent_path = input_root / 'json-audit/independent_cases.py'
    require(file_sha(intent_path) == INTENT_SHA256, 'Independent intent fixture source changed')
    spec = importlib.util.spec_from_file_location('_certificate_independent_json_intent', intent_path)
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
    independent = module.all_cases()
    require(len(independent) == len({case.id for case in independent}) == 612, 'Expected complete independent intent fixture set')
    cases = [{'id': 'intent:' + case.id, 'corpus': 'independent', 'source_bytes': case.input.encode('utf-8') if type(case.input) is str else case.input,
              'expected_acceptance': case.accepts, 'independent_expected_IR': case.expected,
              'intent_origin': 'Independently authored fixture, separate from the implementation',
              'clause_candidates': list(case.clauses), 'policy': case.policy} for case in independent]
    commit = subprocess.check_output(['git', '-C', str(suite), 'rev-parse', 'HEAD'], text=True).strip()
    require(commit == SUITE_COMMIT, 'Upstream suite commit differs from pinned reference')
    files = sorted((suite / 'test_parsing').glob('*.json'))
    require(len(files) == 318, 'Upstream corpus is incomplete')
    historical = json.loads((input_root / 'json-results/qualification.json').read_text())
    identities = {row['file']: row['source_sha256'] for row in historical['records']}
    for path in files:
        raw = path.read_bytes(); require(hashlib.sha256(raw).hexdigest() == identities[path.name], 'Upstream corpus bytes changed')
        cases.append({'id': 'upstream:' + path.name, 'corpus': 'upstream', 'source_bytes': raw,
            'expected_acceptance': True if path.name.startswith('y_') else False if path.name.startswith('n_') else None,
            'independent_expected_IR': None, 'intent_origin': 'Fresh independent Python native parser; upstream acceptance classification',
            'clause_candidates': [], 'policy': 'Published RFC candidate plus disclosed implementation resource limits'})
    return cases


async def run(input_root, source_root, suite, output):
    started = time.perf_counter(); output = Path(output); output.mkdir(parents=True, exist_ok=True)
    input_root = Path(input_root).resolve(); source_root = Path(source_root).resolve()
    checker = Checker(input_root, source_root); candidate, runtime = checker.dependencies()
    identities = {name: file_sha(ROOT / name) for name in [
        'json_certificate.py', 'run_certificates.py', 'test_json_certificate.py', 'verify_certificates.py',
        'test_certificate_independent_review.py', 'json_normative_review.py',
        'JSON_NORMATIVE_REVIEW.json', 'JSON_TARGET_CONTRACT.json', 'JSON_REMAINING_OBLIGATIONS.md']}
    cases = load_cases(input_root, suite); corpora = sorted({case['corpus'] for case in cases})
    admitted = admission(len(corpora)); executor = ThreadPoolExecutor(max_workers=admitted['native_thread_slots'])
    loop = asyncio.get_running_loop(); ready = asyncio.Event(); native_original = {}; native_generated = {}
    artifacts = {}; certificates = {}; generated_by_group = {name: [] for name in corpora}
    actors_started = active = peak = 0

    async def originals(group):
        await ready.wait()
        items = [(case['id'], case['source_bytes']) for case in cases if case['corpus'] == group]
        evidence = await loop.run_in_executor(executor, native_batch, input_root, items)
        native_original[group] = evidence
        return {row['id']: row for row in evidence['observations']}

    native_tasks = {group: asyncio.create_task(originals(group)) for group in corpora}

    async def process(case):
        nonlocal actors_started, active, peak
        actors_started += 1; active += 1; peak = max(peak, active)
        try:
            await ready.wait()
            original = (await native_tasks[case['corpus']])[case['id']]
            row = {key: case[key] for key in ['id', 'corpus', 'expected_acceptance', 'intent_origin', 'clause_candidates', 'policy']}
            row.update(source_JSON_sha256=hashlib.sha256(case['source_bytes']).hexdigest(), native_original=original,
                       certificate_id=None, actual_fresh_generated_USL_execution=False,
                       full_standard_qualified=False, native_observations_replayed=False)
            try:
                value = candidate.parse_json(case['source_bytes'])
            except candidate.JSONResourceLimit as error:
                require(case['expected_acceptance'] is not True, 'Required upstream/independent case unexpectedly resource limited')
                require(original['accepted'] is None, 'Native host resource boundary disagrees')
                row.update(outcome='permitted_profile_resource_limit', resource_limit=str(error),
                           acceptance_or_complete_conformance_claim=False, passed=True)
            except candidate.JSONRuleError as error:
                require(case['expected_acceptance'] is not True and original['accepted'] is False,
                        'Candidate/native/independent rejection disagreement')
                row.update(outcome='syntax_or_encoding_rejected', error=str(error), passed=True)
            else:
                require(case['expected_acceptance'] is not False and original['accepted'] is True,
                        'Candidate/native/independent acceptance disagreement')
                intended = case['independent_expected_IR'] if case['corpus'] == 'independent' else original['IR']
                require(typed_equal(value, intended) and typed_equal(original['IR'], intended), 'Fresh original processing differs from independent intended data')
                generated = candidate.emit_usl(value)
                certificate = checker.certify(value, intended, generated)
                verification = checker.verify(certificate, value, intended, generated)
                executed = candidate.run_usl(value)
                require(typed_equal(executed, intended), 'Actual fresh generated USL execution differs from independent intended IR')
                require(candidate.emit_usl(value) == generated, 'Emitter source changed between certificate and actual candidate.run_usl')
                emitted_json = candidate.generate_json(executed, duplicate_policy='preserve')
                require(typed_equal(candidate.parse_json(emitted_json), intended), 'Generated JSON roundtrip changed typed data')
                artifact_id = certificate['generated_source_sha256']; certificate_id = verification['certificate_sha256']
                artifact = {'source_ir': value, 'independent_intended_ir': intended, 'generated_source': generated}
                require(artifact_id not in artifacts or typed_equal(artifacts[artifact_id], artifact), 'Pure artifact content-address collision')
                require(certificate_id not in certificates or typed_equal(certificates[certificate_id], certificate), 'Certificate content-address collision')
                artifacts[artifact_id] = artifact; certificates[certificate_id] = certificate
                generated_by_group[case['corpus']].append((case['id'], emitted_json))
                row.update(outcome='accepted_and_concrete_artifact_translation_validated',
                           independent_intent_IR_sha256=digest(intended), original_candidate_IR_sha256=digest(value),
                           generated_USL_observed_IR_sha256=digest(executed), generated_JSON_sha256=hashlib.sha256(emitted_json).hexdigest(),
                           generated_artifact_id=artifact_id, certificate_id=certificate_id,
                           certificate_verification=verification, actual_fresh_generated_USL_execution=True, passed=True)
            return row
        finally:
            active -= 1

    tasks = [asyncio.create_task(process(case)) for case in cases]
    try:
        await asyncio.sleep(0)
        all_started = actors_started == len(cases)
        ready.set(); records = await asyncio.gather(*tasks)
        async def generated(group):
            native_generated[group] = await loop.run_in_executor(executor, native_batch, input_root, generated_by_group[group])
        await asyncio.gather(*(generated(group) for group in corpora))
    finally:
        executor.shutdown(wait=True)
    generated_observations = {row['id']: row for evidence in native_generated.values() for row in evidence['observations']}
    for row in records:
        if row['certificate_id']:
            observation = generated_observations[row['id']]
            intended = artifacts[row['generated_artifact_id']]['independent_intended_ir']
            require(observation['accepted'] is True and typed_equal(observation['IR'], intended), 'Fresh native generated-JSON processing differs from independent intended IR')
            row['native_generated'] = observation
    require(all(file_sha(ROOT / name) == identity for name, identity in identities.items()), 'Certificate tranche source changed during execution')
    accepted = sum(row['certificate_id'] is not None for row in records)
    native_cases = sum(len(evidence['observations']) for evidence in list(native_original.values()) + list(native_generated.values()))
    summary = {'passed': all_started and all(row['passed'] for row in records), 'all_case_actors_started_concurrently': all_started,
        'case_actors': len(cases), 'peak_live_logical_case_actors': peak, 'physical_USL_interpreter_execution_threads': 1,
        'independent_vectors': 612, 'upstream_cases': 318, 'accepted_case_certificates_checked': accepted,
        'distinct_concrete_certificates': len(certificates), 'distinct_pure_generated_artifacts': len(artifacts),
        'fresh_generated_USL_executions': accepted, 'fresh_native_processing_cases': native_cases,
        'fresh_native_processes': len(native_original) + len(native_generated), 'native_observations_replayed': False,
        'bounded_literal_translation_validator_implemented': True, 'complete_JSON_parser_proved': False,
        'complete_USL_interpreter_proved': False, 'complete_JSON_standard_qualified': False, 'full_standards_qualified': 0,
        'rejected_cases': sum(row['outcome'] == 'syntax_or_encoding_rejected' for row in records),
        'disclosed_resource_limit_cases': sum(row['outcome'] == 'permitted_profile_resource_limit' for row in records),
        'pure_storage_duplicates_avoided': accepted - len(artifacts), 'source_unchanged_during_run': True,
        'seconds_before_export': time.perf_counter() - started}
    write(output / 'CERTIFICATES.json', {'schema': 'usl.JSON.concrete-certificate-CAS.v1', 'certificates': certificates})
    write(output / 'ARTIFACTS.json', {'schema': 'usl.JSON.concrete-generated-artifact-CAS.v1', 'artifacts': artifacts})
    report = {'schema': 'usl.JSON.fresh-concrete-translation-validation.v1', 'summary': summary,
        'source_identities': identities, 'native_reference_sha256': NATIVE_SHA256, 'independent_oracle_sha256': INTENT_SHA256,
        'upstream_suite_commit': SUITE_COMMIT, 'resource_admission': admitted,
        'native_original_execution_receipts': {group: item['identity'] for group, item in native_original.items()},
        'native_generated_execution_receipts': {group: item['identity'] for group, item in native_generated.items()},
        'trusted_base_and_claim_limits': next(iter(certificates.values()))['trusted_assumptions'],
        'does_not_prove': next(iter(certificates.values()))['excludes'], 'records': records}
    write(output / 'RESULTS.json', report)
    summary['seconds_through_primary_artifact_export'] = time.perf_counter() - started
    summary['exported_bytes_before_summary_manifest'] = sum(path.stat().st_size for path in output.iterdir() if path.is_file())
    write(output / 'SUMMARY.json', summary)
    write(output / 'MANIFEST.json', {path.name: {'sha256': file_sha(path), 'bytes': path.stat().st_size}
          for path in sorted(output.iterdir()) if path.is_file() and path.name not in {'MANIFEST.json', 'RUN_COSTS.json'}})
    costs = {'elapsed_through_all_primary_reports_summary_and_manifest_seconds': time.perf_counter() - started,
             'measurement_scope': 'Complete source checks, source retrieval from local corpus, fresh native processes, concrete certificates, USL executions and primary evidence export',
             'excludes': ['Writing this separate cost record', 'Final console reporting and process shutdown'],
             'primary_export_bytes': sum(path.stat().st_size for path in output.iterdir() if path.is_file() and path.name != 'RUN_COSTS.json'),
             'all_external_execution_costs_included': True, 'not_an_all_language_completion_forecast': True}
    write(output / 'RUN_COSTS.json', costs)
    print(json.dumps(summary)); return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, default=DEFAULT_INPUT)
    parser.add_argument('--source-root', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--suite', type=Path, default=Path('/workspace/.onboarding/providers/JSONTestSuite'))
    parser.add_argument('--output', type=Path, default=Path('results'))
    args = parser.parse_args()
    asyncio.run(run(args.input_root, args.source_root, args.suite, args.output))
