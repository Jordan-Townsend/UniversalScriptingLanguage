"""Materialize a separately authored technical review of pinned RFC 8259.

The rationale below was written after reading the complete published RFC and
the existing candidate ledger. Integrity checks bind that review to its inputs;
they are not a parser/generator correctness proof or external certification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

RFC_SHA256 = '61a5378f4255c720beb2a4b4a63b29540147c140f36988bf086291989b4cd2d7'
RFC_URL = 'https://www.rfc-editor.org/rfc/rfc8259.txt'

GRAMMAR_RATIONALE = {
    'JSON-text': 'The production admits one value surrounded by zero or more of the four JSON whitespace characters. The serialized value may be scalar; full-input consumption is necessary.',
    'begin-array': 'The numeric terminal is exactly U+005B. Surrounding ws belongs to the grammar, not arbitrary Unicode whitespace.',
    'begin-object': 'The numeric terminal is exactly U+007B. Its ws factors permit whitespace both before and after the brace.',
    'end-array': 'The numeric terminal is exactly U+005D. This terminal does not itself permit trailing commas before the closing bracket.',
    'end-object': 'The numeric terminal is exactly U+007D; object member sequencing, not this terminal, controls whether a comma may precede it.',
    'name-separator': 'Exactly one U+003A separates a string name and a value, with optional JSON whitespace. Equals signs and unquoted names are outside the published grammar.',
    'value-separator': 'Exactly one U+002C separates adjacent members or elements. The enclosing repetition requires a member/value after each separator.',
    'ws': 'The zero-or-more repetition contains only U+0020, U+0009, U+000A and U+000D. NBSP, form feed and other Unicode spacing characters are not ws.',
    'value': 'All seven syntactic alternatives are represented. false and true share the boolean data type; seven grammar alternatives do not imply seven data-model types.',
    'false': 'The dotted numeric terminals spell the five lowercase ASCII letters exactly. Lowercase hex digits in the RFC notation do not authorize uppercase FALSE.',
    'null': 'The dotted numeric terminals spell lowercase null exactly. The null literal is distinct from the string containing those letters.',
    'true': 'The four numeric terminals spell lowercase true. Prefix matching alone is insufficient: the enclosing grammar must reject trailing letters.',
    'object': 'The optional member-plus-repetition permits an empty object and comma-separated members, with no trailing comma. Duplicate names are grammar-valid despite the separate SHOULD guidance.',
    'member': 'A name must use the string production, followed by a name separator and any JSON value. Object member order is not assigned semantic significance by this production.',
    'array': 'The optional value-plus-repetition permits an empty array and heterogeneous ordered elements. No trailing comma or omitted element is introduced by this grammar.',
    'number': 'The optional minus, mandatory int and optional frac/exp exclude unary plus, hex, NaN and Infinity. A numeric lexeme is not a promise to execute IEEE arithmetic.',
    'decimal-point': 'The decimal separator is U+002E, independent of process locale; comma and other locale-specific separators are not accepted here.',
    'digit1-9': 'The range is the nine ASCII digits U+0031 through U+0039, not the host regular-expression Unicode digit class.',
    'e': 'Only ASCII e and E introduce an exponent. Both are allowed, with identical structural meaning.',
    'exp': 'At least one imported DIGIT follows e and its optional plus/minus. Leading exponent zeros are allowed by the grammar.',
    'frac': 'At least one imported DIGIT follows the decimal point. Fractional leading or trailing zeros are allowed; a bare decimal point is not.',
    'int': 'The integer component is either one zero or a nonzero ASCII digit followed by zero or more DIGITs. It forbids 00 and 01, not 0.001 or 1E01.',
    'minus': 'This is the ASCII hyphen-minus U+002D, not a Unicode mathematical minus sign. The number and exp productions determine where it may occur.',
    'plus': 'This is ASCII U+002B. Its only route into a number is through exp; there is no leading plus route in number.',
    'zero': 'This is ASCII U+0030. Combined with int it prevents multi-digit leading-zero integer components.',
    'string': 'A pair of quotation marks encloses zero or more local char occurrences. The local rule must be used rather than accidentally substituting ABNF core CHAR.',
    'char': 'The published rule contains unescaped or a backslash followed by one of nine alternatives. The u alternative takes exactly four HEXDIGs; the short escapes are case-sensitive numeric terminals.',
    'escape': 'The escape prefix is U+005C reverse solidus. A literal reverse solidus inside a JSON string therefore requires a valid escape sequence.',
    'quotation-mark': 'The delimiter is ASCII U+0022, not single quotes or typographic quotation marks. Quotes as content must be escaped.',
    'unescaped': 'The published ranges exclude U+0000..001F, quote and reverse solidus but include raw solidus, DEL/C1 and U+2028/U+2029. The abstract range includes surrogate code points; strict network UTF-8 disallows raw surrogate encodings, while escaped surrogates remain grammar-valid.',
}

NORMATIVE_RATIONALE = {
    'N01': ('accurate', 'The MUST restricts value alternatives, and its list contains the three literal names. It does not define native program execution or arithmetic on parsed numbers.'),
    'N02': ('accurate_with_scope', 'Lowercase literal spelling is mandatory for the JSON grammar. Section 9 separately permits parser extensions; rejecting every extension is this profile choice, not a requirement imposed on every conforming parser.'),
    'N03': ('accurate_with_scope', 'SHOULD uniqueness is interoperability guidance with BCP14 exception discipline, not a grammar prohibition. A parser must not silently lose duplicate members while claiming lossless preservation. Explicit generator preserve mode needs a documented deliberate exception.'),
    'N04': ('accurate', 'Quote, reverse solidus and U+0000..001F require escaping. Solidus is an optional escape in the published text, not an additional mandatory escape.'),
    'N05': ('accurate_with_scope', 'UTF-8 is mandatory for interchange outside a closed ecosystem. A strict UTF-8 public API is a suitable profile choice; the RFC does not require accepting UTF-16 network data or every closed-ecosystem encoding.'),
    'N06': ('accurate', 'A network generator must not prepend a BOM. A U+FEFF contained inside a quoted string is data and is not prohibited by this statement.'),
    'N07': ('accurate_with_scope', 'Ignoring an initial BOM is an explicitly permitted parser choice. This does not permit arbitrary U+FEFF between tokens or require every parser to ignore a BOM.'),
    'N08': ('needs_limit_qualification', 'The parser MUST accept conforming texts subject to the explicitly discussed implementation limits. The blanket candidate assertion that all five current limits are allowed needs a precise metric/justification, especially value-node and number-lexeme limits; valid over-limit input must remain a resource refusal, not invalid JSON.'),
    'N09': ('accurate_with_scope', 'Extensions are optional. Electing none supports strict syntax validation; a native parser accepting an extension is not automatically an RFC violation, and differential tests must distinguish that policy choice.'),
    'N10': ('accurate_with_scope', 'Every successfully generated text must conform to the grammar. The RFC does not require a generator to accept every arbitrary host object or every possible malformed IR; rejected caller IR is an API-domain issue, not a generated invalid JSON text.'),
}

# Exact short anchors are independent source citations, not copied candidate
# assertions. Each rationale distinguishes RFC text from implementation policy.
PROSE_RATIONALE = {
    'P01': ('JSON can represent four primitive types', 'accurate', 'The introduction defines four primitive and two structured types, an unordered object and ordered array. Retaining source member order is useful representation metadata, not normative object ordering.'),
    'P02': ('The grammatical rules in this document are to be interpreted', 'needs_dependency_closure', 'BCP14 force and ABNF interpretation are correctly identified. DIGIT and HEXDIG come from RFC5234 core rules and must be separately clause-bound; this row alone does not audit those imported definitions.'),
    'P03': ('The reference to ECMA-404 in the previous sentence is normative', 'accurate_with_scope', 'Section 1.2 gives ECMA-404 a special alignment purpose and distinguishes its permitted practices from interoperability advice. It does not import the ECMAScript language or require a JavaScript engine.'),
    'P04': ('A JSON text is a serialized value.', 'accurate', 'This prose and JSON-text jointly permit primitive top-level values and require a single complete value. Concatenated values are not a JSON text.'),
    'P05': ('When the names within an object are not unique', 'accurate_with_scope', 'The RFC warns about unpredictable receiver behavior and lists last-value, rejection and duplicate-preserving implementations. Lossless duplicate retention is a chosen local representation, not guaranteed interoperability.'),
    'P06': ('whether or not they make the ordering of object members visible', 'clarify_guidance_not_must', 'The source describes interoperability when behavior does not depend on order. Candidate wording that applications must not assume order is prudent guidance, not an additional uppercase normative MUST.'),
    'P07': ('There is no requirement that the values in an array be of the same', 'accurate', 'Arrays preserve sequence and permit mixed types. Homogeneous arrays cannot substitute for implementing the complete array value grammar.'),
    'P08': ('int = zero / ( digit1-9 *DIGIT )', 'accurate_with_scope', 'The grammar resolves the broad prose about leading zeros: only multi-digit integer leading zeros are excluded. Verified snapshot erratum7600 clarifies the same reading, but the target here remains the published text.'),
    'P09': ('Numeric values that cannot be represented in the grammar below', 'accurate_with_scope', 'NaN and Infinity are not grammar-valid numbers. Exact lexemes preserve decimal text without committing to IEEE754 conversion or numeric operations; an extension-accepting native parser needs strict comparison settings.'),
    'P10': ('This specification allows implementations to set limits on the range', 'needs_limit_qualification', 'Range and precision limits are expressly allowed. A 1024-character numeric-lexeme cap is a lexical/storage policy, not literally the same thing as a numeric range/precision cap; justify it as a documented text/resource size metric rather than claiming the sentence directly specifies it.'),
    'P11': ('[IEEE754] is generally', 'clarify_conditional_interoperability', 'The RFC discusses common binary64 receiver capabilities and exact agreement within the safe-integer range when that software is used. It does not say exact agreement is impossible outside that range or require binary64 arithmetic in every parser.'),
    'P12': ('Any character may be escaped.', 'accurate', 'The published string grammar permits raw solidus and optional escapes. The retrieved erratum5318 changes that range and is intentionally not adopted into this historical target.'),
    'P13': ('encoding the UTF-16 surrogate pair.', 'accurate_with_scope', 'The RFC gives a two-escape surrogate-pair representation of a non-BMP character. Combining it into one scalar is this IR canonicalization; section8.2 also requires accounting for syntactically permitted unpaired escapes without promising receiver agreement.'),
    'P14': ('MUST be encoded using UTF-8 [RFC3629].', 'accurate_with_scope', 'Strict decoding realizes the selected open-interchange profile. Full RFC3629 dependency validation is a separate obligation, including overlong, surrogate, out-of-range and incomplete encodings.'),
    'P15': ('allows member names and string values to contain bit sequences', 'accurate_with_scope', 'Section8.2 explicitly acknowledges escaped unpaired surrogates and unpredictable software behavior. The profile can retain their code points and escape output without emitting invalid raw UTF-8.'),
    'P16': ('code unit by code unit, are interoperable', 'correct_project_policy_attribution', 'The RFC recommends decoded numerical code-unit equality and gives an escaped-name example. No normalization and using a scalar-canonicalized code-point IR are chosen preservation policies; this paragraph does not define sorting/collation or an independent MUST about normalization.'),
    'P17': ('An implementation may set limits on the size of texts', 'needs_limit_qualification', 'Section9 lists text size, maximum nesting, numeric range/precision and string length/content limits. Boundary tests and visible error classes are project evidence requirements. Depth must be documented as actually implemented, not simply relabeled container_depth40.'),
    'P18': ('The resulting text MUST strictly conform to the JSON grammar.', 'correct_project_policy_attribution', 'Section10 requires valid generated JSON. Avoiding eval is security guidance in section12 and an implementation policy, not an extra generator MUST in section10. Invalid IR refusal is necessary for the chosen API contract.'),
    'P19': ('The media type for JSON text is application/json.', 'accurate_with_scope', 'The registration includes no required/optional parameters, binary encoding considerations, .json and a charset note. A pure bytes parser/generator has no HTTP behavior; a claimed server/transport must separately enforce media handling against the selected published policy.'),
    'P20': ('This generally constitutes an unacceptable security risk', 'correct_project_policy_attribution', 'The RFC explains the eval risk and legal U+2028/U+2029 characters; it does not state an uppercase ban on eval or mandate a particular preallocation algorithm. The parser must still be data-only and resource-safe under the project deployment contract.'),
    'P21': ('Here are three small JSON texts containing only values:', 'accurate', 'The object, array-of-objects and three scalar examples should be covered, but examples do not enumerate all grammar, encodings or semantic edge cases.'),
    'P22': ('[ECMA-404] Ecma International,', 'needs_dependency_closure', 'Seven normative references are listed: ECMA-404, IEEE754, RFC2119, RFC3629, RFC5234, RFC8174 and Unicode. Each needs an applicability/version/authority decision; retrieval metadata and a single summary row do not close the dependency audit.'),
}

SECTION_REVIEW = {
    'Abstract and status': 'Describes language-independent data interchange and Standards Track publication. Publication status is not certification of this implementation; no runtime rule is added here.',
    'Copyright Notice': 'RFC text and extracted code components have IETF Trust legal conditions. Distribution review is separate from whether implementing JSON grammar requires a proprietary runtime license.',
    '1': 'Type/data-model definitions and Unicode citation are represented by P01 and dependency work. Historical JavaScript derivation does not import execution semantics.',
    '1.1': 'BCP14 applies only to uppercase keywords, and ABNF is delegated to RFC5234. The keyword-definition list is metalinguistic and is not ten extra feature obligations.',
    '1.2': 'Authority replacement, special ECMA alignment and future coordination are covered. Coordination duties belong to the standards organizations rather than a parser API.',
    '1.3': 'Historical errata motivate the revision; they are not new independent runtime features to import on top of the published revised grammar.',
    '2': 'All eight local productions in this section and the four allowed whitespace terminals are represented. The one-value top-level rule includes scalars.',
    '3': 'All four local productions and two operative MUST statements are represented; no other literal names are allowed in the JSON grammar.',
    '4': 'Object/member grammar, SHOULD uniqueness and receiver/order caveats are represented. Duplicate acceptance and local lossless behavior remain distinct.',
    '5': 'Array grammar, order and heterogeneous values are represented.',
    '6': 'All ten numeric productions are represented. Number syntax, permitted limits and conditional binary64 interoperability need separate treatment.',
    '7': 'All five string productions and mandatory escaping are represented; imported HEXDIG and Unicode/UTF16 interpretation remain dependency obligations.',
    '8.1': 'Open-interchange UTF-8, network no-BOM and optional input-BOM handling are represented. Closed ecosystems are outside this selected transport profile.',
    '8.2': 'Unpaired-surrogate syntax and interoperability warnings are represented. Accepting an escape is not a promise that arbitrary receivers agree on it.',
    '8.3': 'Decoded code-unit equality guidance is represented. The standard does not supply a general Unicode normalization/collation API.',
    '9': 'Parser acceptance, optional extensions and each named permitted-limit class are represented; actual metric semantics require the qualifications identified in this review.',
    '10': 'Every generated output must conform. The caller IR domain is an implementation contract; the RFC does not require generating every possible text.',
    '11': 'Registration has application/json, no defined parameters, binary encoding, .json and the published charset note. This is a transport-registration boundary, not an HTTP implementation supplied by the parser.',
    '12': 'Eval security guidance and U+2028/U+2029 distinction are covered. Modern ECMAScript behavior is version-dependent and is not used as the JSON acceptance oracle.',
    '13': 'Both composite examples and all three scalar examples are represented as finite acceptance inputs, not as a conformance proof.',
    '14.1': 'All seven normative references identified; the source-body review is complete but the normative-reference closure is not.',
    '14.2': 'Historical RFCs, ECMAScript and prior errata are informative, so they do not silently extend the selected JSON syntax or runtime contract.',
    'Appendix A': 'Changes explain authority, UTF-8 and security revisions; each operational change is already reflected in the main-body obligations.',
    'Contributors and author': 'Attribution/contact information adds no implementation feature obligations.',
}


def digest(data):
    if not isinstance(data, bytes):
        data = json.dumps(data, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()
    return hashlib.sha256(data).hexdigest()


def citation(text, anchor):
    pattern = re.escape(anchor).replace(r'\ ', r'\s+')
    match = re.search(pattern, text)
    if match is None:
        raise ValueError('Review source anchor is absent: ' + anchor)
    return {'document': 'RFC8259-published-December2017', 'document_sha256': RFC_SHA256,
            'anchor': anchor, 'source_line_start': text.count('\n', 0, match.start()) + 1,
            'source_line_end': text.count('\n', 0, match.end()) + 1,
            'matched_source_sha256': digest(text[match.start():match.end()].encode())}


def source_productions(text):
    result = {}
    for match in re.finditer(r'(?m)^[ \t]{3,6}([A-Za-z][A-Za-z0-9-]*)\s*=\s*([^\n]+)', text):
        end = text.find('\n\n', match.end())
        block = text[match.start():end if end >= 0 else len(text)]
        body = block.split('=', 1)[1]
        abnf = ' '.join(' '.join(line.split(';', 1)[0] for line in body.splitlines()).split())
        if match.group(1) in result:
            raise ValueError('Duplicate local production')
        result[match.group(1)] = (abnf, block)
    return result


def review(base, rfc_path, output):
    base, output = Path(base), Path(output)
    rfc_bytes = Path(rfc_path).read_bytes()
    if digest(rfc_bytes) != RFC_SHA256:
        raise ValueError('Published RFC source hash mismatch')
    text = rfc_bytes.decode('utf-8')
    candidate_path = base / 'json-audit/RFC8259_RULE_AUDIT.json'
    candidate = json.loads(candidate_path.read_text())
    if candidate['source_sha256'] != RFC_SHA256:
        raise ValueError('Candidate was audited against another RFC source')
    productions = source_productions(text)
    if set(productions) != set(GRAMMAR_RATIONALE):
        raise ValueError('Local grammar inventory differs from the reviewed source')
    reviews = []
    groups = [('grammar_productions', GRAMMAR_RATIONALE),
              ('uppercase_requirements', NORMATIVE_RATIONALE),
              ('prose_and_interoperability', PROSE_RATIONALE)]
    for group, authored in groups:
        candidates = candidate[group]
        if {row['id'] for row in candidates} != set(authored) or len(candidates) != len(authored):
            raise ValueError('Candidate row inventory is different from the independently reviewed inventory: ' + group)
        for row in candidates:
            rid = row['id']
            if group == 'grammar_productions':
                observed, block = productions[rid]
                if re.sub(r'\s+', '', row['abnf']) != re.sub(r'\s+', '', observed):
                    raise ValueError('Grammar expression differs from pinned source: ' + rid)
                rationale, disposition = authored[rid], 'accurate_published_production'
                anchor = rid + ' ='
                # Production alignment varies. Cite the actual spelling directly.
                anchor = block.splitlines()[0].strip()
                correspondence = row['implementation_correspondence']
            elif group == 'uppercase_requirements':
                disposition, rationale = authored[rid]
                anchor, correspondence = row['quote'], 'Candidate mapping is historical, not newly executed evidence'
            else:
                anchor, disposition, rationale = authored[rid]
                correspondence = 'See source review; no new execution or proof is inferred from this prose row'
            cite = citation(text, anchor)
            cite['section'] = row['section']
            reviews.append({'candidate_group': group, 'candidate_id': rid,
                            'candidate_row_sha256': digest(row), 'source_clause': cite,
                            'review_disposition': disposition, 'review_rationale': rationale,
                            'implementation_traceability_note': correspondence,
                            'implementation_correctness_proved_by_this_review': False})
    source_hash = digest((base / 'json_semantics.py').read_bytes())
    findings = [
        {'id': 'F01', 'severity': 'scope_precision', 'candidate_ids': ['N08', 'P17'],
         'finding': 'container_depth40 is not the actual code predicate. value(depth) begins at root0, rejects depth>40, and increments for every child value. Forty-one nested empty containers can pass; a scalar under41containers cannot.',
         'action': 'Name the metric value_recursion_depth_root_zero_max40 in the target contract, then independently review every boundary and propagation path.'},
        {'id': 'F02', 'severity': 'normative_justification_open', 'candidate_ids': ['N08', 'P10', 'P17'],
         'finding': 'The RFC expressly discusses text size/nesting/numeric range/precision/string limits. Value-node count10000 and number-lexeme1024 are extra resource-size metrics, not literal clauses or arbitrary missing semantics.',
         'action': 'Document and independently review their permitted-size interpretation; otherwise revise limits or keep full acceptance qualification blocked. Never classify over-limit conforming syntax as invalid JSON.'},
        {'id': 'F03', 'severity': 'attribution_correction', 'candidate_ids': ['P06', 'P16', 'P18', 'P20'],
         'finding': 'Rows combine RFC descriptions/guidance with project policies: no normalization, no eval and preallocation checks are not additional uppercase RFC MUST statements.',
         'action': 'Retain the useful policies, but label origin and force accurately; see per-row review rationales.'},
        {'id': 'F04', 'severity': 'dependency_audit_open', 'candidate_ids': ['P02', 'P03', 'P22'],
         'finding': 'Thirty local productions plus ten uppercase statements and22prose summaries do not enumerate every imported normative dependency clause.',
         'action': 'Audit relevant RFC5234, RFC3629, BCP14 and Unicode clauses and the special ECMA-404 alignment reference; record IEEE754 applicability without inventing arithmetic requirements.'},
        {'id': 'F05', 'severity': 'version_policy', 'candidate_ids': ['unescaped', 'P12'],
         'finding': 'The archived official errata snapshot labels5318 Verified Editorial yet changes the raw-solidus range. Published raw solidus is retained by this target.',
         'action': 'Explicitly label historical published-text conformance only; resolve a separately selected current-errata target before claiming it.'},
        {'id': 'F06', 'severity': 'integration_boundary', 'candidate_ids': ['P19'],
         'finding': 'Section11 registers a media type but this parser/generator does not implement HTTP headers, transport negotiation or MIME routing.',
         'action': 'Keep transport integration out of the pure data API claim and create fresh media/protocol tests for any separately claimed server integration.'},
        {'id': 'F07', 'severity': 'distribution_boundary', 'candidate_ids': ['P22'],
         'finding': 'Prior category-inapplicability shorthand about no external licenses must not erase IETF text/extracted-code copyright and redistribution conditions.',
         'action': 'Review applicable notices for any redistributed RFC text or extracted components; grammar implementation does not require a proprietary execution license.'},
    ]
    additional = [
        {'id': 'A01', 'section': '1.1 and14.1', 'obligation': 'Expand imported DIGIT and HEXDIG and audit the used ABNF composition/operator semantics against pinned RFC5234.', 'status': 'open_dependency_clause_audit'},
        {'id': 'A02', 'section': '8.1 and14.1', 'obligation': 'Bind the complete applicable RFC3629 UTF-8 validity rules, including overlongs, surrogate values, maximum scalar and truncation behavior.', 'status': 'open_dependency_clause_audit'},
        {'id': 'A03', 'section': '1.1,4 and14.1', 'obligation': 'Apply RFC2119/RFC8174 force and record deliberate SHOULD uniqueness exceptions without upgrading SHOULD/MAY to MUST.', 'status': 'open_dependency_clause_audit'},
        {'id': 'A04', 'section': '1,1.2,7,8 and14.1', 'obligation': 'Select Unicode authority/version applicability and verify the ECMA-404 syntax-alignment reference; distinguish code units, code points, scalars and noncharacters.', 'status': 'open_dependency_clause_audit'},
        {'id': 'A05', 'section': '6 and14.1', 'obligation': 'Record IEEE754 as conditional interoperability guidance for this lexeme-preserving API; do not fabricate a required JSON arithmetic library.', 'status': 'applicability_review_required'},
        {'id': 'A06', 'section': '11', 'obligation': 'For any claimed transport, bind application/json and published parameter/charset policy to actual MIME/HTTP behavior; no such transport operation is supplied here.', 'status': 'separate_integration_gate_if_claimed'},
        {'id': 'A07', 'section': 'Copyright Notice', 'obligation': 'Check IETF Trust document and extracted-code conditions for the exact redistributed material.', 'status': 'distribution_review_required'},
        {'id': 'A08', 'section': '9', 'obligation': 'Define actual limit metrics and maintain distinct resource-refusal versus invalid-syntax classifications, including the depth and node/lexeme issues in F01/F02.', 'status': 'open_profile_review'},
    ]
    result = {
        'schema': 'usl.json.published-rfc8259.separate-normative-review.v1',
        'review_kind': 'Separately authored full-source technical inventory and interpretation review; not external accreditation or implementation certification',
        'source': {'url': RFC_URL, 'sha256': RFC_SHA256, 'bytes': len(rfc_bytes), 'full_document_read': True},
        'candidate_audit_sha256': digest(candidate_path.read_bytes()),
        'implementation_source': {'file': 'json_semantics.py', 'sha256': source_hash,
                                  'method': 'Static source review; no universal code correctness proof inferred'},
        'reviewed_candidate_rows': reviews,
        'review_counts': {group: len(authored) for group, authored in groups},
        'whole_document_section_review': [{'section': section, 'review_rationale': rationale}
                                          for section, rationale in SECTION_REVIEW.items()],
        'findings': findings, 'additional_explicit_obligations': additional,
        'conclusion': {
            'all_62_candidate_rows_individually_reviewed': len(reviews) == 62,
            'all_30_local_productions_match_published_source': True,
            'all_10_operative_uppercase_statements_represented_in_candidate': True,
            'whole_published_document_checked_for_additional_obligations': True,
            'candidate_prose_requires_scope_and_attribution_corrections': True,
            'normative_dependency_closure_complete': False,
            'complete_rule_to_implementation_to_test_proof_map': False,
            'full_standard_qualified': False,
            'universal_parser_or_generator_correctness_proved': False,
            'official_certification': False,
        },
    }
    target = {
        'schema': 'usl.json.target-contract.v1', 'catalog_id': 'json',
        'category': 'document_processing',
        'authority': {'title': 'The JavaScript Object Notation (JSON) Data Interchange Format',
                      'identifier': 'RFC8259', 'published': 'December2017', 'source_sha256': RFC_SHA256,
                      'source_url': RFC_URL, 'profile_id': 'RFC8259-published-December2017'},
        'errata_policy': {
            'selected': 'Exact published text; no erratum silently patches the grammar',
            'snapshot_sha256': digest((base / 'json-audit/RFC8259_ERRATA_SNAPSHOT.json').read_bytes()),
            'current_errata_conformance_claimed': False,
            '5318': 'Archived official snapshot changes unescaped solidus despite published raw-solidus allowance; retain raw solidus for this target and leave the alternate target unresolved',
        },
        'operation': 'Strict open-interchange UTF-8 JSON parsing, validated tagged-IR generation, and data-only USL literal materialization',
        'parser': {'input': 'UTF-8 bytes or Unicode text strictly UTF-8 encodable',
                   'extensions': 'none', 'initial_bom': 'ignore one initial U+FEFF after UTF-8 decode',
                   'duplicates': 'preserve all ordered member pairs',
                   'numbers': 'preserve exact JSON number lexeme, without floating-point arithmetic',
                   'strings': 'decoded integer codepoint list; combine valid adjacent escaped surrogate pairs and preserve unmatched escaped surrogate values',
                   'complete_input': 'exactly one ws value ws after optional initial BOM',
                   'failure_classes': ['JSONRuleError for syntax/encoding/API errors', 'JSONResourceLimit for disclosed resource refusal']},
        'generator': {'domain': 'Validated canonical tagged IR; unknown tags, malformed shapes, invalid lexemes/codepoints and adjacent uncombined surrogate pairs are rejected',
                      'output': 'UTF-8 JSON bytes with mandatory escapes and no prefix BOM',
                      'duplicates_default': 'reject', 'duplicates_preserve_mode': 'explicit documented SHOULD exception for lossless data transport',
                      'member_order': 'preserve representation order without promising object-order interoperability',
                      'number_spelling': 'preserved exactly', 'unicode_normalization': 'none'},
        'actual_resource_profile': {
            'parser_input_bytes_max': 65536,
            'value_recursion_depth_root_zero_max': 40,
            'value_nodes_max': 10000,
            'decoded_string_codepoints_max': 8192,
            'number_lexeme_characters_max': 1024,
            'generator_output_bytes_limit': 'No explicit65536-byte bound; generator validates IR/tree limits, so output-size equality is not promised',
            'limit_interpretation_review_complete': False,
            'known_label_correction': 'Do not describe root-zero value recursion depth as an exact maximum40nested containers',
        },
        'equivalence_contract': {
            'parse_generate': 'For supported canonical IR, parse(generate(IR,preserve)) == IR with exact number spellings, pair order/duplicates and string codepoint lists',
            'source_roundtrip': 'Parsing then generating preserves the chosen IR, not insignificant whitespace, escape spelling, original BOM or byte-for-byte source text',
            'usl_materialization': 'Generated USL binds document to the same validated tagged IR under the exact USL runtime; native JSON has no program execution semantics',
            'nondeterministic_or_foreign_receivers': 'No duplicate-member, unpaired-surrogate or numeric-capability agreement beyond the explicit native comparison domain is claimed',
        },
        'not_defined_by_rfc8259': {
            'language_execution_library_threads_or_abi': 'RFC sections1,9,10 define data interchange and parse/generate operations, not a programming execution model, standard executable library, thread model or language ABI',
            'project_interfaces': 'Python/USL API boundaries and host runtime behavior still require project integration evidence; absence of RFC semantics does not auto-complete those gates',
            'http_or_device_host': 'No server, protocol stack or real-device execution is supplied by this pure data API'},
        'claims': {'published_body_inventory_reviewed': True, 'normative_dependency_closure_complete': False,
                   'full_standard_qualified': False, 'universal_translation_proved': False,
                   'official_certification': False},
    }
    output.mkdir(parents=True, exist_ok=True)
    for name, value in [('JSON_NORMATIVE_REVIEW.json', result), ('JSON_TARGET_CONTRACT.json', target)]:
        (output / name).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True) + '\n')
    return result, target


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', required=True)
    parser.add_argument('--rfc-text', required=True)
    parser.add_argument('--output', default=str(Path(__file__).resolve().parent))
    args = parser.parse_args()
    review(args.base, args.rfc_text, args.output)
    print(json.dumps({'review_rows': 62, 'local_productions': 30,
                      'dependency_closure_complete': False, 'full_standard_qualified': False}))


if __name__ == '__main__':
    main()
