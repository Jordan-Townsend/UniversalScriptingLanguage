"""Recheck saved concrete certificates and original contracts without replaying native receipts."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

from json_certificate import Checker, DEFAULT_INPUT, DEFAULT_SOURCE, digest, file_sha, require, typed_equal
from run_certificates import load_cases

ROOT = Path(__file__).resolve().parent


def verify_saved(output, input_root=DEFAULT_INPUT, source_root=DEFAULT_SOURCE,
                 suite=Path('/workspace/.onboarding/providers/JSONTestSuite')):
    output = Path(output).resolve()
    manifest = json.loads((output / 'MANIFEST.json').read_text())
    for name, identity in manifest.items():
        path = (output / name).resolve()
        require(path.is_relative_to(output) and path.is_file(), 'Unsafe or missing saved report path')
        require(file_sha(path) == identity['sha256'] and path.stat().st_size == identity['bytes'], 'Saved evidence file changed')
    report = json.loads((output / 'RESULTS.json').read_text())
    artifacts = json.loads((output / 'ARTIFACTS.json').read_text())['artifacts']
    certificates = json.loads((output / 'CERTIFICATES.json').read_text())['certificates']
    for name, identity in report['source_identities'].items():
        path = (ROOT / name).resolve()
        require(path.is_relative_to(ROOT) and file_sha(path) == identity, 'Recorded checker/runner/test source changed')
    checker = Checker(input_root, source_root); candidate, runtime = checker.dependencies()
    cases = {case['id']: case for case in load_cases(input_root, suite)}
    rows = {row['id']: row for row in report['records']}
    require(len(rows) == len(report['records']) == len(cases) == 930 and set(rows) == set(cases), 'Saved case coverage changed')
    accepted = rejected = limited = 0; used_certificates = set(); used_artifacts = set()
    for name, case in cases.items():
        row = rows[name]
        require(hashlib.sha256(case['source_bytes']).hexdigest() == row['source_JSON_sha256'], 'Original JSON source bytes changed')
        require(row['expected_acceptance'] is case['expected_acceptance'] and row['corpus'] == case['corpus'], 'Original intent contract changed')
        native_original = row['native_original']
        try:
            source_ir = candidate.parse_json(case['source_bytes'])
        except candidate.JSONResourceLimit:
            limited += 1
            require(row['outcome'] == 'permitted_profile_resource_limit' and native_original['accepted'] is None
                    and row['certificate_id'] is None, 'Saved resource outcome changed')
        except candidate.JSONRuleError:
            rejected += 1
            require(row['outcome'] == 'syntax_or_encoding_rejected' and native_original['accepted'] is False
                    and row['certificate_id'] is None, 'Saved rejection outcome changed')
        else:
            accepted += 1
            require(row['outcome'] == 'accepted_and_concrete_artifact_translation_validated', 'Saved acceptance outcome changed')
            artifact_id = row['generated_artifact_id']; certificate_id = row['certificate_id']
            artifact = artifacts[artifact_id]; certificate = certificates[certificate_id]
            intended = case['independent_expected_IR'] if case['corpus'] == 'independent' else native_original['IR']
            generated = artifact['generated_source']
            require(typed_equal(artifact['source_ir'], source_ir)
                    and typed_equal(artifact['independent_intended_ir'], intended)
                    and typed_equal(native_original['IR'], intended), 'Saved artifact no longer matches independently supplied contract')
            require(candidate.emit_usl(source_ir) == generated and hashlib.sha256(generated.encode()).hexdigest() == artifact_id,
                    'Saved generated artifact differs from actual pinned emitter')
            checked = checker.verify(certificate, source_ir, intended, generated)
            require(checked['certificate_sha256'] == certificate_id and digest(certificate) == certificate_id,
                    'Saved certificate CAS identity changed')
            require(row['native_generated']['accepted'] is True and typed_equal(row['native_generated']['IR'], intended),
                    'Historical generated-native observation disagrees with the external contract')
            require(row['generated_USL_observed_IR_sha256'] == digest(intended), 'Historical generated-USL observed value identity differs')
            used_certificates.add(certificate_id); used_artifacts.add(artifact_id)
    require(used_certificates == set(certificates) and used_artifacts == set(artifacts), 'Orphaned or missing saved concrete certificate/artifact')
    require((accepted, rejected, limited) == (626, 296, 8), 'Saved execution partition changed')
    return {'passed': True, 'original_contracts_rechecked': len(cases), 'concrete_certificate_checks': accepted,
            'distinct_certificates_rechecked': len(used_certificates), 'distinct_artifacts_rechecked': len(used_artifacts),
            'current_native_executions': 0, 'current_generated_USL_executions': 0,
            'historical_receipts_reused_as_fresh_evidence': False, 'full_standards_qualified': 0}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('results'))
    parser.add_argument('--input-root', type=Path, default=DEFAULT_INPUT)
    parser.add_argument('--source-root', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--suite', type=Path, default=Path('/workspace/.onboarding/providers/JSONTestSuite'))
    args = parser.parse_args()
    print(json.dumps(verify_saved(args.output, args.input_root, args.source_root, args.suite)))
