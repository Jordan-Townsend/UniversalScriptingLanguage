"""Adversarial concrete translation validation, independently authored inputs."""
import ast
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from json_certificate import CertificateError, Checker, LIMITS, typed_equal, validate_ir


class ConcreteCertificateTests(unittest.TestCase):
    def setUp(self):
        self.checker = Checker()
        self.ir = ['object', [
            [[97], ['number', '-0']], [[97], ['number', '1.00e+02']],
            [[122], ['array', [['boolean', True], ['string', [0xD800, 0, 0x1D11E]], ['null']]]],
        ]]
        self.source = self.checker.dependencies()[0].emit_usl(self.ir)

    def test_real_emitter_source_and_exact_types_are_checked(self):
        certificate = self.checker.certify(self.ir, copy.deepcopy(self.ir), self.source)
        self.assertTrue(self.checker.verify(certificate, self.ir, self.ir, self.source)['verified'])
        self.assertFalse(certificate['full_standard_qualified'])
        self.assertEqual(certificate['structural_derivation']['list_nodes'], 16)

    def test_code_injection_extra_statements_calls_and_effects_are_rejected(self):
        for source in [
            self.source + 'print("side effect")\n', self.source + 'let extra = 1\n',
            'let document = read_file("secret")\n',
            'let document = ["string", [ord("a")]]\n',
            'let document = ["string", [97]]; print("side effect")\n',
            'let document = ["null"]\nwhile True:\n    pass\n',
        ]:
            with self.subTest(source=source), self.assertRaises(CertificateError):
                self.checker.certify(self.ir, self.ir, source)

    def test_tuple_comprehension_name_and_expression_rejected_despite_equal_values(self):
        for source in [
            'let document = ("null",)\n',
            'let document = ["null"] + []\n',
            'let document = [x for x in ["null"]]\n',
            'let document = ["boolean", bool(1)]\n',
            'let document = ["boolean", 1 == 1]\n',
        ]:
            with self.subTest(source=source), self.assertRaises(CertificateError):
                self.checker.certify(['null'], ['null'], source)

    def test_boolean_and_integer_are_never_interchangeable(self):
        self.assertFalse(typed_equal(['boolean', True], ['boolean', 1]))
        self.assertFalse(typed_equal({'count': 1}, {'count': True}))
        self.assertFalse(typed_equal({1: 'value'}, {True: 'value'}))
        for value in [['boolean', 1], ['string', [True]], ['number', 1], ['number', True]]:
            with self.subTest(value=value), self.assertRaises(CertificateError):
                self.checker.certify(value, value)
        with self.assertRaises(CertificateError):
            self.checker.certify(['boolean', True], ['boolean', True], 'let document = ["boolean", 1]\n')

    def test_lexemes_order_and_duplicates_are_observable(self):
        for intended in [
            ['object', list(reversed(self.ir[1]))],
            ['object', self.ir[1][1:]],
            ['object', [[self.ir[1][0][0], ['number', '0']]] + self.ir[1][1:]],
        ]:
            with self.subTest(intended=intended), self.assertRaises(CertificateError):
                self.checker.certify(self.ir, intended, self.source)
        with self.assertRaises(CertificateError):
            self.checker.certify(['number', '1.00'], ['number', '1.0'])

    def test_source_and_intended_ir_are_external_to_certificate(self):
        certificate = self.checker.certify(self.ir, self.ir, self.source)
        changed = copy.deepcopy(self.ir); changed[1][0][1] = ['number', '9']
        with self.assertRaises(CertificateError):
            self.checker.verify(certificate, self.ir, changed, self.source)
        with self.assertRaises(CertificateError):
            self.checker.verify(certificate, changed, changed, self.source)

    def test_tampered_hashes_success_flags_and_derivation_are_rejected(self):
        certificate = self.checker.certify(self.ir, self.ir, self.source)
        variants = []
        for key in ['source_IR_sha256', 'independent_intent_IR_sha256', 'generated_source_sha256', 'generated_AST_sha256']:
            changed = copy.deepcopy(certificate); changed[key] = '0' * 64; variants.append(changed)
        changed = copy.deepcopy(certificate); changed['passed'] = True; variants.append(changed)
        changed = copy.deepcopy(certificate); changed['full_standard_qualified'] = True; variants.append(changed)
        changed = copy.deepcopy(certificate); changed['full_standard_qualified'] = 0; variants.append(changed)
        changed = copy.deepcopy(certificate); changed['preserves_exact_types_number_lexemes_member_order_and_duplicates'] = 1; variants.append(changed)
        changed = copy.deepcopy(certificate); changed['structural_derivation']['constant_nodes'] = True; variants.append(changed)
        for changed in variants:
            with self.subTest(changed=changed), self.assertRaises(CertificateError):
                self.checker.verify(changed, self.ir, self.ir, self.source)

    def test_runtime_checker_and_translator_bindings_recomputed(self):
        certificate = self.checker.certify(self.ir, self.ir, self.source)
        for key in ['checker_source_sha256', 'USL_runtime_source_sha256', 'JSON_translator_source_sha256', 'assumed_Constant_List_branch_AST_sha256']:
            changed = copy.deepcopy(certificate); changed['bindings'][key] = 'f' * 64
            with self.subTest(key=key), self.assertRaises(CertificateError):
                self.checker.verify(changed, self.ir, self.ir, self.source)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); (root / 'json_semantics.py').write_text('# replaced compiler\n')
            with self.assertRaisesRegex(CertificateError, 'translator source changed'):
                Checker(root).certify(['null'], ['null'])
            (root / 'usl_systems').mkdir(); (root / 'usl_systems/language.py').write_text('# replaced runtime\n')
            with self.assertRaisesRegex(CertificateError, 'runtime changed'):
                Checker(source_root=root).certify(['null'], ['null'])

    def test_semantically_equal_source_still_has_its_own_binding(self):
        certificate = self.checker.certify(self.ir, self.ir, self.source)
        with self.assertRaises(CertificateError):
            self.checker.verify(certificate, self.ir, self.ir, self.source + '// extra harmless comment\n')
        second = self.checker.certify(self.ir, self.ir, self.source + '// extra harmless comment\n')
        self.assertNotEqual(certificate['generated_source_sha256'], second['generated_source_sha256'])

    def test_resource_bounds_cycles_and_ir_shape_errors_fail_closed(self):
        cycle = ['array', []]; cycle[1].append(cycle)
        for value in [cycle, ['string', [0x110000]], ['string', [0xD800, 0xDC00]],
                      ['string', [1] * (LIMITS['string_codepoints'] + 1)],
                      ['number', '1' * (LIMITS['number_characters'] + 1)], ['number', '01'],
                      ['number', 'NaN'], ['null', 0], ['object', [[[1], ('null',)]]]]:
            with self.subTest(value=str(value)[:50]), self.assertRaises(CertificateError):
                validate_ir(value)
        with self.assertRaisesRegex(CertificateError, 'byte budget'):
            self.checker.certify(['null'], ['null'], ' ' * (LIMITS['generated_source_utf8_bytes'] + 1))

    def test_literal_ast_rejects_wrong_target_and_non_data_constants(self):
        for source in ['let other = ["null"]\n', 'let document = other = ["null"]\n',
                       'let document = ["string", [97.0]]\n', 'let document = ["string", [-1]]\n',
                       'let document = ["null", None]\n']:
            with self.subTest(source=source), self.assertRaises(CertificateError):
                self.checker.certify(['null'], ['null'], source)


if __name__ == '__main__':
    unittest.main()
