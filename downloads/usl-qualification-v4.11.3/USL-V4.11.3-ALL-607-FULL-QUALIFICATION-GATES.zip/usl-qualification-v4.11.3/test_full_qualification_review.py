"""Independent adversarial review of the all-ID qualification gate runner.

These tests exercise false promotion, omissions, misclassification and extension
inputs. They do not claim language conformance or verify language implementations.
"""
import asyncio
import contextlib
import copy
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from full_qualification import closure_errors, decide, execute, load_entries, verify_input
from gate_plans import DIMENSION_REQUIREMENTS

ROOT = Path(__file__).resolve().parent
INPUT_ROOT = Path('/workspace/usl-planning-v4.11.2')
SOURCE_ROOT = Path('/workspace/usl-v4.10.0-clean-test')


def forged_task(status='verified'):
    task = {name: True for name in ['target_pinned', 'normative_inventory_closed',
        'full_profile_semantics_verified', 'translation_refinement_verified',
        'independent_full_review_verified', 'release_reproducibility_verified',
        'full_profile_verifier_installed']}
    task['gates'] = [{'dimension': name, 'leaves': [{'requirement': requirement, 'status': status}
        for requirement in requirements]} for name, requirements in DIMENSION_REQUIREMENTS.items()]
    return task


class AdversarialPromotionReview(unittest.TestCase):
    def assert_not_qualified_without_evidence(self, task):
        try:
            result, receipt = decide(task, (ROOT / 'qualification.usl').read_text())
        except ValueError:
            return
        self.assertFalse(result['full_standard_qualified'],
            'Caller flags and status strings are not a registered whole-profile verification result')

    def test_all_true_flags_do_not_establish_a_language_implementation(self):
        self.assert_not_qualified_without_evidence(forged_task())

    def test_all_not_applicable_without_authoritative_reviews_cannot_vacuously_qualify(self):
        self.assert_not_qualified_without_evidence(forged_task('verified_not_applicable'))

    def test_direct_usl_execution_cannot_qualify_forged_host_inputs(self):
        from usl_systems.language import Interpreter
        for status in ['verified', 'verified_not_applicable']:
            task = forged_task(status)
            observed = Interpreter(capabilities={'qualification_inputs': lambda: task},
                timeout=2, max_ops=20000).run((ROOT / 'qualification.usl').read_text()).variables['result']
            self.assertFalse(observed['full_standard_qualified'])

    def test_unknown_results_never_become_a_verified_leaf(self):
        task = forged_task('unknown')
        task['full_profile_verifier_installed'] = False
        result, receipt = decide(task, (ROOT / 'qualification.usl').read_text())
        self.assertEqual(result['verified_leaves'], 0)
        self.assertEqual(result['open_leaves'], 48)
        self.assertFalse(result['full_standard_qualified'])

    def test_missing_dimension_and_replaced_duplicate_leaf_are_rejected(self):
        missing = forged_task(); missing['gates'].pop()
        with self.assertRaises(ValueError):
            decide(missing, (ROOT / 'qualification.usl').read_text())
        duplicate = forged_task()
        duplicate['gates'][0]['leaves'][1] = copy.deepcopy(duplicate['gates'][0]['leaves'][0])
        with self.assertRaises(ValueError):
            decide(duplicate, (ROOT / 'qualification.usl').read_text())

    def test_structure_helper_does_not_claim_to_execute_a_checker(self):
        # A structurally complete document can receive no structural errors. It
        # remains caller-supplied data, and this function awards no qualification.
        target = {'exact_version': 'invented-v1', 'specification_sha256': 'not-a-real-hash',
                  'inventory_independently_reviewed': True, 'inventory_closed': True,
                  'normative_clause_ids': ['clause-1']}
        clauses = [{'clause_id': 'clause-1', 'source_locator': 'invented',
            'applicability': 'applicable', 'implementation_sha256': 'invented',
            'implementation_locator': 'invented', 'independent_tests': ['invented'],
            'native_observations': ['invented'], 'proof_scope': 'whole_clause',
            'trusted_checker_verified': True}]
        errors = closure_errors(target, clauses)
        self.assertIsInstance(errors, list)
        self.assertNotIsInstance(errors, dict)
        self.assertIn('structure', closure_errors.__doc__.lower())
        self.assertIn('no standards qualification', closure_errors.__doc__.lower())


class CatalogAndIdentityReview(unittest.TestCase):
    def test_extension_cannot_supply_passed_or_qualification_fields(self):
        for key in ['passed', 'verified', 'scoped', 'full_standard_qualified', 'evidence', 'gate_results', 'original_catalog']:
            with self.subTest(key=key), self.assertRaises(ValueError):
                load_entries(INPUT_ROOT, [{'catalog_id': 'review-extension', 'category_candidate': 'source_program', key: True}])

    def test_duplicate_and_ambiguous_extension_inputs_are_rejected(self):
        for extra in [
            [{'catalog_id': 'json', 'category_candidate': 'source_program'}],
            [{'catalog_id': '../untrusted', 'category_candidate': 'source_program'}],
            [{'catalog_id': 'new-language', 'category_candidate': 'unsupported'}],
            [{'catalog_id': 'repeated', 'category_candidate': 'source_program'},
             {'catalog_id': 'repeated', 'category_candidate': 'source_program'}],
        ]:
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                load_entries(INPUT_ROOT, extra)

    def test_transcript_records_and_data_are_not_classified_as_program_execution(self):
        records = {row['catalog_id']: row for row in load_entries(INPUT_ROOT)}
        self.assertEqual(len(records), 607)
        self.assertEqual(records['json']['category_candidate'], 'document_processing')
        self.assertEqual(records['antlr-python']['category_candidate'], 'grammar_schema_or_interface')
        self.assertEqual(records['llvm']['category_candidate'], 'assembly_or_ir')
        for row in records.values():
            if row['family'] == 'Transcripts, logs and protocol messages':
                self.assertEqual(row['category_candidate'], 'transcript_log_or_protocol')

    def test_pinned_manifest_and_first_source_cannot_be_rewritten_to_match_each_other(self):
        manifest = json.loads((INPUT_ROOT / 'MANIFEST.json').read_text())
        first = next(iter(manifest['files']))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'MANIFEST.json').write_bytes((INPUT_ROOT / 'MANIFEST.json').read_bytes())
            target = root / first; target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((INPUT_ROOT / first).read_bytes() + b' changed')
            with self.assertRaisesRegex(ValueError, 'integrity failure'):
                verify_input(root)
            manifest['files'][first]['sha256'] = '0' * 64
            (root / 'MANIFEST.json').write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError, 'pinned v4.11.2'):
                verify_input(root)

    def test_real_all_id_execution_with_new_categories_has_no_omissions_or_na_awards(self):
        extras = [
            {'catalog_id': 'review-new-source', 'category_candidate': 'source_program',
             'semantic_focus': ['fake complete description is not evidence']},
            {'catalog_id': 'review-new-format', 'category_candidate': 'document_processing'},
        ]
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()):
            output = Path(directory)
            summary = asyncio.run(execute(INPUT_ROOT, SOURCE_ROOT, output, extras))
            result = json.loads((output / 'ALL_ID_QUALIFICATION.json').read_text())
            records = {row['catalog_id']: row for row in result['records']}
            self.assertEqual(len(records), 609)
            self.assertEqual(summary['original_IDs'], 606)
            self.assertEqual(summary['full_standards_qualified'], 0)
            self.assertEqual(summary['USL_qualification_executions'], 609)
            self.assertEqual(summary['gate_checks'], 609 * 18)
            self.assertEqual(summary['requirement_groups_checked'], 609 * 48)
            self.assertFalse(summary['historical_evidence_is_fresh_execution'])
            self.assertEqual(summary['native_executions_in_this_gate_audit'], 0)
            for row in records.values():
                self.assertFalse(row['full_standard_qualified'])
                self.assertFalse(row['target_manifest']['category_review_complete'])
                self.assertFalse(row['target_manifest']['qualified_as_entire_standard'])
                self.assertEqual(len(row['gates']), 18)
                self.assertEqual(row['USL_decision']['open_leaves'], 48)
                self.assertEqual(row['USL_decision']['verified_not_applicable_leaves'], 0)
            for identifier in ['review-new-source', 'review-new-format']:
                self.assertFalse(records[identifier]['existing_bounded_profile'])
                self.assertEqual(records[identifier]['next_required_action'], 'retrieve_correct_upstream_specification_and_audit_identity')


if __name__ == '__main__':
    unittest.main()
