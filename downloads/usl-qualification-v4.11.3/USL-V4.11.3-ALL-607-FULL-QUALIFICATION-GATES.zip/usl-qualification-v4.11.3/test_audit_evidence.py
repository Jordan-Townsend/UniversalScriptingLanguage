"""Adversarial checks for integrity auditing and overclaim prevention."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

from audit_evidence import audit, sha, validate_json_receipts, verify_manifest

INPUT_ROOT = Path('/workspace/usl-planning-v4.11.2')
SOURCE_ROOT = Path('/workspace/usl-v4.10.0-clean-test')


class ManifestIntegrityTests(unittest.TestCase):
    def fixture(self, root):
        (root / 'receipt.json').write_text('{"passed": true}\n')
        manifest = {'version': '4.11.2', 'files': {'receipt.json': {
            'sha256': sha(root / 'receipt.json'), 'bytes': (root / 'receipt.json').stat().st_size}}}
        (root / 'MANIFEST.json').write_text(json.dumps(manifest))
        return manifest

    def test_changes_are_rejected_even_if_passed_flags_remain_true(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); self.fixture(root)
            self.assertEqual(verify_manifest(root)['verified_files'], 1)
            (root / 'receipt.json').write_text('{"passed": true, "invented": 1}\n')
            with self.assertRaisesRegex(ValueError, 'artifact changed'):
                verify_manifest(root)

    def test_manifest_path_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); manifest = self.fixture(root)
            manifest['files']['../receipt.json'] = manifest['files'].pop('receipt.json')
            (root / 'MANIFEST.json').write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError, 'unsafe artifact'):
                verify_manifest(root)


class JSONContractAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path[:0] = [str(INPUT_ROOT), str(INPUT_ROOT / 'json-audit'), str(SOURCE_ROOT)]
        from independent_cases import all_cases
        cls.cases = all_cases()
        cls.upstream = json.loads((INPUT_ROOT / 'json-results/qualification.json').read_text())
        cls.independent = json.loads((INPUT_ROOT / 'json-results/independent-intent.json').read_text())
        cls.rules = json.loads((INPUT_ROOT / 'json-audit/RFC8259_RULE_AUDIT.json').read_text())

    def check(self, upstream=None, independent=None, rules=None):
        return validate_json_receipts(INPUT_ROOT, upstream or self.upstream,
                                      independent or self.independent, rules or self.rules, self.cases)

    def test_each_independent_contract_and_all_normative_rows_checked(self):
        result = self.check()
        self.assertEqual(result['enumerated_normative_inventory_records'], 62)
        self.assertEqual(result['independent_contracts_recomputed'], 612)
        self.assertEqual(result['historical_native_processing_cases'], 1556)
        self.assertEqual(result['current_audit_native_executions'], 0)

    def test_missing_case_cannot_be_hidden_by_passed_summary(self):
        receipt = copy.deepcopy(self.independent)
        receipt['records'].pop()
        with self.assertRaisesRegex(ValueError, 'coverage changed'):
            self.check(independent=receipt)

    def test_forged_native_observation_cannot_be_hidden_by_passed_flags(self):
        receipt = copy.deepcopy(self.upstream)
        accepted = next(row for row in receipt['records'] if row['accepted'] is True)
        accepted['native_generated']['IR'] = ['null'] if accepted['IR'] != ['null'] else ['boolean', True]
        with self.assertRaisesRegex(ValueError, 'successful receipt'):
            self.check(upstream=receipt)

    def test_changed_intent_is_rejected(self):
        receipt = copy.deepcopy(self.independent)
        receipt['records'][0]['expected_acceptance'] = not receipt['records'][0]['expected_acceptance']
        with self.assertRaisesRegex(ValueError, 'contract changed'):
            self.check(independent=receipt)

    def test_candidate_inventory_cannot_be_promoted_by_flag(self):
        rules = copy.deepcopy(self.rules)
        rules['whole_standard_qualification'] = True
        with self.assertRaisesRegex(ValueError, 'promoted to qualification'):
            self.check(rules=rules)

    def test_duplicate_normative_obligation_rejected(self):
        rules = copy.deepcopy(self.rules)
        rules['grammar_productions'][-1]['id'] = rules['grammar_productions'][0]['id']
        with self.assertRaisesRegex(ValueError, 'inventory missing or duplicated'):
            self.check(rules=rules)

    def test_erratum_cannot_be_silently_discarded(self):
        rules = copy.deepcopy(self.rules)
        rules['errata_policy']['unresolved'] = []
        with self.assertRaisesRegex(ValueError, 'erratum decision disappeared'):
            self.check(rules=rules)


class WholeCatalogAuditTests(unittest.TestCase):
    def test_real_receipts_cover_all_catalog_ids_without_promoting_any_standard(self):
        result = audit(INPUT_ROOT, SOURCE_ROOT)
        records = {row['catalog_id']: row for row in result['records']}
        self.assertEqual(len(records), 607)
        self.assertEqual(result['manifest_integrity']['verified_files'], 223)
        self.assertEqual(result['summary']['deep_receipt_audited_IDs'], 5)
        self.assertFalse(any(row['full_standard_qualified'] for row in records.values()))
        self.assertEqual(records['json']['scope_kind'], 'full_candidate')
        self.assertEqual(records['json']['verified_facts']['upstream_source_bodies_hash_rechecked'], 318)
        self.assertFalse(records['usl']['historical_scoped_claim'])
        self.assertTrue(records['usl']['verified_facts']['runtime_used_by_other_profiles_does_not_promote_USL'])
        self.assertEqual(records['antlr-python']['verified_facts']['historical_native_processing_cases'], 2838)
        self.assertTrue(all(row['current_audit_native_executions'] == 0 for row in records.values()))
        self.assertTrue(all(row['missing_gates'] for row in records.values()))


if __name__ == '__main__':
    unittest.main()
