"""Apply evidence-backed full-profile gates to every catalog ID and extensions.

This runner creates and evaluates qualification obligations. It does not invent
normative audits, implement missing language semantics, certify a standards body,
or promote bounded examples into a full-language guarantee.
"""
from __future__ import annotations
import argparse
import asyncio
import collections
import hashlib
import json
from pathlib import Path
import re
import sys
import time

ROOT=Path(__file__).resolve().parent
DEFAULT_INPUT=Path('/workspace/usl-planning-v4.11.2')
BASE_ARCHIVE_SHA256='0ec8164764712255e29ea9a22f887e6629bcd21bf32d93d5974cccc4808f39ae'
BASE_MANIFEST_SHA256='f418a71ad6a069fa0baeec26fd8705c3e9990c7f48011e3283154f10c53b4e9c'
SUPPORT_DIMENSIONS={
 'identity':['specification','reproducibility'],'grammar':['syntax'],'static_semantics':['semantics','typed_ir'],
 'dynamic_semantics':['semantics'],'numbers_and_data':['semantics'],'concurrency':[],
 'runtime_apis':['libraries'],'interoperability':['interoperability'],'backend':['native_execution'],
 'conformance':['conformance'],'performance':[],'safety':['reproducibility'],
 'portability':['platform'],'certification':['independent_review'],'parser_cases':['syntax'],
 'native_execution':['native_execution'],'semantic_translation':['translation','typed_ir'],
 'intent_verification':['independent_intent','proof']}


def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def digest(value):return hashlib.sha256(encoded(value)).hexdigest()
def file_sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,value):Path(path).write_bytes(encoded(value)+b'\n')


def verify_input(input_root):
    input_root=Path(input_root).resolve();path=input_root/'MANIFEST.json'
    if file_sha(path)!=BASE_MANIFEST_SHA256:raise ValueError('Input is not the pinned v4.11.2 source snapshot')
    manifest=json.loads(path.read_text())
    for name,record in manifest['files'].items():
        target=(input_root/name).resolve()
        if not target.is_relative_to(input_root) or not target.is_file() or file_sha(target)!=record['sha256'] or target.stat().st_size!=record['bytes']:
            raise ValueError('Input source integrity failure: '+name)
    return {'source_manifest_sha256':BASE_MANIFEST_SHA256,'source_archive_sha256':BASE_ARCHIVE_SHA256,
            'files_freshly_hash_checked':len(manifest['files']),'native_executions_performed_by_hash_check':0}


def load_entries(input_root,additional=None):
    from gate_plans import DIMENSION_REQUIREMENTS,CATEGORY_CONTRACTS
    catalog=json.loads((Path(input_root)/'joined-results/catalog.json').read_text())
    scope=json.loads((Path(input_root)/'scope-all-results/ALL_IDS.json').read_text())
    current=json.loads((Path(input_root)/'current-scope-results/CURRENT_SCOPE.json').read_text())
    entries=catalog['entries'];by_scope={r['catalog_id']:r for r in scope['records']};by_current={r['catalog_id']:r for r in current['records']}
    ids={r['catalog_id'] for r in entries}
    if len(entries)!=607 or len(ids)!=607 or set(by_scope)!=ids or set(by_current)!=ids or sum(r['original_catalog'] for r in entries)!=606:
        raise ValueError('All606 original IDs plus USL must join exactly')
    for row in entries:
        if {d['dimension']:d['normative_requirements'] for d in row['obligation_dimensions']}!=DIMENSION_REQUIREMENTS:
            raise ValueError('Original48 requirement groups were changed or lost: '+row['catalog_id'])
        row['category_candidate']=by_scope[row['catalog_id']]['category_proposal']
        row['historical_category_proposal']=row['category_candidate']
        if row['family']=='Transcripts, logs and protocol messages':row['category_candidate']='transcript_log_or_protocol'
        row['semantic_focus']=by_current[row['catalog_id']]['specific_semantic_focus']
        row['host_candidate']=by_current[row['catalog_id']]['host_candidate']
        row['retrieved_reference_candidate']=bool(by_current[row['catalog_id']]['available_reference_body_objects'] or by_current[row['catalog_id']]['recovered_candidate_reference'])
    for extra in additional or []:
        identifier=extra.get('catalog_id')
        if not isinstance(identifier,str) or re.fullmatch(r'[a-zA-Z0-9_.+:\-]{1,200}',identifier) is None or identifier in ids:
            raise ValueError('Invalid or duplicate extra catalog ID')
        if extra.get('category_candidate') not in CATEGORY_CONTRACTS:raise ValueError('Extra ID needs an explicit supported category candidate')
        forbidden={'full_standard_qualified','passed','scoped','verified','gate_results','evidence','original_catalog'}
        if forbidden & extra.keys():raise ValueError('An extra catalog record cannot self-declare qualification or evidence')
        row={'catalog_id':identifier,'original_catalog':False,'family':extra.get('family','Extension pending family audit'),
             'scoped':False,'profile_kind':'none','scope':'No validated profile','category_candidate':extra['category_candidate'],
             'semantic_focus':extra.get('semantic_focus',[]),'host_candidate':extra.get('host_candidate','Identify exact upstream implementation'),
             'retrieved_reference_candidate':False,'external_dependencies':extra.get('external_dependencies',[]),
             'obligation_dimensions':[{'dimension':name,'normative_requirements':requirements} for name,requirements in DIMENSION_REQUIREMENTS.items()]}
        entries.append(row);ids.add(identifier)
    return entries


def decide(task,policy):
    from usl_systems.language import Interpreter
    from gate_plans import DIMENSION_REQUIREMENTS
    if task.get('full_profile_verifier_installed') is not False:
        raise ValueError('No full-profile certificate verifier is registered; caller flags cannot install one')
    gates=task['gates']
    if len(gates)!=len(DIMENSION_REQUIREMENTS) or {g['dimension'] for g in gates}!=set(DIMENSION_REQUIREMENTS):raise ValueError('Qualification must retain all18 distinct gate dimensions')
    for gate in gates:
        required=DIMENSION_REQUIREMENTS[gate['dimension']]
        if len(gate['leaves'])!=len(required) or {l['requirement'] for l in gate['leaves']}!=set(required):raise ValueError('Qualification leaf set is missing, duplicate or changed')
        if any(l['status'] in {'verified','verified_not_applicable'} for l in gate['leaves']):
            raise ValueError('Raw verified or not-applicable claims require an installed evidence verifier; none is registered')
    execution=Interpreter(capabilities={'qualification_inputs':lambda:task},timeout=2,max_ops=20000).run(policy)
    observed=execution.variables['result']
    leaves=[leaf for gate in task['gates'] for leaf in gate['leaves']]
    verified=sum(l['status']=='verified' for l in leaves);na=sum(l['status']=='verified_not_applicable' for l in leaves)
    opened=len(leaves)-verified-na
    eligible=all(task[k] for k in ['target_pinned','normative_inventory_closed','full_profile_semantics_verified','translation_refinement_verified','independent_full_review_verified','release_reproducibility_verified']) and opened==0
    expected={'verified_leaves':verified,'open_leaves':opened,'verified_not_applicable_leaves':na,
              'eligible_for_full_qualification':eligible,'full_standard_qualified':False,
              'unknown_is_failure_for_promotion':True}
    if observed!=expected:raise ValueError('USL qualification decision differs from independent closure calculation')
    return observed,{'actual_USL_execution':True,'operations':execution.operations,'policy_sha256':hashlib.sha256(policy.encode()).hexdigest(),'independently_checked':True}


def closure_errors(target,clauses):
    """Check a proposed normative closure; tests alone cannot close proof gates.

    This validates structure for future audited specifications. It intentionally
    awards no standards qualification and runs no caller-supplied commands.
    """
    errors=[]
    if not target.get('exact_version') or not target.get('specification_sha256'):errors.append('exact version and specification identity required')
    if target.get('inventory_independently_reviewed') is not True:errors.append('normative clause inventory needs independent review')
    if target.get('inventory_closed') is not True:errors.append('normative inventory is not closed')
    required=set(target.get('normative_clause_ids',[]))
    if not required or len(required)!=len(target.get('normative_clause_ids',[])):errors.append('nonempty unique normative clause inventory required')
    ids=[c.get('clause_id') for c in clauses]
    if len(ids)!=len(set(ids)) or set(ids)!=required:errors.append('clause map must cover the exact normative set without omissions or additions')
    for clause in clauses:
        if not clause.get('source_locator'):errors.append('missing normative source locator')
        if clause.get('applicability')=='not_applicable':
            if not clause.get('applicability_spec_basis') or clause.get('applicability_reviewed') is not True:errors.append('unsupported not-applicable decision')
            continue
        if not clause.get('implementation_sha256') or not clause.get('implementation_locator'):errors.append('clause lacks implementation binding')
        if not clause.get('independent_tests') or not clause.get('native_observations'):errors.append('clause lacks independent/native validation')
        if clause.get('proof_scope')!='whole_clause' or clause.get('trusted_checker_verified') is not True:errors.append('whole-clause machine-checked refinement evidence missing')
        if clause.get('unmodelled_obligations'):errors.append('clause retains unmodelled behavior')
    return sorted(set(errors))


async def execute(input_root,source_root,output,additional=None):
    from gate_plans import get_gate_plan,DIMENSION_PARENTS
    from audit_evidence import audit
    started=time.perf_counter();input_root=Path(input_root).resolve();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    source_identities={p.name:file_sha(p) for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.usl'))}
    integrity=verify_input(input_root);entries=load_entries(input_root,additional)
    evidence=audit(input_root,source_root);audit_by={r['catalog_id']:r for r in evidence['records']}
    policy=(ROOT/'qualification.usl').read_text();contracts={};contract_keys={};gate_inputs=[]
    for row in entries:
        for d in row['obligation_dimensions']:
            request=(row['category_candidate'],d['dimension'],tuple(d['normative_requirements']))
            key=contract_keys.get(request)
            if key is None:
                plan=get_gate_plan(row['category_candidate'],d['dimension'],d['normative_requirements'])
                key=digest(plan);contracts[key]=plan;contract_keys[request]=key
            gate_inputs.append((row,d,key))
    ready=asyncio.Event();actors_started=0;active=0;peak=0
    async def gate_actor(row,dimension,key):
        nonlocal actors_started,active,peak
        actors_started+=1;active+=1;peak=max(peak,active)
        try:
            await ready.wait()
            prior=audit_by.get(row['catalog_id'],{})
            names=prior.get('relevant_dimensions',[])
            supporting=bool(set(SUPPORT_DIMENSIONS[dimension['dimension']])&set(names))
            leaves=[{'requirement':name,'status':'open',
                     'normative_clause_set_closed':False,'complete_semantics_verified':False} for name in dimension['normative_requirements']]
            return {'catalog_id':row['catalog_id'],'dimension':dimension['dimension'],'contract_sha256':key,
                    'status':'historical_support_unmapped' if supporting else 'open',
                    'prerequisites':DIMENSION_PARENTS[dimension['dimension']],
                    'unmet_prerequisites':DIMENSION_PARENTS[dimension['dimension']],
                    'historical_audit_record_sha256':digest(prior) if prior else None,
                    'historical_support_does_not_close_full_gate':True,'leaves':leaves}
        finally:active-=1
    tasks=[asyncio.create_task(gate_actor(row,d,key)) for row,d,key in gate_inputs]
    await asyncio.sleep(0);all_started=actors_started==len(tasks);ready.set();gates=await asyncio.gather(*tasks)
    by_id=collections.defaultdict(list)
    for gate in gates:by_id[gate['catalog_id']].append(gate)
    results=[];queue=[]
    for row in entries:
        selected=by_id[row['catalog_id']]
        task={k:False for k in ['target_pinned','normative_inventory_closed','full_profile_semantics_verified','translation_refinement_verified','independent_full_review_verified','release_reproducibility_verified','full_profile_verifier_installed']}
        task['gates']=selected
        decision,receipt=decide(task,policy)
        reference_action='audit_reference_authority_version_and_normative_clauses' if row['retrieved_reference_candidate'] else 'retrieve_correct_upstream_specification_and_audit_identity'
        target={'catalog_id':row['catalog_id'],'standard_or_implementation_contract':'requires_authority_and_version_audit',
                'exact_standard_version':None,'dialect':None,'category_candidate':row['category_candidate'],'category_review_complete':False,
                'libraries_and_dependencies':None,'claimed_platforms':None,'conformance_options':None,'implementation_hashes':None,
                'full_program_or_processing_semantics':None,'qualified_as_entire_standard':False}
        record={'catalog_id':row['catalog_id'],'original_catalog':row['original_catalog'],'family':row['family'],
                'existing_bounded_profile':row['scoped'],'category_candidate':row['category_candidate'],
                'target_manifest':target,'target_candidate_sha256':digest(target),'semantic_focus':row['semantic_focus'],
                'historical_category_proposal':row.get('historical_category_proposal'),
                'host_candidate':row['host_candidate'],'external_dependencies':row['external_dependencies'],
                'gates':selected,'USL_decision':decision,'USL_receipt':receipt,
                'full_rule_audit_complete':False,'full_qualification_verifier_installed':False,'full_standard_qualified':False,
                'next_required_action':reference_action,'all_full_profile_obligations_still_open':True}
        results.append(record)
        for gate in selected:
            queue.append({'task_id':row['catalog_id']+':'+gate['dimension'],'catalog_id':row['catalog_id'],
                'dimension':gate['dimension'],'contract_sha256':gate['contract_sha256'],
                'parents':[row['catalog_id']+':'+p for p in gate['prerequisites']],
                'validation_ready':not gate['prerequisites'],'status':gate['status'],
                'independent_preparation_can_start_now':True,
                'preparation_action':reference_action if gate['dimension']=='identity' else 'inventory required constructs, source clauses, tests and available host tools while normative acceptance remains gated'})
    leaves=sum(len(g['leaves']) for g in gates)
    summary={'passed':all_started and len(results)==len(entries),'catalog_IDs':len(entries),'original_IDs':sum(r['original_catalog'] for r in entries),
             'USL_and_additional_IDs':sum(not r['original_catalog'] for r in entries),'dimensions_per_ID':18,'requirement_groups_per_ID':48,
             'gate_checks':len(gates),'requirement_groups_checked':leaves,'all_gate_actors_started_before_release':all_started,
             'peak_live_logical_gate_actors':peak,'actual_interpreter_threads':1,'USL_qualification_executions':len(results),
             'full_standards_qualified':0,'full_implementation_contracts_qualified':0,'full_profile_verifiers_installed':0,
             'all_ID_gate_policies_applied':True,'all_ID_standards_implemented':False,'verified_not_applicable_awarded_automatically':0,
             'existing_bounded_original_profiles':sum(r['original_catalog'] and r['scoped'] for r in entries),
             'fixed_batches_or_worker_cap':False,'native_executions_in_this_gate_audit':0,
             'historical_evidence_is_fresh_execution':False,'qualification_action_count':len(queue),
             'validation_actions_ready_after_prerequisites':sum(q['validation_ready'] for q in queue),
             'independent_preparation_actions_unblocked':len(queue),'distinct_shared_gate_contracts':len(contracts),
             'pure_contract_requests':len(gate_inputs),'duplicate_contract_constructions_avoided':len(gate_inputs)-len(contracts),
             'complete_normative_clause_count':None,'completion_ETA_seconds':None,'computation_seconds_before_export':time.perf_counter()-started}
    if not all(file_sha(ROOT/name)==value for name,value in source_identities.items()):raise ValueError('Qualification source changed during execution')
    summary['source_unchanged_during_run']=True
    dump(output/'ALL_ID_QUALIFICATION.json',{'schema':'usl.all-catalog-full-qualification.v1','summary':summary,'input_integrity':integrity,
         'evidence_audit_sha256':digest(evidence),'runner_source_identities':source_identities,'records':results})
    dump(output/'GATE_CONTRACTS.json',contracts);dump(output/'WORK_QUEUE.json',{'schema':'usl.full-qualification-work-queue.v1','tasks':queue})
    dump(output/'EVIDENCE_AUDIT.json',evidence);dump(output/'SUMMARY.json',summary)
    lines=['# Full qualification status for all catalog entries','',
        f"Applied18 dimensions and48 requirement groups to all{len(entries)} IDs. This evaluates required work; no complete standard or full implementation contract is qualified.",'',
        'Native examples, installed tools, structural reference inventories and bounded symbolic proofs cannot close an entire-language gate. Full-profile verifiers and reviewed exact targets remain required.','',
        '| ID | Family | Existing bounded profile | Full gates closed | Next required action |','|---|---|---|---|---|']
    lines += ['| '+' | '.join(str(v).replace('|','\\|') for v in [r['catalog_id'],r['family'],'yes' if r['existing_bounded_profile'] else 'no','0/18',r['next_required_action']])+' |' for r in results]
    (output/'ALL_ID_STATUS.md').write_text('\n'.join(lines)+'\n')
    export=[p for p in output.iterdir() if p.is_file() and p.name!='MANIFEST.json']
    dump(output/'MANIFEST.json',{p.name:{'sha256':file_sha(p),'bytes':p.stat().st_size} for p in sorted(export)})
    costs={'measured_seconds_through_report_export_and_first_manifest':time.perf_counter()-started,
           'includes_input_integrity_evidence_audit_gate_checks_USL_policy_and_export':True,
           'excludes_only_final_cost_record_and_its_manifest_update':True,'native_executions':0,
           'not_a_language_implementation_speed_or_completion_estimate':True}
    dump(output/'RUN_COSTS.json',costs)
    export=[p for p in output.iterdir() if p.is_file() and p.name!='MANIFEST.json']
    dump(output/'MANIFEST.json',{p.name:{'sha256':file_sha(p),'bytes':p.stat().st_size} for p in sorted(export)})
    print(json.dumps(summary));return summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input-root',type=Path,default=DEFAULT_INPUT);p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--additional-catalog',type=Path)
    a=p.parse_args();sys.path.insert(0,str(a.source_root.resolve()))
    extras=json.loads(a.additional_catalog.read_text()) if a.additional_catalog else None
    asyncio.run(execute(a.input_root,a.source_root,a.output,extras))


if __name__=='__main__':main()
