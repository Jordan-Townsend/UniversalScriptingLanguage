"""Versioned qualification contracts; defining a contract supplies no evidence.

These are engineering acceptance criteria, not claims about the content of any
particular language standard.  A per-ID normative audit must instantiate every
criterion against that ID's exact authoritative version and platform profile.
"""
from copy import deepcopy


DIMENSION_REQUIREMENTS = {
    'identity': ['standard_version', 'dialect_and_extensions', 'authoritative_origin_and_license'],
    'grammar': ['lexical_rules_and_ast', 'invalid_input_and_recovery', 'macros_preprocessing_and_imports'],
    'static_semantics': ['scope_and_binding', 'types_and_overloads', 'modules_mutability_and_contracts'],
    'dynamic_semantics': ['evaluation_order_and_calls', 'closures_recursion_identity_and_mutation', 'exceptions_and_observable_effects'],
    'numbers_and_data': ['overflow_rounding_and_nan', 'unicode_encoding_and_layout', 'ownership_copy_and_aliasing'],
    'concurrency': ['tasks_threads_and_source_restrictions', 'cancellation_effects_and_ordering'],
    'runtime_apis': ['standard_library_surface', 'host_services_and_io', 'capability_and_environment_boundaries'],
    'interoperability': ['typed_ir_and_abi', 'marshalling_callbacks_and_lifetimes', 'errors_async_and_host_guest_provenance'],
    'backend': ['compatible_versioned_toolchain', 'category_appropriate_execution', 'lowering_or_embedded_route_identified'],
    'conformance': ['normative_chapter_traceability', 'upstream_and_independent_acceptance', 'negative_boundary_differential_property_and_fuzz'],
    'performance': ['equivalent_route_domain', 'cold_warm_latency_memory_and_resource_costs'],
    'safety': ['source_isolation_and_capabilities', 'resource_limits', 'supply_chain_license_and_reproducibility'],
    'portability': ['actual_claimed_platform_matrix', 'unavailable_platforms_explicit'],
    'certification': ['independent_review', 'exact_build_regression', 'reviewed_limitations_and_exceptions'],
    'parser_cases': ['positive_and_negative_actual_parser_cases'],
    'native_execution': ['actual_backend_execution', 'independent_positive_boundary_and_negative_oracles'],
    'semantic_translation': ['typed_frontend_and_semantics', 'source_target_observable_equivalence', 'unsupported_operations_fail_closed'],
    'intent_verification': ['independent_intent_contract', 'native_typecheck_and_holdout', 'formal_scope_and_unmodelled_obligations'],
}

# No family supplies a qualification edge.  Every edge is within an exact ID,
# version, platform and artifact identity; shared work remains hash-addressed.
DIMENSION_PARENTS = {
    'identity': [],
    'grammar': ['identity'],
    'static_semantics': ['grammar'],
    'dynamic_semantics': ['static_semantics', 'numbers_and_data'],
    'numbers_and_data': ['identity'],
    'concurrency': ['dynamic_semantics'],
    'runtime_apis': ['dynamic_semantics'],
    'interoperability': ['runtime_apis', 'backend'],
    'backend': ['identity'],
    'conformance': ['parser_cases', 'native_execution', 'semantic_translation', 'intent_verification'],
    'performance': ['conformance'],
    'safety': ['backend'],
    'portability': ['conformance'],
    'certification': ['conformance', 'performance', 'safety', 'portability'],
    'parser_cases': ['grammar'],
    'native_execution': ['backend', 'parser_cases'],
    'semantic_translation': ['dynamic_semantics', 'concurrency', 'runtime_apis', 'interoperability'],
    'intent_verification': ['semantic_translation', 'native_execution'],
}

BINDING_FIELDS = [
    'catalog_id', 'authoritative_document_id_and_version', 'authoritative_document_sha256',
    'normative_clause_ids', 'dialect_and_extensions', 'category_and_profile',
    'source_tree_sha256', 'generated_artifact_sha256', 'ir_and_translator_version_sha256',
    'native_toolchain_version_and_binary_sha256', 'runtime_and_library_versions_sha256',
    'target_triple_or_host_identity', 'os_architecture_and_device', 'configuration_and_environment',
    'test_source_and_independent_oracle_sha256', 'execution_receipt_sha256',
]

# Original project obligations must not be represented as clauses of a language
# standard before the per-ID normative audit.  Some standards impose additional
# requirements in any of these areas; only that audit can establish which ones.
OBLIGATION_CLASSES = {
    'identity': 'identity_and_claim_scope',
    'grammar': 'candidate_language_semantics',
    'static_semantics': 'candidate_language_semantics',
    'dynamic_semantics': 'candidate_language_semantics',
    'numbers_and_data': 'candidate_language_semantics',
    'concurrency': 'candidate_language_semantics',
    'runtime_apis': 'candidate_language_and_host_api_semantics',
    'interoperability': 'project_cross_language_integration',
    'backend': 'project_native_host_integration',
    'conformance': 'conformance_evidence_and_project_coverage',
    'performance': 'project_measurement_quality',
    'safety': 'project_deployment_quality',
    'portability': 'claimed_platform_evidence',
    'certification': 'project_independent_review_and_release',
    'parser_cases': 'conformance_evidence',
    'native_execution': 'project_native_execution_evidence',
    'semantic_translation': 'project_translation_preservation',
    'intent_verification': 'project_intent_contract_verification',
}

NA_REQUIREMENTS = [
    'Exact ID, specification version and profile binding, never a family-wide inference',
    'Cited authoritative clauses or complete reviewed normative inventory establishing that this obligation has no applicable semantics',
    'Explanation of the replacement category contract, including observable absence or prohibited behavior where applicable',
    'Independent reviewer identity, rationale and signed or hash-bound review artifact',
    'No missing source, absent runtime, unfinished implementation or unrun test may be classified not applicable',
]

CATEGORY_CONTRACTS = {
    'source_program': {
        'operation': 'parse, bind, typecheck where defined, and execute source programs',
        'observables': ['values and representation', 'termination and exceptions', 'state mutation and I/O', 'evaluation and concurrency ordering'],
        'native_evidence': 'Fresh original-program execution on the pinned upstream compiler/interpreter/runtime and applicable standard library',
        'translation': 'Source AST to typed/effect IR to executable generated target with observable equivalence; a subprocess wrapper is native embedding only',
        'boundary_tests': ['binding/type errors', 'closures and modules', 'integer/float/Unicode edges', 'effects, aliasing and cancellation'],
    },
    'grammar_schema_or_interface': {
        'operation': 'validate grammars, schemas or interfaces and process their generated parsers, models or stubs',
        'observables': ['accepted and rejected inputs', 'parse trees or validation models', 'recovery diagnostics', 'generated target APIs and serialization'],
        'native_evidence': 'Fresh upstream validator/generator runs plus generated target execution with its matching runtime when generation is defined',
        'translation': 'Preserve acceptance, rejection, structural results and generated-interface behavior; grammar compilation is distinct from executing a source program',
        'boundary_tests': ['ambiguity and precedence', 'invalid productions and messages', 'encoding/recovery', 'schema references and generated ABI'],
    },
    'composite_template': {
        'operation': 'parse and render templates with their pinned embedded language and rendering environment',
        'observables': ['rendered bytes or declared parsed structure', 'escaping in each output context', 'include and variable scope', 'embedded-language errors and effects'],
        'native_evidence': 'Fresh native rendering plus separate exact embedded-runtime checking and execution of emitted code where present',
        'translation': 'Preserve template boundaries, escaping, includes and embedded semantics; a text substitution does not establish host-language equivalence',
        'boundary_tests': ['HTML/attribute/script escaping', 'nested includes and scope', 'missing/null values', 'embedded syntax errors and side effects'],
    },
    'configuration_or_build': {
        'operation': 'validate configuration/build declarations and apply them against isolated declared fixtures',
        'observables': ['resolved dependency graph', 'resulting files and state', 'precedence and includes', 'process/network effects and diagnostics'],
        'native_evidence': 'Fresh upstream checker and controlled configuration/build application; dry-run parsing alone is insufficient for an application claim',
        'translation': 'Preserve dependency resolution, application state, ordering and declared idempotence; configuration data is not an imaginary CPU program',
        'boundary_tests': ['invalid directives', 'conflicting precedence', 'missing/cyclic dependencies', 'repeat application and rollback/failure effects'],
    },
    'document_processing': {
        'operation': 'parse, validate, transform or render documents and data under a declared format contract',
        'observables': ['bytes when required', 'structure/order/duplicates when required', 'encoding and numeric lexemes', 'roundtrip/rendered output and rejection'],
        'native_evidence': 'Fresh pinned native parser/validator/renderer processing with independent structural or byte-level oracles',
        'translation': 'Preserve the exact declared byte, structural, rendering or tolerance equivalence; do not require standalone program execution for a data format',
        'boundary_tests': ['malformed syntax and encoding', 'duplicate/order policy', 'roundtrip loss and number boundaries', 'rendering tolerance and external entity policy'],
    },
    'transcript_log_or_protocol': {
        'operation': 'parse, validate or transform transcripts, logs, patches, sessions and protocol messages',
        'observables': ['records and field boundaries', 'timestamps, encodings and protocol state', 'lossless roundtrip where required', 'malformed/truncated input and diagnostics'],
        'native_evidence': 'Fresh native parser/validator/patch or message processor results on controlled fixtures; executable session snippets require a separately identified embedded runtime',
        'translation': 'Preserve message/session/document processing semantics; a recorded command transcript is data and never evidence that its commands were executed',
        'boundary_tests': ['truncated/multiline records', 'escaping and hostile embedded text', 'malformed protocol transitions', 'patch context or transcript roundtrip'],
    },
    'query': {
        'operation': 'plan and execute queries or updates over exact schemas and isolated database fixtures',
        'observables': ['result multisets or declared order', 'NULL/missing and collation behavior', 'errors and database effects', 'transaction isolation and concurrency'],
        'native_evidence': 'Fresh pinned query engine execution with schema, data, collation, timezone and transaction configuration identities',
        'translation': 'Preserve query/update semantics and effects under declared relational and transaction models; compare multisets unless ordering is required',
        'boundary_tests': ['empty relations and duplicates', 'NULL/three-valued predicates', 'overflow/aggregation and collation', 'rollback and isolation schedules'],
    },
    'proof_or_analysis': {
        'operation': 'parse, elaborate and check proofs, specifications or analysis obligations',
        'observables': ['accepted/rejected judgments', 'proof objects or verification conditions', 'countermodels', 'trusted axioms and bounded/unknown outcomes'],
        'native_evidence': 'Fresh pinned kernel/checker/analyzer execution with all axioms, solver settings and finite/probabilistic bounds recorded',
        'translation': 'Preserve the relevant judgments and proof/checking obligations; proof parsing or bounded model checking is not universal validity',
        'boundary_tests': ['invalid proofs and inconsistent assumptions', 'countermodels', 'unknown/timeouts', 'kernel rechecking and solver bound changes'],
    },
    'device_or_simulation': {
        'operation': 'compile and simulate or execute kernels/hardware descriptions on each claimed simulator or device',
        'observables': ['signals/results and numeric tolerances', 'clock and memory ordering', 'state/traps', 'device resources and synchronization'],
        'native_evidence': 'Fresh compile, simulation and actual-device receipts kept distinct, with exact language revision, device/driver and execution configuration',
        'translation': 'Preserve timing, numerical, memory and synchronization contracts for each claimed target; simulation never supplies an unrun real-device result',
        'boundary_tests': ['reset and clock boundaries', 'race/barrier schedules', 'numeric tolerance limits', 'resource exhaustion and device traps'],
    },
    'assembly_or_ir': {
        'operation': 'assemble/verify, link and execute under an exact ISA or IR and ABI profile',
        'observables': ['encoding and relocations', 'register/stack/memory state', 'observable traps and effects', 'calling convention and object format'],
        'native_evidence': 'Fresh assembler/verifier/linker results and execution on the exact target or explicitly labeled emulator',
        'translation': 'Preserve ISA/IR defined behavior, calling conventions, endian/layout and traps; unsupported or undefined instructions remain explicit',
        'boundary_tests': ['instruction encoding boundaries', 'invalid IR and relocations', 'register/stack invariants', 'alignment, traps and FFI roundtrips'],
    },
}

# Each leaf has its own actual acceptance criteria, evidence types and required
# adversarial/independent test classes.  Rule text still comes from a per-ID audit.
LEAF_CONTRACTS = {
    'standard_version': (
        ['Select the exact published standard/revision, errata policy and conformance class; record an authoritative full-text hash and clause index',
         'When no formal standard exists, identify an exact upstream implementation/manual baseline and label the result whole-implementation qualification, never full-standard certification'],
        ['authoritative_full_text', 'normative_clause_inventory', 'version_selection_review'], ['ambiguous-version rejection', 'errata and conflicting-authority review']),
    'dialect_and_extensions': (
        ['Enumerate every enabled dialect flag, extension and implementation-defined/unspecified choice and its authoritative justification',
         'Prevent an extension or bounded subset from silently substituting for the selected complete standard'],
        ['dialect_feature_matrix', 'configuration_manifest', 'implementation_defined_choices'], ['strict-standard mode', 'extension disabled/enabled differential cases']),
    'authoritative_origin_and_license': (
        ['Bind every specification, compiler, library and test suite to origin, version/hash and redistribution/use terms',
         'Resolve contradictory or secondary documentation against the selected normative authority'],
        ['source_provenance', 'license_inventory', 'authority_conflict_resolution'], ['artifact integrity', 'missing provenance rejection']),
    'lexical_rules_and_ast': (
        ['Map every lexical/grammar production and context-sensitive parsing rule to real frontend code and AST invariants',
         'Handle source encodings, token boundaries and precedence using exact normative rules'],
        ['production_to_implementation_map', 'ast_schema', 'parser_case_receipts'], ['all grammar production classes', 'precedence and contextual ambiguity', 'encoding boundaries']),
    'invalid_input_and_recovery': (
        ['Map required syntax rejection, diagnostics and recovery to native and generated outcomes; distinguish recovered input from valid input',
         'Specify when diagnostic wording is implementation-defined and compare only the justified contract'],
        ['negative_rule_map', 'diagnostic_contract', 'native_recovery_receipts'], ['invalid token/structure cases', 'truncated and trailing input', 'recovery continuation']),
    'macros_preprocessing_and_imports': (
        ['Implement every applicable expansion, hygiene, conditional inclusion, import and dependency-resolution rule before semantic analysis',
         'Bind expansion output, search paths and imported artifact versions so stale or host-specific resolution cannot masquerade as equivalent source'],
        ['expansion_and_resolution_map', 'dependency_manifest', 'expansion_receipts'], ['nested/hygienic expansion', 'cyclic and missing imports', 'conditional/include path differences']),
    'scope_and_binding': (
        ['Map name lookup, visibility, shadowing, forward references, lifetime and binding phases to frontend and IR behavior'],
        ['binding_rule_map', 'resolved_symbol_ir', 'scope_oracle_receipts'], ['shadowing and capture', 'unbound/private references', 'phase and lifetime boundaries']),
    'types_and_overloads': (
        ['Implement each applicable typing, inference, subtyping, conversion, overload and static-error rule, including dynamic-language restrictions',
         'Distinguish compile-time rejection from runtime checks and preserve both phases'],
        ['type_rule_derivations', 'conversion_and_overload_matrix', 'typecheck_receipts'], ['ambiguous overloads', 'invalid conversions/generics', 'inference and dynamic type failures']),
    'modules_mutability_and_contracts': (
        ['Implement module initialization, exports, mutability restrictions and declared compile/runtime contracts',
         'Record effects of initialization order and circular dependencies'],
        ['module_and_contract_rule_map', 'initialization_model', 'module_fixture_receipts'], ['cyclic modules', 'immutable writes', 'initialization and contract failures']),
    'evaluation_order_and_calls': (
        ['Implement the exact specified evaluation strategy, operand/argument sequencing, call conventions, dispatch and termination behavior',
         'Preserve specified nondeterminism as an allowed outcome set rather than inventing a deterministic equality claim'],
        ['operational_semantics_map', 'call_lowering_map', 'evaluation_trace_receipts'], ['side-effecting operands', 'dispatch/default/variadic cases', 'short-circuit and termination cases']),
    'closures_recursion_identity_and_mutation': (
        ['Preserve capture modes, recursion, object/value identity, mutation and lifetime across original and generated execution'],
        ['heap_and_environment_model', 'identity_and_alias_invariants', 'state_trace_receipts'], ['escaping closures', 'mutually recursive calls', 'shared mutation and identity tests']),
    'exceptions_and_observable_effects': (
        ['Preserve exception classes/values, propagation, cleanup, resumability and external side effects in the source-defined order',
         'Retain partial effects and failures instead of comparing only final return values'],
        ['exception_and_effect_model', 'effect_trace_oracles', 'cleanup_receipts'], ['nested handlers and cleanup', 'failure after partial effects', 'I/O and cancellation interactions']),
    'overflow_rounding_and_nan': (
        ['Implement applicable numeric widths, overflow/traps, rounding, signed zero, NaN/infinity, exactness and conversion semantics',
         'Bind float mode and tolerances to the specification; tolerances cannot mask a specified exact result'],
        ['numeric_semantics_matrix', 'representation_configuration', 'numeric_boundary_receipts'], ['min/max and overflow', 'NaN/signed zero/subnormals', 'rounding and division signs']),
    'unicode_encoding_and_layout': (
        ['Implement text/codepoint/code-unit, normalization where defined, byte encoding, layout, alignment and serialization rules'],
        ['encoding_and_layout_map', 'binary_layout_fixtures', 'text_boundary_receipts'], ['invalid encodings and surrogates', 'non-BMP and normalization distinctions', 'endian/alignment and roundtrip cases']),
    'ownership_copy_and_aliasing': (
        ['Preserve copy versus reference behavior, ownership/borrow rules, aliasing, initialization and destruction semantics'],
        ['ownership_and_alias_model', 'lifetime_invariants', 'alias_trace_receipts'], ['copy-on-write and shared aliases', 'use-after-lifetime rejection', 'move/borrow/destruction boundaries']),
    'tasks_threads_and_source_restrictions': (
        ['Implement the source task/thread/actor/event model, permitted sharing and memory-order restrictions including forbidden operations',
         'When the category has no concurrency constructs, audit host processing concurrency and document that boundary rather than silently deleting this obligation'],
        ['concurrency_memory_model', 'allowed_schedule_contract', 'concurrency_receipts'], ['race and sharing boundaries', 'synchronization litmus schedules', 'scheduler nondeterminism']),
    'cancellation_effects_and_ordering': (
        ['Preserve cancellation, interruption, async exceptions, cleanup, ordering and allowed externally observable schedules'],
        ['cancellation_and_ordering_map', 'schedule_oracles', 'fresh_schedule_receipts'], ['cancel before/during/after work', 'partial effects and cleanup', 'deadlock/liveness contracts']),
    'standard_library_surface': (
        ['Inventory every normative standard-library module, overload, constant, error and required behavior and map each to code and tests',
         'Bind host library delegation to compatible semantics; an installed package or same-named function is not complete API evidence'],
        ['complete_api_inventory', 'api_rule_implementation_test_matrix', 'library_artifact_manifest'], ['each normative API contract', 'errors and edge arguments', 'cross-module interactions']),
    'host_services_and_io': (
        ['Preserve applicable filesystem, stream, network, time, process and environment semantics including encoding and errors',
         'Use controlled fixtures and fresh effects; never replay cached external execution as evidence'],
        ['host_service_contracts', 'isolated_fixture_manifest', 'fresh_io_trace_receipts'], ['short/failed I/O', 'time/timezone/locale boundaries', 'permission and process failure']),
    'capability_and_environment_boundaries': (
        ['Define and enforce source capabilities, environment access, locale/timezone/randomness and host/guest boundaries',
         'Keep permitted source behavior distinct from test harness isolation policy'],
        ['capability_matrix', 'environment_manifest', 'boundary_receipts'], ['allowed/denied capability paths', 'environment variation', 'deterministic seed versus real randomness']),
    'typed_ir_and_abi': (
        ['Specify typed/effect IR invariants and each calling convention, layout, alignment, linkage and foreign data representation',
         'Verify both translation invariants and actual caller/callee ABI behavior on each claimed target'],
        ['ir_semantics_and_invariants', 'abi_layout_contract', 'ffi_roundtrip_receipts'], ['cross-language argument/return roundtrips', 'layout/alignment checks', 'invalid IR rejection']),
    'marshalling_callbacks_and_lifetimes': (
        ['Preserve marshalling, encodings, callback reentrancy, ownership and GC/pin/lifetime contracts across the boundary'],
        ['marshalling_and_lifetime_map', 'callback_contract', 'ffi_lifetime_receipts'], ['nested/reentrant callbacks', 'nullable/large values', 'GC/destruction during foreign calls']),
    'errors_async_and_host_guest_provenance': (
        ['Preserve foreign errors, async completion/cancellation and exception boundaries with original host/guest provenance'],
        ['cross_boundary_error_map', 'async_boundary_model', 'provenance_receipts'], ['foreign exception propagation', 'cancelled async callbacks', 'host crash versus guest failure attribution']),
    'compatible_versioned_toolchain': (
        ['Install and identify an actual compatible compiler/interpreter/processor and libraries from hash-bound upstream artifacts',
         'Demonstrate the selected profile/version flags work; command presence or a lexer is insufficient'],
        ['toolchain_provenance', 'version_and_binary_hashes', 'native_smoke_receipts'], ['compile/process and run fresh fixtures', 'incompatible version rejection', 'missing dependency diagnosis']),
    'category_appropriate_execution': (
        ['Run the category operation defined by this contract with captured command, environment, artifacts, outputs, effects, exit status and resource bounds',
         'Keep compilation, processing, simulation, actual-device execution and native program execution separately labeled'],
        ['fresh_native_operation_receipts', 'input_output_and_effect_hashes', 'execution_kind'], ['positive native operation', 'negative and resource-bound cases', 'category observable comparison']),
    'lowering_or_embedded_route_identified': (
        ['Identify every path as semantic translation, native/embedded delegation, generated artifact processing or unsupported',
         'Never promote embedding or same-output toy cases to a full source-translation claim'],
        ['route_classification', 'frontend_to_backend_artifact_chain', 'unsupported_feature_inventory'], ['route provenance checks', 'unsupported route rejection', 'generated target inspection/execution']),
    'normative_chapter_traceability': (
        ['Create a complete reviewed rule-to-implementation-to-test-to-receipt map over every normative clause and required library API',
         'Reconcile unmapped clauses, missing rules and conflicting outcomes; every exclusion needs reviewed applicability evidence'],
        ['complete_normative_coverage_matrix', 'unmapped_clause_report', 'applicability_reviews'], ['coverage completeness against full text', 'omitted/duplicate clause detection', 'errata and API reconciliation']),
    'upstream_and_independent_acceptance': (
        ['Run applicable upstream conformance suites and independently authored acceptance tests against the exact native and generated build',
         'Record suite version, skipped cases, known upstream bugs and independent oracle ownership; passed suites alone do not establish complete semantics'],
        ['upstream_suite_receipts', 'independent_acceptance_receipts', 'skip_and_counterexample_register'], ['normative acceptance suites', 'independent holdouts', 'upstream bug discriminators']),
    'negative_boundary_differential_property_and_fuzz': (
        ['Run independently selected negative, boundary, differential, property and fuzz cases and retain minimized counterexamples',
         'State generators, seeds, domains, time budgets and unresolved failures; no tested finite sample implies universal correctness'],
        ['property_and_fuzz_configuration', 'differential_receipts', 'counterexample_regressions'], ['invalid/boundary corpus', 'metamorphic and property checks', 'seeded fuzz with shrink/replay']),
    'equivalent_route_domain': (
        ['Measure only routes with the same declared semantics, inputs, output/effect contract and qualification domain',
         'Preserve slower alternatives and unsupported cases; do not extrapolate benchmark speedup into language implementation completion time'],
        ['equivalence_domain_manifest', 'benchmark_input_hashes', 'route_cost_comparison'], ['semantic precheck per route', 'cold versus reused artifact identity', 'slower/counterexample retention']),
    'cold_warm_latency_memory_and_resource_costs': (
        ['Measure end-to-end cold/warm wall time, CPU, peak memory, cache/storage and real admitted concurrency with reproducible settings',
         'Count logical actors, native processes and materialized resource lanes separately; virtual workers do not create compute'],
        ['raw_resource_samples', 'hardware_and_admission_manifest', 'cache_and_process_accounting'], ['cold/warm repeated samples', 'resource saturation cases', 'artifact reuse integrity']),
    'source_isolation_and_capabilities': (
        ['Validate isolation and capability policy for source, generated code and toolchain execution under the actual deployment threat model'],
        ['isolation_policy', 'execution_boundary_receipts', 'capability_enforcement_results'], ['escape/capability denial tests', 'source-to-generated policy equivalence', 'controlled side-effect boundaries']),
    'resource_limits': (
        ['Declare and enforce source/AST/stack/heap/CPU/time/output limits and distinguish profile limits from semantic rejection',
         'A bounded execution profile cannot qualify a standard that requires unsupported behaviors outside that bound'],
        ['resource_limit_contract', 'limit_boundary_receipts', 'bound_vs_standard_review'], ['at/below/above each limit', 'timeout and cleanup', 'large/deep input behavior']),
    'supply_chain_license_and_reproducibility': (
        ['Verify source/dependency hashes, licenses and exact build recipe; reproduce the distributable from a clean extraction',
         'Retain provenance and counterexamples without redistributing prohibited material'],
        ['hash_and_license_manifest', 'clean_build_receipts', 'dependency_lock_and_recipe'], ['tampered artifact rejection', 'clean rebuild', 'missing dependency and license review']),
    'actual_claimed_platform_matrix': (
        ['Execute all relevant conformance, ABI and category contracts on every claimed OS/architecture/device/host combination',
         'Bind platform-specific implementation choices and avoid inheriting results from another target'],
        ['claimed_platform_matrix', 'per_platform_execution_receipts', 'platform_choice_review'], ['each claimed platform', 'endian/word-size/locale variations', 'native versus emulator distinction']),
    'unavailable_platforms_explicit': (
        ['List each untested required platform, device, licensed host or account with owner, exact prerequisite and next action',
         'Keep a required unavailable platform blocked; it cannot be waived as not applicable merely because it is unavailable'],
        ['platform_blocker_register', 'host_license_device_requirements', 'profile_scope_review'], ['unavailable-host status preservation', 'unsupported claim rejection', 'platform coverage reconciliation']),
    'independent_review': (
        ['An identified reviewer independent of the implementation checks normative coverage, semantics, tests, counterexamples and limits on the exact artifact',
         'Distinguish internal engineering qualification from any official certification scheme and obtain that scheme if claiming official certification'],
        ['independent_review_artifact', 'reviewer_and_scope_identity', 'official_scheme_decision_if_claimed'], ['review findings closed or retained as blockers', 'evidence integrity sampling', 'claim wording review']),
    'exact_build_regression': (
        ['Re-run all affected gates on the exact release build in a clean extraction; tie every receipt to source, generated code, runtimes and platform',
         'A changed semantic artifact invalidates dependent qualifications until affected checks are freshly completed'],
        ['release_manifest', 'clean_regression_receipts', 'dependency_invalidation_graph'], ['clean extraction', 'changed-artifact invalidation', 'remote/package hash verification']),
    'reviewed_limitations_and_exceptions': (
        ['Publish the exact claimed scope, implementation-defined choices, unsupported behavior, permitted extensions and unresolved exceptions',
         'A missing mandatory normative feature prevents full qualification even when clearly documented'],
        ['reviewed_claim_and_limitations', 'open_obligation_register', 'exception_disposition'], ['mandatory-gap promotion rejection', 'claim versus evidence reconciliation', 'all review blockers resolved']),
    'positive_and_negative_actual_parser_cases': (
        ['Execute the real frontend on normative positive and independently invalid cases, inspect AST/model outcomes and full-input consumption',
         'Lexical highlighting, keyword recognition or zero process status cannot stand in for parsing evidence'],
        ['actual_parser_run_receipts', 'positive_negative_input_corpus', 'ast_or_model_oracles'], ['full-input and trailing garbage', 'valid/invalid production branches', 'recovery versus acceptance']),
    'actual_backend_execution': (
        ['Freshly perform the exact native category operation on source/generated artifacts and preserve raw observations and effects',
         'Tool discovery, compilation-only or cached observations do not establish an unrun execution claim'],
        ['fresh_backend_receipts', 'raw_native_observations', 'artifact_and_environment_bindings'], ['native positive cases', 'expected rejection/failure cases', 'effect and exit-status observation']),
    'independent_positive_boundary_and_negative_oracles': (
        ['Author native positive, negative and boundary expectations independently from translator output and native observed results',
         'Retain specification reasoning and differentiate implementation bugs from source-undefined behavior'],
        ['independent_oracle_source', 'oracle_authorship_and_spec_basis', 'case_comparison_receipts'], ['independent positives', 'negative/error and boundary cases', 'counterexample classification']),
    'typed_frontend_and_semantics': (
        ['Implement a real frontend and explicit typed/effect semantic model for every mandatory source construct and category operation',
         'Trace source rules through IR invariants and target lowering; a library of keywords is not a semantic model'],
        ['complete_frontend_and_ir_map', 'ir_semantics_and_type_effect_rules', 'lowering_implementation_links'], ['construct and interaction coverage', 'IR invariant/type/effect rejection', 'unsupported source features']),
    'source_target_observable_equivalence': (
        ['Compare source and generated executions using a formally stated category-specific relation over values, errors, state, effects and allowed ordering',
         'For a universal claim supply a sound mechanized proof of the claimed semantics and verified assumptions; finite differential tests qualify only their declared domain'],
        ['observable_equivalence_contract', 'native_generated_differential_receipts', 'mechanized_preservation_proof_or_explicit_open_obligations'], ['native/generated independent cases', 'nondeterministic allowed outcomes', 'effect/error/termination counterexamples']),
    'unsupported_operations_fail_closed': (
        ['Reject or explicitly route every unsupported/uncertain feature before claiming semantic equivalence; preserve original diagnostics and route provenance',
         'Do not silently approximate, omit code, substitute canned output or promote an embedded backend to translation'],
        ['feature_support_and_rejection_map', 'fail_closed_receipts', 'route_provenance'], ['every unsupported feature class', 'mixed supported/unsupported programs', 'fallback/approximation rejection']),
    'independent_intent_contract': (
        ['Express the original requested behavior independently as preconditions, postconditions, permitted effects, error behavior and termination/liveness requirements',
         'Resolve ambiguity in intent before claiming proof; expected output derived from generated code is circular'],
        ['independent_formal_or_executable_intent', 'intent_authorship_and_review', 'source_to_intent_mapping'], ['independent examples and holdouts', 'invalid preconditions', 'effects/errors/liveness acceptance']),
    'native_typecheck_and_holdout': (
        ['Run native parse/type/static checks as applicable and fresh original/generated execution on holdouts excluded from implementation tuning',
         'Bind holdout provenance and retain every failed or unsupported case'],
        ['native_check_receipts', 'heldout_case_manifest', 'fresh_heldout_outcomes'], ['independent holdout domain', 'type/static rejection where defined', 'original/generated error behavior']),
    'formal_scope_and_unmodelled_obligations': (
        ['State exactly which intent/translation properties are proved, for which input/heap/concurrency/domain model, and using which trusted kernel/axioms',
         'Check proof artifacts independently or provide complete bounded exhaustive evidence; leave all unmodelled or universal obligations open',
         'No unrestricted arbitrary-program semantic equivalence or human intent proof follows from syntax rules, test counts or an unsat result in an incomplete model'],
        ['formal_model_and_assumptions', 'independently_checked_proof_or_exhaustive_domain_certificate', 'unmodelled_obligation_register'], ['proof replay/checking', 'assumption and model-boundary counterexamples', 'finite versus universal claim review']),
}

QUALIFICATION_STEPS = [
    {'step': 'select_authority_and_profile', 'parents': [], 'dimensions': ['identity'],
     'action': 'Audit exact standard or implementation baseline, category, dialect, versions and required host/library/device scope'},
    {'step': 'audit_all_normative_rules', 'parents': ['select_authority_and_profile'], 'dimensions': ['conformance'],
     'action': 'Read complete authoritative sources and build reviewed clause/API/choice/applicability inventory; retrieval is only an input'},
    {'step': 'prepare_real_native_hosts', 'parents': ['select_authority_and_profile'], 'dimensions': ['backend', 'safety'],
     'action': 'Install or bind compatible actual upstream tools and dependencies; retain licensed/device/platform blockers'},
    {'step': 'implement_frontend_and_semantics', 'parents': ['audit_all_normative_rules'],
     'dimensions': ['grammar', 'static_semantics', 'dynamic_semantics', 'numbers_and_data', 'concurrency', 'parser_cases'],
     'action': 'Implement every applicable lexical, static, dynamic, data, effect and concurrency rule and adversarial parser behavior'},
    {'step': 'complete_libraries_and_interop', 'parents': ['implement_frontend_and_semantics', 'prepare_real_native_hosts'],
     'dimensions': ['runtime_apis', 'interoperability'],
     'action': 'Implement/version-bind the complete mandatory library/API surface and verify foreign ABI, lifetimes, callbacks and errors'},
    {'step': 'implement_and_validate_translation', 'parents': ['complete_libraries_and_interop'],
     'dimensions': ['semantic_translation', 'native_execution'],
     'action': 'Lower real source semantics through typed/effect IR; freshly compare category-native and generated observations, retaining unsupported cases'},
    {'step': 'prove_declared_intent', 'parents': ['implement_and_validate_translation'], 'dimensions': ['intent_verification'],
     'action': 'Use independent formal/executable intent, heldouts and checked proofs; universal proof requires an adequate model and explicit assumptions'},
    {'step': 'close_conformance_coverage', 'parents': ['prove_declared_intent', 'audit_all_normative_rules'], 'dimensions': ['conformance'],
     'action': 'Run normative/upstream/independent suites, properties and fuzzing; resolve every applicable clause and mandatory API gap'},
    {'step': 'qualify_claimed_platforms_and_cost', 'parents': ['close_conformance_coverage'], 'dimensions': ['portability', 'performance', 'safety'],
     'action': 'Freshly validate every claimed actual platform/device, isolation and limits; measure real end-to-end resources and preserve blockers'},
    {'step': 'independent_review_and_release', 'parents': ['qualify_claimed_platforms_and_cost'], 'dimensions': ['certification'],
     'action': 'Independently review complete exact-build evidence, clean-extract/retest, hash-bind release and make only the supported qualification claim'},
]


def get_gate_plan(category, dimension, normative_requirements, semantic_focus=None):
    """Return open leaf-level acceptance contracts without modifying caller data.

    The caller retains per-ID identity, exact rule text, evidence and status.  A
    family match is only an opportunity to reuse a pure artifact, never evidence
    that this ID/version meets these contracts.  Unknown IDs fail closed rather
    than receiving an accidental generic 'passed' or 'not applicable' contract.
    """
    if category not in CATEGORY_CONTRACTS:
        raise ValueError('Unknown qualification category: ' + str(category))
    if dimension not in DIMENSION_REQUIREMENTS:
        raise ValueError('Unknown qualification dimension: ' + str(dimension))
    if not isinstance(normative_requirements, (list, tuple)) or not normative_requirements:
        raise ValueError('A dimension requires a nonempty normative leaf inventory')
    if len(set(normative_requirements)) != len(normative_requirements):
        raise ValueError('Duplicate normative leaf IDs')
    if set(normative_requirements) != set(DIMENSION_REQUIREMENTS[dimension]):
        raise ValueError('Normative leaf inventory must preserve every original requirement in ' + dimension)
    focus = [] if semantic_focus is None else list(semantic_focus)
    if any(not isinstance(item, str) or not item.strip() for item in focus):
        raise ValueError('Semantic focus entries must be nonempty strings')
    category_contract = CATEGORY_CONTRACTS[category]
    leaves = []
    for requirement in normative_requirements:
        acceptance, evidence_types, tests = LEAF_CONTRACTS[requirement]
        leaves.append({
            'requirement': requirement,
            'status': 'open',
            'obligation_class': OBLIGATION_CLASSES[dimension],
            'requirement_origin': 'original_project_obligation_not_audited_normative_clause',
            'standard_mandated_status': 'requires_exact_standard_audit',
            'acceptance': list(acceptance) + [
                'Instantiate this obligation against this exact ID/version and the category operation: ' + category_contract['operation'],
                'Attach cited normative rule text, implementation links, independent case/oracle identities and fresh or formally checked evidence as appropriate',
            ],
            'evidence_types': list(evidence_types),
            'tests': list(tests),
            'category_contract': deepcopy(category_contract),
            'binding_fields': list(BINDING_FIELDS),
            'applicability': {
                'status': 'unresolved',
                'automatic_not_applicable': False,
                'verified_not_applicable_requires': list(NA_REQUIREMENTS),
            },
            'proof_strength_policy': {
                'tests_prove_only_declared_executed_or_exhaustive_domain': True,
                'universal_claim_requires_sound_adequate_model_and_checked_proof': True,
                'missing_or_unmodelled_obligations_remain_open': True,
            },
        })
    return {
        'schema': 'usl.qualification-dimension-contract.v1',
        'category': category,
        'dimension': dimension,
        'prerequisites': list(DIMENSION_PARENTS[dimension]),
        'parents': list(DIMENSION_PARENTS[dimension]),
        'semantic_focus': focus,
        'binding_fields': list(BINDING_FIELDS),
        'acceptance_policy': {
            'initial_status': 'open',
            'requires_all_applicable_normative_leaves': True,
            'requires_complete_reviewed_normative_inventory': True,
            'missing_mandatory_feature_prevents_full_qualification': True,
            'verified_na_requires_authoritative_citations_and_independent_review': True,
            'native_embedding_is_semantic_translation': False,
            'no_formal_standard_claim': 'whole_implementation_qualified_for_exact_baseline; never full_standard_qualified',
            'official_certification_requires_scheme': True,
            'project_gates_are_automatically_standard_mandated': False,
            'normative_conformance_translation_intent_and_release_are_separate_claims': True,
            'evidence_reuse': 'Exact pure artifact identity may be reused; execution observations and external effects must be freshly observed',
        },
        'leaves': leaves,
        'family_evidence_transfers_qualification': False,
        'created_rule_records': 0,
        'qualification_evidence_created': False,
    }


def validate_contract_inventory():
    expected = {leaf for leaves in DIMENSION_REQUIREMENTS.values() for leaf in leaves}
    if set(LEAF_CONTRACTS) != expected:
        raise ValueError('Leaf contract inventory is incomplete or has untracked additions')
    if set(DIMENSION_PARENTS) != set(DIMENSION_REQUIREMENTS):
        raise ValueError('Dimension prerequisite graph is incomplete')
    visiting, visited = set(), set()
    def visit(dimension):
        if dimension in visiting:
            raise ValueError('Qualification graph has a dependency cycle')
        if dimension in visited:
            return
        visiting.add(dimension)
        for parent in DIMENSION_PARENTS[dimension]:
            if parent not in DIMENSION_REQUIREMENTS:
                raise ValueError('Qualification graph has an unknown parent')
            visit(parent)
        visiting.remove(dimension)
        visited.add(dimension)
    for dimension in DIMENSION_REQUIREMENTS:
        visit(dimension)
    return {'dimensions': len(DIMENSION_REQUIREMENTS), 'normative_leaf_contracts': len(expected),
            'categories': len(CATEGORY_CONTRACTS), 'acyclic': True}


validate_contract_inventory()
