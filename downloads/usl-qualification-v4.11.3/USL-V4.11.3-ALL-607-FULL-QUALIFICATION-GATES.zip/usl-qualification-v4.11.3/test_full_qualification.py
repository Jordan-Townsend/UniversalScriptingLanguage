import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
from full_qualification import ROOT, DEFAULT_INPUT, closure_errors, decide, digest, load_entries, verify_input
from gate_plans import DIMENSION_REQUIREMENTS, DIMENSION_PARENTS


def task_fixture(status='open'):
    flags={k:False for k in ['target_pinned','normative_inventory_closed','full_profile_semantics_verified','translation_refinement_verified','independent_full_review_verified','release_reproducibility_verified','full_profile_verifier_installed']}
    flags['gates']=[{'dimension':dimension,'leaves':[{'requirement':r,'status':status} for r in requirements]} for dimension,requirements in DIMENSION_REQUIREMENTS.items()]
    return flags


class FullQualificationTests(unittest.TestCase):
    def test_every_original_and_usl_retains_all_48_obligations(self):
        rows=load_entries(DEFAULT_INPUT)
        self.assertEqual(len(rows),607);self.assertEqual(sum(r['original_catalog'] for r in rows),606)
        self.assertEqual(sum(sum(len(d['normative_requirements']) for d in r['obligation_dimensions']) for r in rows),29136)
        self.assertEqual(next(r for r in rows if r['catalog_id']=='usl')['scoped'],False)

    def test_extensions_are_unbounded_by_607_and_cannot_promote_themselves(self):
        extras=[{'catalog_id':'future-language-'+str(n),'category_candidate':'source_program'} for n in range(127)]
        rows=load_entries(DEFAULT_INPUT,extras)
        self.assertEqual(len(rows),734);self.assertTrue(all(not r['scoped'] for r in rows[607:]))
        for bad in [[extras[0],extras[0]],[{'catalog_id':'usl','category_candidate':'source_program'}],
                    [{'catalog_id':'future','category_candidate':'source_program','passed':True}],
                    [{'catalog_id':'future','category_candidate':'undefined-category'}]]:
            with self.subTest(bad=bad),self.assertRaises(ValueError):load_entries(DEFAULT_INPUT,bad)

    def test_log_and_transcript_contract_is_not_program_execution(self):
        rows=load_entries(DEFAULT_INPUT)
        selected=[r for r in rows if r['family']=='Transcripts, logs and protocol messages']
        self.assertEqual(len(selected),42)
        self.assertTrue(all(r['category_candidate']=='transcript_log_or_protocol' for r in selected))
        self.assertTrue(all(r['historical_category_proposal']=='source_program' for r in selected))

    def test_usl_cannot_turn_bounded_support_or_unknown_into_pass(self):
        policy=(ROOT/'qualification.usl').read_text()
        for status in ['open','partial_historical_support','unknown','solver_unsat_on_examples']:
            task=task_fixture(status)
            for key in task:
                if key not in {'gates','full_profile_verifier_installed'}:task[key]=True
            result,receipt=decide(task,policy)
            self.assertEqual(result['open_leaves'],48);self.assertFalse(result['full_standard_qualified'])
            self.assertTrue(receipt['actual_USL_execution'])

    def test_no_vacuous_or_duplicate_gate_acceptance(self):
        policy=(ROOT/'qualification.usl').read_text()
        for task in [dict(task_fixture(),gates=[]),dict(task_fixture(),gates=task_fixture()['gates'][:-1])]:
            with self.assertRaises(ValueError):decide(task,policy)
        task=task_fixture();task['gates'][1]=copy.deepcopy(task['gates'][0])
        with self.assertRaises(ValueError):decide(task,policy)
        task=task_fixture();task['gates'][0]['leaves'][1]=copy.deepcopy(task['gates'][0]['leaves'][0])
        with self.assertRaises(ValueError):decide(task,policy)

    def test_raw_verified_leaves_cannot_install_a_checker(self):
        task=task_fixture('verified')
        for key in task:
            if key not in {'gates','full_profile_verifier_installed'}:task[key]=True
        with self.assertRaises(ValueError):decide(task,(ROOT/'qualification.usl').read_text())

    def test_clause_structure_rejects_unmapped_or_unproved_rules(self):
        target={'exact_version':'a finite test contract','specification_sha256':'a'*64,'inventory_independently_reviewed':True,'inventory_closed':True,'normative_clause_ids':['R1','R2']}
        partial={'clause_id':'R1','source_locator':'section1','implementation_sha256':'b'*64,'implementation_locator':'line1',
                 'independent_tests':['case1'],'native_observations':['receipt1'],'proof_scope':'finite_examples','trusted_checker_verified':False}
        errors=closure_errors(target,[partial]);self.assertTrue(any('exact normative set' in e for e in errors))
        self.assertTrue(any('machine-checked' in e for e in errors))
        claimed_na={'clause_id':'R2','source_locator':'section2','applicability':'not_applicable'}
        self.assertTrue(any('not-applicable' in e for e in closure_errors(target,[partial,claimed_na])))

    def test_pinned_manifest_cannot_be_replaced_by_self_consistent_forgery(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d,'MANIFEST.json').write_text(json.dumps({'version':'4.11.2','files':{}}))
            with self.assertRaises(ValueError):verify_input(d)

    def test_all_id_outputs_retain_qualification_dependencies(self):
        report=json.loads((ROOT/'results/ALL_ID_QUALIFICATION.json').read_text())
        rows=report['records'];self.assertEqual(len(rows),607)
        contracts=json.loads((ROOT/'results/GATE_CONTRACTS.json').read_text())
        for key,value in contracts.items():self.assertEqual(key,digest(value))
        for row in rows:
            self.assertFalse(row['full_standard_qualified'])
            self.assertEqual(len(row['gates']),18)
            self.assertEqual(row['USL_decision']['open_leaves'],48)
            self.assertEqual(sum(len(g['leaves']) for g in row['gates']),48)
            for gate in row['gates']:
                self.assertIn(gate['contract_sha256'],contracts)
                self.assertEqual(gate['prerequisites'],DIMENSION_PARENTS[gate['dimension']])
        queue=json.loads((ROOT/'results/WORK_QUEUE.json').read_text())['tasks'];ids={t['task_id'] for t in queue}
        self.assertEqual(len(queue),10926);self.assertEqual(len(ids),10926)
        self.assertTrue(all(set(t['parents'])<=ids for t in queue))


if __name__=='__main__':unittest.main()
