"""Inventory the actual USL host implementation and run its existing core tests.

An implementation-source inventory is a candidate input for a normative USL
contract, not a published standard, full rule audit or universal compiler proof.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def inventory(source_root,output):
    source_root=Path(source_root).resolve();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(source_root))
    from usl_systems import language
    module=Path(language.__file__).resolve()
    if module!=source_root/'usl_systems/language.py':raise ValueError('Loaded an unintended USL host')
    source=module.read_bytes();tree=ast.parse(source)
    source_hash=hashlib.sha256(source).hexdigest()
    functions=[{'name':node.name,'line':node.lineno,'end_line':node.end_lineno,
                'source_sha256':source_hash} for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))]
    log=output/'USL_CORE_TESTS.log';started=time.perf_counter()
    env=dict(os.environ);env['PYTHONPATH']=str(source_root);env['PYTHONDONTWRITEBYTECODE']='1'
    with log.open('w') as stream:
        ran=subprocess.run([sys.executable,'-m','unittest','tests.test_core.LanguageTests','-v'],cwd=source_root,env=env,
                           stdout=stream,stderr=subprocess.STDOUT,timeout=30)
    match=re.search(r'Ran (\d+) tests?',log.read_text())
    if ran.returncode or not match or int(match[1])!=18:raise ValueError('USL core workflow failed; inspect '+str(log))
    if hashlib.sha256(module.read_bytes()).hexdigest()!=source_hash:raise ValueError('Host source changed during checks')
    report={'schema':'usl.host-source-inventory-and-core-validation.v1','catalog_id':'usl','passed':True,
            'specification_kind':'implementation-source inventory candidate; normative USL specification audit remains open',
            'source_sha256':source_hash,'test_source_sha256':hashlib.sha256((source_root/'tests/test_core.py').read_bytes()).hexdigest(),
            'Python_version':sys.version,'fresh_test_processes':1,'fresh_core_tests':int(match[1]),'native_execution_results_cached':False,
            'statement_kinds':[t.__name__ for t in language.SUPPORTED_STMTS],
            'expression_kinds':[t.__name__ for t in language.SUPPORTED_EXPRS],
            'binary_operators':[t.__name__ for t in language.BINOPS],
            'comparison_operators':[t.__name__ for t in language.CMPOPS],
            'unary_operators':[t.__name__ for t in language.UNARYOPS],
            'builtins':sorted(language.BUILTINS),'source_functions':functions,
            'normalization_features':['let declarations','function definitions','legacy Symbolic prefixes','C++-style full-line comments','legacy print syntax'],
            'runtime_limits':{'operations':100000,'seconds':4.0,'output_characters':50000,'call_depth':50},
            'normative_rule_set_complete':False,'full_standard_qualified':False,'implementation_contract_fully_qualified':False,
            'missing':['authoritative versioned complete USL specification and errata policy','reviewed grammar/static/dynamic semantic clauses for every supported construct and host capability','complete library/effect/ABI and platform obligations','whole-profile translation/implementation correctness checker and independent final review'],
            'test_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'seconds':time.perf_counter()-started}
    (output/'USL_HOST_INVENTORY.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':True,'USL_core_tests':18,'statements':len(report['statement_kinds']),'expressions':len(report['expression_kinds']),
                      'builtins':len(report['builtins']),'full_standard_qualified':False}));return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('usl-host-results'))
    a=p.parse_args();inventory(a.source_root,a.output)
