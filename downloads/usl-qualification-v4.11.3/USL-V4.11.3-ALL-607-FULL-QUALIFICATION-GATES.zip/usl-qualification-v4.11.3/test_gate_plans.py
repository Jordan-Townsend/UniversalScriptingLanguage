"""Qualification policies must retain obligations and fail closed on claim gaps."""
import copy
import json
import unittest

from gate_plans import (CATEGORY_CONTRACTS, DIMENSION_PARENTS,
                        DIMENSION_REQUIREMENTS, QUALIFICATION_STEPS,
                        get_gate_plan, validate_contract_inventory)


class GateContractTests(unittest.TestCase):
    def plan(self, dimension, category='source_program', focus=None):
        return get_gate_plan(category, dimension,
                             DIMENSION_REQUIREMENTS[dimension], focus)

    def test_every_original_obligation_is_retained_in_every_category(self):
        inventory = validate_contract_inventory()
        self.assertEqual(inventory['dimensions'], 18)
        self.assertEqual(inventory['normative_leaf_contracts'], 48)
        for category in CATEGORY_CONTRACTS:
            actual = []
            for dimension, requirements in DIMENSION_REQUIREMENTS.items():
                with self.subTest(category=category, dimension=dimension):
                    plan = get_gate_plan(category, dimension, requirements)
                    self.assertEqual([leaf['requirement'] for leaf in plan['leaves']], requirements)
                    actual.extend(leaf['requirement'] for leaf in plan['leaves'])
                    self.assertEqual(plan['prerequisites'], DIMENSION_PARENTS[dimension])
                    self.assertFalse(plan['family_evidence_transfers_qualification'])
                    self.assertFalse(plan['qualification_evidence_created'])
                    self.assertEqual(plan['created_rule_records'], 0)
                    for leaf in plan['leaves']:
                        self.assertEqual(leaf['status'], 'open')
                        self.assertGreaterEqual(len(leaf['acceptance']), 3)
                        self.assertGreaterEqual(len(leaf['evidence_types']), 3)
                        self.assertGreaterEqual(len(leaf['tests']), 2)
            self.assertEqual(len(actual), 48)
            self.assertEqual(len(set(actual)), 48)

    def test_inventory_cannot_drop_duplicate_or_relabel_an_obligation(self):
        required = DIMENSION_REQUIREMENTS['numbers_and_data']
        mutations = [required[:-1], required + [required[0]],
                     ['approximate_numbers'] + required[1:], [], None]
        for mutation in mutations:
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                get_gate_plan('source_program', 'numbers_and_data', mutation)
        with self.assertRaises(ValueError):
            get_gate_plan('unknown_program', 'numbers_and_data', required)
        with self.assertRaises(ValueError):
            get_gate_plan('source_program', 'invented_dimension', required)

    def test_no_automatic_na_or_missing_host_waiver(self):
        for category in CATEGORY_CONTRACTS:
            for dimension in ['concurrency', 'interoperability', 'portability']:
                plan = self.plan(dimension, category)
                for leaf in plan['leaves']:
                    decision = leaf['applicability']
                    self.assertEqual(decision['status'], 'unresolved')
                    self.assertFalse(decision['automatic_not_applicable'])
                    criteria = ' '.join(decision['verified_not_applicable_requires']).lower()
                    self.assertIn('authoritative clauses', criteria)
                    self.assertIn('independent reviewer', criteria)
                    self.assertIn('absent runtime', criteria)
                    self.assertIn('may be classified not applicable', criteria)
        unavailable = self.plan('portability')['leaves'][1]
        self.assertIn('blocked', ' '.join(unavailable['acceptance']))

    def test_formats_and_logs_have_real_processing_not_imaginary_cpu_execution(self):
        for category in ['document_processing', 'transcript_log_or_protocol']:
            plan = self.plan('native_execution', category)
            for leaf in plan['leaves']:
                operation = leaf['category_contract']['operation']
                self.assertNotIn('execute source programs', operation)
                self.assertTrue(any(word in operation for word in ['documents', 'protocol messages']))
        transcript = self.plan('semantic_translation', 'transcript_log_or_protocol')
        self.assertIn('never evidence', transcript['leaves'][0]['category_contract']['translation'])
        self.assertIn('separately identified embedded runtime',
                      transcript['leaves'][0]['category_contract']['native_evidence'])

    def test_query_and_template_equivalence_observe_their_own_semantics(self):
        query = self.plan('semantic_translation', 'query')['leaves'][0]['category_contract']
        self.assertIn('NULL/missing and collation behavior', query['observables'])
        self.assertIn('multisets', query['translation'])
        template = self.plan('semantic_translation', 'composite_template')['leaves'][0]['category_contract']
        self.assertIn('escaping in each output context', template['observables'])
        self.assertIn('embedded-runtime', template['native_evidence'])
        grammar = self.plan('native_execution', 'grammar_schema_or_interface')['leaves'][0]['category_contract']
        self.assertIn('generated target execution', grammar['native_evidence'])

    def test_proof_and_device_claims_keep_trust_and_real_execution_boundaries(self):
        proof = self.plan('native_execution', 'proof_or_analysis')['leaves'][0]['category_contract']
        self.assertIn('bounded/unknown outcomes', ' '.join(proof['observables']))
        self.assertIn('not universal validity', proof['translation'])
        device = self.plan('backend', 'device_or_simulation')['leaves'][0]['category_contract']
        self.assertIn('actual-device receipts kept distinct', device['native_evidence'])
        self.assertIn('unrun real-device result', device['translation'])

    def test_full_standard_and_whole_implementation_are_separate_claims(self):
        plan = self.plan('identity')
        self.assertIn('never full_standard_qualified', plan['acceptance_policy']['no_formal_standard_claim'])
        self.assertIn('official_certification_requires_scheme', plan['acceptance_policy'])
        authority = ' '.join(plan['leaves'][0]['acceptance'])
        self.assertIn('whole-implementation qualification', authority)
        self.assertIn('never full-standard certification', authority)

    def test_finite_tests_do_not_prove_all_programs_or_unformalized_intent(self):
        plan = self.plan('intent_verification')
        claim = ' '.join(plan['leaves'][-1]['acceptance'])
        self.assertIn('unmodelled or universal obligations open', claim)
        self.assertIn('unrestricted arbitrary-program', claim)
        for leaf in plan['leaves']:
            self.assertTrue(leaf['proof_strength_policy']['tests_prove_only_declared_executed_or_exhaustive_domain'])
        translation = self.plan('semantic_translation')
        self.assertFalse(translation['acceptance_policy']['native_embedding_is_semantic_translation'])

    def test_project_gates_are_not_invented_standard_requirements(self):
        for dimension in ['performance', 'semantic_translation', 'intent_verification', 'certification']:
            plan = self.plan(dimension)
            self.assertFalse(plan['acceptance_policy']['project_gates_are_automatically_standard_mandated'])
            self.assertTrue(plan['acceptance_policy']['normative_conformance_translation_intent_and_release_are_separate_claims'])
            for leaf in plan['leaves']:
                self.assertTrue(leaf['obligation_class'].startswith('project_'))
                self.assertEqual(leaf['standard_mandated_status'], 'requires_exact_standard_audit')
                self.assertEqual(leaf['requirement_origin'], 'original_project_obligation_not_audited_normative_clause')

    def test_exact_identity_bindings_are_not_replaceable_with_family_labels(self):
        plan = self.plan('certification')
        required = ['catalog_id', 'normative_clause_ids', 'source_tree_sha256',
                    'native_toolchain_version_and_binary_sha256',
                    'target_triple_or_host_identity', 'os_architecture_and_device',
                    'test_source_and_independent_oracle_sha256', 'execution_receipt_sha256']
        for field in required:
            self.assertIn(field, plan['binding_fields'])
            for leaf in plan['leaves']:
                self.assertIn(field, leaf['binding_fields'])
        self.assertNotIn('family', plan['binding_fields'])

    def test_plans_are_deterministic_json_and_do_not_share_mutable_state(self):
        requirements = copy.deepcopy(DIMENSION_REQUIREMENTS['grammar'])
        focus = ['macro hygiene', 'module phase separation']
        first = get_gate_plan('source_program', 'grammar', requirements, focus)
        original = json.dumps(first, sort_keys=True)
        second = get_gate_plan('source_program', 'grammar', requirements, focus)
        self.assertEqual(original, json.dumps(second, sort_keys=True))
        first['leaves'][0]['category_contract']['observables'].clear()
        first['leaves'][0]['applicability']['verified_not_applicable_requires'].clear()
        first['semantic_focus'].append('mutated')
        self.assertEqual(original, json.dumps(get_gate_plan('source_program', 'grammar', requirements, focus), sort_keys=True))
        self.assertEqual(focus, ['macro hygiene', 'module phase separation'])
        self.assertEqual(requirements, DIMENSION_REQUIREMENTS['grammar'])
        with self.assertRaises(ValueError):
            self.plan('grammar', focus=[''])

    def test_engineering_steps_form_a_complete_acyclic_plan(self):
        steps = {row['step']: row for row in QUALIFICATION_STEPS}
        self.assertEqual(len(steps), 10)
        self.assertEqual({dimension for row in steps.values() for dimension in row['dimensions']},
                         set(DIMENSION_REQUIREMENTS))
        ready = set()
        while len(ready) < len(steps):
            newly = {key for key, row in steps.items()
                     if key not in ready and set(row['parents']) <= ready}
            self.assertTrue(newly, 'Engineering plan contains a cycle or missing prerequisite')
            ready |= newly
        self.assertEqual(ready, set(steps))


if __name__ == '__main__':
    unittest.main()
