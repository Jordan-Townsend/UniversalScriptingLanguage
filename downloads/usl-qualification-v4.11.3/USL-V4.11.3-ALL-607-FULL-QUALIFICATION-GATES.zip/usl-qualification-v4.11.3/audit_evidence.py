"""Fail-closed integrity and coverage audit of the published v4.11.2 evidence.

Historical execution receipts are inspected, never presented as fresh execution.
No receipt in this input establishes complete language-standard qualification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(root, name):
    path = (Path(root) / name).resolve()
    require(path.is_relative_to(Path(root).resolve()), 'Artifact escapes input root')
    return json.loads(path.read_text())


def artifact(root, name):
    path = (Path(root) / name).resolve()
    require(path.is_relative_to(Path(root).resolve()) and path.is_file(), 'Missing or unsafe artifact: ' + name)
    return {'path': name, 'sha256': sha(path), 'bytes': path.stat().st_size}


def verify_manifest(root):
    document = read(root, 'MANIFEST.json')
    require(document.get('version') == '4.11.2', 'Unexpected historical release version')
    require(bool(document.get('files')), 'Empty historical source manifest')
    for name, expected in document['files'].items():
        actual = artifact(root, name)
        require(actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes'],
                'Historical release artifact changed: ' + name)
    return {'manifest': artifact(root, 'MANIFEST.json'), 'verified_files': len(document['files']),
            'trust_boundary': 'Local integrity against the supplied release manifest, not external certification or a digital signature'}


def verify_source_hashes(root, identities):
    require(bool(identities), 'Missing implementation identity bindings')
    return [artifact(root, name) for name, expected in identities.items()
            if _check_source(root, name, expected)]


def _check_source(root, name, expected):
    require(artifact(root, name)['sha256'] == expected, 'Changed implementation source: ' + name)
    return True


def validate_json_receipts(root, upstream, independent, rules, cases, *, suite=None):
    """Compare each original contract with source behavior and receipt observations.

    Current parsing and generation here are integrity/contract rechecks. Native and
    USL process counts in these receipts remain historical observations.
    """
    from json_semantics import JSONResourceLimit, JSONRuleError, generate_json, parse_json

    require(upstream.get('schema') == 'usl.JSON.published-RFC8259-candidate.v1', 'Unexpected JSON profile')
    require(upstream.get('passed') is True and independent.get('passed') is True, 'JSON receipts contain failures')
    require(upstream.get('full_standard_qualified') is False and independent.get('universal_program_correctness_proved') is False,
            'JSON receipt makes an unsupported whole-profile claim')
    require(upstream.get('native_observations_replayed') is False, 'JSON historical run replay flag changed')
    require(upstream['suite_commit'] == '1ef36fa01286573e846ac449e8683f8833c5b26a', 'JSON suite identity changed')
    require(len(upstream['records']) == upstream['suite_cases'] == 318, 'JSON upstream coverage missing')
    rows = {r['file']: r for r in upstream['records']}
    require(len(rows) == 318, 'Duplicate JSON upstream cases')
    accepted = rejected = limited = 0
    for name, row in rows.items():
        require(row.get('passed') is True, 'JSON historical counterexample: ' + name)
        expectation = True if name.startswith('y_') else False if name.startswith('n_') else None
        require(row.get('suite_expectation') is expectation, 'Changed upstream classification')
        if row['accepted'] is True:
            accepted += 1
            require(expectation is not False and row['native_original']['accepted'] is True
                    and row['native_generated']['accepted'] is True
                    and row['native_original']['IR'] == row['IR'] == row['native_generated']['IR']
                    and row.get('generated_USL_matches') is True and row.get('roundtrip_matches') is True,
                    'Inconsistent JSON successful receipt: ' + name)
            generated = generate_json(row['IR'], duplicate_policy='preserve')
            require(hashlib.sha256(generated).hexdigest() == row['generated_json_sha256']
                    and parse_json(generated) == row['IR'], 'JSON generated artifact no longer agrees')
        elif row['accepted'] is False:
            rejected += 1
            require(expectation is not True and row['native_original']['accepted'] is False,
                    'Inconsistent JSON rejection receipt')
        else:
            limited += 1
            require(row['accepted'] is None and bool(row.get('permitted_resource_limit')),
                    'Unexplained JSON result')
    require((accepted, rejected, limited) == (116, 199, 3), 'JSON case partition changed')
    require(upstream['fresh_native_processing_cases'] == 318 + accepted
            and upstream['fresh_USL_translation_cases'] == accepted,
            'JSON historical upstream accounting changed')

    expected = {case.id: case for case in cases}
    observed = {row['case']: row for row in independent['records']}
    require(len(cases) == len(expected) == len(observed) == len(independent['records']) == 612
            and set(expected) == set(observed), 'JSON independent contract coverage changed')
    generated_count = 0
    for name, case in expected.items():
        row = observed[name]
        require(row.get('passed') is True and row.get('expected_acceptance') is case.accepts
                and row['clauses'] == list(case.clauses) and row['policy'] == case.policy,
                'JSON independent contract changed: ' + name)
        try:
            value = parse_json(case.input)
        except JSONResourceLimit:
            require(not case.accepts and row.get('resource_limited') is True, 'Unexpected JSON resource restriction')
        except JSONRuleError:
            require(not case.accepts and row.get('resource_limited') is False, 'Unexpected JSON rule rejection')
        else:
            require(case.accepts and value == case.expected, 'Current JSON intent counterexample: ' + name)
            generated = generate_json(value, duplicate_policy='preserve')
            require(hashlib.sha256(generated).hexdigest() == row.get('generated_sha256')
                    and parse_json(generated) == case.expected, 'JSON independent generation differs')
            generated_count += 1
    require(independent['independent_intent_vectors'] == 612
            and independent['fresh_generated_USL_executions'] == generated_count == 510
            and independent['fresh_native_processing_cases'] == 612 + generated_count,
            'JSON independent historical accounting changed')

    groups = [('grammar_productions', 30), ('uppercase_requirements', 10), ('prose_and_interoperability', 22)]
    for key, count in groups:
        require(len(rules[key]) == count and len({r['id'] for r in rules[key]}) == count,
                'JSON normative inventory missing or duplicated: ' + key)
    require(rules.get('whole_standard_qualification') is False
            and rules.get('whole_programming_language_qualification') is False,
            'JSON inventory promoted to qualification')
    require(any(r['id'] == '5318' for r in rules['errata_policy']['unresolved']), 'JSON erratum decision disappeared')

    rechecked_sources = 0
    if suite is not None and Path(suite).is_dir():
        suite = Path(suite)
        files = {p.name: p for p in (suite / 'test_parsing').glob('*.json')}
        require(set(files) == set(rows), 'Installed JSON upstream corpus differs')
        commit = subprocess.check_output(['git', '-C', str(suite), 'rev-parse', 'HEAD'], text=True).strip()
        require(commit == upstream['suite_commit'], 'Installed JSON upstream commit differs')
        for name, path in files.items():
            require(sha(path) == rows[name]['source_sha256'], 'Changed upstream JSON case: ' + name)
            rechecked_sources += 1
    return {'enumerated_normative_inventory_records': 62, 'grammar_productions': 30,
            'uppercase_requirements': 10, 'prose_obligations': 22,
            'upstream_receipt_cases': 318, 'upstream_source_bodies_hash_rechecked': rechecked_sources,
            'upstream_permitted_resource_limit_cases': limited, 'independent_contracts_recomputed': 612,
            'historical_native_processing_cases': 1556, 'historical_generated_USL_executions': 626,
            'erratum_5318': 'Unresolved for latest-errata claims; exact published December 2017 text explicitly targeted',
            'current_audit_native_executions': 0, 'current_audit_generated_USL_executions': 0}


COMMON_MISSING = [
    'Independently reviewed complete versioned normative obligations, including applicable library and platform clauses',
    'Complete implementation and evidence for every applicable obligation, beyond bounded examples',
    'Whole-profile semantic preservation and independently authored intent evidence with declared assumptions',
    'Full conformance, applicable interoperability/ABI and platform qualification, reproducible release and independent final review',
]


def _audit_local(input_root, source_root):
    root = Path(input_root).resolve(); source_root = Path(source_root).resolve()
    sys.path[:0] = [str(root), str(root / 'json-audit'), str(source_root)]
    manifest = verify_manifest(root)
    catalog = read(root, 'joined-results/catalog.json')
    rows = catalog['entries']
    require(len(rows) == len({r['catalog_id'] for r in rows}) == 607, 'All 607 catalog identities are required')
    require(sum(r['original_catalog'] for r in rows) == 606, 'Original catalog identity count changed')
    require(all(r.get('full_standard_qualified') is False for r in rows), 'Unexpected catalog qualification promotion')
    from qualification_ledger import validate_forth, validate_antlr
    from planner import apply_scoped_receipt
    from forth_semantics import WORDS
    from brainfuck_semantics import emit_usl as emit_brainfuck
    from independent_cases import all_cases

    validate_forth(root / 'forth-results/qualification.json')
    validate_antlr(root / 'antlr-results/qualification.json')
    base = read(root, 'inputs/catalog.json')
    apply_scoped_receipt(base, root / 'semantic-final/brainfuck/qualification.json')
    forth = read(root, 'forth-results/qualification.json')
    review = read(root, 'forth-review.json')
    require(review.get('passed') is True and review.get('source_unchanged_during_review') is True
            and review.get('failures') == review.get('errors') == 0 and review.get('tests_run') == 10,
            'Independent Forth review contains a failure or missing tests')
    require(review['implementation_sha256'] == sha(root / 'forth_semantics.py')
            and review['test_source_sha256'] == sha(root / 'test_review_forth.py'), 'Forth review source identity differs')
    require(len(WORDS) == 44 and len(forth['groups']) == 51
            and len([g for g in forth['groups'] if g['name'].startswith('word-')]) == 44,
            'Forth selected-word coverage differs')
    require(review['fresh_native_cases'] == 251 and review['fresh_native_processes'] == 42,
            'Independent Forth review accounting differs')
    brainfuck = read(root, 'semantic-final/brainfuck/qualification.json')
    native_count = 0
    for row in brainfuck['records']:
        receipt = row['USL_receipt']
        require(receipt.get('actual_USL_execution') is True
                and receipt.get('generated_source_sha256') == hashlib.sha256(emit_brainfuck(row['source']).encode()).hexdigest(),
                'Brainfuck generated source identity differs')
        native_count += len(row['native_observations'])
    require(native_count == brainfuck['fresh_native_executions'] == 849
            and brainfuck['fresh_generated_USL_executions'] == 426
            and brainfuck.get('native_observation_cache_used') is False,
            'Brainfuck historical accounting differs')

    antlr = read(root, 'antlr-results/qualification.json')
    require(sha(root / 'inputs/antlr4-debian.json') == antlr['toolchain_metadata_sha256'],
            'ANTLR dependency metadata identity differs')
    for proof in antlr['symbolic_predicate_proofs'].values():
        require(set(proof['excludes']) >= {'ANTLR generator/runtime correctness', 'USL interpreter correctness', 'whole-language semantics'},
                'ANTLR limited proof scope exclusions changed')
    upstream = read(root, 'json-results/qualification.json')
    independent = read(root, 'json-results/independent-intent.json')
    rules = read(root, 'json-audit/RFC8259_RULE_AUDIT.json')
    verify_source_hashes(root, upstream['source_identities'])
    verify_source_hashes(root, independent['source_identities'])
    provenance = read(root, 'json-audit/RFC_PROVENANCE.json')
    require(provenance['sha256'] == rules['source_sha256'] and provenance['bytes'] == 28360,
            'JSON normative source provenance differs')
    json_facts = validate_json_receipts(root, upstream, independent, rules, all_cases(),
                                      suite=Path('/workspace/.onboarding/providers/JSONTestSuite'))

    deep = {
        'forth': {'paths': ['forth-results/qualification.json', 'forth-review.json', 'forth_semantics.py', 'qualify_forth.py', 'test_review_forth.py'],
                  'facts': {'selected_words': 44, 'program_groups': 51, 'historical_independent_intent_cases': 866,
                            'historical_native_processing_cases': 866, 'historical_native_processes': 51,
                            'historical_independent_review_tests': 10, 'historical_review_native_cases': 251,
                            'historical_review_native_processes': 42, 'proof_scope': 'Finite tested contracts only; no whole-profile universal proof'},
                  'missing': forth['outstanding'] + review['remaining'],
                  'dimensions': ['syntax', 'semantics', 'typed_ir', 'translation', 'native_execution', 'independent_intent', 'independent_review']},
        'brainfuck': {'paths': ['semantic-final/brainfuck/qualification.json', 'brainfuck_semantics.py'],
                      'facts': {'commands': 8, 'historical_independent_intent_cases': 426,
                                'historical_native_executions': 849, 'historical_generated_USL_executions': 426,
                                'proof_scope': 'All 256 inputs exhausted for the increment program only; arbitrary programs unproved'},
                      'missing': brainfuck['outstanding'],
                      'dimensions': ['syntax', 'semantics', 'typed_ir', 'translation', 'native_execution', 'independent_intent']},
        'json': {'paths': ['json-results/qualification.json', 'json-results/independent-intent.json',
                           'json-audit/RFC8259_RULE_AUDIT.json', 'json-audit/RFC8259_ERRATA_SNAPSHOT.json', 'json-audit/RFC_PROVENANCE.json'],
                 'facts': json_facts, 'missing': upstream['gates_open'] + upstream['not_proved'],
                 'dimensions': ['specification', 'syntax', 'semantics', 'typed_ir', 'translation', 'native_execution', 'independent_intent', 'conformance']},
    }
    for identifier in ['antlr-python', 'antlr-cpp']:
        deep[identifier] = {'paths': ['antlr-results/qualification.json', 'antlr_semantics.py', 'qualify_antlr.py', 'inputs/antlr4-debian.json'],
            'facts': {'historical_native_processing_cases': 2838, 'historical_case_workers_both_backends': 5676,
                      'historical_native_processes_both_backends': 4, 'literal_grammars': 2,
                      'proof_scope': 'Two generated equality/OR predicates match independent finite intent sets for all strings; excludes native generator/runtime, USL interpreter and whole language'},
            'missing': ['All ANTLR4 grammar constructs beyond pinned literal-choice/EOF subset',
                        'Complete target runtime, semantic actions, error and recovery behavior, libraries and normative audit',
                        'Whole-language/native-generator/runtime correctness and independent complete review'],
            'dimensions': ['syntax', 'semantics', 'typed_ir', 'translation', 'native_execution', 'independent_intent', 'proof']}
    output = []
    catalog_provenance = artifact(root, 'joined-results/catalog.json')
    for row in rows:
        identifier = row['catalog_id']; specific = deep.get(identifier)
        record = {'catalog_id': identifier, 'original_catalog': row['original_catalog'],
                  'historical_scoped_claim': row['scoped'], 'deep_receipt_audit_performed': specific is not None,
                  'scope_kind': 'full_candidate' if identifier == 'json' else 'bounded' if row['scoped'] else 'unscoped',
                  'scope': upstream['standard_profile'] if identifier == 'json' else row['scope'],
                  'artifact_provenance': [artifact(root, name) for name in specific['paths']] if specific else [catalog_provenance],
                  'relevant_dimensions': specific['dimensions'] if specific else [],
                  'verified_facts': specific['facts'] if specific else {'catalog_identity_and_status_read': True,
                      'historical_native_receipts_revalidated_in_this_audit': False},
                  'missing_gates': COMMON_MISSING + (specific['missing'] if specific else []),
                  'execution_evidence_kind': 'historical_receipts_integrity_and_contract_audit',
                  'current_audit_native_executions': 0, 'current_audit_generated_USL_executions': 0,
                  'full_standard_qualified': False}
        if identifier == 'usl':
            record['missing_gates'] += ['Published catalog marks USL unscoped; actual host use does not establish self-hosting or full-standard qualification',
                'Complete versioned USL standard, all subsystems and intrinsic semantics, bootstrapping/self-hosting obligations and independent native host proof']
            record['verified_facts']['runtime_used_by_other_profiles_does_not_promote_USL'] = True
        output.append(record)
    return {'schema': 'usl.full-standard.historical-evidence-audit.v1',
            'input_release': '4.11.2', 'manifest_integrity': manifest,
            'source_runtime_root': str(source_root), 'records': output,
            'summary': {'catalog_IDs': 607, 'original_IDs': 606, 'historical_original_scoped_claims': sum(r['scoped'] for r in rows if r['original_catalog']),
                        'deep_receipt_audited_IDs': 5, 'enumerated_published_normative_inventory_candidates': 1,
                        'full_standards_qualified': 0, 'current_audit_native_executions': 0,
                        'current_audit_generated_USL_executions': 0,
                        'historical_core_native_observations_deeply_audited': 866 + 5676 + 849 + 1556,
                        'historical_additional_Forth_review_native_observations': 251,
                        'JSON_independent_contracts_currently_recomputed': 612,
                        'all_full_standard_gates_closed': False},
            'limits': ['Integrity audit cannot certify the truth of historical execution without rerunning native hosts',
                       'Existing bounded statuses outside the five deeply audited IDs are retained historical catalog claims',
                       'Finite tests, normative inventories and limited SMT claims do not prove complete language implementation']}


def audit(input_root, source_root):
    """Isolate legacy imports from the caller and return validated audit records."""
    result = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--worker',
                             '--input-root', str(Path(input_root).resolve()), '--source-root', str(Path(source_root).resolve())],
                            capture_output=True, text=True, timeout=90)
    if result.returncode:
        raise ValueError('Historical evidence audit failed: ' + result.stderr[-3000:])
    return json.loads(result.stdout)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, required=True)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    result = _audit_local(args.input_root, args.source_root) if args.worker else audit(args.input_root, args.source_root)
    encoded = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded)
        print(json.dumps(result['summary']))
    else:
        print(encoded, end='')
