"""Validate the all-catalog qualification workflow and the real USL host core."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent


def verify(input_root,source_root,output):
    input_root=Path(input_root).resolve();source_root=Path(source_root).resolve();output=Path(output).resolve()
    output.mkdir(parents=True,exist_ok=True);started=time.perf_counter()
    env=dict(os.environ);env['PYTHONPATH']=str(source_root)+os.pathsep+env.get('PYTHONPATH','');env['PYTHONDONTWRITEBYTECODE']='1'
    source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.usl'))}
    def command(name,args):
        log=output/(name+'.log')
        with log.open('w') as stream:
            result=subprocess.run([sys.executable]+args,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
        if result.returncode:raise ValueError(name+' failed: '+str(log))
        return {'passed':True,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    gate=command('all-ID-gates',['full_qualification.py','--input-root',str(input_root),'--source-root',str(source_root),'--output',str(output/'gates')])
    tests=command('regressions',['-m','unittest','discover','-v'])
    count=re.search(r'Ran (\d+) tests?',(output/'regressions.log').read_text())
    if not count or int(count[1])<1:raise ValueError('No completed regression suite observed')
    tests['tests_run']=int(count[1])
    host=command('USL-host',['usl_host_inventory.py','--source-root',str(source_root),'--output',str(output/'usl-host')])
    summary=json.loads((output/'gates/SUMMARY.json').read_text());native=json.loads((output/'usl-host/USL_HOST_INVENTORY.json').read_text())
    if (summary['catalog_IDs'],summary['gate_checks'],summary['requirement_groups_checked'],summary['full_standards_qualified'])!=(607,10926,29136,0):raise ValueError('All-ID gate coverage changed')
    if not all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==identity for name,identity in source_hashes.items()):raise ValueError('Qualification source changed during validation')
    result={'passed':True,'all_ID_gate_audit':gate,'regressions':tests,'USL_host_check':host,'USL_core_tests':native['fresh_core_tests'],
            'catalog_IDs':607,'gate_dimensions':10926,'requirement_groups':29136,'full_standards_qualified':0,
            'fresh_original_language_native_runs_from_historical_audit':0,'historical_receipts_reaudited':True,
            'source_unchanged_during_validation':True,'source_sha256':source_hashes,'seconds':time.perf_counter()-started}
    (output/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}));return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input-root',type=Path,default=Path('/workspace/usl-planning-v4.11.2'))
    p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('/tmp/usl-v4113-validation'))
    a=p.parse_args();verify(a.input_root,a.source_root,a.output)
