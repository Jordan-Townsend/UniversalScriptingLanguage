'use strict';
const $=id=>document.getElementById(id);
const labels={home:'Overview',forge:'Forge IDE',shadow:'Shadow AI',languages:'Languages','source-lab':'Source Lab',jobs:'Operations',bridge:'Process Bridge',integrations:'Integrations',research:'Equation & Worker Lab',autonomy:'Autonomy',system:'System'};
let active='home',langOffset=0,langCount=0,pending=new Set();
const example=`// Core USL: safe, executable source\nlet total = 0\nfor i in range(10):\n    total += i\nif total == 45:\n    print("USL execution verified:", total)\nelse:\n    print("Unexpected result")\nassert total == 45\n`;
$('editor').value=example;
async function request(path,data){
 const cfg=data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)};
 const res=await fetch(path,cfg);const obj=await res.json();if(!res.ok)throw Error(obj.error||`HTTP ${res.status}`);return obj;
}
function nav(id){if(id==='source-lab')renderSourceLab();active=id;document.querySelectorAll('.page').forEach(el=>el.classList.toggle('visible',el.id===id));document.querySelectorAll('[data-nav]').forEach(el=>el.classList.toggle('active',el.dataset.nav===id));$('page-title').textContent=labels[id];if(id==='languages')renderLang(true);if(id==='jobs')renderJobs();if(id==='system')renderSystem();if(id==='bridge')renderBridge();if(id==='integrations')renderIntegrations();if(id==='research')renderResearch();if(id==='autonomy')renderAutonomy();if(id==='shadow')renderModel();}
document.querySelectorAll('[data-nav]').forEach(el=>el.addEventListener('click',()=>nav(el.dataset.nav)));
document.querySelectorAll('[data-go]').forEach(el=>el.addEventListener('click',()=>nav(el.dataset.go)));
function escapeHtml(t){return String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function statusHTML(s){return `<span class="pill ${s==='completed'||s==='passed'?'':'dim'}">${escapeHtml(s)}</span>`;}
async function overview(){try{const d=await request('/api/stats');$('stat-languages').textContent=d.syntax_families;$('stat-emitters').textContent=d.emitters;$('stat-tools').textContent=d.native_available.length;$('stat-jobs').textContent=d.jobs;$('model-summary').textContent=d.model.connected?`Ollama online · ${d.model.models.length} installed model(s)`:'Ollama not connected. Start a local model to enable AI generation.';$('connection-text').textContent='Runtime healthy';$('connection-dot').style.background='#70ebb0';const j=await request('/api/jobs');renderEvents('recent-jobs',j.items.slice(0,5));}catch(e){$('connection-text').textContent='Runtime unreachable';$('connection-dot').style.background='#e07b76';}}
function renderEvents(id,rows){$(id).innerHTML=rows.length?rows.map(r=>`<div class="event"><div><strong>${escapeHtml(r.kind||r.status)}</strong> <small>${escapeHtml((r.id||r.task_id||'').slice(0,18))}</small><div>${escapeHtml((r.message||r.status||'').slice(0,230))}</div></div><div>${r.status?statusHTML(r.status):''}</div></div>`).join(''):'<div class="event">No events recorded yet.</div>';}
async function renderJobs(){try{const a=await Promise.all([request('/api/jobs'),request('/api/events')]);renderEvents('job-list',a[0].items);renderEvents('event-list',a[1].items);}catch(e){$('job-list').textContent=e.message;}}
async function renderSystem(){try{$('system-json').textContent=JSON.stringify(await request('/api/system'),null,2);}catch(e){$('system-json').textContent=e.message;}}
async function renderLang(reset){if(reset){langOffset=0;$('lang-table').innerHTML='';}const query=encodeURIComponent($('search-lang').value);try{const d=await request(`/api/languages?offset=${langOffset}&limit=90&q=${query}`);langCount=d.total;$('lang-count').textContent=`${d.total} matching entries`;$('lang-table').insertAdjacentHTML('beforeend',d.items.map(l=>`<tr><td><strong>${escapeHtml(l.name)}</strong></td><td>${escapeHtml(l.id)}</td><td>${l.emitter?`<span class="pill">Emitter: ${escapeHtml(l.emitter)}</span>`:'<span class="pill dim">Syntax recognition</span>'}</td></tr>`).join(''));langOffset+=d.items.length;$('lang-more').disabled=langOffset>=langCount;$('lang-more').textContent=langOffset>=langCount?'All results loaded':'Load next 90 →';}catch(e){$('lang-count').textContent=e.message;}}
$('search-lang').addEventListener('input',()=>renderLang(true));$('lang-more').addEventListener('click',()=>renderLang(false));
function out(s,title){$('output').textContent=typeof s==='string'?s:JSON.stringify(s,null,2);$('result-kind').textContent=title;}
async function job(kind,data,callback){try{const r=await request('/api/'+kind,data);pending.add(r.task_id);out(`Queued ${kind} task ${r.task_id}\nWatching actual execution…`,'Running');let count=0;const timer=setInterval(async()=>{count++;try{const t=await request('/api/job?id='+r.task_id);if(t.status==='completed'||t.status==='failed'||t.status==='interrupted'){clearInterval(timer);pending.delete(r.task_id);if(callback)callback(t);else out(t.result,t.status);overview();}else if(count>300){clearInterval(timer);pending.delete(r.task_id);out('Polling stopped after 5 minutes; task state is still recorded in SQLite.','Polling limit');}}catch(e){clearInterval(timer);pending.delete(r.task_id);out(e.message,'Connection issue');}},1000);}catch(e){out(e.message,'Error');}}
$('run-btn').onclick=()=>job('run',{source:$('editor').value},t=>out(t.result,t.status));
$('compile-btn').onclick=()=>job('compile',{source:$('editor').value,target:$('target').value},t=>out(t.result?.code||t.result,t.status));
$('verify-btn').onclick=()=>job('verify',{source:$('editor').value,target:$('target').value},t=>out(t.result,t.status));
$('ir-btn').onclick=async()=>{try{out(await request('/api/ir',{source:$('editor').value}),'Semantic IR');}catch(e){out(e.message,'IR error');}};
$('all-btn').onclick=()=>job('ai-transpile',{source:$('editor').value,target:$('all-target').value.trim(),project:$('project').value},t=>out(t.result,t.status));
$('save-btn').onclick=async()=>{try{const r=await request('/api/save',{project:$('project').value,path:'main.usl',content:$('editor').value});out(`Saved ${r.project}/${r.path}\n${r.bytes} bytes`,'Saved');}catch(e){out(e.message,'Error');}};
$('load-btn').onclick=async()=>{try{const r=await request('/api/read?project='+encodeURIComponent($('project').value)+'&path=main.usl');$('editor').value=r.content;out('Restored saved project code.','Loaded');}catch(e){out(e.message,'Error');}};
$('pack-btn').onclick=async()=>{try{await request('/api/save',{project:$('project').value,path:'main.usl',content:$('editor').value});const r=await request('/api/pack',{project:$('project').value});out(`SHA-256 verified project package\nFiles: ${r.files}\nBytes: ${r.bytes}\nExport ready.`,'Packaged');const a=document.createElement('a');a.href=r.url;a.download='';a.click();}catch(e){out(e.message,'Error');}};
async function renderModel(){try{const m=await request('/api/models');$('model-heading').textContent=m.connected?'Ollama connected':'No local AI model connection';$('model-detail').textContent=m.connected?`${m.models.length} available model(s) · ${m.endpoint}`:`${m.endpoint} · ${m.reason||'Offline'}`;$('model-selector').innerHTML='<option value="">Auto-select first available model</option>'+m.models.map(s=>`<option>${escapeHtml(s)}</option>`).join('');}catch(e){$('model-detail').textContent=e.message;}}
$('build-btn').onclick=async()=>{const goal=$('goal').value.trim();if(!goal){$('agent-output').textContent='Provide a concrete program request.';return;}const targets=$('build-targets').value.split(',').map(x=>x.trim()).filter(Boolean);$('agent-output').textContent='Starting local AI development cycle…';try{const r=await request('/api/build',{goal,project:$('project').value,targets,model:$('model-selector').value});let n=0;const timer=setInterval(async()=>{n++;try{const task=await request('/api/job?id='+r.task_id);$('agent-output').textContent=`Task ${r.task_id}\nState: ${task.status}\n${task.result?JSON.stringify(task.result,null,2):'Local model is generating and validating…'}`;if(['completed','failed','interrupted'].includes(task.status)||n>300){clearInterval(timer);overview();}}catch(e){clearInterval(timer);$('agent-output').textContent=e.message;}},1000);}catch(e){$('agent-output').textContent=e.message;}};
$('swarm-btn').onclick=async()=>{
 const goal=$('goal').value.trim();if(!goal){$('agent-output').textContent='Provide a specific goal first.';return;}
 const targets=$('build-targets').value.split(',').map(x=>x.trim()).filter(Boolean);
 $('agent-output').textContent='Running architect → implementer → native QA → reviewer through local Ollama…';
 try{const r=await request('/api/swarm',{goal,project:$('project').value,targets,model:$('model-selector').value});
 const timer=setInterval(async()=>{try{const t=await request('/api/job?id='+r.task_id);
 $('agent-output').textContent=`Multi-role task ${r.task_id} | ${t.status}\n${t.result?JSON.stringify(t.result,null,2):'Check Operations for persistent execution events.'}`;
 if(['completed','failed','interrupted'].includes(t.status))clearInterval(timer);
 }catch(e){clearInterval(timer);$('agent-output').textContent=e.message;}},1000);
 }catch(e){$('agent-output').textContent=e.message;}
};
let selectedProcess='';
async function renderIntegrations(){
 try{$('integrations-json').textContent=JSON.stringify(await request('/api/integrations'),null,2);}catch(e){$('integrations-json').textContent=e.message;}
 try{$('recovered-json').textContent=JSON.stringify(await request('/api/recovered'),null,2);}catch(e){$('recovered-json').textContent=e.message;}
 await renderRecoveredBridge();
}
async function renderRecoveredBridge(){
 try{$('recovered-bridge-json').textContent=JSON.stringify(await request('/api/recovered/bridge'),null,2);}catch(e){$('recovered-bridge-json').textContent=e.message;}
}
$('recovered-refresh').onclick=renderIntegrations;
$('recovered-bridge-refresh').onclick=renderRecoveredBridge;
$('integrations-refresh').onclick=renderIntegrations;
async function renderBridge(){try{const d=await request('/api/processes');$('bridge-processes').innerHTML=d.items.length?d.items.map(p=>`<div class="event" data-process="${escapeHtml(p.id)}"><div><strong>${escapeHtml(p.project)}</strong> <small>${escapeHtml(p.id)}</small><div>${escapeHtml(p.argv.join(' ').slice(0,140))}</div></div>${statusHTML(p.status)}</div>`).join(''):'No processes started by USL yet.';
 document.querySelectorAll('[data-process]').forEach(el=>el.addEventListener('click',()=>showBridge(el.dataset.process)));
 if(selectedProcess)await showBridge(selectedProcess);
 }catch(e){$('bridge-processes').textContent=e.message;}}
async function showBridge(id){selectedProcess=id;try{const d=await request('/api/process?id='+encodeURIComponent(id));
 $('bridge-title').textContent=`${d.project} · ${d.status} · exit ${d.exit_code??'pending'}`;
 $('bridge-log').textContent=(d.truncated?'[output truncated to last 64 KiB]\n':'')+(d.output||'[no console output yet]');
 }catch(e){$('bridge-log').textContent=e.message;}}
$('bridge-refresh').onclick=renderBridge;
let shadowSession='';
async function shadowRequest(path,obj,method='POST'){
 const token=$('shadow-owner-token').value.trim();if(!token)throw Error('Enter the private USL control token.');
 const response=await fetch(path,{method,headers:{'X-USL-Control-Token':token,...(method==='POST'?{'Content-Type':'application/json'}:{})},...(method==='POST'?{body:JSON.stringify(obj)}:{})});
 const value=await response.json();if(!response.ok)throw Error(value.error||'HTTP '+response.status);return value;
}
$('shadow-cancel').onclick=async()=>{try{if(!shadowSession)throw Error('No active session');const r=await shadowRequest('/api/shadow/cancel',{id:shadowSession});$('shadow-session-status').textContent=r.cancellation_requested?'Generation interruption requested; waiting for bounded provider cancellation.':'No active inference in this session.';}catch(e){$('shadow-session-status').textContent=e.message;}};
$('shadow-new-session').onclick=async()=>{try{const r=await shadowRequest('/api/shadow/create',{model:$('model-selector').value||null});shadowSession=r.id;localStorage.setItem('usl_shadow_session',r.id);$('chat-log').textContent='';$('shadow-session-status').textContent='Active session: '+r.id;}catch(e){$('shadow-session-status').textContent=e.message;}};
async function shadowResume(){const id=localStorage.getItem('usl_shadow_session');if(!id)return;
 try{const r=await shadowRequest('/api/shadow/history?id='+encodeURIComponent(id),null,'GET');shadowSession=id;$('chat-log').textContent=r.turns.filter(x=>x.status==='completed').map(x=>(x.role==='user'?'YOU: ':'SHADOW: ')+x.content).join('\n')+'\n';$('shadow-session-status').textContent='Restored session: '+id;}
 catch(e){$('shadow-session-status').textContent='Previous session cannot be restored: '+e.message;}
}
$('shadow-owner-token').addEventListener('change',shadowResume);
$('chat-send').onclick=async()=>{
 const t=$('chat-input').value.trim();if(!t)return;
 try{if(!shadowSession){const r=await shadowRequest('/api/shadow/create',{model:$('model-selector').value||null});shadowSession=r.id;localStorage.setItem('usl_shadow_session',r.id);}
 $('chat-input').value='';$('chat-send').disabled=true;$('chat-log').textContent+=`YOU: ${t}\nSHADOW: Contacting local model…\n`;
 const r=await shadowRequest('/api/shadow/send',{id:shadowSession,prompt:t});
 $('chat-log').textContent=$('chat-log').textContent.replace('SHADOW: Contacting local model…',`SHADOW: ${r.reply}`);
 $('shadow-session-status').textContent='Durable local Shadow session '+shadowSession+' | '+r.model;
 }catch(e){$('chat-log').textContent=$('chat-log').textContent.replace('SHADOW: Contacting local model…',`SHADOW ERROR: ${e.message}`);}finally{$('chat-send').disabled=false;}
};
$('chat-input').addEventListener('keydown',e=>{if(e.key==='Enter')$('chat-send').click()});
$('refresh').onclick=()=>{overview();if(active==='jobs')renderJobs();if(active==='shadow')renderModel();};
$('editor').addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();const i=e.target.selectionStart,j=e.target.selectionEnd;e.target.value=e.target.value.slice(0,i)+'    '+e.target.value.slice(j);e.target.selectionStart=e.target.selectionEnd=i+4;}});
setInterval(()=>{if(active==='home'||active==='jobs')overview();if(active==='jobs')renderJobs();if(active==='bridge')renderBridge();},10000);overview();

// USL 0.5 numerical / equation laboratory
let equationRecords=[];
async function renderResearch(){
 try{
  const q=encodeURIComponent($('equation-search').value.trim());
  const res=await request('/api/equations?q='+q);
  equationRecords=res.items;
  $('equation-id').innerHTML=res.items.map(x=>`<option value="${escapeHtml(x.id)}">${escapeHtml(x.id)} — ${escapeHtml(x.title)}</option>`).join('');
  describeEquation();
 }catch(e){$('equation-output').textContent=e.message;}
}
function describeEquation(){
 const eq=equationRecords.find(x=>x.id===$('equation-id').value);if(!eq)return;
 $('equation-details').textContent=`${eq.formula}\nStatus: ${eq.status} | Domain: ${eq.domain}\nUse cases: ${eq.use_cases.join('; ')}\nSource: ${eq.source}\n${eq.notes||''}`;
 $('equation-params').value=JSON.stringify(eq.defaults,null,2);
 $('eq-evaluate').disabled=!eq.executable;
 $('equation-output').textContent=eq.executable?'Ready for numerical evaluation.':'Symbolic/research equation; no validated scalar evaluator.';
}
$('equation-id').addEventListener('change',describeEquation);
$('eq-refresh').onclick=renderResearch;
$('equation-search').addEventListener('keydown',e=>{if(e.key==='Enter')renderResearch()});
$('eq-evaluate').onclick=async()=>{try{
 const r=await request('/api/equation/evaluate',{id:$('equation-id').value,params:JSON.parse($('equation-params').value)});
 $('equation-output').textContent=JSON.stringify(r,null,2);
 }catch(e){$('equation-output').textContent=e.message;}};
$('collapse-run').onclick=async()=>{try{
 const r=await request('/api/collapse',{text:$('collapse-text').value,reference:$('collapse-reference').value||null,mode:'all'});
 $('collapse-output').textContent=JSON.stringify(r,null,2);
 }catch(e){$('collapse-output').textContent=e.message;}};
$('worker-run').onclick=async()=>{try{
 const count=Number($('worker-count').value),repeat=Number($('worker-repeat').value);
 if(!Number.isInteger(count)||count<1||count>50000||!Number.isInteger(repeat)||repeat<1||repeat>50000)throw Error('Invalid size');
 const r=await request('/api/worker/run',{values:Array.from({length:count},(_,i)=>i%repeat),operator:'sum_squares',dimensions:['execution','cache','verification','composition'],config:{workers:Number($('worker-threads').value),depth:7,leaf_size:256}});
 $('worker-output').textContent=JSON.stringify(r,null,2);
 }catch(e){$('worker-output').textContent=e.message;}};

$('worker-auto').onclick=async()=>{try{
 const count=Number($('worker-count').value),repeat=Number($('worker-repeat').value);
 if(!Number.isInteger(count)||count<1||count>50000||!Number.isInteger(repeat)||repeat<1||repeat>50000)throw Error('Invalid size');
 const r=await request('/api/adaptive/select',{values:Array.from({length:count},(_,i)=>i%repeat),operator:'sum_squares',workers:Number($('worker-threads').value),repeats:3});
 $('worker-output').textContent=JSON.stringify(r,null,2);
 }catch(e){$('worker-output').textContent=e.message;}};

// v0.6 owner-approved persistent automation controller
async function autoRequest(action,data){
 const token=$('auto-token').value.trim();if(!token)throw Error('Paste the private control token from your USL data folder.');
 const res=await fetch('/api/autonomy/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-USL-Control-Token':token},body:JSON.stringify(data)});
 const obj=await res.json();if(!res.ok)throw Error(obj.error||'HTTP '+res.status);return obj;
}
async function renderAutonomy(){
 try {const r=await request('/api/autonomy/runs');$('auto-history').innerHTML=r.items.length?r.items.map(x=>`<div class="event"><div><strong>${escapeHtml(x.id)}</strong> <small>step ${x.cursor}</small></div>${statusHTML(x.status)}</div>`).join(''):'No plans recorded.';
 const id=$('auto-run-id').value.trim();if(id){const rec=await request('/api/autonomy/run?id='+encodeURIComponent(id));$('auto-status').textContent=JSON.stringify(rec,null,2);}
 }catch(e){$('auto-status').textContent=e.message;}
}
async function autoAction(kind){try{
 const id=$('auto-run-id').value.trim();let obj;
 if(kind==='create'){obj=await autoRequest('create',{plan:JSON.parse($('auto-plan').value)});$('auto-run-id').value=obj.id;$('auto-plan').value=JSON.stringify(obj.plan,null,2);}
 else if(kind==='approve'){if(!id)throw Error('Create a draft first');const plan=JSON.parse($('auto-plan').value);const stored=(await request('/api/autonomy/run?id='+encodeURIComponent(id))).plan;if(JSON.stringify(plan)!==JSON.stringify(stored))throw Error('Plan changed after the draft was created. Create a new draft before approval.');const external=stored.steps?.some(s=>['process','bridge_cycle','dev_repair'].includes(s.kind));if(external&&!confirm('Authorize this exact plan to start external programs or browser cycles? Review every action first.'))return;obj=await autoRequest('approve',{id,allow_process:!!external});}
 else {if(!id)throw Error('Select a run first');obj=await autoRequest(kind,{id});}
 $('auto-status').textContent=JSON.stringify(obj,null,2);renderAutonomy();
 }catch(e){$('auto-status').textContent='Error: '+e.message;}
}
$('auto-create').onclick=()=>autoAction('create');
$('auto-approve').onclick=()=>autoAction('approve');
$('auto-start').onclick=()=>autoAction('start');
$('auto-cancel').onclick=()=>autoAction('cancel');
$('auto-refresh').onclick=renderAutonomy;
setInterval(()=>{if(active==='autonomy')renderAutonomy();},2000);

$('auto-propose').onclick=async()=>{
 try{
  const goal=$('auto-goal').value.trim();if(!goal)throw Error('Enter a goal first.');
  $('auto-status').textContent='Requesting a constrained plan from local Ollama… No execution will occur.';
  const draft=await autoRequest('propose',{goal,model:$('model-selector').value});
  $('auto-run-id').value=draft.id;$('auto-plan').value=JSON.stringify(draft.plan,null,2);
  $('auto-status').textContent='Proposed draft for review. Not approved or running.\n'+JSON.stringify(draft,null,2);
  renderAutonomy();
 }catch(e){$('auto-status').textContent='Proposal error: '+e.message;}
};

// v0.7 strict parse qualification for data/config language families.
$('syntax-validate-btn').onclick=async()=>{
 try {const result=await request('/api/syntax/validate',{language:$('syntax-parser').value,source:$('syntax-source').value});
 $('syntax-result').textContent=JSON.stringify(result,null,2);
 } catch(e){$('syntax-result').textContent=e.message;}
};

// v1.3: real native parsing via explicitly authorized external compiler/toolchain.
$('native-syntax-btn').onclick=async()=>{
 const token=$('native-syntax-token').value.trim();
 if(!token){$('native-syntax-result').textContent='Private control token required.';return;}
 if(!confirm('Run the installed native parser on this TRUSTED source? This invokes an external toolchain, not a sandbox.'))return;
 try{
  const response=await fetch('/api/syntax/native-check',{method:'POST',
   headers:{'Content-Type':'application/json','X-USL-Control-Token':token},
   body:JSON.stringify({language:$('native-syntax-language').value,source:$('native-syntax-source').value,approve_native:true})});
  const data=await response.json();if(!response.ok)throw Error(data.error||'HTTP '+response.status);
  $('native-syntax-result').textContent=JSON.stringify(data,null,2);
 }catch(error){$('native-syntax-result').textContent='Native syntax check failed: '+error.message;}
};

// v1.0 — compiler-grounded, draft-only repair proposal. No automatic approval.
$('repair-propose').onclick=async()=>{
 const token=$('auto-token').value.trim();
 if(!token){$('repair-evidence').textContent='Enter the private USL control token first.';return;}
 try {
  const data=await fetch('/api/repair/propose',{method:'POST',headers:{'Content-Type':'application/json','X-USL-Control-Token':token},
   body:JSON.stringify({project:$('repair-project').value.trim(),path:$('repair-path').value.trim()})});
  const result=await data.json();if(!data.ok)throw Error(result.error||'Diagnostic failed');
  $('repair-evidence').textContent=JSON.stringify({diagnostic:result.diagnostic,source_sha256:result.source_sha256,source_modified:false},null,2);
  $('auto-plan').value=JSON.stringify(result.plan,null,2);
  $('auto-run-id').value=result.draft_id;
  $('auto-status').textContent='Compiler-grounded repair DRAFT created. Inspect exact old/new text and approve explicitly before execution.';
  renderAutonomy();
 }catch(e){$('repair-evidence').textContent='Cannot propose: '+e.message;}
};

// v4.2: native source execution remains explicitly owned and approved.
let sourceContracts={};
async function renderSourceLab(){
 try{
  const result=await request('/api/source-engines');sourceContracts=result.contracts;
  const select=$('source-engine');const selected=select.value||'graphql';select.replaceChildren();
  for(const [id,contract] of Object.entries(sourceContracts)){
   const option=document.createElement('option');option.value=id;option.textContent=id+(contract.provider_available?'':' (provider unavailable)');select.appendChild(option);
  }
  select.value=selected;
 }catch(e){$('source-result').textContent=e.message;}
}
$('source-example').onclick=()=>{
 const example=sourceContracts[$('source-engine').value]?.example;if(!example)return;
 $('source-text').value=example.source;$('source-context').value=JSON.stringify(example.context,null,2);
};
$('source-run').onclick=async()=>{
 const button=$('source-run');button.disabled=true;
 try{
  const token=$('source-token').value.trim();if(!token)throw Error('Local control token required.');
  if(!$('source-approve').checked)throw Error('Allow this source to execute before running.');
  const response=await fetch('/api/source/run',{method:'POST',headers:{'Content-Type':'application/json','X-USL-Control-Token':token},body:JSON.stringify({catalog_id:$('source-engine').value,source:$('source-text').value,context:JSON.parse($('source-context').value),approve_execution:true})});
  const result=await response.json();if(!response.ok)throw Error(result.error||`HTTP ${response.status}`);
  $('source-result').textContent=JSON.stringify({value:result.value,source_sha256:result.source_ir.source_sha256,runtime:result.runtime,full_spec_qualified:result.full_spec_qualified},null,2);
 }catch(e){$('source-result').textContent=e.message;}finally{button.disabled=false;}
};
