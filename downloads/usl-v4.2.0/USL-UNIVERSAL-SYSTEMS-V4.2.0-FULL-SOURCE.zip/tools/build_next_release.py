"""Release gate for exact source tree, preserving six recovered archives."""
from __future__ import annotations
import hashlib,json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/'VERSION').read_text().strip()
NAME=f'USL-UNIVERSAL-SYSTEMS-V{VERSION}-FULL-SOURCE.zip'

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def build():
    isolate=json.loads((ROOT/f'test_results/v{VERSION}_isolated_regressions.json').read_text())
    if not isolate.get('passed') or len(isolate.get('files',[]))!=len(list((ROOT/'tests').glob('test_*.py'))):
        raise RuntimeError('Isolated complete-module test evidence missing')
    for result in isolate['files']:
        recorded=(ROOT/'test_results'/('run_'+Path(result['file']).stem+'.log')).read_text(errors='replace')
        match=re.search(r'Ran (\d+) tests? in [\d.]+s\s+OK(?:\s+\(skipped=(\d+)\))?\s*$',recorded)
        if not match or int(match.group(1))!=result['tests'] or int(match.group(2) or 0)!=result.get('skipped',0) or not result['passed'] or result['exit_code']!=0:
            raise RuntimeError('Test evidence invalid: '+result['file'])
    total=sum(x['tests'] for x in isolate['files'])
    if total<201:raise RuntimeError('Test count regressed from latest 201 cases')
    quali=json.loads((ROOT/f'test_results/v{VERSION}_native_qualification.json').read_text())
    passed=sum(v.get('passed',0) for v in quali['qualification'].values())
    if passed<40:raise RuntimeError('Native qualification regressed below 40/40')
    if VERSION=='4.2.0':
        from usl_systems.source_engines import CONTRACTS
        sources=json.loads((ROOT/'test_results/v4.2.0_source_qualification.json').read_text())
        graph=json.loads((ROOT/'test_results/v4.2.0_application.json').read_text())
        ledger=json.loads((ROOT/'test_results/v4.2.0_606_coverage.json').read_text())
        matrix=json.loads((ROOT/'test_results/v4.2.0_typed_matrix.json').read_text())
        if (not sources['all_passed'] or sources['passed_cases']!=72 or sources['new_catalog_entries']!=18
            or not graph['graph']['all_verified'] or graph['stdout']!='18\n374\n96\n'
            or ledger['total_subset_evidence']!=71 or ledger['unqualified_entries']!=535
            or ledger['full_specifications_qualified']!=0 or matrix['typed_artifact_handoffs']!=324):
            raise RuntimeError('v4.2 source/application/coverage evidence gate failed')
        snapshots=sorted(p for folder in ('usl_systems','tools','tests','ui') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.js','.html','.css'))
        hashes={p.relative_to(ROOT).as_posix():digest(p) for p in snapshots}
        current=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
        if current!=isolate.get('source_snapshot_sha256') or not isolate.get('source_unchanged_during_run'):
            raise RuntimeError('Regression source evidence is stale')
    if not (ROOT/'NEXT_ITERATION_PROMPT.md').is_file():raise RuntimeError('Missing next-iteration prompt')
    if not (ROOT/'docs/ITERATION_BACKLOG.json').is_file():raise RuntimeError('Missing machine-readable backlog')
    files=sorted([p for p in ROOT.rglob('*') if p.is_file() and p.name!='RELEASE_MANIFEST.json'
              and not any(x in p.parts for x in ('__pycache__','.pytest_cache','.git'))
              and p.suffix not in ('.pyc','.pyo')],key=lambda p:p.relative_to(ROOT).as_posix())
    manifest={'schema':'usl.verified.release.v5','version':VERSION,
       'files':{p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in files},
       'actual_testing':{'linux_isolated_unittest_cases_enumerated':total,
           'linux_isolated_unittest_cases_passed':isolate.get('tests_executed',total),
           'skipped_tests':isolate.get('skipped',0),'fully_exercised':isolate.get('fully_exercised',True),
           'native_subset_cases_passed':passed,
           'windows_installer_qualified':False,'real_local_ollama_qualified':False,
           'full_606_semantic_compilers':False,'live_browser_qualified':False,
           'gpu_acceleration_qualified':False,'real_camera_meta_qualified':False},
       'next_prompt':'NEXT_ITERATION_PROMPT.md','backlog':'docs/ITERATION_BACKLOG.json'}
    recovered=[p for p in files if p.parent.name=='legacy_sources' and p.suffix=='.zip']
    if len(recovered)!=6:raise RuntimeError('Six recovered archives must be retained')
    manifest['recovered_archive_sha256']={p.relative_to(ROOT).as_posix():digest(p) for p in recovered}
    if VERSION=='4.2.0':manifest['v4.2_evidence']={'new_source_entries':18,'positive_negative_boundary_cases':72,'typed_artifact_handoffs':324,'historical_plus_new_subsets':71,'fully_qualified_specifications':0}
    (ROOT/'RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    target=ROOT.parent/NAME
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for f in [*files,ROOT/'RELEASE_MANIFEST.json']:
            z.write(f,f.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        m=json.loads(z.read('RELEASE_MANIFEST.json'))
        for name,record in m['files'].items():
            assert hashlib.sha256(z.read(name)).hexdigest()==record['sha256'],name
    print(json.dumps({'output':str(target),'sha256':digest(target),'files':len(files)+1,
       'unittests':total,'native_cases':passed,'bytes':target.stat().st_size},indent=2))

if __name__=='__main__':build()
