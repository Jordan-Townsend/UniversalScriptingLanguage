"""USL cooperative partial workers v1.

Finite DAG of allowlisted operations, content-hashed inputs/results, cooperative
result binding, bounded OS process workers for numeric compute and threads for
I/O/compiler operations. Not independent AI agents or extra hardware.
"""
from __future__ import annotations
import hashlib, json, os, tempfile, time, multiprocessing
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path

from .module_linker import link_project
from .module_contracts import validate_contracts
from .semantic_types import check_types
from .fractal import FactoredFractal
from .language import Interpreter
from .collapse import collapse_bytes, restore_bytes

KINDS = frozenset(('link', 'contracts', 'static_types', 'interpreter', 'fractal', 'compress', 'join_evidence', 'bounded_delay', 'native_verify', 'semantic_route', 'semantic_native_collapse', 'matrix_pair_probe', 'domain_qualify', 'domain_expand', 'source_execute', 'source_program'))
PURE_KINDS = KINDS - {'native_verify', 'semantic_native_collapse', 'domain_qualify', 'domain_expand', 'source_execute', 'source_program'}
ENGINE_VERSION='usl.cooperative.engine.v4.2'
class CooperativeError(ValueError): pass

def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def _sha(value):
    return hashlib.sha256(_canonical(value).encode('utf-8')).hexdigest()

def _op(kind, inputs):
    """All functions are top-level and safe to dispatch with Windows spawn."""
    if kind == 'source_execute':
        from .source_engines import execute
        result=execute(inputs['language'],inputs['source'],inputs.get('context',{}),approved=True)
        return {k:v for k,v in result.items() if k!='elapsed_ms'}
    if kind == 'source_program':
        from .source_engines import SourceSession
        imports=dict(inputs.get('imports',{}))
        imports.update({k:v for k,v in inputs.items() if k not in ('source','imports')})
        return SourceSession(approved=True,imports=imports).interpret(inputs['source'])
    if kind == 'link':
        r = link_project(inputs['project'])
        return {'linked_source': r['source'], 'source_sha256': r['output_sha256'], 'modules': r['modules']}
    if kind == 'contracts':
        r = validate_contracts(inputs['project'])
        if not r['valid']: raise CooperativeError('Contract violations: '+_canonical(r['errors'])[:600])
        return {'valid': True, 'contracts_sha256':r['contracts_sha256'], 'verified_checks':r['locally_verified_checks'], 'unproven_checks':len(r['unproven_checks'])}
    if kind == 'static_types':
        r = check_types(inputs['source'])
        if r['error_count']: raise CooperativeError('Static errors: '+_canonical(r['issues'])[:600])
        return {'valid': True, 'source_sha256':r['source_sha256'], 'nodes_examined':r['nodes_examined']}
    if kind == 'interpreter':
        r = Interpreter(timeout=4, max_ops=100_000).run(inputs['source'])
        return {'stdout':r.output, 'operations':r.operations, 'source_sha256':hashlib.sha256(inputs['source'].encode()).hexdigest()}
    if kind == 'fractal':
        workers = int(inputs.get('workers',2))
        r = FactoredFractal(workers=workers,max_depth=4,leaf_size=int(inputs.get('leaf_size',32))).execute(
            inputs['values'],operator=inputs.get('operator','sum_squares'),
            dimensions=inputs.get('dimensions',['compiler','research']),mode='sync',reuse=True,verify=True)
        if not r['verified_exact']:raise CooperativeError('Numeric reference mismatch')
        return {k:r[k] for k in ('result','reference','verified_exact','N_logical_partials','reused_identical_partials')}
    if kind == 'compress':
        raw = inputs['text'] if isinstance(inputs['text'],str) else _canonical(inputs['text'])
        data=raw.encode('utf-8')
        if len(data)>100_000:raise CooperativeError('Compression input too large')
        record=collapse_bytes(data)
        if restore_bytes(record)!=data: raise CooperativeError('Compression round-trip failed')
        return {'verified_exact':True, 'sha256':record['sha256'],'raw_bytes':len(data),'codec':record['codec'],'encoded_bytes':record['encoded_bytes']}
    if kind == 'join_evidence':
        items = inputs.get('evidence')
        if not isinstance(items,dict) or not items:raise CooperativeError('Nonempty evidence object required')
        return {'verified':True,'dependencies':sorted(items), 'evidence_sha256':_sha(items)}
    if kind == 'bounded_delay':
        delay=inputs.get('seconds',0)
        if type(delay) not in (int,float) or not 0<=delay<=0.25:raise CooperativeError('Delay out of bounds')
        started=time.monotonic_ns();time.sleep(delay);ended=time.monotonic_ns()
        return {'verified':True,'started_ns':started,'ended_ns':ended,'observed_seconds':(ended-started)/1e9}
    if kind == 'domain_expand':
        from .expanded_domains import execute
        result=execute(inputs['language'],approved=True,artifacts=inputs.get('artifacts'))
        if not result['verified']:raise CooperativeError('Expanded native domain not verified')
        # Recorded elapsed time is telemetry, not semantic result identity.
        return {k:v for k,v in result.items() if k!='elapsed_ms'}
    if kind == 'domain_qualify':
        from .domain_execution import run
        result=run(inputs['language'],approved=True,artifacts=inputs.get('artifacts'))
        if not result['verified']:raise CooperativeError('Language scope not qualified')
        # Timing is telemetry, not a semantic result; preserve deterministic dependency hashes.
        return {k:v for k,v in result.items() if k != 'elapsed_ms'}
    if kind == 'matrix_pair_probe':
        from .executable_matrix import execute_pair
        result=execute_pair(inputs['host'],inputs['guest'],authorized=True)
        if not result.get('verified'):
            raise CooperativeError('Native bridge pair not verified: '+str(result.get('status')))
        return {'verified':True,'host':result['host'],'guest':result['guest'],
                'observed_values':result['actual_values'],
                'source_sha256':result['source_sha256'],
                'modes':result['native_modes'],'project_sha256':result['project_sha256']}
    if kind == 'semantic_route':
        from .universal import route
        outcome = route(inputs['source'], inputs['target'])
        return {'mode':outcome['mode'], 'catalog_id':outcome['catalog_id'],
                'ir_sha256':outcome['ir_sha256'], 'reference_stdout_sha256':outcome['reference_stdout_sha256'],
                'reference_output':outcome['reference_output'], 'native_verified':False}
    if kind == 'semantic_native_collapse':
        from .universal import collapse_success_all
        targets=tuple(inputs.get('targets',('python','javascript','ruby','php')))
        outcome=collapse_success_all(inputs['source'],targets=targets)
        if not outcome['native_verified_for_this_program']:
            raise CooperativeError('Native candidate equivalence not established')
        return {'mode':outcome['mode'], 'chosen_backend':outcome['chosen_backend'],
                'reference_stdout_sha256':outcome['reference_stdout_sha256'],
                'attempts':outcome['attempts'], 'native_verified':True}
    if kind == 'native_verify':
        from .native import verify
        r=verify(inputs['source'],inputs['target'])
        if r.get('status')!='passed':raise CooperativeError('Native check failed: '+str(r.get('status'))+' '+str(r.get('error',''))[:300])
        return {'verified':True,'target':inputs['target'],'status':'passed','observed':r.get('actual')}
    raise CooperativeError('Unsupported operation '+str(kind))

def _run_task(kind,inputs):
    started_ns=time.monotonic_ns()
    value=_op(kind,inputs)
    finished_ns=time.monotonic_ns()
    return {'value':value,'result_sha256':_sha(value),'started_ns':started_ns,'finished_ns':finished_ns,
            'elapsed_ms':round((finished_ns-started_ns)/1e6,4)}

class CooperativeScheduler:
    def __init__(self,threads=4,processes=2,allow_native=False,max_in_flight=None):
        if type(threads)!=int or not 1<=threads<=8:raise CooperativeError('threads 1..8')
        if type(processes)!=int or not 0<=processes<=4:raise CooperativeError('processes 0..4')
        if max_in_flight is None:max_in_flight=threads+processes
        if type(max_in_flight)!=int or not 1<=max_in_flight<=16:raise CooperativeError('max_in_flight 1..16')
        self.threads=threads;self.processes=processes;self.allow_native=allow_native;self.max_in_flight=max_in_flight

    @staticmethod
    def _validate(graph):
        if not isinstance(graph,dict) or graph.get('schema')!='usl.cooperative.graph.v1':raise CooperativeError('Invalid schema')
        nodes=graph.get('tasks')
        if not isinstance(nodes,list) or not 1<=len(nodes)<=40:raise CooperativeError('1..40 tasks required')
        if len(_canonical(graph).encode())>350_000:raise CooperativeError('Graph too large')
        byid={}
        for n in nodes:
            if not isinstance(n,dict) or set(n)-{'id','kind','deps','inputs','bind','lane','priority'}:raise CooperativeError('Unexpected task keys')
            key=n.get('id');kind=n.get('kind');deps=n.get('deps',[]);bindings=n.get('bind',{})
            if not isinstance(key,str) or not key.isidentifier() or len(key)>50 or key in byid:raise CooperativeError('Invalid/duplicate task ID')
            if kind not in KINDS:raise CooperativeError('Not allowlisted operation')
            if type(n.get('priority',0)) is not int or not 0<=n.get('priority',0)<=100:
                raise CooperativeError('Task priority must be an integer 0..100')
            if not isinstance(deps,list) or len(set(deps))!=len(deps) or len(deps)>20:raise CooperativeError('Invalid dependencies')
            if not isinstance(n.get('inputs',{}),dict) or not isinstance(bindings,dict) or len(bindings)>20:raise CooperativeError('Invalid inputs/bindings')
            if n.get('lane','thread') not in ('thread','process'):raise CooperativeError('Invalid lane')
            if n.get('lane')=='process' and kind!='fractal':raise CooperativeError('Process lane currently supports pure numeric fractal tasks only')
            for dest,ref in bindings.items():
                if not isinstance(dest,str) or not dest.isidentifier() or not isinstance(ref,str) or len(ref)>120:raise CooperativeError('Invalid binding')
                origin=ref.split('.',1)[0]
                if origin not in deps:raise CooperativeError('Bindings must refer to declared dependencies')
            byid[key]=n
        for key,n in byid.items():
            if any(dep not in byid or dep==key for dep in n.get('deps',[])):raise CooperativeError('Missing/self dependency')
        visiting=set();done=set()
        def visit(x):
            if x in visiting:raise CooperativeError('Dependency cycle')
            if x in done:return
            visiting.add(x)
            for y in byid[x].get('deps',[]):visit(y)
            visiting.remove(x);done.add(x)
        for x in byid:visit(x)
        return byid

    def run(self,graph,checkpoint=None,cache=True,cancel_event=None):
        byid=self._validate(graph)
        graph_sha=_sha(graph)
        path=Path(checkpoint) if checkpoint else None
        prior={}
        if path is not None and path.exists() and cache:
            try:
                saved=json.loads(path.read_text('utf-8'))
                if saved.get('graph_sha256')==graph_sha and saved.get('schema')=='usl.cooperative.checkpoint.v1':
                    prior=saved.get('results',{})
            except (OSError,ValueError):prior={}
        results={};pending=set(byid);active={};failures={};reused=0;cancelled=False;max_active_observed=0
        time_start=time.perf_counter()
        def persist():
            if path is None:return
            path.parent.mkdir(parents=True,exist_ok=True)
            payload={'schema':'usl.cooperative.checkpoint.v1','graph_sha256':graph_sha,'results':results}
            with tempfile.NamedTemporaryFile('w',encoding='utf8',dir=path.parent,prefix='.usl-checkpoint-',delete=False) as temp:
                json.dump(payload,temp,indent=2);tmp=Path(temp.name)
            os.replace(tmp,path)
        # Only deterministic pure tasks are reused; never replay or cache external actions.
        with ThreadPoolExecutor(max_workers=self.threads,thread_name_prefix='usl-coop') as threads:
            process_pool=ProcessPoolExecutor(max_workers=self.processes,mp_context=multiprocessing.get_context('spawn')) if self.processes else None
            try:
                while pending or active:
                    if cancel_event is not None and cancel_event.is_set() and pending:
                        cancelled=True
                        for key in sorted(pending):
                            results[key]={'status':'cancelled','reason':'Cancelled before dispatch; already running tasks finish normally'}
                        pending.clear();persist()
                    submitted=False
                    for key in sorted(pending,key=lambda k:(-byid[k].get('priority',0),k)):
                        if len(active)>=self.max_in_flight:break
                        node=byid[key];deps=node.get('deps',[])
                        if any(d in pending or d in active.values() for d in deps):continue
                        if any(results[d]['status']!='verified' for d in deps):
                            results[key]={'status':'blocked','reason':'Dependency did not verify'}
                            pending.remove(key);submitted=True;persist();continue
                        inputs=dict(node.get('inputs',{}))
                        for dest,reference in node.get('bind',{}).items():
                            origin,*parts=reference.split('.')
                            current=results[origin]['value']
                            for component in parts:
                                if not isinstance(current,dict) or component not in current:raise CooperativeError('Missing verified binding: '+reference)
                                current=current[component]
                            inputs[dest]=current
                        if node['kind']=='join_evidence' and 'evidence' not in inputs:
                            inputs['evidence']={d:results[d]['result_sha256'] for d in deps}
                        spec_sha=_sha({'engine_version':ENGINE_VERSION,'kind':node['kind'],'inputs':inputs,'deps':[results[d]['result_sha256'] for d in deps]})
                        old=prior.get(key)
                        if cache and node['kind'] in PURE_KINDS-{'bounded_delay'} and isinstance(old,dict) and old.get('spec_sha256')==spec_sha and old.get('status')=='verified' and old.get('result_sha256')==_sha(old.get('value')):
                            results[key]={**old,'cache_reused':True};pending.remove(key);reused+=1;submitted=True;persist();continue
                        if node['kind'] in ('native_verify', 'semantic_native_collapse','matrix_pair_probe','domain_qualify','domain_expand','source_execute','source_program') and not self.allow_native:
                            results[key]={'status':'failed','reason':'Native execution requires explicit opt-in'}
                            pending.remove(key);submitted=True;persist();continue
                        lane=node.get('lane','thread')
                        if lane=='process' and process_pool is None:
                            results[key]={'status':'failed','reason':'Process workers disabled'}
                            pending.remove(key);submitted=True;persist();continue
                        executor=process_pool if lane=='process' else threads
                        future=executor.submit(_run_task,node['kind'],inputs)
                        active[future]=key
                        max_active_observed=max(max_active_observed,len(active))
                        pending.remove(key);submitted=True
                    if not active:
                        if pending and not submitted:raise CooperativeError('Unresolvable scheduler dependencies')
                        continue
                    done,_=wait(active,timeout=0.05,return_when=FIRST_COMPLETED)
                    if not done:continue  # Poll cancellation while active tasks are running.
                    for future in done:
                        key=active.pop(future);node=byid[key]
                        try:
                            data=future.result()
                            results[key]={'status':'verified','kind':node['kind'],'lane':node.get('lane','thread'),'cache_reused':False,
                                          'spec_sha256':_sha({'engine_version':ENGINE_VERSION,'kind':node['kind'],'inputs':self._rebuild_inputs(node,results),'deps':[results[d]['result_sha256'] for d in node.get('deps',[])]}),**data}
                        except Exception as exc:
                            results[key]={'status':'failed','reason':type(exc).__name__+': '+str(exc)[:800]}
                            failures[key]=results[key]['reason']
                        persist()
            finally:
                if process_pool is not None:process_pool.shutdown(wait=True,cancel_futures=True)
        return {'schema':'usl.cooperative.report.v1','graph_sha256':graph_sha,'all_verified':all(r['status']=='verified' for r in results.values()),
                'task_count':len(results),'verified_count':sum(r['status']=='verified' for r in results.values()),
                'blocked_or_failed':{k:r.get('reason') for k,r in results.items() if r['status']!='verified'},
                'reused_verified_partials':reused,'cancelled_pending_tasks':cancelled,'actual_process_workers_max':self.processes,'actual_thread_workers_max':self.threads,
                'admission_max_in_flight':self.max_in_flight,'max_active_observed':max_active_observed,
                'priority_rule':'higher bounded priority first for ready, unscheduled tasks',
                'elapsed_ms':round((time.perf_counter()-time_start)*1000,3),'tasks':results}

    @staticmethod
    def _rebuild_inputs(node,results):
        inputs=dict(node.get('inputs',{}))
        for dest,reference in node.get('bind',{}).items():
            origin,*parts=reference.split('.')
            current=results[origin]['value']
            for component in parts:current=current[component]
            inputs[dest]=current
        if node['kind']=='join_evidence' and 'evidence' not in inputs:
            inputs['evidence']={d:results[d]['result_sha256'] for d in node.get('deps',[])}
        return inputs
