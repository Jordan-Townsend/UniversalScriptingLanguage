"""Catalog-wide plugin contract with evidence-based semantic capability tiers.

Descriptors are inert data. Registering a descriptor never imports or executes
third-party code. Native execution remains through approved existing toolchains;
a catalog/grammar adapter is not a full compiler.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from hashlib import sha256
import json,re
from .catalog import load_catalog
from .compiler import TARGETS,target_name
from .native import tool_available,verify
from .native_syntax import CAPABILITIES,available
from .syntax_validation import VALIDATORS

CONTRACT_VERSION=1
SUPPORTED_STAGES=('recognition','parser_validation','native_static_check','restricted_emitter','restricted_native_execution','native_source_import','native_source_execution')

@dataclass(frozen=True)
class Plugin:
    id:str
    display_name:str
    stages:tuple[str,...]
    backend:str|None
    toolchain_available:bool
    guarantee:str
    reference:str
    source_contract:dict|None=None

class PluginError(ValueError):pass

class Registry:
    def __init__(self,rows=None):
        self._entries={};self._aliases={}
        from .source_engines import discover
        source_contracts=discover()
        for row in (rows if rows is not None else load_catalog()):
            name=row['id']
            backend=target_name(name)
            stages=['recognition']
            if name in VALIDATORS:stages.append('parser_validation')
            if name in CAPABILITIES:stages.append('native_static_check')
            if backend in TARGETS:stages.append('restricted_emitter')
            # A target is only marked as executable (never fully qualified)
            # if its actual native toolchain is present at discovery time.
            if backend in TARGETS and tool_available(backend):stages.append('restricted_native_execution')
            source_contract=source_contracts.get(name)
            if source_contract and source_contract['provider_available']:
                stages.extend(('native_source_import','native_source_execution'))
            p=Plugin(name,row['name'],tuple(stages),backend if backend in TARGETS else None,
                     bool((backend in TARGETS and tool_available(backend)) or (source_contract and source_contract['provider_available'])),
                     'Only features actually tested can be claimed; catalog recognition has no semantic guarantee.',
                     'catalog:'+name,source_contract)
            self.add(p,aliases=row.get('aliases',[]))
    def add(self,descriptor,aliases=()):
        if not isinstance(descriptor,Plugin):raise PluginError('Plugin must use immutable descriptor contract')
        if not re.fullmatch(r'[a-z0-9][a-z0-9_.+\-]{0,79}',descriptor.id):raise PluginError('Invalid plugin id')
        if any(s not in SUPPORTED_STAGES for s in descriptor.stages):raise PluginError('Unknown stage')
        if descriptor.id in self._entries:raise PluginError('Duplicate plugin id')
        if 'recognition' not in descriptor.stages:raise PluginError('Every entry needs explicit recognition stage')
        self._entries[descriptor.id]=descriptor
        for alias in (descriptor.id,*aliases):
            key=str(alias).lower()
            if key not in self._aliases:self._aliases[key]=descriptor.id
    def resolve(self,name):
        if not isinstance(name,str):raise PluginError('Invalid target name')
        key=name.lower()
        if key in self._entries:return self._entries[key]
        if key in self._aliases:return self._entries[self._aliases[key]]
        raise PluginError('Unknown catalog language: '+key)
    def report(self):
        entries=[asdict(p) for p in self._entries.values()]
        return {'schema':'usl.semantic.plugins.v1','contract_version':CONTRACT_VERSION,
                'catalog_count':len(entries),'verified_full_semantic_compilers':0,
                'tier_counts':{s:sum(s in x['stages'] for x in entries) for s in SUPPORTED_STAGES},
                'entries':entries}

ARRAY_CASES={
 'index_constants':'let values = [4, 10, 15]\nprint(values[0] + values[2])',
 'length':'let values = [4, 10, 15]\nprint(len(values))',
 'computed_index':'let values = [4, 10, 15]\nlet k = 1\nprint(values[k] * 3)',
 'array_branch':'let values = [4, 10, 15]\nif values[1] > 9:\n    print(values[2])\nelse:\n    print(values[0])',
}
NEGATIVE_CASES={
 'invalid_source':'let values = [3,4]\nprint(values[',
 'private_attribute':'let values = [3,4]\nprint(values.__class__)',
}
ARRAY_TARGETS=('python','javascript','ruby','php')

def array_qualification(targets=None,timeout=12):
    selected=tuple(targets if targets is not None else ARRAY_TARGETS)
    if not selected or any(t not in ARRAY_TARGETS for t in selected):raise PluginError('Unsupported target for array-index equivalence')
    outcomes=[]
    for lang in selected:
        for label,source in ARRAY_CASES.items():
            result=verify(source,lang,timeout=timeout)
            outcomes.append({'language':lang,'case':label,'source_sha256':sha256(source.encode()).hexdigest(),
                             'status':result['status'],'expected':result.get('expected_output'),
                             'observed':result.get('native',{}).get('stdout'),
                             'exit_code':result.get('native',{}).get('returncode'),
                             'diagnostic':str(result.get('error') or result.get('build',{}).get('stderr') or '')[-600:]})
        for label,source in NEGATIVE_CASES.items():
            result=verify(source,lang,timeout=timeout)
            outcomes.append({'language':lang,'case':label,'source_sha256':sha256(source.encode()).hexdigest(),
                             'status':'rejected' if result['status']=='invalid_usl' else 'unexpected_acceptance',
                             'error':result.get('error','')[:500]})
    return {'schema':'usl.array.qualification.v1','claims':'Only listed array cases and runtimes checked; no general compiler claim',
            'passed':sum(r['status'] in ('passed','rejected') for r in outcomes),
            'total':len(outcomes),'all_passed':all(r['status'] in ('passed','rejected') for r in outcomes),
            'outcomes':outcomes}
