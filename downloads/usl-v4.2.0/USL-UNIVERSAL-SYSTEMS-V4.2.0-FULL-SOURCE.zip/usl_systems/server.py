"""Local-only JSON API and responsive single-page development GUI (stdlib server)."""
import json,os,platform,urllib.parse,webbrowser,threading,time,shutil,secrets
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from .store import Store
from .repair_proposals import propose_syntax_repair
from .observed_repair import ObservedRepair
from .native_syntax import check_source as native_syntax_check, available as native_syntax_availability
from .engine import Engine
from .catalog import load_catalog
from .equations import list_equations,evaluate,EquationError
from .equation_import import EquationWorkspace,CustomEquationError
from .collapse import collapse_bytes,restore_bytes,CollapseError
from .fractal import FactoredFractal,ServiceTensorPlanner,dimensionless_load,FractalError
from .incremental import CollapseCompute,IncrementalError
from .adaptive import AdaptiveExecutor
from .compiler import TARGETS
from .native import tool_available
from .agent import models,ask_model
from .pack import package,verify_package
from .language import USLError
from .resources import discover
from .bridge import ProcessBridge
from .autonomy import AutonomyController, AutonomyError
from .ir import lower
from .integrations import integration_status
from .legacy_runtime import bundled_sources, bridge_status, bridge_latest_report, LegacyError
from .qualification import profiles
from .syntax_validation import VALIDATORS, validate_syntax
from .shadow_sessions import ShadowSessions
from . import __version__

ROOT=Path(__file__).resolve().parent.parent
MIMES={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'}

class Handler(BaseHTTPRequestHandler):
    store=None
    engine=None
    bridge=None
    autonomy=None
    shadow_sessions=None
    server_version='USLUniversal/1.3'
    def log_message(self,fmt,*args):
        # Avoid logging prompt content, tokens or secret-bearing URLs.
        if '/api/model/chat' not in str(args):super().log_message(fmt,*args)

    def json(self,obj,status=200):
        data=json.dumps(obj,ensure_ascii=False,default=str).encode('utf8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; connect-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self'")
        self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

    def check_host(self):
        host=self.headers.get('Host','')
        return host.split(':')[0].lower() in ('127.0.0.1','localhost','[::1]')

    def get_body(self):
        typ=self.headers.get('Content-Type','').lower()
        if not typ.startswith('application/json'):raise ValueError('JSON Content-Type required')
        size=int(self.headers.get('Content-Length','0'))
        if size<1 or size>1_000_000:raise ValueError('Request size must be 1..1,000,000 bytes')
        return json.loads(self.rfile.read(size))

    def do_OPTIONS(self):self.send_response(405);self.end_headers()

    def do_GET(self):
        if not self.check_host():return self.json({'error':'Invalid host'},403)
        p=urllib.parse.urlsplit(self.path);q=urllib.parse.parse_qs(p.query)
        try:
            if p.path=='/api/health':return self.json({'status':'ok','version':__version__,'port':self.server.server_port})
            if p.path=='/api/source-engines':
                from .source_engines import discover
                from .source_qualification import fixture
                contracts=discover()
                for id_,contract in contracts.items():
                    example=fixture(id_)
                    contract['example']={'source':example['source'],'context':example['context']}
                return self.json({'version':__version__,'contracts':contracts})
            if p.path=='/api/stats':
                c=load_catalog()
                return self.json({'version':__version__,'syntax_families':len(c),'emitters':len(TARGETS),
                    'emitter_languages':list(TARGETS),'jobs':len(self.store.jobs(500)),'projects':len(self.store.list_projects()),
                    'model':models(),'native_available':[x for x in TARGETS if tool_available(x)]})
            if p.path=='/api/languages':
                items=load_catalog()
                term=q.get('q',[''])[0].lower()[:80]
                if term:items=[r for r in items if term in r['name'].lower() or term in r['id'].lower() or any(term in a.lower() for a in r['aliases'])]
                offset=max(0,int(q.get('offset',['0'])[0]));limit=min(200,max(1,int(q.get('limit',['90'])[0])))
                return self.json({'total':len(items),'offset':offset,'items':items[offset:offset+limit],'note':'Recognition does not imply a transpiler or installed native compiler.'})
            if p.path=='/api/jobs':return self.json({'items':self.store.jobs()})
            if p.path=='/api/job':
                obj=self.store.job(q.get('id',[''])[0]);return self.json(obj if obj else {'error':'Not found'},200 if obj else 404)
            if p.path=='/api/events':return self.json({'items':self.store.events()})
            if p.path=='/api/shadow/sessions':
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                return self.json({'items':self.shadow_sessions.list()})
            if p.path=='/api/shadow/history':
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                return self.json(self.shadow_sessions.history(q.get('id',[''])[0]))
            if p.path=='/api/autonomy/runs':return self.json({'items':self.autonomy.list()})
            if p.path=='/api/autonomy/run':return self.json(self.autonomy.detail(q.get('id',[''])[0]))
            if p.path=='/api/processes':return self.json({'items':self.bridge.list()})
            if p.path=='/api/process':
                obj=self.bridge.detail(q.get('id',[''])[0]);return self.json(obj if obj else {'error':'Not found'},200 if obj else 404)
            if p.path=='/api/projects':return self.json({'items':self.store.list_projects()})
            if p.path=='/api/read':return self.json({'content':self.store.read(q.get('project',['demo'])[0],q.get('path',['main.usl'])[0])})
            if p.path=='/api/models':return self.json(models())
            if p.path=='/api/integrations':return self.json(integration_status(network_probe=False))
            if p.path=='/api/equations':
                items=list_equations(q.get('q',[''])[0][:100],q.get('domain',[None])[0],extra=EquationWorkspace(self.store.root).records())
                return self.json({'total':len(items),'executable':sum(x['executable'] for x in items),'items':items[:200]})
            if p.path=='/api/algorithms':
                return self.json({'version':'1.3.0','equations':len(list_equations()),'operations':
                 ['SHA-256 content identity','zlib codec optimization','XOR/reference delta','partial segment reuse','exact verification',
                 'N-M logical scheduling','bounded recursive factoring','identical-work CAS','Jain load fairness'],
                 'full_606_compilers':False,'hardware_acceleration':'optional external providers; not implied'})
            if p.path=='/api/recovered':return self.json({'components':bundled_sources(),'note':'Original archives included; stage via recovered-stage CLI. Not started automatically.'})
            if p.path=='/api/recovered/bridge':
                # Authenticated upstream status, deliberately sanitized. No pairing token ever crosses to the UI.
                try:return self.json(bridge_status())
                except LegacyError as exc:return self.json({'connected':False,'component':'bridge_v3','reason':str(exc)})
            if p.path=='/api/syntax/native-targets':return self.json({'targets':native_syntax_availability(),'claim':'Actual syntax checks only; not full semantic compilers'})
            if p.path=='/api/syntax/parsers':return self.json({'parsers':VALIDATORS,'claim':'Syntax parsing only, not complete semantic compilation'})
            if p.path=='/api/bridge/latest':
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                return self.json(bridge_latest_report())
            if p.path=='/api/compilers':
                rows=list(profiles());return self.json({'catalog_count':len(rows),'built_in_emitters':len(TARGETS),'complete_semantic_compilers_proven':0,'items':rows})
            if p.path=='/api/system':return self.json({'system':platform.system(),'version':platform.version(),'cpu_logical':os.cpu_count(),
                'python':platform.python_version(),'machine':platform.machine(),'data_root':str(self.store.root),
                'native_available':{x:tool_available(x) for x in TARGETS},'resources':discover()})
            if p.path.startswith('/api/download/'):
                name=p.path.split('/')[-1]
                if not name.endswith('.uslpack.zip') or not name.replace('.','').replace('_','').replace('-','').isalnum():raise ValueError('Invalid bundle name')
                file=self.store.root/'exports'/name
                if not file.exists():return self.json({'error':'Missing export'},404)
                data=file.read_bytes();self.send_response(200)
                self.send_header('Content-Type','application/zip');self.send_header('Content-Disposition','attachment; filename="'+name+'"')
                self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
            if p.path=='/':filename='index.html'
            else:
                filename=p.path.lstrip('/')
            if filename not in ('index.html','app.js','styles.css'):return self.json({'error':'Not found'},404)
            file=ROOT/'ui'/filename
            content=file.read_bytes()
            self.send_response(200);self.send_header('Content-Type',MIMES[file.suffix]+'; charset=utf-8')
            self.send_header('Cache-Control','no-cache')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; connect-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self'")
            self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
        except (ValueError,OSError,KeyError) as e:self.json({'error':str(e)},400)

    def do_POST(self):
        if not self.check_host():return self.json({'error':'Invalid host'},403)
        origin=self.headers.get('Origin')
        if origin:
            from urllib.parse import urlsplit
            o=urlsplit(origin)
            if o.hostname not in ('localhost','127.0.0.1') or o.port!=self.server.server_port:
                return self.json({'error':'Cross-origin mutations denied'},403)
        try:
            body=self.get_body();p=urllib.parse.urlsplit(self.path).path
            if not isinstance(body,dict):raise ValueError('Expected JSON object')
            if p in ('/api/source/run','/api/source/program'):
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                if body.get('approve_execution') is not True:
                    return self.json({'error':'Explicit source execution approval required'},403)
                from .source_engines import execute,SourceSession
                if p.endswith('/run'):
                    return self.json(execute(body.get('catalog_id'),body.get('source'),body.get('context',{}),approved=True))
                return self.json(SourceSession(approved=True,imports=body.get('imports',{})).interpret(body.get('source','')))
            if p.startswith('/api/shadow/'):
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                if p=='/api/shadow/create':return self.json(self.shadow_sessions.new(body.get('model')))
                if p=='/api/shadow/send':return self.json(self.shadow_sessions.send(body.get('id'),body.get('prompt'),body.get('model')))
                if p=='/api/shadow/cancel':return self.json(self.shadow_sessions.cancel(body.get('id')))
                return self.json({'error':'Unknown session operation'},404)
            if p=='/api/syntax/native-check':
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                return self.json(native_syntax_check(body.get('language'),body.get('source'),authorized=body.get('approve_native') is True))
            if p in ('/api/repair/observe','/api/repair/continue'):
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                observer=ObservedRepair(self.store,self.bridge)
                if p=='/api/repair/observe':
                    return self.json(observer.observe(body.get('project'),body.get('path'),authorized=body.get('approve_observation') is True),201)
                return self.json(observer.approve_and_verify(body.get('observation_id'),authorized=body.get('approve_repair') is True),200)
            if p=='/api/repair/propose':
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                suggestion=propose_syntax_repair(self.store,body.get('project'),body.get('path'))
                # Persist a DRAFT only; approval and process execution remain separate owner actions.
                draft=self.autonomy.create(suggestion['plan'])
                suggestion['draft_id']=draft['id']
                return self.json(suggestion,201)
            if p.startswith('/api/autonomy/'):
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                if p=='/api/autonomy/create':return self.json(self.autonomy.create(body.get('plan')),201)
                if p=='/api/autonomy/propose':return self.json(self.autonomy.propose(body.get('goal'),body.get('model')),201)
                rid=body.get('id','')
                if not isinstance(rid,str) or len(rid)>50:raise ValueError('Invalid autonomy run ID')
                if p=='/api/autonomy/approve':return self.json(self.autonomy.approve(rid,allow_process=body.get('allow_process') is True))
                if p=='/api/autonomy/start':return self.json(self.autonomy.begin(rid),202)
                if p=='/api/autonomy/cancel':return self.json(self.autonomy.cancel(rid))
                return self.json({'error':'Unknown autonomy command'},404)
            if p in ('/api/run','/api/compile','/api/verify','/api/build','/api/ai-transpile','/api/flow','/api/swarm'):
                return self.json(self.engine.submit(p[5:],body),202)
            if p in ('/api/process/launch','/api/process/stop'):
                if self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required'},403)
                if p.endswith('/launch'):
                    result=self.bridge.launch(body.get('project','demo'),body.get('argv'),body.get('max_seconds',300))
                    return self.json(result,202 if result['status']=='running' else 400)
                return self.json(self.bridge.stop(body.get('id','')))
            if p=='/api/equation/evaluate':
                return self.json(evaluate(body.get('id'),body.get('params'),extra=EquationWorkspace(self.store.root).records()))
            if p=='/api/worker/run':
                if body.get('mode')=='process' and self.headers.get('X-USL-Control-Token','')!=self.store.stop_token:
                    return self.json({'error':'Private control token required for process workers'},403)
                values=body.get('values',[])
                if not isinstance(values,list) or len(values)>50000:raise ValueError('At most 50,000 values through local HTTP')
                config=body.get('config',{})
                if not isinstance(config,dict):raise ValueError('config must be object')
                workers=FactoredFractal(workers=config.get('workers',4),max_depth=config.get('depth',5),leaf_size=config.get('leaf_size',512))
                return self.json(workers.execute(values,operator=body.get('operator','sum_squares'),
                     dimensions=body.get('dimensions',['execution','cache','verification']),mode=body.get('mode','async'),reuse=body.get('reuse',True)))
            if p=='/api/incremental':
                values=body.get('values',[])
                if not isinstance(values,list) or len(values)>50000:raise ValueError('50,000 items maximum')
                calc=CollapseCompute(body.get('operator','sum_squares'))
                baseline=calc.initialize(values)
                changes=body.get('changes',{})
                if not isinstance(changes,dict):raise ValueError('Changes must be a JSON object')
                next_=calc.update({int(k):v for k,v in changes.items()},audit=bool(body.get('audit',True)))
                return self.json({'baseline':baseline,'incremental':next_,'snapshot':calc.snapshot()})
            if p=='/api/tensor/place':return self.json(ServiceTensorPlanner().plan(body.get('requirements'),body.get('capacities')))
            if p=='/api/adaptive/select':
                values=body.get('values',[])
                if not isinstance(values,list) or len(values)>50000:raise ValueError('At most 50,000 items')
                return self.json(AdaptiveExecutor(workers=body.get('workers',4)).choose(values,
                    operator=body.get('operator','sum_squares'),repeats=body.get('repeats',3)))
            if p=='/api/resource/load':return self.json(dimensionless_load(body.get('requirements',{}),body.get('capacity',{})))
            if p=='/api/collapse':
                raw=body.get('text','');ref=body.get('reference')
                if not isinstance(raw,str) or (ref is not None and not isinstance(ref,str)):raise ValueError('text/reference must be strings')
                result=collapse_bytes(raw.encode('utf8'),None if ref is None else ref.encode('utf8'),body.get('mode','all'))
                verified=restore_bytes(result,ref.encode('utf8') if ref is not None else None)==raw.encode('utf8')
                # return compact summary, not payload (it is an API diagnostic)
                return self.json({'codec':result['codec'],'input_bytes':result['raw_bytes'],
                    'encoded_bytes':result['encoded_bytes'],'saved_bytes':result['saved_bytes'],
                    'sha256':result['sha256'],'exact_verified':verified})
            if p=='/api/syntax/validate':
                return self.json(validate_syntax(body.get('source'),body.get('language')))
            if p=='/api/ir':
                source=body.get('source','')
                if not isinstance(source,str):raise ValueError('source must be a string')
                return self.json(lower(source))
            if p=='/api/save':
                return self.json(self.store.save(body.get('project','demo'),body.get('path','main.usl'),body.get('content','')))
            if p=='/api/remember':
                key=body.get('key','')
                if not isinstance(key,str) or not key.startswith('user.') or len(key)>100:raise ValueError('Memory keys must be user.*')
                self.store.remember(key,body.get('value'));return self.json({'saved':True,'key':key})
            if p=='/api/recall':return self.json({'value':self.store.recall(body.get('key',''))})
            if p=='/api/model/chat':
                prompt=body.get('prompt','')
                if not isinstance(prompt,str) or not prompt or len(prompt)>8000:raise ValueError('Invalid prompt')
                reply=ask_model(prompt,body.get('model'))
                return self.json({'reply':reply,'provider':'ollama-local'})
            if p=='/api/shutdown':
                if self.headers.get('X-USL-Stop-Token','')!=self.store.stop_token:
                    return self.json({'error':'Invalid shutdown token'},403)
                self.json({'stopping':True})
                threading.Thread(target=self.server.shutdown,daemon=True).start()
                return
            if p=='/api/pack':
                project=body.get('project','demo')
                root=self.store.safe_project_path(project,'.')
                name=project+'.uslpack.zip'
                out=self.store.root/'exports'/name;out.parent.mkdir(exist_ok=True)
                manifest=package(root,out)
                verified=verify_package(out)
                self.store.event('package','Packaged '+name)
                return self.json({'url':'/api/download/'+name,'files':verified['files'],'bytes':out.stat().st_size,'verified':verified['verified']})
            return self.json({'error':'Unknown endpoint'},404)
        except (USLError,EquationError,CustomEquationError,CollapseError,FractalError,IncrementalError,AutonomyError,ValueError,TypeError,KeyError,OSError,json.JSONDecodeError) as e:
            self.store.event('api_error',f'{type(e).__name__}: {e}')
            return self.json({'error':str(e)},400)


def start(host='127.0.0.1',port=8772,data=None,open_browser=True):
    store=Store(data);engine=Engine(store);bridge=ProcessBridge(store);autonomy=AutonomyController(store,bridge);shadow_sessions=ShadowSessions(store)
    token_path=store.root/'control_token'
    if not token_path.exists():
        token_path.write_text(secrets.token_urlsafe(40),encoding='utf8')
        try:os.chmod(token_path,0o600)
        except OSError:pass
    store.stop_token=token_path.read_text(encoding='utf8').strip()
    class LocalHandler(Handler):pass
    LocalHandler.store=store;LocalHandler.engine=engine;LocalHandler.bridge=bridge;LocalHandler.autonomy=autonomy;LocalHandler.shadow_sessions=shadow_sessions
    with ThreadingHTTPServer((host,int(port)),LocalHandler) as server:
        server.daemon_threads=True
        addr=f'http://{host}:{server.server_port}/'
        print(f'USL Universal Systems 1.0.0 | {addr}',flush=True)
        print('Persistent data:',store.root,flush=True)
        if open_browser:threading.Timer(0.7,lambda:webbrowser.open(addr)).start()
        try:server.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:print('Stopped.')
        finally:
            bridge.shutdown()
            autonomy.close()
            engine.pool.shutdown(wait=False,cancel_futures=True)
