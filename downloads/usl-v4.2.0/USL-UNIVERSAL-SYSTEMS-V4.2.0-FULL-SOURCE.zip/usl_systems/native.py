"""Optional native toolchain verification for code GENERATED from the safe USL subset."""
import shutil,subprocess,tempfile,sys
from pathlib import Path
from .compiler import transpile,UnsupportedCompile
from .language import Interpreter,USLError

COMMANDS={
 'python':(['{python}','main.py'],None),
 'javascript':(['node','main.js'],None),
 'ruby':(['ruby','main.rb'],None),
 'php':(['php','main.php'],None),
 'lua':(['lua','main.lua'],None),
 'go':(['go','run','main.go'],None),
 'java':(['java','Main'],['javac','Main.java']),
 'cpp':(['./program'],['g++','-std=c++17','-O0','main.cpp','-o','program']),
 'c':(['./program'],['gcc','-std=c11','-O0','main.c','-o','program']),
 'rust':(['./program'],['rustc','main.rs','-o','program']),
 'powershell':(['pwsh','-NoProfile','-File','main.ps1'],None),
}

def tool_available(target):
    if target=='python':return True
    if target not in COMMANDS:return False
    runner,build=COMMANDS[target]
    return all(shutil.which(a[0]) if a[0] not in ('{python}','./program') else True for a in [runner]+([build] if build else []))

def verify(source,target,timeout=8):
    """Returns behavioral equality to the USL interpreter when toolchain exists."""
    target=target.lower();target={'js':'javascript','py':'python','c++':'cpp'}.get(target,target)
    try:expected=Interpreter(timeout=min(timeout,4)).run(source).output
    except USLError as e:return {'status':'invalid_usl','target':target,'error':str(e)}
    try:generated=transpile(source,target)
    except (UnsupportedCompile,USLError) as e:return {'status':'unsupported_construct','target':target,'error':str(e)}
    if not tool_available(target):return {'status':'toolchain_missing','target':target,'expected_output':expected,'code':generated.code}
    runner,build=COMMANDS[target]
    with tempfile.TemporaryDirectory(prefix='usl_verify_') as tmp:
        work=Path(tmp)
        (work/generated.filename).write_text(generated.code,encoding='utf8')
        def call(command):
            command=[sys.executable if s=='{python}' else s for s in command]
            try:
                x=subprocess.run(command,cwd=work,text=True,capture_output=True,timeout=timeout,check=False)
                return {'returncode':x.returncode,'stdout':x.stdout[-15000:],'stderr':x.stderr[-15000:]}
            except subprocess.TimeoutExpired:return {'returncode':-1,'stdout':'','stderr':'Timeout'}
        if build:
            b=call(build)
            if b['returncode']!=0:return {'status':'compilation_failed','target':target,'build':b,'code':generated.code}
        result=call(runner)
        matched=result['returncode']==0 and result['stdout'].replace('\r\n','\n')==expected
        return {'status':'passed' if matched else 'failed','target':target,'matched':matched,
                'expected_output':expected,'native':result,'code':generated.code}
