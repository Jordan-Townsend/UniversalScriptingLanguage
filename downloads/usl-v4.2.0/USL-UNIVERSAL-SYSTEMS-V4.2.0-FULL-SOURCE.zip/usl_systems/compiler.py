"""USL subset AST -> explicit, typed target code emitters.

A code generator is not automatically proof of a compiling or equivalent program.
Language results carry a support tier and require their actual toolchain for verification.
"""
from __future__ import annotations
import ast
import json
from dataclasses import dataclass
from .language import parse,USLError

class UnsupportedCompile(USLError): pass

TARGETS = {
    'python': {'extension':'.py','toolchain':'python','tier':'implemented'},
    'javascript': {'extension':'.js','toolchain':'node','tier':'implemented'},
    'typescript': {'extension':'.ts','toolchain':'tsc','tier':'implemented'},
    'ruby': {'extension':'.rb','toolchain':'ruby','tier':'implemented'},
    'lua': {'extension':'.lua','toolchain':'lua','tier':'implemented'},
    'php': {'extension':'.php','toolchain':'php','tier':'implemented'},
    'go': {'extension':'.go','toolchain':'go','tier':'implemented'},
    'java': {'extension':'.java','toolchain':'javac','tier':'implemented'},
    'cpp': {'extension':'.cpp','toolchain':'g++','tier':'implemented'},
    'c': {'extension':'.c','toolchain':'gcc','tier':'implemented'},
    'csharp': {'extension':'.cs','toolchain':'dotnet','tier':'experimental'},
    'rust': {'extension':'.rs','toolchain':'rustc','tier':'experimental'},
    'powershell': {'extension':'.ps1','toolchain':'pwsh','tier':'experimental'},
}
ALIASES={'js':'javascript','ts':'typescript','py':'python','c++':'cpp','cs':'csharp','golang':'go','pwsh':'powershell','ps':'powershell'}

def target_name(name):return ALIASES.get(name.lower(),name.lower())

@dataclass
class Generated:
    target:str
    filename:str
    code:str
    tier:str
    note:str

class Compiler:
    def __init__(self,target):
        self.lang=target_name(target)
        if self.lang not in TARGETS:raise UnsupportedCompile(f'No verified emitter for {target}. All catalog languages remain available for native toolchain adapters and legacy-template import.')
        self.lines=[];self.depth=0;self.types={};self.vars=set();self.fn_depth=0;self.int_functions=set();self.top_funcs=[]

    def add(self,s):self.lines.append(('    '*self.depth)+s)

    def expr(self,n):
        if isinstance(n,ast.Constant):
            if n.value is None:return {'python':'None','ruby':'nil','lua':'nil','php':'null','powershell':'$null'}.get(self.lang,'null')
            if isinstance(n.value,bool):
                if self.lang=='python':return str(n.value)
                if self.lang=='powershell':return '$true' if n.value else '$false'
                return 'true' if n.value else 'false'
            return json.dumps(n.value,ensure_ascii=False)
        if isinstance(n,ast.Name):
            if self.lang in ('php','powershell'):return '$'+n.id
            return n.id
        if isinstance(n,ast.BinOp):
            ops={ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/',ast.FloorDiv:'//',ast.Mod:'%',ast.Pow:'**'}
            if type(n.op) not in ops:raise UnsupportedCompile('Unsupported math operation')
            if self.lang in ('c','cpp','go','java','csharp','rust') and isinstance(n.op,(ast.FloorDiv,ast.Pow)):
                raise UnsupportedCompile('Target requires specialized integer/power conversion')
            if self.lang=='lua' and isinstance(n.op,ast.FloorDiv):raise UnsupportedCompile('Lua floor division requires version-specific support')
            op=ops[type(n.op)]
            if self.lang=='powershell' and op=='%':op='-mod'
            return '('+self.expr(n.left)+' '+op+' '+self.expr(n.right)+')'
        if isinstance(n,ast.UnaryOp):
            x=self.expr(n.operand)
            if isinstance(n.op,ast.Not):return ('not ' if self.lang in ('python','ruby','lua') else '-not ' if self.lang=='powershell' else '!')+'('+x+')'
            if isinstance(n.op,ast.USub):return '-'+x
            if isinstance(n.op,ast.UAdd):return '+'+x
        if isinstance(n,ast.Compare):
            ops={ast.Eq:'==',ast.NotEq:'!=',ast.Lt:'<',ast.Gt:'>',ast.LtE:'<=',ast.GtE:'>='}
            chunks=[]; left=n.left
            for op,right in zip(n.ops,n.comparators):
                if type(op) not in ops:raise UnsupportedCompile('Membership comparisons require target-specific conversion')
                sep=ops[type(op)]
                if self.lang=='lua' and sep=='!=':sep='~='
                if self.lang=='powershell':sep={'==':'-eq','!=':'-ne','<':'-lt','>':'-gt','<=':'-le','>=':'-ge'}[sep]
                chunks.append('('+self.expr(left)+' '+sep+' '+self.expr(right)+')');left=right
            conj=' and ' if self.lang in ('python','ruby','lua') else ' -and ' if self.lang=='powershell' else ' && '
            return conj.join(chunks)
        if isinstance(n,ast.BoolOp):
            sep=(' and ' if isinstance(n.op,ast.And) else ' or ') if self.lang in ('python','ruby','lua') else (' -and ' if isinstance(n.op,ast.And) else ' -or ') if self.lang=='powershell' else (' && ' if isinstance(n.op,ast.And) else ' || ')
            return '('+sep.join(self.expr(x) for x in n.values)+')'
        if isinstance(n,ast.IfExp):
            if self.lang in ('python',):return f'{self.expr(n.body)} if {self.expr(n.test)} else {self.expr(n.orelse)}'
            if self.lang in ('javascript','typescript','php','java','cpp','c','go','csharp'):
                return f'({self.expr(n.test)} ? {self.expr(n.body)} : {self.expr(n.orelse)})' if self.lang!='go' else self.fail('Go does not support ternary')
            return self.fail('Conditional expression unsupported in this emitter')
        if isinstance(n,ast.Call):
            if not isinstance(n.func,ast.Name) or n.keywords:raise UnsupportedCompile('Only direct positional calls')
            name=n.func.id
            if name=='print':raise UnsupportedCompile('Nested print calls unsupported')
            if name=='range':raise UnsupportedCompile('Use range only in for-loop')
            supported={'str','int','float','len'}
            if name not in supported and name not in self.vars:raise UnsupportedCompile(f'Expression function {name} not supported')
            args=', '.join(self.expr(v) for v in n.args)
            if name=='len':
                if self.lang in ('javascript','typescript'):return f'({args}).length'
                if self.lang=='ruby':return f'({args}).length'
                if self.lang=='lua':return f'#{args}'
                if self.lang=='php':return f'count({args})'
                if self.lang=='python':return f'len({args})'
            return f'{name}({args})'
        if isinstance(n,ast.Subscript):
            # The interpreter already supports subscripts. Expose bounded, explicit
            # nonnegative list indexing in compatible native emitters. In
            # particular, Lua has 1-based arrays; USL is 0-based.
            if self.lang not in ('python','javascript','typescript','ruby','php','lua'):
                self.fail('Index expression not qualified for this target')
            if isinstance(n.slice,ast.Constant) and (type(n.slice.value) is not int or n.slice.value<0):
                self.fail('Only nonnegative integral array indexes have cross-target semantics')
            if isinstance(n.slice,ast.UnaryOp) and isinstance(n.slice.op,ast.USub):
                self.fail('Negative indexes have target-specific semantics')
            left=self.expr(n.value)
            index=self.expr(n.slice)
            if self.lang=='lua':index='('+index+' + 1)'
            return left+'['+index+']'
        if isinstance(n,(ast.List,ast.Tuple)):
            x=', '.join(self.expr(v) for v in n.elts)
            if self.lang=='php':return '['+x+']'
            if self.lang=='lua':return '{'+x+'}'
            if self.lang=='ruby':return '['+x+']'
            if self.lang in ('python','javascript','typescript'):return '['+x+']'
            return self.fail('List values not supported for this target')
        return self.fail('Expression unsupported: '+type(n).__name__)

    def fail(self,message):raise UnsupportedCompile(message)

    def vartype(self,n):
        if isinstance(n,ast.Constant):
            if isinstance(n.value,bool):return 'bool'
            if isinstance(n.value,int):return 'int'
            if isinstance(n.value,float):return 'float'
            if isinstance(n.value,str):return 'str'
        if isinstance(n,ast.Name):return self.types.get(n.id,'unknown')
        if isinstance(n,(ast.List,ast.Tuple)):
            entries=[self.vartype(z) for z in n.elts]
            return ('array['+entries[0]+']') if entries and all(t==entries[0] and t!='unknown' for t in entries) else 'array[unknown]'
        if isinstance(n,ast.Subscript):
            original=self.vartype(n.value)
            return original[6:-1] if original.startswith('array[') and original.endswith(']') else 'unknown'
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in self.int_functions:return 'int'
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='len':return 'int'
        if isinstance(n,ast.BinOp):
            a,b=self.vartype(n.left),self.vartype(n.right)
            if a=='str' and b=='str' and isinstance(n.op,ast.Add):return 'str'
            if a in ('int','float') and b in ('int','float'):
                return 'float' if isinstance(n.op,ast.Div) or a=='float' or b=='float' else 'int'
        if isinstance(n,(ast.Compare,ast.BoolOp)):return 'bool'
        return 'unknown'

    def printline(self,n):
        args=n.args
        if len(args)!=1 and self.lang in ('c','cpp','rust'):self.fail('Only single expression printing supported in this target')
        x=', '.join(self.expr(z) for z in args)
        # USL/Python boolean display is capitalized; many foreign runtimes
        # print lowercase true/false (or PHP's 1/empty). Lower known-bool
        # expressions through a target-specific formatting shim, preserving
        # native boolean computation. Unknown types remain qualified by actual
        # differential execution, never guessed to be equivalent.
        if len(args)==1 and self.vartype(args[0])=='bool':
            if self.lang in ('javascript','typescript'):
                return 'console.log(('+x+') ? "True" : "False");'
            if self.lang=='ruby':
                return 'puts (('+x+') ? "True" : "False")'
            if self.lang=='php':
                return 'echo (('+x+') ? "True" : "False"), PHP_EOL;'
            if self.lang=='lua':
                return 'print(('+x+') and "True" or "False")'
            if self.lang=='go':
                return 'fmt.Println(map[bool]string{true: "True", false: "False"}[('+x+')])'
            if self.lang=='java':
                return 'System.out.println(('+x+') ? "True" : "False");'
            if self.lang=='cpp':
                return 'std::cout << (('+x+') ? "True" : "False") << std::endl;'
            if self.lang=='c':
                return 'printf("%s\\n", ('+x+') ? "True" : "False");'
            if self.lang=='csharp':
                return 'Console.WriteLine(('+x+') ? "True" : "False");'
            if self.lang=='rust':
                return 'println!("{}", if '+x+' { "True" } else { "False" });'
        if self.lang=='python':return 'print('+x+')'
        if self.lang in ('javascript','typescript'):return 'console.log('+x+');'
        if self.lang=='ruby':return 'puts '+(x or '""')
        if self.lang=='lua':return 'print('+x+')'
        if self.lang=='php':return 'echo '+(x or '""')+', PHP_EOL;'
        if self.lang=='go':return 'fmt.Println('+x+')'
        if self.lang=='java':return 'System.out.println('+x+');'
        if self.lang=='cpp':return 'std::cout << '+(x or '""')+' << std::endl;'
        if self.lang=='rust':return 'println!("{}", '+x+');'
        if self.lang=='csharp':return 'Console.WriteLine('+x+');'
        if self.lang=='powershell':return 'Write-Output '+x
        if self.lang=='c':
            t=self.vartype(args[0]) if args else 'str'
            fmt={'int':'%d','float':'%g','str':'%s','bool':'%d'}.get(t)
            if fmt is None:self.fail('C printing requires an inferable primitive type')
            return 'printf("'+fmt+'\\n", '+x+');'
        return self.fail('Printer unavailable')

    def assign(self,n):
        key=n.targets[0].id; x=self.expr(n.value);new=key not in self.vars
        if self.lang in ('python','ruby','lua','powershell','php'):
            lhs='$'+key if self.lang in ('php','powershell') else key
            starter='local ' if self.lang=='lua' and new else ''
            s=starter+lhs+' = '+x
            if self.lang=='php':s+=';'
        elif self.lang in ('javascript','typescript'):s=('let ' if new else '')+key+' = '+x+';'
        elif self.lang=='go':s=key+(' := ' if new else ' = ')+x
        elif self.lang=='rust':s=('let mut ' if new else '')+key+' = '+x+';'
        elif self.lang=='cpp':s=('auto ' if new else '')+key+' = '+x+';'
        elif self.lang=='java':s=('var ' if new else '')+key+' = '+x+';'
        elif self.lang=='csharp':s=('var ' if new else '')+key+' = '+x+';'
        elif self.lang=='c':
            ty=self.vartype(n.value)
            if new:
                cast={'int':'int','float':'double','str':'const char*','bool':'int'}.get(ty)
                if not cast:self.fail('C assignment requires an inferable primitive')
                s=cast+' '+key+' = '+x+';'
            else:s=key+' = '+x+';'
        else:self.fail('Assignment unavailable')
        self.add(s);self.vars.add(key)
        if new:self.types[key]=self.vartype(n.value)

    def block(self,body):
        if not body:
            if self.lang=='python':self.add('pass')
            return
        for n in body:self.stmt(n)

    def scoped(self,body):
        self.depth+=1
        try:self.block(body)
        finally:self.depth-=1

    def control(self,keyword,cond,body,else_body=None):
        lang=self.lang
        if lang=='python':
            self.add(keyword+(' '+cond if cond else '')+':');self.scoped(body)
            if else_body:self.add('else:');self.scoped(else_body)
        elif lang in ('ruby','lua'):
            head=keyword+(' '+cond if cond else '')
            if lang=='lua':head+=' then' if keyword=='if' else ' do'
            self.add(head);self.scoped(body)
            if else_body:self.add('else');self.scoped(else_body)
            self.add('end')
        elif lang=='powershell':
            self.add(keyword+' ('+cond+') {');self.scoped(body);self.add('}')
            if else_body:self.add('else {');self.scoped(else_body);self.add('}')
        else:
            c=('('+cond+')' if lang!='go' else cond)
            self.add(keyword+' '+c+' {');self.scoped(body)
            if else_body and lang=='go':
                self.add('} else {');self.scoped(else_body);self.add('}')
            else:
                self.add('}')
                if else_body:self.add('else {');self.scoped(else_body);self.add('}')

    def forloop(self,n):
        if n.orelse:self.fail('For-loop else unsupported outside interpreter/Python')
        if not isinstance(n.iter,ast.Call) or not isinstance(n.iter.func,ast.Name) or n.iter.func.id!='range':
            self.fail('Emitter supports for loops over range only')
        args=n.iter.args
        if len(args)==1: lo,hi='0',self.expr(args[0])
        elif len(args)==2:lo,hi=self.expr(args[0]),self.expr(args[1])
        else:self.fail('Emitter supports range(end) or range(start,end)')
        var=n.target.id
        self.types[var]='int';self.vars.add(var)
        if self.lang=='python':self.add(f'for {var} in range({lo}, {hi}):');self.scoped(n.body)
        elif self.lang in ('javascript','typescript','php','c','cpp','java','csharp'):
            v='$'+var if self.lang=='php' else var
            decl=('$'+var if self.lang=='php' else ('let '+var if self.lang in ('javascript','typescript') else 'int '+var))
            self.add(f'for ({decl} = {lo}; {v} < {hi}; {v}++) '+'{')
            self.scoped(n.body);self.add('}')
        elif self.lang=='go':self.add(f'for {var} := {lo}; {var} < {hi}; {var}++ '+'{');self.scoped(n.body);self.add('}')
        elif self.lang=='rust':self.add(f'for {var} in {lo}..{hi} '+'{');self.scoped(n.body);self.add('}')
        elif self.lang=='ruby':self.add(f'for {var} in {lo}...{hi}');self.scoped(n.body);self.add('end')
        elif self.lang=='lua':self.add(f'for {var} = {lo}, ({hi})-1 do');self.scoped(n.body);self.add('end')
        elif self.lang=='powershell':
            self.add(f'for (${var} = {lo}; ${var} -lt {hi}; ${var}++) '+'{');self.scoped(n.body);self.add('}')
        else:self.fail('For loop unsupported')

    def stmt(self,n):
        if isinstance(n,ast.Assign):return self.assign(n)
        if isinstance(n,ast.Expr):
            if isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='print':return self.add(self.printline(n.value))
            if self.lang in ('python','javascript','typescript','php','ruby','lua'):return self.add(self.expr(n.value)+(';' if self.lang in ('javascript','typescript','php') else ''))
            self.fail('Standalone expression unsupported in this target')
        if isinstance(n,ast.If):return self.control('if',self.expr(n.test),n.body,n.orelse)
        if isinstance(n,ast.While):
            if n.orelse:self.fail('While-else unsupported outside interpreter/Python')
            if self.lang=='go':return self.control('for',self.expr(n.test),n.body)
            return self.control('while',self.expr(n.test),n.body)
        if isinstance(n,ast.For):return self.forloop(n)
        if isinstance(n,ast.Pass):
            if self.lang=='python':self.add('pass')
            return
        if isinstance(n,ast.Break):return self.add('break'+(';' if self.lang in ('javascript','typescript','php','cpp','c','java','csharp','rust') else ''))
        if isinstance(n,ast.Continue):
            if self.lang=='lua':self.fail('Lua continue unsupported')
            return self.add('continue'+(';' if self.lang in ('javascript','typescript','php','cpp','c','java','csharp','rust') else ''))
        if isinstance(n,ast.AugAssign):
            if self.lang in ('php','powershell'):key='$'+n.target.id
            else:key=n.target.id
            if not isinstance(n.op,(ast.Add,ast.Sub)):self.fail('Augmented operator only += and -= supported')
            sym='+=' if isinstance(n.op,ast.Add) else '-='
            if self.lang=='lua':return self.add(key+' = '+key+(' + ' if sym=='+=' else ' - ')+self.expr(n.value))
            if self.lang=='powershell':return self.add(key+' '+sym+' '+self.expr(n.value))
            self.add(key+' '+sym+' '+self.expr(n.value)+(';' if self.lang in ('php','javascript','typescript','c','cpp','java','csharp','rust') else ''))
            return
        if isinstance(n,ast.Assert):
            cond=self.expr(n.test)
            if self.lang in ('python','lua'):return self.add('assert('+cond+')')
            if self.lang in ('javascript','typescript'):return self.add('if (!('+cond+')) { throw new Error("Assertion failed"); }')
            if self.lang=='ruby':return self.add('raise "Assertion failed" unless ('+cond+')')
            if self.lang=='php':return self.add('if (!('+cond+')) { throw new Exception("Assertion failed"); }')
            if self.lang=='go':return self.add('if !('+cond+') { panic("Assertion failed") }')
            if self.lang=='java':return self.add('if (!('+cond+')) { throw new AssertionError("Assertion failed"); }')
            if self.lang in ('c','cpp'):return self.add('if (!('+cond+')) { return 1; }')
            if self.lang=='csharp':return self.add('if (!('+cond+')) { throw new Exception("Assertion failed"); }')
            if self.lang=='rust':return self.add('assert!('+cond+');')
            if self.lang=='powershell':return self.add('if (-not ('+cond+')) { throw "Assertion failed" }')
            self.fail('Target assertion is not implemented')
        if isinstance(n,ast.FunctionDef):
            if self.lang not in ('python','javascript','typescript','ruby','lua','php'):
                self.fail('Functions not implemented in this emitter')
            params=[a.arg for a in n.args.args]; self.vars.add(n.name)
            if self.lang=='python':self.add('def '+n.name+'('+', '.join(params)+'):');self.scoped(n.body)
            elif self.lang in ('javascript','typescript','php'):
                ps=', '.join('$'+p if self.lang=='php' else p for p in params)
                self.add('function '+n.name+'('+ps+') {');self.scoped(n.body);self.add('}')
            elif self.lang=='ruby':self.add('def '+n.name+'('+', '.join(params)+')');self.scoped(n.body);self.add('end')
            elif self.lang=='lua':self.add('function '+n.name+'('+', '.join(params)+')');self.scoped(n.body);self.add('end')
            return
        if isinstance(n,ast.Return):
            if self.lang not in ('python','javascript','typescript','php','ruby','lua'):self.fail('Return statement unsupported')
            self.add('return'+(' '+self.expr(n.value) if n.value else '')+(';' if self.lang in ('javascript','typescript','php') else ''))
            return
        self.fail('Statement unsupported in emitter: '+type(n).__name__)

    def emit_int_function(self,n):
        """Conservative integer-only function emission, not a general type system."""
        if n.decorator_list or len(n.body)!=1 or not isinstance(n.body[0],ast.Return) or n.body[0].value is None:
            self.fail('Native numeric function requires a single return expression')
        params=[a.arg for a in n.args.args]
        if not params or len(params)>8:self.fail('Native numeric function requires 1..8 parameters')
        def is_int_expr(node):
            if isinstance(node,ast.Constant):return type(node.value)==int
            if isinstance(node,ast.Name):return node.id in params
            if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):return is_int_expr(node.operand)
            if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Mod)):
                return is_int_expr(node.left) and is_int_expr(node.right)
            return False
        if not is_int_expr(n.body[0].value):self.fail('Native numeric function must use pure integer arithmetic')
        expr=self.expr(n.body[0].value)
        lang=self.lang; name=n.name
        if lang in ('c','cpp','java','csharp'):
            sig=('static ' if lang in ('java','csharp') else '')+'int '+name+'('+', '.join('int '+p for p in params)+')'
            return sig+' { return '+expr+'; }'
        if lang=='go':return 'func '+name+'('+', '.join(p+' int' for p in params)+') int { return '+expr+' }'
        if lang=='rust':return 'fn '+name+'('+', '.join(p+': i32' for p in params)+') -> i32 { return '+expr+'; }'
        self.fail('No native function backend')

    def compile(self,source):
        tree=parse(source) if isinstance(source,str) else source
        if self.lang=='python':
            # AST is already the defined source subset. Canonical Python is fully emitted.
            return ast.unparse(tree)+'\n'
        pre={'javascript':[], 'typescript':[], 'ruby':[], 'lua':[], 'php':['<?php'],
             'go':['package main','','import "fmt"','','func main() {'],
             'java':['public class Main {','    public static void main(String[] args) {'],
             'cpp':['#include <iostream>','','int main() {'],
             'c':['#include <stdio.h>','#include <stdbool.h>','','int main(void) {'],
             'csharp':['using System;','','class Program {','    static void Main() {'],
             'rust':['fn main() {'], 'powershell':[]}[self.lang]
        self.lines=list(pre)
        self.depth=2 if self.lang in ('java','csharp') else 1 if self.lang in ('go','cpp','c','rust') else 0
        numeric_backends=('c','cpp','java','csharp','go','rust')
        for n in tree.body:
            if isinstance(n,ast.FunctionDef) and self.lang in numeric_backends:
                definition=self.emit_int_function(n)
                self.top_funcs.append(definition)
                self.int_functions.add(n.name)
                self.vars.add(n.name)
            else:self.stmt(n)
        if self.lang in ('c','cpp'):self.add('return 0;')
        if self.lang in ('go','java','cpp','c','csharp','rust'):
            self.depth-=1;self.add('}')
            if self.lang in ('java','csharp'):self.depth-=1;self.add('}')
        if self.top_funcs:
            if self.lang in ('java','csharp'):
                self.lines[-1:-1]=['    '+x for x in self.top_funcs]
            else:
                main_pos=next((i for i,line in enumerate(self.lines) if line.startswith(('int main(', 'func main(', 'fn main('))),None)
                if main_pos is None:self.fail('Could not locate generated entrypoint')
                self.lines[main_pos:main_pos]=self.top_funcs+['']
        return '\n'.join(self.lines)+'\n'

def transpile(source: str,target: str) -> Generated:
    canon=target_name(target)
    compiler=Compiler(canon)
    content=compiler.compile(source)
    info=TARGETS[canon]
    name='Main.java' if canon=='java' else 'main'+info['extension']
    return Generated(canon,name,content,info['tier'],f'Generated subset code. Validation with {info["toolchain"]} is separate from generation.')


def transpile_ir(ir,target: str) -> Generated:
    """Compile IR after integrity and safe USL grammar validation."""
    from .ir import restore
    canon=target_name(target)
    compiler=Compiler(canon)
    content=compiler.compile(restore(ir))
    info=TARGETS[canon]
    filename='Main.java' if canon=='java' else 'main'+info['extension']
    return Generated(canon,filename,content,info['tier'],
                     'Compiled from validated, versioned USL semantic IR; target execution verification is separate.')
