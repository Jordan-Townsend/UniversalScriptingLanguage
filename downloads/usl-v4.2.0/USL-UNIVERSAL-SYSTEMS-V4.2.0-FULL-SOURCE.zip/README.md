# USL v4.2 — Native source engines and executable USL orchestration

18 additional source-engine entries have real execution evidence. The current ledger records 71 tested subsets and 535 unqualified entries, with full specification qualification still zero. General source import, .usl engine calls, bounded cooperative graphs and Source Lab extend the existing subsystems. See [build status and remaining work](docs/V4.2_BUILD_STATUS.md) for commands, evidence and limits.

# USL v4.0 — New Language Capability and Cooperative Worker Release

See `docs/V4.0_LANGUAGE_DISCOVERY_EXECUTION.md` for 15 real additional executable domain-language subsets, limits, commands, and evidence. v3.9 and earlier source is retained.

# USL Universal Systems v3.9.0 — Whole-Specification Semantic Qualification Framework

New versioned standard-coverage acceptance contract, 606-entry semantic evidence ledger, source-pinned differential conformance corpus, native syntax negative tests, and bounded Python-to-JavaScript compatibility proof. **The 606 whole specifications are NOT yet complete.** See `docs/FULL_LANGUAGE_SEMANTIC_COMPLETENESS_STANDARD.md` and `MASTER_SEMANTIC_COMPLETION_PROMPT.md`.

# USL Universal Systems v3.8.0 — Compiler/Bridge Registry Expansion

**Latest verified development release (Linux).** Reviewed, hash-checked guest adapter manifests extend the existing USL central bridge without replacing it. New real installed adapter subsets: Tcl, Lua (texlua), GNU Make and CMake. The native executable 606×606 matrix has **401 observed successful supported pairs** and **366,835 unverified pairs**, with no conditional eligible pair left untested in this host's current subset. Twenty nested stages return **57,601**. No entry has been proven to implement every operation in its language specification.

Run `RUN_UNIVERSAL_ADAPTERS.bat` (reviewed adapters), `RUN_UNIVERSAL_COMPILER_MATRIX.bat` (all installed eligible host→guest pairs), or `RUN_TWENTY_LANGUAGE_NESTING.bat` (20-stage example). Tests: `RUN_TESTS.bat`. Full evidence: `docs/V3.8_UNIVERSAL_COMPILER_REGISTRY_REPORT.md` and `test_results/v3.8.0_*.json`.

Native guest code executes with the caller's permissions: **do not run untrusted source without external OS isolation.** Original recovered sources and user data are preserved. Windows/device behavior requires qualification on the target machine.

---

# USL Universal Systems v3.7.0 — Executable 606×606 Matrix + N×M Language Workers

**Current development release.** Real tested 18-environment/19-node language graph,
17 foreign catalog execution subsets plus portable USL, per-catalog 606-entry
qualification, 257 actual typed host→guest probes, 367,236-cell routing matrix
with true executed/conditional/unverified statuses, and cooperation through
the existing partial-worker scheduler. See `docs/V3.7_EXECUTABLE_MATRIX_REPORT.md`.

# USL Universal Systems v3.6.0 — Fifteen Executable Engines

# USL Universal Systems v3.6 — Fifteen Actual Language/Engine Execution Stages

From verified v3.5, USL now invokes a compiled C++ shared-library function
using an explicit `extern "C"` ABI and a Bash shell function through parameterized
arguments. The C++ function runs in a separate child process through the
existing ctypes ABI bridge; Bash is a real installed shell with declared
`i64/bool/text` arguments/returns. Both require explicit execution approval.

## Demonstration

`examples/nested_fifteen_languages.uslnest.json` runs:
Python → JavaScript → SQLite → Ruby → PHP → Go → Java → TypeScript → Perl
→ Swift → Kotlin → Bash → C++ → compiled C → USL.

Expected final result **19,601**. Each stage reports its exact source SHA-256,
value hash, ABI transport mode and observed execution evidence. Full report:
`test_results/v3.6.0_fifteen_native.json`.

## What the 606 catalog means

`tools/qualify_606_runtime_coverage.py` generates
`test_results/v3.6.0_606_runtime_qualification.json`. The 606 syntax catalog
is complete as an *inventory*. Fourteen foreign source/runtime families in the
executed example have demonstrated **bounded subset programs**; the other
592 catalog entries do not have guest execution proof here. The USL interpreter
is an additional fifteenth execution engine and not one of the Pygments-based
606 syntax entries. A separate sparse matrix tracks **367,236 conditional
ordered pairs**; it does not assert they were all executed successfully.

These 14 guest adapters do not represent 14 fully implemented programming
languages either. Source grammar, runtime libraries, exceptions, concurrency,
mutable handles, import features and platform semantics remain partial.
Markup, stylesheet and configuration formats need appropriate parse/validate/
render behavior rather than fabricated native executables.

## Status

End-to-end tests and security rejection cases are under `tests/test_v36_*.py`.
Windows native runtime qualification, full Shadow/Ollama, Chrome real extension,
EmoVision live camera, GPU acceleration and Meta physical hardware remain
pending. Guest code runs with process isolation, not an OS security sandbox.

# USL Universal Systems v3.5.0 — Native Build Cache

# USL v3.5 — Integrity-checked native build reuse

Extends v3.4, preserving full source, the six original archives, complete
existing runtime and 606-entry catalog. Adds `usl_systems/native_build_cache.py`
with source, generated ABI wrapper, compiler executable metadata, build flags,
platform and Python ABI included in SHA-256 cache keys. TypeScript and Kotlin
adapters can restore unchanged verified compiled artifacts; they **always run
and validate the current guest** and do not treat cache hits as task success.

Cache directory is persistent user data (`USL_NATIVE_CACHE_ROOT` if configured,
otherwise USL user data/native_build_cache), not a disposable release folder.
Cache entry manifests contain a SHA-256 artifact hash. Corrupted, mismatched,
source-edited or toolchain-changed entries are rejected or cause recompilation.
Writer locking avoids torn cache entries. Native guest execution remains
explicitly approval-controlled and is **not sandboxed**.

## Observed environment-specific benchmark

From fresh temporary caches, one cold call followed by three warm calls with
verified output in the local Linux test container:

- TypeScript: cold end-to-end 1597.035 ms; median warm 25.745 ms.
- Kotlin: cold end-to-end 5256.355 ms; median warm 72.429 ms.

These are four-sample observations, not general performance guarantees, and
measure a very small guest function where compiler startup dominates cold runs.
Check `test_results/v3.5.0_native_cache_benchmark.json` for actual per-call
build/run measurements and verified values. Measurements do not imply speedup
for large running applications or workloads where compilation is amortized.

The 606 catalog entries remain capability records; no new languages are
fully semantically compiled by caching. Windows performance and device
integration remain unverified here.

# USL Universal Systems v3.4.0 — Structured Bridge ABI and Node Callbacks

# USL v3.4 — Structure-preserving ABI and active JavaScript callbacks

Extends the same nested bridge architecture, without a second compiler. The
versioned ABI now accepts bounded `optional<T>`, `list<T>`, and
`record{field:T,...}` type contracts, in addition to the original scalar/i64[]
contracts. Parser and verifier reject unknown identifiers, recursive depth
violations, duplicate record fields, wrong type, missing or additional keys,
malformed UTF-8 encodings, oversized payloads and i64 outside its declared
signed 64-bit range. Nested Python→JavaScript and compiled TypeScript record
calls have been executed through their actual runtimes.

The live Python↔USL callback protocol now also works with JavaScript/Node.js
as guest: a real running Node process waits for the result of a bounded USL
callback before returning. Callback sessions are explicitly approved, limited
by declared signature, count and deadline, and terminated on failure. See
`tests/test_v34_structural_abi_node_callbacks.py`.

Examples: `examples/nested_structured_abi.json` and
`examples/nested_callback_bridge.json`.

Unresolved: complete ABI ownership/GC across runtimes, full semantic imports,
all 606 program grammar compilers, safe isolation of untrusted guest source,
production hardware/GPU/Meta integration. Current adapters implement only
qualified type/operation subsets.

# USL Universal Systems v3.3.0 — Live Bidirectional Callbacks

# v3.3.0 — Live Python guest ↔ USL runtime callback protocol

Adds a real, stateful, bidirectional callback mechanism to the existing nested
DAG. A Python guest function executes in one child process, issues a typed
line-delimited JSON callback, the parent verifies the declared callback
contract and invokes a bounded USL function, then the original Python guest
process receives the response and continues. The callback uses **the same
running child process**, not staged source generation masquerading as a call.

The caller must explicitly approve executing foreign guest source. USL callback
exports, type bounds, named function, maximum call count (1..8), and total
process deadline are checked. Unknown exports, ABI errors, faulty guest code,
reentrancy beyond the declared limit, and timeouts fail the corresponding DAG
node and block descendants. On exit or failure, child process groups are
terminated when still active, with captured evidence.

Verification demo `examples/nested_callback_bridge.json`:
Node.js output 11 → original Python guest invokes USL `twice` and receives 22,
returns 24 → compiled C squares to **576**. Inspect
`test_results/v3.3.0_callback_demo.json`.

**Important security limitation:** this is process isolation and a bounded
protocol, not a system sandbox for arbitrary third-party Python code. Use a
restricted OS user/container for untrusted source. Callback support is currently
qualified for Python guest ↔ USL runtime. Other host languages remain open.

The original 606 catalog is preserved, with observed routes separately
recorded from speculative eligibility. Windows, GPU, camera and physical
model/device qualifications remain explicitly pending.

# USL Universal Systems v3.2.0 — Thirteen-Language Bridge

# USL 3.2: TypeScript and Kotlin guest execution

Extends v3.1 with two installed native/managed compilation pipelines:
`tsc` -> CommonJS -> Node, and `kotlinc` -> JVM executable JAR -> Java.
Both return typed USL ABI results with actual per-call compilation, output,
exit code and timings, and require explicit execution approval. These are
**trusted-source development adapters**, not sandboxes.

TypeScript supports i64, bool, text and i64[] under the safe JavaScript integer
range only. Values outside IEEE-754 safe integer range must not be represented
as exact `i64` values in that adapter. Kotlin currently supports i64 and bool.
Unsupported types, compiler failures, runtime errors, mismatched outputs and
missing toolchains are not counted as successful routes.

`examples/nested_thirteen_languages.uslnest.json` provides an end-to-end
Python->JavaScript->SQLite->Ruby->PHP->Go->Java->TypeScript->Perl->Swift->Kotlin->C->USL
sequence, finishing at 4226. Inspect `test_results/v3.2.0_thirteen_native.json`.

This advances tested source interoperability; it is not native compilation of
all 606 syntax families. Source imports into a typed USL IR remain restricted;
Windows, hardware, camera and full Shadow inference remain unqualified here.

# USL Universal Systems v3.1.0 — Eleven-Language Native Bridge

See `docs/V3.1_POLYGLOT_REPORT.md`.

# USL Universal Systems v3.0.0 — Go/JVM Native Bridge Expansion

# v3.0.0 — Go/JVM Native Bridge Expansion

Starting point v2.9 source. New modules: `usl_systems/polyglot_native.py`, `tests/test_v30_go_java_bridge.py`.

## Real capabilities
- `go` compiles and executes declared `package main` functions through installed `go build`, using typed JSON ABI for `i64`, `bool`, `text`, and `i64[]`.
- `java` compiles `Guest.java` and a generated `USLBridgeEntry.java` using `javac`, invokes Java using `java`, and marshals `i64`, `bool`, and `text` via bounded Base64 command arguments and JSON result.
- Both run in subprocesses; file content is **not sandboxed** and must be explicitly authorized.
- `examples/nested_nine_languages.uslnest.json`: Python→JavaScript→SQLite→Ruby→PHP→Go→Java→C→USL; expected output 2402.
- Native compiler failures and incompatible ABI contracts explicitly fail closed.

## Not implemented
- Full semantic import/compilation of 606 languages. Catalog contains identifiers; only tested adapters count as executable guest routes.
- Bidirectional in-process callbacks, ownership of mutable objects, general exception translation.
- Windows/Android physical testing, live Shadow/Ollama and physical Meta/EmoVision GPU testing.

## Evidence
Look under `test_results/v3.0.0_*`. Target qualification includes real Go and Java compilation/execution. Repeat on Windows using `RUN_NINE_LANGUAGE_NESTING.bat` after installing guest toolchains. Java wrapper uses bounded command arguments; Go wrappers use JSON stdin. Experimental adapters are not intended to safely execute untrusted input.

# USL Universal Systems v2.9.0 — Seven-Language Native Nesting

Adds Ruby and PHP typed native guest adapters to v2.8, now executing real Python → JavaScript → SQLite → Ruby → PHP → compiled C → USL calls in a single dependency graph. See `docs/V2.9_POLYGLOT_BRIDGE_REPORT.md` and `RUN_SEVEN_LANGUAGE_NESTING.bat`. Guest source requires explicit approval and is not sandboxed.

# USL Universal Systems v2.8.0 — Read-only SQLite Bridge and Five-language Nesting

Adds a typed, parameterized SQLite SELECT guest to v2.7; real Python → JavaScript → SQL → compiled C → USL execution passes ABI checks and expected outputs. Read `docs/V2.8_SQL_NATIVE_NESTING_REPORT.md` and run `RUN_FIVE_LANGUAGE_NESTING.bat`. Native arbitrary source is not securely sandboxed.

# USL Universal Systems v2.7.0 — Actual Nested-Language Native Bridge

A versioned `.uslnest.json` manifest composes trusted USL, Python, JavaScript, and compiled C source through a typed ABI and verified execution graph, including a reverse Python-host-to-USL callable API. The catalog reports all 606 entries separately from supported native bridge routes. See `docs/V2.7_NATIVE_NESTING_REPORT.md`. Run `RUN_NATIVE_BRIDGES.bat`, `RUN_606_MATRIX.bat`, or `python -m usl_systems nested-run examples/nested_languages.uslnest.json --i-approve-native`. Foreign code execution is NOT an OS sandbox.

# USL Universal Systems v2.6.0 — Native Semantic Compatibility Shims

Extends the v2.5 universal compiler route with **native boolean display compatibility** for Python, JavaScript, Ruby, PHP, Go, Java, C++ and C, all tested against the reference interpreter. A mismatched `None`/`null` representation still routes to the compatible VM instead of being counted as equivalent. Run `RUN_BOOLEAN_COMPATIBILITY.bat`; see `docs/V2.6_RELEASE_REPORT.md`.

# USL Universal Systems v2.5.0 — Universal Semantic Route / Collapse Success All

A unified USL semantic IR feeds proven native emitters or a portable compatibility runtime. The **Collapse Success All** planner concurrently probes authorized installed backends, compares actual stdout with the USL reference, records elapsed cost and diagnostics, and selects the fastest observed valid candidate for that source. New cooperative tasks allow independent semantic workers to share evidence. Target catalog labels (606) are addressable but not necessarily native executable languages. See `docs/UNIVERSAL_SEMANTIC_COLLAPSE.md`.

**Try:** `RUN_UNIVERSAL_COLLAPSE.bat`; or `python -m usl_systems universal-export examples/universal_semantic.usl --target json --output portable.zip` to export a self-contained Python 3 semantic runtime package. Native probes require explicit approval.

# USL Universal Systems v2.4.0 — Multidimensional Array Contracts

Adds bounded static two- and three-dimensional array shapes in closed-world module signatures and native-verified nested indexing. Run `RUN_NESTED_ARRAY_TESTS.bat`, see `docs/V2.4_RELEASE_REPORT.md`. This remains a restricted static analysis subset; complete language compilation and physical Windows/hardware validation are not established.

# USL Universal Systems v2.3.0 — Bounded Cooperative Work Scheduling

New optional `--max-in-flight N` for `python -m usl_systems cooperate` and task `priority` 0..100. Scheduler applies strict admission limits, dispatches ready higher-priority work before lower-priority work, and checks cancellation while active work continues. See `docs/V2.3_RELEASE_REPORT.md`. Does not preempt running OS subprocesses.

# USL Universal Systems v2.2.0 — Typed Array Contract Qualification

Native-qualified closed-world array contracts for module functions, with verified interpreter/native behavior and negative tests. Run `RUN_ARRAY_CONTRACT_TESTS.bat`. See `docs/V2.2_RELEASE_REPORT.md`. Existing systems remain preserved. Hardware and full 606 semantics remain unverified.

# USL Universal Systems v1.9.0 — Verified modular semantics development release

**Latest verified capabilities:** 606 syntax-family descriptors (not 606 compilers), 13 restricted native syntax/static frontends, dependency-checked closed-world modules, explicit source-bound function contracts, conservative scalar/array type diagnostics, exact array-index native qualifications, the previous USL compiler/runtime, compression and N×M scheduling engines, Shadow/Chrome/EmoVision recovered sources, and supervised autonomous repair foundations.

Quick start: `INSTALL_AND_START.bat` (Forge at `http://127.0.0.1:8772/`). New qualification tools: `RUN_SEMANTIC_PLUGIN_TESTS.bat`, `RUN_MODULE_QUALIFICATION.bat`, `RUN_TYPE_QUALIFICATION.bat`, `RUN_CONTRACT_TESTS.bat`. The full suite is `RUN_TESTS.bat`. Release integrity: `VERIFY_RELEASE.bat`.

**Hardware caveat:** Real Windows desktop control, live user Ollama/voice, Chrome extension, camera, smart glasses, and GPU compute are NOT validated by these Linux test runs. Full 606-language semantic compilation remains unfinished. See `docs/V1.9_RELEASE_REPORT.md` and `NEXT_ITERATION_PROMPT.md`.

---

# USL Universal Systems v1.5.0 — Native semantic holdout qualification

Adds 7 installed toolchain syntax-check adapters to prior v1.2 features. See docs/V1.3_RELEASE_REPORT.md.

# USL Universal Systems v1.2.0 — Shadow bounded streaming and cancellation

Real local-model response streaming with explicit cancellation and truthful persisted status. Includes all original v1.1 and legacy source components. Tested against an emulated Ollama HTTP server; user-installed Ollama/microphone unverified. See docs/V1.2_RELEASE_REPORT.md.

# USL Universal Systems v1.1.0 — Observe/Repair/Continue

The release retains all v1.0.0 components and six recovered source archives.
New: real monitored subprocess compiler observation with captured exit status, explicit repair approval, staged source edits, hash checks, durable once-only observation consumption, and monitored unit-test continuation. Real Windows qualification is still pending. See `docs/V1.1_RELEASE_REPORT.md`.

**Run:** `INSTALL_AND_START.bat`. Test: `RUN_TESTS.bat`. Demonstrate: `RUN_OBSERVED_REPAIR_DEMO.bat`. Generate next prompt: `PLAN_NEXT_ITERATION.bat`.

# USL Universal Systems v1.0.0

Now also provides compiler-grounded, draft-only Python repair proposals and explicit approval-driven staged validation. See `docs/V1.0_RELEASE_REPORT.md`, `NEXT_ITERATION_PROMPT.md`, `docs/ITERATION_BACKLOG.json`. Run `RUN_DIAGNOSE_REPAIR_DEMO.bat` for a real local test/repair demo. This release is not a full master-architecture completion.

# USL UNIVERSAL SYSTEMS v0.8.0 — Incremental integrated release

**v0.8 additions:** durable Shadow sessions, actual Ollama `/api/chat` HTTP protocol adapter, approved Chrome V3 automation cycles with independent completion gates, real CPU multiprocessing reductions and adaptive comparisons. For precise evidence, safety boundaries, limitations and verification commands, see `docs/V0.8_RELEASE_REPORT.md`.

**The system is not yet a complete 606-language compiler suite or a fully autonomous Windows/Meta/EmoVision operating system.** Both facts are tracked explicitly. All six recovered component archives are included unchanged.

# USL UNIVERSAL SYSTEMS — v0.8.0: Verified Browser Cycles and Shadow Sessions

This is a continuation of v0.7.0, with the previous six recovered source archives preserved.

**Verified in this environment:** 180 automated tests passed in a full Linux regression run. Browser cycle tests use a real local recovered Chrome Bridge process with authenticated calls; they do **not** prove full Windows/Chrome UI automation or live user browser control. Model adapter tests use a local HTTP test server and are **not** evidence that a real installed Ollama model was queried. CPU multiprocessing tests compare outcomes against serial references; hardware GPU validation is still pending.

**Added:** persistent Shadow conversation sessions with recoverable interrupted turns; authentication-protected browser cycle arming and correlation with fresh verified reports; conservative failure states, timeout and cancellation behavior; CPU multiprocessing adaptive workload measurement. Unauthorized/replayed/stale reports do not count as success.

**Quick start:** On Windows, extract the flat ZIP to a new folder, run `VERIFY_RELEASE.bat`, then `INSTALL_AND_START.bat`. Open http://127.0.0.1:8772/. Run `RUN_TESTS.bat` for host-specific regression checks. Keep existing installations and user data intact.

**Remaining major work:** broad semantic compilation beyond limited emitters for the 606 syntax families; Windows desktop end-to-end control; live local LLM/voice use; live EmoVision camera and Meta glasses validation; real GPU scheduling; full agent-driven self-development.

---

# USL UNIVERSAL SYSTEMS — v0.7.0: Verified Dataflow and Syntax Qualification

**Complete v0.6 source continuation, with all six recovered archives retained.**

This release adds stable dependency ordering for approved autonomous tasks, strictly typed result-to-step bindings, safe checkpoint resume, syntax validators for 7 catalog entries plus JSON Lines, and an authenticated read-only Chrome Bridge V3 report observer that cannot silently claim a task succeeded.

**To start on Windows:** Extract this ZIP into a new directory; double-click `VERIFY_RELEASE.bat`, then `INSTALL_AND_START.bat`. Use `RUN_TESTS.bat` and `RUN_INTEGRATION_TESTS.bat` for checks. Visit `http://127.0.0.1:8772/` after launch.

**Try:** `python -m usl_systems syntax-validate examples/syntax_example.json --language json` or open Languages → Real Syntax Parsers. See `examples/autonomy_bound_dag.uslauto.json` and `docs/V0.7_RELEASE_REPORT.md`.

**Scope:** 606 syntax families recognized; 13 restricted emitters; qualified native tests cover a subset only. None of the 606 has been demonstrated as a complete semantic compiler. Research formulas, GPU acceleration, actual Windows, camera, microphone, and smart-glasses capabilities have separate verification requirements.

---

# USL UNIVERSAL SYSTEMS — v0.6.0: Approved Autonomous Execution

**Full source release built on v0.5.0, not a replacement mockup.**

New: a durable autonomous execution controller that accepts validated `uslauto-1` plans, requires an owner control-token approval, executes real supported steps, evaluates deterministic assertions, records all outcomes in SQLite, refuses to continue after failures, and supports explicit recovery of safe tasks after process interruptions.

- **Autonomy GUI:** review, approve, start/resume, cancel, inspect proof and history.
- **Shadow plan proposal:** optional local Ollama produces a constrained draft; model output is untrusted, never approves itself, and never runs external programs without separate owner approval.
- **Integrated steps:** bounded USL, compilation, native verification, 57-entry equations, SHA-256 exact compression, N×M factored workers, incremental H0/H1/H2 processing, dimensionless placement, saved USL Fabric workflows, Chrome Bridge V3 status, Shadow V87 SDK health, EmoVision V63 health, optional local model chat, and approved monitored child processes.
- **Restart policy:** pure work may be resumed after an interruption, but external process/model calls are placed into `needs_review` and are not automatically replayed.
- **Original source preservation:** full previous 606-language syntax catalog, 13 restricted emitters, six original recovered ZIPs, README history, install scripts, and previous research test reports remain included.

**Quick start:** extract the single flat release ZIP; run `INSTALL_AND_START.bat`; open `http://127.0.0.1:8772/` and select **Autonomy**. The private approval token is created in the persistent data folder (find the path on the System page) as `control_token`.

**No-Ollama proof:** run `RUN_AUTONOMY_DEMO.bat`, or `python examples/run_autonomy_demo.py` on Linux. See `docs/AUTONOMOUS_EXECUTION.md` and `examples/autonomy_*.uslauto.json`.

**Limits:** 606 catalog entries are not 606 complete semantic compilers. Chrome Bridge health is not general desktop control. Shadow/EmoVision health is not camera, audio, or AI inference verification. The Windows installation, real target hardware, and full autonomous multi-application loop have not been validated from this Linux environment. A native child process is not sandboxed: execute only trusted, approved commands.

---

# USL UNIVERSAL SYSTEMS — v0.5.0 Algorithms, Equations and Verified Work Fabric

**Current release:** research/platform release built on v0.4. Includes the six SHA-256-verified recovered-source archives and all previous compiler/bridge/Shadow/EmoVision integration interfaces. It adds genuine runnable algorithm libraries, rather than only listing proposed capabilities.

### New v0.5 features

- **Compression Success All:** exact raw/zlib/reference delta/duplicate/partial candidates, proof-gated selection, immutable SHA-256 CAS and measurements.
- **N×M factored fractal workers:** real bounded threadpool, recursively split disjoint work, dimensionless service coordinates, identical-work reuse and exact serial references.
- **H0/H1/H2 incremental processing:** full exact evaluation, exact reuse and small-change algebraic updates. Baseline audits are optional and their overhead is reported.
- **Measured adaptive route selection:** benchmarks serial, synchronous factored and asynchronous factored execution; selects a verified fastest candidate instead of automatically assuming threads win.
- **M-dimensional service tensor planning:** estimated CPU/GPU/memory-capacity placement with fairness and conservation checks, not imaginary hardware.
- **Equation Atlas:** 57 categorized, source-annotated mathematical formulations and use cases; 41 finite scalar evaluators. Symbolic research entries stay marked as unvalidated. New reviewed expressions can be imported into a persistent, bounded JSON registry (see below).
- **Historical formula provenance:** 1,000 candidate text lines indexed from bundled legacy sources; candidates are explicitly not assumed to be valid formulae.
- **Forge GUI:** new Equation & Worker Lab; new CLI commands and verified-workflow kinds.

### Quick launch

On Windows, extract the *single flat release ZIP* and double-click **`INSTALL_AND_START.bat`**. Then open <http://127.0.0.1:8772/> and select **Equation & Worker Lab**. For native integration, use the existing recovered-source scripts from v0.4.

To import a reviewed mathematical expression without modifying application source:

```shell
python -m usl_systems equations-import examples/research/custom_equation_import.json
python -m usl_systems equations --id custom_oscillator_energy
python -m usl_systems flow examples/research_pipeline.uslflow.json
```

Imports remain marked **unverified user hypotheses** and cannot execute Python code, shell commands, or access files.

See `docs/EQUATION_ATLAS.md`, `docs/ALGORITHM_EXPANSION.md`, `docs/INTEGRATION_MIGRATION.md`, and `test_results/` for precise validation and limits.

---

## Preserved v0.4 architecture and historical notes

# USL UNIVERSAL SYSTEMS — v0.4.0 Source-Integrated Research Release

**A tested development foundation, not completion of the full master architecture.** This release preserves v0.2 functionality and adds a versioned semantic intermediate representation (IR), native compiler conformance, fixed Go conditional emission, restricted integer functions for C/C++/Go/Java (plus generated Rust/C#), read-only discovery of existing USL/Shadow/EmoVision installations, new dashboard views, an actual RK4 numerical solver, and optional image inspection.

## v0.4 recovered-source integrations

The original USL V0.31 native compiler, Chrome Bridge V3 (plus V2.2.1 baseline), Shadow V87 SDK, EmoVision V63 HTTP server and Android Meta V53 source are now **included and SHA-256 verified** under `legacy_sources/`. They are safely staged to persistent user data at launch, not silently executed. Real tests confirmed V0.31 native compilation, a token-authenticated Chrome Bridge V3 handshake, and the original Shadow/EmoVision API handlers with synthetic model/sensor state. See `docs/INTEGRATION_MIGRATION.md` for precise capability boundaries and port collision mitigation.

### One-command Windows start

Double-click `INSTALL_AND_START.bat`; recovered sources stage automatically. Open Forge > Integrations to see full sources and pairing status. To start the actual recovered Chrome Bridge V3 in a separate window, double-click `START_CHROME_BRIDGE_V3.bat`. To run a trusted native integer compiler demo, use `RUN_RECOVERED_NATIVE_DEMO.bat` after installing GCC.

**This is not 606 complete semantic compilers and is not yet an entirely autonomous operating system.** The platform indexes 606 syntax families but retains 13 restricted source emitters; production-grade source-specific parsers, runtime semantics and equivalence tests remain outstanding. Live Windows, microphone, glasses, and GPU testing require the actual devices.

## Windows — install and start

1. Extract this single ZIP into a directory on any drive (there is no nested wrapper directory).
2. Double-click **`INSTALL_AND_START.bat`** (requires Python 3.10+). Nothing is automatically overwritten in older USL installations.
3. Open **http://127.0.0.1:8772/**, then use Forge, Shadow, Languages, Integrations, and Process Bridge.
4. To find previous Windows projects: run **`SCAN_LEGACY_INSTALLS.bat`**. To compare native backend output: **`RUN_COMPILER_QUALIFICATION.bat`**. To run all regression tests: **`RUN_TESTS.bat`**.
5. Stop with **`STOP.bat`** or Ctrl+C. User state stays in `%LOCALAPPDATA%\USL_Universal_Systems`.

The core uses only Python's standard library. Optional local Ollama is required for Shadow AI code generation, native target compilers are required for code execution comparisons, and Pillow is optional for image inspection.

## What works (and what the 606 count means)

- **606 catalogued lexer/syntax families** in the offline metadata inventory. This includes configuration, markup and overlapping syntax families; it is NOT 606 runnable semantic compilers.
- **13 built-in, restricted AST-based source emitters**: Python, JavaScript, TypeScript, Ruby, Lua, PHP, Go, Java, C++, C, C#, Rust, PowerShell. Emission supports a limited common semantic subset; unsupported constructs fail explicitly. It is not full language coverage.
- **Versioned semantic IR**: JSON tree derived from checked USL input, integrity hash, reconstructable AST, conservative diagnostics and native backend generation. The IR is a foundation for additional target semantics rather than invented compiler implementations.
- **Native equivalence**: 5 independent tests for each supported emitter. In the build environment, Python, JavaScript, Ruby, PHP, Go, Java, C++, and C each passed **5/5**. The five other emitters had no available native runtime/compiler and were unverified.
- **All-catalog language access**: detect extension, browse entry, configure an opt-in external native command for a given language/syntax, and package existing source. Optional Ollama drafting for any named catalog entry remains explicitly unverified; some formats cannot express programs.
- **Forge**: local IDE, `.usl` execution, save/load, inspect semantic IR, restricted code emitters, native checks, source packaging.
- **Shadow**: local Ollama connection, bounded code generation, local model multi-role Swarm. Live Ollama was unavailable in the build environment.
- **Fabric**: SQLite journal, memoization, dependency-graph workflows and bounded parallel scheduling. GPU discovery is informational only, not GPU execution.
- **Process Bridge**: secure-token-gated launch, live stdout/stderr, exit codes, timeouts, stop, bounded history, restarts marked interrupted. Only authorized children launched by this component can be monitored.
- **Legacy Installations**: read-only directory evidence scanning for USL V0.31, Chrome Bridge, Shadow, EmoVision. Does **not** attach to arbitrary Windows processes, merge old source, or establish protocol compatibility. These integrations still need the original source/service protocols and Windows hardware for validation.
- **Scientific baseline**: classical RK4 decay with analytic-reference error, plus linear mass-spring-damper solver. No claims of BEC/H70/kagome material breakthroughs.
- **Vision baseline**: optional local Pillow image decoding and luminance histogram; no object detector, live camera, Android integration or device inference.

## Commands

Run from the extracted directory. On Windows, use `py -3` instead of `python` when appropriate.

```sh
python -m usl_systems serve
python -m usl_systems doctor --json
python -m usl_systems catalog --search cobol
python -m usl_systems detect example.rs
python -m usl_systems ir examples/functions.usl --output program.uslir.json
python -m usl_systems run examples/hello.usl
python -m usl_systems transpile examples/hello.usl --target go --output main.go
python -m usl_systems verify examples/hello.usl --target javascript
python -m usl_systems qualify --output conformance.json
python -m usl_systems integrations --probe-local-bridge
python -m usl_systems simulate decay --steps 200 --seconds 10
python -m usl_systems simulate damper --steps 400 --seconds 10
python -m usl_systems vision-inspect local_photo.png
python -m usl_systems flow examples/integrated.uslflow.json
python -m usl_systems native-info cobol
python -m usl_systems native-configure python '["{python}","{file}"]'
python -m usl_systems native-run python existing.py --i-allow-execution
python -m unittest discover -s tests -v
```

### Connect your previous Windows release folders

Discovery searches a small set of relevant top-level Windows folders. Set `USL_LEGACY_ROOTS` to a semicolon-separated list of exact legacy directories to check deeper roots, or pass a list to the CLI explicitly:

```bat
set "USL_LEGACY_ROOTS=D:\USL-V031-FULL-WINDOWS-INSTALLER-PORTABLE-TEST-FIX;D:\USL-CHROME-BRIDGE-V2.2.0;C:\EmoVision"
py -3 -m usl_systems integrations --probe-local-bridge
```

This reads directory names and candidate file paths, without running the found software. Chrome Bridge's port 8766 may be probed by a **read-only unauthenticated request**; a response confirms only HTTP presence and not actual connection. Importing source and operating the legacy systems require original files and tested, authorized adapters. See `docs/INTEGRATION_MIGRATION.md`.

## Verification

- 80 Python automated tests passing in the Linux container.
- 40 target-runtime conformance executions passing across eight installed targets (five per target).
- Live local HTTP service smoke verified `/api/health`, `/api/integrations`, `/api/compilers`, `/api/ir`, static GUI and authorized shutdown.
- Windows installation, Chrome extension pairing, native Windows V0.31 reuse, model inference, live camera, real GPU computations and physical materials **not verified here**.
- Core components are not a secure multi-tenant sandbox. All native executable execution is opt-in; do not run untrusted code. The web server must remain bound to loopback.

This release includes full source and regression tests. The 606 list is exhaustive **as a syntax inventory**, not as independently implemented semantic compilers. See `docs/V0.3_RELEASE_REPORT.md` for exact test evidence and `docs/SEMANTIC_COMPILATION.md` for the compiler architecture.

## v1.4 native syntax/typecheck additions
Six opt-in toolchain adapters: TypeScript, Swift, Fortran, Perl, Bash, and Kotlin. The existing seven remain. Toolchains accept **trusted source only**; compilers are not sandboxes and some may execute compile-time code. Fortran/Swift/TypeScript/Kotlin invoke static analysis, not executable semantic equivalence. Catalog recognizes 606 syntax families; no claim of 606 compilers. See `docs/V1.4_RELEASE_REPORT.md`.

## v1.5 verified semantic holdouts
Run `python tools/qualify_semantic_holdouts.py` to compare generated seeded `.usl` programs against actual available native runtimes; see the recorded evidence and `docs/V1.5_RELEASE_REPORT.md`. Full semantic compiler coverage for 606 families remains **unproven**.

## v2.0.0 — cooperative N×M engineering workers and interprocedural flow

**New executable controller**: `python -m usl_systems cooperate examples/cooperative_development.json --threads 3 --processes 2` or `RUN_COOPERATIVE_WORKERS.bat`. Independent module compilation checks, contract/static QA, bounded `.usl` interpretation, exact compression, and a separate N×M OS process worker execute as a dependency-aware graph and share only verified results. Results can be reused from an integrity-checked checkpoint; any changed graph invalidates reuse. Run `RUN_COOPERATIVE_QUALIFICATION.bat` for actual evidence. See `docs/COOPERATIVE_WORKERS.md`.

**Compiler progress**: `module_contracts.validate_contracts` now conservatively joins variable type information across both branches and invalidates loop-mutated type assumptions before interprocedural call checking. Unknown types remain unproven; no full language type soundness is claimed. New regression tests are `test_v20_cooperative_workers.py` and `test_v20_interprocedural_flow.py`.

**Not qualified**: Real Windows application control, live Ollama/voice, Chrome extension roundtrip, hardware GPU/EmoVision/Meta, full 606 semantic compilers, arbitrary USL language module semantics, and unfettered dynamic agent self-modification remain open.

## v2.1.0 — Cooperative native verification and cancellation

The worker graph can execute four independent native-language qualification branches concurrently after a single `.usl` module-link step. Run `RUN_COOPERATIVE_NATIVE.bat` to opt into Python, JavaScript, Ruby, and PHP native execution, requiring those runtimes locally. Their verified outputs are consolidated as an evidence digest. Results from native runs are deliberately not replayed from a checkpoint cache. The Python scheduler also accepts `cancel_event`, which stops **pending** work only, without pretending it can interrupt an already-running child. See `docs/COOPERATIVE_NATIVE_AND_CANCEL.md`.

## v3.7 GNU Fortran native bridge

Includes real GNU Fortran `bind(C)` compiled guest through the existing isolated `ctypes` C-ABI worker, 16-engine actual nested demonstration (`RUN_SIXTEEN_LANGUAGE_NESTING.bat`), per-entry runtime evidence and negative tests. **Not 606 complete native compilers.** See `docs/V3.7_FORTRAN_BRIDGE.md`.

## v4.1 — shared-family expansion and Collapse Success All qualification

This release adds **17 new real-engine executable subsets** with positive and
negative tests, integrates their execution into the existing `CooperativeScheduler`,
and preserves a 606-entry evidence-first development plan. Their outputs are
reused in actual USL execution, and a typed artifact handoff matrix is tested.
Cython compiled artifacts reuse USL's verified native build cache and still
execute guest code on each call. This does **not** mean full semantics for the
53 tested catalog subsets, nor automatic compilation of 606 complete languages.
See `docs/V4.1_COLLAPSE_EXPANSION_REPORT.md` and `NEXT_ITERATION_PROMPT.md`.
