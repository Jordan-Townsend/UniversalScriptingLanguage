# Continue USL from v4.2

Preserve every earlier module, the six recovered archives, original v4.1 ZIP, fixture evidence and persistent user data. Read docs/V4.2_BUILD_STATUS.md, docs/V4.2_GRAMMAR_CONTRACTS.json and test_results/v4.2.0_606_coverage.json first.

Current evidence is 71/606 language-family subsets, including 18 new general-source engine entries. Complete specification qualification remains zero. Opaque native-source IR and typed JSON transport do not establish general semantic translation. The .usl application consumes real source and compiled/queried artifacts through the existing scheduler and interpreter.

Next useful work:

1. Select exact unqualified entries from docs/ITERATION_BACKLOG.json, discover authoritative versioned engines and add at least ten independently tested entries where real tools are available. Reuse source_engines, semantic plugins and the scheduler. Record blocked engines explicitly.
2. Expand formal feature and standard-chapter coverage for existing entries: types, exceptions, numerical and Unicode boundaries, imports, callbacks, async/streams, ownership and side effects. full_spec_qualified requires complete version-specific evidence, rather than an installed parser or successful fixtures.
3. Lower supported foreign AST features into typed USL semantics with accurate source maps and qualify real native host/guest ABI calls. Keep source preservation, JSON handoffs, historical pair tests and newly executed source pairs distinct.
4. Extend useful .usl applications using verified runtime outputs, measured adaptive routes and existing BuildCache, Collapse, FactoredFractal and Store components. Never replay native execution as current success; run and verify the selected route.
5. Continue Windows, Shadow/Ollama voice, Chrome Bridge, camera/EmoVision/Meta, GPU, mesh/telescope and missing Ghostshell/Nexus assets only with actual services, protocols and hardware. Do not fabricate integrations.

Rerun all current modules and available native compiler cases; preserve skips and missing hardware separately. Run expanded positive/negative/boundary qualifications, the native .usl graph and typed matrix. Preserve exact outputs, source/runtime hashes and resource bounds. Generate a flat-root source ZIP, verify every member SHA-256 and the six recovered archives, then test a clean extraction. Testing another directory on the same Linux host does not validate Windows or a fresh cloud machine.
