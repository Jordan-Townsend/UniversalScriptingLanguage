@echo off
setlocal
pushd "%~dp0"
python -m usl_systems nested-run examples\nested_twenty_languages.uslnest.json --workers 8 --i-approve-native --output test_results\v3.8.0_twenty_language_chain.json
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%
