@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v35_native_build_cache.py -v
pause
