@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems nested-run examples\nested_languages.uslnest.json --i-approve-native) else (python -m usl_systems nested-run examples\nested_languages.uslnest.json --i-approve-native)
exit /b %errorlevel%
