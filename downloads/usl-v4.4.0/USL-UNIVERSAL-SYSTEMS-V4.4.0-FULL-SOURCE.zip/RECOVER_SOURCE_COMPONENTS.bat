@echo off
setlocal
cd /d "%~dp0"
echo Recovering and checking 6 historical full-source components...
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems recovered-stage all) else (python -m usl_systems recovered-stage all)
if errorlevel 1 (echo Recovery FAILED. & pause & exit /b 1)
echo Historical sources safely staged in user data. Original archives remain intact.
pause
endlocal
