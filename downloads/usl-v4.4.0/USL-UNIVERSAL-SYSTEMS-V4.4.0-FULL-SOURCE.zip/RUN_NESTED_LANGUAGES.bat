@echo off
call "%~dp0RUN_NATIVE_BRIDGES.bat"
