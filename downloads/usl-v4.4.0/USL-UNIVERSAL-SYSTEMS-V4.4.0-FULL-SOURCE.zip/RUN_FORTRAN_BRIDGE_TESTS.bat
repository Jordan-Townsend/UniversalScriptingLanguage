@echo off
setlocal
pushd "%~dp0"
python -m unittest discover -s tests -p test_v37_fortran_bridge.py -v
popd
pause
