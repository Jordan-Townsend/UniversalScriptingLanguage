# USL Cooperative Factored Partial Workers — v2.0.0

`usl_systems/cooperative_workers.py` orchestrates **real** threads and opt-in OS processes to execute a finite, dependency-checked graph of work across existing USL modules. It consumes `.usl` program text inside a USL module project and reuses the existing `fractal.FactoredFractal` engine. It does **not** change ChatGPT inference or create additional physical compute cores.

## Example (Windows)

Run `RUN_COOPERATIVE_WORKERS.bat` from the extracted project root, or:

```bat
python -m usl_systems cooperate examples\cooperative_development.json --threads 3 --processes 2 --checkpoint "%LOCALAPPDATA%\USL_UniversalSystems\cooperative_demo_checkpoint.json"
```

On Linux use forward slashes and a user-selected checkpoint path. Use `RUN_COOPERATIVE_QUALIFICATION.bat` or `python tools/qualify_cooperative.py` to run the real test project twice and record verified reuse.

## Worker cooperation

- **Module-link worker** links dependency-checked `.usl` modules, rejecting cycles and name conflicts.
- **Contract QA** inspects source-bound function contracts (including conservative branch/loop flow from v2).
- **Static QA** detects demonstrably invalid scalar/array operations.
- **Interpreter worker** runs the linked `.usl` program only after successful QA.
- **Compression worker** reuses the verified interpreter output and proves an exact round trip.
- **N×M fractal worker** runs separately in a spawned OS process using `FactoredFractal` (named dimensions are logical coordinates).
- **Integration worker** collects hashes of **all** required verified worker results into a content-addressed evidence digest.

Independent workers are submitted together; dependents wait. Failure blocks only downstream workers. All independent branches continue. Immutable verified partial results are reused on an identical graph if their own hashes and upstream specs match. A tampered result or changed graph invalidates reuse. Do not reuse native-execution results automatically.

## Execution and safety guarantees

The bounded graph allows **40 tasks**, up to **8 thread workers** and **4 spawned processes**, with up to 20 dependencies per task. It accepts known operations only; no arbitrary shell commands, imports, model execution, filesystem writes or general agent tool access are available through graph tasks. Native compilation/execution requires `--i-approve-native` and is never retrieved from the checkpoint cache. Structural bindings may only read explicitly declared upstream verified outputs. Checkpoint updates use atomic replace.

Per-task worker verifications are **bounded demonstrations**, not full language semantic soundness or third-party app autonomy. Process/thread timings include scheduling, startup and IPC; a real process is not necessarily faster. Job cancellation, distributed machines, dynamic subtask stealing, arbitrary AI agent collaboration, GPU kernels, and real Windows qualification remain future work.

## Developer interface

Python API:

```python
from usl_systems.cooperative_workers import CooperativeScheduler
report = CooperativeScheduler(threads=3,processes=2).run(graph,checkpoint='run-state.json')
assert report['all_verified'],report['blocked_or_failed']
```

`graph` is a JSON object with `schema: "usl.cooperative.graph.v1"` and `tasks`: each has `id`, `kind`, optional `deps`, `inputs`, `bind`, and `lane`. For a binding, `{"source":"link.linked_source"}` copies a source field from a **verified** dependency named `link` into the downstream worker's `source` input. `join_evidence` automatically combines the verified SHA-256 digests from all declared dependencies.
