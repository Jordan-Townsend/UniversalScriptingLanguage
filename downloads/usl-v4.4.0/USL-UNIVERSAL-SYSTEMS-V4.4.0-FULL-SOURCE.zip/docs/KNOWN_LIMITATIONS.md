# v0.4 source-integrated release boundaries

- All six recovered sources are shipped and SHA-256 verified. Staging and original SDK/API smoke tests do **not** constitute full platform integration or production certification.
- Actual USL V0.31 compiler executes trusted, restricted, typed USL programs through GCC; its grammar differs from the v0.3 interpreter, and no universal ABI bridge has been proven.
- Chrome Bridge V3 token-authenticated status works; fully automated browser-extension operation in a logged-in Windows browser is unverified.
- The real Shadow V87 SDK and EmoVision V63 HTTP handlers respond in mock-engine / mock-sensor tests; real Ollama, live conversation, sensors, Windows TTS and cameras are not demonstrated.
- Shadow's original SDK port and Chrome Bridge's port conflict at 8766; use 8767 for Shadow SDK. Shadow SDK and EmoVision V63 HTTP services lack authentication and must remain on loopback; the Forge UI only exposes sanitized status for Chrome Bridge.
- Meta Android V53 source is staged but no APK is built in this environment. Physical Meta glasses and related SDK permissions must be verified on an authorized device.
- Only 13 restricted emitters exist. The 606 count is a syntax inventory that includes non-programming syntaxes; **606 complete semantic compilers do not exist in this release**.
- This local system is not a security sandbox and native execution is opt-in. Do not run downloaded or untrusted code on your regular Windows account.
- Installer and integration scripts were not executed on Windows here; Linux tests do not establish Windows installation compatibility.

---

# v0.3 additional limitations

- The v0.3 semantic intermediate representation has roundtrip checks and basic name-resolution warnings; it does NOT establish arbitrary whole-language semantic equivalence for any of the 606 syntaxes.
- Legacy Windows installations are discovered by folder evidence only. No authenticated Chrome Bridge 2.2 handshake, native V0.31 ABI link, Shadow persistent-memory import or EmoVision Android/runtime integration is proven.
- RK4 solver models are classical numerical examples. Pillow image statistics do not constitute object detection or live computer vision.
- Native code and child processes remain outside a secure OS sandbox. Service is for local single-user development and must not be exposed publicly.
- The Windows launcher and actual Windows behavior remain untested in this environment.

---

# Known limitations — do not misrepresent these

1. **500+** refers to syntax recognition/metadata and optional native toolchain adapters, not full transpiler implementations. Catalog includes multiple lexers for some languages, markup, configuration formats and other syntaxes.
2. Source emitters support only a restricted common AST subset. Function definitions, container types, multi-argument printing and some operators vary by backend. An emitter's presence is not proof every legal USL program translates successfully.
3. Code generation by Ollama may not satisfy the user's intent; a successful USL execution proves only that the program ran without triggering the supported checks. A human review/acceptance test is still necessary.
4. Ollama is not provided and was not available for integration tests in this environment. Live AI inference remains unverified.
5. Windows installation scripts are supplied but Windows 10/11 install tests were not possible in this Linux environment.
6. Native source adapters execute user-provided programs outside a sandbox. They are opt-in for precisely that reason.
7. There is no authenticated multi-user system, service-account daemon, TLS server or remote access.
8. A restarted service marks unfinished asynchronous tasks interrupted. It does not transparently resume arbitrary subprocesses.
9. Full-breadth older code, unavailable to this sandbox, was not copied in, and previous program-specific states are not automatically migrated.
10. Pygments catalog metadata and any fetched legacy registries require appropriate licensing review for commercial redistribution.
11. Native verification compares standard output for a given program. It does not establish cross-language semantics for all possible inputs.
12. The interpreter prevents many unsafe expressions and limits work; it is not a formally verified sandbox. Use a container/VM for untrusted workloads.
13. Hardware acceleration, Emovision camera integration, real Chrome Bridge extension, robotics and experimental materials simulators are not present in v0.2.
14. App backend currently binds port 8772 by default; pass `--port` for conflicts. `STOP.bat` is built for the default port.
15. Generic native adapters require the user to supply and trust external compiler/runtime commands for languages without a built-in adapter.

16. The new process bridge observes only explicitly authorized child processes it launches; it does not read third-party application's consoles or inspect internal GUI state. It captures a 64 KiB tail, not full unlimited logs.
17. The Swarm roles are separate local-model calls through the same Ollama adapter, not concurrently training independent AI agents. Live Ollama testing was unavailable.
18. Bridge native execution is not sandboxed. CLI opt-in and a private service token are required; use only trusted executables and source files.
19. The process bridge does not attach to or recover OS child process handles after a service restart; interrupted runs are marked interrupted.
