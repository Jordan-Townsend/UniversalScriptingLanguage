# Evidence-driven fast iterations for USL

`NEXT_ITERATION_PROMPT.md` is generated deterministically from `docs/ITERATION_BACKLOG.json`.
It is an *instruction* and is **not automatically executed by the software**.

Each engineering session should:

1. Extract the previous verified flat ZIP to a fresh project directory, leaving original installations and user data intact.
2. Verify its SHA-256 manifest; rerun the complete regression suite and installed native qualifications.
3. Work on the highest-priority feasible backlog item. Use previously verified code rather than duplicating it.
4. Test real observed behavior on applicable devices, capture exit codes and console logs, and compare to authoritative reference implementations.
5. Keep separate result categories for parser recognition, type diagnostics, native code execution, and physical hardware qualification.
6. Generate a new backlog prompt using `PLAN_NEXT_ITERATION.bat` or `python tools/plan_next_iteration.py`.
7. Seal the archive only after its complete test gate passes via `python tools/build_next_release.py`; verify a clean extraction.

Logical N-dimensional fractal decomposition and exact USL collapse can avoid duplicate computation in eligible workloads; they cannot bypass required execution, toolchain evidence, hardware constraints, or change ChatGPT's inference engine.

External program changes remain approval-gated and must use recorded evidence and bounded retries.

The Linux test environment cannot verify the user's Windows GUI, Ollama microphone, physical Meta glasses, or uninstalled GPU toolchains. Preserve explicit blocks until verified on that hardware.
