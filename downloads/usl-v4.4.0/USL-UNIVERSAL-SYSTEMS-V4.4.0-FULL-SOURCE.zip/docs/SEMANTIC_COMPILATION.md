**v0.7 addition:** See `docs/V0.7_RELEASE_REPORT.md` for typed DAG bindings, read-only report observation and seven parser-backed syntax validators. Earlier capability claims remain scoped to the v0.6 test context.

# Semantic compilation design and evidence

## Why 606 != 606 compilers

`s​yntax_catalog.json` is 606 Pygments lexer/syntax-family descriptors. Some are executable programming languages, some are query, shell, or configuration languages, and some are markup or template syntaxes. Many names have different semantics (integer arithmetic, numerical overflow, scoping, type safety, memory, asynchronous execution, exception behavior, I/O, FFI, etc.). A lexer descriptor does not describe executable semantics.

## Implemented architecture

USL input -> normalize legacy syntax -> whitelisted parser -> semantic IR v1 (`usl_systems.ir`) -> specific target emitter (`usl_systems.compiler`) -> optional native compiler/runtime -> output equivalence (`usl_systems.native`) -> proof/status record (`usl_systems.qualification`).

The IR is a reconstructable AST with SHA-256 integrity, a stable schema, and basic name-resolution diagnostics. It is not an SSA IR, complete type checker, optimizer proof system or effect analysis. It is intentionally limited to the executable subset in `usl_systems.language`.

## Current target qualification

The `qualification.py` suite tests arithmetic, counted loops, branching, bounded integer functions and while loops. Test outcomes are saved to `test_results/compiler_qualification.json`. They are narrow concrete behavior tests; they do not imply complete equivalence across inputs or all legal programs.

Eight native runtimes in this build environment passed 5/5: Python, JavaScript, Ruby, PHP, Go, Java, C++ and C. The other five target emitters remained without installed toolchains. Code generation is marked separately from native verification.

## Extension contract for any target

1. Determine whether the catalog entry is an executable target, data format, query language, or syntax alias.
2. Obtain the target's language standard, grammar, type system, runtime and licensing obligations.
3. Implement a backend that explicitly declares supported USL constructs; reject everything else.
4. Add grammar-aware decoding and source maps; do not rely on token replacement.
5. Establish standard-library and FFI translations only when semantics match.
6. Provide an isolated build/runtime image or an explicitly authorized external toolchain.
7. Test golden outputs and behavior on diverse inputs, edge cases, failure paths, overflow, numeric precision, I/O and platform differences.
8. Gate release status by executed conformance evidence. Never market syntax recognition as full compilation.

`usl native-configure` provides a safe-by-default explicit no-shell argv registration contract, but **does not** automatically implement USL-to-target translation. A full compiler needs a backend and conformance evidence.
