# Architecture

```text
                       +-------------------------+
                       | Local browser / Forge   |
                       | 127.0.0.1:8772           |
                       +------------+------------+
                                    |
                         authenticated-by-loopback
                         JSON API + origin checks
                                    |
                +-------------------+-----------------+
                |  Engine: bounded task queue (3)      |
                |  durable SQLite task/event journal   |
                +---------+---------------+------------+
                          |               |
           +--------------+----+    +-----+---------------+
           | USL AST parser    |    | Shadow Ollama adapter |
           | safe interpreter  |    | AI build 3 retries    |
           | 13 source emitters|    | validated USL only    |
           +---------+---------+    +---------------------+
                     |
           +---------+-----------------------+
           | Native output verification      |
           | built-in command maps           |
           | subprocess actual toolchain     |
           +---------+-----------------------+
                     |
      +--------------+--------------------------+
      | 606 family static catalog; native argv  |
      | adapters for any catalogued syntax      |
      +-----------------------------------------+
      | USL Fabric: DAG executor, parallel task |
      | scheduling, caching, dependency errors  |
      +-----------------------------------------+
      | Project store + hashed .uslpack         |
      +-----------------------------------------+
```

## V0.2 additional execution routes

- **Process Bridge**: local private-control-token launch/stop → `subprocess.Popen` without shell → bounded stdout/stderr capture → SQLite process history → Process Bridge GUI and CLI inspection. Does not attach to arbitrary processes.
- **Multi-role Swarm**: Ollama architect inference → implementer inference → USL interpreter → parallel native verification → advisory reviewer inference → versioned project artifacts. One verified executable result is not proof of intent satisfaction.
- API launch and stop are token-protected; read-only process history is accessible only on the loopback-bound service.

## Architecture decisions

- Core is Python 3.10+ stdlib, so there is no pip-based first-run setup.
- GUI is local HTML/CSS/JS served by `ThreadingHTTPServer`, not an Electron app. It requires the service console to remain running.
- USL subset is Python-like syntax parsed into a whitelisted AST. Only known AST operations are evaluated by the interpreter. This is NOT arbitrary Python execution.
- Verified emitters map AST to concrete target syntax. They explicitly refuse unsupported constructs.
- Catalog is a static metadata snapshot from Pygments lexers (606 entries in build environment). Syntax recognition is independent of transpilation.
- The legacy registry import is additive metadata only; imported templates are not assumed correct.
- The AI writes executable USL, never executing unsanitized model-provided Python or shell commands. Supported native translations are verified separately.
- Task execution uses a bounded queue and SQLite persistent records. A restart marks unfinished tasks interrupted; no automatic resumption of arbitrary work.
- USL Flow runs independent tasks concurrently with dependent scheduling and cached run/transpile results. External side effects are never cached.

## Future architecture modules, not implemented

Chrome/native messaging bridge, arbitrary existing-process console observation, production AI agent governance, per-task permissions, GPU scheduling backends, ONNX, Emovision, scientific solvers and hardware runtimes require actual integration source, hardware, and testing.


## v0.3 additions

```text
USL source -- normalize + parse -- safe AST -- semantic IR v1
                                     |             |                                             |             |         -> SHA-256 + diagnostics
                                     |             -> 13 limited target emitters
                                     |                     -> native toolchains -> conformance evidence
                                     -> bounded USL interpreter

606 syntax metadata -> extensions/aliases -> user-configured native adapters
                   (not 606 semantic compiler implementations)

Integration discovery (read-only) -> separate evidence of USL V0.31,
Chrome Bridge 2.2, Shadow and EmoVision --> no merge or invocation without source and protocol

Optional independent tools: RK4 simlab, Pillow image inspection
```

The Integrations UI requests `/api/integrations`, which performs bounded read-only filesystem inspection. `/api/compilers` gives a separate capability profile for every catalog entry. `/api/ir` exposes the versioned semantic tree. None of these claim existing Windows installs have authenticated interoperability.
