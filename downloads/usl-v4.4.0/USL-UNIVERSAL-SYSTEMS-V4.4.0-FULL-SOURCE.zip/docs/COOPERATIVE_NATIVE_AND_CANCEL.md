# USL Cooperative Engineering v2.1 — Parallel Native QA and Cancellation

This extends v2.0's finite verified dependency graph. To demonstrate **actual concurrent native compiler/runtime verifications** against the same linked `.usl` source, run `RUN_COOPERATIVE_NATIVE.bat`. This is intentionally opt-in native execution and requires four locally installed target runtimes (Python, Node.js, Ruby, PHP). Missing providers must be reported, not simulated.

The graph in `examples/cooperative_native_targets.json` links the module once; four language-native verification tasks all depend on that verified source and execute concurrently in real operating-system child processes spawned by the existing native adapters. The fifth worker consolidates SHA-256 evidence only after the four checks succeed.

This verifies the *tested program and installed runtimes*, not general semantic equivalence of those languages. Nothing about the implementation accelerates ChatGPT model inference.

## Cancellation behavior

The Python API now supports a shared `threading.Event` named `cancel_event`:

```python
from threading import Event
from usl_systems.cooperative_workers import CooperativeScheduler
cancel = Event()
report = CooperativeScheduler(threads=4,processes=2).run(graph, cancel_event=cancel)
# Another authorized control thread may set cancel.set() during the run.
```

When the event is set, the coordinator marks **not yet dispatched** work as cancelled; tasks that were already executing are allowed to return, and no new dependent work is submitted. This is a safe scheduling stop, not arbitrary termination of external processes or a promise of instant cancellation. The report exposes `cancelled_pending_tasks` and per-task `status`.

## Qualification

`tests/test_v21_cooperation.py` checks real concurrent native subprocess verifications and rejects a cache shortcut: even when the USL source link is reused, native verifications **execute again** because the installed runtime or environment could have changed. It also tests cancellation both before start and during an executing task.

Remaining gaps: subtask reassignment/work-stealing, distributed machines, GPU kernels, dynamic agent source edits, system-level cross-application control, safely terminating already-running subprocess tasks, and production Windows qualification.
