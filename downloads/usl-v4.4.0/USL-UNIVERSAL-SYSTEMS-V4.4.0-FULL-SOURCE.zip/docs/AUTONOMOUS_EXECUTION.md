**v0.7 addition:** See `docs/V0.7_RELEASE_REPORT.md` for typed DAG bindings, read-only report observation and seven parser-backed syntax validators. Earlier capability claims remain scoped to the v0.6 test context.

# USL Autonomous Execution Controller — V0.6.0

## Purpose

The controller implements **observe → execute → verify → checkpoint → continue** for approved, bounded tasks. It does not assume that a local AI model can autonomously control the Windows desktop, that every program's console is readable, or that a successful service connection implies real camera/model functionality.

This is an incremental integration over the real V0.5 architecture. Existing full archives are unchanged.

## Run it on Windows

1. Run `INSTALL_AND_START.bat`, and open `http://127.0.0.1:8772/`.
2. Select **Autonomy**.
3. For approving and starting commands, paste the local control token from the **persistent user data directory** shown on the **System** page, filename `control_token`. This secret is not included in release ZIPs and is not transmitted to model providers.
4. Inspect/edit the JSON draft. Select **Create draft**, then **Approve exact plan**, then **Run / Resume**. This is deliberate: an AI proposal or a create request does not authorize execution.
5. See `examples/autonomy_verified.uslauto.json` and `examples/autonomy_research.uslauto.json` for genuine runnable plans.
6. Run `RUN_AUTONOMY_DEMO.bat` for real standalone tests that do not require Ollama or persistent-user-file modifications.

For local AI planning, start Ollama and use **Suggest draft**. A returned plan is explicitly *untrusted* and *not executed*. Generated plans may use only bounded operations, not arbitrary OS processes.

## Supported steps

| Type | Execution | Proof / restriction |
|---|---|---|
| `usl` | Bounded USL interpreter | Source hash, output, operations; optional deterministic output assertions |
| `compile` | Supported USL source emitter | Generated output hash, emitter tier; compilation is not semantic equivalence verification |
| `verify` | Actual native toolchain where available | `passed` result required; fails closed when toolchain unsupported |
| `equation` | Registered bounded numerical expression | Executable mathematical result, **not** experimental physics verification |
| `collapse` | Exact verified compression and optional reference reuse | SHA-256 plus reconstructed-byte equality |
| `fractal` | N×M logical partitioning and factored-worker computation | Runtime internal exact-reference check |
| `incremental` | H0/H1/H2 incremental operations | Optional full audit; report acknowledges cost |
| `resource_placement` | Dimensionless capacity-based scheduling estimate | Planned placement, not physical throughput guarantee |
| `fabric_flow` | Saved USL Fabric workflow within project directory | Workflow success, native tasks forcibly disabled |
| `bridge_health` | Authenticated recovered Chrome Bridge V3 status | Local pairing token required; no blanket OS control |
| `shadow_health` | Explicit Shadow V87 SDK handshake | Local SDK state only; not verified live inference |
| `emovision_health` | Explicit EmoVision V63 HTTP health | Service reachability only; not proof of camera or physical glasses |
| `model_chat` | Local Ollama call (only in approved user-authored plans) | Generated text is **not** evidence or deterministic proof |
| `process` | Authorized child process through monitored Process Bridge | Separate allow_process approval, exit code and bounded stdout; non-zero exit fails plan |

A plan is at most 32 steps and 150,000 encoded characters. A model-proposed plan is at most 8 steps, and cannot include `process`, `model_chat`, or `fabric_flow`.

## Persistent state and recovery semantics

- SQLite table `autonomous_runs` records original approved plan, current step index, outcomes, run state and current launched child.
- Every step commits a result, and verified failures block all subsequent steps.
- On service restart, an unfinished **pure/calculation** step is paused and may be explicitly resumed. It can recompute, but never automatically replays an OS action.
- An interrupted `process` or `model_chat` step is marked **needs_review**. No implicit process rerun.
- The controller is designed for **one active service process managing a given data directory**. Do not run a second service using the same data root.
- Cancellation occurs between steps, and attempts to stop an actively supervised child. Long-running native toolchains or local model calls may not be interruptible immediately.
- Exact same-step idempotency across arbitrary external programs is not guaranteed; the project refuses to claim it.

## Security and limitations

- Only loopback HTTP requests with the host/origin checks in `server.py` are supported.
- Mutating autonomy endpoints require the private control token. Do not expose port 8772, the token, or the persistent data directory to a public network.
- A Process Bridge launch is **not a sandbox**. Approved commands execute with your Windows user privileges; review every command carefully.
- A healthy Shadow/EmoVision service does not imply trained models, cameras or smart-glasses hardware are active.
- The 606 syntax-family registry is retained. Only 13 restricted code emitters are implemented, and native equivalence passes a defined subset on a toolchain-dependent basis.
- Equation catalog entries range from established formulas to research hypotheses. Mathematical evaluation is not an independent demonstration of exotic physical effects.

## API

Read-only: `GET /api/autonomy/runs`, `GET /api/autonomy/run?id=...`.

Mutating (header `X-USL-Control-Token` required):

- `POST /api/autonomy/create` `{ "plan": { ... } }`
- `POST /api/autonomy/propose` `{ "goal": "...", "model": "optional Ollama model" }`
- `POST /api/autonomy/approve` `{ "id": "...", "allow_process": false }`
- `POST /api/autonomy/start` `{ "id": "..." }`
- `POST /api/autonomy/cancel` `{ "id": "..." }`

Each API operation returns a JSON record. The browser never stores the control token on disk; you must supply it to approve an action.

## Verified testing

See `tests/test_autonomy.py` and `test_results/v0.6_linux_full.txt`. Tests include: exact approval state, rejected unauthenticated API mutation, sequential deterministic output, a real launched child process and output capture, nonzero process exit, crash state recovery, untrusted model proposal filtering, regression prevention, and mixed research steps. Windows-native execution and real microphone/camera/Ollama tests require the target machine.
