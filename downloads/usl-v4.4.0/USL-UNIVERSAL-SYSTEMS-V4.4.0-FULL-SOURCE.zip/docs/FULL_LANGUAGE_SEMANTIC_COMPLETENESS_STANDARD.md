# USL semantic completeness: acceptance contract v1 (v3.9 implementation)

## What "complete" can mean

A language is a **versioned standard/profile with specified behavior**, not simply a string ID or one source fixture. For an entry to be declared `conformance_qualified`, USL must identify the **exact language specification/version, dialect, supported extensions, target ABI, runtime/OS profile, standard-library surface and explicit exceptions**. The implemented semantics must satisfy that profile's relevant normative requirements. No finite test suite proves all possible executions of an arbitrary Turing-complete language. A useful engineering completion gate combines authoritative standard coverage, established upstream compiler/runtime conformance, differential tests, property/metamorphic tests, fuzzing, compatibility proofs for transformations, and documented exclusions.

`fully_executable` for a syntax family must be interpreted **by category**: a markup file is parsed/validated and serialized, a SQL dialect is prepared/executed by a database engine, a shader is compiled and executed on a qualifying device, a hardware description is elaborated/simulated/synthesized by an appropriate toolchain, and an ordinary program is compiled/interpreted/run. It is incorrect to demand a conventional program entry point for every Pygments lexer in the historical 606 catalog.

## Required per-entry gates (none may be omitted)

1. **Identity:** unique catalog ID; actual language family; version and dialect; normative standard/specification and its origin/licensing.
2. **Grammar:** lexical rules, parser and AST; errors and recovery; imports, tokens, contexts, preprocessor/macro semantics.
3. **Static semantics:** symbol tables, scopes, types, overloads, generics, contracts, mutability and module systems as applicable.
4. **Dynamic semantics:** evaluation order, functions, recursion, closures, exception propagation, object identity, copy/reference semantics, observable I/O.
5. **Numbers and data:** signed/unsigned overflow, rounding modes, float/NaN, big integers, encodings, Unicode code points/code units/bytes, N-D records/arrays and ownership.
6. **Concurrency:** threads, tasks, coroutines, cancellation, effects, memory ordering and scheduling, including source-language restrictions.
7. **Runtime APIs:** native standard library, host services, system calls, file/network/process access and environment-dependent behavior, with explicit sandbox constraints.
8. **Interoperability:** versioned USL typed IR; native ABI/FI/RPC/embedded-runtime routes, marshaling, errors, callbacks, lifetime/pinning, async cancellation, host/guest provenance.
9. **Backend:** actual compatible toolchain discovered; compiled/linked/executed program or format-appropriate validator/executor; distinguish a shim preserving behavior from native lowering.
10. **Conformance:** authoritative upstream suite when available, independently reviewed fixed cases, invalid cases, holdout property tests, metamorphic/differential tests, fuzz regression, standard-chapter traceability.
11. **Performance:** compare USL direct/embedded/native/sandboxed/reference routes including cold/warm latency, memory and safety; only optimize after behavior equivalence on the declared input domain.
12. **Safety:** untrusted source isolation and permission gates; import boundaries; resource ceilings; supply-chain/licensing provenance; deterministic artifacts and reproducibility.
13. **Portability:** actual qualification on claimed OS/architecture/device combinations; explicit unavailable matrices rather than extrapolated passes.
14. **Certification:** independent source review of versioned chapters/features, regression evidence linked to the exact compiler/runtime build, limitations and exceptions reviewed and signed off. Rerun on any changed dependency.

A status is one of `not_classified`, `spec_not_audited`, `parser_qualified`, `subset_behavior_observed`, `broader_standard_suite_passed`, `profile_conformance_qualified`, or `blocked`; each stage records actual evidence. Never set `profile_conformance_qualified` because a portable interpreter accepted a catalog label.

## Architecture for completion

`source -> family/version resolver -> native frontend or semantics-preserving embedded guest -> USL typed IR/effect system -> static check -> explicit data/ownership/exception/IO contract -> native/VM/RPC/shim route -> runtime proof obligations -> source-specific reference comparator -> result/certificate`.

A direct lowering is permissible when operations preserve relevant semantics. When they differ, insert a **tested compatibility shim** or retain execution within the original language runtime. A refused operation is preferable to silently changed behavior. Track static proofs, observational differential evidence and missing obligations separately.

## v3.9 actually implemented and measured

- Recovered v3.8 release retained; baseline 453/453 tests and 40/40 native subset cases reexecuted before source edits.
- `semantic_fixtures/CORPUS.json`: 40 SHA-256-pinned source fixtures (10 semantic dimensions × Python, JavaScript, Ruby, PHP).
- `usl_systems/semantic_conformance.py`: bounded, approval-controlled **real native** execution, stdout/exit and source hash evidence, language-specific oracle values, per-feature pair compatibility status, parser negative tests, bounded Python→JavaScript compat shim.
- 606-entry **honest specification ledger**: individual IDs, conservative category assignment, minimum relevant standards dimensions, no inflated completion claim.
- `semantic-qualify` and `semantic-ledger` CLI and Windows launcher; tests and JSON reports in `test_results/`.

**Observed differences** among these four languages: negative division, Unicode length representation, copy/reference array assignment, empty-array/list truthiness and precision above 2^53. USL must preserve those instead of flattening them. Matching one case is evidence only for that case, not general pairwise equivalence.

## What is not complete

A full source frontend/IR semantics for arbitrary Python, JavaScript, Ruby, PHP or the other 602 identifiers; complete normative standard inventory; garbage collector compatibility across language ABI boundaries; complete C/Java/Go/Rust memory models; full standard libraries; shader/HDL targets; 606 native runtimes; actual Windows, camera, voice, glasses, GPU and device validation. The v3.9 ledger intentionally records **zero fully certified language specifications**.
