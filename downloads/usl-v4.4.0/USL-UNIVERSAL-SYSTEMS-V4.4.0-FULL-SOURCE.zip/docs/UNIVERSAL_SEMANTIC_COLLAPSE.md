# USL Universal Semantic Routing — v2.5

## What is now executable

One USL source is lowered through the **existing safe parser and hash-checked semantic IR**. The same IR can be sent to:

1. **Portable semantic VM (H0):** a bounded Python 3 standard-library implementation of the supported USL interpreter semantics. An export bundles the interpreter, IR, a tamper-evident manifest, and Windows/Linux entry points. It does not need the installed USL project after extraction.
2. **Direct native emitter (H1):** the existing backend for a specific executable target, **admitted only when the installed toolchain runs the concrete input program and its output matches the USL reference**.
3. **Collapse Success All (H2):** an allowlisted set of independently executed native candidate probes, with completion time, diagnostics, exit codes and results recorded. The lowest observed complete compile+verification time among successful candidates wins. Failed/unsupported probes never count as success. Short runs are noisy and do not guarantee future speedups.
4. **Cooperative partials (H3):** new `semantic_route` (cacheable) and `semantic_native_collapse` (requires explicit native permission; never auto-cached) operations run as independent USL cooperative DAG nodes and join their verified evidence.

Both routes preserve the **one semantic reference**. A requested target such as JSON, Markdown, or an unavailable native compiler is a catalog routing descriptor. It uses the portable USL VM and **does not** magically make JSON/Markdown executable or implement all semantics of that language.

## Steps to grow beyond the present subset

1. Recover the historical source/grammar/semantic registries for each catalog entry.
2. Distinguish executable languages from query, data, markup and template formats.
3. Represent values, effects, functions, modules, types, control flow, concurrency and exceptional behavior in versioned USL IR.
4. Implement and qualify *native* lowering where a target supports the operation.
5. Implement compatibility libraries/interpreters/emulation routes to preserve USL behavior when direct lowering is insufficient. Mark hosted routes independently from native-target compilation.
6. Extend negative tests, boundary semantics (overflow, Unicode, floats, mutation, exceptions, async), and input-domain equivalence evidence.
7. Model target hardware, compilation time, transfer/initialization costs, latency and memory. Adaptively select with measured workload-specific budgets, not a universal speedup claim.
8. Keep source provenance, permissions and stable compatibility wrappers; reuse pure results only if inputs **and engine version** match.
9. Use cooperative workers for independent qualification, deterministic merges, test-driven repair and safe code generation.
10. Qualify hardware on the actual Windows/Ollama/Chrome/EmoVision/Meta installation before raising production claims.

## Usage

```
python -m usl_systems universal-route examples/universal_semantic.usl --target json
python -m usl_systems universal-route examples/universal_semantic.usl --target python --allow-native
python -m usl_systems collapse-success-all examples/universal_semantic.usl --targets python,javascript,ruby,php --i-approve-native --output test_results/native_routes.json
python -m usl_systems universal-export examples/universal_semantic.usl --target javascript --output portable.zip
python -m usl_systems cooperate examples/universal_semantic_cooperation.json --threads 3 --processes 0 --i-approve-native
```

Extract `portable.zip`; run `python3 RUN_PORTABLE.py` without installing USL. Python 3 is still required; this is an interpreter route rather than a native executable for the requested language.

## Current evidence and boundaries

The all-catalog routing tests exercise **606 labels** through one semantic kernel, which is one engine with 606 addressing entries, **not 606 semantically complete foreign-language compilers**. Native verification uses observed behavior of the particular bounded sample, not a universal proof of equivalence. Native execution is explicitly opt-in. The 606-language architectural target remains open.
