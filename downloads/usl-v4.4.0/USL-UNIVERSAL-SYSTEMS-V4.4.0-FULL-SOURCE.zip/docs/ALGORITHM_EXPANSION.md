# USL v0.5.0 — Verified Algorithms and Coverage

## Implemented

- Content-addressed store (CAS): SHA-256 integrity checked, thread-safe immutable writes.
- Compression Success All: compare raw, zlib-1/-6/-9, exact reference duplicate, XOR+zlib delta and partial chunk reuse. Every accepted candidate reconstructs to the original bytes and validates SHA-256. The recorded `encoded_bytes` includes the serialized codec record **excluding the diagnostic fields** that are returned to the caller.
- Bounded exact worker scheduler: N nonoverlapping logical partials tagged with M named service coordinates. Recursive factoring, threadpool execution, identical pure-chunk reuse, serial authority verification, Jain fairness.
- H0/H1/H2 Collapse Compute: H0 exact full baseline, H1 exact reuse, H2 algebraic partial update for bounded integers. Optional full recomputation audits are included in work-unit accounting. These are v0.5 implementation names, not a claim of byte-for-byte replication of all prior experimental versions.
- Evidence-gated adaptive route choice: tests serial, factored synchronous and factored asynchronous on the same input and chooses the lowest measured median time only after equality checks.
- M-dimensional real-capacity tensor placement: greedy normalized-capacity load estimates against round-robin, assignment conservation verification.
- 57 curated built-in formulas, 41 bounded scalar evaluators, provenance and use cases, plus a persistent import path for separately reviewed user equations.
- Read-only historical formula candidate discovery with source archive, file, and line markers; all candidates explicitly unvalidated.
- New USL Fabric task kinds: equation, collapse, fractal, incremental.
- CLI and local HTTP APIs, Forge graphical Equation & Worker Lab.

## Limits not hidden

- Python ThreadPoolExecutor may be slower for CPU-bound work due to overhead and the GIL. Reuse reduces the count of repeated pure chunk computations, not a promise of wall-clock speedup.
- Dimensionless work coordinates are mathematical normalizations; the scheduler does not create additional CPU/GPU cores.
- When the H2 correctness audit re-runs the full operator, avoided arithmetic work may be negative; reporting includes the audit cost.
- The 606 language entries remain syntax/lexer profiles, NOT 606 complete semantic compilers.
- Experimental equations from Kagome, BEC, H70, quantum materials, and future hardware are stored as research proposals unless validated by real numerical solvers and physical experiments.
- Local Chrome/Shadow/EmoVision integrations retain the v0.4 stage and smoke-test scope; no real device connection has been made in this sandbox.
- Exact reuse is valid only for equal/canonically specified pure inputs. Arbitrary in-memory processes or side effects cannot be collapsed safely.

## Commands

```
python -m usl_systems equations --search kagome
python -m usl_systems equations --id transmissibility
python -m usl_systems collapse examples/research/compression.txt --mode all
python -m usl_systems fractal --count 100000 --repeat 128 --workers 8 --leaf 256 --depth 9
python -m usl_systems incremental --count 100000 --changes 100
python -m usl_systems tensor-place '[{"cpu":2,"gpu":8},{"cpu":6,"gpu":0}]' '[{"cpu":4,"gpu":16},{"cpu":12,"gpu":2}]'
python -m usl_systems research-index --max 1000 --output test_results/historical_equation_candidates.json
python -m usl_systems flow examples/research_pipeline.uslflow.json
python -m unittest discover -s tests -v
```

## Interpretation of benchmark metrics

- `physical_work_items` counts reduction-element evaluations, not hash, materialization or instrumentation operations. Compare `elapsed_ms` with an equivalent authoritative serial operation before claiming speed.
- `encoded_bytes` is the complete serialized codec record including its decompression metadata, not the size of its JSON diagnostic wrapper or any file-system overhead.
- All reported times are for the environment stated in `test_results/v0.5_benchmark_summary.json`, not promises on a user's Windows hardware.
- No GPU kernel or physical material measurement was run here.

## Extensibility

`python -m usl_systems equations-import examples/research/custom_equation_import.json` registers a reviewed formula in the persistent local equation store. The parser rejects arbitrary function or attribute access. New equations are marked unverified hypotheses and are **not** auto-imported from the 1,000 historical rule-like candidates.
