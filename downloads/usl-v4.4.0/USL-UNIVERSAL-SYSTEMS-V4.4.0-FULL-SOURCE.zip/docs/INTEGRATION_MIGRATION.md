# Recovered source integrations — v0.4.0

All six listed source archives were recovered from the user's prior ChatGPT Library packages and are now embedded under `legacy_sources/` as exact SHA-256-verified original ZIPs. Original Windows installations, data, and licenses are not overwritten or automatically upgraded.

## Recovered source components

| ID | Source | Integration evidence | Remaining |
|---|---|---|---|
| usl_v031 | Windows regression repair | Recovered Python/GCC compiler actually compiled and executed typed USL example; returned `7` for `5 + 2` | Actual Windows native conformance, ABI merge, nontrivial corpus |
| bridge_v3 | Chrome Bridge Autonomous V3.0 | Actual service launched in isolated subprocess; unpaired GET rejected; paired `/api/status` authenticated; integrated Forge read-only health | Chrome extension + logged-in browser pairing; automated browser acceptance cycle |
| bridge_v221 | Chrome Bridge Stable V2.2.1 | Full recovered source staged intact for comparison | Regression comparison with V3 and Windows acceptance |
| shadow_v87 | Shadow Developer Studio V87 | Actual SDK service instantiated on isolated port with synthetic engine; health schema checked | Live Ollama/audio/camera; application state migration; SDK lacks authentication |
| emovision_v63 | EmoVision Fabric V63 | Actual HTTP service invoked using synthetic bus/sensor; health schema checked | ONNX models, physical sensors, persistent state migration; service lacks authentication |
| meta_v53 | Shadow Meta Android V53 | Exact source staged, verified expected Kotlin entry point | Gradle APK builds, SDK entitlement, actual Meta display hardware |

These are compatible *source and interface contracts*, not proof of a complete integrated OS, wearable deployment, 606 semantic compilers, or unrestricted autonomous control.

## Installation and first launch

1. Extract the distribution ZIP **once**, flat (without duplicate nested project directories).
2. Run `INSTALL_AND_START.bat`, which checks Python 3.10+, verifies all six bundled ZIPs, stages them under `%LOCALAPPDATA%\USL_Universal_Systems\legacy_components`, and opens Forge at `127.0.0.1:8772`.
3. To start the actual recovered Chrome Bridge, run `START_CHROME_BRIDGE_V3.bat` in its own command window. Existing Chrome Bridge data remain under `%USERPROFILE%\USL_Chrome_Bridge_Data` unless `USL_BRIDGE_DATA` is explicitly set.
4. Pair the browser extension from the staged component's `extension` directory. Trusted automatic testing remains **off by default**. Do not execute downloaded code outside an isolated disposable environment.
5. Forge > Integrations > Check paired Chrome Bridge performs an authenticated read-only request, using the pairing token in the local data directory. No pairing token is returned to the browser.
6. Run `RUN_RECOVERED_NATIVE_DEMO.bat` to compile and execute the known-safe v0.31 integer test (requires GCC available on PATH).

## Shell commands

```text
python -m usl_systems recovered-list
python -m usl_systems recovered-stage all
python -m usl_systems recovered-bridge-run --i-allow-launch
python -m usl_systems recovered-health bridge
python -m usl_systems recovered-native examples/recovered_native.usl --arg 5 --i-allow-native
python -m usl_systems recovered-health shadow --url http://127.0.0.1:8767 --i-allow-unauthenticated-sdk
python -m usl_systems recovered-health emovision --url http://127.0.0.1:8774 --i-allow-unauthenticated-sdk
```

## Port collision: Chrome Bridge vs Shadow V87

The historical Chrome Bridge controller **and** V87's original `SDKRuntime` both default to `127.0.0.1:8766`. Do not run both there. Preserve Bridge at 8766 and configure the V87 SDK service to **8767** by constructing `SDKRuntime(engine, port=8767)` or changing its initialization in a staged copy of `studio/engine.py` to `SDKRuntime(self,port=8767)`. Do not patch the original user installation automatically. The complete original V87 source is provided for an authorized later integration.

Shadow V87's API and EmoVision V63's API do **not** implement bearer-token authorization in their recovered source. For this reason, v0.4 refuses to probe these services without an explicit CLI opt-in and does not publish their potentially private creator/vision/state payloads through the Forge browser endpoint. Do not expose those ports to any non-loopback interface. A future production integration should add authenticated reverse proxy and stricter capabilities.

## Security and source provenance

The source bundles are SHA-256 matched against their original recovered versions. Staging is bounded and rejects unsafe archive path traversal, symlinks and case collisions. Three EmoVision ZIP entries contain embedded Windows drive-style state filenames; they are intentionally excluded from staging, with the original unmodified archive still included. Native compilation and launching an upstream service are explicitly opt-in and **not sandboxes**. No silent filesystems, admin privileges, browser tabs, accounts or external services are controlled.
