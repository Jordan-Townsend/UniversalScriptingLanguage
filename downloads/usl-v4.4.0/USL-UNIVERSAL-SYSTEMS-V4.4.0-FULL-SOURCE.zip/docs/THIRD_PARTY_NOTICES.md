# Third-party notices

The included static `usl_systems/syntax_catalog.json` was derived from lexer metadata returned by **Pygments 2.20.0**, a third-party open-source package. No Pygments Python runtime modules are bundled. See `licenses/PYGMENTS_LICENSE.txt` for the upstream Pygments license.

The core USL software created for this release is implemented using Python 3 standard-library components. The project does **not** bundle third-party language compilers or external AI models. Native compilers, Ollama, and Pygments at developer build time are separate software whose respective licenses and installation terms govern their use.

Historical source from Jordan-Townsend GitHub repositories was inspected for architecture and compatibility but is not copied or embedded in this release. The downloaded legacy JSON file, if the user chooses to import it after installation, has separate provenance and must be considered in any commercial redistribution audit.
