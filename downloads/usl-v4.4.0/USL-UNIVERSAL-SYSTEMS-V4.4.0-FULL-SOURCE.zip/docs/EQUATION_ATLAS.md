# USL Research Equation Atlas — v0.5.0

57 curated records; 41 have bounded numerical evaluators. Symbolic entries are NOT physics proofs.

## Interpretation and source policy

The registry records equations relevant to conversations, recovered source archives, and established mathematical foundations. It does NOT establish that all formulas from every past conversation have been recovered. Archive candidate strings (in `test_results/historical_equation_candidates.json`) are not verified equations. All numeric examples below use illustrative, not measured hardware parameters.

No arbitrary `eval` occurs: scalar AST evaluates only permitted operators and functions with finite numeric parameters. Matrix equations, many-body quantum systems and real material behavior require specialist solvers and experimental evidence.

## Computation

### Content-addressed exact identity (`sha256_identity`)

**Formula:** `key = SHA256(bytes)`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Immutable CAS; deduplication; exact reconstruction.

**Source:** prior USL research and mathematical models.

**Limitations:** Hash equality is a practical collision-resistant identity claim; exact bytes still verified.

### Serialized compression ratio (`collapse_ratio`)

**Formula:** `R = input_bytes / encoded_bytes`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Measure actual compression; compare all codecs; packaging decisions.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id collapse_ratio`

### Physical work avoidance fraction (`work_avoidance`)

**Formula:** `A = (logical - executed) / logical`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Repeated-work elimination; proof-gated cache accounting.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id work_avoidance`

### Observed speedup (`speedup`)

**Formula:** `S = baseline_seconds / candidate_seconds`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Independent baseline comparison; regression detection.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id speedup`

### Amdahl speedup bound (`amdahl`)

**Formula:** `S = 1 / ((1-p)+p/n)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Parallel scaling ceiling; decide thread count.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id amdahl`

### Incremental state update (`incremental_update`)

**Formula:** `S_(t+1)=S_t + delta_S`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Partial recompute; scene updates; reusable state.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id incremental_update`

### Reusable exact transform (`cached_transform`)

**Formula:** `Observed=T(known)+Residual`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Exact delta reconstruction; prediction residual testing.

**Source:** USL predictive/market discussions.

### Exactness gate (`semantic_equivalence`)

**Formula:** `decode(encode(x))=x`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Lossless compression; AST roundtrip; state replay.

**Source:** prior USL research and mathematical models.

### Adaptive execution objective (`cost_min`)

**Formula:** `min(C_compute + lambda*C_memory + mu*C_latency)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Scheduling policy selection; budget analysis.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id cost_min`

## Finance

### Risk-adjusted decision objective (`cvar_objective`)

**Formula:** `max E(R)-lambda1*CVaR-lambda2*Cost-lambda3*Drawdown-lambda4*CausalDebt`

**Status:** research_model · **Bounded scalar evaluation:** yes.

**Use cases:** Backtesting and paper-trading decision research.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id cvar_objective`

### Hedging pressure proxy (`dealer_pressure`)

**Formula:** `HPF=sum_i Gamma_i OI_i Multiplier_i S^2 P(DealerState_i)`

**Status:** research_model · **Bounded scalar evaluation:** no.

**Use cases:** Derivatives exposure studies; market regime research.

**Source:** prior USL research and mathematical models.

## Fluids

### Reynolds number (`reynolds`)

**Formula:** `Re=rho*v*L/mu`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Flow regime estimates; fan/drone aerodynamics.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id reynolds`

### Bernoulli pressure relation (`bernoulli`)

**Formula:** `p+0.5*rho*v^2+rho*g*h=constant`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Fluid-flow baseline; piping approximations.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id bernoulli`

### Betz ideal wind extraction bound (`betz`)

**Formula:** `P_max=(16/27)*0.5*rho*A*v^3`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Wind turbine sanity bound; rotor concepts.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id betz`

## Information

### Shannon entropy (`entropy`)

**Formula:** `H=-sum p_i log2(p_i)`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Compression limits; uncertainty; feature selection.

**Source:** prior USL research and mathematical models.

**Limitations:** Nonzero entropy bounds exact representation; no zero-cost universal compression.

### Normalized compression distance (`normalized_compression_distance`)

**Formula:** `NCD=(C(xy)-min(C(x),C(y)))/max(C(x),C(y))`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Similarity research; compression-based clustering.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id normalized_compression_distance`

## Materials

### Stored linear elastic energy (`elastic_energy`)

**Formula:** `E=0.5*k*x^2`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Kagome mount energy; elastic actuator design.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id elastic_energy`

### Linear mass spring damper (`damped_oscillator`)

**Formula:** `m*x_doubleprime+c*x_prime+k*x=0`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Vibration isolation baseline; control system simulation.

**Source:** prior USL research and mathematical models.

### Damped harmonic transmissibility (`transmissibility`)

**Formula:** `T=sqrt((1+(2*zeta*r)^2)/((1-r^2)^2+(2*zeta*r)^2))`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Kagome vs conventional isolators; frequency response.

**Source:** KAGOME_ZERO_V7_ONE_SCRIPT.py.

**Example:** `python -m usl_systems equations --id transmissibility`

### Bragg condition (`bragg`)

**Formula:** `n*lambda=2*d*sin(theta)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Crystalline lattice diffraction; material characterization.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id bragg`

## Ml

### Logistic activation (`logistic`)

**Formula:** `sigma(x)=1/(1+exp(-x))`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** AI probabilities; classification.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id logistic`

### Softmax probability (`softmax`)

**Formula:** `p_i=exp(x_i)/sum_j exp(x_j)`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Neural output calibration; classification.

**Source:** prior USL research and mathematical models.

### Gradient update (`gradient_descent`)

**Formula:** `theta_next=theta-lr*gradient`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Model training; numerical optimization.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id gradient_descent`

### Scalar Kalman gain (`kalman_gain`)

**Formula:** `K=P/(P+R)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Sensor filtering; vision tracking.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id kalman_gain`

## Optimization

### Pareto admissibility (`pareto`)

**Formula:** `x dominates y iff all x_i<=y_i and any x_i<y_i`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Select non-dominated algorithm variants; cost trade-offs.

**Source:** prior USL research and mathematical models.

### Resource value of a task (`resource_reward`)

**Formula:** `R_i=P_i*W_i-lambda*E_switch-mu*C_compute-nu*R_decoherence`

**Status:** research_model · **Bounded scalar evaluation:** yes.

**Use cases:** Quantum control model experiments; energy-aware scheduling.

**Source:** SU(3)/Kagome BEC lattice discussions.

**Example:** `python -m usl_systems equations --id resource_reward`

## Physics

### Kinetic energy (`kinetic_energy`)

**Formula:** `E=0.5*m*v^2`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Moving object energy; mechanical simulation.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id kinetic_energy`

### Linear momentum (`momentum`)

**Formula:** `p=m*v`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Collision analysis; inertial mechanics.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id momentum`

### Newton second law (`force`)

**Formula:** `F=m*a`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Robot forces; actuator feasibility.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id force`

### Aerodynamic drag (`drag`)

**Formula:** `F_d=0.5*rho*v^2*C_d*A`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Drone and vehicle drag modeling; wind tunnel comparisons.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id drag`

### Closed-cycle energy bookkeeping (`energy_conservation`)

**Formula:** `Delta_U_cycle=0 for closed conservative cycle`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Reject perpetual energy claims; measurement reconciliation.

**Source:** prior USL research and mathematical models.

**Limitations:** Include all heat, work, electrical and environmental energy exchanges.

### Lorentz factor (`lorentz`)

**Formula:** `gamma=1/sqrt(1-v^2/c^2)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** High-speed particle calculations.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id lorentz`

### Decay equation (`exponential_decay`)

**Formula:** `y=y0*exp(-k*t)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Simulation baseline; attention decay.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id exponential_decay`

## Quantum

### Photon quantum energy (`photon_energy`)

**Formula:** `E=h*f`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Optics experiments; photon engineering.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id photon_energy`

### de Broglie wavelength (`debroglie`)

**Formula:** `lambda=h/p`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Matter-wave modeling; low-temperature physics.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id debroglie`

### Lindblad master evolution (`lindblad`)

**Formula:** `dot(rho)=-i/hbar[H,rho]+sum_k(L_k rho L_k† -0.5{L_k†L_k,rho})`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Quantum open-system numerical modeling; decoherence estimates.

**Source:** prior USL research and mathematical models.

**Limitations:** Symbolic matrix differential equation; not proof of room-temperature BEC or new stable hydrogen.

### Time-dependent Schrödinger equation (`schrodinger`)

**Formula:** `i*hbar*dpsi/dt=H*psi`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Quantum simulation; numerical approximation.

**Source:** prior USL research and mathematical models.

**Limitations:** Requires Hamiltonian and boundary conditions.

## Scheduling

### Jain fairness (`jain`)

**Formula:** `J=(sum_i x_i)^2/(n sum_i x_i^2)`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Fair CPU/GPU allocation; load distribution.

**Source:** EmoVision V63 handoff, V13 tensor discussion.

### Load imbalance residual (`fairness_residual`)

**Formula:** `epsilon=1-J`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Reapply weak partials; balance load across dimensions.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id fairness_residual`

### Normalized service load (`rho`)

**Formula:** `rho = required_rate / available_rate`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Heterogeneous resource ratio; admission control.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id rho`

### Minimize worst provider load (`rho_minmax`)

**Formula:** `minimize max_i(rho_i)`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Resource-aware placement; bottleneck mitigation.

**Source:** EmoVision V18 handoff and fractal scheduler.

### N partials by M dimensions (`factor_dimensions`)

**Formula:** `P=(partial_i, dimension_j, depth_k)`

**Status:** design_rule · **Bounded scalar evaluation:** no.

**Use cases:** Fractal worker routing; named logical work axes.

**Source:** EmoVision Fabric V63.

## Statistics

### Linear covariance propagation (`covariance_propagation`)

**Formula:** `Sigma_Y=M Sigma_R M^T + N`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Uncertainty tracking; filter design; sensor fusion.

**Source:** USL quantum and predictive work.

### Attention memory decay (`exponential_attention`)

**Formula:** `A(t+dt)=A(t)*exp(-lambda*dt)+NewAttention`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** News-event decay; concept memory; forecasting.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id exponential_attention`

### Attention-flow divergence (`normalized_attention_mismatch`)

**Formula:** `NCD=NormalizedAttentionDirection-NormalizedCapitalFlowDirection`

**Status:** research_model · **Bounded scalar evaluation:** yes.

**Use cases:** Finance research features; causal mismatch tests.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id normalized_attention_mismatch`

### Exponential moving average (`ewma`)

**Formula:** `EMA_next=alpha*x+(1-alpha)*EMA`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Prediction features; filter telemetry; rate smoothing.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id ewma`

### Mean squared error (`mean_squared_error`)

**Formula:** `MSE=sum((prediction-truth)^2)/n`

**Status:** established_math · **Bounded scalar evaluation:** no.

**Use cases:** Predictive model evaluation; optimization.

**Source:** prior USL research and mathematical models.

### Root mean square error (`rmse`)

**Formula:** `RMSE=sqrt(MSE)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Forecast quality; residual monitoring.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id rmse`

### Bayes theorem (`bayes`)

**Formula:** `P(H|E)=P(E|H)*P(H)/P(E)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Decision support; diagnostic prediction.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id bayes`

### Normal distribution density (`gaussian_distribution`)

**Formula:** `p(x)=exp(-0.5*((x-mu)/sigma)^2)/(sigma*sqrt(2*pi))`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Prediction uncertainty; noise model.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id gaussian_distribution`

## Thermal

### Fourier conduction (`fourier_heat`)

**Formula:** `q=-k*A*dT/dx`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Heat-exchanger design; cooling comparison.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id fourier_heat`

### Convective heat transfer (`newton_cooling`)

**Formula:** `Q=h*A*(T_surface-T_fluid)`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Datacenter thermal budget; cold plate sizing.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id newton_cooling`

### Thermal storage (`heat_capacity`)

**Formula:** `Q=m*c_p*delta_T`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Heat buffers; thermal load modeling.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id heat_capacity`

### Pump hydraulic power (`pressure_power`)

**Formula:** `P=delta_p*volumetric_flow/efficiency`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Cooling loop pump sizing; energy efficiency.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id pressure_power`

### Coefficient of performance (`cop`)

**Formula:** `COP=heat_removed/electrical_input`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Thermal equipment comparison.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id cop`

### Power usage effectiveness (`pue`)

**Formula:** `PUE=facility_power/IT_power`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Datacenter infrastructure efficiency.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id pue`

### Water use effectiveness (`water_intensity`)

**Formula:** `WUE=water_liters/IT_energy_kWh`

**Status:** established_math · **Bounded scalar evaluation:** yes.

**Use cases:** Data-center water impact; cooling trade-offs.

**Source:** prior USL research and mathematical models.

**Example:** `python -m usl_systems equations --id water_intensity`

