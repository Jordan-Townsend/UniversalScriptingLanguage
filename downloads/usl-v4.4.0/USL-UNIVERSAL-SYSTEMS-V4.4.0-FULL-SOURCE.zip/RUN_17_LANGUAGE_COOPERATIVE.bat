@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 tools\reuse_v41_abilities.py
) else (
  python tools\reuse_v41_abilities.py
)
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" echo USL v4.1 command failed with exit code %CODE%
endlocal & exit /b %CODE%
