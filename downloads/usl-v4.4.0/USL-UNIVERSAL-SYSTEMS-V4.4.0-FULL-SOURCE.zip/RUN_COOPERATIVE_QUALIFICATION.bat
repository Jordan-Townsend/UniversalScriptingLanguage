@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (py -3 tools\qualify_cooperative.py) else (python tools\qualify_cooperative.py)
exit /b %ERRORLEVEL%
