@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (set "PYTHON=py -3") else (set "PYTHON=python")
%PYTHON% -m usl_systems equations --search kagome
%PYTHON% -m usl_systems incremental --count 100000 --changes 100
%PYTHON% -m usl_systems fractal --count 100000 --repeat 128 --workers 8 --leaf 256 --depth 9
%PYTHON% -m usl_systems flow examplesesearch_pipeline.uslflow.json
endlocal
pause
