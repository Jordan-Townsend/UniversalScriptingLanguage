@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 tools\run_isolated_regressions.py) else (python tools\run_isolated_regressions.py)
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
