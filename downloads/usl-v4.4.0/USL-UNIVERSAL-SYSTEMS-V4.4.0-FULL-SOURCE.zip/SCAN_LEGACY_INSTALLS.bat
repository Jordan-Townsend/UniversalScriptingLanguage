@echo off
setlocal
cd /d "%~dp0"
echo USL v0.3 - read-only discovery of legacy Windows installations
if not exist "test_results" mkdir "test_results"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -m usl_systems integrations --probe-local-bridge > "test_results\legacy_installations.json"
) else (
 python -m usl_systems integrations --probe-local-bridge > "test_results\legacy_installations.json"
)
set "CODE=%ERRORLEVEL%"
type "test_results\legacy_installations.json"
echo.
echo No discovered component was executed or modified.
endlocal & exit /b %CODE%
