#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m usl_systems entity-plan examples/entity_plan.json --data ./entity-data --i-allow-execution
python -m usl_systems entity-memory 'double integer' --data ./entity-data
