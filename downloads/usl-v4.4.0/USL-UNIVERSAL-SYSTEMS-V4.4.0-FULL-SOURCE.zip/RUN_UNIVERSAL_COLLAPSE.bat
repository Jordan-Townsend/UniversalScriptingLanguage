@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m usl_systems universal-route examples\universal_semantic.usl --target json --output test_results\universal_portable.json
if errorlevel 1 exit /b 1
%PY% -m usl_systems collapse-success-all examples\universal_semantic.usl --targets python,javascript,ruby,php --i-approve-native --output test_results\universal_native_collapse.json
if errorlevel 1 exit /b 1
%PY% -m usl_systems cooperate examples\universal_semantic_cooperation.json --threads 3 --processes 0 --i-approve-native --output test_results\universal_cooperation.json
exit /b %errorlevel%
