@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 tools\qualify_native_frontends.py
) else (
 python tools\qualify_native_frontends.py
)
endlocal & exit /b %ERRORLEVEL%
