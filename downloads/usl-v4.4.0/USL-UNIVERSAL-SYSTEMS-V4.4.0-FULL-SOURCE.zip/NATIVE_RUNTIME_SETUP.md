# Native runtime setup

The source ZIP does not contain native operating-system toolchains or the 378 downloaded grammar libraries. The current cloud machine retains those under /workspace/.onboarding. Source /workspace/.onboarding/activate-usl.sh there.

For another Linux host, use Python 3.12, a C/C++ compiler and development headers, Node.js, and the following compatible upstream runtimes. Debian package names vary by distribution:

- gcc/g++, gfortran, rustc, gdc-14, gnat-14
- fp-compiler-3.2.2 and fp-units-rtl-3.2.2
- ocaml-interp and its standard/compiler libraries
- sbcl, guile-3.0, clojure, groovy, scala
- erlang-base and standard application packages; elixir
- pike8.0-core, r-base-core, swi-prolog-core, fennel, lua5.4
- bc, tcsh, fish, iverilog, ghdl-mcode
- mono-runtime, mono-runtime-common, mono-mcs and their standard assembly dependencies
- Ruby, PHP CLI with tokenizer, Java/Javac, Go and the existing v4.2 source-fleet dependencies
- Tesseract for the recorded OCR example; live device/model dependencies remain separate

Install pinned Python dependencies with:

CC=gcc CXX=g++ python -m pip install -r requirements-catalog.txt

On Windows, select installed compiler toolchains rather than setting these Unix environment variables. Windows qualification remains outstanding.

Install the pinned Node source-engine dependencies with npm ci --prefix native_engines --ignore-scripts, and TypeScript 7.0.2 through a local npm tool installation on PATH.

Download actual grammar libraries using the pinned upstream package:

python -c "import tree_sitter_language_pack as p; p.download_all(); print(len(p.downloaded_languages()))"

The package performs its own download/checksum handling. Cache access and networking must be available. Installed parsers are not execution or conformance evidence. The mappings and profile reviews remain explicit.

Install requirements-neural.txt in the same environment or set USL_NEURAL_PYTHON to a separate compatible Python interpreter before the isolated regression runner. Only the seven neural tests use that alternative interpreter. Its actual path is recorded in the report.

Run python tools/qualify_translation_intent.py and python -m usl_systems catalog-sweep --i-allow-execution. Exit 2 from the sweep indicates that the full objective is still incomplete, not that its blocked entries are qualified. Review the JSON case reports, platform/dialect restrictions and MASTER_IMPLEMENTATION_PROMPT.md.

The cloud custom root required explicit standard-library/linker/module paths for several runtimes. Normal system package installation supplies those paths. A fresh machine, Windows, macOS and proprietary runtime hosts have not been qualified by the cloud extraction test.
