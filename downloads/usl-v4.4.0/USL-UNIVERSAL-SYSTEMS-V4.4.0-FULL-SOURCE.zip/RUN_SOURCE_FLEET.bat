@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 -m usl_systems cooperate examples\source_fleet.coop.json --threads 4 --processes 0 --i-approve-native
exit /b %errorlevel%
:python
python -m usl_systems cooperate examples\source_fleet.coop.json --threads 4 --processes 0 --i-approve-native
exit /b %errorlevel%
