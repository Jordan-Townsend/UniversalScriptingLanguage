@echo off
setlocal
cd /d "%~dp0"
echo This example EXECUTES trusted USL code via installed Python, JavaScript, Ruby and PHP runtimes.
where py >nul 2>&1
if not errorlevel 1 (py -3 -m usl_systems cooperate examples\cooperative_native_targets.json --threads 4 --processes 0 --i-approve-native) else (python -m usl_systems cooperate examples\cooperative_native_targets.json --threads 4 --processes 0 --i-approve-native)
exit /b %ERRORLEVEL%
