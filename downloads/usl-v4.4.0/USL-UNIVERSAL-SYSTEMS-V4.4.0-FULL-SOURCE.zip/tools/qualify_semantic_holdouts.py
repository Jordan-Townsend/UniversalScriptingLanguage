"""Emit measured native output comparison evidence for generated holdout programs."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from usl_systems.semantic_holdouts import qualification
report=qualification()
path=ROOT/'test_results'/f"v{(ROOT/'VERSION').read_text().strip()}_semantic_holdouts.json"
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'evidence':str(path),'passed':report['passes'],'executions':report['actual_native_executions'],
                  'all_tested_passed':report['all_tested_passed'],'skipped':report['skipped']},indent=2))
if not report['all_tested_passed']:raise SystemExit(1)
