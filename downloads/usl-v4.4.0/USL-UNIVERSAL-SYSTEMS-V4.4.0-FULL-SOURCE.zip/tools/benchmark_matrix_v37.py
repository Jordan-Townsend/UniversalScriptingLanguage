"""Real end-to-end serial vs 8-way warm native pair probes, with value parity."""
from pathlib import Path
import sys,json,statistics,time,platform,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.executable_matrix import run_pairs

def main():
    data=json.loads((ROOT/'test_results/v3.7.0_parallel_pair_execution.json').read_text('utf8'))
    pairs=[(x['host'],x['guest']) for x in data['pairs']]
    timings={};results={}
    for workers in (1,8):
        timings[workers]=[]
        for trial in range(2):
            r=run_pairs(pairs,authorized=True,workers=workers)
            if r['actual_verified_pairs']!=len(pairs):
                raise RuntimeError(f'Pair failed: {workers} workers, trial {trial}: '+str([x for x in r['pairs'] if not x['verified']]))
            normalized={(x['host'],x['guest']):x['actual_values'] for x in r['pairs']}
            if results and normalized != results:
                raise RuntimeError('Serial and parallel native outputs differ')
            results=normalized
            timings[workers].append(r['elapsed_ms'])
    med={str(k):round(statistics.median(v),3) for k,v in timings.items()}
    output={'schema':'usl.matrix.verified.benchmark.v1','platform':platform.platform(),
        'pairs':len(pairs),'actual_native_calls_per_workload':len(pairs)*2,
        'timings_ms':{str(k):v for k,v in timings.items()},'median_ms':med,
        'observed_serial_to_eight_speed_ratio':round(med['1']/med['8'],3),
        'source_output_match':True,'compilation_cache':'warm; actual execution repeated on each trial',
        'worker_dimensions':'logical work partition, 1 or 8 real threads, bounded native subprocesses',
        'not_a_guarantee_of_acceleration':True}
    p=ROOT/'test_results/v3.7.0_matrix_parallel_benchmark.json'
    p.write_text(json.dumps(output,indent=2)+'\n','utf8');print(json.dumps(output,indent=2))
if __name__=='__main__':main()
