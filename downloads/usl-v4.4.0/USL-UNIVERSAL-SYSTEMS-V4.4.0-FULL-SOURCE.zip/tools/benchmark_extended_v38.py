"""Measured native host->guest batches: cold toolchain costs not excluded without disclosure."""
import json,sys,time,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.executable_matrix import run_pairs
pairs=[('tcl','lua'),('lua','tcl'),('make','cmake'),('cmake','make'),
 ('python','tcl'),('tcl','python'),('javascript','lua'),('lua','javascript'),
 ('awk','make'),('make','awk'),('c','cmake'),('cmake','c')]
rows=[]
for workers in (1,8):
 times=[];digests=[]
 for i in range(3):
  results=run_pairs(pairs,authorized=True,workers=workers,include_registry=True)
  if results['actual_verified_pairs']!=len(pairs):raise RuntimeError('Failed benchmark native route; no performance claim')
  times.append(results['elapsed_ms'])
  digests.append({(r['host'],r['guest']):r['actual_values'] for r in results['pairs']})
 if any(d!=digests[0] for d in digests):raise RuntimeError('Benchmark output mismatch')
 rows.append({'workers':workers,'samples_ms':times,'median_ms':statistics.median(times),'actual_pairs':len(pairs),'outputs_verified':True})
report={'schema':'usl.v38.real_parallel_benchmark.v1','samples_per_configuration':3,'pairs':len(pairs),
 'measurements':rows,'serial_to_parallel_speedup':round(rows[0]['median_ms']/rows[1]['median_ms'],3),
 'scope':'twelve selected actual small native guest pairs; excludes full 401-route workload; not universal acceleration'}
(ROOT/'test_results/v3.8.0_parallel_benchmark.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
