"""Evidence-based 606-entry per-family runtime qualification.

Takes real nested execution report. Each entry records observed subset success
only when exact catalog family is represented in the executed program. Other
catalog entries remain pending. This is NOT a substitute for 606 full compilers.
"""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from usl_systems.catalog import load_catalog
from usl_systems.interop import bridge_eligibility_matrix, catalog_matrix
MODE_KIND={'python':'interpreted','javascript':'interpreted','sql':'query_engine',
 'ruby':'interpreted','php':'interpreted','perl':'interpreted','bash':'shell_runtime',
 'go':'native_compiled','java':'managed_compiled','swift':'native_compiled',
 'typescript':'managed_compiled','kotlin':'managed_compiled',
 'c':'native_compiled','cpp':'native_compiled','fortran':'native_compiled'}

def make_report(report_path=None):
    if report_path is None: report_path=ROOT/'test_results/v3.7.0_sixteen_native.json'
    observed=json.loads(Path(report_path).read_text('utf8'))
    if not observed.get('all_verified') or observed.get('verified')!=16:
        raise ValueError('Need real verified sixteen-stage report')
    bylanguage={}
    for result in observed['results'].values():
        if result.get('verified_execution') is not True or result.get('status')!='verified':
            raise ValueError('Nested execution evidence unverified')
        lang=result['language']
        if lang in bylanguage:raise ValueError('Demonstration repeated a language')
        bylanguage[lang]=result
    if set(bylanguage)!={*MODE_KIND,'usl'}:
        raise ValueError('Missing qualified guest families')
    rows=load_catalog()
    if len(rows)!=606:raise ValueError('Expected exactly 606 catalog entries')
    identifiers={r['id'] for r in rows}
    if not set(MODE_KIND)<=identifiers:raise ValueError('Missing native guest catalog IDs')
    bridge_rows={x['id']:x for x in catalog_matrix()['entries']}
    entries=[]
    for r in rows:
        lang=r['id'];ev=bylanguage.get(lang)
        row=bridge_rows[lang]
        qualified=bool(ev)
        entries.append({'id':lang,'name':r['name'],'category_inferred':False,
          'recognized':True,'guest_adapter_declared':bool(row['native_bridge_family']),
          'toolchain_present':bool(row['native_toolchain_present']),
          'subset_program_executed':qualified,
          'observed_mode':ev['evidence'].get('mode') if ev else None,
          'observed_source_sha256':ev['source_sha256'] if ev else None,
          'observed_value_sha256':ev['value_sha256'] if ev else None,
          'execution_type':MODE_KIND.get(lang) if qualified else None,
          'complete_native_semantic_compiler':False,
          'next_action':'expand real positive/negative language-specific conformance' if qualified else
                        'recover/install a suitable grammar, semantic frontend and executable runtime; qualify an actual source program'})
    return {'schema':'usl.catalog.runtime.qualified.v1','catalog_count':606,
      'unique_catalog_ids':len(set(identifiers)),'verified_guest_subset_ids':sorted(MODE_KIND),
      'verified_guest_subset_count':len(MODE_KIND),
      'catalog_entries_without_native_subset_evidence':606-len(MODE_KIND),
      'usl_runtime_outside_syntax_catalog':bylanguage['usl']['evidence'].get('mode'),
      'native_execution_claim_scope':'exact tested program/ABI; not full language',
      'all_606_full_native_compilers':False,
      'routable_606_pair_eligibility':bridge_eligibility_matrix(),
      'observed_pair_edges_in_demo':15,
      'entries':entries}

if __name__=='__main__':
    x=make_report();p=ROOT/'test_results/v3.7.0_606_runtime_qualification.json'
    p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print(json.dumps({'file':str(p),'catalog_entries':x['catalog_count'],
       'verified_bounded_guests':x['verified_guest_subset_count'],
       'unverified_guest_semantics':x['catalog_entries_without_native_subset_evidence'],
       'full_606_compilers':x['all_606_full_native_compilers']},indent=2))
