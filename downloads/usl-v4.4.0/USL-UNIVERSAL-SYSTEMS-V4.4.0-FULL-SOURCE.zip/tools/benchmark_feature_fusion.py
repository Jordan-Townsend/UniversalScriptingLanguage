"""Compare the baseline and stacked fusion on an independent local holdout."""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from usl_systems.neural_training import benchmark

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='test_results/v4.3.0_neural')
    parser.add_argument('--epochs', type=int, default=24)
    parser.add_argument('--seeds', default='7,23,61')
    args = parser.parse_args()
    report = benchmark(args.output, epochs=args.epochs, seeds=tuple(int(s) for s in args.seeds.split(',')))
    print(json.dumps({k:v for k,v in report.items() if k != 'records'}, indent=2))
