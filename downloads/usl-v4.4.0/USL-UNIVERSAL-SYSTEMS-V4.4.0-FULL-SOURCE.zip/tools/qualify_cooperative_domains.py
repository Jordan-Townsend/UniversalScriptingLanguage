"""Actual USL CooperativeScheduler language execution graph; native opt-in required."""
import argparse,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from usl_systems.domain_execution import FIXTURES,discovered
from usl_systems.cooperative_workers import CooperativeScheduler

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--approved',action='store_true')
    p.add_argument('--workers',type=int,default=8)
    p.add_argument('--output',default='test_results/v4.0.0_cooperative_languages.json')
    p.add_argument('--artifacts',default='test_results/v4.0.0_cooperative_artifacts')
    args=p.parse_args()
    if not args.approved:raise SystemExit('Language engines require --approved')
    engines=discovered(); chosen=[k for k in sorted(FIXTURES) if engines[k]['installed']]
    tasks=[{'id':'skill'+str(i),'kind':'domain_qualify','deps':[],
            'inputs':{'language':lang,'artifacts':str((ROOT/args.artifacts).resolve())},'priority':50}
           for i,lang in enumerate(chosen)]
    tasks.append({'id':'evidence','kind':'join_evidence','deps':[t['id'] for t in tasks],'priority':5})
    graph={'schema':'usl.cooperative.graph.v1','tasks':tasks}
    engine=CooperativeScheduler(threads=args.workers,processes=0,allow_native=True,max_in_flight=args.workers)
    report=engine.run(graph,cache=False)
    report['qualified_language_ids']=chosen
    outfile=ROOT/args.output;outfile.parent.mkdir(parents=True,exist_ok=True)
    outfile.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n','utf8')
    print(json.dumps({'verified':report['all_verified'],'tasks':report['task_count'],
          'languages':len(chosen),'actual_parallel_tasks_max':report['max_active_observed'],
          'elapsed_ms':report['elapsed_ms'],'out':str(outfile)},indent=2))
    return 0 if report['all_verified'] else 1
if __name__=='__main__':raise SystemExit(main())
