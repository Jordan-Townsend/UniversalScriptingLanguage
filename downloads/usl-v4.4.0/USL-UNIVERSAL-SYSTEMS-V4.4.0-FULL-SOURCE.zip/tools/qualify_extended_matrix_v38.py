"""Execute every currently eligible catalog-to-catalog route, with reviewed dynamic adapters.

Every unqualified cell is represented but not mislabeled. This is bounded
parallel *real execution*, not simulation or proof of entire language semantics.
"""
from __future__ import annotations
import hashlib,json,sys,time,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.executable_matrix import build_dense_matrix,run_pairs,run_language_qualifications
from usl_systems.universal_adapters import qualify_registry,capability_report,discovered
from usl_systems.interop import catalog_matrix

def write(name,value):
 p=ROOT/'test_results'/name;p.parent.mkdir(exist_ok=True)
 p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8');return p

def main():
 start=time.perf_counter()
 reg=qualify_registry(authorized=True,workers=4)
 write('v3.8.0_registered_adapters.json',reg)
 # Automatically detect only executable toolchains on this host; preserve all
 # uninstalled catalog entries with explicit unqualified status.
 registry_tools=discovered()
 available={row['native_bridge_family'] for row in catalog_matrix()['entries']
            if row['native_toolchain_present'] and row['native_bridge_family']}
 available.update(k for k,v in registry_tools.items() if v['toolchain_present'])
 available.add('usl')
 from usl_systems.executable_matrix import fixtures
 selected=sorted(set(fixtures(include_registry=True))&available)
 langs=run_language_qualifications(authorized=True,workers=8,include_registry=True,include=selected)
 write('v3.8.0_language_executions.json',langs)
 if langs['failed_real_execution']:raise SystemExit('Guest failures; see report')
 base,meta=build_dense_matrix(language_evidence=langs,include_registry=True)
 ids=meta['entry_order'];pairs=[(ids[i],ids[j]) for i in range(606) for j in range(606) if base[i*606+j]==1]
 print('Native candidates:',len(pairs),flush=True)
 attempts=run_pairs(pairs,authorized=True,workers=8,include_registry=True)
 write('v3.8.0_executable_pairs.json',attempts)
 dense,evidence=build_dense_matrix(language_evidence=langs,pair_evidence=attempts,include_registry=True)
 (ROOT/'test_results/v3.8.0_executable_matrix.bin').write_bytes(dense)
 write('v3.8.0_executable_matrix.json',evidence)
 capability=capability_report(qualifications=reg)
 qualified={r['id'] for r in capability['entries'] if r['execution_status']=='observed_fixture_execution'}
 from usl_systems.catalog import load_catalog
 for entry in capability['entries']:
  if entry['id'] in langs['status_by_language'] and langs['status_by_language'][entry['id']]['status']=='verified':
   entry['execution_status']='observed_fixture_execution'
 write('v3.8.0_all_606_execution_status.json',capability)
 summary={'schema':'usl.v38.extended_execution_evidence.v1',
   'catalog_records':606,'matrix_cells':606**2,
   'guest_environments_executed':langs['verified_exact_subsets'],
   'runtime_subsets_in_catalog_executed':sum(r['execution_status']=='observed_fixture_execution' for r in capability['entries']),
   'route_candidates':len(pairs),'actually_executed_and_verified_pairs':attempts['actual_verified_pairs'],
   'no_execution_route_currently':evidence['count_unverified'],
   'conditional_not_executed':evidence['count_conditional_unverified'],
   'new_adapter_fixtures_verified':reg['passed'],'new_adapter_languages':sorted(qualified),
   'registered_guest_tools_not_installed':[k for k,v in registry_tools.items() if not v['toolchain_present']],
   'errors':[{k:x.get(k) for k in ('host','guest','status','error','failures')} for x in attempts['pairs'] if not x.get('verified')],
   'elapsed_ms':round((time.perf_counter()-start)*1000,2),'workers':8,'platform':platform.platform(),
   'full_language_semantic_compilers_proven':0,
   'integrity_sha256':hashlib.sha256(dense).hexdigest()}
 write('v3.8.0_qualification_summary.json',summary)
 print(json.dumps(summary,indent=2),flush=True)
 return 0 if (attempts['actual_verified_pairs']==len(pairs) and langs['failed_real_execution']==0) else 2
if __name__=='__main__':raise SystemExit(main())
