"""Generate versioned 606-accountability and typed executable matrix evidence."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.extrapolate_606 import plan,matrix

def run():
    report=json.loads((ROOT/'test_results/v4.1.0_domains.json').read_text('utf8'))
    ledger=plan(report);path=ROOT/'test_results/v4.1.0_606_expansion_plan.json'
    path.write_text(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n','utf8')
    cells=matrix(ROOT/'test_results/v4.1.0_artifacts',report)
    dest=ROOT/'test_results/v4.1.0_executable_typed_matrix.json'
    dest.write_text(json.dumps(cells,indent=2,ensure_ascii=False)+'\n','utf8')
    return {'catalog_total':ledger['catalog_total'],'new_verified_subset_languages':ledger['newly_executed_catalog_entries'],
        'total_tested_executable_subsets':ledger['total_executable_subsets'],
        'not_yet_executable':ledger['unqualified_entries'],
        'proven_typed_artifact_handoffs':cells['tested_typed_handoff_cells'],
        'no_unverified_executions_promoted':True,'whole_specifications_complete':0}
if __name__=='__main__':print(json.dumps(run(),indent=2))
