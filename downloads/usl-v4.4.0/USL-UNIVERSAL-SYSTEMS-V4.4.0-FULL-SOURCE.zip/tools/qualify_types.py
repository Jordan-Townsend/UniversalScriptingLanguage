"""Static checker positive/negative test report, no user code execution."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.semantic_types import check_types
CASES={
 'valid':'let a = [1,2,3]\nlet i = 1\nprint(a[i] + 4)',
 'bad_index_type':'let a = [1,2,3]\nprint(a["one"])',
 'bad_oob':'let a = [1,2,3]\nprint(a[30])',
 'bad_negative_oob':'let a = [1,2,3]\nprint(a[-5])',
 'bad_arithmetic':'let a = "hi"\nprint(a - 2)',
 'bad_function_arity':'function add(x):\n    return x + 2\nprint(add(1, 2))',
}
records=[]
for case,src in CASES.items():
 result=check_types(src);expected=0 if case=='valid' else 1
 records.append({'case':case,'source_sha256':hashlib.sha256(src.encode()).hexdigest(),
                 'errors':result['error_count'],'expected_error_presence':bool(expected),
                 'passed':bool(result['error_count'])==bool(expected),'issues':result['issues']})
report={'schema':'usl.static.qualification.v1','cases':records,'passed':sum(row['passed'] for row in records),
        'total':len(records),'complete_type_system_proven':False}
path=ROOT/'test_results'/f"v{(ROOT/'VERSION').read_text().strip()}_type_qualification.json"
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'total':report['total'],'path':str(path)},indent=2))
if report['passed']!=report['total']:raise SystemExit(1)
