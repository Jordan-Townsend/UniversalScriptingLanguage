"""Actual cold/warm execution with temporary isolated cache, no invented speedups."""
from pathlib import Path
import json,os,shutil,statistics,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from usl_systems.interop import SCHEMA,run_nested

def run():
    evidence={}
    for lang,tool,src in (
        ('typescript','tsc','export function transform(x:number):number{return x+12;}'),
        ('kotlin','kotlinc','fun transform(x:Long):Long = x+12L')):
        if not shutil.which(tool):
            evidence[lang]={'status':'not_installed','toolchain':tool};continue
        with tempfile.TemporaryDirectory(prefix='USL native benchmark cache ') as tmp:
            old=os.environ.get('USL_NATIVE_CACHE_ROOT')
            try:
                os.environ['USL_NATIVE_CACHE_ROOT']=tmp
                measures=[]
                for n in range(4):
                    proj={'schema':SCHEMA,'nodes':[{'id':'guest','language':lang,'source':src,
                        'export':'transform','params':['i64'],'returns':'i64','args':[n]}]}
                    rep=run_nested(proj,authorized=True,workers=1)
                    if not rep['all_verified'] or rep['results']['guest']['value']!=n+12:
                        raise RuntimeError('Native benchmark output mismatch: '+repr(rep.get('failures')))
                    detail=rep['results']['guest']['evidence']
                    measures.append({'call_index':n,'warm_build_cache':bool(detail['cache_hit']),
                         'elapsed_ms':rep['elapsed_ms'],'build_ms':detail['build']['duration_ms'],
                         'execution_ms':detail['run']['duration_ms'],'verified_value':n+12})
                if measures[0]['warm_build_cache'] or not all(m['warm_build_cache'] for m in measures[1:]):
                    raise RuntimeError('Native build cache cold/warm pattern invalid')
                evidence[lang]={'status':'verified','samples':measures,
                   'cold_elapsed_ms':measures[0]['elapsed_ms'],
                   'warm_elapsed_median_ms':round(statistics.median(m['elapsed_ms'] for m in measures[1:]),3),
                   'cold_build_ms':measures[0]['build_ms'],
                   'warm_build_median_ms':round(statistics.median(m['build_ms'] for m in measures[1:]),3),
                   'all_results_verified':True}
            finally:
                if old is None:os.environ.pop('USL_NATIVE_CACHE_ROOT',None)
                else:os.environ['USL_NATIVE_CACHE_ROOT']=old
    return {'schema':'usl.native.cache.benchmark.v1','environment':sys.platform,
            'samples_per_installed_toolchain':4,'warm_cache_does_not_skip_guest_execution':True,
            'results':evidence}
if __name__=='__main__':
    result=run();out=ROOT/'test_results'/'v3.5.0_native_cache_benchmark.json'
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
