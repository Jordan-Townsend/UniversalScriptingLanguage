"""Execute EVERY currently eligible 606x606 catalog route, bounded by real workers.

Use the actual USL host/guest bridge, cached source builds and verified result
hashes. A conditional cell becomes observed only after an actual real two-stage
execution. All 367236 catalog matrix cells remain represented.
"""
from pathlib import Path
import json,sys,time,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.executable_matrix import build_dense_matrix,run_pairs,run_language_qualifications

def save(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def main():
    lang_file=ROOT/'test_results/v3.7.0_parallel_guest_execution.json'
    # Always reprobe actual installed toolchains on the current host; a
    # previous Linux qualification must never masquerade as a Windows run.
    langs=run_language_qualifications(authorized=True,workers=4)
    save(lang_file,langs)
    grid,m=build_dense_matrix(language_evidence=langs)
    ids=m['entry_order']
    selected=[(ids[i],ids[j]) for i in range(606) for j in range(606) if grid[606*i+j]==1]
    print('actual candidate routes to execute:',len(selected),flush=True)
    started=time.perf_counter()
    probes=run_pairs(selected,authorized=True,workers=8)
    save(ROOT/'test_results/v3.7.0_all_eligible_pair_exec.json',probes)
    matrix,meta=build_dense_matrix(language_evidence=langs,pair_evidence=probes)
    (ROOT/'test_results/v3.7.0_executable_matrix_606x606.bin').write_bytes(matrix)
    save(ROOT/'test_results/v3.7.0_executable_matrix_606x606.json',meta)
    summary_file=ROOT/'test_results/v3.7.0_qualification_summary.json'
    summary=json.loads(summary_file.read_text('utf8'))
    summary.update({'total_eligible_pair_execution_attempts':len(selected),
      'actual_executed_pairs':probes['actual_verified_pairs'],
      'observed_pairs_in_catalog_matrix':meta['count_executed_verified'],
      'conditional_unexecuted_pairs':meta['count_conditional_unverified'],
      'unverified_pairs':meta['count_unverified'],
      'actual_pair_probe_elapsed_ms':probes['elapsed_ms'],
      'native_pair_parallel_workers':8,
      'failed_pairs':[(x['host'],x['guest'],x.get('failures') or x.get('error')) for x in probes['pairs'] if not x.get('verified')]})
    save(summary_file,summary)
    print(json.dumps({'attempted':probes['probe_count'],'verified':probes['actual_verified_pairs'],
        'conditional_remaining':meta['count_conditional_unverified'],
        'unverified_pairs':meta['count_unverified'],
        'elapsed_ms':round((time.perf_counter()-started)*1000,2),
        'failed_count':len(summary['failed_pairs'])},indent=2),flush=True)
    return 0 if (probes['actual_verified_pairs']==len(selected) and langs['failed_real_execution']==0) else 2
if __name__=='__main__':raise SystemExit(main())
