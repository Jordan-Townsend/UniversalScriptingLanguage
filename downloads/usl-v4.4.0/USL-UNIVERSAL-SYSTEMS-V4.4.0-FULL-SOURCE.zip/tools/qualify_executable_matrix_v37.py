"""Full 606-catalog qualification with real, parallel guest/pair execution.

Only approved, reviewed fixtures are launched. Every catalog entry receives a
status. A binary matrix materializes all 367,236 possible routes without
claiming unverified pairs execute successfully.
"""
from pathlib import Path
import json,sys,time,platform,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.executable_matrix import (run_language_qualifications,run_pairs,build_dense_matrix,fixtures)

# Representative native pairs: light process guests and real compiled guests.
# These are intentionally not a fabricated exhaustive qualification of 606^2.
PAIRS=[('python','javascript'),('javascript','sql'),('sql','ruby'),
       ('ruby','php'),('php','awk'),('awk','bash'),('bash','perl'),
       ('perl','c'),('c','fortran'),('fortran','cpp'),('cpp','go'),
       ('go','java'),('java','typescript'),('typescript','swift'),
       ('swift','kotlin'),('kotlin','usl'),('sed','sed'),
       ('javascript','python'),('php','python'),('awk','c')]

def save(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n','utf8')
def main():
    start=time.perf_counter()
    g=run_language_qualifications(authorized=True,workers=4)
    save(ROOT/'test_results/v3.7.0_parallel_guest_execution.json',g)
    print('Qualified real guest execution:',g['verified_exact_subsets'],'/',g['attempted_real_execution'],'in',g['elapsed_ms'],'ms',flush=True)
    p=run_pairs(PAIRS,authorized=True,workers=4)
    save(ROOT/'test_results/v3.7.0_parallel_pair_execution.json',p)
    print('Qualified real pair execution:',p['actual_verified_pairs'],'/',p['probe_count'],'in',p['elapsed_ms'],'ms',flush=True)
    grid,meta=build_dense_matrix(language_evidence=g,pair_evidence=p)
    (ROOT/'test_results/v3.7.0_executable_matrix_606x606.bin').write_bytes(grid)
    save(ROOT/'test_results/v3.7.0_executable_matrix_606x606.json',meta)
    record={'schema':'usl.v3.7.0.executable_matrix_qualification','host_platform':platform.platform(),
        'catalog_entries':len(g['catalog']),'pair_matrix_cells':meta['cells'],
        'catalog_entries_executed':sum(x['status']=='verified_executable_subset' for x in g['catalog']),
        'catalog_entries_unverified':sum(x['status']!='verified_executable_subset' for x in g['catalog']),
        'actual_executed_runtimes':g['verified_exact_subsets'],
        'actual_executed_pairs':p['actual_verified_pairs'],
        'conditional_unexecuted_pairs':meta['count_conditional_unverified'],
        'unverified_pairs':meta['count_unverified'],
        'complete_semantic_compilers_established':0,
        'duration_ms':round((time.perf_counter()-start)*1000,3),
        'source_fixture_hashes':{k:hashlib.sha256(v['source'].encode()).hexdigest() for k,v in fixtures().items()},
        'qualifications_are_for_specific_fixture_programs_not_whole_languages':True,
        'windows_hardware_verified':False}
    save(ROOT/'test_results/v3.7.0_qualification_summary.json',record)
    print(json.dumps(record,indent=2),flush=True)
    if g['failed_real_execution'] or p['actual_verified_pairs']!=len(PAIRS):
        print('Some execution probes failed; inspect JSON evidence',file=sys.stderr)
        return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
