"""Write reproducible observed 8-target boolean compatibility evidence."""
import json,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from usl_systems.universal import route
from usl_systems.native import tool_available
root=Path(__file__).resolve().parents[1]
targets=('python','javascript','ruby','php','go','java','cpp','c')
sources=('print(True)','print(False)','let enabled = 5 > 4\nprint(enabled)')
rows=[]
for target in targets:
    for source in sources:
        info=route(source,target,allow_native=True)
        rows.append({'backend':target,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
            'native_installed':tool_available(target),'pass':bool(info['native_verified_for_this_program']),
            'mode':info['mode'], 'reference_sha256':info['reference_stdout_sha256'],
            'native_status':info['attempts'][0]['status'],
            'exit_code':info['attempts'][0].get('native_exit_code')})
report={'schema':'usl.native.compat.boolean.v1','version':'2.6.0','total':len(rows),
        'passed':sum(r['pass'] for r in rows),'all_passed':all(r['pass'] for r in rows),
        'claim':'Concrete boolean-display compatibility checks only; not complete target-language semantics',
        'rows':rows}
path=root/'test_results/v2.6.0_boolean_compatibility.json';path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'total':report['total'],'passed':report['passed'],'all_passed':report['all_passed'],'output':str(path)},indent=2))
raise SystemExit(0 if report['all_passed'] else 2)
