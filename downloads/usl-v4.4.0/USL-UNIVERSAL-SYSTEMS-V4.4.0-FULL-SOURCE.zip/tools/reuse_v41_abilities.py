"""Bounded partial-worker demonstration consuming actual new language artifacts."""
import argparse,hashlib,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.cooperative_workers import CooperativeScheduler
from usl_systems.expanded_domains import SPEC

def run(artifacts, *, threads=8):
    folder=Path(artifacts)
    tasks=[{'id':'domain_'+str(i),'kind':'domain_expand','inputs':{'language':lang,'artifacts':str(folder)}}
           for i,lang in enumerate(sorted(SPEC))]
    tasks.append({'id':'verified_join','kind':'join_evidence','deps':[t['id'] for t in tasks]})
    graph={'schema':'usl.cooperative.graph.v1','tasks':tasks}
    started=time.perf_counter()
    result=CooperativeScheduler(threads=threads,processes=0,allow_native=True,max_in_flight=threads).run(graph,cache=False)
    if not result['all_verified']:raise RuntimeError('Unverified USL native partials '+str(result['blocked_or_failed']))
    raw={lang:json.loads((folder/(lang.replace('+','_')+'.json')).read_text('utf8')) for lang in SPEC}
    if len(raw)!=17:raise ValueError('Incomplete new language evidence artifacts')
    # Actual values are obtained from independently executed source. These
    # values control a new USL program and form a typed dependency pipeline.
    assert raw['protobuf']['workers']==raw['turtle']['workers']==raw['sparql']['workers']==6
    assert raw['jsonld']['name']=='USL'
    assert raw['jmespath']['selected']=='verifier'
    assert raw['nginx']['validated'] and raw['asymptote']['vector_root']=='eps'
    assert raw['jsonbareobject']['mode']=='verified'
    assert raw['cython']['result']==raw['llvm']['jit_result']==42
    assert raw['bibtex']['bibliography']
    for lang in ('xml+mako','xml+php','xml+ruby'):assert raw[lang]['xml_n']==42
    assert raw['html+mako']['html_strong']=='VERIFIED'
    assert raw['css+mako']['css_declarations']==2
    assert raw['sql+jinja']['square']==49
    value=sum([raw['protobuf']['workers'],raw['turtle']['workers'],raw['sparql']['workers'],raw['sql+jinja']['square'],raw['cython']['result'],raw['llvm']['jit_result']])
    expected=str(value*2)+'\n'
    final=CooperativeScheduler(threads=threads,processes=0).run({'schema':'usl.cooperative.graph.v1','tasks':[
        {'id':'interpret','kind':'interpreter','inputs':{'source':f'let result = {value}\nprint(result * 2)'}},
        {'id':'digest','kind':'compress','inputs':{'text':json.dumps(raw,sort_keys=True)}},
        {'id':'done','kind':'join_evidence','deps':['interpret','digest']}
    ]},cache=False)
    if not final['all_verified'] or final['tasks']['interpret']['value']['stdout']!=expected:
        raise RuntimeError('Composed language results failed actual USL execution')
    return {'schema':'usl.expansion.reuse.v4.1','all_17_new_artifacts_consumed':True,
      'new_catalog_ids':sorted(raw),'observed_derived_sum':value,'usl_composed_stdout':expected,
      'artifacts_sha256':{k:hashlib.sha256((folder/(k.replace('+','_')+'.json')).read_bytes()).hexdigest() for k in raw},
      'parallel_partial_graph':result,'usl_composition_graph':final,
      'elapsed_ms':round((time.perf_counter()-started)*1000,2)}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--artifacts',default='test_results/v4.1.0_artifacts')
    p.add_argument('--threads',type=int,default=8);p.add_argument('--output',default='test_results/v4.1.0_ability_reuse.json');a=p.parse_args()
    output=run(ROOT/a.artifacts,threads=a.threads)
    dest=ROOT/a.output;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n','utf8')
    print(json.dumps({'verified':output['all_17_new_artifacts_consumed'],'skills':len(output['new_catalog_ids']),
      'max_active':output['parallel_partial_graph']['max_active_observed'],'usl_result':output['usl_composed_stdout'],
      'elapsed_ms':output['elapsed_ms']},indent=2))
