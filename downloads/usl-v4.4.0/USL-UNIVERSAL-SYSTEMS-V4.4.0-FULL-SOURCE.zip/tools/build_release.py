"""Create the complete, flat v0.8.0 USL release from an actually verified tree.

This hashes source files (including immutable recovered archives) rather than
claiming file presence implies a working product. Full test suite MUST pass.
"""
from __future__ import annotations
import hashlib,json,re
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT.parent/'USL-UNIVERSAL-SYSTEMS-V0.8.0-FULL-LIVE-LOOP-CPU-SOURCE.zip'

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as fh:
        for b in iter(lambda:fh.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()

def build():
    log=(ROOT/'test_results/v0.8_linux_full.txt').read_text(encoding='utf8',errors='replace')
    m=re.search(r'Ran (\d+) tests in [\d.]+s\s+OK\s*$',log)
    if not m:raise RuntimeError('Cannot package: most recent full regression suite is not passing')
    tests=int(m.group(1))
    q=json.loads((ROOT/'test_results/v0.8_native_qualification.json').read_text(encoding='utf8'))
    native=sum(row.get('passed',0) for row in q['qualification'].values())
    installed=sum(bool(row.get('toolchain_installed')) for row in q['qualification'].values())
    if native!=40:raise RuntimeError('Native qualifying results regressed from previous 40/40 baseline')
    bench=json.loads((ROOT/'test_results/v0.8_parallel_benchmark.json').read_text(encoding='utf8'))
    if bench.get('verified_exact') is not True:raise RuntimeError('Parallel benchmark not reference-verified')
    files=sorted((p for p in ROOT.rglob('*') if p.is_file()
       and p.name!='RELEASE_MANIFEST.json'
       and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')
       and not p.name.endswith('.pid')),key=lambda p:p.relative_to(ROOT).as_posix())
    paths={p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in files}
    manifest={
      'schema':'usl.integrated.release.v3','version':'0.8.0','baseline':'0.7.0',
      'files':paths,
      'verified_tests':{'linux_unittest':tests,'linux_regressions_passed':True,
                        'native_subset_cases_passed':native,'native_targets_available':installed,
                        'shadow_ollama_http_simulated_server':True,
                        'physical_ollama_model_test':False,
                        'browser_cycle_mock_server':True,
                        'browser_extension_real_user_test':False},
      'classification':{'syntax_catalogue_count':606,'restricted_source_emitters':13,
                        'complete_semantic_compilers_proven':0,
                        'real_cpu_multiprocessing_implemented':True,
                        'live_gpu_kernels_verified':False},
      'benchmarks':{'worker_verified':bench['verified_exact'],
                    'worker_timing_medians_ms':bench['median_ms'],
                    'adaptive_selected':bench['selected']},
      'limitations':['No completed live Windows autonomous browser-cycle test',
        'No live installed Ollama inference test, microphone/camera or Meta Display test',
        'No independently qualified GPU acceleration',
        'Shadow, EmoVision, Meta archives bundled but not fully merged into one runtime',
        '606 lexer/syntax entries are not 606 complete compilers',
        'Chrome Bridge API lacks a cryptographically bound task correlation ID'],
      'manifest_signed':False,
    }
    mf=ROOT/'RELEASE_MANIFEST.json';mf.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
    with ZipFile(ARCHIVE,'w',ZIP_DEFLATED,compresslevel=7) as zipf:
        for p in [*files,mf]:zipf.write(p,p.relative_to(ROOT).as_posix())
    with ZipFile(ARCHIVE) as zipf:
        if zipf.testzip() is not None:raise RuntimeError('ZIP checksum failed')
    print(json.dumps({'archive':str(ARCHIVE),'total_files':len(files)+1,
       'unittests':tests,'native_qualified_cases':native,'bytes':ARCHIVE.stat().st_size,
       'sha256':digest(ARCHIVE)},indent=2))

if __name__=='__main__':build()
