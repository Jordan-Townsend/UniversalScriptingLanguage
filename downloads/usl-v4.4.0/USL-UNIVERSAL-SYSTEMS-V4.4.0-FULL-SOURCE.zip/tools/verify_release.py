"""Non-destructive SHA-256 file-integrity verifier for a distributed USL release.

This detects accidental changes and missing files. The manifest is not digitally
signed and therefore does NOT authenticate an untrusted download's publisher.
"""
import hashlib
import json
import sys
from pathlib import Path, PurePosixPath


def verify(root):
    root=Path(root).resolve()
    manifest=json.loads((root/'RELEASE_MANIFEST.json').read_text(encoding='utf8'))
    files=manifest['files']
    failures=[]
    for name, expected in files.items():
        part=PurePosixPath(name)
        if part.is_absolute() or '..' in part.parts or '\\' in name:
            failures.append({'path':name,'error':'unsafe path'})
            continue
        path=root.joinpath(*part.parts)
        if not path.is_file():
            failures.append({'path':name,'error':'missing'})
            continue
        h=hashlib.sha256()
        with path.open('rb') as fh:
            for block in iter(lambda:fh.read(1024*1024),b''):
                h.update(block)
        digest=h.hexdigest()
        if digest!=expected['sha256'] or path.stat().st_size!=expected['bytes']:
            failures.append({'path':name,'error':'size or checksum mismatch'})
    return {'verified':not failures,'version':manifest['version'],
            'expected_files':len(files),'errors':failures,'manifest_signed':False}

if __name__=='__main__':
    result=verify(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
    print(json.dumps(result,indent=2))
    sys.exit(0 if result['verified'] else 2)
