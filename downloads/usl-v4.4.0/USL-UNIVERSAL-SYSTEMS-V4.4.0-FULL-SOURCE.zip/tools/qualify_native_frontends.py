"""Conformance evidence for actual native syntax/type-check tools, trusted fixtures ONLY.

Negative checks must fail with a nonzero exit code. Not a runtime-equivalence claim.
The underlying compiler may execute compile-time code; never use untrusted input.
"""
from pathlib import Path
import json,sys,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'tests'))
from test_v13_native_syntax import SAMPLES as LEGACY
from test_v14_frontends import SAMPLES as ADDITIONAL
from usl_systems.native_syntax import check_source,available,CAPABILITIES

def main():
 fixtures={**LEGACY,**{k:v[:2] for k,v in ADDITIONAL.items()}}
 status=available();cases={};total=0;passed=0
 for language,(good,bad) in sorted(fixtures.items()):
  if not status[language]['installed']:
   cases[language]={'installed':False,'status':'unavailable'};continue
  results=[]
  for expected,src in (('valid',good),('invalid',bad)):
   t=time.monotonic()
   r=check_source(language,src,authorized=True,timeout=30)
   valid=(r['exit_code']==0 and r['syntax_valid']) if expected=='valid' else (r['exit_code']!=0 and not r['syntax_valid'])
   total+=1;passed+=bool(valid)
   results.append({'kind':expected,'passed':bool(valid),'exit_code':r['exit_code'],
    'tool':r['toolchain_path'],'source_sha256':r['source_sha256'],
    'diagnostics_tail':r['console_tail'][-1000:],'elapsed_ms':round((time.monotonic()-t)*1000,2),
    'verification_kind':r['verification_kind'],'semantic_equivalence_proven':False,
    'compile_time_code_may_execute':r.get('compile_time_code_may_execute')})
  cases[language]={'installed':True,'status':'passed' if all(r['passed'] for r in results) else 'failed','cases':results}
 result={'schema':'usl.native_frontends.evidence.v1','version':(ROOT/'VERSION').read_text().strip(),
         'installed_frontends':sum(v['installed'] for v in cases.values()),'cases_total':total,
         'cases_passed':passed,'all_passed':total>0 and passed==total,'evidence':cases,
         'does_not_prove_full_semantic_compilation':True}
 output=ROOT/'test_results'/f"v{result['version']}_native_frontend_cases.json"
 output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'output':str(output),'installed_frontends':result['installed_frontends'],
    'cases_passed':passed,'cases_total':total,'all_passed':result['all_passed']},indent=2))
 if not result['all_passed']:raise SystemExit(1)
if __name__=='__main__':main()
