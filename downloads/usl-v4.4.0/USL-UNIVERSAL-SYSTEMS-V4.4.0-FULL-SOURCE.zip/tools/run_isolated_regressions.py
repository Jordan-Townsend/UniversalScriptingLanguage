"""Fully qualified regression modules in independent monitored process groups.
No stdout pipes inherited by child processes; each module writes a dedicated log.
Timeouts are failures and terminate the launched test group on supported OSes.
"""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import os,re,subprocess,sys,json,time,signal
ROOT=Path(__file__).resolve().parents[1]
def source_snapshot():
    import hashlib
    files=sorted(p for folder in ('usl_systems','tools','tests','ui') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.js','.html','.css'))
    payload={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
version=(ROOT/'VERSION').read_text().strip()
initial_source_snapshot=source_snapshot()
folder=ROOT/'test_results';folder.mkdir(exist_ok=True)
files=sorted((ROOT/'tests').glob('test_*.py'))
def run(file):
    interpreter=os.environ.get('USL_NEURAL_PYTHON',sys.executable) if file.name=='test_v43_feature_fusion.py' else sys.executable
    argv=[interpreter,'-m','unittest','discover','-s','tests','-p',file.name]
    log=folder/('run_'+file.stem+'.log')
    options={'cwd':ROOT,'stdin':subprocess.DEVNULL}
    if os.name=='nt':options['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    else:options['start_new_session']=True
    with log.open('wb') as sink:
        proc=subprocess.Popen(argv,stdout=sink,stderr=subprocess.STDOUT,**options)
        expired=False
        try:code=proc.wait(timeout=35)
        except subprocess.TimeoutExpired:
            expired=True
            if os.name=='nt':
                subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=6)
            else:
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            try:code=proc.wait(timeout=5)
            except subprocess.TimeoutExpired:code=None
    output=log.read_text(errors='replace')
    matches=re.search(r'Ran (\d+) tests? in [0-9.]+s',output)
    count=int(matches.group(1)) if matches else 0
    skipped_match=re.search(r'skipped=(\d+)',output)
    skipped=int(skipped_match.group(1)) if skipped_match else 0
    ok=(not expired and code==0 and count>0 and re.search(r'\bOK(?:\s+\(skipped=\d+\))?\s*$',output) is not None)
    return {'file':file.name,'interpreter':interpreter,'tests':count,'tests_executed':count-skipped,'skipped':skipped,'passed':bool(ok),'exit_code':code,'timed_out':expired,'output_tail':output[-3000:]}

results=[]
# Native compiler processes and the HTTP repair test can interfere when launched
# simultaneously with other HTTP/inference modules. Qualify them serially first.
serial_names={'test_v11_observed_repair.py','test_v14_frontends.py','test_v15_semantic_holdouts.py','test_v16_plugins_arrays.py','test_v17_module_linker.py','test_v18_semantic_types.py','test_v19_module_contracts.py'}
for special in files:
    if special.name in serial_names:
        result=run(special)
        results.append(result)
        print(result['file'],result['tests'],'PASS' if result['passed'] else 'FAIL',flush=True)
files_parallel=[f for f in files if f.name not in serial_names]
with ThreadPoolExecutor(max_workers=3) as pool:
    futures={pool.submit(run,file):file for file in files_parallel}
    for future in as_completed(futures):
        result=future.result();results.append(result)
        print(result['file'],result['tests'],'PASS' if result['passed'] else 'FAIL',flush=True)
results.sort(key=lambda x:x['file'])
summary={'schema':'usl.isolated_regression.v2','count_files':len(files),'tests':sum(r['tests'] for r in results),
         'tests_executed':sum(r['tests_executed'] for r in results),'skipped':sum(r['skipped'] for r in results),
         'fully_exercised':all(r['skipped']==0 for r in results),'passed':all(r['passed'] for r in results),'files':results,
         'source_snapshot_sha256':initial_source_snapshot,'source_unchanged_during_run':initial_source_snapshot==source_snapshot()}
if not summary['source_unchanged_during_run']:summary['passed']=False
(folder/f'v{version}_isolated_regressions.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed':summary['passed'],'count_files':len(files),'tests':summary['tests'],
                  'failures':[r['file'] for r in results if not r['passed']]},indent=2),flush=True)
if not summary['passed']:raise SystemExit(1)
