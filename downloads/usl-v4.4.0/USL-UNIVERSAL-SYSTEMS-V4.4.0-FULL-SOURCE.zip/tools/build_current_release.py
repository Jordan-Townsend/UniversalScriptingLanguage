"""Reproducible flat-root source release; gates on actual isolated exits."""
from pathlib import Path
from hashlib import sha256
import json,zipfile,os,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/'VERSION').read_text().strip()
LOG=ROOT/'test_results'/f'v{VERSION}_isolated_regressions.json'
QUAL=ROOT/'test_results'/f'v{VERSION.replace(".", "")}_native_qualification.json'
# Current release uses 'v27' rather than 'v270' historic log naming
if not QUAL.exists(): QUAL=ROOT/'test_results'/f'v{VERSION}_native_qualification.json'
if not QUAL.exists(): QUAL=ROOT/'test_results'/('v'+VERSION.split('.')[0]+VERSION.split('.')[1]+'_native_qualification.json')
ARCHIVE=ROOT.parent/f'USL-UNIVERSAL-SYSTEMS-V{VERSION}-FULL-SOURCE.zip'
SKIP_PARTS={'__pycache__','.pytest_cache','.git','.venv'}
def sha(p):return sha256(p.read_bytes()).hexdigest()
def build():
    if not LOG.exists():raise RuntimeError('No full isolated regression run for '+VERSION)
    r=json.loads(LOG.read_text('utf8'))
    if not r.get('passed') or r.get('tests',0)<301 or not all(x['passed'] and x['exit_code']==0 for x in r['files']):
        raise RuntimeError('Regression gate has not passed')
    if not QUAL.exists():raise RuntimeError('No real native qualification evidence: '+str(QUAL))
    q=json.loads(QUAL.read_text('utf8'))
    passed=sum(x.get('passed',0) for x in q['qualification'].values())
    if passed!=40:raise RuntimeError('40/40 native qualification regression')
    executable_matrix=None
    if VERSION=='3.7.0':
        qualification=ROOT/'test_results/v3.7.0_qualification_summary.json'
        if not qualification.is_file():raise RuntimeError('Missing executable matrix qualification')
        executable_matrix=json.loads(qualification.read_text('utf8'))
        if (executable_matrix['catalog_entries']!=606 or
            executable_matrix['pair_matrix_cells']!=606*606 or
            executable_matrix['actual_executed_runtimes']<18 or
            executable_matrix['actual_executed_pairs']<257):
            raise RuntimeError('USL executable-matrix acceptance gate incomplete')
        details=json.loads((ROOT/'test_results/v3.7.0_executable_matrix_606x606.json').read_text('utf8'))
        grid=(ROOT/'test_results/v3.7.0_executable_matrix_606x606.bin').read_bytes()
        if len(grid)!=606**2 or hashlib.sha256(grid).hexdigest()!=details['matrix_sha256']:
            raise RuntimeError('606x606 executable routing-matrix checksum mismatch')
        if details['count_executed_verified']<257 or details['count_conditional_unverified']!=0:
            raise RuntimeError('Insufficient actual pairwise execution evidence')
        nested=json.loads((ROOT/'test_results/v3.7.0_eighteen_environments.json').read_text('utf8'))
        if not nested['all_verified'] or nested['verified']!=19 or nested['results']['usl']['value']!=12997:
            raise RuntimeError('18-environment nested execution gate failed')
    v40_gate=None
    if VERSION=='4.0.0':
        gatefile=ROOT/'test_results/v4.0.0_qualification_summary.json'
        if not gatefile.exists():raise RuntimeError('v4.0.0 executable-domain acceptance gate is missing')
        v40_gate=json.loads(gatefile.read_text('utf8'))
        if (v40_gate.get('status')!='passed' or v40_gate.get('new_catalog_executable_scopes',0)<10 or
            v40_gate.get('abilities_reused_in_real_usl_graph',0)<10 or
            v40_gate.get('catalog_entries_accounted_for')!=606):
            raise RuntimeError('v4.0.0 accepted language execution/ability-reuse contract not met')
    v41_gate=None
    if VERSION=='4.1.0':
        domain=json.loads((ROOT/'test_results/v4.1.0_domains.json').read_text('utf8'))
        reuse=json.loads((ROOT/'test_results/v4.1.0_ability_reuse.json').read_text('utf8'))
        ledger=json.loads((ROOT/'test_results/v4.1.0_606_expansion_plan.json').read_text('utf8'))
        matrix=json.loads((ROOT/'test_results/v4.1.0_executable_typed_matrix.json').read_text('utf8'))
        bench=json.loads((ROOT/'test_results/v4.1.0_benchmark.json').read_text('utf8'))
        provenance=json.loads((ROOT/'test_results/v4.1.0_toolchain_provenance.json').read_text('utf8'))
        if (r['tests'] < 482 or r['count_files'] < 55 or not domain['all_passed']
            or domain['newly_qualified_count'] < 10 or domain['tests_passed'] != domain['tests_run']
            or not reuse['all_17_new_artifacts_consumed'] or not reuse['parallel_partial_graph']['all_verified']
            or not reuse['usl_composition_graph']['all_verified'] or reuse['usl_composed_stdout']!='302\n'
            or ledger['catalog_total']!=606 or ledger['unqualified_entries']!=553
            or ledger['fully_semantically_complete']!=0 or matrix['ordered_cells']!=367236
            or matrix['tested_typed_handoff_cells']!=289 or len(matrix['cells'])!=289
            or not bench['repeated_outputs_verified'] or len(provenance['languages'])!=17):
            raise RuntimeError('v4.1 multi-language expansion/worker/corpus/606 evidence gate incomplete')
        v41_gate={'new_verified_executable_subsets':domain['newly_qualified_count'],
            'positive_and_negative_cases':domain['tests_passed'],
            'catalog_total':ledger['catalog_total'],
            'catalog_any_qualified_subset':ledger['total_executable_subsets'],
            'full_language_specifications_proven':ledger['fully_semantically_complete'],
            'real_typed_artifact_handoffs':matrix['tested_typed_handoff_cells'],
            'actual_usl_composed_stdout':reuse['usl_composed_stdout'],
            'median_8_vs_1_observed_speedup':bench['observed_speedup_one_to_eight']}
    files=sorted((p for p in ROOT.rglob('*') if p.is_file() and not set(p.relative_to(ROOT).parts)&SKIP_PARTS
         and p.suffix not in ('.pyc','.pyo') and p.name!='RELEASE_MANIFEST.json' and not p.name.endswith('.pid')),
         key=lambda p:p.relative_to(ROOT).as_posix())
    hashes={p.relative_to(ROOT).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in files}
    recovered=[k for k in hashes if k.lower().endswith('.zip') and ('recovered' in k.lower() or 'sources/' in k.lower())]
    if len(recovered)<6:raise RuntimeError('Six original recovered source archives are missing: '+str(recovered))
    benchmark=json.loads((ROOT/'test_results/v3.7.0_matrix_parallel_benchmark.json').read_text('utf8')) if VERSION=='3.7.0' else None
    if VERSION=='3.7.0' and (not benchmark['source_output_match'] or benchmark['pairs']!=20):
        raise RuntimeError('Verified serial/parallel matrix benchmark missing')
    manifest={'schema':'usl.release.manifest.v2','version':VERSION,'files':hashes,
       'verification':{'linux_regressions':r['tests'],'test_modules':r['count_files'],'all_exits_zero':True,
                       'native_subset_passed':passed,'native_qualified_runtimes':sum(v.get('toolchain_installed',False) for v in q['qualification'].values()),
                       'nested_bridge_actual_native':True},
       'matrix_benchmark':benchmark,
       'new_domain_language_qualification':v40_gate,
       'expanded_domain_qualification':v41_gate,
       'language_claims':{'catalog':606,'full_semantic_compilers_verified':0,
                          'tested_executable_catalog_subsets':executable_matrix['catalog_entries_executed'] if executable_matrix else None,
                          'tested_runtime_environment_count':executable_matrix['actual_executed_runtimes'] if executable_matrix else None,
                          'tested_two_stage_pairs':executable_matrix['actual_executed_pairs'] if executable_matrix else None,
                          'routable_pair_cells':606*606,
                          'native_bridge_claim':'only documented positive and negative execution cases; no full-language equivalence'},
       'hardware_limits':['Windows hardware not tested','No physical Meta device qualification','Live Shadow voice and Ollama untested'],
       'manifest_signed':False}
    mf=ROOT/'RELEASE_MANIFEST.json';mf.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
    with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in [*files,mf]:z.write(p,p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(ARCHIVE) as z:
        if z.testzip() is not None:raise RuntimeError('ZIP member corruption')
        for name,info in hashes.items():
            if sha256(z.read(name)).hexdigest()!=info['sha256']:raise RuntimeError('File hash mismatch: '+name)
    return {'archive':str(ARCHIVE),'tests':r['tests'],'files':len(files)+1,'sha256':sha(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'recovered_archives':len(recovered)}
if __name__=='__main__':print(json.dumps(build(),indent=2))
