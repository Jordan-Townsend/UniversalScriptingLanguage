import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.module_contracts import validate_contracts
p=json.loads((ROOT/'examples/contracts.uslproject.json').read_text())
positive=validate_contracts(p)
p2={**p,'modules':{**p['modules'],'main':'use math\nprint(double("wrong type"))'}}
negative=validate_contracts(p2)
r={'schema':'usl.contract_qualification.v1','positive_verified':positive['valid'] and positive['locally_verified_checks']>=2,
   'negative_rejected':not negative['valid'],'positive':positive,'negative':negative,
   'native_contract_enforcement_proven':False,'fully_sound_type_system':False}
path=ROOT/'test_results'/f"v{(ROOT/'VERSION').read_text().strip()}_contract_qualification.json"
path.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'path':str(path),'positive_verified':r['positive_verified'],'negative_rejected':r['negative_rejected']},indent=2))
if not (r['positive_verified'] and r['negative_rejected']):raise SystemExit(1)
