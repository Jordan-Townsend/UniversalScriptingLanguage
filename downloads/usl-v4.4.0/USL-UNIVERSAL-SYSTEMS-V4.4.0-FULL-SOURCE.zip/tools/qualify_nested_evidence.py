"""Extract actual qualified guest-to-guest program transitions, not pairwide proof."""
import json,platform,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'examples/nested_seven_languages.uslnest.json').read_text('utf8'))
report=json.loads((ROOT/'test_results/v29_seven_engines.json').read_text('utf8'))
if not report.get('all_verified'):raise SystemExit('Nested demonstration did not pass')
byid={n['id']:n for n in manifest['nodes']}
transitions=[]
for n in manifest['nodes']:
    for arg in n['args']:
        if isinstance(arg,dict) and 'ref' in arg:
            src=arg['ref'];from_node=byid[src]
            a=report['results'][src];b=report['results'][n['id']]
            if a['status']!='verified' or b['status']!='verified':raise SystemExit('Unverified evidence')
            transitions.append({'from':from_node['language'],'to':n['language'],
                                'source_id':src,'destination_id':n['id'],
                                'source_sha256':a['source_sha256'],'destination_sha256':b['source_sha256'],
                                'observed_values':[a['value'],b['value']],
                                'evidence':'observed_success_for_these_exact_programs_only'})
commands={k:v for k,v in {'python':[sys.executable,'--version'],'node':['node','--version'],
                            'ruby':['ruby','--version'],'php':['php','--version'],
                            'gcc':['gcc','--version']}.items()}
tools={}
for name,command in commands.items():
    try:
        p=subprocess.run(command,capture_output=True,text=True,timeout=4)
        tools[name]={'exit_code':p.returncode,'version':(p.stdout or p.stderr).splitlines()[0] if p.stdout or p.stderr else None}
    except Exception as exc:tools[name]={'available':False,'error':type(exc).__name__}
qualification={'schema':'usl.cross_language.evidence.v1','platform':platform.platform(),
  'guest_runtime_versions':tools,'seven_language_program_passed':True,
  'guest_nodes':len(report['results']),'verified_transitions':transitions,
  'no_pairwide_semantic_completeness_claim':True,'all_606_complete':False,
  'authorization_required_for_native_source':True}
p=ROOT/'test_results/v29_cross_language_edges.json';p.write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'verified_transitions':len(transitions),'node_count':len(report['results']),'record':str(p)},indent=2))
