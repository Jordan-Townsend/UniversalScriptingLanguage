"""Strong release-specific acceptance gate for 15 new executable capabilities."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
def get(path):return json.loads((ROOT/'test_results'/path).read_text('utf8'))
def report():
    run=get('v4.0.0_isolated_regressions.json')
    if not run['passed'] or run['tests']<470 or run['count_files']<54:
        raise RuntimeError('Complete regression gate missing or failed')
    native=get('v4.0.0_native_qualification.json')
    n=sum(v.get('passed',0) for v in native['qualification'].values())
    if n!=40:raise RuntimeError('Native qualification does not pass 40 cases')
    domain=get('v4.0.0_domains_first_run.json')
    if not domain['all_verified'] or domain['new_executable_subsets_qualified']<10 or domain['passed_executions']!=domain['test_executions']:
        raise RuntimeError('Ten new actual executable scopes not qualified')
    coop=get('v4.0.0_cooperative_languages.json')
    if not coop['all_verified'] or coop['verified_count']<16 or coop['max_active_observed']<2:raise RuntimeError('USL partial workers not qualified')
    reuse=get('v4.0.0_ability_reuse.json')
    if not reuse['all_15_artifacts_consumed'] or not reuse['actual_usl_graph']['all_verified']:
        raise RuntimeError('Discovered abilities have not been reused in actual USL workflows')
    ledger=get('v4.0.0_language_606_qualification.json')
    if ledger['catalog_records']!=606 or ledger['new_domain_language_execution_subsets']<10 or ledger['fully_semantically_complete_languages_proven']!=0:
        raise RuntimeError('606 ledger misstates real coverage')
    benchmark=get('v4.0.0_worker_benchmark.json')
    if not benchmark['both_outputs_verified']:raise RuntimeError('Performance routes not verified')
    result={'schema':'usl.v4.0.0.qualifications.final','status':'passed',
      'regression_cases_passed':run['tests'],'test_modules':run['count_files'],
      'native_cases_passed':n,'new_catalog_executable_scopes':domain['new_executable_subsets_qualified'],
      'reviewed_actual_new_engine_executions_passed':domain['passed_executions'],
      'new_language_ids':domain['qualified_catalog_ids'],
      'cooperative_tasks_verified':coop['verified_count'],
      'max_active_cooperative_workers_observed':coop['max_active_observed'],
      'abilities_reused_in_real_usl_graph':len(reuse['reused_capabilities']),
      'catalog_entries_accounted_for':606,'catalog_entries_with_any_tested_scope':ledger['total_tested_catalog_subsets'],
      'whole_language_specifications_proven':0,'bench_speedup':benchmark['observed_speedup'],
      'windows_execution_tested':False,'hardware_gpu_tested':False,'new_domain_entries_are_not_native_general_purpose_compilers':True}
    dest=ROOT/'test_results/v4.0.0_qualification_summary.json'
    dest.write_text(json.dumps(result,indent=2)+'\n','utf8')
    return result
if __name__=='__main__':print(json.dumps(report(),indent=2))
