"""Qualify four real installed runtime branches, emit machine-readable evidence."""
from pathlib import Path
import json,tempfile,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.cooperative_workers import CooperativeScheduler
from usl_systems.native import tool_available

def main():
    targets=('python','javascript','ruby','php')
    missing=[x for x in targets if not tool_available(x)]
    if missing:
        print('MISSING ACTUAL RUNTIMES:',missing)
        raise SystemExit(2)
    g=json.loads((ROOT/'examples/cooperative_native_targets.json').read_text())
    with tempfile.TemporaryDirectory() as td:
        cache=Path(td)/'state.json';runner=CooperativeScheduler(threads=4,processes=0,allow_native=True)
        first=runner.run(g,checkpoint=cache);second=runner.run(g,checkpoint=cache)
    native_rows=[first['tasks']['verify_'+x] for x in targets]
    overlap=(max(x['started_ns'] for x in native_rows)<min(x['finished_ns'] for x in native_rows))
    all_passed=first['all_verified'] and second['all_verified'] and all(x['value']['status']=='passed' for x in native_rows)
    fresh_native=all(not second['tasks']['verify_'+x]['cache_reused'] for x in targets)
    evidence={'schema':'usl.native.cooperation.qualification.v1','real_installed_target_runtimes':list(targets),
      'all_native_results_verified':all_passed,'actual_interval_overlap':overlap,'native_reexecuted_after_checkpoint':fresh_native,
      'pure_module_link_reused':second['tasks']['compile_link']['cache_reused'],
      'first_cycle_ms':first['elapsed_ms'],'second_cycle_ms':second['elapsed_ms'],
      'native_results':{name:{'observed':first['tasks']['verify_'+name]['value'].get('observed'),
          'elapsed_ms':first['tasks']['verify_'+name]['elapsed_ms']} for name in targets},
      'claims_limited_to_tested_USL_program':True,'Windows_hardware_tested':False}
    (ROOT/'test_results/v2.1.0_native_cooperation.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(evidence,indent=2))
    if not(all_passed and overlap and fresh_native and evidence['pure_module_link_reused']):raise SystemExit(1)
if __name__=='__main__':main()
