"""Run approved reviewed-source behavioral tests in parallel; export all-606 ledger."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from usl_systems.semantic_conformance import qualify,ledger,negative_syntax,scoped_compatibility_matrix,qualify_python_js_shim
p=argparse.ArgumentParser()
p.add_argument('--approve-reviewed-source',action='store_true')
p.add_argument('--workers',type=int,default=4)
p.add_argument('--output',default='test_results/v3.9.0_semantic_feature_qualification.json')
p.add_argument('--ledger',default='test_results/v3.9.0_semantic_606_ledger.json')
a=p.parse_args()
try:
 q=qualify(authorized=a.approve_reviewed_source,workers=a.workers)
 n=negative_syntax(authorized=a.approve_reviewed_source)
 q['negative_syntax']=n
 q['pair_scoped_semantics']=scoped_compatibility_matrix(q)
 q['python_to_js_bounded_shim']=qualify_python_js_shim(authorized=a.approve_reviewed_source)
 f=ROOT/a.output;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(q,indent=2,ensure_ascii=False)+'\n')
 g=ROOT/a.ledger;g.parent.mkdir(parents=True,exist_ok=True);g.write_text(json.dumps(ledger(root=ROOT,qualification=q),indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'passed':q['passed'],'tests':q['test_count'],'all_passed':q['all_passed'],
 'negative_tests_passed':n['passed'],'catalog':606,'certified_complete':0,'output':str(f),'ledger':str(g)}))
 if not q['all_passed'] or not n['all_passed'] or q['python_to_js_bounded_shim']['status']!='observed_pass':raise SystemExit(1)
except ValueError as e:
 print(str(e),file=sys.stderr);raise SystemExit(2)
