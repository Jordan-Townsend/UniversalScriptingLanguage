"""Verify additional engines and a grounded perception/USL learning workflow."""
from __future__ import annotations
import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.entity import Entity,EntitySession
from usl_systems.entity_memory import fingerprint
from usl_systems.language_qualification import qualify,fixture
from usl_systems.language_runtime import catalog_readiness
from usl_systems.cooperative_workers import CooperativeScheduler

def run():
    folder=ROOT/'test_results'
    def save(name,value):(folder/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
    languages=qualify();save('v4.3.0_language_qualification.json',languages)
    if not languages['all_passed']:raise RuntimeError('new upstream language engines failed')
    coverage=catalog_readiness(languages);save('v4.3.0_606_coverage.json',coverage)
    observation=json.loads((folder/'v4.3.0_neural/observation.json').read_text())
    expected=json.loads((folder/'v4.3.0_neural/heldout_digit_expected.json').read_text())
    if observation['evidence']['predicted_digit']!=expected['label']:
        raise RuntimeError('preselected heldout perception case failed')
    imports={'lesson':json.loads((ROOT/'examples/entity_lesson.json').read_text()),'vision':observation}
    (ROOT/'examples/entity_imports.json').write_text(json.dumps(imports,indent=2)+'\n')
    source=(ROOT/'examples/entity_learning.usl').read_text()
    with tempfile.TemporaryDirectory(prefix='usl-entity-proof-') as root:
        entity=Entity(root)
        result=EntitySession(entity,imports,approved=True).interpret(source)
        expected_stdout='25\n\nmemory persisted\nperception recorded\n'
        if result['stdout']!=expected_stdout:raise RuntimeError('entity .usl workflow failed')
        restarted=Entity(root)
        restart=restarted.execute_skill('double_plus_one',17,'35\n')
        if not restart['outcome_verified'] or not restarted.memory.retrieve('double integer'):
            raise RuntimeError('restart learning/memory proof failed')
        studied=restarted.memory.study_document(ROOT/'examples/study_notes.md')
        if not restarted.memory.retrieve('residual convolutional'):raise RuntimeError('document study retrieval failed')
        p1=restarted.memory.remember_fact('test-device','temperature',20,{'source':'synthetic sensor fixture A'})
        p2=restarted.memory.remember_fact('test-device','temperature',30,{'source':'synthetic sensor fixture B'})
        if p1['memory_id'] not in p2['conflicting_memory_ids']:raise RuntimeError('conflict preservation failed')
        # A new instance must never auto-replay an interrupted native action.
        restarted.memory.save_run('crashed-external','running',{'pending_action':{'kind':'native_source'}})
        recovered=Entity(root,recover_interrupted=True)
        if recovered.memory.run('crashed-external')['state']!='needs_review':raise RuntimeError('restart side-effect guard failed')
        graph={'schema':'usl.cooperative.graph.v1','tasks':[]}
        for index,language in enumerate(sorted(fixture_language_ids())):
            f=fixture(language)
            graph['tasks'].append({'id':f'language{index}','kind':'language_execute','inputs':{'language':language,'source':f['source'],'context':f['context']}})
        language_ids=[t['id'] for t in graph['tasks']]
        graph_source=source
        binding={}
        for index,language in enumerate(sorted(fixture_language_ids())):
            binding['tool'+str(index)]=f'language{index}'
            graph_source+='let tool'+str(index)+' = artifact('+json.dumps('tool'+str(index))+')\n'
            graph_source+='assert tool'+str(index)+'["actual_native_execution"]\n'
            graph_source+='assert tool'+str(index)+'["language"] == '+json.dumps(language)+'\n'
        graph_source+='print("native tools verified", '+str(len(language_ids))+')\n'
        graph['tasks'].append({'id':'entity','kind':'entity_program','deps':language_ids,
            'inputs':{'source':graph_source,'imports':imports,'data_root':root},'bind':binding})
        graph['tasks'].append({'id':'compress','kind':'compress','deps':['entity'],'inputs':{'text':source}})
        graph['tasks'].append({'id':'numeric','kind':'fractal','deps':['entity'],'inputs':{'values':[2,4,6,8],'operator':'sum_squares'}})
        graph['tasks'].append({'id':'joined','kind':'join_evidence','deps':['entity','compress','numeric']})
        scheduled=CooperativeScheduler(threads=3,processes=0,allow_native=True,max_in_flight=3).run(graph,cache=False)
        if not scheduled['all_verified'] or scheduled['tasks']['entity']['value']['stdout']!=expected_stdout+'native tools verified 12\n':
            raise RuntimeError('cooperative language/entity graph failed: '+str(scheduled['blocked_or_failed']))
        if scheduled['tasks']['numeric']['value']['result']!=120:raise RuntimeError('numeric reference failed')
        save('v4.3.0_entity_application.json',{'schema':'usl.entity.application.v4.3','all_verified':True,'program':result,
            'restart':restart,'document_study':studied,'conflict':p2,'perception':observation,'graph':scheduled,'new_native_outputs_consumed':len(language_ids),
            'general_human_equivalence':False,'physical_sensors_qualified':False,'real_ollama_qualified':False})
    summary={'all_verified':True,'additional_entries':languages['new_entries'],'additional_cases':languages['passed_cases'],
        'subset_evidence':coverage['subset_evidence'],'unqualified_entries':coverage['unqualified_entries'],
        'full_specifications_qualified':0,'entity_stdout':result['stdout'],'graph_tasks':scheduled['verified_count']}
    save('v4.3.0_qualification_summary.json',summary)
    return summary

def fixture_language_ids():
    from usl_systems.language_runtime import CONTRACTS
    return CONTRACTS

if __name__=='__main__':print(json.dumps(run(),indent=2))
