"""Proof plus actual native holdout executions for an explicit integer intent.

This proves only the declared pure function arithmetic. ABI, IO and compiler
correctness remain separate obligations; no full-language claim is produced.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.intent_contracts import prove_usl,prove_native
from usl_systems.compiler import transpile
from usl_systems.native import verify,tool_available
from usl_systems.entity_memory import fingerprint

CONTRACT={'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-1000000,'max':1000000}},'postcondition':'result == value * 2',
    'intent':'Return twice the input integer; independently check one printed result.',
    'unmodelled_obligations':['whole-program IO equivalence','ABI','compiler implementation correctness','libraries','general-language semantics']}

def source(value):return f'function twice(value):\n    return value * 2\nprint(twice({value}))\n'

def run():
    report={'schema':'usl.translation.intent.qualification.v1','contract':CONTRACT,
        'usl_proof':prove_usl(source(21),'twice',CONTRACT),'targets':[],
        'arbitrary_source_translation_complete':False,'full_specifications_qualified':0}
    for language in ('python','javascript','typescript','c','cpp','go','rust','ruby','php','java','lua','csharp'):
        emitted=transpile(source(21),language).code
        proof=prove_native(emitted,language,'twice',CONTRACT)
        cases=[]
        for value in (-1000000,-17,0,1,21,1000000):
            observed=verify(source(value),language,timeout=20)
            passed=observed['status']=='passed' and observed.get('native',{}).get('stdout')==str(value*2)+'\n'
            cases.append({'input':value,'expected_stdout':str(value*2)+'\n','passed':passed,'native_evidence':observed})
        report['targets'].append({'language':language,'native_ast_proof':proof,
            'generated_source_sha256':fingerprint(emitted),'cases':cases,
            'declared_case_checks_passed':all(c['passed'] for c in cases),'full_semantic_translation':False})
    report['function_proofs_passed']=sum(t['native_ast_proof']['proved'] for t in report['targets'])
    report['native_holdout_cases_passed']=sum(c['passed'] for t in report['targets'] for c in t['cases'])
    report['declared_profile_all_checks_passed']=report['usl_proof']['proved'] and all(t['native_ast_proof']['proved'] and t['declared_case_checks_passed'] for t in report['targets'])
    (ROOT/'test_results/v4.4.0_translation_intent.json').write_text(json.dumps(report,indent=2)+'\n')
    return {k:report[k] for k in ('function_proofs_passed','native_holdout_cases_passed','declared_profile_all_checks_passed','arbitrary_source_translation_complete')}

if __name__=='__main__':print(json.dumps(run(),indent=2))
