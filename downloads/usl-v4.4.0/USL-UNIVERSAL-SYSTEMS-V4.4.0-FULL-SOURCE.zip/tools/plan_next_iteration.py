"""Turn unfinished, versioned acceptance criteria into a deterministic next prompt."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    data=json.loads((ROOT/'docs/ITERATION_BACKLOG.json').read_text())
    todo=sorted(data['not_verified'],key=lambda x:x['priority'])
    if not todo:raise SystemExit('No pending tasks in backlog; check real qualification before declaring completion')
    top=next((x for x in todo if not x.get("blocked_in_current_linux_environment")),todo[0])
    text=['# Next USL Development Iteration — generated checkpoint',
          '',f"Continue from verified version {data['base_version']} source without rebuilding working modules.",
          '',f"## First unresolved milestone: {top['id']}",top['goal'],'',
          '## Unfinished master architecture (retained until independently verified)',
          *[f"- {x['id']}: {x['goal']}" + (" [REQUIRES HARDWARE QUALIFICATION]" if x.get("blocked_in_current_linux_environment") else "") for x in todo],
          '', '## Required execution contract',
          '1. Re-run complete regression suite and actual installed native compiler qualifications before changing source.',
          '2. Recover and use the six bundled original V0.31/Chrome V3/Shadow V87/EmoVision V63/Meta V53 archives; never silently replace existing installations.',
          '3. Implement real source and tests for the highest-impact feasible unverified milestone; do not stop at a plan.',
          '4. Run correctness checks and end-to-end baseline comparisons, including negative/security cases and actual stdout/exit status.',
          '5. Do not conflate 606 lexer recognizers with verified semantic compilers, or simulated devices with real hardware.',
          '6. On unavailable Windows/GPU/camera/microphone/glasses hardware, record the explicit blocker and keep working on other testable independent capabilities.',
          '7. Store test logs, qualification report, source hashes, release metadata, and update machine-readable backlog evidence.',
          '8. Produce a single flat full-source ZIP including all six recovered archives, complete source, scripts, next generated prompt, and honest limitations.',
          '9. Repeat generation of this prompt from newly verified criteria and execute the next feasible development cycle when tools and time permit.',
          '', '**Start implementing the first feasible unfinished capability immediately.**','']
    output=ROOT/'NEXT_ITERATION_PROMPT.md';output.write_text('\n'.join(text),encoding='utf8')
    print(f'Wrote: {output}; next milestone={top["id"]}; remaining={len(todo)}')
if __name__=='__main__':main()
