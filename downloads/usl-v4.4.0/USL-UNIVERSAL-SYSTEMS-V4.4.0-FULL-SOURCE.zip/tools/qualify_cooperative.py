"""Real cooperative worker qualification; evidence includes cache integrity and lanes."""
import json,sys,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.cooperative_workers import CooperativeScheduler

def main():
    graph=json.loads((ROOT/'examples/cooperative_development.json').read_text())
    with tempfile.TemporaryDirectory(prefix='usl-cooperate-') as td:
        checkpoint=Path(td)/'checkpoint.json'
        first=CooperativeScheduler(threads=3,processes=2).run(graph,checkpoint=checkpoint)
        second=CooperativeScheduler(threads=3,processes=2).run(graph,checkpoint=checkpoint)
    numeric=first['tasks']['numerical_lab']
    result={'schema':'usl.cooperative.qualify.v1','graph_sha256':first['graph_sha256'],
       'first_run_all_verified':first['all_verified'],'second_run_all_verified':second['all_verified'],
       'tasks_verified_first':first['verified_count'],'tasks_verified_second':second['verified_count'],
       'verified_reuse_second':second['reused_verified_partials'],
       'numeric_verified':numeric['value']['verified_exact'],'numeric_from_os_process':numeric['lane']=='process',
       'equation_result':numeric['value']['result'],'verified_runtime_output':first['tasks']['run']['value']['stdout'],
       'integration_sha256':first['tasks']['integrate_evidence']['value']['evidence_sha256'],
       'threads_max':3,'processes_max':2,
       'first_elapsed_ms':first['elapsed_ms'],'second_elapsed_ms':second['elapsed_ms'],
       'classification':'Actual worker process, local source/inference-free tests, no real GPU/Windows qualification'}
    output=ROOT/'test_results/v2.0.0_cooperative_qualification.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not (result['first_run_all_verified'] and result['second_run_all_verified'] and
            result['tasks_verified_first']==7 and result['verified_reuse_second']==7 and
            result['numeric_verified'] and result['numeric_from_os_process'] and result['equation_result']==139):
        raise SystemExit(1)
if __name__=='__main__':main()
