"""Reproducible actual native module linkage qualification."""
import json,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.module_linker import from_file
from usl_systems.native import verify,tool_available
project=from_file(ROOT/'examples/modules.uslproject.json')
results=[]
for target in ('python','javascript','ruby','php'):
 if tool_available(target):
  result=verify(project['source'],target)
  results.append({'target':target,'status':result['status'],
                  'native_exit_code':result.get('native',{}).get('returncode'),
                  'stdout':result.get('native',{}).get('stdout'),
                  'expected':result.get('expected_output'),
                  'error':result.get('error') or result.get('native',{}).get('stderr','')})
report={'schema':'usl.module.qualification.v1','source_sha256':project['output_sha256'],
        'topological_order':project['order'],'tested':len(results),
        'passed':sum(x['status']=='passed' for x in results),
        'all_passed':bool(results) and all(x['status']=='passed' for x in results),
        'results':results,'qualifies_full_module_system':False}
path=ROOT/'test_results'/f"v{(ROOT/'VERSION').read_text().strip()}_module_qualification.json"
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(path),'passed':report['passed'],'tested':len(results)},indent=2))
if not report['all_passed']:raise SystemExit(1)
