"""Release gate for exact source tree, preserving six recovered archives."""
from __future__ import annotations
import hashlib,json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/'VERSION').read_text().strip()
NAME=f'USL-UNIVERSAL-SYSTEMS-V{VERSION}-FULL-SOURCE.zip'

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def build():
    isolate=json.loads((ROOT/f'test_results/v{VERSION}_isolated_regressions.json').read_text())
    if not isolate.get('passed') or len(isolate.get('files',[]))!=len(list((ROOT/'tests').glob('test_*.py'))):
        raise RuntimeError('Isolated complete-module test evidence missing')
    for result in isolate['files']:
        recorded=(ROOT/'test_results'/('run_'+Path(result['file']).stem+'.log')).read_text(errors='replace')
        match=re.search(r'Ran (\d+) tests? in [\d.]+s\s+OK(?:\s+\(skipped=(\d+)\))?\s*$',recorded)
        if not match or int(match.group(1))!=result['tests'] or int(match.group(2) or 0)!=result.get('skipped',0) or not result['passed'] or result['exit_code']!=0:
            raise RuntimeError('Test evidence invalid: '+result['file'])
    total=sum(x['tests'] for x in isolate['files'])
    if total<201:raise RuntimeError('Test count regressed from latest 201 cases')
    quali=json.loads((ROOT/f'test_results/v{VERSION}_native_qualification.json').read_text())
    passed=sum(v.get('passed',0) for v in quali['qualification'].values())
    if passed<40:raise RuntimeError('Native qualification regressed below 40/40')
    snapshots=sorted(p for folder in ('usl_systems','tools','tests','ui') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.js','.html','.css'))
    hashes={p.relative_to(ROOT).as_posix():digest(p) for p in snapshots}
    current=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
    if current!=isolate.get('source_snapshot_sha256') or not isolate.get('source_unchanged_during_run'):
        raise RuntimeError('Regression source evidence is stale')
    if VERSION=='4.2.0':
        from usl_systems.source_engines import CONTRACTS
        sources=json.loads((ROOT/'test_results/v4.2.0_source_qualification.json').read_text())
        graph=json.loads((ROOT/'test_results/v4.2.0_application.json').read_text())
        ledger=json.loads((ROOT/'test_results/v4.2.0_606_coverage.json').read_text())
        matrix=json.loads((ROOT/'test_results/v4.2.0_typed_matrix.json').read_text())
        if (not sources['all_passed'] or sources['passed_cases']!=72 or sources['new_catalog_entries']!=18
            or not graph['graph']['all_verified'] or graph['stdout']!='18\n374\n96\n'
            or ledger['total_subset_evidence']!=71 or ledger['unqualified_entries']!=535
            or ledger['full_specifications_qualified']!=0 or matrix['typed_artifact_handoffs']!=324):
            raise RuntimeError('v4.2 source/application/coverage evidence gate failed')
    if VERSION in ('4.3.0','4.4.0'):
        from usl_systems.language_runtime import CONTRACTS
        language=json.loads((ROOT/'test_results/v4.3.0_language_qualification.json').read_text())
        coverage=json.loads((ROOT/'test_results/v4.3.0_606_coverage.json').read_text())
        application=json.loads((ROOT/'test_results/v4.3.0_entity_application.json').read_text())
        neural=json.loads((ROOT/'test_results/v4.3.0_neural/benchmark.json').read_text())
        if (not language['all_passed'] or language['passed_cases']!=48 or language['new_entries']!=len(CONTRACTS)
            or coverage['subset_evidence']!=83 or coverage['unqualified_entries']!=523 or coverage['full_specifications_qualified']!=0
            or not application['all_verified'] or not application['graph']['all_verified']
            or application['new_native_outputs_consumed']!=12 or not application['restart']['outcome_verified']
            or application['general_human_equivalence'] or application['real_ollama_qualified']):
            raise RuntimeError('v4.3 language/entity evidence gate failed')
        if neural['architecture_sha256']!=digest(ROOT/'usl_systems/feature_fusion.py'):
            raise RuntimeError('Neural architecture evidence stale')
        model=ROOT/'test_results/v4.3.0_neural'/neural['bundle']['file']
        if model.parent!=ROOT/'test_results/v4.3.0_neural' or digest(model)!=neural['bundle']['sha256']:
            raise RuntimeError('Neural model bundle integrity failed')
        if len(neural['records'])!=6 or any(r['initial_baseline_equivalence_max_abs_error']!=0 for r in neural['records']):
            raise RuntimeError('Neural equivalence/benchmark evidence missing')
        neural_tests=next((r for r in isolate['files'] if r['file']=='test_v43_feature_fusion.py'),None)
        if not neural_tests or neural_tests['tests_executed']!=7 or neural_tests['skipped']:
            raise RuntimeError('Optional neural tests must actually execute for this release')
    if VERSION=='4.4.0':
        from usl_systems.catalog_backends import PROFILES
        sweep=json.loads((ROOT/'test_results/v4.4.0_sweep/full_606_sweep.json').read_text())
        intent=json.loads((ROOT/'test_results/v4.4.0_translation_intent.json').read_text())
        if (sweep['inventory_accounted_for']!=606 or sweep['initial_remaining']!=523
            or sweep['new_profiles_attempted']!=len(PROFILES) or sweep['new_profiles_passed']!=len(PROFILES)
            or not sweep['factored']['verified_exact'] or sweep['initial_task_complete']
            or sweep['full_specifications_qualified']!=0 or not intent['declared_profile_all_checks_passed']
            or intent['function_proofs_passed']!=12 or intent['native_holdout_cases_passed']!=72):
            raise RuntimeError('v4.4 backend/proof evidence invalid or completion overclaimed')
    if not (ROOT/'NEXT_ITERATION_PROMPT.md').is_file():raise RuntimeError('Missing next-iteration prompt')
    if not (ROOT/'docs/ITERATION_BACKLOG.json').is_file():raise RuntimeError('Missing machine-readable backlog')
    files=sorted([p for p in ROOT.rglob('*') if p.is_file() and p.name!='RELEASE_MANIFEST.json'
              and not any(x in p.parts for x in ('__pycache__','.pytest_cache','.git','node_modules','.venv'))
              and p.suffix not in ('.pyc','.pyo')],key=lambda p:p.relative_to(ROOT).as_posix())
    manifest={'schema':'usl.verified.release.v5','version':VERSION,
       'files':{p.relative_to(ROOT).as_posix():{'sha256':digest(p),'bytes':p.stat().st_size} for p in files},
       'actual_testing':{'linux_isolated_unittest_cases_enumerated':total,
           'linux_isolated_unittest_cases_passed':isolate.get('tests_executed',total),
           'skipped_tests':isolate.get('skipped',0),'fully_exercised':isolate.get('fully_exercised',True),
           'native_subset_cases_passed':passed,
           'windows_installer_qualified':False,'real_local_ollama_qualified':False,
           'full_606_semantic_compilers':False,'live_browser_qualified':False,
           'gpu_acceleration_qualified':False,'real_camera_meta_qualified':False},
       'next_prompt':'NEXT_ITERATION_PROMPT.md','backlog':'docs/ITERATION_BACKLOG.json'}
    recovered=[p for p in files if p.parent.name=='legacy_sources' and p.suffix=='.zip']
    if len(recovered)!=6:raise RuntimeError('Six recovered archives must be retained')
    manifest['recovered_archive_sha256']={p.relative_to(ROOT).as_posix():digest(p) for p in recovered}
    if VERSION=='4.2.0':manifest['v4.2_evidence']={'new_source_entries':18,'positive_negative_boundary_cases':72,'typed_artifact_handoffs':324,'historical_plus_new_subsets':71,'fully_qualified_specifications':0}
    if VERSION in ('4.3.0','4.4.0'):manifest['v4.3_evidence']={'additional_source_entries':12,'positive_negative_boundary_cases':48,
        'historical_plus_new_subsets':83,'fully_qualified_specifications':0,'entity_workflow_verified':True,
        'neural_zero_residual_equivalence':True,'neural_universal_superiority':False,
        'paired_mean_accuracy_difference':neural['mean_accuracy_difference'],'trained_model_sha256':neural['bundle']['sha256'],
        'physical_sensory_equivalence':False,'live_ollama_inference':False}
    if VERSION=='4.4.0':manifest['v4.4_evidence']={'initial_remaining_inventory':523,
        'new_native_and_format_profiles':sweep['new_profiles_passed'],
        'historical_plus_new_subsets':sweep['historical_plus_new_subsets'],
        'unqualified_entries':sweep['unqualified_entries'],'fully_semantic_translated_languages':0,
        'full_606_objective_complete':False,'bounded_function_proofs':12,'native_intent_cases':72,
        'proof_scope':'explicit bounded pure integer function; other semantics unproved'}
    (ROOT/'RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    target=ROOT.parent/NAME
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for f in [*files,ROOT/'RELEASE_MANIFEST.json']:
            z.write(f,f.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        m=json.loads(z.read('RELEASE_MANIFEST.json'))
        for name,record in m['files'].items():
            assert hashlib.sha256(z.read(name)).hexdigest()==record['sha256'],name
    print(json.dumps({'output':str(target),'sha256':digest(target),'files':len(files)+1,
       'unittests':total,'native_cases':passed,'bytes':target.stat().st_size},indent=2))

if __name__=='__main__':build()
