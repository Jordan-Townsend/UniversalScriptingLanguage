"""Demonstrate real reuse of newly qualified language-family abilities in USL.

Consumes executed artifacts (not declared capability labels), verifies basic
structure, constructs a task graph from parsed configuration, and executes it.
"""
import argparse,hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.cooperative_workers import CooperativeScheduler
from usl_systems.domain_execution import FIXTURES

def sha(x):return hashlib.sha256(x).hexdigest()
def run(artifacts):
    folder=Path(artifacts);files={k: next(folder.glob(k.replace('+','_')+'.*'),None) for k in FIXTURES}
    if any(p is None for p in files.values()):raise ValueError('Missing executed language artifact: '+str([k for k,p in files.items() if p is None]))
    raw={k:p.read_bytes() for k,p in files.items()}
    yaml=json.loads(raw['yaml']);toml=json.loads(raw['toml']);ini=json.loads(raw['ini']);j5=json.loads(raw['json5']); j=json.loads(raw['json']); templ=json.loads(raw['yaml+jinja'])
    html=json.loads(raw['html']);css=json.loads(raw['css']);
    assert yaml['version']==4 and len(yaml['workers'])==2
    assert toml['execution']['workers']==4 and ini['workers']==4 and templ['workers']==5
    assert j5['release']=='v4' and j['engine']=='USL'
    assert html['href']=='/usl/v4' and css['color']=='navy'
    assert b'<strong>' in raw['markdown'] and b'<em>' in raw['restructuredtext']
    assert b'<summary>17</summary>' in raw['xslt'] and raw['xml']==b'qualified'
    assert raw['postscript'].startswith(b'%PDF') and raw['tex'].startswith(b'DVI')
    svg=ET.fromstring(raw['graphviz']);assert svg.tag.endswith('svg')
    # The configuration languages determine actual scheduler parameters.
    cpu=__import__('os').cpu_count() or 1
    threads=min(cpu,toml['execution']['workers'],ini['workers'],templ['workers'],8)
    # The values come from independently parsed YAML/TOML/INI config.
    total=yaml['version']+toml['execution']['workers']+ini['workers']
    usl='let x = '+str(total)+'\nprint(x * 2)'
    evidences={k:{'sha256':sha(contents),'bytes':len(contents)} for k,contents in raw.items()}
    source=json.dumps(evidences,sort_keys=True,separators=(',',':'))
    graph={'schema':'usl.cooperative.graph.v1','tasks':[
      {'id':'interpret','kind':'interpreter','inputs':{'source':usl}},
      {'id':'numeric','kind':'fractal','inputs':{'values':[yaml['version'],ini['workers'],toml['execution']['workers']],'operator':'sum_squares','workers':2}},
      {'id':'compress','kind':'compress','inputs':{'text':source}},
      {'id':'validated','kind':'join_evidence','deps':['interpret','numeric','compress']},
    ]}
    out=CooperativeScheduler(threads=threads,processes=0,allow_native=False).run(graph,cache=False)
    if not out['all_verified']:raise RuntimeError('Reused USL task graph failed: '+str(out['blocked_or_failed']))
    if out['tasks']['interpret']['value']['stdout']!='24\n':raise RuntimeError('Parsed config was not used in computation')
    return {'schema':'usl.discovered.abilities.reuse.v1','all_15_artifacts_consumed':True,
       'scheduler_threads_from_actual_parsed_configuration':threads,
       'reused_capabilities':{k:{'task_scope':FIXTURES[k][0],'artifact_sha256':evidences[k]['sha256']}
                                for k in FIXTURES},
       'actual_usl_graph':out,'config_derived_usl_output':'24',
       'notes':'Each newly qualified language skill supplies a tested artifact or a concrete configuration input. No universal performance improvement claimed.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--artifacts',default='test_results/v4.0.0_artifacts')
    p.add_argument('--output',default='test_results/v4.0.0_ability_reuse.json');a=p.parse_args()
    result=run(ROOT/a.artifacts)
    path=ROOT/a.output;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf8')
    print(json.dumps({'verified':result['all_15_artifacts_consumed'],'skills':len(result['reused_capabilities']),
       'graph_verified':result['actual_usl_graph']['all_verified'],
       'scheduler_threads':result['scheduler_threads_from_actual_parsed_configuration'],'file':str(path)},indent=2))
