"""Executable v4.2 source fleet, .usl application and reused existing subsystems."""
from __future__ import annotations
import argparse,json,sys,time,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.source_engines import CONTRACTS,SourceSession,digest
from usl_systems.source_qualification import fixture,qualify,ledger,matrix
from usl_systems.cooperative_workers import CooperativeScheduler
from usl_systems.adaptive import AdaptiveExecutor
from usl_systems.ir import lower,restore
from usl_systems.store import Store

def application_source(include_imports=True):
    lines=['# Real native engine outputs consumed by USL; no fabricated language routes.']
    names=[];scores=[]
    for i,id_ in enumerate(sorted(CONTRACTS)):
        f=fixture(id_);c=CONTRACTS[id_];name=f'engine{i}';names.append(name)
        lines.append(f'let {name} = engine_run({json.dumps(id_)}, {json.dumps(f["source"])}, {repr(f["context"])})')
        root=name+'["value"]'
        if c['engine']=='graphql':score=root+'["data"]["twice"]'
        elif c['engine']=='dtd' or c['host']=='xml':score='int('+root+'["text"])'
        elif c['host']=='javascript':score='int('+root+'["stdout"])'
        elif c['host']=='css':score='len('+root+'["declarations"][0]["value"])'
        elif c['host']=='html':score='len('+root+'["text"])'
        else:score='len('+root+'["rendered"])'
        scores.append(score)
    lines.extend(['let scores = ['+', '.join(scores)+']','assert len(scores) == 18','assert sum(scores) == 374','print(len(scores))','print(sum(scores))'])
    if include_imports:
        lines.extend([
            'let native_total = artifact("cython")["observed"]["result"] + artifact("llvm")["observed"]["jit_result"] + artifact("sparql")["observed"]["workers"] + artifact("protobuf")["observed"]["workers"]',
            'assert native_total == 96', 'print(native_total)',
            'let dashboard = engine_run("html+django", "<html><body><h1>USL source fleet</h1><output>Engines: {{ count }}; source score: {{ score }}; native result: {{ native }}</output></body></html>", {"count": len(scores), "score": sum(scores), "native": native_total})',
            'let dashboard_html = dashboard["value"]["rendered"]'])
    return '\n'.join(lines)+'\n'

def application_graph(source):
    tasks=[]
    for i,id_ in enumerate(sorted(CONTRACTS)):
        f=fixture(id_)
        tasks.append({'id':f'source{i}','kind':'source_execute','inputs':{'language':id_,'source':f['source'],'context':f['context']}})
    tasks.append({'id':'source_join','kind':'join_evidence','deps':[t['id'] for t in tasks]})
    tasks.append({'id':'application','kind':'source_program','deps':['source_join','cython','llvm','sparql','protobuf'],
        'inputs':{'source':source},'bind':{key:key for key in ('cython','llvm','sparql','protobuf')}})
    tasks.append({'id':'numeric','kind':'fractal','deps':['application'],'bind':{'values':'application.scores'},'inputs':{'operator':'sum_squares','workers':4,'leaf_size':4}})
    tasks.append({'id':'compress','kind':'compress','deps':['application'],'inputs':{'text':source}})
    for lang in ('cython','llvm','sparql','protobuf'):
        tasks.append({'id':lang,'kind':'domain_expand','deps':['source_join'],'inputs':{'language':lang}})
    tasks.append({'id':'complete','kind':'join_evidence','deps':['application','numeric','compress','cython','llvm','sparql','protobuf']})
    return {'schema':'usl.cooperative.graph.v1','tasks':tasks}

def run(output_folder=None):
    folder=Path(output_folder or ROOT/'test_results');folder.mkdir(parents=True,exist_ok=True)
    def save(name,value):
        (folder/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    report=qualify(workers=4)
    save('v4.2.0_source_qualification.json',report)
    if not report['all_passed']:raise RuntimeError('Source engine qualification failed')
    baseline=json.loads((ROOT/'test_results/v4.1.0_606_expansion_plan.json').read_text('utf8'))
    coverage=ledger(report,baseline);transport=matrix(report)
    save('v4.2.0_606_coverage.json',coverage);save('v4.2.0_typed_matrix.json',transport)
    source=application_source();graph=application_graph(source)
    (ROOT/'examples/source_fleet.usl').write_text(source,encoding='utf8')
    (ROOT/'examples/native_sources.usl').write_text(application_source(include_imports=False),encoding='utf8')
    (ROOT/'examples/source_fleet.coop.json').write_text(json.dumps(graph,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    ir=lower(source)
    # This IR stores the USL capability calls; native-language IR stays separate.
    assert restore(ir) is not None
    save('v4.2.0_source_application_ir.json',ir)
    start=time.perf_counter()
    journal=Store();job='source-'+uuid.uuid4().hex[:18]
    journal.create(job,'source-fleet',{'source_sha256':digest(source),'engines':sorted(CONTRACTS)})
    journal.update(job,'running')
    outcome=CooperativeScheduler(threads=4,processes=0,allow_native=True,max_in_flight=4).run(graph,cache=False)
    if not outcome['all_verified']:
        journal.update(job,'failed',outcome['blocked_or_failed'])
        raise RuntimeError(str(outcome['blocked_or_failed']))
    program=outcome['tasks']['application']['value']
    if program['stdout']!='18\n374\n96\n' or len(program['evidence'])!=19:raise RuntimeError('Actual USL application result mismatch')
    if 'native result: 96' not in program['dashboard_html']:raise RuntimeError('Dashboard did not consume native outputs')
    (folder/'v4.2.0_dashboard.html').write_text(program['dashboard_html'],encoding='utf8')
    values=program['scores'];numeric=outcome['tasks']['numeric']['value']
    if numeric['result']!=sum(x*x for x in values):raise RuntimeError('Dependent numeric exactness failed')
    adaptive=AdaptiveExecutor(workers=4,leaf_size=4).choose(values,repeats=3)
    if not adaptive['verified_exact'] or adaptive['value']!=numeric['result']:raise RuntimeError('Adaptive route mismatch')
    save('v4.2.0_application.json',{'schema':'usl.source.application.v4.2','graph':outcome,'adaptive':adaptive,
        'all_18_source_artifacts_used':True,'stdout':program['stdout'],'source_sha256':digest(source),
        'elapsed_ms':round((time.perf_counter()-start)*1000,3),'subsystems':[
            'USL interpreter','USL semantic IR','native source parser IR','CooperativeScheduler',
            'FactoredFractal','Collapse compression','AdaptiveExecutor','Cython BuildCache',
            'LLVM MCJIT','SPARQL','Protobuf','typed artifact matrix']})
    summary={'schema':'usl.release.qualification.v4.2','new_catalog_entries':18,'source_cases_passed':report['passed_cases'],
        'catalog_inventory':606,'observed_subset_entries':coverage['total_subset_evidence'],
        'unqualified_entries':coverage['unqualified_entries'],'full_specifications_qualified':0,
        'typed_handoff_cells':transport['typed_artifact_handoffs'],'actual_usl_stdout':program['stdout'],
        'bounded_graph_tasks':outcome['verified_count'],'all_verified':True}
    save('v4.2.0_qualification_summary.json',summary)
    journal.update(job,'completed',summary)
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output-folder');a=p.parse_args()
    print(json.dumps(run(a.output_folder),indent=2))
