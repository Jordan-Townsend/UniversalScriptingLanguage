"""Discover additional real engines without claiming they are qualified.
Never download, install, trust, or execute unreviewed source from discovery.
"""
from pathlib import Path
import importlib.util,json,shutil,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.catalog import load_catalog
from usl_systems.domain_execution import FIXTURES

PROBES={
'protobuf':('python','google.protobuf','binary message encoding and roundtrip; must test actual descriptor/schema handling'),
'jsonld':('python','rdflib','JSON-LD RDF parsing and graph statement semantics'),
'sql+jinja':('python','jinja2','parameterized Jinja template plus isolated SQL engine'),
'asymptote':('command','asy','compile reviewed vector graphics script'),
'nginx':('command','nginx','validate and run versioned Nginx config in isolated test instance'),
'jsonbareobject':('python','json5','real non-strict JSON object parsing with reference conformance'),
'gnuplot':('command','gnuplot','render generated plots using independent data oracle'),
'bibtex':('command','bibtex','compile referenced bibliography from aux/bib fixtures'),
'jsonnet':('command','jsonnet','actual Jsonnet language interpreter and standards'),
'graphql':('python','graphql','GraphQL schema validation, parsing, and query execution'),
}

def main():
    ids={x['id'] for x in load_catalog()};rows=[]
    prior=json.loads((ROOT/'test_results/v4.0.0_language_606_qualification.json').read_text('utf8'))
    already={row['catalog_id'] for row in prior['entries'] if row['qualification']!='unverified_execution'}
    for lang,(kind,name,capability) in PROBES.items():
        if lang not in ids:continue
        if lang in FIXTURES or lang in already:continue
        try:present=bool(importlib.util.find_spec(name)) if kind=='python' else bool(shutil.which(name))
        except (ImportError,AttributeError,ValueError):present=False
        rows.append({'catalog_id':lang,'engine_kind':kind,'provider':name,'available':present,
            'qualification':'not_implemented_or_verified','next_actual_test':capability})
    result={'schema':'usl.language.engine.candidate.discovery.v4.0','candidates':rows,
      'discovered_available_engine_candidates':sum(row['available'] for row in rows),
      'qualified_by_discovery':0,
      'meaning':'Engine presence enables a future reviewed qualifier; it does NOT qualify language semantics.'}
    dest=ROOT/'test_results/v4.0.0_next_language_engine_discovery.json'
    dest.write_text(json.dumps(result,indent=2)+'\n','utf8')
    print(json.dumps({'output':str(dest),'candidates':len(rows),'engine_present':result['discovered_available_engine_candidates'],
                       'names':[x['catalog_id'] for x in rows if x['available']]},indent=2))

if __name__=='__main__':main()
