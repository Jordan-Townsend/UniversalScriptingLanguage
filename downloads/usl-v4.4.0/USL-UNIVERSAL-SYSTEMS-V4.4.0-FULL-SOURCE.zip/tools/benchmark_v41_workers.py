"""Measured end-to-end new engine execution with 1 vs 8 real threads."""
import json,statistics,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tools.reuse_v41_abilities import run

def benchmark():
    art=ROOT/'test_results/v4.1.0_artifacts';runs={}
    # alternate to reduce thermal/cold-bias and report medians, not a promise
    for n in (1,8,8,1,1,8):
        result=run(art,threads=n)
        if result['usl_composed_stdout']!='302\n':raise RuntimeError('Output mismatch')
        runs.setdefault(str(n),[]).append(result['elapsed_ms'])
    med={k:statistics.median(v) for k,v in runs.items()}
    return {'schema':'usl.benchmark.v4.1','runs_ms':runs,'median_ms':med,
      'observed_speedup_one_to_eight':round(med['1']/med['8'],4),'repeated_outputs_verified':True,
      'scope':'17 reviewed engine executions and 1 USL join on this Linux host; process/compiler cold/warm effects may vary; not universal speedup'}
if __name__=='__main__':
    r=benchmark();(ROOT/'test_results/v4.1.0_benchmark.json').write_text(json.dumps(r,indent=2)+'\n','utf8')
    print(json.dumps(r,indent=2))
