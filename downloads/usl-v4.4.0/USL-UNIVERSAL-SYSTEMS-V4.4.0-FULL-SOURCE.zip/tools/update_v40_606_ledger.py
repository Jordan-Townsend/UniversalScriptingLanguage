"""Merge historical native fixture evidence with new domain execution qualification.
Existing native evidence is preserved, never relabelled as full spec support.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.domain_execution import discovered

def build():
 prior=json.loads((ROOT/'test_results/v3.8.0_all_606_execution_status.json').read_text('utf8'))
 new=json.loads((ROOT/'test_results/v4.0.0_domains_first_run.json').read_text('utf8'))
 if not new['all_verified'] or new['new_executable_subsets_qualified']<10:raise ValueError('Insufficient verified executable capabilities')
 native={x['id'] for x in prior['entries'] if x['execution_status']=='observed_fixture_execution'}
 records=discovered()
 added=set(new['qualified_catalog_ids'])
 if native & added:raise ValueError('Language not newly added; overlaps historic runtime evidence: '+str(native&added))
 if len(prior['entries'])!=606 or len({r['id'] for r in prior['entries']})!=606:raise ValueError('Catalog mismatch')
 rows=[]
 for old in prior['entries']:
  key=old['id']
  if key in added:
   row={'catalog_id':key,'qualification':'observed_domain_language_execution_subset',
        'scope':records[key]['capability_scope'],'provider':records[key]['provider'],
        'evidence_source_sha256':records[key]['source_sha256'],
        'complete_language_specification':False,
        'next_dependency':'Authoritative full spec version, exhaustive semantic feature tests, platform tests'}
  elif key in native:
   row={'catalog_id':key,'qualification':'previously_observed_guest_fixture_subset',
        'scope':'v3.8 previously qualified adapter','provider':old.get('adapter'),
        'evidence_source_sha256':None,'complete_language_specification':False,
        'next_dependency':'Full semantic conformance and source-language frontend'}
  else:
   row={'catalog_id':key,'qualification':'unverified_execution','scope':None,'provider':None,
        'evidence_source_sha256':None,'complete_language_specification':False,
        'next_dependency':'Real language-family engine and reviewed runnable qualification'}
  rows.append(row)
 result={'schema':'usl.language.qualification.ledger.v4.0.0','catalog_records':606,
    'previous_guest_subsets':len(native),'new_domain_language_execution_subsets':len(added),
    'total_tested_catalog_subsets':len(native|added),'fully_semantically_complete_languages_proven':0,
    'catalog_not_execution_qualified':606-len(native|added),'previous_executable_pairs_preserved':401,
    'new_domain_pair_semantics':'not qualified as arbitrary-language pairwise code calls; capability artifacts used through USL task graph',
    'newly_added':sorted(added),'entries':rows}
 dest=ROOT/'test_results/v4.0.0_language_606_qualification.json';dest.write_text(json.dumps(result,indent=2)+'\n','utf8')
 return {'output':str(dest),'catalog':len(rows),'new':len(added),'qualified_total':len(native|added)}
if __name__=='__main__':print(json.dumps(build(),indent=2))
