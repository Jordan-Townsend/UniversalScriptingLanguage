"""Qualify closed-world typed arrays against interpreter and actual native runtimes."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.module_contracts import validate_contracts
from usl_systems.module_linker import link_project
from usl_systems.native import verify,tool_available
SOURCE={'schema':'usl.module_project.v1','entry':'main','modules':{
 'main':'use array_math\nlet xs = [4, 5, 6]\nprint(second(xs))',
 'array_math':'function second(values):\n    return values[1]'},
 'contracts':{'array_math.second':{'params':['int[3]'],'returns':'int'}}}
report=validate_contracts(SOURCE)
source=link_project(SOURCE)['source']
results={name:verify(source,name) for name in ('python','javascript','ruby','php')}
missing=[name for name,record in results.items() if record['status']=='toolchain_missing']
if missing:raise SystemExit('Missing qualifying runtime(s): '+str(missing))
pass_count=sum(r['status']=='passed' for r in results.values())
negative={}
for case,main in {'element':'use array_math\nprint(second(["a", "b", "c"]))',
                  'length':'use array_math\nprint(second([2, 3]))'}.items():
 p={**SOURCE,'modules':{**SOURCE['modules'],'main':main}}
 negative[case]=validate_contracts(p)
proof={'schema':'usl.typed.array.qualification.v1','source_hash':report['linked_source_sha256'],
 'typed_contract_valid':report['valid'],'native_passes':pass_count,'native_targets':list(results),
 'negative_element_rejected':not negative['element']['valid'],
 'negative_length_rejected':not negative['length']['valid'],
 'real_native_reports':results,'static_contracts_only':True,'complete_606_compilers':False}
output=ROOT/'test_results'/f'v{(ROOT/"VERSION").read_text().strip()}_typed_array_qualification.json'
output.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'native_passes':pass_count,'negative_element_rejected':proof['negative_element_rejected'],
 'negative_length_rejected':proof['negative_length_rejected'],'report':str(output)},indent=2))
if not (report['valid'] and pass_count==4 and all((proof['negative_element_rejected'],proof['negative_length_rejected']))):raise SystemExit(1)
