"""Collect actual installed runtime identities, separate from vendor claims."""
import importlib.metadata,hashlib,json,platform,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.expanded_domains import SPEC,SOURCES,digest,discover

def run():
    engines=discover();tools={}
    for entry in engines.values():
        provider=entry['provider']
        if provider in tools:continue
        if provider.startswith('python:'):
            module=provider.split(':',1)[1]
            package=module.split('.')[0]
            try:version=importlib.metadata.version({'google':'protobuf','llvmlite':'llvmlite'}.get(package,package))
            except importlib.metadata.PackageNotFoundError:version='installed_version_unknown'
            tools[provider]={'category':'python_package','import_name':module,'package_version':version}
        else:
            path=shutil.which(provider)
            if not path:tools[provider]={'installed':False};continue
            p=Path(path)
            try:version=subprocess.run([path,'--version'],timeout=5,capture_output=True,text=True).stdout[:150]
            except Exception:version='version_flag_unavailable'
            tools[provider]={'category':'native_executable','resolved_path':str(p.resolve()),
                'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':p.stat().st_size,'version_banner':version.strip()}
    return {'schema':'usl.toolchain.provenance.v4.1','platform':platform.platform(),'python':sys.version,
      'languages':{k:{'provider':v['provider'],'reviewed_source_sha256':digest(SOURCES[k][0]),
                      'fixture_spec_version':'usl.domain.expansion.v4.1'} for k,v in engines.items()},
      'engines':tools,'full_specification_certified':0}
if __name__=='__main__':
    result=run();out=ROOT/'test_results/v4.1.0_toolchain_provenance.json'
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf8')
    print(json.dumps({'providers':len(result['engines']),'languages':len(result['languages']),'output':str(out)},indent=2))
