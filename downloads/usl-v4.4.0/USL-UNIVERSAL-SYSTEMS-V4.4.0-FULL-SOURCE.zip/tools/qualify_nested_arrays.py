"""Cross-check 2D and 3D closed-world USL arrays with actual installed runtimes."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from usl_systems.module_contracts import validate_contracts
from usl_systems.module_linker import link_project
from usl_systems.native import verify

def project(shape,main,lib):
 return {'schema':'usl.module_project.v1','entry':'main',
  'modules':{'main':main,'matrix':lib},'contracts':{'matrix.pick':{'params':[shape],'returns':'int'}}}
rows=[]
for name,shape,main,lib in [
 ('matrix2d','int[2,2]','use matrix\nprint(pick([[1,2],[3,4]]))','function pick(grid):\n    return grid[1][0]'),
 ('matrix3d','int[1,2,2]','use matrix\nprint(pick([[[1,2],[3,4]]]))','function pick(grid):\n    return grid[0][1][0]')]:
 p=project(shape,main,lib);report=validate_contracts(p)
 native={target:verify(link_project(p)['source'],target) for target in ('python','javascript','ruby','php')}
 rows.append({'case':name,'static_valid':report['valid'],'native':native,
              'native_passes':sum(x['status']=='passed' for x in native.values())})
negative=validate_contracts(project('int[2,2]','use matrix\nprint(pick([[1],[3]]))','function pick(grid):\n    return grid[1][0]'))
r={'schema':'usl.nested_array.qualification.v1','cases':rows,'negative_known_shape_rejected':not negative['valid'],
  'scope':'2D and 3D fixed-shape arrays within restricted USL grammar',
  'full_606_compilers_proven':False,'native_contract_enforcement_proven':False}
path=ROOT/'test_results'/f'v{(ROOT/"VERSION").read_text().strip()}_nested_array_qualification.json'
path.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'actual_native_executions_passed':sum(x['native_passes'] for x in rows),
 'negative_known_shape_rejected':r['negative_known_shape_rejected'],'report':str(path)},indent=2))
if not(r['negative_known_shape_rejected'] and len(rows)==2 and all(x['static_valid'] and x['native_passes']==4 for x in rows)):
 raise SystemExit(1)
