@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m usl_systems fractal --count 20000 --repeat 32 --workers 4 --processes --auto
exit /b %errorlevel%
