@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m unittest -v tests.test_dag_bindings tests.test_bridge_report tests.test_syntax_validation tests.test_v07_http tests.test_recovered_runtime) else (python -m unittest -v tests.test_dag_bindings tests.test_bridge_report tests.test_syntax_validation tests.test_v07_http tests.test_recovered_runtime)
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
