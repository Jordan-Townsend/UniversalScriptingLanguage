@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul && (py -3 tools\plan_next_iteration.py & exit /b %errorlevel%)
python tools\plan_next_iteration.py
exit /b %errorlevel%
