import json, tempfile, unittest
from pathlib import Path
from usl_systems.domain_execution import FIXTURES, INVALID, EXPECTED, DomainError, discovered, qualify, run
from usl_systems.cooperative_workers import CooperativeScheduler

class ReviewedLanguageCapabilities(unittest.TestCase):
    def test_catalog_and_new_coverage(self):
        registry=discovered()
        self.assertGreaterEqual(len(registry),10)
        self.assertEqual(len(registry),len(FIXTURES))
        self.assertTrue(all(x['installed'] for x in registry.values()))
        self.assertTrue(all(not x['whole_specification_complete'] for x in registry.values()))

    def test_all_reviewed_engine_real_execution(self):
        with tempfile.TemporaryDirectory() as temp:
            for lang in FIXTURES:
                with self.subTest(lang=lang):
                    result=run(lang,approved=True,artifacts=temp)
                    self.assertTrue(result['verified'])
                    self.assertEqual(result['engine_exit_code'],0)
                    self.assertTrue((Path(temp)/result['artifact']).stat().st_size>0)
                    self.assertEqual(result['source_sha256'],discovered()[lang]['source_sha256'])

    def test_negative_variants_are_rejected(self):
        for lang in INVALID:
            with self.subTest(lang=lang):
                result=run(lang,approved=True,variant='invalid')
                self.assertTrue(result['verified'])
                self.assertNotEqual(result['engine_exit_code'],0)

    def test_explicit_approval_and_unknowns(self):
        with self.assertRaises(DomainError):run('graphviz')
        with self.assertRaises(DomainError):run('inexistent',approved=True)
        with self.assertRaises(DomainError):qualify(workers=8)
        with self.assertRaises(DomainError):qualify(workers=99,approved=True)

    def test_cooperative_graph_approval(self):
        graph={'schema':'usl.cooperative.graph.v1','tasks':[
            {'id':'lang','kind':'domain_qualify','inputs':{'language':'toml'}}]}
        denied=CooperativeScheduler(threads=2,processes=0,allow_native=False).run(graph,cache=False)
        self.assertFalse(denied['all_verified'])
        approved=CooperativeScheduler(threads=2,processes=0,allow_native=True).run(graph,cache=False)
        self.assertTrue(approved['all_verified'])
        self.assertEqual(approved['tasks']['lang']['value']['language'],'toml')

    def test_actual_multi_worker_conformance(self):
        report=qualify(workers=6,approved=True,include_negative=True)
        self.assertTrue(report['all_verified'])
        self.assertGreaterEqual(report['new_executable_subsets_qualified'],10)
        self.assertEqual(report['passed_executions'],report['test_executions'])
        self.assertTrue(all(not row['whole_language_specification_complete'] for row in report['results']))

if __name__=='__main__':unittest.main()
