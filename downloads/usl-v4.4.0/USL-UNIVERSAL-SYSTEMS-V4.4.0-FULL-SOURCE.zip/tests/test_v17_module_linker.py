import unittest
from usl_systems.module_linker import link_project,LinkError,SCHEMA
from usl_systems.language import Interpreter
from usl_systems.native import verify,tool_available
PROJECT={'schema':SCHEMA,'entry':'main','modules':{
 'main':'use derived\nlet x = [5, 7, 9]\nprint(compute(x[1]))',
 'derived':'use base\nfunction compute(x):\n    return twice(x) + 3',
 'base':'function twice(x):\n    return x * 2'}}
class ModuleLinkTests(unittest.TestCase):
 def test_order_hashes_and_actual_interpreter_execution(self):
  r=link_project(PROJECT)
  self.assertEqual(r['order'],['base','derived','main'])
  self.assertEqual(Interpreter().run(r['source']).output,'17\n')
  self.assertEqual(len(r['modules']),3)
  self.assertFalse(r['general_module_system_complete'])
 def test_native_cross_module_compiler_output(self):
  r=link_project(PROJECT)
  for target in ('python','javascript','ruby','php'):
   if not tool_available(target):continue
   with self.subTest(target=target):
    out=verify(r['source'],target)
    self.assertEqual(out['status'],'passed',out)
 def test_missing_and_cycle(self):
  p={**PROJECT,'modules':{**PROJECT['modules'],'derived':'use no_such_module\nfunction compute(x):\n    return x'}}
  with self.assertRaises(LinkError):link_project(p)
  p={**PROJECT,'modules':{**PROJECT['modules'],'base':'use main\nfunction twice(x):\n    return x * 2'}}
  with self.assertRaises(LinkError):link_project(p)
 def test_no_arbitrary_imports_or_effects(self):
  for bad in ('import os','print("side effect")','open("/tmp/out", "w")'):
   p={**PROJECT,'modules':{**PROJECT['modules'],'base':bad}}
   with self.subTest(bad=bad),self.assertRaises((LinkError,Exception)):
    link_project(p)
 def test_function_collision_and_wrong_arity(self):
  p={**PROJECT,'modules':{**PROJECT['modules'],'derived':'use base\nfunction twice(x):\n    return x'}}
  with self.assertRaises(LinkError):link_project(p)
  p={**PROJECT,'modules':{**PROJECT['modules'],'main':'use derived\nprint(compute(3,4))'}}
  with self.assertRaises(LinkError):link_project(p)
 def test_missing_source_and_path_traversal(self):
  for name in ('../file','/tmp/a',''):
   p={**PROJECT,'modules':{**PROJECT['modules'],name:'print(1)'}}
   with self.assertRaises(LinkError):link_project(p)
if __name__=='__main__':unittest.main()
