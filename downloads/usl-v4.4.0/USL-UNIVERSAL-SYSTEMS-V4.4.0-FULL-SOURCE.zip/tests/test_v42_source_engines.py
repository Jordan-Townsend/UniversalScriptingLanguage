import copy, json, math, tempfile, unittest
from pathlib import Path
from usl_systems.source_engines import CONTRACTS,SourceError,SourceSession,execute,restore
from usl_systems.source_qualification import fixture,qualify,ledger,matrix
from usl_systems.cooperative_workers import CooperativeScheduler
from usl_systems.language import Interpreter,USLError

ROOT=Path(__file__).resolve().parents[1]
class NativeSourceEngines(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report=qualify(workers=4)
    def test_eighteen_exact_new_catalog_entries_execute(self):
        self.assertEqual(len(CONTRACTS),18)
        self.assertTrue(self.report['all_passed'],[(e['catalog_id'],e['cases']) for e in self.report['entries'] if not e['passed']])
        self.assertEqual(self.report['cases'],72)
        self.assertEqual(self.report['passed_cases'],72)
        from usl_systems.semantic_plugins import Registry
        stages=Registry().resolve('graphql').stages
        self.assertIn('native_source_import',stages)
        self.assertIn('native_source_execution',stages)
    def test_source_import_is_general_not_fixture_selection(self):
        result=execute('django','{% for x in values %}{{ x }};{% endfor %}',{'values':['a','café',3]},approved=True)
        self.assertEqual(result['value']['rendered'],'a;café;3;')
        result=execute('mako','${sum(values)}',{'values':[8,3,5]},approved=True)
        self.assertEqual(result['value']['rendered'],'16')
        result=execute('graphql','{ echo(text: "independent") twice(x: 13) }',approved=True)
        self.assertEqual(result['value']['data'],{'echo':'independent','twice':26})
    def test_general_source_ast_and_roundtrip(self):
        f=fixture('django');r=execute('django',f['source'],f['context'],approved=True)
        self.assertEqual(restore(r['source_ir']),f['source'])
        self.assertTrue(r['source_ir']['ast'])
        self.assertEqual(r['source_ir']['source_map']['start_line'],1)
        self.assertFalse(r['full_spec_qualified'])
    def test_tampered_source_and_ast_are_rejected(self):
        f=fixture('django');r=execute('django',f['source'],f['context'],approved=True)
        for field,value in [('source','changed'),('ast',[]),('context_sha256','0'*64)]:
            bad=copy.deepcopy(r['source_ir']);bad[field]=value
            with self.assertRaises(SourceError):restore(bad)
    def test_graphql_static_type_validation(self):
        for query,context in [('{ unknown }',{}),('query($value:Int!){twice(x:$value)}',{'value':'text'}),('{twice(x:2147483648)}',{})]:
            with self.subTest(query=query),self.assertRaises(SourceError):execute('graphql',query,context,approved=True)
    def test_dtd_actual_document_validation(self):
        f=fixture('dtd')
        with self.assertRaises(SourceError):execute('dtd',f['source'],{'document':'<task><wrong/></task>'},approved=True)
        with self.assertRaises(SourceError):execute('dtd','<!ENTITY external SYSTEM "file:///etc/passwd">',approved=True)
    def test_permissions_and_capability_budgets(self):
        f=fixture('django')
        with self.assertRaises(SourceError):execute('django',f['source'])
        with self.assertRaises(SourceError):execute('unknown',f['source'],approved=True)
        session=SourceSession(approved=True,max_calls=1)
        session.run('django',f['source'],f['context'])
        with self.assertRaises(SourceError):session.run('django',f['source'],f['context'])
        with self.assertRaises(USLError):Interpreter().run('engine_run("django", "text", {})')
    def test_input_bounds_and_finite_context(self):
        for context in [{'x':math.nan},['not','an','object'],{'x':'a'*17000}]:
            with self.assertRaises(SourceError):execute('django','text',context,approved=True)
        with self.assertRaises(SourceError):execute('django','x'*32769,approved=True)
        with self.assertRaises(SourceError):execute('django','text',approved=True,timeout=20)
    def test_native_timeout_and_descendant_cleanup(self):
        with self.assertRaisesRegex(SourceError,'timed out'):
            execute('javascript+php','<?php echo "while(true) {}";',approved=True,timeout=.5)
    def test_native_programs_are_not_checkpoint_replayed(self):
        f=fixture('graphql')
        graph={'schema':'usl.cooperative.graph.v1','tasks':[{'id':'query','kind':'source_execute','inputs':{'language':'graphql','source':f['source'],'context':f['context']}}]}
        blocked=CooperativeScheduler(processes=0).run(graph)
        self.assertFalse(blocked['all_verified'])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'checkpoint.json'
            scheduler=CooperativeScheduler(processes=0,allow_native=True)
            for _ in range(2):
                result=scheduler.run(graph,checkpoint=path)
                self.assertTrue(result['all_verified'])
                self.assertEqual(result['reused_verified_partials'],0)
    def test_usl_program_invokes_real_engines(self):
        source='let query = engine_run("graphql", "{twice(x:21)}", {})\nlet result = query["value"]["data"]["twice"]\nprint(result)'
        result=SourceSession(approved=True).interpret(source)
        self.assertEqual(result['stdout'],'42\n')
        self.assertEqual(result['engine_calls'],1)
        with self.assertRaises(USLError):SourceSession().interpret(source)
        imported=SourceSession(imports={'input':{'x':13}}).interpret('print(artifact("input")["x"])')
        self.assertEqual(imported['stdout'],'13\n')
        for bad in [[],{'bad':math.inf}]:
            with self.assertRaises(SourceError):SourceSession(imports=bad)
    def test_all_catalog_rows_accounted_and_no_full_spec_promotion(self):
        old=json.loads((ROOT/'test_results/v4.1.0_606_expansion_plan.json').read_text())
        result=ledger(self.report,old)
        self.assertEqual(result['catalog_total'],606)
        self.assertEqual(result['total_subset_evidence'],71)
        self.assertEqual(result['unqualified_entries'],535)
        self.assertEqual(result['full_specifications_qualified'],0)
    def test_typed_transport_is_distinct_from_native_pair_semantics(self):
        result=matrix(self.report)
        self.assertEqual(result['typed_artifact_handoffs'],324)
        self.assertEqual(result['addressable_cells'],367236)
        self.assertFalse(result['native_source_pair_claim'])
        bad=copy.deepcopy(self.report);bad['entries'][0]['cases'][0]['result']['value']={'tampered':True}
        with self.assertRaises(SourceError):matrix(bad)

if __name__=='__main__':unittest.main()
