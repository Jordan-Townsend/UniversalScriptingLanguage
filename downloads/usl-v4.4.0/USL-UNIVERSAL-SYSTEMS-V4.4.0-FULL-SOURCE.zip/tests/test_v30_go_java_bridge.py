import copy,json,shutil,unittest
from pathlib import Path
from usl_systems.interop import SCHEMA,run_nested,catalog_matrix,bridge_eligibility_matrix
ROOT=Path(__file__).resolve().parents[1]
GO='package main\nfunc transform(x int64) int64 { return x * 3 }\n'
JAVA='class Guest { static long transform(long x) { return x + 4; } }'

class GoJavaNativeTests(unittest.TestCase):
    def node(self,lang,source,params=['i64'],ret='i64',args=[7],export='transform'):
        return {'schema':SCHEMA,'nodes':[{'id':'step','language':lang,'source':source,'export':export,
                 'params':params,'returns':ret,'args':args}]}
    @unittest.skipUnless(shutil.which('go'),'Go not installed')
    def test_real_go_integer(self):
        r=run_nested(self.node('go',GO),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['step']['value'],21)
        self.assertEqual(r['results']['step']['evidence']['build']['exit_code'],0)
    @unittest.skipUnless(shutil.which('go'),'Go not installed')
    def test_go_array_native(self):
        s='package main\nfunc transform(a []int64) int64 { var s int64; for _,v:=range a {s+=v};return s }\n'
        r=run_nested(self.node('go',s,['i64[]'],'i64',[[2,3,5]]),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['step']['value'],10)
    @unittest.skipUnless(shutil.which('java') and shutil.which('javac'),'JVM unavailable')
    def test_java_boolean(self):
        s='class Guest { static boolean transform(boolean x) {return !x;} }'
        r=run_nested(self.node('java',s,['bool'],'bool',[True]),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertIs(r['results']['step']['value'],False)
    @unittest.skipUnless(shutil.which('java') and shutil.which('javac'),'JVM unavailable')
    def test_java_unicode_text(self):
        s='class Guest { static String transform(String x) {return x+"\\n☃\\\"";} }'
        r=run_nested(self.node('java',s,['text'],'text',['café']),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['step']['value'],'café\n☃"')
    @unittest.skipUnless(shutil.which('go'),'Go unavailable')
    def test_go_build_failure(self):
        r=run_nested(self.node('go','package main\nfunc transform( {'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Go build failed',r['failures']['step']['reason'])
    @unittest.skipUnless(shutil.which('java') and shutil.which('javac'),'JVM unavailable')
    def test_java_missing_symbol_failure(self):
        r=run_nested(self.node('java','class Guest { static long wrong(long x){return x;} }'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Java compile failed',r['failures']['step']['reason'])
    def test_no_approval_rejected(self):
        with self.assertRaisesRegex(ValueError,'approval'):
            run_nested(self.node('go',GO),authorized=False)
    def test_new_606_registry_recognizes_families(self):
        m=catalog_matrix();families={r['native_bridge_family'] for r in m['entries'] if r['native_bridge_family']}
        self.assertTrue({'go','java'}<=families)
        v=bridge_eligibility_matrix();self.assertEqual(v['total_pair_count'],606**2)
        self.assertFalse(v['pairs_are_tested'] if 'pairs_are_tested' in v else False)
    @unittest.skipUnless(shutil.which('go') and shutil.which('javac') and shutil.which('ruby') and shutil.which('php') and shutil.which('node') and shutil.which('gcc'), 'Native runtimes missing')
    def test_nine_engine_chain(self):
        p=json.loads((ROOT/'examples/nested_nine_languages.uslnest.json').read_text())
        r=run_nested(p,authorized=True,workers=3)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(len(r['results']),9)
        self.assertEqual(r['results']['usl']['value'],2402)
if __name__=='__main__': unittest.main()
