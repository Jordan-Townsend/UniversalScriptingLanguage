import hashlib,os,shutil,tempfile,unittest
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from usl_systems.native_build_cache import BuildCache
from usl_systems.interop import run_nested,SCHEMA
class BuildCacheTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='usl artifact cache tests ')
        self.old=os.environ.get('USL_NATIVE_CACHE_ROOT')
        os.environ['USL_NATIVE_CACHE_ROOT']=self.tmp.name
        self.cache=BuildCache()
    def tearDown(self):
        if self.old is None:os.environ.pop('USL_NATIVE_CACHE_ROOT',None)
        else:os.environ['USL_NATIVE_CACHE_ROOT']=self.old
        self.tmp.cleanup()
    def key(self,src='a',flags=()):
        return self.cache.fingerprint('test',src,'code',('python3',),flags)
    def test_content_addressed_restore(self):
        k,m=self.key();artifact=Path(self.tmp.name)/'compile.bin';artifact.write_bytes(b'hello!')
        self.cache.store(k,m,artifact)
        result=Path(self.tmp.name)/'result.bin'
        self.assertTrue(self.cache.restore(k,m,result));self.assertEqual(result.read_bytes(),b'hello!')
    def test_source_change_invalidates(self):
        self.assertNotEqual(self.key('a')[0],self.key('b')[0])
        self.assertNotEqual(self.key(flags=('flag',))[0],self.key(flags=())[0])
    def test_corrupted_artifact_does_not_restore(self):
        k,m=self.key();artifact=Path(self.tmp.name)/'a.bin';artifact.write_bytes(b'orig')
        self.cache.store(k,m,artifact)
        (self.cache.entry(k)/'artifact.bin').write_bytes(b'malicious')
        self.assertFalse(self.cache.restore(k,m,Path(self.tmp.name)/'recovered.bin'))
    def test_falsified_meta_rejected(self):
        k,m=self.key();artifact=Path(self.tmp.name)/'a.bin';artifact.write_bytes(b'orig')
        self.cache.store(k,m,artifact)
        self.assertFalse(self.cache.restore(k,{**m,'flags':['different']},Path(self.tmp.name)/'out.bin'))
    def test_concurrent_identical_store(self):
        k,m=self.key();artifact=Path(self.tmp.name)/'a.bin';artifact.write_bytes(b'good')
        with ThreadPoolExecutor(max_workers=5) as ex:
            results=list(ex.map(lambda _: self.cache.store(k,m,artifact),range(5)))
        self.assertEqual(results,[k]*5)
        self.assertTrue(self.cache.restore(k,m,Path(self.tmp.name)/'out.bin'))
    def project(self,lang,source,value):
        return {'schema':SCHEMA,'nodes':[{'id':'n','language':lang,'source':source,'export':'transform',
                'params':['i64'],'returns':'i64','args':[value]}]}
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript toolchain unavailable')
    def test_typescript_live_run_after_cached_build(self):
        p=self.project('typescript','export function transform(x:number):number{return x+9;}',2)
        a=run_nested(p,authorized=True);self.assertTrue(a['all_verified'],a['failures'])
        self.assertFalse(a['results']['n']['evidence']['cache_hit'])
        p['nodes'][0]['args']=[3]
        b=run_nested(p,authorized=True);self.assertTrue(b['all_verified'],b['failures'])
        self.assertTrue(b['results']['n']['evidence']['cache_hit'])
        self.assertEqual((a['results']['n']['value'],b['results']['n']['value']),(11,12))
        self.assertEqual(b['results']['n']['evidence']['run']['exit_code'],0)
    @unittest.skipUnless(shutil.which('kotlinc') and shutil.which('java'),'Kotlin toolchain unavailable')
    def test_kotlin_live_run_after_cached_build(self):
        p=self.project('kotlin','fun transform(x:Long):Long = x+9L',2)
        a=run_nested(p,authorized=True);self.assertTrue(a['all_verified'],a['failures'])
        self.assertFalse(a['results']['n']['evidence']['cache_hit'])
        p['nodes'][0]['args']=[3]
        b=run_nested(p,authorized=True);self.assertTrue(b['all_verified'],b['failures'])
        self.assertTrue(b['results']['n']['evidence']['cache_hit'])
        self.assertEqual((a['results']['n']['value'],b['results']['n']['value']),(11,12))
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript toolchain unavailable')
    def test_tampered_native_output_rebuilds(self):
        p=self.project('typescript','export function transform(x:number):number{return x+7;}',3)
        a=run_nested(p,authorized=True);self.assertTrue(a['all_verified'],a['failures'])
        key=a['results']['n']['evidence']['cache_key']
        (self.cache.entry(key)/'artifact.bin').write_bytes(b'garbage')
        b=run_nested(p,authorized=True);self.assertTrue(b['all_verified'],b['failures'])
        self.assertFalse(b['results']['n']['evidence']['cache_hit']);self.assertEqual(b['results']['n']['value'],10)
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript toolchain unavailable')
    def test_cached_build_still_requires_authorization(self):
        p=self.project('typescript','export function transform(x:number):number{return x+5;}',1)
        self.assertTrue(run_nested(p,authorized=True)['all_verified'])
        with self.assertRaisesRegex(ValueError,'approval'):run_nested(p,authorized=False)
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript toolchain unavailable')
    def test_source_edit_causes_recompile(self):
        p=self.project('typescript','export function transform(x:number):number{return x+5;}',1)
        a=run_nested(p,authorized=True)
        p['nodes'][0]['source']='export function transform(x:number):number{return x+6;}'
        b=run_nested(p,authorized=True)
        self.assertFalse(b['results']['n']['evidence']['cache_hit'])
        self.assertNotEqual(a['results']['n']['evidence']['cache_key'],b['results']['n']['evidence']['cache_key'])
if __name__=='__main__':unittest.main()
