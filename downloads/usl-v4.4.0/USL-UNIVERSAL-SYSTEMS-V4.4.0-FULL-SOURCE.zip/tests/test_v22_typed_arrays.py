"""Cross-module array contracts and real executable conformance for the supported subset."""
import unittest
from usl_systems.module_linker import SCHEMA,link_project,LinkError
from usl_systems.module_contracts import validate_contracts
from usl_systems.native import verify,tool_available

SRC_MAIN='use arrays\nlet values = [2, 4, 6]\nprint(first(values))'
SRC_LIB='function first(values):\n    return values[0]'
BASE={'schema':SCHEMA,'entry':'main','modules':{'main':SRC_MAIN,'arrays':SRC_LIB},
      'contracts':{'arrays.first':{'params':['int[3]'],'returns':'int'}}}

class TypedArrayContractTests(unittest.TestCase):
 def make(self,*,main=None,lib=None,argtype=None,rettype=None):
  return {**BASE,'modules':{'main':SRC_MAIN if main is None else main,'arrays':SRC_LIB if lib is None else lib},
    'contracts':{'arrays.first':{'params':[argtype or 'int[3]'],'returns':rettype or 'int'}}}
 def errors(self,project):return [e['kind'] for e in validate_contracts(project)['errors']]
 def test_valid_fixed_length_array_cross_module(self):
  report=validate_contracts(BASE)
  self.assertTrue(report['valid']);self.assertGreaterEqual(report['locally_verified_checks'],2)
  self.assertEqual(report['declared_signatures'],1)
 def test_valid_open_length(self):
  self.assertTrue(validate_contracts(self.make(argtype='int[]'))['valid'])
 def test_wrong_element_type(self):
  p=self.make(main='use arrays\nprint(first(["hello", "world", "!"]))')
  self.assertIn('argument_type_mismatch',self.errors(p))
 def test_wrong_fixed_length(self):
  p=self.make(main='use arrays\nprint(first([2, 4]))')
  self.assertIn('argument_type_mismatch',self.errors(p))
 def test_wrong_return_array_type(self):
  p=self.make(lib='function first(values):\n    return ["bad"]',rettype='int[1]')
  self.assertIn('return_type_mismatch',self.errors(p))
 def test_wrong_return_array_length(self):
  p=self.make(lib='function first(values):\n    return [1, 2]',rettype='int[3]')
  self.assertIn('return_type_mismatch',self.errors(p))
 def test_valid_array_return(self):
  p=self.make(lib='function first(values):\n    return [1, 2, 3]',rettype='int[3]')
  self.assertTrue(validate_contracts(p)['valid'])
 def test_function_result_signature_propagates(self):
  p=self.make(main='use arrays\nprint(first(first([2, 4, 6])))',
     lib='function first(values):\n    return [1, 2, 3]',rettype='int[3]')
  self.assertTrue(validate_contracts(p)['valid'])
  self.assertGreaterEqual(validate_contracts(p)['locally_verified_checks'],3)
 def test_invalid_contract_shape_and_size(self):
  for typ in ('list','int[2][3]','int[-1]','int[100001]','int[999999999999999999999999]',123):
   with self.subTest(typ=typ),self.assertRaises(LinkError):validate_contracts(self.make(argtype=typ))
 def test_unknown_argument_not_guessed(self):
  p=self.make(main='use arrays\nfunction unknown(v):\n    return first(v)\nprint(unknown([2,4,6]))')
  r=validate_contracts(p)
  self.assertTrue(r['valid']);self.assertTrue(r['unproven_checks'])
 def test_arity_rejection(self):
  p=self.make(main='use arrays\nprint(first([2,4,6], [1,2,3]))')
  with self.assertRaisesRegex(LinkError,'Argument count mismatch'):validate_contracts(p)
 def test_real_native_conformance_four_runtimes(self):
  source=link_project(BASE)['source']
  for lang in ('python','javascript','ruby','php'):
   if not tool_available(lang):self.skipTest('missing '+lang)
   with self.subTest(lang=lang):
    actual=verify(source,lang)
    self.assertEqual(actual['status'],'passed',actual)
if __name__=='__main__':unittest.main()
