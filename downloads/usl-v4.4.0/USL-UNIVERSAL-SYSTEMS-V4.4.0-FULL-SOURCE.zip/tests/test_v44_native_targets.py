import unittest
from usl_systems.native import verify,tool_available
from usl_systems.compiler import transpile

class NativeTargetTests(unittest.TestCase):
    def test_typescript_numeric_function_passes_native_typechecking(self):
        if not tool_available('typescript'):self.skipTest('native TypeScript/Node unavailable')
        source='function twice(value):\n    return value*2\nprint(twice(-17))\n'
        generated=transpile(source,'typescript').code
        self.assertIn('value: number',generated)
        r=verify(source,'typescript',timeout=20)
        self.assertEqual(r['status'],'passed',r)
        self.assertEqual(r['native']['stdout'],'-34\n')
    def test_csharp_function_compiles_and_runs_in_mono(self):
        if not tool_available('csharp'):self.skipTest('Mono/mcs unavailable')
        r=verify('function twice(value):\n    return value*2\nprint(twice(-17))','csharp',timeout=20)
        self.assertEqual(r['status'],'passed',r)
        self.assertEqual(r['native']['stdout'],'-34\n')

if __name__=='__main__':unittest.main()
