import math
import os
import tempfile
import unittest
from pathlib import Path
from usl_systems.simlab import simulate_decay,simulate_damper
from usl_systems.language import USLError
from usl_systems.vision import inspect_image

class ScientificTests(unittest.TestCase):
 def test_decay_matches_exact(self):
  r=simulate_decay(3,0.5,10,200)
  self.assertLess(r['absolute_error'],1e-7)
  self.assertEqual(r['solver'],'RK4')
 def test_decay_no_energy_creation(self):
  r=simulate_decay(4,1,2,200)
  self.assertLess(r['final_value'],4)
 def test_zero_rate(self):
  self.assertAlmostEqual(simulate_decay(7,0,13,300)['final_value'],7)
 def test_damper_reduces_energy(self):
  r=simulate_damper(damping=2,seconds=10,steps=500)
  self.assertLess(r['trace'][-1]['energy_j'],r['trace'][0]['energy_j'])
 def test_invalid_parameters_rejected(self):
  with self.assertRaises(USLError):simulate_decay(rate=-1)
  with self.assertRaises(USLError):simulate_damper(mass=0)
  with self.assertRaises(USLError):simulate_damper(steps=0)
  with self.assertRaises(USLError):simulate_decay(rate=float('nan'))

class VisionTests(unittest.TestCase):
 def test_real_image_decode_if_pillow(self):
  try:from PIL import Image
  except ImportError:self.skipTest('Pillow not installed')
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'gray.png';Image.new('RGB',(20,10),(128,128,128)).save(f)
   r=inspect_image(f)
   self.assertEqual(r['width'],20)
   self.assertAlmostEqual(r['mean_luminance_0_255'],128,delta=1)
   self.assertEqual(sum(r['histogram_16_bins']),200)
   self.assertFalse(r['object_detection'])
 def test_missing_image_rejected(self):
  with self.assertRaises(USLError):inspect_image('/not/here/file.png')
