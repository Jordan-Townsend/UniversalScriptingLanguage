import json,shutil,unittest
from pathlib import Path
from usl_systems.interop import run_nested,SCHEMA,catalog_matrix
ROOT=Path(__file__).resolve().parents[1]
SRC='module guestmod\n  use iso_c_binding\ncontains\n  function transform(x) bind(c, name="transform") result(y)\n    integer(c_int64_t), value :: x\n    integer(c_int64_t) :: y\n    y = x + 2_c_int64_t\n  end function\nend module\n'
class FortranNativeBridgeTests(unittest.TestCase):
    def node(self,source=SRC,export='transform',params=None,returns='i64',args=None):
        return {'schema':SCHEMA,'nodes':[{'id':'guest','language':'fortran','source':source,
           'export':export,'params':params if params is not None else ['i64'],
           'returns':returns,'args':args if args is not None else [4]}]}
    @unittest.skipUnless(shutil.which('gfortran'),'GNU Fortran missing')
    def test_fortran_real_compilation_and_execution(self):
        r=run_nested(self.node(),authorized=True)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(r['results']['guest']['value'],6)
        e=r['results']['guest']['evidence']
        self.assertEqual(e['mode'],'compiled_fortran_iso_c_binding_isolated_process')
        self.assertEqual(e['build']['exit_code'],0)
        self.assertEqual(e['call']['exit_code'],0)
    @unittest.skipUnless(shutil.which('gfortran'),'GNU Fortran missing')
    def test_fortran_compile_error(self):
        r=run_nested(self.node('not valid Fortran source'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Fortran compile failed',r['failures']['guest']['reason'])
    @unittest.skipUnless(shutil.which('gfortran'),'GNU Fortran missing')
    def test_fortran_missing_export(self):
        r=run_nested(self.node(export='wrong_name'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Fortran guest failed',r['failures']['guest']['reason'])
    def test_fortran_rejects_non_c_abi_type(self):
        r=run_nested(self.node(params=['text'],args=['x']),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Fortran C interoperable ABI',r['failures']['guest']['reason'])
    def test_fortran_requires_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):
            run_nested(self.node(),authorized=False)
    def test_registry_reports_fortran_bridge(self):
        d={r['id']:r for r in catalog_matrix()['entries']}
        self.assertIn('fortran',d);self.assertEqual(d['fortran']['native_bridge_family'],'fortran')
    @unittest.skipUnless(all(shutil.which(x) for x in ('gfortran','g++','bash','tsc','kotlinc','swiftc','perl','javac','go','ruby','php','node','gcc')), 'Native runtimes missing')
    def test_sixteen_real_engines(self):
        project=json.loads((ROOT/'examples/nested_sixteen_languages.uslnest.json').read_text())
        r=run_nested(project,authorized=True,workers=3)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(len(r['results']),16)
        self.assertEqual(r['results']['usl']['value'],20737)
        self.assertEqual(r['results']['fortran']['value'],72)
if __name__=='__main__':unittest.main()
