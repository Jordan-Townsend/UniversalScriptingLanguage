import json,shutil,unittest
from pathlib import Path
from usl_systems.interop import SCHEMA,run_nested,catalog_matrix
ROOT=Path(__file__).resolve().parents[1]
class TypeScriptKotlinTests(unittest.TestCase):
    def node(self,lang,source,params=['i64'],ret='i64',args=[4]):
        return {'schema':SCHEMA,'nodes':[{'id':'n','language':lang,'source':source,'export':'transform','params':params,'returns':ret,'args':args}]}
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript unavailable')
    def test_typescript_build_run(self):
        r=run_nested(self.node('typescript','export function transform(x:number):number {return x*7;}'),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['n']['value'],28)
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript unavailable')
    def test_typescript_async(self):
        s='export async function transform(x:number): Promise<number> {return x*7;}'
        r=run_nested(self.node('typescript',s),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['n']['value'],28)
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript unavailable')
    def test_typescript_static_error(self):
        s='export function transform(x:number):number {return "string";}'
        r=run_nested(self.node('typescript',s),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('TypeScript compile failed',r['failures']['n']['reason'])
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript unavailable')
    def test_typescript_i64_safe_bound(self):
        r=run_nested(self.node('typescript','export function transform(x:number):number{return x;}',args=[9007199254740992]),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('precision',r['failures']['n']['reason'])
    @unittest.skipUnless(shutil.which('kotlinc') and shutil.which('java'),'Kotlin unavailable')
    def test_kotlin_native(self):
        r=run_nested(self.node('kotlin','fun transform(x:Long):Long = x*7L'),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['n']['value'],28)
    @unittest.skipUnless(shutil.which('kotlinc') and shutil.which('java'),'Kotlin unavailable')
    def test_kotlin_boolean(self):
        r=run_nested(self.node('kotlin','fun transform(x:Boolean):Boolean = !x',['bool'],'bool',[True]),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertIs(r['results']['n']['value'],False)
    @unittest.skipUnless(shutil.which('kotlinc') and shutil.which('java'),'Kotlin unavailable')
    def test_kotlin_static_error(self):
        r=run_nested(self.node('kotlin','fun transform(x:Long):Long = "bad"'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Kotlin compile failed',r['failures']['n']['reason'])
    def test_no_native_without_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):
            run_nested(self.node('kotlin','fun transform(x:Long):Long = x'),authorized=False)
    def test_catalog_preserved(self):
        m=catalog_matrix();self.assertEqual(m['count'],606)
        routes={i['native_bridge_family'] for i in m['entries'] if i['native_bridge_family']}
        self.assertTrue({'typescript','kotlin'}<=routes)
    @unittest.skipUnless(all(shutil.which(t) for t in ('tsc','node','kotlinc','java','swiftc','perl','go','javac','gcc','ruby','php')),'Toolchains missing')
    def test_thirteen_languages_real(self):
        p=json.loads((ROOT/'examples/nested_thirteen_languages.uslnest.json').read_text())
        r=run_nested(p,authorized=True,workers=3)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(len(r['results']),13)
        self.assertEqual(r['results']['usl']['value'],4226)
if __name__=='__main__':unittest.main()
