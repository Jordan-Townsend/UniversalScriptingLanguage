import unittest
from usl_systems.semantic_holdouts import cases,qualification
from usl_systems.native import tool_available
from usl_systems.language import Interpreter,USLError
class SemanticHoldoutTests(unittest.TestCase):
 def test_deterministic_distinct_source_inputs(self):
  x=list(cases(count=4));y=list(cases(count=4))
  self.assertEqual(x,y)
  self.assertEqual(len({z['source_sha256'] for z in x}),4)
  for a in x:
   out=Interpreter(timeout=4).run(a['source']).output
   self.assertTrue(out.strip().lstrip('-').isdigit(),out)
 def test_reject_out_of_range(self):
  with self.assertRaises(ValueError):list(cases(count=100))
  with self.assertRaises(ValueError):qualification(targets=['unknown'])
 def test_actual_native_runtime_equivalence_on_holdouts(self):
  selected=[t for t in ('python','javascript','ruby','php','go','java','cpp','c') if tool_available(t)]
  report=qualification(count=2,targets=selected)
  self.assertGreaterEqual(report['actual_native_executions'],8)
  self.assertTrue(report['all_tested_passed'],report)
  self.assertEqual(report['passes'],report['actual_native_executions'])
  self.assertFalse(report['all_606_semantic_compilers_completed'])
if __name__=='__main__':unittest.main()
