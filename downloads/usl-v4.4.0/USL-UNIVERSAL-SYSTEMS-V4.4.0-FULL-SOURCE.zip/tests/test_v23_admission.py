import threading,time,unittest
from usl_systems.cooperative_workers import CooperativeScheduler,CooperativeError

def graph(items):return {'schema':'usl.cooperative.graph.v1','tasks':items}
def delay(id,priority,seconds=.02):return {'id':id,'kind':'bounded_delay','priority':priority,'inputs':{'seconds':seconds}}

class AdmissionTests(unittest.TestCase):
 def test_priority_with_strict_admission(self):
  g=graph([delay('low',0),delay('top',100),delay('medium',50)])
  result=CooperativeScheduler(threads=3,processes=0,max_in_flight=1).run(g,cache=False)
  self.assertTrue(result['all_verified'])
  started=sorted(result['tasks'],key=lambda k:result['tasks'][k]['started_ns'])
  self.assertEqual(started,['top','medium','low'])
  self.assertEqual(result['max_active_observed'],1)
 def test_parallel_bound_observed(self):
  g=graph([delay('job'+str(i),i) for i in range(1,7)])
  result=CooperativeScheduler(threads=6,processes=0,max_in_flight=2).run(g,cache=False)
  self.assertTrue(result['all_verified']);self.assertEqual(result['max_active_observed'],2)
 def test_cancellation_poll_before_active_task_finishes(self):
  cancel=threading.Event()
  g=graph([delay('start',100,.2),delay('second',0,.01),delay('third',0,.01)])
  threading.Timer(.04,cancel.set).start()
  result=CooperativeScheduler(threads=2,processes=0,max_in_flight=1).run(g,cancel_event=cancel,cache=False)
  self.assertTrue(result['cancelled_pending_tasks'])
  self.assertEqual(result['tasks']['start']['status'],'verified')
  self.assertEqual(result['tasks']['second']['status'],'cancelled')
  self.assertEqual(result['tasks']['third']['status'],'cancelled')
 def test_rejected_invalid_priorities(self):
  for priority in (-1,101,1.5,True,'10'):
   with self.subTest(priority=priority),self.assertRaises(CooperativeError):
    CooperativeScheduler(threads=1,processes=0).run(graph([delay('x',priority)]))
 def test_invalid_admission(self):
  for value in (-1,0,17,False,'4'):
   with self.subTest(value=value),self.assertRaises(CooperativeError):
    CooperativeScheduler(threads=1,processes=0,max_in_flight=value)
 def test_dependency_precedes_priority(self):
  g=graph([{'id':'dependent','kind':'join_evidence','priority':100,'deps':['base']},
           {'id':'base','kind':'bounded_delay','priority':0,'inputs':{'seconds':0.01}}])
  result=CooperativeScheduler(threads=2,processes=0,max_in_flight=1).run(g)
  self.assertTrue(result['all_verified'])
  self.assertLess(result['tasks']['base']['finished_ns'],result['tasks']['dependent']['started_ns'])
if __name__=='__main__':unittest.main()
