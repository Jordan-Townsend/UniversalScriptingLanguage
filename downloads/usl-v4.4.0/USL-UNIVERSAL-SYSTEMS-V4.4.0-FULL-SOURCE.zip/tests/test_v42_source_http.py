import json, unittest, urllib.error, urllib.request, tempfile
from types import SimpleNamespace
from threading import Thread
from http.server import ThreadingHTTPServer
from usl_systems.server import Handler
from usl_systems.store import Store

class SourceHTTP(unittest.TestCase):
    def setUp(self):
        class H(Handler):pass
        self.temp=tempfile.TemporaryDirectory()
        H.store=Store(self.temp.name)
        H.store.stop_token='test-local-source-control'
        self.server=ThreadingHTTPServer(('127.0.0.1',0),H)
        self.thread=Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base=f'http://127.0.0.1:{self.server.server_port}'
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=2)
        self.temp.cleanup()
    def post(self,payload,token=True):
        headers={'Content-Type':'application/json'}
        if token:headers['X-USL-Control-Token']='test-local-source-control'
        req=urllib.request.Request(self.base+'/api/source/run',data=json.dumps(payload).encode(),headers=headers)
        with urllib.request.urlopen(req,timeout=15) as r:return json.load(r)
    def test_provider_discovery_is_not_execution_qualification(self):
        with urllib.request.urlopen(self.base+'/api/source-engines') as r:result=json.load(r)
        self.assertEqual(len(result['contracts']),18)
        self.assertFalse(result['contracts']['graphql']['execution_qualified'])
    def test_execution_requires_token_and_explicit_permission(self):
        payload={'catalog_id':'graphql','source':'{twice(x:21)}'}
        for token,approved in [(False,True),(True,False)]:
            with self.subTest(token=token),self.assertRaises(urllib.error.HTTPError) as error:
                self.post({**payload,'approve_execution':approved},token)
            self.assertEqual(error.exception.code,403)
    def test_real_query_and_validation_over_http(self):
        result=self.post({'catalog_id':'graphql','source':'{twice(x:21)}','approve_execution':True})
        self.assertEqual(result['value']['data']['twice'],42)
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.post({'catalog_id':'graphql','source':'{unknown}','approve_execution':True})
        self.assertEqual(error.exception.code,400)

if __name__=='__main__':unittest.main()
