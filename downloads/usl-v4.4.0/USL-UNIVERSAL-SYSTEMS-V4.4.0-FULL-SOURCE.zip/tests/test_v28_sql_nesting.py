from pathlib import Path
import json,shutil,unittest
from usl_systems.interop import run_nested,BridgeError,SCHEMA,bridge_eligibility_matrix,catalog_matrix
ROOT=Path(__file__).resolve().parents[1]
class SQLiteInterop(unittest.TestCase):
    def query(self,sql,params=['i64'],args=[4],returns='i64'):
        p={'schema':SCHEMA,'nodes':[{'id':'query','language':'sql','source':sql,'export':'query',
             'params':params,'args':args,'returns':returns}]}
        return run_nested(p,authorized=True)
    def test_real_select(self):
        r=self.query('SELECT ? + 3')
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(r['results']['query']['value'],7)
        self.assertEqual(r['results']['query']['evidence']['mode'],'sqlite3_readonly_query')
    def test_sql_null(self):
        r=self.query('SELECT NULL',[],[],'null')
        self.assertTrue(r['all_verified'],r['failures']);self.assertIsNone(r['results']['query']['value'])
    def test_sql_text(self):
        r=self.query("SELECT 'hello'",[],[],'text')
        self.assertEqual(r['results']['query']['value'],'hello')
    def test_blocks_multi_statement(self):
        r=self.query('SELECT 1; DROP TABLE secret')
        self.assertFalse(r['all_verified']);self.assertIn('one parameterized SELECT',r['failures']['query']['reason'])
    def test_blocks_write(self):
        r=self.query('CREATE TABLE x (a INT)')
        self.assertFalse(r['all_verified']);self.assertIn('one parameterized SELECT',r['failures']['query']['reason'])
    def test_parameterized_no_code_injection(self):
        r=self.query('SELECT ?', ['text'], ["a'; DROP TABLE b; --"], 'text')
        self.assertTrue(r['all_verified']);self.assertEqual(r['results']['query']['value'],"a'; DROP TABLE b; --")
    def test_sql_query_error(self):
        r=self.query('SELECT no_such_column',[],[])
        self.assertFalse(r['all_verified']);self.assertIn('SQLite SELECT failed',r['failures']['query']['reason'])
    @unittest.skipUnless(shutil.which('node') and (shutil.which('gcc') or shutil.which('cc')),'Guest toolchains missing')
    def test_five_real_engines(self):
        p=json.loads((ROOT/'examples/nested_five_languages.uslnest.json').read_text('utf8'))
        result=run_nested(p,authorized=True,workers=3)
        self.assertTrue(result['all_verified'],result['failures'])
        self.assertEqual(result['results']['usl']['value'],1765)
        self.assertEqual({v['language'] for v in result['results'].values()},{'python','javascript','sql','c','usl'})
    def test_catalog_matrix_adds_sqlite(self):
        rows=catalog_matrix()['entries']
        self.assertEqual(len(rows),606)
        self.assertTrue(any(x['native_bridge_family']=='sql' for x in rows))
        m=bridge_eligibility_matrix()
        self.assertEqual(m['total_pair_count'],367236)
if __name__=='__main__':unittest.main()
