"""Qualify target-specific boolean compatibility with actual native runtimes."""
import unittest
from usl_systems.universal import route,collapse_success_all
from usl_systems.native import tool_available
from usl_systems.compiler import transpile

TARGETS=('python','javascript','ruby','php','go','java','cpp','c')
SOURCES=('print(True)','print(False)','let yes = 8 > 3\nprint(yes)')

class NativeBooleanCompatibility(unittest.TestCase):
    def test_native_boolean_cases(self):
        tested=0
        for target in TARGETS:
            with self.subTest(backend=target):
                if not tool_available(target):continue
                for source in SOURCES:
                    with self.subTest(source=source):
                        result=route(source,target,allow_native=True)
                        self.assertTrue(result['native_verified_for_this_program'],result['attempts'])
                        self.assertEqual(result['mode'],'direct_native')
                        self.assertEqual(result['attempts'][0]['native_exit_code'],0)
                        tested+=1
        self.assertGreaterEqual(tested,3)

    def test_semantic_fallback_still_rejects_none_difference(self):
        if not tool_available('javascript'):self.skipTest('JS missing')
        result=route('print(None)','javascript',allow_native=True)
        self.assertEqual(result['mode'],'portable_semantic_vm')
        self.assertEqual(result['attempts'][0]['status'],'failed')

    def test_c_has_stdbool_header(self):
        generated=transpile('print(True)','c')
        self.assertIn('#include <stdbool.h>',generated.code)

    def test_cross_backend_bounded_collapse(self):
        chosen=('python','javascript','ruby','php')
        if not all(tool_available(t) for t in chosen):self.skipTest('Native tool missing')
        record=collapse_success_all('print(True)',targets=chosen)
        self.assertTrue(record['native_verified_for_this_program'])
        self.assertEqual(len(record['attempts']),4)
        self.assertTrue(all(p['status']=='passed' for p in record['attempts']))
        self.assertFalse(record['full_target_language_semantics_verified'])

if __name__=='__main__':unittest.main()
