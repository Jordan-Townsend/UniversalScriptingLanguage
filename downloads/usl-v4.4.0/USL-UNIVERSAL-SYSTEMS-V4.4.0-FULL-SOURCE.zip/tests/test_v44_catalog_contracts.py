import unittest
from usl_systems.catalog_backends import PROFILES,run
from usl_systems.catalog_completion import audit
from usl_systems.catalog_parser import mappings,parse_source

class CatalogContractTests(unittest.TestCase):
    def test_full_inventory_preserves_completion_gaps(self):
        rows=audit();self.assertEqual(len(rows),606);self.assertEqual(sum(not r['historical_subset_evidence'] for r in rows),523)
        self.assertTrue(all(not r['full_spec_qualified'] for r in rows))
    def test_keyword_recognition_cannot_become_translation(self):
        rows=audit();abap=next(r for r in rows if r['catalog_id']=='abap')
        self.assertIsNone(abap['execution_profile']);self.assertFalse(abap['reference_is_audited_semantic_standard'])
    def test_native_execution_permission_is_explicit(self):
        with self.assertRaisesRegex(ValueError,'approval'):run('rust','fn main(){}')
    def test_foreign_language_cannot_fallback_to_usl(self):
        with self.assertRaisesRegex(ValueError,'reviewed'):run('unknown','print(42)',approved=True)
    def test_actual_parser_ast_preserves_source_spans(self):
        if 'rust' not in mappings():self.skipTest('Rust upstream grammar unavailable')
        r=parse_source('rust','fn main() { println!("42"); }')
        self.assertFalse(r['native_execution']);self.assertFalse(r['typed_semantic_lowering'])
        self.assertEqual(r['ast']['nodes'][0]['start'],0)
    def test_actual_parser_rejects_invalid_rust(self):
        if 'rust' not in mappings():self.skipTest('Rust upstream grammar unavailable')
        with self.assertRaisesRegex(ValueError,'rejected'):parse_source('rust','fn main( {')

if __name__=='__main__':unittest.main()
