"""Reject release evidence that pretends skipped matrix cells are executed."""
import json,hashlib,unittest
from pathlib import Path
from usl_systems.executable_matrix import cell_value
ROOT=Path(__file__).resolve().parents[1]
class ExhaustiveMatrixEvidenceTests(unittest.TestCase):
    def data(self):
        base=ROOT/'test_results'
        report=json.loads((base/'v3.7.0_all_eligible_pair_exec.json').read_text('utf8'))
        meta=json.loads((base/'v3.7.0_executable_matrix_606x606.json').read_text('utf8'))
        grid=(base/'v3.7.0_executable_matrix_606x606.bin').read_bytes()
        return report,meta,grid
    def test_every_eligible_cell_really_executed(self):
        report,meta,grid=self.data()
        self.assertEqual(report['probe_count'],257)
        self.assertEqual(report['actual_verified_pairs'],257)
        self.assertEqual(len({(x['host'],x['guest']) for x in report['pairs']}),257)
        self.assertTrue(all(x['verified'] and x['status']=='observed_success' for x in report['pairs']))
        self.assertEqual(meta['count_executed_verified'],257)
        self.assertEqual(meta['count_conditional_unverified'],0)
        self.assertEqual(meta['count_unverified'],366979)
        self.assertEqual(len(grid),606*606)
    def test_binary_matrix_hash_and_per_pair_correspondence(self):
        report,meta,grid=self.data()
        self.assertEqual(hashlib.sha256(grid).hexdigest(),meta['matrix_sha256'])
        for entry in report['pairs']:
            self.assertEqual(cell_value(grid,meta,entry['host'],entry['guest']),'observed_verified')
        self.assertEqual(cell_value(grid,meta,'abap','python'),'unverified')
    def test_all_606_have_explicit_guest_status(self):
        report,meta,grid=self.data()
        lang=json.loads((ROOT/'test_results/v3.7.0_parallel_guest_execution.json').read_text('utf8'))
        self.assertEqual(len(lang['catalog']),606)
        self.assertEqual(sum(x['status']=='verified_executable_subset' for x in lang['catalog']),17)
        self.assertEqual(sum(x['status']=='not_yet_executable_qualified' for x in lang['catalog']),589)
if __name__=='__main__':unittest.main()
