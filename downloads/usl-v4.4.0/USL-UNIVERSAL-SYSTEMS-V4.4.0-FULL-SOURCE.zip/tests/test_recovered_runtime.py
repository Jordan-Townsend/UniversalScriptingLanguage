import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from usl_systems.legacy_runtime import (
    SOURCES, LegacyError, _safe_members, bundled_sources, stage_component,component_root,
    bridge_status,shadow_health,emovision_health,native_v031_run,_safe_local_service
)

class ArchiveTests(unittest.TestCase):
    def test_archives_have_exact_verified_digests(self):
        items=bundled_sources()
        self.assertEqual(len(items),6)
        self.assertTrue(all(x['sha256_matches'] for x in items.values()))
    def test_untrusted_zip_path_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            zfile=Path(tmp)/'attack.zip'
            with zipfile.ZipFile(zfile,'w') as z:z.writestr('../../escape.py','attack')
            with zipfile.ZipFile(zfile) as z:
                with self.assertRaisesRegex(LegacyError,'Unsafe'):list(_safe_members(z))
    def test_all_sources_stage_without_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            for name in SOURCES:
                with self.subTest(name=name):
                    x=stage_component(name,tmp)
                    self.assertEqual(x['status'],'staged')
                    self.assertTrue(component_root(name,tmp).is_dir())
                    self.assertEqual(stage_component(name,tmp)['status'],'already-staged')
            root=component_root('emovision_v63',tmp)
            self.assertTrue((root/'emovision_fabric'/'server.py').is_file())
    def test_rejects_overwriting_modified_stage(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage_component('usl_v031',tmp)
            path=Path(tmp)/'legacy_components'/'usl_v031'/'STAGED_SOURCE.json'
            path.write_text('{}')
            with self.assertRaisesRegex(LegacyError,'refuse overwrite'):
                stage_component('usl_v031',tmp)

class AdapterTests(unittest.TestCase):
    def test_invalid_remote_hosts_are_rejected(self):
        for address in ('http://localhost:8766','http://192.168.0.1:8766','https://127.0.0.1:8766','http://127.0.0.1:8766/a'):
            with self.subTest(address=address):
                with self.assertRaises(LegacyError):_safe_local_service(address,'/api/health')
    def test_unauthenticated_services_require_explicit_optin(self):
        with self.assertRaises(LegacyError):shadow_health()
        with self.assertRaises(LegacyError):emovision_health()
    def test_mock_shadow_and_emovision_probes(self):
        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                data=({'ok':True,'sdk':{'running':True},'provider':{'available':True},'creator':{'private':'do not leak'}}
                      if self.path=='/health' else {'error':'unknown'})
                raw=json.dumps(data).encode();self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
            def log_message(self,*args):pass
        s=ThreadingHTTPServer(('127.0.0.1',0),H)
        from threading import Thread
        t=Thread(target=s.serve_forever,daemon=True);t.start()
        try:
            url=f'http://127.0.0.1:{s.server_port}'
            x=shadow_health(url,True)
            self.assertTrue(x['connected']);self.assertTrue(x['sdk_running'])
            self.assertNotIn('creator',x)
            self.assertTrue(emovision_health(url,True)['connected'])
        finally:s.shutdown();s.server_close();t.join(timeout=2)
    @unittest.skipUnless(shutil.which('gcc'), 'gcc required for recovered native compiler integration')
    def test_native_v031_actual_compilation_and_execution(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage_component('usl_v031',tmp)
            file=Path(tmp)/'source.usl'
            file.write_text('fn main(x: int) -> int:\n    return x + 2\n',encoding='utf8')
            with self.assertRaisesRegex(LegacyError,'Explicit'):native_v031_run(file,tmp,runarg=5)
            result=native_v031_run(file,tmp,runarg=5,allow=True)
            self.assertEqual(result['status'],'executed',result)
            self.assertEqual(result['exit_code'],0,result)
            self.assertEqual(result['stdout'].strip(),'7',result)
            self.assertTrue(result['verified'])
    def test_actual_shadow_v87_sdk_contract_in_isolated_worker(self):
        """Run V87's real SDK source with fake model state, not an invented API."""
        with tempfile.TemporaryDirectory() as tmp:
            stage_component('shadow_v87',tmp)
            root=component_root('shadow_v87',tmp)
            sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
            program=(
                'import sys,time\n'
                'from studio.sdk_runtime import SDKRuntime\n'
                'class Provider:\n def probe(self):return {"available":False}\n'
                'class Reactive:\n def diagnostics(self):return {"waiting":True}\n'
                'class Engine:\n providers=Provider()\n reactive=Reactive()\n'
                f'rt=SDKRuntime(Engine(),port={port})\n'
                's=rt.start()\n'
                'assert s["running"],s\n'
                'time.sleep(8)\n'
            )
            proc=subprocess.Popen([sys.executable,'-c',program],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            try:
                url=f'http://127.0.0.1:{port}'
                for _ in range(35):
                    if proc.poll() is not None:self.fail('V87 SDK failed to launch')
                    try:
                        result=shadow_health(url,True)
                        break
                    except LegacyError:time.sleep(.1)
                else:self.fail('V87 SDK did not respond')
                self.assertTrue(result['connected'])
                self.assertTrue(result['sdk_running'])
                self.assertFalse(result['provider_available'])
            finally:
                proc.terminate()
                try:proc.communicate(timeout=2)
                except subprocess.TimeoutExpired:proc.kill();proc.communicate()

    def test_actual_emovision_v63_server_contract_in_isolated_worker(self):
        """Invoke recovered EmoVision V63 HTTP service with mocked sensor data."""
        with tempfile.TemporaryDirectory() as tmp:
            stage_component('emovision_v63',tmp)
            root=component_root('emovision_v63',tmp)
            sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
            program=(
                'import time\nfrom emovision_fabric.server import start\n'
                'class Bus:\n def snapshot(self):return {"frame":None}\n'
                'class Mgr:\n def list(self):return []\n'
                'class VR:pass\n'
                f'start({{"api":{{"host":"127.0.0.1","port":{port}}}}},Bus(),Mgr(),VR(),{{"ok":True,"source":"v63"}})\n'
                'time.sleep(8)\n'
            )
            proc=subprocess.Popen([sys.executable,'-c',program],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            try:
                url=f'http://127.0.0.1:{port}'
                for _ in range(35):
                    if proc.poll() is not None:self.fail('V63 server failed to launch')
                    try:
                        result=emovision_health(url,True)
                        break
                    except LegacyError:time.sleep(.1)
                else:self.fail('V63 service did not respond')
                self.assertTrue(result['connected'])
                self.assertTrue(result['health_reachable'])
            finally:
                proc.terminate()
                try:proc.communicate(timeout=2)
                except subprocess.TimeoutExpired:proc.kill();proc.communicate()

    def test_real_chrome_bridge_authenticated_status(self):
        # Run original recovered service in a dedicated temporary data directory.
        with tempfile.TemporaryDirectory() as tmp:
            stage_component('bridge_v3',tmp)
            root=component_root('bridge_v3',tmp)
            local=Path(tmp)/'bridge_data'
            sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
            env={**os.environ,'USL_BRIDGE_DATA':str(local),'USL_OPEN_DASHBOARD':'0'}
            proc=subprocess.Popen([sys.executable,str(root/'bridge.py'),'--port',str(port)],cwd=root,env=env,
                                  stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:
                tokenfile=local/'pairing_token.txt'
                url=f'http://127.0.0.1:{port}'
                for _ in range(70):
                    if proc.poll() is not None:self.fail('Original Bridge V3 exited during startup')
                    if tokenfile.is_file():
                        try:
                            with urllib.request.urlopen(url+'/api/status',timeout=.25):pass
                        except urllib.error.HTTPError as exc:
                            if exc.code==401:break
                        except (urllib.error.URLError,TimeoutError):pass
                    time.sleep(.1)
                else:self.fail('Bridge V3 did not start before deadline')
                with patch.dict(os.environ,{'USL_BRIDGE_DATA':str(local),'USL_BRIDGE_TOKEN':''}):
                    result=bridge_status(url=url)
                self.assertTrue(result['connected'],result)
                self.assertTrue(result['authenticated'])
                self.assertNotIn('pairing_token',json.dumps(result).lower())
            finally:
                if proc.poll() is None:
                    proc.terminate()
                    try:proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=2)

if __name__=='__main__':unittest.main()
