import json,unittest
from pathlib import Path
from tools.qualify_606_runtime_coverage_v37 import make_report
ROOT=Path(__file__).resolve().parents[1]
class CoverageV37(unittest.TestCase):
    def test_sixteen_qualified_exact_subsets(self):
        p=ROOT/'test_results/v3.7.0_sixteen_native.json'
        d=make_report(p)
        self.assertEqual(d['catalog_count'],606)
        self.assertEqual(d['verified_guest_subset_count'],15)
        self.assertEqual(d['catalog_entries_without_native_subset_evidence'],591)
        self.assertEqual(d['routable_606_pair_eligibility']['total_pair_count'],606*606)
        self.assertFalse(d['all_606_full_native_compilers'])
    def test_tampering_fails(self):
        p=ROOT/'test_results/v3.7.0_sixteen_native.json'
        d=json.loads(p.read_text())
        d['verified']=15
        import tempfile
        with tempfile.TemporaryDirectory() as t:
            q=Path(t)/'bad.json';q.write_text(json.dumps(d))
            with self.assertRaisesRegex(ValueError,'verified sixteen-stage'):
                make_report(q)
if __name__=='__main__':unittest.main()
