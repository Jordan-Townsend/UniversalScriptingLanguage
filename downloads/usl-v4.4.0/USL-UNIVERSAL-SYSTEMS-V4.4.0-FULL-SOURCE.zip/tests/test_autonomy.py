import json
import sys
import tempfile
import time
import unittest
from usl_systems.store import Store
from usl_systems.bridge import ProcessBridge
from usl_systems.autonomy import AutonomyController,AutonomyError,validate_plan


def wait(controller, rid, deadline=10):
    end=time.monotonic()+deadline
    while time.monotonic()<end:
        row=controller.detail(rid)
        if row['status'] in ('completed','failed','cancelled','paused','needs_review'):
            return row
        time.sleep(.025)
    raise AssertionError('Controller did not settle')


class AutonomyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(self.tmp.name)
        self.bridge=ProcessBridge(self.store)
        self.ctrl=AutonomyController(self.store,self.bridge)

    def tearDown(self):
        self.bridge.shutdown()
        self.ctrl.close()
        self.tmp.cleanup()

    def plan(self):
        return {'format':'uslauto-1','steps':[
            {'id':'calculation','kind':'usl','source':'let x = 5\nprint(x + 2)\nassert x + 2 == 7',
             'expected':{'output_contains':'7'}},
            {'id':'code','kind':'compile','source':'let x = 3\nprint(x)','target':'python',
             'expected':{'status':'completed'}}]}

    def test_plan_is_inert_until_approved(self):
        row=self.ctrl.create(self.plan())
        self.assertEqual(row['status'],'draft')
        self.assertEqual(row['outcomes'],[])
        with self.assertRaises(AutonomyError):self.ctrl.begin(row['id'])
        self.ctrl.approve(row['id'])
        self.ctrl.begin(row['id'])
        row=wait(self.ctrl,row['id'])
        self.assertEqual(row['status'],'completed',row)
        self.assertEqual(row['cursor'],2)
        self.assertTrue(all(x['successful'] for x in row['outcomes']))
        self.assertTrue(row['outcomes'][0]['proof']['passed'])

    def test_verification_failure_prevents_later_steps(self):
        plan=self.plan();plan['steps'][0]['expected']={'output_equals':'NOT TRUE'}
        rid=self.ctrl.create(plan)['id'];self.ctrl.approve(rid);self.ctrl.begin(rid)
        row=wait(self.ctrl,rid)
        self.assertEqual(row['status'],'failed')
        self.assertEqual(row['cursor'],1)
        self.assertFalse(row['outcomes'][0]['successful'])

    def test_no_process_without_special_approval(self):
        plan={'format':'uslauto-1','steps':[{'id':'child','kind':'process','argv':[sys.executable,'-c','print(23)']}]}
        rid=self.ctrl.create(plan)['id']
        with self.assertRaises(AutonomyError):self.ctrl.approve(rid)
        self.assertEqual(self.ctrl.detail(rid)['status'],'draft')
        self.ctrl.approve(rid,allow_process=True)
        self.ctrl.begin(rid)
        row=wait(self.ctrl,rid)
        self.assertEqual(row['status'],'completed',row)
        result=row['outcomes'][0]['result']
        self.assertIn('23',result['output']);self.assertEqual(result['exit_code'],0)
        self.assertTrue(self.bridge.detail(result['process_id'])['status']=='completed')

    def test_process_failure_fails_automated_plan(self):
        plan={'format':'uslauto-1','steps':[{'id':'child','kind':'process','argv':[sys.executable,'-c','import sys;sys.exit(4)']}]}
        rid=self.ctrl.create(plan)['id'];self.ctrl.approve(rid,allow_process=True);self.ctrl.begin(rid)
        row=wait(self.ctrl,rid)
        self.assertEqual(row['status'],'failed')
        self.assertEqual(row['outcomes'][0]['result']['exit_code'],4)

    def test_restart_pauses_safe_step_but_blocks_process_replay(self):
        a=self.ctrl.create(self.plan())['id'];self.ctrl.approve(a)
        p={'format':'uslauto-1','steps':[{'id':'p','kind':'process','argv':[sys.executable,'-c','print(2)']}]}
        b=self.ctrl.create(p)['id'];self.ctrl.approve(b,allow_process=True)
        self.ctrl._update(a,status='running',cursor=0)
        self.ctrl._update(b,status='running',cursor=0)
        self.ctrl.close()
        self.ctrl=AutonomyController(self.store,self.bridge)
        self.assertEqual(self.ctrl.detail(a)['status'],'paused')
        self.assertEqual(self.ctrl.detail(b)['status'],'needs_review')
        with self.assertRaises(AutonomyError):self.ctrl.begin(b)
        self.ctrl.begin(a)
        self.assertEqual(wait(self.ctrl,a)['status'],'completed')

    def test_cancel_draft_without_running(self):
        rid=self.ctrl.create(self.plan())['id']
        self.assertEqual(self.ctrl.cancel(rid)['status'],'cancelled')
        with self.assertRaises(AutonomyError):self.ctrl.approve(rid)

    def test_validation_rejects_unknown_steps_and_duplicate_ids(self):
        invalids=[{'format':'uslauto-1','steps':[{'id':'x','kind':'unknown'}]},
                  {'format':'uslauto-1','steps':[{'id':'x','kind':'usl','source':''}, {'id':'x','kind':'usl','source':''}]},
                  {'format':'uslauto-1','steps':[{'id':'x','kind':'usl','source':'','magic':'unexpected'}]},
                  {'format':'uslauto-1','steps':[{'id':'x','kind':'process','argv':'rm'}]}]
        for plan in invalids:
            with self.subTest(plan=plan),self.assertRaises(AutonomyError):validate_plan(plan)

    def test_persistent_journal_roundtrip(self):
        rid=self.ctrl.create(self.plan())['id'];self.ctrl.approve(rid);self.ctrl.begin(rid)
        row=wait(self.ctrl,rid)
        other=Store(self.tmp.name)
        with other.lock,other._db() as db:
            self.assertEqual(db.execute('SELECT status FROM autonomous_runs WHERE id=?',(rid,)).fetchone()['status'],'completed')
        self.assertGreaterEqual(len(self.store.events()),5)


if __name__=='__main__':unittest.main()

class ResearchAutonomyTests(unittest.TestCase):
    def test_research_operations_in_one_approved_plan(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(tmp);bridge=ProcessBridge(store);controller=AutonomyController(store,bridge)
            try:
                plan={'format':'uslauto-1','steps':[
                    {'id':'compact','kind':'collapse','text':'USL'*300,'expected':{'field':'exact','equals':True}},
                    {'id':'partition','kind':'fractal','values':[i%8 for i in range(200)],'operator':'sum_squares',
                     'workers':3,'depth':3,'leaf_size':24,'expected':{'status':'completed'}},
                    {'id':'partial','kind':'incremental','values':[1,2,3,4],'changes':{'0':5},'audit':True,
                     'expected':{'field':'updated.correct','equals':True}}]}
                rid=controller.create(plan)['id'];controller.approve(rid);controller.begin(rid)
                result=wait(controller,rid)
                self.assertEqual(result['status'],'completed',result)
                self.assertTrue(all(item['proof']['passed'] for item in result['outcomes']))
                self.assertEqual(len(result['outcomes']),3)
            finally:bridge.shutdown();controller.close()

    def test_unknown_equation_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(tmp);ctrl=AutonomyController(store)
            plan={'format':'uslauto-1','steps':[{'id':'bad','kind':'equation','equation_id':'impossible_formula_no_such_id','params':{}}]}
            try:
                rid=ctrl.create(plan)['id'];ctrl.approve(rid);ctrl.begin(rid)
                row=wait(ctrl,rid)
                self.assertEqual(row['status'],'failed')
                self.assertIn('error',row['outcomes'][0])
            finally:ctrl.close()

class AutoModelProposalTests(unittest.TestCase):
    def test_model_plan_is_draft_and_needs_approval(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as tmp:
            ctrl=AutonomyController(Store(tmp))
            try:
                plan={'format':'uslauto-1','steps':[{'id':'one','kind':'usl','source':'print(5)',
                     'expected':{'output_contains':'5'}}]}
                with patch('usl_systems.autonomy.ask_model',return_value='```json\n'+json.dumps(plan)+'\n```'):
                    result=ctrl.propose('Please print the value five')
                self.assertEqual(result['status'],'draft')
                self.assertFalse(result['approved'])
                self.assertEqual(result['outcomes'],[])
                with self.assertRaises(AutonomyError):ctrl.begin(result['id'])
            finally:ctrl.close()

    def test_model_cannot_propose_external_process(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as tmp:
            ctrl=AutonomyController(Store(tmp))
            try:
                plan={'format':'uslauto-1','steps':[{'id':'exec','kind':'process','argv':[sys.executable,'-c','print(1)']}]}
                with patch('usl_systems.autonomy.ask_model',return_value=json.dumps(plan)):
                    with self.assertRaisesRegex(AutonomyError,'unapproved external'):ctrl.propose('please execute external code')
                self.assertEqual(ctrl.list(),[])
            finally:ctrl.close()

class AutoHTTPTests(unittest.TestCase):
    def test_endpoints_require_control_token_then_verify_real_result(self):
        from http.server import ThreadingHTTPServer
        from threading import Thread
        from usl_systems.server import Handler
        from usl_systems.engine import Engine
        import urllib.request,urllib.error
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(tmp);store.stop_token='autotest-secret-token'
            bridge=ProcessBridge(store);engine=Engine(store);controller=AutonomyController(store,bridge)
            class H(Handler):pass
            H.store=store;H.engine=engine;H.bridge=bridge;H.autonomy=controller
            server=ThreadingHTTPServer(('127.0.0.1',0),H)
            thread=Thread(target=server.serve_forever,daemon=True);thread.start()
            base='http://127.0.0.1:'+str(server.server_port)
            def call(path,body,token=None):
                heads={'Content-Type':'application/json'}
                if token:heads['X-USL-Control-Token']=token
                req=urllib.request.Request(base+path,data=json.dumps(body).encode(),headers=heads)
                with urllib.request.urlopen(req,timeout=5) as resp:return json.load(resp)
            try:
                with self.assertRaises(urllib.error.HTTPError) as denied:
                    call('/api/autonomy/create',{'plan':{'format':'uslauto-1','steps':[{'id':'hi','kind':'usl','source':'print(5)'}]}})
                self.assertEqual(denied.exception.code,403)
                p={'format':'uslauto-1','steps':[{'id':'hi','kind':'usl','source':'print(5)','expected':{'output_contains':'5'}}]}
                draft=call('/api/autonomy/create',{'plan':p},store.stop_token)
                self.assertEqual(draft['status'],'draft')
                call('/api/autonomy/approve',{'id':draft['id']},store.stop_token)
                call('/api/autonomy/start',{'id':draft['id']},store.stop_token)
                state=wait(controller,draft['id'])
                self.assertEqual(state['status'],'completed')
                with urllib.request.urlopen(base+'/api/autonomy/run?id='+draft['id']) as resp:
                    remote=json.load(resp)
                self.assertEqual(remote['outcomes'][0]['result']['output'].strip(),'5')
            finally:
                server.shutdown();server.server_close();thread.join(timeout=3)
                bridge.shutdown();engine.pool.shutdown(wait=False,cancel_futures=True);controller.close()
