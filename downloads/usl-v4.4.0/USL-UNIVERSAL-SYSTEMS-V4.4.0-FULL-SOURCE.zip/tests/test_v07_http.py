import json
import tempfile
import unittest
import urllib.error
import urllib.request
from threading import Thread
from unittest.mock import patch
from http.server import ThreadingHTTPServer
from usl_systems.server import Handler
from usl_systems.store import Store
from usl_systems.engine import Engine
from usl_systems.bridge import ProcessBridge
from usl_systems.autonomy import AutonomyController

class APIQualificationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(self.temp.name)
        self.store.stop_token='demo-token-for-tests'
        self.engine=Engine(self.store)
        self.bridge=ProcessBridge(self.store)
        self.auto=AutonomyController(self.store,self.bridge)
        class H(Handler):pass
        H.store=self.store;H.engine=self.engine;H.bridge=self.bridge;H.autonomy=self.auto
        self.server=ThreadingHTTPServer(('127.0.0.1',0),H)
        self.thread=Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base='http://127.0.0.1:'+str(self.server.server_port)
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=3)
        self.auto.close();self.bridge.shutdown();self.engine.pool.shutdown(wait=False,cancel_futures=True)
        self.temp.cleanup()
    def get(self,path,token=None):
        headers={}
        if token:headers['X-USL-Control-Token']=token
        with urllib.request.urlopen(urllib.request.Request(self.base+path,headers=headers),timeout=5) as r:
            return json.load(r)
    def post(self,path,body):
        req=urllib.request.Request(self.base+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=5) as r:return json.load(r)
    def test_parsers_and_syntax_validation_live(self):
        d=self.get('/api/syntax/parsers')
        self.assertIn('toml',d['parsers'])
        yes=self.post('/api/syntax/validate',{'language':'json','source':'{"ok":true}'})
        no=self.post('/api/syntax/validate',{'language':'json','source':'{"ok":NaN}'})
        self.assertTrue(yes['valid']);self.assertFalse(no['valid'])
    def test_dag_controller_live(self):
        plan={'format':'uslauto-1','steps':[
            {'id':'b','kind':'collapse','depends_on':['a'],'inputs':{'text':{'step':'a','path':'result.output'}}},
            {'id':'a','kind':'usl','source':'print(12)'}]}
        request=lambda path,body:self._post_token(path,body)
        data=request('/api/autonomy/create',{'plan':plan})
        self.assertEqual([x['id'] for x in data['plan']['steps']],['a','b'])
        request('/api/autonomy/approve',{'id':data['id']})
        request('/api/autonomy/start',{'id':data['id']})
        import time
        for _ in range(200):
            status=self.get('/api/autonomy/run?id='+data['id'])
            if status['status']=='completed':break
            time.sleep(.03)
        self.assertEqual(status['status'],'completed',status)
        self.assertTrue(status['outcomes'][1]['result']['exact'])
    def _post_token(self,path,body):
        req=urllib.request.Request(self.base+path,data=json.dumps(body).encode(),headers={
            'Content-Type':'application/json','X-USL-Control-Token':self.store.stop_token})
        with urllib.request.urlopen(req,timeout=5) as r:return json.load(r)
    def test_observation_requires_token(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.get('/api/bridge/latest')
        self.assertEqual(e.exception.code,403)
        with patch('usl_systems.server.bridge_latest_report',return_value={'connected':True,'verified_task':False,'status':'no_report'}):
            item=self.get('/api/bridge/latest',self.store.stop_token)
            self.assertTrue(item['connected']);self.assertFalse(item['verified_task'])
    def test_ui_has_language_parser(self):
        with urllib.request.urlopen(self.base+'/') as r:body=r.read().decode('utf8')
        self.assertIn('syntax-validate-btn',body)

if __name__=='__main__':unittest.main()
