import copy,json,tempfile,unittest
from pathlib import Path
from usl_systems.expanded_domains import SPEC,discover,execute,qualify,EXPECT,DomainError
from usl_systems.extrapolate_606 import plan,matrix
from usl_systems.cooperative_workers import CooperativeScheduler
from tools.reuse_v41_abilities import run as reuse

class V41SemanticExpansion(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory(prefix='usl-v41-test-')
  cls.artifacts=Path(cls.temp.name)
  cls.q=qualify(approved=True,workers=8,artifacts=cls.artifacts)
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def test_seventeen_new_executable_domains(self):
  self.assertEqual(len(SPEC),17)
  self.assertTrue(self.q['all_passed'])
  self.assertEqual(self.q['tests_passed'],34)
  self.assertEqual(self.q['newly_qualified_count'],17)
 def test_positive_negative_native_exit(self):
  for lang in SPEC:
   matching=[x for x in self.q['cases'] if x['language']==lang]
   self.assertEqual({x['variant'] for x in matching},{'valid','invalid'})
   self.assertTrue(all(x['verified'] for x in matching))
   self.assertTrue(any(x['status']=='invalid_rejected' for x in matching))
 def test_explicit_execution_approval(self):
  with self.assertRaises(DomainError):execute('jmespath')
  with self.assertRaises(DomainError):qualify()
  with self.assertRaises(DomainError):execute('unknown',approved=True)
  with self.assertRaises(DomainError):execute('jmespath',approved=True,variant='unreviewed')
 def test_bounded_workers(self):
  with self.assertRaises(DomainError):qualify(approved=True,workers=1000)
 def test_behavioral_assertions_reject_wrong_oracle(self):
  # Dynamic mutation of the reference oracle is not sufficient for verification.
  from usl_systems import expanded_domains as e
  old=e.EXPECT['jmespath'];e.EXPECT['jmespath']={'selected':'incorrect'}
  try:
   with self.assertRaises(DomainError):execute('jmespath',approved=True)
  finally:e.EXPECT['jmespath']=old
 def test_606_coverage_has_no_fabricated_semantic_completions(self):
  x=plan(self.q)
  self.assertEqual(x['catalog_total'],606)
  self.assertEqual(x['newly_executed_catalog_entries'],17)
  self.assertEqual(x['total_executable_subsets'],53)
  self.assertEqual(x['unqualified_entries'],553)
  self.assertEqual(x['fully_semantically_complete'],0)
  self.assertEqual(len({r['catalog_id'] for r in x['entries']}),606)
 def test_289_typed_handoffs_have_provenance(self):
  r=matrix(self.artifacts,self.q,workers=8)
  self.assertEqual(r['ordered_cells'],367236)
  self.assertEqual(r['tested_typed_handoff_cells'],289)
  self.assertTrue(all(x['verified'] for x in r['cells']))
 def test_corrupted_artifact_is_not_trusted(self):
  path=self.artifacts/'protobuf.json';original=path.read_bytes()
  try:
   path.write_text('{"workers":600}',encoding='utf8')
   with self.assertRaisesRegex(ValueError,'Tampered'):matrix(self.artifacts,self.q)
  finally:path.write_bytes(original)
 def test_corrupted_language_evidence_is_not_trusted(self):
  bad=copy.deepcopy(self.q)
  case=next(x for x in bad['cases'] if x['language']=='protobuf' and x['variant']=='valid')
  case['source_sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'stale'):matrix(self.artifacts,bad)
 def test_actual_usl_cooperative_graph_consumes_every_artifact(self):
  report=reuse(self.artifacts,threads=8)
  self.assertTrue(report['all_17_new_artifacts_consumed'])
  self.assertEqual(report['parallel_partial_graph']['verified_count'],18)
  self.assertEqual(report['usl_composed_stdout'],'302\n')
 def test_unapproved_scheduler_native_tasks_are_blocked(self):
  g={'schema':'usl.cooperative.graph.v1','tasks':[{'id':'domain','kind':'domain_expand','inputs':{'language':'jmespath'}}]}
  r=CooperativeScheduler(threads=1,processes=0,allow_native=False).run(g,cache=False)
  self.assertFalse(r['all_verified'])
 def test_registry_has_actual_installed_providers(self):
  d=discover();self.assertEqual(set(d),set(SPEC))
  self.assertTrue(all(x['installed'] for x in d.values()))
  self.assertTrue(all(not x['whole_specification_complete'] for x in d.values()))

if __name__=='__main__':unittest.main()
