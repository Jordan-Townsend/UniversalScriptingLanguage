import copy, json, tempfile, unittest
from usl_systems.entity import Entity, EntitySession
from usl_systems.entity_memory import EntityMemory

def lesson(name='double_plus_one'):
    return {'name':name,'description':'double an integer and add one','evidence_source':'independently labelled arithmetic examples',
        'training':[{'input':x,'expected_stdout':str(x*2+1)+'\n'} for x in [-3,0,4]],
        'holdout':[{'input':x,'expected_stdout':str(x*2+1)+'\n'} for x in [-9,7]]}

class EntityTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.entity=Entity(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def test_learns_and_reuses_after_restart(self):
        learned=self.entity.learn(lesson())
        self.assertTrue(learned['all_passed'])
        self.assertEqual(Entity(self.temp.name).execute_skill('double_plus_one',12,'25\n')['stdout'],'25\n')
    def test_holdout_rejection_does_not_install(self):
        l=lesson();l['holdout'][0]['expected_stdout']='wrong\n'
        with self.assertRaisesRegex(ValueError,'failed'):self.entity.learn(l)
        with self.assertRaisesRegex(ValueError,'not installed'):self.entity.memory.skill(l['name'])
    def test_failed_update_preserves_previous_skill(self):
        l=lesson();self.entity.learn(l)
        failed={**l,'schema':'usl.entity.lesson.v1','source':'print(999)'}
        with self.assertRaises(ValueError):self.entity.study(failed)
        self.assertEqual(self.entity.execute_skill(l['name'],12,'25\n')['version'],1)
    def test_rollback_to_verified_version(self):
        l=lesson();self.entity.learn(l)
        # A second, independently qualified arithmetic behavior.
        l2={**l,'schema':'usl.entity.lesson.v1','source':'print(input_value() * 3)'}
        for key in ('training','holdout'):l2[key]=[{'input':c['input'],'expected_stdout':str(c['input']*3)+'\n'} for c in l[key]]
        self.entity.study(l2)
        self.assertEqual(self.entity.execute_skill(l['name'],12,'36\n')['version'],2)
        self.entity.memory.rollback(l['name'],1)
        self.assertEqual(self.entity.execute_skill(l['name'],12,'25\n')['version'],1)
    def test_overlapping_holdout_rejected(self):
        l=lesson();l['holdout']=[l['training'][0]]
        with self.assertRaisesRegex(ValueError,'disjoint'):self.entity.learn(l)
    def test_execution_alone_is_not_outcome_verification(self):
        self.entity.learn(lesson())
        self.assertFalse(self.entity.execute_skill('double_plus_one',12)['outcome_verified'])
    def test_source_cannot_import_or_access_os(self):
        l={**lesson(),'schema':'usl.entity.lesson.v1','source':'import os\nos.system("anything")'}
        with self.assertRaises(Exception):self.entity.study(l)
    def test_evidence_retrieval_survives_restart_and_quotes(self):
        m=self.entity.memory
        identity=m.remember('A camera observes reflected light.',{'source':'reference optics text'},0.8)
        self.assertEqual(m.remember('A camera observes reflected light.',{'source':'reference optics text'},0.8),identity)
        self.assertEqual(EntityMemory(self.temp.name).retrieve('camera " OR *')[0]['id'],identity)
    def test_confidence_and_provenance_are_required(self):
        with self.assertRaises(ValueError):self.entity.memory.remember('claim',{})
        with self.assertRaises(ValueError):self.entity.memory.remember('claim',{'source':'x'},float('nan'))
    def test_conflicting_facts_are_retained_without_inventing_truth(self):
        a=self.entity.memory.remember_fact('device','temperature',20,{'source':'sensor A'})
        b=self.entity.memory.remember_fact('device','temperature',30,{'source':'sensor B'})
        self.assertEqual(b['conflicting_memory_ids'],[a['memory_id']]);self.assertFalse(b['settled_truth'])
    def test_document_study_retains_exact_evidence(self):
        from pathlib import Path
        path=Path(self.temp.name)/'lesson.md';path.write_text('A prism disperses light into wavelengths.')
        studied=self.entity.memory.study_document(path)
        found=Entity(self.temp.name).memory.retrieve('prism')[0]
        self.assertEqual(found['text'],path.read_text())
        self.assertEqual(found['evidence']['source_sha256'],studied['source_sha256'])
        self.assertFalse(studied['model_weights_changed'])
    def test_recovery_marks_external_actions_for_review(self):
        self.entity.memory.save_run('interrupted','running',{'kind':'native_source'})
        restored=Entity(self.temp.name,recover_interrupted=True)
        self.assertEqual(restored.interrupted_runs,['interrupted'])
        self.assertEqual(restored.memory.run('interrupted')['state'],'needs_review')
    def test_new_reader_does_not_interrupt_live_run(self):
        self.entity.memory.save_run('live','running',{})
        Entity(self.temp.name)
        self.assertEqual(self.entity.memory.run('live')['state'],'running')
    def test_plan_requires_explicit_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):self.entity.plan({'schema':'usl.entity.plan.v1','actions':[]})
    def test_usl_session_learns_and_verifies(self):
        source='let learned = learn_skill(artifact("lesson"))\nlet result = run_skill("double_plus_one", 12, "25\\n")\nassert result["outcome_verified"]\nprint(result["stdout"])'
        r=EntitySession(self.entity,{'lesson':lesson()},approved=True).interpret(source)
        self.assertEqual(r['stdout'],'25\n\n')
    def test_plain_interpreter_has_no_entity_capabilities(self):
        from usl_systems.language import Interpreter
        with self.assertRaises(Exception):Interpreter().run('recall("private")')

if __name__=='__main__':unittest.main()
