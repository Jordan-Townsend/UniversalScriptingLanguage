import json,shutil,unittest
from pathlib import Path
from usl_systems.interop import run_nested,SCHEMA,catalog_matrix
ROOT=Path(__file__).resolve().parents[1]
class PerlSwiftBridgeTests(unittest.TestCase):
    def node(self,lang,source,params=['i64'],returns='i64',args=[4]):
        return {'schema':SCHEMA,'nodes':[{'id':'value','language':lang,'source':source,'export':'transform','params':params,'returns':returns,'args':args}]}
    @unittest.skipUnless(shutil.which('swiftc'),'Swift compiler unavailable')
    def test_swift_real_compilation(self):
        r=run_nested(self.node('swift','func transform(_ x: Int64)->Int64 {x*3}'),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['value']['value'],12)
        self.assertEqual(r['results']['value']['evidence']['build']['exit_code'],0)
    @unittest.skipUnless(shutil.which('swiftc'),'Swift compiler unavailable')
    def test_swift_unicode(self):
        s='func transform(_ x:String)->String {x+"é雪\\n"}'
        r=run_nested(self.node('swift',s,['text'],'text',['hi']),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['value']['value'],'hié雪\n')
    @unittest.skipUnless(shutil.which('swiftc'),'Swift compiler unavailable')
    def test_swift_wrong_type_rejected(self):
        s='func transform(_ x: Int64)->String {"wrong"}'
        r=run_nested(self.node('swift',s),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Swift build failed',r['failures']['value']['reason'])
    @unittest.skipUnless(shutil.which('swiftc'),'Swift compiler unavailable')
    def test_swift_native_array(self):
        s='func transform(_ x:[Int64])->Int64 {x.reduce(0,+)}'
        r=run_nested(self.node('swift',s,['i64[]'],'i64',[[1,2,3,4]]),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['value']['value'],10)
    @unittest.skipUnless(shutil.which('perl'),'Perl unavailable')
    def test_perl_guest(self):
        s='package USLGuest;\nsub transform {my($x)=@_;return $x*3;}\n1;\n'
        r=run_nested(self.node('perl',s),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['value']['value'],12)
    @unittest.skipUnless(shutil.which('perl'),'Perl unavailable')
    def test_perl_missing_export(self):
        s='package USLGuest;\nsub other { return 1; }\n1;\n'
        r=run_nested(self.node('perl',s),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Perl guest failed',r['failures']['value']['reason'])
    @unittest.skipUnless(shutil.which('perl'),'Perl unavailable')
    def test_perl_type_mismatch(self):
        s='package USLGuest;\nsub transform {return "bad";}\n1;\n'
        r=run_nested(self.node('perl',s),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('i64',r['failures']['value']['reason'])
    def test_explicit_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):
            run_nested(self.node('perl','package USLGuest;1;'),authorized=False)
    def test_syntax_catalog_606(self):
        r=catalog_matrix();self.assertEqual(r['count'],606)
        self.assertTrue({'swift','perl'}<={v['native_bridge_family'] for v in r['entries'] if v['native_bridge_family']})
    @unittest.skipUnless(all(shutil.which(t) for t in ('swiftc','perl','go','javac','gcc','node','ruby','php')),'Native toolchains missing')
    def test_eleven_languages_real_native(self):
        p=json.loads((ROOT/'examples/nested_eleven_languages.uslnest.json').read_text())
        r=run_nested(p,authorized=True,workers=3)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(len(r['results']),11)
        self.assertEqual(r['results']['usl']['value'],3601)
if __name__=='__main__':unittest.main()
