import hashlib,tempfile,time,unittest
from pathlib import Path
from usl_systems.store import Store
from usl_systems.repairloop import RepairLoop,RepairError
from usl_systems.autonomy import AutonomyController,AutonomyError

class RepairLoopTests(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
        self.store=Store(Path(t.name)/'state')
        self.src=self.store.safe_project_path('broken','main.py')
        self.src.parent.mkdir(parents=True,exist_ok=True)
        self.src.write_text('def add(a,b)\n    return a+b\n')
        tests=self.src.parent/'tests';tests.mkdir()
        (tests/'test_main.py').write_text('from main import add\nimport unittest\nclass T(unittest.TestCase):\n    def test_value(self):\n        self.assertEqual(add(2,3),5)\n')
    def spec(self,**kw):
        x={'path':'main.py','original_sha256':hashlib.sha256(self.src.read_bytes()).hexdigest(),
           'old':'def add(a,b)\n','new':'def add(a,b):\n','check':'unittest','timeout':12}
        x.update(kw);return x
    def test_staged_syntax_error_is_repaired_and_verified(self):
        r=RepairLoop(self.store).run('broken',self.spec())
        self.assertEqual(r['status'],'completed')
        self.assertTrue(r['verified'])
        self.assertNotEqual(r['baseline_syntax']['exit_code'],0)
        self.assertEqual(r['candidate_syntax']['exit_code'],0)
        self.assertEqual(r['tests']['exit_code'],0)
        self.assertIn('def add(a,b):',self.src.read_text())
        self.assertEqual(Path(r['backup']).read_text(),'def add(a,b)\n    return a+b\n')
    def test_failed_tests_do_not_mutate_original(self):
        (self.src.parent/'tests'/'test_main.py').write_text('from main import add\nimport unittest\nclass T(unittest.TestCase):\n    def test_bad(self):self.assertEqual(add(2,3),500)\n')
        start=self.src.read_bytes();r=RepairLoop(self.store).run('broken',self.spec())
        self.assertEqual(r['status'],'not_applied');self.assertEqual(self.src.read_bytes(),start)
        self.assertNotEqual(r['tests']['exit_code'],0)
    def test_bad_candidate_does_not_commit(self):
        src=self.src.read_bytes();r=RepairLoop(self.store).run('broken',self.spec(new='def add(a,b): garbage\n'))
        self.assertEqual(r['status'],'not_applied');self.assertEqual(self.src.read_bytes(),src)
    def test_stale_hash_and_traversal_rejected(self):
        with self.assertRaises(RepairError):RepairLoop(self.store).run('broken',self.spec(original_sha256='0'*64))
        with self.assertRaises(RepairError):RepairLoop.validate(self.spec(path='../escape.py'))
    def test_autonomy_requires_exact_process_approval(self):
        control=AutonomyController(self.store);self.addCleanup(control.close)
        step={'id':'fix','kind':'dev_repair','project':'broken',**self.spec()}
        plan={'format':'uslauto-1','steps':[step]}
        record=control.create(plan)
        with self.assertRaises(AutonomyError):control.approve(record['id'])
        control.approve(record['id'],allow_process=True)
        control.begin(record['id']);end=time.monotonic()+20
        while time.monotonic()<end:
            r=control.detail(record['id'])
            if r['status'] in ('completed','failed'):break
            time.sleep(.05)
        self.assertEqual(r['status'],'completed',r)
        self.assertTrue(r['outcomes'][0]['successful'])
    def test_repair_is_not_safe_to_autoreplay(self):
        from usl_systems.autonomy import SAFE_TO_RETRY
        self.assertNotIn('dev_repair',SAFE_TO_RETRY)
