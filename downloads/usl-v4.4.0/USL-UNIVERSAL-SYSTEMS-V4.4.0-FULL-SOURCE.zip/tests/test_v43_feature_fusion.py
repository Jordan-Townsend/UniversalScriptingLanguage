import tempfile, unittest
try:
    import torch
    from usl_systems.feature_fusion import ConvBaseline, StackedFeatureFusionNet, CrossModalFusion
except ImportError:torch=None

@unittest.skipIf(torch is None,'optional PyTorch runtime unavailable')
class FeatureFusionTests(unittest.TestCase):
    def setUp(self):torch.set_num_threads(1);torch.manual_seed(29)
    def test_exact_baseline_equivalence_on_different_sizes(self):
        baseline=ConvBaseline();fusion=StackedFeatureFusionNet.from_baseline(baseline)
        for size in (8,13,24):
            x=torch.rand(3,1,size,size)
            torch.testing.assert_close(baseline(x),fusion(x),rtol=0,atol=0)
    def test_stack_and_gates_preserve_batch(self):
        r=StackedFeatureFusionNet().encode(torch.rand(2,1,8,8))
        self.assertEqual(tuple(r['stack'].shape),(2,3,32,2,2))
        torch.testing.assert_close(r['gates'].sum(1),torch.ones(2))
    def test_residual_and_early_projection_receive_gradients(self):
        model=StackedFeatureFusionNet();optimizer=torch.optim.SGD(model.parameters(),lr=0.1)
        x=torch.rand(4,1,8,8);y=torch.tensor([0,1,2,3])
        torch.nn.functional.cross_entropy(model(x),y).backward()
        self.assertGreater(float(model.mix.weight.grad.abs().sum()),0)
        optimizer.step();optimizer.zero_grad()
        torch.nn.functional.cross_entropy(model(x),y).backward()
        self.assertGreater(float(model.projections[0].weight.grad.abs().sum()),0)
    def test_nan_input_rejected(self):
        with self.assertRaises(ValueError):StackedFeatureFusionNet()(torch.full((1,1,8,8),float('nan')))
    def test_missing_modality_has_zero_weight_and_no_effect(self):
        model=CrossModalFusion({'vision':3,'hearing':2},width=8)
        features={'vision':torch.rand(2,3),'hearing':torch.rand(2,2)}
        # Names are hearing, vision; hearing missing in both rows.
        mask=torch.tensor([[False,True],[False,True]])
        first=model(features,mask)
        features['hearing']=torch.ones(2,2)*999
        second=model(features,mask)
        torch.testing.assert_close(first['embedding'],second['embedding'])
        self.assertEqual(first['weights'][:,0].tolist(),[0,0])
    def test_all_missing_modalities_rejected(self):
        model=CrossModalFusion({'touch':1})
        with self.assertRaises(ValueError):model({'touch':torch.zeros(1,1)},torch.tensor([[False]]))
    def test_state_dict_roundtrip(self):
        model=StackedFeatureFusionNet();model.mix.weight.data.fill_(0.01)
        with tempfile.TemporaryDirectory() as root:
            path=root+'/weights.pt';torch.save(model.state_dict(),path)
            restored=StackedFeatureFusionNet();restored.load_state_dict(torch.load(path,weights_only=True))
            x=torch.rand(2,1,8,8);torch.testing.assert_close(model(x),restored(x))

if __name__=='__main__':unittest.main()
