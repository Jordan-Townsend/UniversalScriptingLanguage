import unittest
from usl_systems.language_runtime import discover,run,CONTRACTS,catalog_readiness

class LanguageRuntimeTests(unittest.TestCase):
    def test_discovery_does_not_claim_execution(self):
        self.assertTrue(all(not e['execution_qualified'] for e in discover().values()))
    def test_execution_permission_required(self):
        with self.assertRaisesRegex(ValueError,'approval'):run('hylang','(print 1)')
    def test_unknown_language_cannot_fallback_to_usl(self):
        with self.assertRaisesRegex(ValueError,'known exact'):run('imaginary','print(1)',approved=True)
    def test_actual_hy_loop(self):
        if not discover()['hylang']['available']:self.skipTest('Hy not installed')
        result=run('hylang','(for [x (range 3)] (print (* x x)))',approved=True)
        self.assertEqual(result['value']['stdout'],'0\n1\n4\n')
    def test_actual_coffee_loop(self):
        if not discover()['coffeescript']['available']:self.skipTest('CoffeeScript not installed')
        result=run('coffeescript','console.log x * x for x in [0..2]',approved=True)
        self.assertEqual(result['value']['stdout'],'0\n1\n4\n')
    def test_catalog_readiness_requires_case_evidence(self):
        r=catalog_readiness()
        self.assertEqual(r['catalog_total'],606);self.assertEqual(r['subset_evidence'],71)
        self.assertEqual(r['full_specifications_qualified'],0)

if __name__=='__main__':unittest.main()
