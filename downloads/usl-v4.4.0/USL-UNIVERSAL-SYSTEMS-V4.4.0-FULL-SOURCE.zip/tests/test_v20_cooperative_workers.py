import json,tempfile,unittest
from pathlib import Path
from usl_systems.cooperative_workers import CooperativeScheduler,CooperativeError

SCHEMA='usl.cooperative.graph.v1'
PROJECT={'schema':'usl.module_project.v1','entry':'main','modules':{
    'main':'use helper\nlet x = 8\nprint(twice(x))',
    'helper':'function twice(x):\n    return x*2'},
    'contracts':{'helper.twice':{'params':['int'],'returns':'int'}}}

class CooperativeWorkerTests(unittest.TestCase):
 def setUp(self):self.runner=CooperativeScheduler(threads=3,processes=0)
 def workflow(self):
  return {'schema':SCHEMA,'tasks':[
    {'id':'link','kind':'link','inputs':{'project':PROJECT}},
    {'id':'contracts','kind':'contracts','deps':['link'],'inputs':{'project':PROJECT}},
    {'id':'static','kind':'static_types','deps':['link'],'bind':{'source':'link.linked_source'}},
    {'id':'execute','kind':'interpreter','deps':['link','static','contracts'],'bind':{'source':'link.linked_source'}},
    {'id':'compressed','kind':'compress','deps':['execute'],'bind':{'text':'execute.stdout'}},
    {'id':'numeric','kind':'fractal','inputs':{'values':[1,2,3,4],'operator':'sum_squares'},'lane':'thread'},
    {'id':'finished','kind':'join_evidence','deps':['numeric','compressed','contracts']}]}
 def test_cooperating_results(self):
  g=self.workflow()
  r=self.runner.run(g)
  self.assertTrue(r['all_verified'],r['blocked_or_failed'])
  self.assertEqual(r['tasks']['numeric']['value']['result'],30)
  self.assertTrue(r['tasks']['compressed']['value']['verified_exact'])
  self.assertIn('16',str(r['tasks']['execute']['value']['stdout']))
  self.assertEqual(r['tasks']['finished']['value']['dependencies'],['compressed','contracts','numeric'])
 def test_concurrent_partial_workers_overlap(self):
  graph={'schema':SCHEMA,'tasks':[{'id':k,'kind':'bounded_delay','inputs':{'seconds':0.16}} for k in ('a','b','c')]}
  r=self.runner.run(graph)
  self.assertTrue(r['all_verified'])
  a,b=r['tasks']['a']['value'],r['tasks']['b']['value']
  self.assertLess(max(a['started_ns'],b['started_ns']),min(a['ended_ns'],b['ended_ns']))
 def test_dependency_is_verified_not_assumed(self):
  bad={**PROJECT,'modules':{**PROJECT['modules'],'main':'use helper\nprint(twice("bad"))'}}
  g={'schema':SCHEMA,'tasks':[{'id':'contract','kind':'contracts','inputs':{'project':bad}},
                                {'id':'dependent','kind':'fractal','deps':['contract'],'inputs':{'values':[1]}}]}
  r=self.runner.run(g)
  self.assertFalse(r['all_verified']);self.assertEqual(r['tasks']['contract']['status'],'failed')
  self.assertEqual(r['tasks']['dependent']['status'],'blocked')
 def test_cycle_unknown_operation_and_unverified_native_rejected(self):
  for tasks in ([{'id':'a','kind':'fractal','deps':['b']},{'id':'b','kind':'fractal','deps':['a']}],
               [{'id':'x','kind':'shell'}],
               [{'id':'x','kind':'fractal','deps':['missing']}],
               [{'id':'x','kind':'fractal','bind':{'values':'ghost.result'}}]):
   with self.subTest(tasks=tasks),self.assertRaises(CooperativeError):self.runner.run({'schema':SCHEMA,'tasks':tasks})
  g={'schema':SCHEMA,'tasks':[{'id':'n','kind':'native_verify','inputs':{'source':'print(1)','target':'python'}}]}
  self.assertEqual(self.runner.run(g)['tasks']['n']['status'],'failed')
 def test_checkpoint_requires_hash_and_spec_matching(self):
  with tempfile.TemporaryDirectory() as td:
   file=Path(td)/'state.json';g=self.workflow()
   one=self.runner.run(g,checkpoint=file);two=self.runner.run(g,checkpoint=file)
   self.assertTrue(one['all_verified']);self.assertEqual(two['reused_verified_partials'],7)
   saved=json.loads(file.read_text());saved['results']['numeric']['value']['result']=999
   file.write_text(json.dumps(saved))
   changed=self.runner.run(g,checkpoint=file)
   # Numeric must recompute after its cached value is tampered. The final
   # join MAY reuse its prior result because the recomputed numeric result
   # has exactly the same hash as the original verified numeric result.
   self.assertEqual(changed['reused_verified_partials'],6)
   self.assertFalse(changed['tasks']['numeric']['cache_reused'])
   self.assertTrue(changed['tasks']['finished']['cache_reused'])
   self.assertEqual(changed['tasks']['numeric']['value']['result'],30)
   g['tasks'][5]['inputs']['values']=[10,20]
   other=self.runner.run(g,checkpoint=file)
   self.assertEqual(other['reused_verified_partials'],0)
   self.assertEqual(other['tasks']['numeric']['value']['result'],500)
 def test_process_worker_is_real_and_verified(self):
  # This uses a Python spawn process, not a simulated worker. Windows compatible.
  r=CooperativeScheduler(threads=2,processes=1).run({'schema':SCHEMA,'tasks':[
   {'id':'num','kind':'fractal','lane':'process','inputs':{'operator':'sum_abs','values':[-4,8,-2]}}]})
  self.assertTrue(r['all_verified'],r['blocked_or_failed'])
  self.assertEqual(r['tasks']['num']['value']['result'],14)
  self.assertEqual(r['tasks']['num']['lane'],'process')

if __name__=='__main__':unittest.main()
