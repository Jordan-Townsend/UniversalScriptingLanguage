import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from usl_systems.bridge import ProcessBridge,BridgeError
from usl_systems.store import Store
from usl_systems.swarm import build_swarm


class ProcessBridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(self.tmp.name)
        self.bridge=ProcessBridge(self.store)
    def tearDown(self):
        self.bridge.shutdown()
        self.tmp.cleanup()
    def finished(self,ident,timeout=8):
        start=time.monotonic()
        while time.monotonic()-start<timeout:
            row=self.bridge.detail(ident)
            if row['status'] not in ('starting','running','stopping'):return row
            time.sleep(.04)
        self.fail('Process timed out waiting for bridge watcher to finalize')
    def test_capture_actual_stdout_and_exitcode(self):
        row=self.bridge.launch('demo',[sys.executable,'-u','-c','print("bridge live output")'])
        result=self.finished(row['id'])
        self.assertEqual(result['status'],'completed')
        self.assertEqual(result['exit_code'],0)
        self.assertIn('bridge live output',result['output'])
        self.assertEqual(self.bridge.list()[0]['id'],row['id'])
    def test_detect_failures(self):
        row=self.bridge.launch('demo',[sys.executable,'-c','import sys; print("bad exit");sys.exit(7)'])
        result=self.finished(row['id'])
        self.assertEqual(result['status'],'failed')
        self.assertEqual(result['exit_code'],7)
        self.assertIn('bad exit',result['output'])
    def test_timeout(self):
        row=self.bridge.launch('demo',[sys.executable,'-c','import time;time.sleep(20)'],1)
        result=self.finished(row['id'],timeout=5)
        self.assertEqual(result['status'],'timed_out')
    def test_manual_stop(self):
        row=self.bridge.launch('demo',[sys.executable,'-u','-c','import time; print("ready",flush=True);time.sleep(30)'])
        self.bridge.stop(row['id'])
        result=self.finished(row['id'])
        self.assertEqual(result['status'],'stopped')

    def test_bounded_output(self):
        row=self.bridge.launch('demo',[sys.executable,'-u','-c','print("Z"*90000)'])
        result=self.finished(row['id'])
        self.assertTrue(result['truncated'])
        self.assertLessEqual(len(result['output']),65536)
        self.assertEqual(result['status'],'completed')

    def test_reject_invalid(self):
        for argv in ('echo hi',[],[''],['a\x00b']):
            with self.assertRaises(BridgeError):self.bridge.launch('demo',argv)
        with self.assertRaises(ValueError):self.bridge.launch('../escape',[sys.executable,'-V'])
    def test_persist_and_reopen_history(self):
        row=self.bridge.launch('demo',[sys.executable,'-c','print(42)'])
        completed=self.finished(row['id'])
        # A fresh observer recovers records without inventing a new process.
        other=ProcessBridge(self.store)
        self.assertEqual(other.detail(row['id'])['output'],completed['output'])
        self.assertEqual(other.detail(row['id'])['status'],'completed')
    def test_live_lines_before_exit(self):
        row=self.bridge.launch('demo',[sys.executable,'-u','-c','import time; print("first",flush=True);time.sleep(3);print("second",flush=True)'])
        start=time.monotonic();found_while_running=False
        while time.monotonic()-start<2.2:
            status=self.bridge.detail(row['id'])
            if 'first' in status['output'] and status['status']=='running':
                found_while_running=True;break
            time.sleep(.03)
        self.assertTrue(found_while_running,'Line-buffered live output should appear during a running process')
        self.finished(row['id'])


class SwarmPipelineTests(unittest.TestCase):
    def test_role_calls_and_real_verification(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(tmp)
            outputs=iter(['Plan: print 7 and assert', 'let x = 7\nprint(x)\nassert x == 7', 'Review: matches the numeric requirement'])
            with patch('usl_systems.swarm.agent.ask_model',side_effect=lambda *args,**kwargs:next(outputs)) as model:
                result=build_swarm({'goal':'Print 7','targets':['python'],'project':'demo'},store,'test')
            self.assertEqual(model.call_count,3)
            self.assertTrue(result['source_interpreter_verified'])
            self.assertFalse(result['user_intent_verified'])
            self.assertEqual(result['interpreter_output'].strip(),'7')
            self.assertEqual(result['targets']['python']['status'],'passed')
            self.assertEqual(store.read('demo','main.usl'),result['source'])
            self.assertIn('Review',store.read('demo','swarm/review.txt'))
    def test_rejected_goal_and_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(tmp)
            with self.assertRaisesRegex(Exception,'Goal'):
                build_swarm({'goal':''},store,'t')
            with self.assertRaisesRegex(Exception,'emitter'):
                build_swarm({'goal':'Print 7','targets':['cobol']},store,'t')


if __name__=='__main__':unittest.main()
