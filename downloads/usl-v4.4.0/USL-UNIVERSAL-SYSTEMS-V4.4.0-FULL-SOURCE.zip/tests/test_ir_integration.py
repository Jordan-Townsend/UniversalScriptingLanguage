import ast
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from usl_systems.ir import lower,restore
from usl_systems.language import parse,USLError,Interpreter
from usl_systems.compiler import transpile,transpile_ir,UnsupportedCompile,TARGETS
from usl_systems.integrations import scan,integration_status,legacy_bridge_probe
from usl_systems.qualification import profiles,qualification_report,SAMPLES
from usl_systems.catalog import load_catalog

class IntermediateRepresentationTests(unittest.TestCase):
    SOURCES=['let x = 4\nprint(x+2)', 'function twice(n):\n    return n*2\nprint(twice(3))',
       'let s=0\nfor i in range(4):\n    s += i\nprint(s)',
       'let v=5\nif v>1:\n    print("yes")\nelse:\n    print("no")']
    def test_roundtrip_semantics(self):
        for source in self.SOURCES:
            with self.subTest(source=source):
                ir=lower(source);restored=restore(json.loads(json.dumps(ir)))
                self.assertEqual(ast.dump(parse(source)),ast.dump(restored))
                self.assertEqual(Interpreter().run(source).output,Interpreter().run(ast.unparse(restored)).output)
    def test_integrity_rejects_modifications(self):
        ir=lower('print(3)');ir['body']['fields']['body'][0]['fields']['value']['fields']['args'][0]['fields']['value']=99
        with self.assertRaisesRegex(USLError,'integrity'):restore(ir)
    def test_ir_compiler_matches_direct_generation(self):
        for source in self.SOURCES:
            ir=lower(source)
            for target in ('python','javascript','ruby','php'):
                with self.subTest(target=target):
                    self.assertEqual(transpile(source,target).code,transpile_ir(ir,target).code)
    def test_ir_reports_undefined_variables_without_faking_success(self):
        ir=lower('print(missing_variable)')
        self.assertTrue(any(x['code']=='POSSIBLY_UNDEFINED' for x in ir['diagnostics']))
    def test_ir_preserves_branch_definiteness(self):
        ir=lower('if True:\n    z=3\nprint(z)')
        self.assertTrue(any(x['code']=='POSSIBLY_UNDEFINED' for x in ir['diagnostics']))
    def test_reject_unsafe_source(self):
        with self.assertRaises(USLError):lower('import os')
    def test_stable_fingerprint(self):
        self.assertEqual(lower('let a=3')['ir_sha256'],lower('let a=3')['ir_sha256'])

class IntegrationTests(unittest.TestCase):
    def test_marker_discovery_never_executes_code(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'USL-V031';root.mkdir()
            (root/'INSTALL-USL-WINDOWS.cmd').write_text('echo test')
            result=scan([root]);self.assertEqual(len(result['detected']),1)
            self.assertIn('usl_v031',result['detected'][0]['families'])
            self.assertFalse(result['detected'][0]['executed'])
    def test_missing_path_is_not_present(self):
        self.assertEqual(scan(['/totally/nonexistent/path'])['roots_scanned'],0)
    def test_generic_bridge_module_not_misidentified(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d,'bridge.py').write_text('pass')
            self.assertEqual(scan([d])['detected'],[])
    def test_connection_stays_unverified(self):
        result=integration_status(['/totally/nonexistent/path'])
        self.assertEqual(result['detected'],[])
        self.assertIn('emovision',result['required_contracts'])

class QualificationTests(unittest.TestCase):
    def test_all_catalogued_have_honest_capability_profile(self):
        rows=list(profiles())
        self.assertEqual(len(rows),len(load_catalog()))
        self.assertGreaterEqual(len(rows),606)
        self.assertEqual(sum(x['built_in_semantic_backend'] for x in rows),len(TARGETS))
        self.assertFalse(any(x['complete_semantic_compiler'] for x in rows))
    def test_qualify_without_toolchain_fakes_no_passes(self):
        with patch('usl_systems.qualification.tool_available',return_value=False):
            r=qualification_report(['python'],include_catalog=False)
        self.assertEqual(r['qualification']['python']['passed'],0)
        self.assertFalse(r['all_catalogued_languages_compiled'])
    def test_native_functions_typed(self):
        from usl_systems.native import verify, tool_available
        for t in ('c','cpp','java','go'):
            if tool_available(t):
                with self.subTest(target=t):
                    r=verify(SAMPLES['function'],t)
                    self.assertEqual(r['status'],'passed',r)
    def test_go_else(self):
        from usl_systems.native import verify, tool_available
        if tool_available('go'):
            result=verify(SAMPLES['branch'],'go')
            self.assertEqual(result['status'],'passed',result)

if __name__=='__main__':unittest.main()
