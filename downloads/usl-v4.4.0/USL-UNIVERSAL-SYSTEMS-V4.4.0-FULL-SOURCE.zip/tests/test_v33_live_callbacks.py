import copy,time,unittest
from usl_systems.interop import run_nested,SCHEMA,BridgeError
SRC='def transform(x):\n    return usl_twice(x)+1\n'
CB={'name':'usl_twice','source':'def twice(x):\n    return x*2\n','export':'twice','params':['i64'],'returns':'i64','max_calls':2,'timeout_seconds':4}
class LiveCallbackTests(unittest.TestCase):
    def p(self,source=SRC,cb=CB,args=[8],expected=17):
        return {'schema':SCHEMA,'nodes':[{'id':'py','language':'python','source':source,'export':'transform',
           'params':['i64'],'returns':'i64','args':args,'expected':expected,'callback':copy.deepcopy(cb)}]}
    def test_real_interactive_roundtrip(self):
        r=run_nested(self.p(),authorized=True)
        self.assertTrue(r['all_verified'],r['failures'])
        e=r['results']['py']['evidence'];self.assertEqual(e['mode'],'live_python_usl_callback')
        self.assertEqual(e['callback_count'],1);self.assertGreater(e['callbacks'][0]['USL_operations'],0)
    def test_two_callbacks_same_guest_process(self):
        p=self.p('def transform(x):\n    a=usl_twice(x)\n    b=usl_twice(a)\n    return b+1\n',expected=33)
        r=run_nested(p,authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['py']['evidence']['callback_count'],2)
    def test_max_calls_enforced(self):
        p=self.p('def transform(x):\n    a=usl_twice(x)\n    b=usl_twice(a)\n    return b\n')
        p['nodes'][0]['callback']['max_calls']=1
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('maximum invocation',r['failures']['py']['reason'])
    def test_wrong_callback_type(self):
        r=run_nested(self.p('def transform(x):\n    return usl_twice("bad")\n'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('i64',r['failures']['py']['reason'])
    def test_wrong_callback_contract(self):
        p=self.p();p['nodes'][0]['callback']['returns']='object'
        with self.assertRaisesRegex(ValueError,'callback return'):run_nested(p,authorized=True)
    def test_no_privileged_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):run_nested(self.p(),authorized=False)
    def test_host_language_only(self):
        p=self.p();p['nodes'][0]['language']='java'
        with self.assertRaisesRegex(ValueError,'Python and JavaScript guests only'):run_nested(p,authorized=True)
    def test_unknown_export(self):
        p=self.p();p['nodes'][0]['callback']['export']='absent'
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified'])
    def test_guest_owns_callback_identifier_rejected(self):
        p=self.p('def usl_twice(x):\n    return 5\ndef transform(x):\n    return usl_twice(x)\n')
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('closed callback pipe',r['failures']['py']['reason'])
    def test_timeout_kills_guest(self):
        p=self.p('import time\ndef transform(x):\n    time.sleep(30)\n    return usl_twice(x)\n')
        p['nodes'][0]['callback']['timeout_seconds']=.25
        start=time.perf_counter();r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('timed out',r['failures']['py']['reason'])
        self.assertLess(time.perf_counter()-start,3)
    def test_guest_function_exception(self):
        p=self.p('def transform(x):\n    raise ValueError("fail")\n')
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('closed callback pipe',r['failures']['py']['reason'])
if __name__=='__main__':unittest.main()
