import unittest
from usl_systems.semantic_plugins import Registry,Plugin,PluginError,array_qualification,ARRAY_CASES
from usl_systems.language import Interpreter,USLError
from usl_systems.native import verify,tool_available
class SemanticPluginTests(unittest.TestCase):
 def test_registry_606_coverage_and_zero_false_completeness(self):
  data=Registry().report()
  self.assertEqual(data['catalog_count'],606)
  self.assertEqual(data['verified_full_semantic_compilers'],0)
  self.assertEqual(data['tier_counts']['recognition'],606)
  self.assertTrue(data['tier_counts']['restricted_emitter']>=13)
 def test_resolution_and_nonexecution(self):
  reg=Registry()
  self.assertEqual(reg.resolve('python').id,reg.resolve('PYTHON').id)
  with self.assertRaises(PluginError):reg.resolve('missing-imaginary-language')
  with self.assertRaises(PluginError):reg.add(Plugin('python','Duplicate',('recognition',),None,False,'',''))
  with self.assertRaises(PluginError):reg.add(Plugin('unsafe','Unsafe',('full_compilation',),None,False,'',''))
 def test_interpreter_arrays(self):
  for label,s in ARRAY_CASES.items():
   with self.subTest(label=label):self.assertTrue(Interpreter().run(s).output.strip().isdigit())
 def test_array_rejects_unsupported_negative_native_index(self):
  source='let x = [1,2]\nprint(x[-1])'
  result=verify(source,'javascript')
  self.assertEqual(result['status'],'unsupported_construct')
 def test_array_equivalence_actual_targets(self):
  targets=[x for x in ('python','javascript','ruby','php') if tool_available(x)]
  report=array_qualification(targets=targets)
  self.assertEqual(report['passed'],report['total'],report)
  self.assertEqual(report['total'],len(targets)*6)
if __name__=='__main__':unittest.main()
