import json,tempfile,unittest,urllib.request,urllib.error
from threading import Thread
from http.server import ThreadingHTTPServer
from usl_systems.server import Handler
from usl_systems.store import Store
from test_v43_entity import lesson

class EntityHTTPTests(unittest.TestCase):
    def setUp(self):
        class H(Handler):pass
        self.temp=tempfile.TemporaryDirectory();H.store=Store(self.temp.name);H.store.stop_token='test-entity-control'
        self.server=ThreadingHTTPServer(('127.0.0.1',0),H);self.thread=Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base=f'http://127.0.0.1:{self.server.server_port}'
    def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join(timeout=2);self.temp.cleanup()
    def request(self,path,body=None,token=True):
        headers={'Content-Type':'application/json'}
        if token:headers['X-USL-Control-Token']='test-entity-control'
        req=urllib.request.Request(self.base+path,data=json.dumps(body).encode() if body is not None else None,headers=headers)
        with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
    def test_entity_mutations_need_token_and_approval(self):
        for token,approved in [(False,True),(True,False)]:
            with self.assertRaises(urllib.error.HTTPError) as err:self.request('/api/entity/learn',{'lesson':lesson(),'approve_execution':approved},token)
            self.assertEqual(err.exception.code,403)
    def test_http_learning_then_execution_and_retrieval(self):
        learned=self.request('/api/entity/learn',{'lesson':lesson(),'approve_execution':True})
        self.assertTrue(learned['all_passed'])
        plan={'schema':'usl.entity.plan.v1','actions':[{'kind':'skill','name':'double_plus_one','input':12,'expected_stdout':'25\n'}]}
        result=self.request('/api/entity/plan',{'plan':plan,'approve_execution':True})
        self.assertTrue(result['results'][0]['result']['outcome_verified'])
        memory=self.request('/api/entity/memory?q=double')
        self.assertGreater(len(memory['matches']),0)
    def test_memory_cannot_be_read_without_control_token(self):
        with self.assertRaises(urllib.error.HTTPError) as err:self.request('/api/entity/memory?q=private',token=False)
        self.assertEqual(err.exception.code,403)
    def test_failed_study_returns_error_and_does_not_install(self):
        l=lesson();l['holdout'][0]['expected_stdout']='wrong'
        with self.assertRaises(urllib.error.HTTPError) as err:self.request('/api/entity/learn',{'lesson':l,'approve_execution':True})
        self.assertEqual(err.exception.code,400)

if __name__=='__main__':unittest.main()
