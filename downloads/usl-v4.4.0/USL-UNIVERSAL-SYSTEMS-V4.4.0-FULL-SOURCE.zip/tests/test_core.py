import json,os,tempfile,unittest,ast
from pathlib import Path
from usl_systems.language import Interpreter,parse,USLError,LimitExceeded
from usl_systems.compiler import transpile,TARGETS,UnsupportedCompile
from usl_systems.catalog import load_catalog,syntax_catalog,native_extension
from usl_systems.native import verify,tool_available
from usl_systems.store import Store
from usl_systems.engine import Engine
from usl_systems.pack import package,verify_package
from usl_systems.adapters import AdapterRegistry,detect

class LanguageTests(unittest.TestCase):
    def run_usl(self,s):return Interpreter(max_ops=25000,timeout=2).run(s)
    def test_let_and_print(self):self.assertEqual(self.run_usl('let x = 4\nprint x+3').output,'7\n')
    def test_legacy_symbolic(self):self.assertEqual(self.run_usl('Symbolic: let a = 2\nSymbolic[python]: print(a)').output,'2\n')
    def test_cpp_style_comment(self):self.assertEqual(self.run_usl('// note\nlet a=2\nprint a').output,'2\n')
    def test_function(self):self.assertEqual(self.run_usl('function twice(x):\n    return x * 2\nprint(twice(21))').output,'42\n')
    def test_conditionals(self):self.assertEqual(self.run_usl('let a=5\nif a > 4:\n    print("yes")\nelse:\n    print("no")').output,'yes\n')
    def test_for(self):self.assertEqual(self.run_usl('let n=0\nfor i in range(5):\n    n += i\nprint(n)').output,'10\n')
    def test_while(self):self.assertEqual(self.run_usl('let i=0\nwhile i<5:\n    i += 1\nprint i').output,'5\n')
    def test_bool_logic(self):self.assertEqual(self.run_usl('let ok=True\nif ok and 2 < 3:\n    print("yes")').output,'yes\n')
    def test_indexing(self):self.assertEqual(self.run_usl('let vals=[9,8,7]\nprint(vals[1])').output,'8\n')
    def test_assert_failure(self):
        with self.assertRaisesRegex(USLError,'Assertion'):self.run_usl('assert 3 == 2')
    def test_reject_import(self):
        with self.assertRaisesRegex(USLError,'Unsupported'):parse('import os')
    def test_reject_attributes(self):
        with self.assertRaisesRegex(USLError,'Unsafe'):parse('print((1).__class__)')
    def test_reject_exec(self):
        with self.assertRaisesRegex(USLError,'unsupported function'):self.run_usl('exec("print(7)")')
    def test_reject_file_access(self):
        with self.assertRaisesRegex(USLError,'unsupported function'):self.run_usl('open("important.txt")')
    def test_stop_infinite_loop(self):
        with self.assertRaises(LimitExceeded):Interpreter(max_ops=120,timeout=2).run('while True:\n    pass')
    def test_stop_huge_range(self):
        with self.assertRaises(LimitExceeded):self.run_usl('for i in range(10000000):\n    pass')
    def test_cannot_use_private(self):
        with self.assertRaises(USLError):parse('print(__import__("os"))')
    def test_output_limit(self):
        with self.assertRaises(LimitExceeded):Interpreter(max_output=10).run('print("A" * 20)')

class TranslationTests(unittest.TestCase):
    SAMPLE='let sum = 0\nfor i in range(5):\n    sum += i\nprint(sum)'
    def test_target_count(self):self.assertGreaterEqual(len(TARGETS),13)
    def test_transpile_all_13(self):
        for target in TARGETS:
            with self.subTest(target=target):
                g=transpile(self.SAMPLE,target)
                self.assertGreater(len(g.code),20)
                self.assertIn('10' if False else 'sum',g.code)
    def test_reject_unsupported_syntax(self):
        with self.assertRaises(UnsupportedCompile):transpile('let x = 5','ada')
    def test_sample_native_equivalence(self):
        checked=0
        for lang in ('python','javascript','ruby','php','go','java','cpp','c'):
            if not tool_available(lang):continue
            with self.subTest(lang=lang):
                a=verify(self.SAMPLE,lang)
                self.assertEqual(a['status'],'passed',f'{lang}: {str(a)[:1300]}')
                checked+=1
        self.assertGreaterEqual(checked,2)
    def test_unsupported_type_rejected(self):
        with self.assertRaises(UnsupportedCompile):transpile('let z = [1,2,3]','c')

class CatalogTests(unittest.TestCase):
    def test_500_plus(self):self.assertGreaterEqual(len(load_catalog()),500)
    def test_all_entries_names_and_aliases(self):
        for row in load_catalog():
            self.assertTrue(row['id']);self.assertTrue(row['name']);self.assertIn('support',row)
    def test_known_language(self):self.assertIn('python',[x['id'] for x in load_catalog()])
    def test_filename_detection(self):self.assertIn('python',[x['id'] for x in detect('hello.py')])
    def test_legacy_merge(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'reg.json';p.write_text(json.dumps({'usl-secret-legacy':{'structure':{'print':'{}'}}}))
            rows=load_catalog(p)
            self.assertIn('usl-secret-legacy',[x['id'] for x in rows])
    def test_native_adapter_config(self):
        with tempfile.TemporaryDirectory() as d:
            reg=AdapterRegistry(Store(d))
            self.assertEqual(reg.canonical('py'),'python')
            reg.configure('python',['{python}','{file}'])
            src=Path(d)/'hello.py';src.write_text('print(42)')
            self.assertEqual(reg.run('python',src,allow=True)['stdout'],'42\n')
            with self.assertRaises(USLError):reg.run('python',src,allow=False)

class StateTests(unittest.TestCase):
    def test_persist_tasks_and_memory(self):
        with tempfile.TemporaryDirectory() as d:
            s=Store(d);s.create('abc','run',{'source':'print(3)'});s.update('abc','completed',{'output':'3\n'})
            s.remember('user.theme','dark')
            reopened=Store(d)
            self.assertEqual(reopened.job('abc')['status'],'completed')
            self.assertEqual(reopened.recall('user.theme'),'dark')
    def test_path_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            s=Store(d)
            with self.assertRaises(ValueError):s.save('demo','../../unsafe','hi')
            with self.assertRaises(ValueError):s.save('../root','file','hi')
    def test_package_integrity(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'source';root.mkdir();(root/'main.usl').write_text('print("ok")')
            path=Path(d)/'x.uslpack.zip';package(root,path)
            self.assertTrue(verify_package(path)['verified'])
    def test_background_engine(self):
        import time
        with tempfile.TemporaryDirectory() as d:
            s=Store(d);eng=Engine(s);id_=eng.submit('run',{'source':'print("hello")'})['task_id']
            for _ in range(200):
                job=s.job(id_)
                if job['status'] in ('completed','failed'):break
                time.sleep(.02)
            self.assertEqual(job['status'],'completed');self.assertEqual(job['result']['output'],'hello\n')
            eng.pool.shutdown(wait=True)

if __name__=='__main__':unittest.main()
