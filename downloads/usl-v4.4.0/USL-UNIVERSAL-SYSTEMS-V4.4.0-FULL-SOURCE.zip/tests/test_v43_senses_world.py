import array, tempfile, unittest, wave
from pathlib import Path
from usl_systems.senses import packet, validate_packet, synchronize, audio_observation, readiness
from usl_systems.sensor_devices import capture, serial_observation
from usl_systems.entity_memory import EntityMemory
from usl_systems.world_model import WorldModel

class SenseWorldTests(unittest.TestCase):
    def test_timestamps_and_missing_senses_are_explicit(self):
        p=packet('touch',[2.5],'test.load_cell',{'source':'calibrated test fixture'},mode='synthetic_test',timestamp=100)
        q=packet('temperature',[20],'test.thermometer',{'source':'calibrated test fixture'},mode='synthetic_test',timestamp=100.1)
        frame=synchronize([p,q]);self.assertIn('vision',frame['missing']);self.assertFalse(frame['semantic_understanding_qualified'])
    def test_sensor_skew_rejected(self):
        p=packet('touch',[1],'test',{'source':'fixture'},timestamp=1)
        q=packet('temperature',[20],'test',{'source':'fixture'},timestamp=2)
        with self.assertRaisesRegex(ValueError,'skew'):synchronize([p,q])
    def test_unit_and_nan_rejected(self):
        p=packet('touch',[1],'test',{'source':'fixture'});p['unit']='celsius'
        with self.assertRaises(ValueError):validate_packet(p)
        with self.assertRaises(ValueError):packet('touch',[float('nan')],'test',{'source':'fixture'})
    def test_actual_pcm_analysis(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'sample.wav'
            with wave.open(str(path),'wb') as wav:
                wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(16000);wav.writeframes(array.array('h',[16384,-16384]*800).tobytes())
            p=audio_observation(path)
            self.assertAlmostEqual(p['features'][0],0.5);self.assertAlmostEqual(p['features'][3],0.1)
            self.assertFalse(p['evidence']['speech_recognition'])
    def test_device_actions_require_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):capture('camera','unused.png')
        with self.assertRaisesRegex(ValueError,'approval'):serial_observation('/dev/missing')
    def test_readiness_does_not_invent_hardware(self):
        self.assertFalse(readiness()['human_sensory_equivalence'])
        self.assertTrue(all(not x['live_qualified'] for x in readiness()['senses'].values()))
    def test_grounded_velocity_and_prediction_error(self):
        with tempfile.TemporaryDirectory() as root:
            world=WorldModel(EntityMemory(root))
            base={'object_id':'moving-object','frame':'lab','unit':'metre','evidence':{'source':'synthetic labelled positions'}}
            first=world.update({**base,'timestamp':1,'position':[0,0,0]})
            self.assertIsNone(first['velocity'])
            world.update({**base,'timestamp':2,'position':[2,0,0]})
            self.assertEqual(world.predict('moving-object',1)['position'],[4,0,0])
            moved=world.update({**base,'timestamp':3,'position':[5,0,0]})
            self.assertEqual(moved['prediction_error_metres'],1)
    def test_world_model_refuses_unobserved_prediction(self):
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaises(ValueError):WorldModel(EntityMemory(root)).predict('unknown',1)
    def test_coordinate_frames_cannot_be_silently_mixed(self):
        with tempfile.TemporaryDirectory() as root:
            world=WorldModel(EntityMemory(root));base={'object_id':'x','unit':'metre','position':[0,0,0],'evidence':{'source':'fixture'}}
            world.update({**base,'frame':'a','timestamp':1})
            with self.assertRaises(ValueError):world.update({**base,'frame':'b','timestamp':2})

if __name__=='__main__':unittest.main()
