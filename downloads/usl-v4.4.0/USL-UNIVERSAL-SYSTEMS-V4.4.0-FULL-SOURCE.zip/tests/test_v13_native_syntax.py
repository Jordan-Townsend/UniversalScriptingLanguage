import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from usl_systems.native_syntax import CAPABILITIES,check_source,available,NativeSyntaxError
from usl_systems.catalog import load_catalog
from usl_systems.store import Store
from usl_systems.engine import Engine
from usl_systems.bridge import ProcessBridge
from usl_systems.autonomy import AutonomyController
from usl_systems.server import Handler

SAMPLES={
 'javascript':('function add(x){ return x + 1; }','function add( {'),
 'ruby':('def add(x)\n x + 1\nend\n','def add(x\n x + 1\nend\n'),
 'php':('<?php function add($x) {return $x + 1;}','<?php function add($x) {return $x +;}'),
 'go':('package main\nfunc add(x int) int { return x+1 }\n','package main\nfunc add( {\n'),
 'c':('int add(int x){return x+1;}','int add( {'),
 'cpp':('int add(int x){return x+1;}','int add( {'),
 'java':('public class USLCheck { public static int add(int x) {return x+1;} }','public class USLCheck { public static int add(int x) {return x+;} }'),
}
class NativeChecks(unittest.TestCase):
 def test_seven_adapters_have_real_valid_and_invalid_evidence(self):
  self.assertTrue(set(SAMPLES).issubset(set(CAPABILITIES)))
  installed=available()
  tested=0
  for lang,(valid,invalid) in SAMPLES.items():
   if not installed[lang]['installed']:continue
   tested+=1
   with self.subTest(language=lang,kind='valid'):
    record=check_source(lang,valid,authorized=True)
    self.assertTrue(record['syntax_valid'],record)
    self.assertEqual(record['exit_code'],0)
    self.assertFalse(record['source_executed'])
    self.assertFalse(record['semantic_equivalence_proven'])
   with self.subTest(language=lang,kind='invalid'):
    record=check_source(lang,invalid,authorized=True)
    self.assertFalse(record['syntax_valid'],record)
    self.assertNotEqual(record['exit_code'],0)
  self.assertGreaterEqual(tested,1,'No syntax-check toolchains installed')
 def test_reject_unauthorized_and_oversized(self):
  with self.assertRaises(NativeSyntaxError):check_source('javascript','const x=1')
  with self.assertRaises(NativeSyntaxError):check_source('java','x'*262145,authorized=True)
  with self.assertRaises(NativeSyntaxError):check_source('java','x',authorized=True,timeout=0)
  with self.assertRaises(NativeSyntaxError):check_source('someinventedlang','x',authorized=True)
 def test_language_catalog_kept_and_not_claimed_compiled(self):
  self.assertEqual(len(load_catalog()),606)
  self.assertGreaterEqual(len(CAPABILITIES),7)
 def test_local_http_token_gate(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=Store(Path(tmp)/'data');store.stop_token='private-native-token'
   engine=Engine(store);bridge=ProcessBridge(store);autonomy=AutonomyController(store,bridge)
   class H(Handler):pass
   H.store=store;H.engine=engine;H.bridge=bridge;H.autonomy=autonomy
   server=ThreadingHTTPServer(('127.0.0.1',0),H)
   thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   try:
    url=f'http://127.0.0.1:{server.server_port}/api/syntax/native-check'
    payload=json.dumps({'language':'javascript','source':'let a = 1;','approve_native':True}).encode()
    def send(token):
     head={'Content-Type':'application/json'}
     if token:head['X-USL-Control-Token']=token
     req=urllib.request.Request(url,method='POST',headers=head,data=payload)
     with urllib.request.urlopen(req,timeout=10) as resp:return json.load(resp)
    with self.assertRaises(urllib.error.HTTPError) as fail:send(None)
    self.assertEqual(fail.exception.code,403)
    if available()['javascript']['installed']:
     result=send('private-native-token')
     self.assertEqual(result['exit_code'],0)
     self.assertTrue(result['syntax_valid'])
   finally:
    server.shutdown();server.server_close();thread.join(3);autonomy.close();bridge.shutdown();engine.pool.shutdown(wait=False,cancel_futures=True)
if __name__=='__main__':unittest.main()
