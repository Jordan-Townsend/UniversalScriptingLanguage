"""Real positive and negative qualification, no mocked compiler outputs."""
import copy
import json
from pathlib import Path
import shutil
import sys
import unittest
from usl_systems.interop import (
    SCHEMA, BridgeError, bridge_eligibility_matrix, catalog_matrix, python_subset_import,
    run_nested, python_host_call_usl,validate_project,validate_value
)
ROOT=Path(__file__).resolve().parents[1]
DEMO=json.loads((ROOT/'examples/nested_languages.uslnest.json').read_text('utf8'))
class NativeNesting(unittest.TestCase):
    def test_606_entries(self):
        m=catalog_matrix();self.assertEqual(m['count'],606)
        self.assertEqual(len(m['entries']),606)
        self.assertFalse(any(x['native_execution_qualified'] for x in m['entries']))
        p=bridge_eligibility_matrix();self.assertEqual(p['total_pair_count'],367236)
        self.assertEqual(p['conditional_pair_count'],len(p['conditional_host_guest'])**2)
    def test_requires_approval(self):
        with self.assertRaisesRegex(BridgeError,'approval'):run_nested(DEMO)
    @unittest.skipUnless(shutil.which('node') and (shutil.which('gcc') or shutil.which('cc')),'Toolchains unavailable')
    def test_actual_c_python_js_usl(self):
        r=run_nested(DEMO,authorized=True,workers=3)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(r['results']['finish']['value'],1682)
        self.assertEqual(r['results']['square']['evidence']['mode'],'compiled_c_abi_isolated_process')
        self.assertEqual(r['results']['increment']['evidence']['exit_code'],0)
    def test_wrong_abi_rejected(self):
        p=copy.deepcopy(DEMO);p['nodes'][1]['params']=['text']
        with self.assertRaisesRegex(BridgeError,'ABI type mismatch'):validate_project(p)
    def test_reject_boolean_as_i64(self):
        with self.assertRaises(BridgeError):validate_value(True,'i64')
        with self.assertRaises(BridgeError):validate_value(1<<64,'i64')
    def test_reject_invalid_shapes(self):
        with self.assertRaises(BridgeError):validate_value(['3'],'i64[]')
    def test_dag_works_out_of_order(self):
        p=copy.deepcopy(DEMO);p['nodes'].reverse();validate_project(p)
        if shutil.which('node') and (shutil.which('gcc') or shutil.which('cc')):
            self.assertEqual(run_nested(p,authorized=True)['results']['finish']['value'],1682)
    def test_cycle_rejected(self):
        p={'schema':SCHEMA,'nodes':[
            {'id':'alpha','language':'usl','source':'def f(x):\n    return x\n','export':'f','params':['i64'],'returns':'i64','args':[{'ref':'beta'}]},
            {'id':'beta','language':'usl','source':'def f(x):\n    return x\n','export':'f','params':['i64'],'returns':'i64','args':[{'ref':'alpha'}]}]}
        with self.assertRaisesRegex(BridgeError,'Dependency cycle'):validate_project(p)
    def test_missing_reference(self):
        p=copy.deepcopy(DEMO);p['nodes'][1]['args']=[{'ref':'absent'}]
        with self.assertRaisesRegex(BridgeError,'Missing/self'):validate_project(p)
    def test_python_host_usl_guest(self):
        r=python_host_call_usl('def triple(x):\n    return x*3\n','triple',[14],['i64'],'i64')
        self.assertEqual(r['value'],42)
    def test_actual_python_source_frontend(self):
        m=python_subset_import('def twice(x):\n    return x*2\n')
        self.assertEqual(m['ir']['schema'],'usl.semantic_ir')
    def test_unsafe_python_frontend_rejected(self):
        from usl_systems.language import USLError
        with self.assertRaises(USLError):python_subset_import('import subprocess\n')
    def test_python_guest_error_blocks_downstream(self):
        p={'schema':SCHEMA,'nodes':[
            {'id':'bad','language':'python','source':'def fail(x):\n    raise Exception("bad")\n','export':'fail','params':['i64'],'returns':'i64','args':[1]},
            {'id':'later','language':'usl','source':'def f(x):\n    return x\n','export':'f','params':['i64'],'returns':'i64','args':[{'ref':'bad'}]}]}
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertEqual(r['failures']['later']['status'],'blocked')
    @unittest.skipUnless(shutil.which('gcc') or shutil.which('cc'),'C compiler unavailable')
    def test_c_compile_failure(self):
        p={'schema':SCHEMA,'nodes':[{'id':'bad','language':'c','source':'INVALID C !!!!',
              'export':'f','params':['i64'],'returns':'i64','args':[1]}]}
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('C compile failed',r['failures']['bad']['reason'])
    @unittest.skipUnless(shutil.which('node'),'Node unavailable')
    def test_js_abi_return_type(self):
        p={'schema':SCHEMA,'nodes':[{'id':'bad','language':'javascript','source':'export function f(x){return "wrong";}\n',
              'export':'f','params':['i64'],'returns':'i64','args':[1]}]}
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('i64',r['failures']['bad']['reason'])
    def test_speculative_not_real_bridge(self):
        m=catalog_matrix()
        self.assertFalse(m['pairs_are_tested']) if 'pairs_are_tested' in m else self.assertFalse(m['matrix_policy'].get('tested',False))
if __name__=='__main__':unittest.main()
