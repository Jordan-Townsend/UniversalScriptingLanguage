import json,shutil,unittest
from pathlib import Path
from usl_systems.interop import run_nested,SCHEMA,catalog_matrix
ROOT=Path(__file__).resolve().parents[1]
CPP_SRC='#include <cstdint>\nextern "C" int64_t transform(int64_t x){return x+3;}\n'
BASH_SRC='transform(){ echo $(( $1 + 3 )); }\n'
class CppBashTests(unittest.TestCase):
    def node(self,language,source,param='i64',ret='i64',arg=4):
        return {'schema':SCHEMA,'nodes':[{'id':'t','language':language,'source':source,'export':'transform','params':[param],'returns':ret,'args':[arg]}]}
    @unittest.skipUnless(shutil.which('g++') or shutil.which('clang++'),'C++ compiler unavailable')
    def test_cpp_shared_abi(self):
        r=run_nested(self.node('cpp',CPP_SRC),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['t']['value'],7)
        self.assertEqual(r['results']['t']['evidence']['build']['exit_code'],0)
    @unittest.skipUnless(shutil.which('g++') or shutil.which('clang++'),'C++ compiler unavailable')
    def test_cpp_requires_extern_c(self):
        src='#include <cstdint>\nint64_t transform(int64_t x){return x;}\n'
        r=run_nested(self.node('cpp',src),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('CPP guest failed',r['failures']['t']['reason'])
    @unittest.skipUnless(shutil.which('g++') or shutil.which('clang++'),'C++ compiler unavailable')
    def test_cpp_rejects_invalid_syntax(self):
        r=run_nested(self.node('cpp','#include <notexist>\n'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('CPP compile failed',r['failures']['t']['reason'])
    @unittest.skipUnless(shutil.which('bash'),'Bash unavailable')
    def test_bash_function(self):
        r=run_nested(self.node('bash',BASH_SRC),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['t']['value'],7)
    @unittest.skipUnless(shutil.which('bash'),'Bash unavailable')
    def test_bash_error(self):
        r=run_nested(self.node('bash','transform(){ echo failure 1>&2; return 5; }'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Bash guest failed',r['failures']['t']['reason'])
    @unittest.skipUnless(shutil.which('bash'),'Bash unavailable')
    def test_bash_wrong_output(self):
        r=run_nested(self.node('bash','transform(){ echo not_an_integer; }'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Bash i64 output invalid',r['failures']['t']['reason'])
    @unittest.skipUnless(shutil.which('bash'),'Bash unavailable')
    def test_bash_argv_not_evaled(self):
        literal='hello; $(exit 9) | text'
        r=run_nested(self.node('bash',"transform(){ printf '%s\\n' \"$1\"; }",'text','text',literal),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['t']['value'],literal)
    def test_permission(self):
        with self.assertRaisesRegex(ValueError,'approval'):run_nested(self.node('bash',BASH_SRC),authorized=False)
    def test_catalog_bridges(self):
        x=catalog_matrix();self.assertEqual(x['count'],606)
        r={v['native_bridge_family'] for v in x['entries'] if v['native_bridge_family']}
        self.assertTrue({'cpp','bash'}<=r)
    @unittest.skipUnless(all(shutil.which(x) for x in ('g++','bash','tsc','kotlinc','swiftc','perl','javac','go','ruby','php','node','gcc')), 'Native toolchains missing')
    def test_fifteen_real_engines(self):
        p=json.loads((ROOT/'examples/nested_fifteen_languages.uslnest.json').read_text())
        r=run_nested(p,authorized=True,workers=3)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(len(r['results']),15)
        self.assertEqual(r['results']['usl']['value'],19601)
if __name__=='__main__':unittest.main()
