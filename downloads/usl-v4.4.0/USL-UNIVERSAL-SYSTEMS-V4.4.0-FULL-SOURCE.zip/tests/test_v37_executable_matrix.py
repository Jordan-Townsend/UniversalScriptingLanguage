"""Actual matrix execution tests; a conditional cell is NEVER a passing compiler."""
import hashlib,json,shutil,tempfile,unittest
from pathlib import Path
from usl_systems.interop import run_nested,BridgeError,SCHEMA
from usl_systems.executable_matrix import (fixtures,run_language_qualifications,pair_eligibility,
            execute_pair,run_pairs,build_dense_matrix,cell_value)
ROOT=Path(__file__).resolve().parents[1]
class MatrixTests(unittest.TestCase):
    def test_all_606x606_cells_have_a_status(self):
        grid,m=build_dense_matrix()
        self.assertEqual(len(m['entry_order']),606)
        self.assertEqual(len(grid),367236)
        self.assertEqual(m['count_unverified']+m['count_conditional_unverified']+m['count_executed_verified'],367236)
        self.assertEqual(cell_value(grid,m,'abap','python'),'unverified')
        self.assertEqual(cell_value(grid,m,'python','javascript'),'conditional_not_executed')
        self.assertNotEqual(m['count_conditional_unverified'],367236)
    def test_all_fixtures_and_incompatible_pair(self):
        f=fixtures()
        self.assertEqual(len(f),18)
        self.assertEqual(pair_eligibility('sed','c',f),'incompatible_declared_abi')
        self.assertEqual(pair_eligibility('sed','sed',f),'conditionally_routable')
        self.assertEqual(pair_eligibility('abap','python',f),'unverified')
    def test_execution_requires_explicit_approval(self):
        with self.assertRaisesRegex(BridgeError,'approval'):
            execute_pair('python','javascript')
        with self.assertRaisesRegex(BridgeError,'approval'):
            run_language_qualifications()
        with self.assertRaisesRegex(BridgeError,'approval'):
            run_pairs([('python','javascript')])
    def test_real_python_js_pair_and_evidence_marks_only_that_pair(self):
        obs=execute_pair('python','javascript',authorized=True)
        self.assertTrue(obs['verified']);self.assertEqual(obs['actual_values'],{'host':40,'guest':41})
        grid,meta=build_dense_matrix(pair_evidence={'pairs':[obs]})
        self.assertEqual(cell_value(grid,meta,'python','javascript'),'observed_verified')
        self.assertEqual(cell_value(grid,meta,'javascript','python'),'conditional_not_executed')
        self.assertEqual(meta['count_executed_verified'],1)
    def test_malformed_pairs_rejected(self):
        with self.assertRaises(ValueError):run_pairs([('python','javascript'),('python','javascript')],authorized=True)
    def test_invalid_foreign_and_incorrect_type_are_not_verified(self):
        result=execute_pair('sed','c',authorized=True)
        self.assertEqual(result['status'],'incompatible_declared_abi');self.assertFalse(result['verified'])
    @unittest.skipUnless(shutil.which('awk'),'awk unavailable')
    def test_real_awk_execution(self):
        n={'id':'awk','language':'awk','source':'function transform(x) { return x + 9 }\n',
           'export':'transform','params':['i64'],'returns':'i64','args':[41],'expected':50}
        r=run_nested({'schema':SCHEMA,'nodes':[n]},authorized=True)
        self.assertTrue(r['all_verified']);self.assertEqual(r['results']['awk']['value'],50)
        self.assertEqual(r['results']['awk']['evidence']['mode'],'awk_function_subprocess')
    @unittest.skipUnless(shutil.which('sed'),'sed unavailable')
    def test_real_sed_execution_and_negative(self):
        n={'id':'sed','language':'sed','source':'s/cat/dog/g\n',
           'export':'transform','params':['text'],'returns':'text','args':['cat here'],'expected':'dog here'}
        r=run_nested({'schema':SCHEMA,'nodes':[n]},authorized=True)
        self.assertTrue(r['all_verified']);self.assertEqual(r['results']['sed']['value'],'dog here')
        n['source']='INVALID SED [\\n'
        r=run_nested({'schema':SCHEMA,'nodes':[n]},authorized=True)
        self.assertFalse(r['all_verified'])
    def test_real_sed_chain(self):
        r=execute_pair('sed','sed',authorized=True)
        self.assertTrue(r['verified'],r)
        self.assertEqual(r['actual_values']['host'],'dog here')
        self.assertEqual(r['actual_values']['guest'],'dog here')
    def test_a_parallel_qualification_records_real_execution(self):
        r=run_language_qualifications(authorized=True,workers=3,include=['python','javascript','ruby'])
        self.assertEqual(r['attempted_real_execution'],3)
        self.assertEqual(r['verified_exact_subsets'],3,r)
        self.assertEqual(r['failed_real_execution'],0)
        self.assertEqual(len(r['catalog']),606)
        self.assertEqual(next(x for x in r['catalog'] if x['id']=='abap')['status'],'not_yet_executable_qualified')
        grid,metadata=build_dense_matrix(language_evidence=r)
        self.assertEqual(cell_value(grid,metadata,'python','javascript'),'conditional_not_executed')
        self.assertEqual(cell_value(grid,metadata,'abap','python'),'unverified')
if __name__=='__main__':unittest.main()

class MatrixCooperativeTests(unittest.TestCase):
    def test_native_cooperative_pair_probe_requires_explicit_permission(self):
        from usl_systems.cooperative_workers import CooperativeScheduler
        graph={'schema':'usl.cooperative.graph.v1','tasks':[
            {'id':'pair','kind':'matrix_pair_probe','inputs':{'host':'python','guest':'javascript'}}]}
        blocked=CooperativeScheduler(threads=2,processes=0).run(graph)
        self.assertFalse(blocked['all_verified']);self.assertEqual(blocked['tasks']['pair']['status'],'failed')
        allowed=CooperativeScheduler(threads=2,processes=0,allow_native=True).run(graph)
        self.assertTrue(allowed['all_verified'],allowed['blocked_or_failed'])
        self.assertEqual(allowed['tasks']['pair']['value']['observed_values']['guest'],41)
    def test_four_native_pair_workers_and_verified_evidence_join(self):
        from usl_systems.cooperative_workers import CooperativeScheduler
        graph=json.loads((ROOT/'examples/cooperative_executable_matrix.json').read_text('utf8'))
        result=CooperativeScheduler(threads=4,processes=0,allow_native=True,max_in_flight=4).run(graph)
        self.assertTrue(result['all_verified'],result['blocked_or_failed'])
        self.assertEqual(result['verified_count'],5)
        self.assertEqual(result['tasks']['join']['value']['dependencies'],['awk_c','python_js','ruby_php','sed_sed'])
        self.assertLessEqual(result['max_active_observed'],4)
