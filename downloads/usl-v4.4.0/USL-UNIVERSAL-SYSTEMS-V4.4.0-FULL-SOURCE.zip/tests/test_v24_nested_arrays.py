"""Nested fixed-size array contracts for the supported closed-world USL subset."""
import unittest
from usl_systems.module_linker import SCHEMA,link_project,LinkError
from usl_systems.module_contracts import validate_contracts
from usl_systems.native import verify,tool_available

MAIN='use matrix\nprint(pick([[1,2],[3,4]]))'
LIB='function pick(grid):\n    return grid[1][0]'
BASE={'schema':SCHEMA,'entry':'main','modules':{'main':MAIN,'matrix':LIB},
      'contracts':{'matrix.pick':{'params':['int[2,2]'],'returns':'int'}}}
class MatrixContractTests(unittest.TestCase):
 def mk(self,main=MAIN,lib=LIB,param='int[2,2]',ret='int'):
  return {**BASE,'modules':{'main':main,'matrix':lib},'contracts':{'matrix.pick':{'params':[param],'returns':ret}}}
 def test_known_two_dimensional_matrix(self):
  r=validate_contracts(BASE);self.assertTrue(r['valid'],r['errors']);self.assertGreaterEqual(r['locally_verified_checks'],2)
 def test_wrong_number_of_rows(self):
  r=validate_contracts(self.mk(main='use matrix\nprint(pick([[1,2]]))'))
  self.assertFalse(r['valid']);self.assertIn('argument_type_mismatch',{x['kind'] for x in r['errors']})
 def test_wrong_inner_width(self):
  r=validate_contracts(self.mk(main='use matrix\nprint(pick([[1],[3]]))'))
  self.assertFalse(r['valid']);self.assertIn('argument_type_mismatch',{x['kind'] for x in r['errors']})
 def test_wrong_element_type(self):
  r=validate_contracts(self.mk(main='use matrix\nprint(pick([["a","b"],["c","d"]]))'))
  self.assertFalse(r['valid'])
 def test_three_dimensional_contract(self):
  r=validate_contracts(self.mk(param='int[1,2,2]',main='use matrix\nprint(pick([[[1,2],[3,4]]]))',lib='function pick(grid):\n    return grid[0][1][0]'))
  self.assertTrue(r['valid'],r['errors'])
 def test_invalid_shapes_rejected(self):
  for token in ('int[1,2,3,4]','int[2,]','int[,2]','int[100000,2]','int[1,00000000001]'):
   with self.subTest(token=token),self.assertRaises(LinkError):validate_contracts(self.mk(param=token))
 def test_ragged_stays_unproven_or_rejected(self):
  r=validate_contracts(self.mk(main='use matrix\nprint(pick([[1,2],[3]]))'))
  self.assertTrue(r['unproven_checks'] or not r['valid'])
 def test_real_native_matrix_execution(self):
  source=link_project(BASE)['source']
  for language in ('python','javascript','ruby','php'):
   if not tool_available(language):self.skipTest('Missing native '+language)
   with self.subTest(target=language):
    v=verify(source,language);self.assertEqual(v['status'],'passed',v)
if __name__=='__main__':unittest.main()
