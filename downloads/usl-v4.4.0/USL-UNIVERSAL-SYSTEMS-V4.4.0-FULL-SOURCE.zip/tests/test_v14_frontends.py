"""Actual front-end conformance and negative diagnostic tests, environment-aware."""
import tempfile,unittest
from pathlib import Path
from usl_systems.native_syntax import CAPABILITIES, check_source, available, NativeSyntaxError
from usl_systems.qualification import profiles
SAMPLES={
 'typescript':('function twice(n: number): number { return n*2; }', 'function twice(n: number): number { return "bad"; }', 'static_type_and_syntax'),
 'swift':('func twice(_ n: Int) -> Int { return n * 2 }\n', 'func twice(_ n: Int) -> Int { return "bad" }\n', 'static_type_and_syntax'),
 'fortran':('program test\n implicit none\n integer :: x\n x = 2\n print *, x\nend program test\n','program test\n implicit none\n integer :: x\n x = \"bad\"\nend program test\n','static_type_and_syntax'),
 'perl':('use strict; use warnings; my $x = 2;\n','use strict; my $x = ;\n','syntax_or_compile_check'),
 'bash':('#!/usr/bin/env bash\nfoo() { echo 2; }\n','foo() { echo 2;\n','syntax_or_compile_check'),
 'kotlin':('fun twice(n: Int): Int = n * 2\n','fun twice(n: Int): Int = "bad"\n','static_type_and_syntax')
}
# Format-check literal to force a true Fortran type mismatch, not mis-escaped string.
SAMPLES['fortran']=(SAMPLES['fortran'][0], 'program test\n implicit none\n integer :: x\n x = "bad"\nend program test\n','static_type_and_syntax')
class ExpandedNativeFrontends(unittest.TestCase):
 def test_static_and_syntax_frontends(self):
  discovered=available()
  performed=[]
  for language,(good,bad,level) in SAMPLES.items():
   self.assertIn(language,CAPABILITIES)
   if not discovered[language]['installed']:continue
   performed.append(language)
   with self.subTest(lang=language,case='positive'):
    result=check_source(language,good,authorized=True,timeout=30)
    self.assertTrue(result['syntax_valid'],result)
    self.assertEqual(result['exit_code'],0)
    self.assertEqual(result['verification_kind'],level)
    self.assertFalse(result['source_executed'])
    self.assertFalse(result['semantic_equivalence_proven'])
   with self.subTest(lang=language,case='negative'):
    result=check_source(language,bad,authorized=True,timeout=30)
    self.assertFalse(result['syntax_valid'],result)
    self.assertNotEqual(result['exit_code'],0)
    self.assertTrue(result['console_tail'],result)
  self.assertGreaterEqual(len(performed),4, 'At least four actual frontends required in this test environment')
 def test_alias_authorization_limits(self):
  for name in SAMPLES:
   with self.subTest(lang=name):
    with self.assertRaises(NativeSyntaxError):check_source(name,'let x = 1')
  for alias,original in (('ts','typescript'),('sh','bash'),('f90','fortran'),('kt','kotlin')):
   if available()[original]['installed']:
    with self.subTest(alias=alias):
     result=check_source(alias,SAMPLES[original][0],authorized=True,timeout=30)
     self.assertEqual(result['language'],original)
 def test_catalog_claims_are_precise(self):
  records={p['id']:p for p in profiles()}
  self.assertEqual(len(records),606)
  for lang in SAMPLES:
   with self.subTest(lang=lang):
    self.assertIn(lang,records)
    self.assertFalse(records[lang]['complete_semantic_compiler'])
    self.assertEqual(records[lang]['native_syntax_or_typecheck_available'],available()[lang]['installed'])
if __name__=='__main__':unittest.main()
