"""Actual localhost HTTP authorization and observation, no implied success."""
import json,os,threading,unittest
from unittest.mock import patch
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from usl_systems.legacy_runtime import bridge_latest_report,LegacyError
from usl_systems.autonomy import validate_plan,AutonomyController
from usl_systems.store import Store
import tempfile,time

class SourceHandler(BaseHTTPRequestHandler):
    report=None
    def do_GET(self):
        if self.headers.get('Authorization')!='Bearer good-token':
            self.send_response(401);self.end_headers();return
        body={'ok':True,'report':self.report}
        data=json.dumps(body).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass

class BridgeReportTests(unittest.TestCase):
    def setUp(self):
        self.srv=ThreadingHTTPServer(('127.0.0.1',0),SourceHandler)
        self.thread=threading.Thread(target=self.srv.serve_forever,daemon=True);self.thread.start()
        self.url=f'http://127.0.0.1:{self.srv.server_port}'
        self.patcher=patch.dict(os.environ,{'USL_BRIDGE_TOKEN':'good-token'})
        self.patcher.start()
    def tearDown(self):
        self.patcher.stop();self.srv.shutdown();self.srv.server_close();self.thread.join(timeout=3)
    def test_report_present_but_unverified_is_not_marked_success(self):
        SourceHandler.report={'id':'b1','status':'finished','debug':'private content','verified':False,'success':True}
        item=bridge_latest_report(self.url)
        self.assertTrue(item['connected']);self.assertFalse(item['verified_task'])
        self.assertNotIn('debug',item['report']);self.assertEqual(item['upstream_status'],'finished')
    def test_no_report_is_different_from_disconnected(self):
        SourceHandler.report=None
        item=bridge_latest_report(self.url)
        self.assertTrue(item['connected']);self.assertFalse(item['verified_task'])
        self.assertEqual(item['status'],'no_report')
    def test_report_claim_without_independent_evidence_is_insufficient(self):
        SourceHandler.report={'id':'b2','status':'finished','verified':True,'success':True}
        result=bridge_latest_report(self.url)
        self.assertFalse(result['verified_task'])
        self.assertEqual(result['report']['verified'],True)
    def test_url_restrictions(self):
        with self.assertRaises(LegacyError):bridge_latest_report('http://example.com:8766')
    def test_plan_supports_observation_not_automatic_mutation(self):
        plan={'format':'uslauto-1','steps':[{'id':'observe','kind':'bridge_report'}]}
        self.assertEqual(validate_plan(plan),plan)

if __name__=='__main__':unittest.main()
