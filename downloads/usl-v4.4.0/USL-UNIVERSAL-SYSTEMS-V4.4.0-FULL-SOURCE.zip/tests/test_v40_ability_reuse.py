import json,tempfile,unittest
from pathlib import Path
from usl_systems.domain_execution import qualify
from tools.reuse_discovered_abilities import run

class Reuse(unittest.TestCase):
 def test_fifteen_artifacts_used_in_real_usl_schedule(self):
  with tempfile.TemporaryDirectory() as temp:
   q=qualify(approved=True,workers=8,artifacts=temp,include_negative=False)
   self.assertTrue(q['all_verified'])
   self.assertGreaterEqual(len(q['qualified_catalog_ids']),10)
   report=run(temp)
   self.assertTrue(report['all_15_artifacts_consumed'])
   self.assertTrue(report['actual_usl_graph']['all_verified'])
   self.assertEqual(report['config_derived_usl_output'],'24')
 def test_damaged_or_missing_data_cannot_be_used(self):
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaises(ValueError):run(tmp)

if __name__=='__main__':unittest.main()
