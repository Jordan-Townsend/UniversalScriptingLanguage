"""Real localhost HTTP protocol tests and actual CPU multiprocessing, no models or GPU claimed."""
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

from usl_systems.store import Store
from usl_systems.shadow_sessions import ShadowSessions
from usl_systems.fractal import FactoredFractal
from usl_systems.adaptive import AdaptiveExecutor


class LocalModel(BaseHTTPRequestHandler):
    calls=[]
    def log_message(self,*a): pass
    def respond(self,value,status=200):
        raw=json.dumps(value).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
    def do_GET(self):
        if self.path == '/api/tags':
            return self.respond({'models':[{'name':'usl-local-test:1'}]})
        return self.respond({'error':'not found'},404)
    def do_POST(self):
        if self.path!='/api/chat':return self.respond({'error':'not found'},404)
        data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        self.calls.append(data)
        if data.get('stream') is True:
            payload=(json.dumps({'message':{'role':'assistant','content':'This response came through an actual HTTP socket.'},'done':True})+'\n').encode()
            self.send_response(200)
            self.send_header('Content-Type','application/x-ndjson')
            self.send_header('Content-Length',str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        else:
            self.respond({'message':{'role':'assistant','content':'This response came through an actual HTTP socket.'}})


class ComputeAndModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),LocalModel)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=3)

    def test_real_local_http_model_and_persistent_memory(self):
        with tempfile.TemporaryDirectory() as d, patch('usl_systems.agent.OLLAMA',f'http://127.0.0.1:{self.server.server_port}'):
            store=Store(Path(d))
            sessions=ShadowSessions(store)
            session=sessions.new()
            result=sessions.send(session['id'],'What is your local interface?')
            self.assertEqual(result['model'],'usl-local-test:1')
            self.assertTrue(result['verified_provider_response'])
            self.assertEqual(len(ShadowSessions(store).history(session['id'])['turns']),2)
            sent=self.server.RequestHandlerClass.calls[-1]
            self.assertEqual(sent['model'],'usl-local-test:1')
            self.assertEqual(sent['messages'][-1]['content'],'What is your local interface?')
            sessions.send(session['id'],'Remember the earlier exchange')
            self.assertEqual(len(self.server.RequestHandlerClass.calls[-1]['messages']),3)

    def test_actual_parallel_multiprocessing_with_exact_reference(self):
        samples=[((i*17)%97)-48 for i in range(5200)]
        engine=FactoredFractal(workers=2,max_depth=5,leaf_size=256)
        for operator in ('sum','sum_squares','sum_abs','sum_even','histogram'):
            with self.subTest(operator=operator):
                r=engine.execute(samples,operator=operator,dimensions=['region','stage','epoch'],mode='process',reuse=True)
                self.assertTrue(r['verified_exact'])
                self.assertEqual(r['result'],r['reference'])
                self.assertEqual(r['physical_worker_processes_max'],2)
                self.assertGreater(r['physically_computed_partials'],0)

    def test_process_candidate_is_measured_not_assumed_fastest(self):
        arr=[i%5 for i in range(4096)]
        result=AdaptiveExecutor(workers=2,leaf_size=256).choose(arr,repeats=1,include_process=True)
        self.assertTrue(result['verified_exact'])
        self.assertIn('factored_process',result['median_ms'])
        self.assertEqual(result['value'],sum(x*x for x in arr))
        self.assertEqual(result['selected'],min(result['median_ms'],key=result['median_ms'].get))

if __name__=='__main__':unittest.main()
