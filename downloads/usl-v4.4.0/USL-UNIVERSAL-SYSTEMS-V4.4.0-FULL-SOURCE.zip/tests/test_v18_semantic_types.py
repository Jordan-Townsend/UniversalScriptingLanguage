import unittest
from usl_systems.semantic_types import check_types
from usl_systems.module_linker import link_project,SCHEMA
class StaticTypeTests(unittest.TestCase):
 def test_valid_homogeneous_array_flow(self):
  code='let a = [1, 2, 3]\nlet i = 1\nlet b = a[i] + 5\nprint(b)'
  self.assertEqual(check_types(code)['error_count'],0)
 def test_mismatched_scalar_operand(self):
  res=check_types('let x = "hello"\nprint(x - 3)')
  self.assertIn('operand_type_mismatch',{x['code'] for x in res['issues']})
 def test_nonint_array_index(self):
  res=check_types('let a = [1,2]\nprint(a["0"])')
  self.assertIn('index_not_integer',{x['code'] for x in res['issues']})
 def test_bounds_both_sides(self):
  res=check_types('let a = [1,2]\nprint(a[9])\nprint(a[-3])')
  self.assertEqual(sum(x['code']=='index_out_of_bounds' for x in res['issues']),2)
 def test_conditional_type_unknown_no_false_rejection(self):
  code='let value = 1\nif value > 0:\n    value = "ok"\nelse:\n    value = 2\nprint(value)'
  self.assertEqual(check_types(code)['error_count'],0)
 def test_function_arity(self):
  code='function twice(x):\n    return x * 2\nprint(twice(1,2))'
  res=check_types(code)
  self.assertIn('function_arity',{x['code'] for x in res['issues']})
 def test_module_link_with_static_check(self):
  project={'schema':SCHEMA,'entry':'main','modules':{'main':'use lib\nlet a = [2,4]\nprint(twice(a[0]))','lib':'function twice(x):\n    return x*2'}}
  result=link_project(project)
  self.assertEqual(check_types(result['source'])['error_count'],0)
if __name__=='__main__':unittest.main()
