import unittest
from usl_systems.module_contracts import validate_contracts

LIB='function twice(x):\n    return x*2'
def project(code):
 return {'schema':'usl.module_project.v1','entry':'main','modules':{'main':'use lib\n'+code,'lib':LIB},
         'contracts':{'lib.twice':{'params':['int'],'returns':'int'}}}

class DataflowTests(unittest.TestCase):
 def test_same_type_branches_prove_call(self):
  r=validate_contracts(project('if 1:\n    let value = 2\nelse:\n    let value = 5\nprint(twice(value))'))
  self.assertTrue(r['valid']);self.assertTrue(any(x['name']=='value' and x['kind']=='int' for x in r['dataflow_branch_joins']))
  self.assertTrue(any(x['kind']=='argument' for x in r['errors']) is False)
 def test_mixed_type_branch_is_unknown_not_false_proof(self):
  r=validate_contracts(project('if 1:\n    let value = 2\nelse:\n    let value = "hi"\nprint(twice(value))'))
  self.assertTrue(r['valid']);self.assertTrue(any(x.get('actual')=='unknown' for x in r['unproven_checks']))
 def test_same_wrong_branch_type_rejected(self):
  r=validate_contracts(project('if 1:\n    let value = "x"\nelse:\n    let value = "y"\nprint(twice(value))'))
  self.assertFalse(r['valid']);self.assertTrue(any(x['kind']=='argument_type_mismatch' for x in r['errors']))
 def test_loop_change_invalidates_old_type(self):
  r=validate_contracts(project('let value = 8\nwhile value > 0:\n    let value = "x"\nprint(twice(value))'))
  self.assertTrue(r['valid']);self.assertTrue(r['dataflow_loop_invalidations']);self.assertTrue(r['unproven_checks'])
 def test_nested_calls_propagate_declared_return(self):
  r=validate_contracts(project('print(twice(twice(5)))'))
  self.assertTrue(r['valid']);self.assertFalse(r['unproven_checks']);self.assertGreaterEqual(r['locally_verified_checks'],3)

if __name__=='__main__':unittest.main()
