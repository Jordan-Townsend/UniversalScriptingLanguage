"""Executable conformance tests for verified cross-step dataflow."""
import sys
import tempfile
import time
import unittest

from usl_systems.autonomy import AutonomyController,AutonomyError,validate_plan
from usl_systems.store import Store
from usl_systems.bridge import ProcessBridge


def settle(ctrl, rid):
    end=time.monotonic()+10
    while time.monotonic()<end:
        rec=ctrl.detail(rid)
        if rec['status'] in ('completed','failed','cancelled','needs_review'):
            return rec
        time.sleep(.025)
    raise AssertionError('timed out waiting for autonomous run')

class DagBindingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(self.temp.name)
        self.bridge=ProcessBridge(self.store)
        self.ctrl=AutonomyController(self.store,self.bridge)
    def tearDown(self):
        self.ctrl.close(); self.bridge.shutdown();self.temp.cleanup()

    def test_automatic_topological_order_and_typed_source(self):
        plan={'format':'uslauto-1','steps':[
            {'id':'execute','kind':'usl','depends_on':['produce'],
             'inputs':{'source':{'step':'produce','path':'result.output'}},
             'expected':{'output_contains':'7'}},
            {'id':'compress','kind':'collapse','depends_on':['execute'],
             'inputs':{'text':{'step':'execute','path':'result.output'}},
             'expected':{'field':'exact','equals':True}},
            {'id':'produce','kind':'usl','source':'print("print(7)")',
             'expected':{'output_contains':'print(7)'}},
        ]}
        row=self.ctrl.create(plan);rid=row['id']
        self.assertEqual([x['id'] for x in row['plan']['steps']],['produce','execute','compress'])
        self.ctrl.approve(rid);self.ctrl.begin(rid)
        result=settle(self.ctrl,rid)
        self.assertEqual(result['status'],'completed',result)
        self.assertEqual([x['id'] for x in result['outcomes']],['produce','execute','compress'])
        self.assertTrue(all(x['successful'] for x in result['outcomes']))
        self.assertEqual(result['outcomes'][1]['result']['output'],'7\n')

    def test_dependency_cycle_rejected(self):
        with self.assertRaisesRegex(AutonomyError,'cycle'):
            validate_plan({'format':'uslauto-1','steps':[
                {'id':'one','kind':'usl','source':'print(1)','depends_on':['two']},
                {'id':'two','kind':'usl','source':'print(2)','depends_on':['one']} ]})

    def test_undeclared_and_missing_dependencies_rejected(self):
        variants=[
            [{'id':'a','kind':'usl','source':'print(1)','depends_on':['missing']}],
            [{'id':'a','kind':'usl','source':'print(1)',
              'inputs':{'source':{'step':'x','path':'result.output'}}}],
            [{'id':'a','kind':'usl','source':'print(1)','depends_on':['a']}],
        ]
        for steps in variants:
            with self.subTest(steps=steps),self.assertRaises(AutonomyError):
                validate_plan({'format':'uslauto-1','steps':steps})

    def test_process_arguments_cannot_be_bound(self):
        plan={'format':'uslauto-1','steps':[
            {'id':'first','kind':'usl','source':'print(9)'},
            {'id':'second','kind':'process','argv':[sys.executable,'-c','print(9)'],
             'depends_on':['first'],'inputs':{'argv':{'step':'first','path':'result.output'}}}]}
        with self.assertRaisesRegex(AutonomyError,'cannot change'):
            validate_plan(plan)

    def test_missing_output_fails_closed(self):
        plan={'format':'uslauto-1','steps':[
            {'id':'a','kind':'usl','source':'print(3)'},
            {'id':'b','kind':'collapse','depends_on':['a'],
             'inputs':{'text':{'step':'a','path':'result.nonexistent'}}}]}
        rid=self.ctrl.create(plan)['id'];self.ctrl.approve(rid);self.ctrl.begin(rid)
        report=settle(self.ctrl,rid)
        self.assertEqual(report['status'],'failed');self.assertIn('missing',report['outcomes'][-1]['error'])

    def test_failed_dependency_stops_pipeline(self):
        plan={'format':'uslauto-1','steps':[
            {'id':'a','kind':'usl','source':'print(1)','expected':{'output_equals':'not 1'}},
            {'id':'b','kind':'collapse','depends_on':['a'],'inputs':{'text':{'step':'a','path':'result.output'}}}]}
        rid=self.ctrl.create(plan)['id'];self.ctrl.approve(rid);self.ctrl.begin(rid)
        report=settle(self.ctrl,rid)
        self.assertEqual(report['status'],'failed');self.assertEqual(report['cursor'],1)
        self.assertEqual(len(report['outcomes']),1)

    def test_restart_with_checkpointed_binding(self):
        plan={'format':'uslauto-1','steps':[
            {'id':'a','kind':'usl','source':'print("hello")'},
            {'id':'b','kind':'collapse','depends_on':['a'],
             'inputs':{'text':{'step':'a','path':'result.output'}}}]}
        rid=self.ctrl.create(plan)['id'];self.ctrl.approve(rid)
        self.ctrl._update(rid,status='running',cursor=1,outcomes='[{"id":"a","kind":"usl","successful":true,"result":{"output":"hello\\n"}}]')
        self.ctrl.close();self.ctrl=AutonomyController(self.store,self.bridge)
        self.assertEqual(self.ctrl.detail(rid)['status'],'paused')
        self.ctrl.begin(rid)
        report=settle(self.ctrl,rid)
        self.assertEqual(report['status'],'completed',report)
        self.assertTrue(report['outcomes'][1]['result']['exact'])

if __name__=='__main__':unittest.main()
