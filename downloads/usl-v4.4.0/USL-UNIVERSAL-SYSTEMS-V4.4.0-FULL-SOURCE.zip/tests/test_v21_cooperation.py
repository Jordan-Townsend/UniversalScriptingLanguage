import json,tempfile,threading,time,unittest
from pathlib import Path
from usl_systems.cooperative_workers import CooperativeScheduler
from usl_systems.native import tool_available

class V21CooperationTests(unittest.TestCase):
 def test_cancel_pending_without_restarting_or_killing_running_workers(self):
  flag=threading.Event();jobs={'schema':'usl.cooperative.graph.v1','tasks':[
   {'id':'started','kind':'bounded_delay','inputs':{'seconds':0.17}},
   {'id':'later','kind':'fractal','deps':['started'],'inputs':{'values':[3,4,5]}}]}
  def signal():time.sleep(0.04);flag.set()
  thread=threading.Thread(target=signal,daemon=True);thread.start()
  r=CooperativeScheduler(threads=1,processes=0).run(jobs,cancel_event=flag)
  thread.join(timeout=1)
  self.assertEqual(r['tasks']['started']['status'],'verified')
  self.assertEqual(r['tasks']['later']['status'],'cancelled')
  self.assertTrue(r['cancelled_pending_tasks'])
 def test_concurrent_native_workers_and_evidence_join(self):
  need=('python','javascript','ruby','php')
  if any(not tool_available(x) for x in need):self.skipTest('Real target runtimes not installed')
  root=Path(__file__).resolve().parents[1]
  graph=json.loads((root/'examples/cooperative_native_targets.json').read_text())
  with tempfile.TemporaryDirectory() as td:
   cp=Path(td)/'checkpoint.json';runner=CooperativeScheduler(threads=4,processes=0,allow_native=True)
   first=runner.run(graph,checkpoint=cp)
   self.assertTrue(first['all_verified'],first['blocked_or_failed'])
   for target in need:
    row=first['tasks']['verify_'+target]
    self.assertEqual(row['value']['status'],'passed')
    self.assertFalse(row['cache_reused'])
   # All four independent compiler verifications must overlap in time.
   intervals=[first['tasks']['verify_'+x] for x in need]
   overlap=max(x['started_ns'] for x in intervals)<min(x['finished_ns'] for x in intervals)
   self.assertTrue(overlap,'Native compilers were not concurrent')
   second=runner.run(graph,checkpoint=cp)
   self.assertTrue(second['all_verified'],second['blocked_or_failed'])
   self.assertTrue(second['tasks']['compile_link']['cache_reused'])
   self.assertFalse(any(second['tasks']['verify_'+x]['cache_reused'] for x in need))
   self.assertTrue(second['tasks']['native_evidence']['value']['verified'])
 def test_cancel_all_before_start(self):
  flag=threading.Event();flag.set()
  result=CooperativeScheduler(threads=1,processes=0).run({'schema':'usl.cooperative.graph.v1','tasks':[
   {'id':'never','kind':'fractal','inputs':{'values':[2,3,4]}}]},cancel_event=flag)
  self.assertFalse(result['all_verified'])
  self.assertEqual(result['tasks']['never']['status'],'cancelled')
if __name__=='__main__':unittest.main()
