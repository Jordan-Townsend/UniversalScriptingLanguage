import hashlib,json,tempfile,time,unittest,urllib.request,urllib.error
from pathlib import Path
from threading import Thread
from http.server import ThreadingHTTPServer
from usl_systems.store import Store
from usl_systems.autonomy import AutonomyController
from usl_systems.engine import Engine
from usl_systems.bridge import ProcessBridge
from usl_systems.server import Handler
from usl_systems.repair_proposals import propose_syntax_repair,RepairError

class DiagnosisProposal(unittest.TestCase):
 def setUp(self):
  tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
  self.store=Store(Path(tmp.name)/'data')
  self.src=self.store.safe_project_path('calc','main.py');self.src.parent.mkdir(parents=True)
  self.src.write_text('def add(x, y)\n    return x + y\n')
  testdir=self.src.parent/'tests';testdir.mkdir()
  (testdir/'test_calc.py').write_text('import unittest\nfrom main import add\nclass T(unittest.TestCase):\n def test_add(self):self.assertEqual(add(8,3),11)\n')
 def test_diagnosis_is_inert_and_compiler_grounded(self):
  before=self.src.read_bytes()
  proposal=propose_syntax_repair(self.store,'calc','main.py')
  self.assertEqual(before,self.src.read_bytes());self.assertEqual(proposal['status'],'proposal_only')
  self.assertEqual(proposal['diagnostic']['message'],"expected ':'")
  self.assertEqual(proposal['plan']['steps'][0]['original_sha256'],hashlib.sha256(before).hexdigest())
 def test_generated_plan_passes_real_repair(self):
  proposal=propose_syntax_repair(self.store,'calc','main.py')
  ctl=AutonomyController(self.store);self.addCleanup(ctl.close)
  draft=ctl.create(proposal['plan']);ctl.approve(draft['id'],allow_process=True)
  ctl.begin(draft['id'])
  for _ in range(300):
   result=ctl.detail(draft['id'])
   if result['status'] in ('completed','failed','needs_review'):break
   time.sleep(.05)
  self.assertEqual(result['status'],'completed',result)
  self.assertEqual(result['outcomes'][0]['result']['tests']['exit_code'],0)
  self.assertIn('def add(x, y):',self.src.read_text())
 def test_syntax_that_is_not_supported_rejected(self):
  self.src.write_text('this_is_surely_not_python ???\n')
  with self.assertRaises(RepairError):propose_syntax_repair(self.store,'calc','main.py')
 def test_no_proposal_on_valid_source(self):
  self.src.write_text('def add(x,y):\n return x+y\n')
  with self.assertRaises(RepairError):propose_syntax_repair(self.store,'calc','main.py')
 def test_proposal_api_token_gate(self):
  self.store.stop_token='token-test';engine=Engine(self.store);bridge=ProcessBridge(self.store)
  ctl=AutonomyController(self.store,bridge)
  class H(Handler):pass
  H.store=self.store;H.engine=engine;H.bridge=bridge;H.autonomy=ctl
  http=ThreadingHTTPServer(('127.0.0.1',0),H)
  thread=Thread(target=http.serve_forever,daemon=True);thread.start()
  self.addCleanup(lambda:(http.shutdown(),http.server_close(),thread.join(timeout=2),ctl.close(),bridge.shutdown(),engine.pool.shutdown(wait=False,cancel_futures=True)))
  url='http://127.0.0.1:'+str(http.server_port)+'/api/repair/propose'
  before=self.src.read_bytes()
  def call(token=None):
   headers={'Content-Type':'application/json'}
   if token:headers['X-USL-Control-Token']=token
   req=urllib.request.Request(url,json.dumps({'project':'calc','path':'main.py'}).encode(),headers=headers)
   with urllib.request.urlopen(req,timeout=5) as r:return json.load(r)
  with self.assertRaises(urllib.error.HTTPError) as e:call()
  self.assertEqual(e.exception.code,403)
  proposal=call('token-test')
  self.assertEqual(proposal['status'],'proposal_only')
  self.assertEqual(ctl.detail(proposal['draft_id'])['status'],'draft')
  self.assertEqual(before,self.src.read_bytes())

class RepairSafetyRegression(unittest.TestCase):
 def test_zero_unittests_cannot_grant_verification(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'data');f=s.safe_project_path('empty','main.py');f.parent.mkdir(parents=True)
   f.write_text('def value()\n return 9\n')
   from usl_systems.repairloop import RepairLoop
   item={'path':'main.py','original_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
         'old':'def value()\n','new':'def value():\n','check':'unittest','timeout':5}
   res=RepairLoop(s).run('empty',item)
   self.assertEqual(res['status'],'not_applied')
   self.assertIn('def value()\n',f.read_text())
 def test_reject_missing_project(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'data')
   with self.assertRaises(RepairError):propose_syntax_repair(s,None,'main.py')
