import copy,json,shutil,unittest
from pathlib import Path
from usl_systems.interop import run_nested,SCHEMA,catalog_matrix,bridge_eligibility_matrix
ROOT=Path(__file__).resolve().parents[1]
DEMO=json.loads((ROOT/'examples/nested_seven_languages.uslnest.json').read_text('utf8'))
class PolyglotGuestTests(unittest.TestCase):
    def node(self,lang,src,fn='f',arg=5,ret='i64',param='i64'):
        return {'schema':SCHEMA,'nodes':[{'id':'x','language':lang,'source':src,'export':fn,
            'params':[param],'returns':ret,'args':[arg]}]}
    @unittest.skipUnless(shutil.which('ruby') and shutil.which('php') and shutil.which('node') and (shutil.which('gcc') or shutil.which('cc')),'Native toolchains missing')
    def test_actual_seven_engines(self):
        r=run_nested(DEMO,authorized=True)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(r['results']['usl']['value'],1937)
        self.assertEqual(len({x['language'] for x in r['results'].values()}),7)
    @unittest.skipUnless(shutil.which('ruby'),'Ruby unavailable')
    def test_ruby_guest(self):
        r=run_nested(self.node('ruby','module USLGuest\n  def self.f(x)\n   x+10\n  end\nend\n'),authorized=True)
        self.assertTrue(r['all_verified']);self.assertEqual(r['results']['x']['value'],15)
    @unittest.skipUnless(shutil.which('php'),'PHP unavailable')
    def test_php_guest(self):
        r=run_nested(self.node('php','<?php function f($x) { return $x + 10; }'),authorized=True)
        self.assertTrue(r['all_verified']);self.assertEqual(r['results']['x']['value'],15)
    @unittest.skipUnless(shutil.which('ruby'),'Ruby unavailable')
    def test_ruby_error_not_accepted(self):
        r=run_nested(self.node('ruby','module USLGuest\n  def self.f(x)\n   raise "error"\n  end\nend\n'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Ruby guest failed',r['failures']['x']['reason'])
    @unittest.skipUnless(shutil.which('php'),'PHP unavailable')
    def test_php_error_not_accepted(self):
        r=run_nested(self.node('php','<?php function f($x) { throw new Exception("error"); }'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('PHP guest failed',r['failures']['x']['reason'])
    @unittest.skipUnless(shutil.which('ruby'),'Ruby unavailable')
    def test_ruby_missing_export(self):
        r=run_nested(self.node('ruby','module USLGuest\n  def self.other(x)\n   x\n  end\nend\n'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Ruby guest failed',r['failures']['x']['reason'])
    @unittest.skipUnless(shutil.which('php'),'PHP unavailable')
    def test_php_builtin_cannot_be_invoked_as_export(self):
        r=run_nested(self.node('php','<?php function notsystem($x) { return $x; }','system'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('Unknown declared guest export',r['failures']['x']['reason'])
    @unittest.skipUnless(shutil.which('php'),'PHP unavailable')
    def test_php_type_mismatch(self):
        r=run_nested(self.node('php','<?php function f($x) { return "string"; }'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('i64',r['failures']['x']['reason'])
    @unittest.skipUnless(shutil.which('ruby'),'Ruby unavailable')
    def test_ruby_type_mismatch(self):
        r=run_nested(self.node('ruby','module USLGuest\n  def self.f(x)\n   "string"\n  end\nend\n'),authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('i64',r['failures']['x']['reason'])
    def test_matrix_606(self):
        c=catalog_matrix(); self.assertEqual(len(c['entries']),606)
        native={x['native_bridge_family'] for x in c['entries'] if x['native_bridge_family']}
        self.assertTrue({'ruby','php','python','javascript','sql','c'}<=native)
        m=bridge_eligibility_matrix();self.assertEqual(m['total_pair_count'],367236)
        self.assertGreaterEqual(m['conditional_pair_count'],36)
    def test_no_permission_no_program(self):
        with self.assertRaisesRegex(ValueError,'approval'):run_nested(DEMO,authorized=False)
if __name__=='__main__':unittest.main()
