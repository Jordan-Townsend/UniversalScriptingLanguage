"""Real qualification for target routing; NOT a proof of all-language semantics."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from usl_systems.catalog import load_catalog
from usl_systems.universal import (route,collapse_success_all,export_portable,
                                   portable_execute,UniversalError)
from usl_systems.cooperative_workers import CooperativeScheduler,CooperativeError
from usl_systems.ir import restore
from usl_systems.language import USLError

SAMPLE='let nums = [2,5,11]\nprint(nums[0] + nums[2])'

class UniversalSemanticTest(unittest.TestCase):
    def test_ir_restores_and_executes(self):
        r=route(SAMPLE,'python')
        self.assertEqual(r['reference_output'],'13\n')
        self.assertEqual(portable_execute(r['ir']),r['reference_output'])
        self.assertEqual(r['mode'],'portable_semantic_vm')

    def test_all_606_catalog_ids_route_to_one_semantic_vm(self):
        ids=[x['id'] for x in load_catalog()]
        self.assertEqual(len(ids),606)
        cases=[route('print(2 + 3)',i) for i in ids]
        self.assertEqual(len(set(c['reference_stdout_sha256'] for c in cases)),1)
        self.assertTrue(all(c['mode']=='portable_semantic_vm' for c in cases))
        self.assertTrue(all(not c['full_target_language_semantics_verified'] for c in cases))

    def test_alias_and_unknown_fail_closed(self):
        self.assertEqual(route('print(3)','py')['catalog_id'],'python')
        with self.assertRaises(UniversalError):route('print(3)','not-real-language')
        with self.assertRaises(UniversalError):route('print(3)',123)

    def test_ir_tampering_rejected(self):
        r=route(SAMPLE,'python')
        r['ir']['body']['fields']['body'][0]['node']='Delete'
        with self.assertRaises(USLError):restore(r['ir'])

    def test_untrusted_source_rejected(self):
        with self.assertRaises(USLError):route('import os\nprint(os.environ)','python')
        with self.assertRaises(USLError):route('print((2).__class__)','python')
        with self.assertRaises(UniversalError):route('x'*100001,'python')

    def test_direct_native_verified_on_actual_program(self):
        r=route(SAMPLE,'python',allow_native=True)
        self.assertEqual(r['mode'],'direct_native')
        self.assertTrue(r['native_verified_for_this_program'])
        self.assertEqual(r['attempts'][0]['native_exit_code'],0)
        self.assertEqual(r['native_generated']['filename'],'main.py')
        self.assertFalse(r['full_target_language_semantics_verified'])

    def test_unsupported_native_construct_falls_back(self):
        source='let arr = [2,3]\nprint(arr[1])'
        r=route(source,'c',allow_native=True)
        self.assertEqual(r['mode'],'portable_semantic_vm')
        self.assertIn(r['attempts'][0]['status'],('unsupported_construct','toolchain_missing'))

    def test_semantic_mismatch_uses_compatibility_route(self):
        # Python/USL stringify None as 'None'; JS prints 'null'. The
        # native emitter has no None compatibility shim yet.
        result=route('print(None)','javascript',allow_native=True)
        self.assertEqual(result['reference_output'],'None\n')
        self.assertEqual(result['attempts'][0]['status'],'failed')
        self.assertEqual(result['mode'],'portable_semantic_vm')
        self.assertFalse(result['native_verified_for_this_program'])

    def test_native_collapse_compares_actual_execution(self):
        result=collapse_success_all(SAMPLE,targets=('python','javascript','ruby','php'))
        self.assertEqual(len(result['attempts']),4)
        self.assertTrue(result['native_verified_for_this_program'])
        self.assertIn(result['chosen_backend'],('python','javascript','ruby','php'))
        self.assertTrue(all(x['status']=='passed' for x in result['attempts']))

    def test_native_requires_explicit_cli_approval(self):
        with tempfile.TemporaryDirectory() as folder:
            src=Path(folder)/'demo.usl';src.write_text('print(3)',encoding='utf8')
            outcome=subprocess.run([sys.executable,'-m','usl_systems','collapse-success-all',str(src)],capture_output=True,text=True)
            self.assertNotEqual(outcome.returncode,0)
            self.assertIn('approve',outcome.stderr.lower())

    def test_portable_archive_executes_from_clean_extract(self):
        with tempfile.TemporaryDirectory(prefix='usl portable path ') as folder:
            f=Path(folder)/'portable.zip'
            result=export_portable(SAMPLE,'markdown',f)
            self.assertEqual(result['mode'],'portable_semantic_vm')
            self.assertEqual(result['files'],9)
            with zipfile.ZipFile(f) as z:
                self.assertIsNone(z.testzip());z.extractall(Path(folder)/'extract')
            run=subprocess.run([sys.executable,'RUN_PORTABLE.py'],cwd=Path(folder)/'extract',capture_output=True,text=True,timeout=12)
            self.assertEqual((run.returncode,run.stdout),(0,'13\n'),run.stderr)

    def test_portable_archive_rejects_corrupted_payload(self):
        with tempfile.TemporaryDirectory() as folder:
            f=Path(folder)/'p.zip';export_portable(SAMPLE,'json',f)
            with zipfile.ZipFile(f) as z:z.extractall(Path(folder)/'extract')
            (Path(folder)/'extract'/'payload.uslir.json').write_text('{}',encoding='utf8')
            run=subprocess.run([sys.executable,'RUN_PORTABLE.py'],cwd=Path(folder)/'extract',capture_output=True,text=True,timeout=12)
            self.assertNotEqual(run.returncode,0)
            self.assertIn('integrity',run.stderr.lower())

    def test_cooperative_semantic_workers_share_reference(self):
        graph={'schema':'usl.cooperative.graph.v1','tasks':[
            {'id':'first','kind':'semantic_route','inputs':{'source':SAMPLE,'target':'json'}},
            {'id':'second','kind':'semantic_route','inputs':{'source':SAMPLE,'target':'python'}},
            {'id':'evidence','kind':'join_evidence','deps':['first','second']} ]}
        report=CooperativeScheduler(threads=2,processes=0).run(graph)
        self.assertTrue(report['all_verified'],report)
        self.assertEqual(report['tasks']['first']['value']['reference_output'], '13\n')
        self.assertEqual(report['tasks']['evidence']['status'],'verified')

    def test_cooperative_native_worker_requires_authorization(self):
        graph={'schema':'usl.cooperative.graph.v1','tasks':[
            {'id':'native','kind':'semantic_native_collapse',
             'inputs':{'source':'print(8 + 1)','targets':['python']}}]}
        rejected=CooperativeScheduler(threads=1,processes=0,allow_native=False).run(graph)
        self.assertFalse(rejected['all_verified'])
        accepted=CooperativeScheduler(threads=1,processes=0,allow_native=True).run(graph)
        self.assertTrue(accepted['all_verified'])
        self.assertEqual(accepted['tasks']['native']['value']['chosen_backend'],'python')

if __name__=='__main__':unittest.main()
