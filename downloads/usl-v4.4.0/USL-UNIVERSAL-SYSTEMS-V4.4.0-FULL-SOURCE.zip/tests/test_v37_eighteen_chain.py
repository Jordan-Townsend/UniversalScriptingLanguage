import json,shutil,unittest
from pathlib import Path
from usl_systems.interop import run_nested
ROOT=Path(__file__).resolve().parents[1]
TOOLS=('awk','sed','gcc','g++','gfortran','go','java','javac','node','ruby','php','perl','swiftc','tsc','kotlinc','bash')
class EighteenEngineGraph(unittest.TestCase):
    @unittest.skipUnless(all(shutil.which(tool) for tool in TOOLS),'Required actual native runtimes unavailable')
    def test_real_eighteen_engines_nineteen_nodes(self):
        project=json.loads((ROOT/'examples/nested_eighteen_environments.uslnest.json').read_text('utf8'))
        self.assertEqual(len(set(n['language'] for n in project['nodes'])),18)
        self.assertEqual(len(project['nodes']),19)
        r=run_nested(project,authorized=True,workers=4)
        self.assertTrue(r['all_verified'],r['failures'])
        self.assertEqual(r['verified'],19)
        self.assertEqual(r['results']['usl']['value'],12997)
        self.assertEqual(r['results']['sed']['value'],'dog here')
        self.assertEqual(r['results']['awk']['value'],55)
    def test_unapproved_native_graph_refused(self):
        project=json.loads((ROOT/'examples/nested_eighteen_environments.uslnest.json').read_text('utf8'))
        with self.assertRaisesRegex(ValueError,'approval'):
            run_nested(project,authorized=False)
if __name__=='__main__':unittest.main()
