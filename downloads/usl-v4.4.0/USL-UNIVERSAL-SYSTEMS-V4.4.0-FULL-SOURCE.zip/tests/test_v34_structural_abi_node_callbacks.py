import json,shutil,time,unittest
from pathlib import Path
from usl_systems.abi_types import parse_spec,validate,ABITypeError
from usl_systems.interop import run_nested,SCHEMA,BridgeError
ROOT=Path(__file__).resolve().parents[1]
SPEC='record{title:text,items:list<optional<i64>>,success:bool}'
OBJ={'title':'pâtisserie','items':[2,None,3],'success':True}
CB={'name':'usl_twice','source':'def twice(x):\n    return x*2\n','export':'twice','params':['i64'],'returns':'i64','max_calls':2,'timeout_seconds':4}
class StructuralABITests(unittest.TestCase):
    def test_valid_record_with_unicode_and_null(self):
        self.assertEqual(validate(OBJ,SPEC),OBJ)
        self.assertEqual(parse_spec(SPEC)[0],'record')
    def test_bad_record_fields(self):
        for value in ({'title':'x','items':[]},{**OBJ,'extra':1},{**OBJ,'items':[True]}):
            with self.subTest(value=value),self.assertRaises(ABITypeError):validate(value,SPEC)
    def test_bad_recursive_specs(self):
        for spec in ('record{a:i64,a:text}','list<unknown>','record{a:i64','__import__(os)','optional<list<list<list<list<list<text>>>>>>'):
            with self.subTest(spec=spec),self.assertRaises(ABITypeError):parse_spec(spec)
    def test_i64_boundaries(self):
        validate(-(2**63),'i64');validate(2**63-1,'i64')
        for x in (2**63,-2**63-1,True):
            with self.assertRaises(ABITypeError):validate(x,'i64')
    def test_null_distinct_from_missing(self):
        self.assertIsNone(validate(None,'optional<i64>'))
        with self.assertRaises(ABITypeError):validate(None,'i64')
    def test_oversized_record(self):
        with self.assertRaises(ABITypeError):validate({'value':'a'*65000},'record{value:text}')
    @unittest.skipUnless(shutil.which('node'),'Node unavailable')
    def test_real_python_to_javascript_record(self):
        pr={'schema':SCHEMA,'nodes':[
        {'id':'py','language':'python','source':'def transform(x):\n    return x\n','export':'transform','params':[SPEC],'returns':SPEC,'args':[OBJ], 'expected':OBJ},
        {'id':'js','language':'javascript','source':'export function transform(x) {return {...x,title:x.title+"!"};}','export':'transform','params':[SPEC],'returns':SPEC,'args':[{'ref':'py'}],'expected':{**OBJ,'title':OBJ['title']+'!'}}]}
        r=run_nested(pr,authorized=True)
        self.assertTrue(r['all_verified'],r['failures'])
    @unittest.skipUnless(shutil.which('tsc') and shutil.which('node'),'TypeScript unavailable')
    def test_tsc_compiled_record(self):
        src='export function transform(x:{title:string;items:(number|null)[];success:boolean}) {return {...x,title:x.title+"!"};}'
        pr={'schema':SCHEMA,'nodes':[{'id':'ts','language':'typescript','source':src,'export':'transform','params':[SPEC],'returns':SPEC,'args':[OBJ],'expected':{**OBJ,'title':OBJ['title']+'!'}}]}
        r=run_nested(pr,authorized=True)
        self.assertTrue(r['all_verified'],r['failures'])
    def test_literal_ref_field(self):
        val={'ref':42}
        pr={'schema':SCHEMA,'nodes':[{'id':'py','language':'python','source':'def transform(x):\n    return x\n', 'export':'transform','params':['record{ref:i64}'],'returns':'record{ref:i64}','args':[{'literal':val}]}]}
        r=run_nested(pr,authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['py']['value'],val)
class NodeCallbackTests(unittest.TestCase):
    def project(self,source='export async function transform(x) {const y=await usl_twice(x);return y+1;}',arg=8):
        return {'schema':SCHEMA,'nodes':[{'id':'js','language':'javascript','source':source,'export':'transform','params':['i64'],'returns':'i64','args':[arg],'callback':dict(CB)}]}
    @unittest.skipUnless(shutil.which('node'),'Node unavailable')
    def test_active_javascript_callback(self):
        r=run_nested(self.project(),authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['js']['value'],17)
        e=r['results']['js']['evidence'];self.assertEqual(e['mode'],'live_javascript_usl_callback')
        self.assertEqual(e['callback_count'],1)
    @unittest.skipUnless(shutil.which('node'),'Node unavailable')
    def test_javascript_two_calls(self):
        p=self.project('export async function transform(x) { const a=await usl_twice(x);return await usl_twice(a); }')
        r=run_nested(p,authorized=True)
        self.assertTrue(r['all_verified'],r['failures']);self.assertEqual(r['results']['js']['value'],32)
        self.assertEqual(r['results']['js']['evidence']['callback_count'],2)
    @unittest.skipUnless(shutil.which('node'),'Node unavailable')
    def test_javascript_call_limit(self):
        p=self.project('export async function transform(x) { const a=await usl_twice(x);return await usl_twice(a); }')
        p['nodes'][0]['callback']['max_calls']=1
        r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('maximum invocation',r['failures']['js']['reason'])
    @unittest.skipUnless(shutil.which('node'),'Node unavailable')
    def test_javascript_timeout(self):
        p=self.project('export async function transform(x){await new Promise(r=>setTimeout(r,3000));return await usl_twice(x);}')
        p['nodes'][0]['callback']['timeout_seconds']=.25
        t=time.perf_counter();r=run_nested(p,authorized=True)
        self.assertFalse(r['all_verified']);self.assertIn('timed out',r['failures']['js']['reason'])
        self.assertLess(time.perf_counter()-t,2)
    def test_no_approval(self):
        with self.assertRaisesRegex(ValueError,'approval'):
            run_nested(self.project(),authorized=False)
if __name__=='__main__':unittest.main()
