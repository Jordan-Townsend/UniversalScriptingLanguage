import json
import tempfile
import threading
import time
import unittest
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from usl_systems.store import Store
from usl_systems.shadow_sessions import ShadowSessions, ShadowInterrupted
from usl_systems.language import USLError

class ShadowStreaming(unittest.TestCase):
 def setUp(self):
  t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup)
  self.store=Store(Path(t.name)/'state')
  self.first_chunk=threading.Event()
  testcase=self
  class Ollama(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    if self.path!='/api/chat':self.send_error(404);return
    req=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
    testcase.last_request=req
    self.send_response(200);self.send_header('Content-Type','application/x-ndjson');self.end_headers()
    values=({'message':{'content':'HEL'},'done':False},
            {'message':{'content':'LO'},'done':False},
            {'message':{'content':'!'},'done':True})
    if getattr(testcase,'incomplete',False):values=values[:1]
    for i,x in enumerate(values):
     try:self.wfile.write((json.dumps(x)+'\n').encode());self.wfile.flush()
     except (BrokenPipeError,ConnectionResetError):break
     if i==0:
      testcase.first_chunk.set()
      if getattr(testcase,'delayed',False):time.sleep(.35)
  self.http=ThreadingHTTPServer(('127.0.0.1',0),Ollama)
  thread=threading.Thread(target=self.http.serve_forever,daemon=True);thread.start()
  self.addCleanup(lambda:(self.http.shutdown(),self.http.server_close(),thread.join(2)))
  self.models_patch=patch('usl_systems.shadow_sessions.models',return_value={'connected':True,'models':['local-mini']})
  self.url_patch=patch('usl_systems.shadow_sessions._url',side_effect=lambda path:f'http://127.0.0.1:{self.http.server_port}{path}')
  self.models_patch.start();self.url_patch.start();self.addCleanup(self.models_patch.stop);self.addCleanup(self.url_patch.stop)
  self.sessions=ShadowSessions(self.store)
  self.id=self.sessions.new('local-mini')['id']
 def test_stream_three_chunks_and_persist_exact_reply(self):
  result=self.sessions.send(self.id,'Hi there')
  self.assertEqual(result['reply'],'HELLO!')
  self.assertTrue(self.last_request['stream'])
  self.assertEqual(self.last_request['messages'][-1]['content'],'Hi there')
  self.assertEqual([x['status'] for x in self.sessions.history(self.id)['turns']],['completed','completed'])
 def test_incomplete_stream_must_not_commit(self):
  self.incomplete=True
  with self.assertRaises(USLError):self.sessions.send(self.id,'Hi there')
  self.assertEqual([x['status'] for x in self.sessions.history(self.id)['turns']],['failed'])
 def test_cancel_does_not_commit_partial_reply(self):
  self.delayed=True
  results=[]
  def send():
   try:results.append(self.sessions.send(self.id,'cancellable'))
   except Exception as exc:results.append(exc)
  t=threading.Thread(target=send);t.start()
  self.assertTrue(self.first_chunk.wait(4))
  self.assertTrue(self.sessions.cancel(self.id)['cancellation_requested'])
  t.join(6)
  self.assertFalse(t.is_alive())
  self.assertEqual(len(results),1)
  self.assertIsInstance(results[0],ShadowInterrupted)
  self.assertEqual([x['status'] for x in self.sessions.history(self.id)['turns']],['interrupted'])
  self.assertFalse(self.sessions.cancel(self.id)['cancellation_requested'])
 def test_reopened_sessions_keep_interrupted_status(self):
  self.delayed=True
  thread=threading.Thread(target=lambda:self._safe_send(),daemon=True);thread.start()
  self.assertTrue(self.first_chunk.wait(4));self.sessions.cancel(self.id)
  thread.join(6);self.assertFalse(thread.is_alive())
  self.assertEqual(ShadowSessions(self.store).history(self.id)['turns'][0]['status'],'interrupted')
 def _safe_send(self):
  try:self.sessions.send(self.id,'will stop')
  except ShadowInterrupted:pass
 def test_custom_model_provider_compatibility(self):
  local=ShadowSessions(self.store,invoke=lambda turns,model:('fake response',model or 'test'))
  self.assertEqual(local.send(self.id,'custom provider')['reply'],'fake response')
 def test_http_cancel_rejects_wrong_token(self):
  from usl_systems.server import Handler
  from usl_systems.engine import Engine
  from usl_systems.bridge import ProcessBridge
  from usl_systems.autonomy import AutonomyController
  self.store.stop_token='secret-control'
  engine=Engine(self.store);bridge=ProcessBridge(self.store);controller=AutonomyController(self.store,bridge)
  class H(Handler):pass
  H.store=self.store;H.engine=engine;H.bridge=bridge;H.autonomy=controller;H.shadow_sessions=self.sessions
  api=ThreadingHTTPServer(('127.0.0.1',0),H)
  t=threading.Thread(target=api.serve_forever,daemon=True);t.start()
  self.addCleanup(lambda:(api.shutdown(),api.server_close(),t.join(2),controller.close(),bridge.shutdown(),engine.pool.shutdown(wait=False,cancel_futures=True)))
  uri=f'http://127.0.0.1:{api.server_port}/api/shadow/cancel'
  def post(token):
   req=urllib.request.Request(uri,method='POST',data=json.dumps({'id':self.id}).encode(),
           headers={'Content-Type':'application/json',**({'X-USL-Control-Token':token} if token else {})})
   with urllib.request.urlopen(req,timeout=5) as rsp:return json.load(rsp)
  import urllib.error
  with self.assertRaises(urllib.error.HTTPError) as e:post(None)
  self.assertEqual(e.exception.code,403)
  self.assertFalse(post('secret-control')['cancellation_requested'])

 def test_concurrent_duplicate_turn_rejected(self):
  self.delayed=True
  thread=threading.Thread(target=self._safe_send,daemon=True);thread.start()
  self.assertTrue(self.first_chunk.wait(4))
  with self.assertRaises(ValueError):self.sessions.send(self.id,'second request during first')
  self.sessions.cancel(self.id);thread.join(6)
  self.assertFalse(thread.is_alive())
  self.assertEqual(self.sessions.history(self.id)['turns'][0]['status'],'interrupted')

 def test_bad_session_cancel_rejected(self):
  with self.assertRaises(ValueError):self.sessions.cancel('unsafe/invalid')

if __name__=='__main__':unittest.main()
