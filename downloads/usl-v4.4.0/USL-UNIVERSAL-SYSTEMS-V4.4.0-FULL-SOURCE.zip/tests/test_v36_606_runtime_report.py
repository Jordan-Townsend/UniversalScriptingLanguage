import tempfile,json,unittest
from pathlib import Path
from tools.qualify_606_runtime_coverage import make_report,MODE_KIND
class CatalogQualificationTests(unittest.TestCase):
    def test_all_606_present_no_fabricated_native_compilers(self):
        r=make_report()
        self.assertEqual(r['catalog_count'],606)
        self.assertEqual(len(r['entries']),606)
        self.assertFalse(r['all_606_full_native_compilers'])
        self.assertEqual(len(set(x['id'] for x in r['entries'])),606)
        self.assertEqual(r['verified_guest_subset_count'],14)
    def test_real_guest_only_claims(self):
        x=make_report();d={r['id']:r for r in x['entries']}
        for k in MODE_KIND:self.assertTrue(d[k]['subset_program_executed'])
        self.assertFalse(d['cpp']['complete_native_semantic_compiler'])
        self.assertTrue(any(not i['subset_program_executed'] for i in x['entries']))
        self.assertEqual(x['routable_606_pair_eligibility']['total_pair_count'],606**2)
    def test_missing_observed_proof_refused(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'empty.json';p.write_text(json.dumps({'all_verified':True,'verified':15,'results':{}}))
            with self.assertRaises(ValueError):make_report(p)
if __name__=='__main__':unittest.main()
