"""Local HTTP auth regression: untrusted pages cannot launch CPU process pools."""
import json, tempfile, threading, unittest, urllib.error, urllib.request
from http.server import ThreadingHTTPServer
from usl_systems.server import Handler
from usl_systems.store import Store
from usl_systems.engine import Engine
from usl_systems.bridge import ProcessBridge
from usl_systems.autonomy import AutonomyController
from usl_systems.shadow_sessions import ShadowSessions

class LocalControlSecurityTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        store=Store(self.temp.name);store.stop_token='private-test-token'
        engine=Engine(store);bridge=ProcessBridge(store);autonomy=AutonomyController(store,bridge)
        self.addCleanup(engine.pool.shutdown,wait=False,cancel_futures=True)
        self.addCleanup(bridge.shutdown)
        self.addCleanup(autonomy.close)
        class H(Handler):pass
        H.store=store;H.engine=engine;H.bridge=bridge;H.autonomy=autonomy;H.shadow_sessions=ShadowSessions(store)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),H)
        t=threading.Thread(target=self.server.serve_forever,daemon=True);t.start()
        self.addCleanup(t.join,timeout=3);self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
        self.base='http://127.0.0.1:'+str(self.server.server_port)

    def post(self,path,token=None):
        headers={'Content-Type':'application/json'}
        if token:headers['X-USL-Control-Token']=token
        req=urllib.request.Request(self.base+path,method='POST',headers=headers,
            data=json.dumps({'values':[1,2,3,4,5],'operator':'sum_squares','mode':'process',
                'config':{'workers':2,'leaf_size':2,'depth':2}}).encode())
        with urllib.request.urlopen(req,timeout=15) as response:return json.load(response)

    def test_process_backend_requires_private_token(self):
        with self.assertRaises(urllib.error.HTTPError) as cm:self.post('/api/worker/run')
        self.assertEqual(cm.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError) as cm:self.post('/api/worker/run',token='invalid')
        self.assertEqual(cm.exception.code,403)
        yes=self.post('/api/worker/run',token='private-test-token')
        self.assertTrue(yes['verified_exact'])
        self.assertEqual(yes['result'],55)
        self.assertEqual(yes['physical_worker_processes_max'],2)

if __name__=='__main__':unittest.main()
