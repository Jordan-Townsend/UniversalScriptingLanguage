import unittest
from usl_systems.module_contracts import validate_contracts
from usl_systems.module_linker import LinkError
from usl_systems.native import verify,tool_available
from usl_systems.module_linker import link_project,SCHEMA
BASE={'schema':SCHEMA,'entry':'main','modules':{'main':'use lib\nlet number = 7\nprint(double(number))','lib':'function double(x):\n    return x*2'},'contracts':{'lib.double':{'params':['int'],'returns':'int'}}}
class ContractTests(unittest.TestCase):
 def test_known_int_calls_and_returns(self):
  r=validate_contracts(BASE)
  self.assertTrue(r['valid'])
  self.assertGreaterEqual(r['locally_verified_checks'],2)
  self.assertFalse(r['full_type_soundness_proven'])
 def test_wrong_argument_is_rejected(self):
  p={**BASE,'modules':{**BASE['modules'],'main':'use lib\nprint(double("string"))'}}
  self.assertIn('argument_type_mismatch',{x['kind'] for x in validate_contracts(p)['errors']})
 def test_bad_return_is_rejected(self):
  p={**BASE,'modules':{**BASE['modules'],'lib':'function double(x):\n    return "bad"'}}
  self.assertIn('return_type_mismatch',{x['kind'] for x in validate_contracts(p)['errors']})
 def test_no_guessed_type_for_dynamic_args(self):
  p={**BASE,'modules':{**BASE['modules'],'main':'use lib\nfunction unknown(y):\n    return double(y)\nprint(unknown(7))'}}
  r=validate_contracts(p)
  self.assertTrue(r['valid']);self.assertTrue(r['unproven_checks'])
 def test_unrecognized_or_forged_contract(self):
  for key in ('missing.double','lib.fake'):
   p={**BASE,'contracts':{key:{'params':['int'],'returns':'int'}}}
   with self.subTest(key=key),self.assertRaises(LinkError):validate_contracts(p)
 def test_actual_native_behavior_is_independent_of_metadata(self):
  compiled=link_project(BASE)['source']
  for target in ('python','javascript','ruby','php'):
   if tool_available(target):
    with self.subTest(target=target):self.assertEqual(verify(compiled,target)['status'],'passed')
if __name__=='__main__':unittest.main()
