import json
import shutil
import tempfile
import unittest
from pathlib import Path
from usl_systems import semantic_conformance as sem

class TestSemanticSpecification(unittest.TestCase):
    def test_complete_catalog_no_false_complete(self):
        r=sem.ledger()
        self.assertEqual(r['catalog_count'],606)
        self.assertEqual(len({x['id'] for x in r['entries']}),606)
        self.assertEqual(r['certified_complete'],0)
        self.assertEqual(len(r['entries'][0]['required_dimensions'])>0,True)
        self.assertTrue(all(x['full_semantic_status']=='not_certified' for x in r['entries']))
    def test_reviewed_manifest_integrity(self):
        d=sem.corpus()
        self.assertEqual(len(d['cases']),10)
        with tempfile.TemporaryDirectory() as t:
            base=Path(t)/'semantic_fixtures';shutil.copytree(sem.ROOT/'semantic_fixtures',base)
            example=next(base.glob('*.python.py'))
            example.write_text(example.read_text(encoding='utf8')+'\n# mutation',encoding='utf8')
            with self.assertRaises(sem.ConformanceError):sem.corpus(root=t)
    def test_authorization_and_unknowns(self):
        with self.assertRaises(sem.ConformanceError):sem.run_case('python','loop_sum')
        with self.assertRaises(sem.ConformanceError):sem.run_case('unknown','loop_sum',authorized=True)
        with self.assertRaises(sem.ConformanceError):sem.qualify(authorized=True,workers=0)
        with self.assertRaises(sem.ConformanceError):sem.qualify(authorized=True,features=['not_real'])
        with self.assertRaises(sem.ConformanceError):sem.negative_syntax()
    def test_real_execution_with_provenance(self):
        for k in ('python','javascript','ruby','php'):
            with self.subTest(k=k):
                r=sem.run_case(k,'record_and_list',authorized=True)
                self.assertEqual(r['status'],'observed_pass')
                self.assertEqual(r['observed'],{'sum':11,'length':3})
                self.assertEqual(r['exit_code'],0)
                self.assertEqual(len(r['source_sha256']),64)
    def test_language_specific_numeric_semantics(self):
        r=sem.qualify(authorized=True,workers=4,
            features=('negative_integer_division','unicode_length','mutable_alias','empty_list_truth','precision_boundary'))
        self.assertTrue(r['all_passed'],repr([x for x in r['cases'] if x['status']!='observed_pass']))
        self.assertEqual(r['test_count'],20)
        div=r['language_specific_oracles']['negative_integer_division']
        self.assertEqual(div['python'],-3)
        self.assertEqual(div['javascript'],-2)
        self.assertEqual(r['language_specific_oracles']['empty_list_truth']['php'],False)
    def test_scoped_compatibility_matrix(self):
        q=sem.qualify(authorized=True,workers=4,features=('negative_integer_division','unicode_length'))
        matrix=sem.scoped_compatibility_matrix(q)
        self.assertEqual(matrix['cells'],160)
        self.assertGreater(matrix['shim_needed_for_fixture'],0)
        self.assertGreater(matrix['unverified'],0)
        self.assertFalse(any('full' in str(x['equivalence_claim']) and x['equivalence_claim'].startswith('full') for x in matrix['entries']))
    def test_bounded_python_to_js_semantics(self):
        q=sem.qualify_python_js_shim(authorized=True)
        self.assertEqual(q['status'],'observed_pass')
        self.assertEqual(q['observed']['precision_boundary']['decimal'],'9007199254740993')
        self.assertEqual(q['observed']['unicode_length'],2)
    def test_all_negative_parsers_reject(self):
        result=sem.negative_syntax(authorized=True)
        self.assertTrue(result['all_passed'],repr(result))
        self.assertEqual(result['passed'],4)
    def test_language_families_not_fabricated(self):
        entries={x['id']:x for x in sem.ledger()['entries']}
        self.assertEqual(entries['json']['category'],'data_markup_or_grammar')
        self.assertEqual(entries['python']['category'],'programming_language')
        self.assertEqual(entries['verilog']['category'],'hardware_description_language')
        self.assertTrue(sem.ledger()['requires_classification']>0)

if __name__=='__main__':unittest.main()
