"""Actual compiler/interpreter fixture tests; not a claim of complete languages."""
from __future__ import annotations
import json
import shutil
import tempfile
import unittest
from unittest import mock
from pathlib import Path
from usl_systems.universal_adapters import (load_registry,discovered,run_adapter,qualify_registry,
      execute_extended_pair,capability_report,AdapterError)
from usl_systems.executable_matrix import fixtures,execute_pair,run_language_qualifications
from usl_systems.interop import SCHEMA,run_nested,BridgeError

class NativeAdapterTests(unittest.TestCase):
    def setUp(self):
        self.reg=load_registry()
    def test_registry_real_catalog_names(self):
        self.assertEqual(set(self.reg),{'tcl','lua','cmake','make'})
        self.assertEqual(len(capability_report()['entries']),606)
    def test_discovery_honest(self):
        d=discovered()
        for name in self.reg:
            self.assertEqual(d[name]['toolchain_present'],bool(shutil.which(self.reg[name]['runtime'])))
    def test_explicit_approval(self):
        with self.assertRaisesRegex(AdapterError,'approval'):
            run_adapter('tcl',41)
    def test_actual_native_processes(self):
        for name in self.reg:
            if not shutil.which(self.reg[name]['runtime']):continue
            for x in (41,5,-3):
                with self.subTest(lang=name,arg=x):
                    a=run_adapter(name,x,authorized=True)
                    self.assertEqual(a['observed'],x+self.reg[name]['operation']['constant'])
                    self.assertEqual(a['exit_code'],0)
                    self.assertEqual(len(a['stdout_sha256']),64)
    def test_i64_type_boundaries(self):
        for bad in ('41',True,1000000001):
            with self.assertRaises(AdapterError):run_adapter('tcl',bad,authorized=True)
    def test_source_digest_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)/'guest_adapters';base.mkdir()
            original=Path(__file__).resolve().parents[1]/'guest_adapters'/'tcl.json'
            doc=json.loads(original.read_text())
            doc['source']+='puts hacked\n'
            (base/'tcl.json').write_text(json.dumps(doc))
            with self.assertRaisesRegex(AdapterError,'Source hash mismatch'):load_registry(d)
    def test_reject_command_injection_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)/'guest_adapters';base.mkdir()
            original=Path(__file__).resolve().parents[1]/'guest_adapters'/'tcl.json'
            doc=json.loads(original.read_text())
            doc['argv']=['tclsh','guest.tcl','; touch /tmp/owned']
            (base/'tcl.json').write_text(json.dumps(doc))
            with self.assertRaisesRegex(AdapterError,'Unsafe argv'):load_registry(d)
    def test_missing_runtime_is_not_counted(self):
        with mock.patch('shutil.which',return_value=None):
            with self.assertRaisesRegex(AdapterError,'unavailable'):
                run_adapter('tcl',41,authorized=True)
    def test_nested_fixture_contract(self):
        f=fixtures(include_registry=True)
        self.assertEqual(len(f),22)
        a={k:v for k,v in f['tcl'].items() if k!='expected'}
        b={k:v for k,v in f['lua'].items() if k!='expected'}
        b['args']=[{'ref':'a'}]
        a['expected']=48;b['expected']=59
        out=run_nested({'schema':SCHEMA,'nodes':[{'id':'a',**a},{'id':'b',**b}]},authorized=True,workers=2)
        self.assertTrue(out['all_verified'])
        self.assertEqual(out['results']['b']['value'],59)
    def test_reject_modified_foreign_source(self):
        f=fixtures(include_registry=True)['tcl']
        doc={'schema':SCHEMA,'nodes':[{'id':'t',**f,'source':f['source']+'puts 99\n'}]}
        out=run_nested(doc,authorized=True)
        self.assertFalse(out['all_verified'])
        self.assertIn('reviewed fixture',out['failures']['t']['reason'])
    def test_parallel_batch_verification(self):
        out=qualify_registry(authorized=True,workers=4)
        present=sum(bool(shutil.which(d['runtime'])) for d in self.reg.values())
        self.assertEqual(out['tested_adapters'],4)
        self.assertEqual(out['passed'],present*3)
        self.assertEqual(out['tests'],12)
        self.assertEqual(out['full_semantic_language_compilers_proven'],0)
    def test_extended_pair(self):
        if not (shutil.which('tclsh') and shutil.which('texlua')):self.skipTest('runtime missing')
        out=execute_extended_pair('tcl','lua',authorized=True)
        self.assertEqual(out['second']['observed'],59)
        route=execute_pair('tcl','lua',authorized=True,include_registry=True)
        self.assertTrue(route['verified'])
    def test_bad_adapter_cannot_qualify_native(self):
        with self.assertRaises(AdapterError):execute_extended_pair('tcl','made_up',authorized=True)

if __name__=='__main__':unittest.main()
