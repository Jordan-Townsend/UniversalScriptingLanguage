import json, tempfile, unittest
from pathlib import Path
from usl_systems.syntax_validation import validate_syntax,VALIDATORS,SyntaxValidationError
from usl_systems.catalog import syntax_catalog
from usl_systems.qualification import profiles

class ParserTests(unittest.TestCase):
    def test_catalogue_preserved(self):
        self.assertEqual(len(syntax_catalog()),606)
        self.assertEqual(len(list(profiles())),606)
        self.assertTrue(set(VALIDATORS).issubset({x['id'] for x in syntax_catalog()}|{'jsonl'}))
    def test_real_parsers_accept(self):
        fixtures={'json':'{"a":true}', 'jsonld':'{"@context":{},"a":3}',
                  'jsonl':'{"a":1}\n[1,2]\n', 'toml':'[tool]\nx=3\n',
                  'ini':'[tool]\nx = 3\n','xml':'<root><child/></root>',
                  'python':'def twice(x):\n    return 2*x\n'}
        for lang,text in fixtures.items():
            with self.subTest(lang=lang):
                result=validate_syntax(text,lang)
                self.assertTrue(result['valid'],result)
                self.assertFalse(result['semantic_compiler'])
    def test_real_parsers_reject(self):
        failures={'json':'{"a":NaN}', 'jsonld':'{"a": 1,}',
                  'jsonl':'{"a":1}\nnot json', 'toml':'a = 1\na = 2\n',
                  'ini':'[a]\nk=1\nk=2', 'xml':'<root><a></root>',
                  'python':'def : no'}
        for lang,text in failures.items():
            with self.subTest(lang=lang):
                self.assertFalse(validate_syntax(text,lang)['valid'])
    def test_xml_entity_rejected(self):
        x='<!DOCTYPE root [<!ENTITY a "expansion">]><root>&a;</root>'
        self.assertFalse(validate_syntax(x,'xml')['valid'])
    def test_unknown_and_size_guard(self):
        with self.assertRaises(SyntaxValidationError): validate_syntax('x','not-a-parser')
        with self.assertRaises(SyntaxValidationError): validate_syntax('x'*1000001,'json')
    def test_source_integrity_sha(self):
        import hashlib
        x=validate_syntax('{"ok":true}','json')
        self.assertEqual(x['source_sha256'],hashlib.sha256(b'{"ok":true}').hexdigest())

if __name__=='__main__':unittest.main()
