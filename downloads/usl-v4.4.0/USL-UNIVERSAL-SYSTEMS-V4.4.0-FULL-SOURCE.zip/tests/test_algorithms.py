"""Proof-oriented regression tests for mathematical and USL execution modules."""
import concurrent.futures,json,math,os,random,tempfile,unittest
from pathlib import Path
from usl_systems.equations import list_equations,evaluate,EquationError
from usl_systems.collapse import collapse_bytes,restore_bytes,CollapseError,ContentStore
from usl_systems.fractal import FactoredFractal,dimensionless_load,jain_fairness,FractalError

class EquationTests(unittest.TestCase):
    def test_catalog_size(self):self.assertGreaterEqual(len(list_equations()),50)
    def test_executable_count(self):self.assertGreaterEqual(sum(x['executable'] for x in list_equations()),35)
    def test_all_scalar_defaults_finite(self):
        for x in list_equations():
            if x['executable']:
                with self.subTest(equation=x['id']):self.assertTrue(math.isfinite(evaluate(x['id'])['result']))
    def test_source_provenance(self):self.assertTrue(all(x['source'] and x['use_cases'] for x in list_equations()))
    def test_kinetic_energy(self):self.assertEqual(evaluate('kinetic_energy',{'m':2,'v':3})['result'],9)
    def test_photon_energy(self):self.assertAlmostEqual(evaluate('photon_energy')['result'],3.313035075e-19,places=28)
    def test_symbolic_reject(self):
        with self.assertRaises(EquationError):evaluate('lindblad')
    def test_unsafe_params_reject(self):
        with self.assertRaises(EquationError):evaluate('kinetic_energy',{'m':'__import__("os")'})
    def test_extra_params_reject(self):
        with self.assertRaises(EquationError):evaluate('kinetic_energy',{'extra':1})
    def test_div_zero(self):
        with self.assertRaises(EquationError):evaluate('rho',{'available':0})
    def test_usecase_search(self):self.assertTrue(list_equations('data-center'))

class CompressionTests(unittest.TestCase):
    def verify(self,data,ref=None,mode='all'):
        record=collapse_bytes(data,ref,mode)
        self.assertTrue(record['exact_verified'])
        self.assertEqual(restore_bytes(record,ref),data)
        self.assertEqual(record['sha256'],__import__('hashlib').sha256(data).hexdigest())
        return record
    def test_empty(self):self.verify(b'')
    def test_repetition(self):self.verify(b'A'*20000)
    def test_unicode(self):self.verify('héllø 世界 🌎'.encode()*200)
    def test_random(self):self.verify(os.urandom(12000))
    def test_all_zero(self):self.verify(b'\x00'*5000)
    def test_incompressible_negative_savings(self):
        rec=self.verify(os.urandom(5000))
        self.assertLess(rec['saved_bytes'],0)
    def test_zlib(self):self.verify(b'abc'*500,None,'zlib')
    def test_delta(self):
        ref=b'A'*2000;self.verify(b'A'*1999+b'B',ref,'delta')
    def test_duplicate(self):
        ref=b'test'*250;rec=self.verify(ref,ref,'duplicate');self.assertEqual(rec['codec'],'duplicate')
    def test_partial(self):self.verify(b'XYZ'*4000,None,'partial')
    def test_ref_corrupted(self):
        ref=b'C'*300;rec=self.verify(ref,ref,'duplicate')
        with self.assertRaises(CollapseError):restore_bytes(rec,b'D'*300)
    def test_payload_corrupted(self):
        rec=self.verify(b'ABCDEFG'*1000,None,'all')
        rec=dict(rec);rec['sha256']='0'*64
        with self.assertRaises(CollapseError):restore_bytes(rec)
    def test_bounded(self):
        with self.assertRaises(CollapseError):collapse_bytes(b'x'*16_000_001)
    def test_content_store(self):
        with tempfile.TemporaryDirectory() as d:
            store=ContentStore(d);payload=b'original bytes'*50
            self.assertFalse(store.put(payload)['reused']);self.assertTrue(store.put(payload)['reused'])
            self.assertEqual(store.get(store.put(payload)['sha256']),payload)
    def test_content_store_corrupt(self):
        with tempfile.TemporaryDirectory() as d:
            store=ContentStore(d);payload=b'alpha';sha=store.put(payload)['sha256'];store._path(sha).write_bytes(b'wrong')
            with self.assertRaises(CollapseError):store.get(sha)
    def test_concurrent_cas(self):
        with tempfile.TemporaryDirectory() as d:
            store=ContentStore(d);data=b'concurrent'*100
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                res=list(pool.map(store.put,[data]*30))
            self.assertEqual(len(set(x['sha256'] for x in res)),1)
            self.assertEqual(store.get(res[0]['sha256']),data)

class FractalTests(unittest.TestCase):
    def test_dimensions(self):
        r=dimensionless_load({'cache':2,'compute':4},{'cache':4,'compute':8})
        self.assertAlmostEqual(r['max_rho'],.5);self.assertEqual(r['fairness'],1)
    def test_jain(self):self.assertAlmostEqual(jain_fairness([1,2]),.9)
    def test_zero(self):self.assertEqual(FactoredFractal().execute([])['result'],0)
    def test_all_operators(self):
        seq=[3,2,-1,0,4,2]*350
        for op in ('sum','sum_squares','sum_abs','sum_even','histogram'):
            with self.subTest(op=op):
                r=FactoredFractal(workers=4,leaf_size=100,max_depth=8).execute(seq,op)
                self.assertTrue(r['verified_exact']);self.assertEqual(r['logical_items'],len(seq))
    def test_async_sync_identical(self):
        seq=[i%10-5 for i in range(10000)]
        calc=FactoredFractal(workers=4,leaf_size=50,max_depth=6)
        a=calc.execute(seq,'sum_squares',mode='async');b=calc.execute(seq,'sum_squares',mode='sync')
        self.assertEqual(a['result'],b['result']);self.assertTrue(a['reused_identical_partials']>0)
    def test_nonoverlap(self):
        r=FactoredFractal(leaf_size=5,max_depth=9).execute(list(range(103)))
        p=r['partitions'];self.assertEqual(sum(x['end']-x['start'] for x in p),103)
    def test_invalid_float(self):
        with self.assertRaises(FractalError):FactoredFractal().execute([1.5])
    def test_invalid_dims(self):
        with self.assertRaises(FractalError):FactoredFractal().execute([1,2],dimensions=['a','a'])
    def test_workers_not_imaginary(self):self.assertEqual(FactoredFractal(workers=3).execute([1,2])['physical_worker_threads_max'],3)
    def test_work_avoided_no_false_claims(self):
        seq=list(range(100))
        r=FactoredFractal(leaf_size=10,max_depth=6).execute(seq,reuse=False)
        self.assertEqual(r['reused_identical_partials'],0)
        self.assertEqual(r['physically_computed_partials'],r['N_logical_partials'])

if __name__=='__main__':unittest.main()

class IncrementalTests(unittest.TestCase):
    def test_all_operators(self):
        from usl_systems.incremental import CollapseCompute
        for op in ('sum','sum_squares','sum_abs','sum_even','histogram'):
            with self.subTest(op=op):
                engine=CollapseCompute(op)
                self.assertEqual(engine.initialize([1,2,-3,5])['mode'],'H0_FULL')
                self.assertEqual(engine.update({1:8,3:-5},audit=True)['mode'],'H2_PARTIAL_DELTA')
                self.assertEqual(engine.update({},audit=True)['mode'],'H1_EXACT_REUSE')
                self.assertEqual(engine.update({0:7},audit=False)['audited_against_full'],False)
                self.assertEqual(engine.output,__import__('usl_systems.fractal',fromlist=['_work'])._work(op,engine.values))
    def test_changes_transaction_validated(self):
        from usl_systems.incremental import CollapseCompute,IncrementalError
        e=CollapseCompute();e.initialize([1,2,3])
        with self.assertRaises(IncrementalError):e.update({12:10})
        self.assertEqual(e.values,[1,2,3])
    def test_benchmarks_honest_audit(self):
        from usl_systems.incremental import CollapseCompute
        x=CollapseCompute();x.initialize(list(range(100)))
        res=x.update({10:11},audit=True)
        self.assertGreater(res['physical_work_items'],res['logical_work_items'])
        self.assertLess(res['avoided_work_fraction'],0)
    def test_large_exact_delta(self):
        from usl_systems.incremental import CollapseCompute
        seq=[i%31 for i in range(10000)];x=CollapseCompute('sum_squares')
        x.initialize(seq)
        out=x.update({18:-500,9000:777},audit=False)
        self.assertEqual(out['physical_work_items'],2)
        self.assertTrue(out['correct'])
        self.assertEqual(x.output,sum(v*v for v in x.values))
    def test_archive_candidate_provenance(self):
        from usl_systems.research_index import discover_archives
        with tempfile.TemporaryDirectory() as t:
            import zipfile
            with zipfile.ZipFile(Path(t)/'src.zip','w') as z:
                z.writestr('research.md','My experiment equation: F = m*a and other notes\n')
            r=discover_archives(t)
            self.assertEqual(len(r['candidates']),1)
            self.assertEqual(r['candidates'][0]['status'],'unverified_candidate')

class FabricAlgorithmsTests(unittest.TestCase):
    def test_research_pipeline_real(self):
        from usl_systems.fabric import Fabric
        from usl_systems.store import Store
        from pathlib import Path
        root=Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory() as d:
            f=Fabric(Store(d),workers=4)
            r=f.execute(root/'examples/research_pipeline.uslflow.json')
            self.assertTrue(r['success'],r['status'])
            self.assertEqual(r['tasks'],5)
            self.assertTrue(r['results']['factored']['verified_exact'])
            self.assertTrue(r['results']['exact_store']['verified'])
            self.assertTrue(r['results']['partial_update']['verified'])
            self.assertTrue(r['results']['thermal']['numerical_evaluation'])
            r2=f.execute(root/'examples/research_pipeline.uslflow.json')
            self.assertTrue(r2['success'])
            self.assertTrue(all(v=='cached' for v in r2['status'].values()))

class TensorPlannerTests(unittest.TestCase):
    def test_balanced(self):
        from usl_systems.fractal import ServiceTensorPlanner
        req=[{'cpu':1,'memory':2} for _ in range(50)]
        caps=[{'cpu':5,'memory':10} for _ in range(4)]
        r=ServiceTensorPlanner().plan(req,caps)
        self.assertTrue(r['demand_conserved'])
        self.assertTrue(r['assignments_exactly_once'])
        self.assertEqual(r['M_dimensions'],2)
        self.assertEqual(r['N_logical_items'],50)
    def test_heterogeneous_capacity(self):
        from usl_systems.fractal import ServiceTensorPlanner
        req=[{'gpu':10,'cpu':1},{'gpu':1,'cpu':15},{'gpu':10,'cpu':1}]
        caps=[{'gpu':100,'cpu':10},{'gpu':10,'cpu':100}]
        r=ServiceTensorPlanner().plan(req,caps)
        self.assertTrue(r['planner']['max_rho']<=r['round_robin_baseline']['max_rho'])
    def test_fails_negative_and_mismatch(self):
        from usl_systems.fractal import ServiceTensorPlanner
        with self.assertRaises(FractalError):ServiceTensorPlanner().plan([{'cpu':-1}],[{'cpu':1}])
        with self.assertRaises(FractalError):ServiceTensorPlanner().plan([{'cpu':1}],[{'memory':1}])

class CustomEquationTests(unittest.TestCase):
    def test_safe_import_and_evaluate(self):
        from usl_systems.equation_import import EquationWorkspace
        from usl_systems.equations import evaluate
        root=Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory() as d:
            ws=EquationWorkspace(d)
            r=ws.import_file(root/'examples/research/custom_equation_import.json')
            self.assertEqual(r['imported'],1)
            self.assertAlmostEqual(evaluate('custom_oscillator_energy',extra=ws.records())['result'],.02)
    def test_reject_arbitrary_python_eval(self):
        from usl_systems.equation_import import EquationWorkspace,CustomEquationError
        with tempfile.TemporaryDirectory() as d:
            ws=EquationWorkspace(d)
            obj={'equations':[{'id':'malicious_equation','title':'Test','formula':'1+1','domain':'test',
                'source':'test','use_cases':['negative case'],'expression':'__import__("os").system("whoami")','defaults':{}}]}
            p=Path(d)/'import.json';p.write_text(json.dumps(obj))
            with self.assertRaises(CustomEquationError):ws.import_file(p)
    def test_duplicate_not_overwritten(self):
        from usl_systems.equation_import import EquationWorkspace,CustomEquationError
        root=Path(__file__).resolve().parent.parent
        with tempfile.TemporaryDirectory() as d:
            ws=EquationWorkspace(d);path=root/'examples/research/custom_equation_import.json'
            ws.import_file(path)
            with self.assertRaises(CustomEquationError):ws.import_file(path)

class AdaptivePolicyTests(unittest.TestCase):
    def test_adapts_without_false_speedup(self):
        from usl_systems.adaptive import AdaptiveExecutor
        r=AdaptiveExecutor(workers=4,max_depth=4,leaf_size=32).choose([i%7 for i in range(500)],repeats=2)
        self.assertTrue(r['verified_exact']);self.assertEqual(r['value'],sum((i%7)**2 for i in range(500)))
        self.assertIn(r['selected'],('serial','factored_sync','factored_async'))
        self.assertEqual(len(r['median_ms']),3)
    def test_input_validation(self):
        from usl_systems.adaptive import AdaptiveExecutor
        with self.assertRaises(FractalError):AdaptiveExecutor().choose([1,2],repeats=0)
