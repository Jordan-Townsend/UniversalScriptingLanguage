import unittest
from tools.qualify_v42_release import application_source,application_graph
from usl_systems.cooperative_workers import CooperativeScheduler

class SourceFleetApplication(unittest.TestCase):
    def test_native_artifacts_feed_usl_numeric_compression_and_old_bridges(self):
        source=application_source();graph=application_graph(source)
        result=CooperativeScheduler(threads=4,processes=0,allow_native=True,max_in_flight=4).run(graph,cache=False)
        self.assertTrue(result['all_verified'],result['blocked_or_failed'])
        app=result['tasks']['application']['value']
        self.assertEqual(app['stdout'],'18\n374\n96\n')
        self.assertEqual(len(app['evidence']),19)
        self.assertIn('native result: 96',app['dashboard_html'])
        self.assertEqual(result['tasks']['numeric']['value']['result'],sum(x*x for x in app['scores']))
        self.assertTrue(result['tasks']['compress']['value']['verified_exact'])
        self.assertLessEqual(result['max_active_observed'],4)
        for name in ('cython','llvm','sparql','protobuf'):
            self.assertEqual(result['tasks'][name]['status'],'verified')

if __name__=='__main__':unittest.main()
