import unittest
from usl_systems.intent_contracts import prove_usl,prove_native,prove_expression,IntentError
from usl_systems.compiler import transpile

CONTRACT={'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-1000000,'max':1000000}},'postcondition':'result == value * 2'}
SOURCE='function twice(value):\n    return value * 2\nprint(twice(21))\n'

class IntentContractTests(unittest.TestCase):
    def test_all_inputs_in_declared_domain_proved(self):self.assertTrue(prove_usl(SOURCE,'twice',CONTRACT)['proved'])
    def test_wrong_intent_produces_counterexample(self):
        r=prove_expression('value * 3',CONTRACT);self.assertFalse(r['proved']);self.assertIn('counterexample',r)
    def test_overflow_cannot_be_hidden_by_correct_equation(self):
        c={**CONTRACT,'inputs':{'value':{'min':2**30,'max':2**30+1}}}
        self.assertFalse(prove_expression('value * 2',c)['proved'])
    def test_unmodelled_library_call_fails_closed(self):
        with self.assertRaises(IntentError):prove_expression('abs(value)',CONTRACT)
    def test_actual_generated_native_ast_proved(self):
        for lang in ('python','javascript','c','cpp','go','rust','ruby','php','java','lua'):
            with self.subTest(language=lang):self.assertTrue(prove_native(transpile(SOURCE,lang).code,lang,'twice',CONTRACT)['proved'])
    def test_extra_native_side_effect_in_function_rejected(self):
        with self.assertRaises(IntentError):prove_native('function twice(value) { console.log(value); return value*2; }','javascript','twice',CONTRACT)
    def test_contract_is_mandatory(self):
        with self.assertRaises(IntentError):prove_expression('value*2',{})
    def test_constant_return_overflow_rejected(self):
        c={**CONTRACT,'postcondition':'result == 2147483648'}
        self.assertFalse(prove_expression('2147483648',c)['proved'])
    def test_wrong_native_parameter_signature_rejected(self):
        with self.assertRaises(IntentError):prove_native('function twice(other) { return value*2; }','javascript','twice',CONTRACT)
    def test_native_return_narrowing_and_async_rejected(self):
        with self.assertRaises(IntentError):prove_native('bool twice(int value) { return value*2; }','cpp','twice',CONTRACT)
        with self.assertRaises(IntentError):prove_native('async function twice(value) { return value*2; }','javascript','twice',CONTRACT)

if __name__=='__main__':unittest.main()
