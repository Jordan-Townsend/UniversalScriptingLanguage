import hashlib
import json
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from usl_systems.store import Store
from usl_systems.bridge import ProcessBridge
from usl_systems.engine import Engine
from usl_systems.autonomy import AutonomyController
from usl_systems.server import Handler
from usl_systems.observed_repair import ObservedRepair,ObserveError

class ObservedRepairTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.store=Store(Path(self.tmp.name)/'state')
  self.file=self.store.safe_project_path('calc','main.py');self.file.parent.mkdir(parents=True)
  self.file.write_text('def add(a,b)\n    return a+b\n')
  tests=self.file.parent/'tests';tests.mkdir()
  (tests/'test_calc.py').write_text('import unittest\nfrom main import add\nclass Test(unittest.TestCase):\n def test_add(self): self.assertEqual(add(4,5),9)\n')
  self.bridge=ProcessBridge(self.store);self.addCleanup(self.bridge.shutdown)
  self.worker=ObservedRepair(self.store,self.bridge)
 def test_real_compiler_failure_approve_repair_retest(self):
  before=hashlib.sha256(self.file.read_bytes()).hexdigest()
  with self.assertRaises(ObserveError):self.worker.observe('calc','main.py')
  state=self.worker.observe('calc','main.py',authorized=True)
  self.assertEqual(state['source_sha256'],before)
  self.assertNotEqual(state['exit_code'],0)
  self.assertIn('SyntaxError',state['stdout_stderr_tail'])
  self.assertIn('proposal',state)
  self.assertEqual(state['observed_process_id'],self.bridge.detail(state['observed_process_id'])['id'])
  self.assertIn('def add(a,b)\n',self.file.read_text())
  with self.assertRaises(ObserveError):self.worker.approve_and_verify(state['observed_process_id'])
  outcome=self.worker.approve_and_verify(state['observed_process_id'],authorized=True)
  self.assertEqual(outcome['status'],'verified_completed',outcome)
  self.assertEqual(outcome['repair']['baseline_syntax']['exit_code']!=0,True)
  self.assertTrue(outcome['verified_continuation'])
  self.assertIn('Ran 1 test',outcome['continuation']['stdout_stderr_tail'])
  self.assertEqual(outcome['continuation']['exit_code'],0)
  self.assertIn('def add(a,b):',self.file.read_text())
  with self.assertRaises(ObserveError):self.worker.approve_and_verify(state['observed_process_id'],authorized=True)
  again=ObservedRepair(self.store,ProcessBridge(self.store))
  self.addCleanup(again.bridge.shutdown)
  with self.assertRaises(ObserveError):again.approve_and_verify(state['observed_process_id'],authorized=True)
 def test_nonfailed_process_cannot_authorize_repair(self):
  self.file.write_text('def add(a,b):\n return a+b\n')
  state=self.worker.observe('calc','main.py',authorized=True)
  self.assertEqual(state['exit_code'],0)
  self.assertNotIn('proposal',state)
  with self.assertRaises(ObserveError):self.worker.approve_and_verify(state['observed_process_id'],authorized=True)
 def test_stale_hash_prevents_mutation(self):
  state=self.worker.observe('calc','main.py',authorized=True)
  self.file.write_text(self.file.read_text()+'# concurrent edit\n')
  with self.assertRaises(ObserveError):self.worker.approve_and_verify(state['observed_process_id'],authorized=True)
  self.assertIn('concurrent edit',self.file.read_text())
 def test_out_of_scope_path_rejected(self):
  with self.assertRaises((ObserveError,ValueError)):self.worker.observe('calc','../../secrets.py',authorized=True)
 def test_duplicate_claim_protected_under_parallel_calls(self):
  state=self.worker.observe('calc','main.py',authorized=True)
  from concurrent.futures import ThreadPoolExecutor
  def run():
   try:return self.worker.approve_and_verify(state['observed_process_id'],authorized=True)['status']
   except ObserveError:return 'rejected'
  with ThreadPoolExecutor(max_workers=2) as ex:results=list(ex.map(lambda _:run(),range(2)))
  self.assertEqual(results.count('verified_completed'),1,results)
  self.assertEqual(results.count('rejected'),1,results)
 def test_api_token_and_separate_approvals(self):
  self.store.stop_token='private-token'
  class H(Handler):pass
  H.store=self.store;H.engine=Engine(self.store);H.bridge=self.bridge
  H.autonomy=AutonomyController(self.store,self.bridge)
  server=ThreadingHTTPServer(('127.0.0.1',0),H)
  thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  self.addCleanup(lambda:(server.shutdown(),server.server_close(),thread.join(2),H.autonomy.close(),H.engine.pool.shutdown(wait=False,cancel_futures=True)))
  def post(path,body,token=None):
   headers={'Content-Type':'application/json'}
   if token:headers['X-USL-Control-Token']=token
   req=urllib.request.Request(f'http://127.0.0.1:{server.server_port}{path}',method='POST',data=json.dumps(body).encode(),headers=headers)
   with urllib.request.urlopen(req,timeout=15) as r:return json.load(r)
  args={'project':'calc','path':'main.py','approve_observation':True}
  with self.assertRaises(urllib.error.HTTPError) as x:post('/api/repair/observe',args)
  self.assertEqual(x.exception.code,403)
  with self.assertRaises(urllib.error.HTTPError):post('/api/repair/observe',{'project':'calc','path':'main.py'},'private-token')
  observed=post('/api/repair/observe',args,'private-token')
  with self.assertRaises(urllib.error.HTTPError):post('/api/repair/continue',{'observation_id':observed['observed_process_id'],'approve_repair':True})
  with self.assertRaises(urllib.error.HTTPError):post('/api/repair/continue',{'observation_id':observed['observed_process_id']},'private-token')
  result=post('/api/repair/continue',{'observation_id':observed['observed_process_id'],'approve_repair':True},'private-token')
  self.assertEqual(result['status'],'verified_completed',result)

if __name__=='__main__':unittest.main()
