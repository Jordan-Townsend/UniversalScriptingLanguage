import json, tempfile, threading, time, unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from usl_systems.store import Store
from usl_systems.shadow_sessions import ShadowSessions
from usl_systems.autonomy import AutonomyController, validate_plan, AutonomyError
from usl_systems.bridge_cycle import execute_cycle, LegacyError


class MockChromeBridge(BaseHTTPRequestHandler):
    state={'token':'0'*40, 'latest':None,'starts':0,'stops':0,'auth_errors':0,'finish':True,'stale':False,'goal':None,'completed':False}
    def log_message(self,*args):pass
    def _send(self,obj,code=200):
        b=json.dumps(obj).encode();self.send_response(code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def authorized(self):
        if self.headers.get('Authorization')!='Bearer '+self.state['token']:
            self.state['auth_errors']+=1;self._send({'ok':False},401);return False
        return True
    def do_GET(self):
        if not self.authorized():return
        if self.path=='/api/latest':return self._send({'ok':True,'report':self.state['latest']})
        if self.path=='/api/status':return self._send({'ok':True,'completed':self.state['completed'],
            'automation':{'phase':'verified' if self.state['completed'] else 'waiting_for_feedback',
                          'active':bool(self.state.get('advertise_active',False))},
            'jobs':[{'id':self.state['latest']['id'],'status':'finished'}] if self.state['latest'] else []})
        self._send({'ok':False},404)
    def do_POST(self):
        if not self.authorized():return
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        if self.path=='/api/automation_start':
            self.state['starts']+=1;self.state['goal']=body.get('goal')
            if self.state['finish']:
                self.state['completed']=True
                self.state['latest']={'id':'new-'+str(self.state['starts']), 'status':'pending','text':'verified by local acceptance','at':'2026-10-12'}
            elif not self.state['stale']:
                self.state['latest']={'id':'new-'+str(self.state['starts']), 'status':'waiting','verified':False,'success':False}
            return self._send({'ok':True,'message':'Cycle armed'})
        if self.path=='/api/automation_stop':self.state['stops']+=1;return self._send({'ok':True})
        self._send({'ok':False},404)


class V08Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=Store(Path(self.temp.name)/'state')
        self.state={'token':'0'*40,'latest':None,'starts':0,'stops':0,'auth_errors':0,'finish':True,'stale':False,'goal':None,'completed':False}
        # Bind request handler class to isolated state.
        handler=type('ChromeHandler',(MockChromeBridge,),{'state':self.state})
        self.server=ThreadingHTTPServer(('127.0.0.1',0),handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
        self.url='http://127.0.0.1:'+str(self.server.server_port)
        from os import environ
        self.patch=patch.dict(environ,{'USL_BRIDGE_TOKEN':self.state['token']});self.patch.start();self.addCleanup(self.patch.stop)

    def test_real_authenticated_bridge_cycle(self):
        marked=[]
        r=execute_cycle('Build and verify a working application',timeout=2,url=self.url,on_arm=lambda:marked.append(True),poll_interval=.02)
        self.assertTrue(r['verified_task']);self.assertEqual(r['status'],'completed');self.assertEqual(marked,[True])
        self.assertEqual(self.state['starts'],1);self.assertEqual(self.state['stops'],1)
        self.assertEqual(self.state['goal'],'Build and verify a working application')

    def test_stale_report_never_counts_as_success(self):
        self.state.update({'finish':False,'stale':True,'latest':{'id':'old','status':'completed','verified':True,'success':True}})
        r=execute_cycle('Build and verify a working application',timeout=1,url=self.url,poll_interval=.03)
        self.assertFalse(r['verified_task']);self.assertEqual(r['status'],'timed_out');self.assertEqual(self.state['stops'],1)

    def test_unverified_report_never_counts(self):
        self.state['finish']=False
        r=execute_cycle('Build and verify a working application',timeout=1,url=self.url,poll_interval=.02)
        self.assertFalse(r['verified_task'])

    def test_does_not_overwrite_an_existing_external_cycle(self):
        # This test server advertises an active automation; the owner may not
        # replace it through the v3 start endpoint.
        before=self.state['starts']
        self.state['advertise_active']=True
        with self.assertRaises(LegacyError):
            execute_cycle('Build and verify a working application',timeout=1,url=self.url)
        self.assertEqual(self.state['starts'],before)

    def test_cancel_before_arming(self):
        r=execute_cycle('Build and verify a working application',timeout=2,url=self.url,cancel=lambda:True)
        self.assertEqual(r['status'],'cancelled');self.assertEqual(self.state['starts'],0)

    def test_bridge_cycle_approval_required(self):
        control=AutonomyController(self.store)
        self.addCleanup(control.close)
        plan={'format':'uslauto-1','steps':[{'id':'go','kind':'bridge_cycle','prompt':'Build and verify a working application','timeout':2}]}
        record=control.create(plan)
        with self.assertRaises(AutonomyError):control.approve(record['id'])
        control.approve(record['id'],allow_process=True)
        with patch('usl_systems.autonomy.execute_cycle',return_value={'status':'completed','verified_task':True}) as call:
            control._run_step(record['id'],plan['steps'][0]);self.assertTrue(call.called)

    def test_bridge_cycle_never_auto_replays_after_interruption(self):
        ctl=AutonomyController(self.store);self.addCleanup(ctl.close)
        record=ctl.create({'format':'uslauto-1','steps':[{'id':'go','kind':'bridge_cycle','prompt':'Build and verify a working application'}]})
        ctl.approve(record['id'],allow_process=True)
        ctl._update(record['id'],status='running',current_child='bridge_cycle:external')
        ctl.close()
        ctl2=AutonomyController(self.store);self.addCleanup(ctl2.close)
        self.assertEqual(ctl2.detail(record['id'])['status'],'needs_review')

    def test_shadow_persistent_transcript(self):
        seen=[]
        def invoke(messages,model):
            seen.append(messages)
            return 'I can see '+messages[-1]['content'],'local-model'
        s=ShadowSessions(self.store,invoke=invoke)
        key=s.new()['id'];self.assertEqual(s.send(key,'First prompt')['turns'],2)
        self.assertEqual(s.send(key,'Second prompt')['turns'],4)
        self.assertEqual(len(seen[1]),3)
        restored=ShadowSessions(self.store,invoke=invoke).history(key)
        self.assertEqual(len(restored['turns']),4)
        self.assertEqual(restored['model'],'local-model')

    def test_shadow_failed_model_not_replayed(self):
        s=ShadowSessions(self.store,invoke=lambda *_: (_ for _ in ()).throw(RuntimeError('model offline')))
        key=s.new()['id']
        with self.assertRaises(RuntimeError):s.send(key,'Hello')
        history=s.history(key)
        self.assertEqual(history['turns'][0]['status'],'failed')
        self.assertEqual(len([x for x in history['turns'] if x['role']=='assistant']),0)

    def test_shadow_interrupted_transcript_on_restart(self):
        s=ShadowSessions(self.store,invoke=lambda *_: ('OK','m'))
        key=s.new()['id']
        with self.store.lock,self.store._db() as c:
            c.execute('INSERT INTO shadow_turns(session_id,role,content,status,created) VALUES (?,?,?,?,?)',(key,'user','not finished','pending',time.time()))
        self.assertEqual(ShadowSessions(self.store).history(key)['turns'][0]['status'],'interrupted')

    def test_invalid_endpoint_rejected_without_network(self):
        for url in ('http://example.com:8766','http://localhost:8766','http://127.0.0.1:80','https://127.0.0.1:8766'):
            with self.subTest(url=url),self.assertRaises(LegacyError):execute_cycle('Build and verify a working application',url=url,timeout=1)

    def test_invalid_goal_rejected(self):
        with self.assertRaises(LegacyError):execute_cycle('short',url=self.url)

if __name__=='__main__':unittest.main()
