import json,tempfile,unittest
from pathlib import Path
from usl_systems.fabric import Fabric,validate_flow,FabricError
from usl_systems.store import Store

class FabricTests(unittest.TestCase):
    def test_cycle_rejection(self):
        p={'format':'uslflow-1','tasks':[{'id':'a','kind':'run','source':'s.usl','depends':['b']}, {'id':'b','kind':'run','source':'s.usl','depends':['a']}]}
        with self.assertRaisesRegex(FabricError,'Cycle'):validate_flow(p)
    def test_invalid_dependency(self):
        p={'format':'uslflow-1','tasks':[{'id':'a','kind':'run','source':'s.usl','depends':['x']}]}
        with self.assertRaises(FabricError):validate_flow(p)
    def test_parallel_flow_and_cache(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'app.usl').write_text('let sum=0\nfor i in range(5):\n    sum += i\nprint(sum)')
            plan={'format':'uslflow-1','tasks':[{'id':'run','kind':'run','source':'app.usl'},
                {'id':'js','kind':'compile','source':'app.usl','target':'javascript'},
                {'id':'python','kind':'verify','source':'app.usl','target':'python','depends':['run']} ]}
            path=root/'flow.json';path.write_text(json.dumps(plan))
            fabric=Fabric(Store(root/'data'),workers=3)
            first=fabric.execute(path);self.assertTrue(first['success'])
            self.assertEqual(first['results']['python']['status'],'passed')
            second=fabric.execute(path);self.assertTrue(second['success'])
            self.assertEqual(second['status']['run'],'cached')
            self.assertEqual(second['status']['js'],'cached')
            self.assertEqual(second['status']['python'],'completed')
    def test_native_opt_in_required(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'t.py').write_text('print(12)')
            plan={'format':'uslflow-1','tasks':[{'id':'native','kind':'native','source':'t.py','target':'python'}]}
            path=root/'flow.json';path.write_text(json.dumps(plan))
            r=Fabric(Store(root/'db')).execute(path)
            self.assertFalse(r['success']);self.assertIn('explicit opt-in',r['results']['native']['error'])
            x=Fabric(Store(root/'db')).execute(path,allow_native=True)
            self.assertTrue(x['success']);self.assertIn('12\n',x['results']['native']['stdout'])

if __name__=='__main__':unittest.main()
