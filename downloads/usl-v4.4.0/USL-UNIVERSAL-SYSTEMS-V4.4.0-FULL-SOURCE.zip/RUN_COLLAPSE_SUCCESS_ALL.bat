@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems collapse-success-all examples\universal_semantic.usl --i-approve-native) else (python -m usl_systems collapse-success-all examples\universal_semantic.usl --i-approve-native)
exit /b %errorlevel%
