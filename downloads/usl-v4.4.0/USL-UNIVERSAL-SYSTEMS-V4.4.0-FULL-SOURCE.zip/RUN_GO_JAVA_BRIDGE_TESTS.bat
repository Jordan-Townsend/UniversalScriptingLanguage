@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v30_go_java_bridge.py -v
pause
