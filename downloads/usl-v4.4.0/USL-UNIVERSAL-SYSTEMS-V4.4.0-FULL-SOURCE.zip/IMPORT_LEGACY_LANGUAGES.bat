@echo off
setlocal
cd /d "%~dp0"
echo Import historical public USL registry from Jordan-Townsend/Usldev.
echo This requires internet. The existing 606-syntax offline catalog works without it.
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems fetch-legacy) else (python -m usl_systems fetch-legacy)
if errorlevel 1 (echo Offline / unable to retrieve legacy registry. Current installation remains intact.&pause)
endlocal
