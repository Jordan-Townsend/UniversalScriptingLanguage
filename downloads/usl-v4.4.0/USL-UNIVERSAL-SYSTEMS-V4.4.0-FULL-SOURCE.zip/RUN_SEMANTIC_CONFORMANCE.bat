@echo off
setlocal
cd /d "%~dp0"
if not exist test_results mkdir test_results
where py >nul 2>nul
if not errorlevel 1 (
 py -3 tools\qualify_semantic_spec.py --approve-reviewed-source --workers 8
) else (
 python tools\qualify_semantic_spec.py --approve-reviewed-source --workers 8
)
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
