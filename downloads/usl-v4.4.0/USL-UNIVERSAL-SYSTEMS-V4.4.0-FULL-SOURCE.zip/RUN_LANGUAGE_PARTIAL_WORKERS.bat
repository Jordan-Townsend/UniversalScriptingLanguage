@echo off
setlocal
cd /d "%~dp0"
echo Qualify 15 language operations using USL cooperative workers.
where py >nul 2>nul
if not errorlevel 1 (
  set "USL_PY=py -3"
) else (
  set "USL_PY=python"
)
%USL_PY% tools\qualify_cooperative_domains.py --approved --workers 8
set "CODE=%ERRORLEVEL%"
echo Exit code: %CODE%
endlocal & exit /b %CODE%
