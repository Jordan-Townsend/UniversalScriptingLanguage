@echo off
cd /d "%~dp0"
echo No auto-updater is included in research release 0.3.0.
echo Update by extracting a verified new full release in a NEW directory.
echo Persistent state is stored outside this directory under LOCALAPPDATA.
echo Never overwrite a previous installation before testing the new one.
pause
