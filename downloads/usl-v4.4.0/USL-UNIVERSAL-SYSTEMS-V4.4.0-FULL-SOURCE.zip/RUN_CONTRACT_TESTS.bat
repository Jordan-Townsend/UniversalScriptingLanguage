@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m usl_systems check-contracts examples\contracts.uslproject.json --output test_results\local_contract_qualification.json
if errorlevel 1 exit /b 1
%PY% -m unittest discover -s tests -p test_v19_module_contracts.py -v
exit /b %errorlevel%
