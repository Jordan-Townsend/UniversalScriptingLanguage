@echo off
setlocal
cd /d "%~dp0"
if not exist "test_results" mkdir "test_results"
where py >nul 2>nul
if not errorlevel 1 (set "PYTHON=py -3") else (set "PYTHON=python")
%PYTHON% -m usl_systems bench --iterations 1000 > "test_results\bench.json"
type "test_results\bench.json"
%PYTHON% -m usl_systems incremental --count 100000 --changes 100 > "test_results\bench_incremental.json"
%PYTHON% -m usl_systems fractal --count 100000 --repeat 128 --workers 8 --leaf 256 --depth 9 > "test_results\bench_fractal.json"
echo RESEARCH: additional exact integer computation benchmarks saved in test_results.
echo NOTE: This is a local USL interpreter benchmark, NOT proof of acceleration against another runtime.
endlocal
