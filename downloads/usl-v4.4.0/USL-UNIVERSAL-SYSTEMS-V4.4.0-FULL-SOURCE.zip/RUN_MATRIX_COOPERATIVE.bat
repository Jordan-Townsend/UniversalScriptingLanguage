@echo off
setlocal
pushd "%~dp0"
python -m usl_systems cooperate "examples\cooperative_executable_matrix.json" --threads 4 --processes 0 --max-in-flight 4 --i-approve-native --output "test_results\v3.7.0_cooperative_executable_matrix.json"
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%
