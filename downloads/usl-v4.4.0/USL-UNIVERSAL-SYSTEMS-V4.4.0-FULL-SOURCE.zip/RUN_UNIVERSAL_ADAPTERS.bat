@echo off
setlocal
pushd "%~dp0"
python -m usl_systems adapter-qualify --i-approve-native --workers 4 --output test_results\v3.8.0_registered_adapters.json
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%
