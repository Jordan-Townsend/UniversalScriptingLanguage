@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 examples\observed_repair_demo.py) else (python examples\observed_repair_demo.py)
exit /b %ERRORLEVEL%
