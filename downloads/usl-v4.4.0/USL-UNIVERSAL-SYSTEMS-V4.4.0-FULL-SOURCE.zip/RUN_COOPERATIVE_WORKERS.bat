@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (set "PY=py -3") else (set "PY=python")
%PY% -m usl_systems cooperate examples\cooperative_development.json --threads 3 --processes 2 --checkpoint "%LOCALAPPDATA%\USL_UniversalSystems\cooperative_demo_checkpoint.json"
if errorlevel 1 (
 echo USL cooperative worker cycle FAILED. Check console for details.
 exit /b 1
)
echo USL cooperative worker cycle verified.
