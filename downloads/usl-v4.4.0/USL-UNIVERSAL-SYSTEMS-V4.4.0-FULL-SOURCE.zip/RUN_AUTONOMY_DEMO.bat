@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 examples\run_autonomy_demo.py) else (python examples\run_autonomy_demo.py)
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" pause
endlocal & exit /b %ERR%
