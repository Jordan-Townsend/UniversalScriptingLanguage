@echo off
setlocal
pushd "%~dp0"
echo USL 3.7: Re-qualify all locally available actual guests and all eligible catalog pairs.
call RUN_EXECUTABLE_MATRIX.bat
set "CODE=%ERRORLEVEL%"
popd
endlocal & exit /b %CODE%
