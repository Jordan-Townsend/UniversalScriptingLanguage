@echo off
setlocal
cd /d "%~dp0"
py -3 -m usl_systems nested-run examples\nested_nine_languages.uslnest.json --i-approve-native --output test_results\v3.0.0_nine_native_windows.json
pause
