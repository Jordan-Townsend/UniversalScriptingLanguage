@echo off
setlocal
cd /d "%~dp0"
if not exist "test_results" mkdir "test_results"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems doctor --json > "test_results\diagnostics.json") else (python -m usl_systems doctor --json > "test_results\diagnostics.json")
type "test_results\diagnostics.json"
echo Diagnostics written to test_results\diagnostics.json
endlocal
