@echo off
setlocal
pushd "%~dp0"
python -m usl_systems nested-run "examples\nested_eighteen_environments.uslnest.json" --workers 4 --i-approve-native --output "test_results\v3.7.0_eighteen_environments.json"
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%
