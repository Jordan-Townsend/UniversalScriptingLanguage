@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m usl_systems type-check-project examples\modules.uslproject.json --output test_results\local_type_diagnostics.json
if errorlevel 1 exit /b 1
%PY% -m unittest discover -s tests -p test_v18_semantic_types.py -v
exit /b %errorlevel%
