@echo off
setlocal
pushd "%~dp0"
echo USL v3.7 read-only routing status. No native compiler invoked.
call RUN_EXECUTABLE_MATRIX_STATUS.bat
set "CODE=%ERRORLEVEL%"
popd
endlocal & exit /b %CODE%
