@echo off
setlocal
pushd "%~dp0"
echo Running EVERY locally qualified USL guest-to-guest pair (native execution approved).
python tools\qualify_all_eligible_pairs_v37.py
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Failure evidence: test_results\v3.7.0_all_eligible_pair_exec.json
popd
endlocal & exit /b %RC%
