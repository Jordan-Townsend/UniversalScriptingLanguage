"""One reviewed upstream backend per bounded process and private work directory."""
from __future__ import annotations
import contextlib,io,json,os,subprocess,sys
from pathlib import Path

def native(argv,input_text=''):
    with tempfile_file() as out,tempfile_file() as err:
        p=subprocess.run(argv,input=input_text.encode(),stdout=out,stderr=err,timeout=16)
        out.seek(0);err.seek(0);stdout=out.read(262145);stderr=err.read(262145)
    if max(len(stdout),len(stderr))>262144:raise ValueError('native output bound')
    text=stderr.decode(errors='replace')
    if p.returncode or (Path(argv[0]).name=='bc' and ('error' in text.lower())):
        raise ValueError('NativeParserOrRuntimeError (exit '+str(p.returncode)+'): '+text+stdout.decode(errors='replace'))
    return stdout.decode('utf8')

def tempfile_file():
    import tempfile
    return tempfile.TemporaryFile()

def execute(req):
    p=req['profile'];engine=p['engine'];source=req['source'];context=req['context']
    suffix={'rust':'.rs','pascal':'.pas','lisp':'.lisp','scheme':'.scm','ocaml':'.ml','erlang':'.erl',
        'elixir':'.exs','clojure':'.clj','groovy':'.groovy','bc':'.bc','tcsh':'.csh','fish':'.fish',
        'pike':'.pike','r':'.R','prolog':'.pl','d':'.d','ada':'.adb','fortran_fixed':'.f',
        'verilog':'.sv','vhdl':'.vhd','fennel':'.fnl','scala':'.scala','csharp':'.cs'}.get(engine)
    if suffix:
        file=Path('source'+suffix);file.write_text(source)
        if engine=='rust':native(['rustc',str(file),'-o','program']);observed=native(['./program'])
        elif engine=='pascal':native(['fpc','-oprogram',str(file)]);observed=native(['./program'])
        elif engine=='d':native(['gdc',str(file),'-o','program']);observed=native(['./program'])
        elif engine=='ada':native(['gnatmake',str(file),'-o','program']);observed=native(['./program'])
        elif engine=='fortran_fixed':native(['gfortran',str(file),'-o','program']);observed=native(['./program'])
        elif engine=='lisp':observed=native(['sbcl','--script',str(file)])
        elif engine=='scheme':observed=native(['guile','--no-auto-compile','-s',str(file)])
        elif engine=='ocaml':observed=native(['ocaml',str(file)])
        elif engine=='erlang':observed=native(['erl','-noshell','-eval',source])
        elif engine=='prolog':observed=native(['swipl','-q','-s',str(file),'-g','main','-t','halt'])
        elif engine=='bc':observed=native(['bc','-q',str(file)])
        elif engine=='tcsh':observed=native(['tcsh','-f',str(file)])
        elif engine=='fish':observed=native(['fish','--no-config',str(file)])
        elif engine=='r':observed=native(['Rscript',str(file)])
        elif engine=='csharp':native(['mcs','-out:program.exe',str(file)]);observed=native(['mono','program.exe'])
        elif engine=='verilog':
            native(['iverilog','-g2012','-o','simulation',str(file)]);observed=native(['vvp','simulation'])
        elif engine=='vhdl':
            native(['ghdl','-a','--std=08',str(file)])
            observed=native(['ghdl','-r','--std=08','source','--stop-time=1ns'])
        else:observed=native([p['tool'],str(file)])
        return {'value':{'stdout':observed},'evidence':{'mode':p['mode'],'real_tool':p['tool']}}
    if engine=='asn1':
        import asn1tools
        schema=asn1tools.compile_string(source,'der')
        value=context['value'];encoded=schema.encode('Value',value)
        return {'value':{'decoded':schema.decode('Value',encoded),'encoded_hex':encoded.hex()}}
    if engine=='nestedtext':
        import nestedtext
        return {'value':nestedtext.loads(source)}
    if engine=='hcl':
        import hcl2
        return {'value':hcl2.loads(source)}
    if engine=='jsonnet':
        import _jsonnet
        return {'value':json.loads(_jsonnet.evaluate_snippet('source.jsonnet',source))}
    if engine=='wasm':
        import wasmtime
        configuration=wasmtime.Config();configuration.consume_fuel=True
        engine_=wasmtime.Engine(configuration);store=wasmtime.Store(engine_);store.set_fuel(100000)
        module=wasmtime.Module(engine_,source);instance=wasmtime.Instance(store,module,[])
        value=instance.exports(store)['twice'](store,context['value'])
        return {'value':{'result':value}}
    if engine=='email':
        from email.parser import Parser
        from email import policy
        message=Parser(policy=policy.strict).parsestr(source)
        return {'value':{'subject':str(message['Subject']),'body':message.get_payload().strip()}}
    if engine=='http':
        from http.client import HTTPResponse
        class Socket:
            def makefile(self,*args):return io.BytesIO(source.encode())
        response=HTTPResponse(Socket());response.begin()
        return {'value':{'status':response.status,'body':response.read(32768).decode()}}
    if engine=='urlencoded':
        from urllib.parse import parse_qs
        return {'value':parse_qs(source,strict_parsing=True,max_num_fields=100)}
    if engine=='deb822':
        from debian.deb822 import Deb822
        parsed=Deb822(io.StringIO(source))
        if not parsed or any(':' not in line for line in source.splitlines() if line and not line.startswith((' ','\t','#'))):
            raise ValueError('Deb822 field syntax rejected')
        return {'value':dict(parsed)}
    if engine=='dns':
        import dns.zone
        zone=dns.zone.from_text(source,origin='example.org.',check_origin=False)
        return {'value':{'addresses':[r.address for r in zone.get_rdataset('value','A')]}}
    if engine=='yang':
        from pyang import context as pc,repository,error
        ctx=pc.Context(repository.FileRepository('.'));module=ctx.add_module('source.yang',source);ctx.validate()
        errors=[(str(position),tag,str(args)) for position,tag,args in ctx.errors if error.is_error(error.err_level(tag))]
        if module is None or errors:raise ValueError('YangGrammarError: '+str(errors))
        return {'value':{'module':module.arg,'leaves':[leaf.arg for leaf in module.search('leaf')]}}
    if engine=='yara':
        import yara
        rules=yara.compile(source=source)
        return {'value':{'matches':[m.rule for m in rules.match(data=context['text'])]}}
    if engine=='abnf':
        from abnf import Rule
        class Grammar(Rule):pass
        Grammar.load_grammar(source)
        node=Grammar('value').parse_all(context['text'])
        return {'value':{'matched':node.value}}
    if engine=='ebnf':
        from lark import Lark
        parser=Lark(source,parser='lalr');tree=parser.parse(context['text'])
        return {'value':{'tree':tree.pretty(),'text':context['text']}}
    if engine=='properties':
        Path('PropertiesReader.java').write_text('import java.io.*; import java.util.*; class PropertiesReader { public static void main(String[] a)throws Exception { Properties p=new Properties(); try(Reader r=new FileReader(a[0])){p.load(r);} System.out.println(p.getProperty("value")); }}')
        Path('source.properties').write_text(source)
        return {'value':{'stdout':native(['java','PropertiesReader.java','source.properties'])}}
    if engine=='erb':
        Path('source.erb').write_text(source)
        rendered=native(['ruby','-rjson','-rerb','-e','c=JSON.parse(STDIN.read);puts ERB.new(File.read(ARGV[0])).result_with_hash(c.transform_keys(&:to_sym))','source.erb'],json.dumps(context))
    elif engine in ('mako','genshi_text'):
        from source_worker import execute as render
        return render({'engine':engine if engine=='mako' else 'not_used','host':p['host'],'source':source,'context':context}) if engine=='mako' else genshi_render(source,context,p['host'])
    elif engine=='ul4':
        from ll import ul4c
        template=ul4c.Template(source);rendered=template.renders(**context)
    else:raise ValueError('unknown reviewed backend')
    if p['host']=='python':
        Path('rendered.py').write_text(rendered)
        return {'value':{'stdout':native([sys.executable,'rendered.py'])}}
    from source_worker import validate_host
    return {'value':validate_host(p['host'],rendered)}

def genshi_render(source,context,host):
    from genshi.template import NewTextTemplate
    from source_worker import validate_host
    return {'value':validate_host(host,NewTextTemplate(source).generate(**context).render('text'))}

if __name__=='__main__':
    try:
        if os.name!='nt':
            import resource
            resource.setrlimit(resource.RLIMIT_CPU,(24,24));resource.setrlimit(resource.RLIMIT_FSIZE,(128*1024**2,128*1024**2))
        request=json.loads(sys.stdin.buffer.read(65537))
        value=execute(request);encoded=json.dumps(value,ensure_ascii=False,allow_nan=False).encode()
        if len(encoded)>524288:raise ValueError('worker JSON bound exceeded')
        sys.stdout.buffer.write(encoded)
    except Exception as exc:
        sys.stderr.write(type(exc).__name__+': '+str(exc)[:4000]);sys.exit(1)
