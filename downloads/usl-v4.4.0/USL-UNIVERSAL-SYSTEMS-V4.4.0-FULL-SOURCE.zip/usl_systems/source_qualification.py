"""Separate source, syntax, behavior and runtime evidence for 18 new catalog IDs."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from .source_engines import CONTRACTS, SourceError, execute, digest, restore

def fixture(catalog_id,value=21):
    c=CONTRACTS[catalog_id];engine=c['engine'];host=c['host']
    context={'value':value,'label':'café ☃'}
    expr={'django':'{{ value }}','cheetah':'$value','mako':'${value}'}.get(engine)
    label={'django':'{{ label }}','cheetah':'$label','mako':'${label}'}.get(engine)
    if engine in ('django','cheetah','mako'):
        source={'text':f'{label}:{expr}', 'html':f'<strong>{label}:{expr}</strong>',
                'xml':f'<task><value>{expr}</value></task>', 'css':f'body {{ margin: {expr}px; }}',
                'javascript':f'console.log({expr} * 2);'}[host]
        bad={'django':'{% if value %}','cheetah':'#if $value\nmissing end','mako':'${value'}[engine]
    elif engine=='php':
        expressions={'html':'"<strong>".$usl_context["value"]."</strong>"',
            'css':'"body { margin: ".$usl_context["value"]."px; }"',
            'javascript':'"console.log(".$usl_context["value"]." * 2);"'}
        source='<?php echo '+expressions[host]+';'
        bad='<?php echo ('
    elif engine=='ruby':
        source={'css':'puts "body { margin: #{USL_CONTEXT[\"value\"]}px; }"',
            'javascript':'puts "console.log(#{USL_CONTEXT[\"value\"]} * 2);"'}[host]
        bad='puts ('
    elif engine=='graphql':
        source='query Compute($value: Int!) { twice(x: $value) echo(text: "café ☃") }'
        context={'value':value};bad='{ twice(x: }'
    elif engine=='dtd':
        source='<!ELEMENT task (value)>\n<!ELEMENT value (#PCDATA)>'
        context={'document':f'<task><value>{value}</value></task>'};bad='<!ELEMENT task ('
    return {'source':source,'context':context,'invalid_source':bad,'value':value}

def oracle(catalog_id,result,value):
    c=CONTRACTS[catalog_id];observed=result['value'];host=c['host'];engine=c['engine']
    if engine=='graphql':correct=observed['data']=={'twice':value*2,'echo':'café ☃'}
    elif engine=='dtd':correct=observed=={'validated':True,'root':'task','text':str(value)}
    elif host=='javascript':correct=observed['stdout']==str(value*2)+'\n'
    elif host=='css':correct=observed['declarations']==[{'name':'margin','value':str(value)+'px','important':False}]
    elif host=='xml':correct=observed['root']=='task' and observed['text']==str(value)
    elif host=='html':correct=observed['text']==(str(value) if engine=='php' else f'café ☃:{value}')
    else:correct=observed['rendered']==f'café ☃:{value}'
    if not correct:raise SourceError('Independent semantic oracle mismatch: '+str(observed))
    if restore(result['source_ir'])!=result['source_ir']['source']:raise SourceError('Source roundtrip failed')
    return True

def qualify_one(catalog_id):
    cases=[]
    for value,label in [(21,'positive'),(0,'boundary_zero'),(-7,'metamorphic_negative_input')]:
        f=fixture(catalog_id,value)
        try:
            result=execute(catalog_id,f['source'],f['context'],approved=True)
            oracle(catalog_id,result,value)
            cases.append({'case':label,'passed':True,'result':result})
        except Exception as e:cases.append({'case':label,'passed':False,'error':str(e)})
    f=fixture(catalog_id)
    try:
        execute(catalog_id,f['invalid_source'],f['context'],approved=True)
        cases.append({'case':'syntax_negative','passed':False,'error':'Native parser accepted invalid source'})
    except SourceError as e:
        # An absent provider/timeout is not a parser rejection success.
        marker={'django':'TemplateSyntaxError','cheetah':'ParseError','mako':'SyntaxException',
            'php':'Parse error','ruby':'syntax error','graphql':'GraphQLSyntaxError','dtd':'DTDParseError'}[CONTRACTS[catalog_id]['engine']]
        cases.append({'case':'syntax_negative','passed':'rejected source (exit 1)' in str(e) and marker in str(e),
            'expected_parser_error':marker,
            'source_sha256':digest(f['invalid_source']),'error':str(e)})
    return {'catalog_id':catalog_id,'cases':cases,'passed':all(c['passed'] for c in cases),'full_spec_qualified':False}

def qualify(*,workers=4):
    if type(workers) is not int or not 1<=workers<=8:raise SourceError('1..8 worker bound')
    with ThreadPoolExecutor(max_workers=workers) as pool:entries=list(pool.map(qualify_one,sorted(CONTRACTS)))
    return {'schema':'usl.source.qualification.v4.2','entries':entries,'new_catalog_entries':len(entries),
        'cases':sum(len(e['cases']) for e in entries),'passed_cases':sum(c['passed'] for e in entries for c in e['cases']),
        'all_passed':all(e['passed'] for e in entries),'full_specifications_qualified':0}

def ledger(report,baseline):
    if not report['all_passed']:raise SourceError('Native source qualification failed')
    new={e['catalog_id'] for e in report['entries']}
    rows=[]
    for row in baseline['entries']:
        copied=dict(row)
        if row['catalog_id'] in new:
            if row['qualification']!='unverified_execution':raise SourceError('New entry overlaps historical evidence')
            c=CONTRACTS[row['catalog_id']]
            copied.update(qualification='verified_source_engine_subset',family=c['engine'],
                source_import=True,full_spec_qualified=False,feature_tests=['positive','boundary_zero','metamorphic_negative_input','syntax_negative'],
                specification_reference=c['reference'],untested_features=['complete library','IO and imports','all semantic chapters','cross-runtime ownership','callbacks and concurrency'])
        rows.append(copied)
    if len(rows)!=606 or len({r['catalog_id'] for r in rows})!=606:raise SourceError('Invalid full catalog inventory')
    previous=baseline['total_executable_subsets']
    return {'schema':'usl.source.ledger.v4.2','catalog_total':606,'historical_subset_evidence':previous,
        'new_observed_source_entries':len(new),'total_subset_evidence':previous+len(new),
        'unqualified_entries':606-previous-len(new),'full_specifications_qualified':0,'entries':rows}

def matrix(report):
    if not report['all_passed']:raise SourceError('Qualification failed')
    records={r['catalog_id']:next(c['result'] for c in r['cases'] if c['case']=='positive') for r in report['entries']}
    cells=[]
    for host,result in sorted(records.items()):
        if digest(result['value'])!=result['value_sha256']:raise SourceError('Artifact integrity failed')
        if result['exit_code']!=0 or not result['source_execution_verified'] or result['source_ir']['catalog_id']!=host or digest(result['source_ir'])!=result['ir_sha256']:
            raise SourceError('Native source evidence integrity failed')
        if result['source_ir']['source']!=fixture(host)['source']:raise SourceError('Native source evidence is stale')
        oracle(host,result,21)
        for guest in sorted(records):
            raw=json.dumps({'host':host,'guest':guest,'typed_value':result['value']},ensure_ascii=False,sort_keys=True,allow_nan=False)
            if json.loads(raw)['typed_value']!=result['value']:raise SourceError('Typed transport corrupted')
            cells.append({'host':host,'guest':guest,'value_sha256':result['value_sha256'],'transport_sha256':digest(raw),'verified':True})
    return {'schema':'usl.source.matrix.v4.2','addressable_cells':606*606,'default':'unverified_native_semantics',
        'typed_artifact_handoffs':len(cells),'native_source_pair_claim':False,'historical_native_pairs_retained_separately':True,'cells':cells}
