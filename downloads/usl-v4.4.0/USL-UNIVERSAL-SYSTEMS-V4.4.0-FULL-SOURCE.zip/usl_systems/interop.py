"""USL nested language graph v1: real subprocess and C ABI bridges.

Explicitly approved native guest source is untrusted. This is NOT an OS
sandbox; run arbitrary native source only in a suitable isolated machine.
Wire values are JSON-compatible scalar values with strong boundary checks.
"""
from __future__ import annotations
import ast
import hashlib
import json
import sqlite3
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

from .language import Interpreter, USLError
from .ir import lower
from .catalog import load_catalog

SCHEMA = 'usl.nested.project.v1'
ABI = 'usl.bridge.abi.v1'
IDENT = re.compile(r'^[A-Za-z][A-Za-z0-9_]{0,60}$')
LANGS = ('usl','python','javascript','c','sql','ruby','php','go','java','perl','swift','typescript','kotlin','cpp','bash','fortran','awk','sed') + tuple(sorted(__import__('usl_systems.universal_adapters',fromlist=['load_registry']).load_registry()))
MAX_SOURCE = 16000
class BridgeError(ValueError):
    pass

def digest(data):
    if isinstance(data,str): data=data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()

def _json(obj):
    return json.dumps(obj,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))

def validate_value(value, spec):
    from .abi_types import validate, ABITypeError
    try:return validate(value,spec)
    except ABITypeError as exc:raise BridgeError(str(exc)) from exc

def _resolve_args(node, outputs):
    values=[]
    for item,typ in zip(node['args'],node['params']):
        if isinstance(item,dict) and set(item)=={'ref'}:
            key=item['ref']
            if key not in outputs:raise BridgeError('Missing dependency result '+str(key))
            val=outputs[key]['value']
        elif isinstance(item,dict) and set(item)=={'literal'}:val=item['literal']
        else:val=item
        values.append(validate_value(val,typ))
    return values

def _run_process(command, *, cwd, input_text=None, timeout=8):
    started=time.perf_counter()
    try:
        run=subprocess.run(command,cwd=str(cwd),input=input_text,text=True,capture_output=True,
                           timeout=timeout,check=False,encoding='utf8')
    except subprocess.TimeoutExpired as exc:
        raise BridgeError('Guest timed out after '+str(timeout)+' seconds') from exc
    return {'exit_code':run.returncode,'stdout':run.stdout[:50000], 'stderr':run.stderr[:4000],
            'duration_ms':round((time.perf_counter()-started)*1000,3),
            'command_program':Path(command[0]).name}

PY_GUEST = '''import contextlib,importlib.util,io,json,sys\nfrom pathlib import Path\nreq=json.loads(sys.stdin.read())\nmodule_path=Path(__file__).parent/'guest.py'\nspec=importlib.util.spec_from_file_location('usl_guest',module_path)\nm=importlib.util.module_from_spec(spec)\nwith contextlib.redirect_stdout(sys.stderr):\n    spec.loader.exec_module(m)\n    fn=getattr(m,req['function'])\n    value=fn(*req['args'])\nprint(json.dumps({'abi':'usl.bridge.abi.v1','value':value},allow_nan=False))\n'''
JS_GUEST = '''import * as guest from './guest.mjs';\nlet text='';for await(const chunk of process.stdin)text+=chunk;\nconst req=JSON.parse(text);\nconst fn=guest[req.function];\nif(typeof fn!=='function')throw Error('Missing export');\nconst value=await fn(...req.args);\nconsole.log(JSON.stringify({abi:'usl.bridge.abi.v1',value}));\n'''

C_GUEST = "import ctypes,json,sys\nfrom pathlib import Path\nreq=json.loads(sys.stdin.read())\nlib=ctypes.CDLL(str(Path(__file__).parent/req['library']))\nfn=getattr(lib,req['function'])\nfn.argtypes=[ctypes.c_int64]*len(req['args'])\nfn.restype=ctypes.c_int64\nvalue=fn(*req['args'])\nprint(json.dumps({'abi':'usl.bridge.abi.v1','value':value}))\n"

RUBY_GUEST = "require 'json'\nreq=JSON.parse(STDIN.read)\nload File.join(__dir__,'guest.rb')\nraise 'Missing declared USLGuest module' unless defined?(USLGuest)\nfn=req.fetch('function')\nraise 'Unknown declared guest export' unless USLGuest.singleton_methods(false).map(&:to_s).include?(fn)\nvalue=USLGuest.public_send(fn,*req.fetch('args'))\nSTDOUT.write(JSON.generate({'abi'=>'usl.bridge.abi.v1','value'=>value}))\n"
PHP_GUEST = "<?php\n$req=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR);\n$before=get_defined_functions()['user'];\nob_start(); require __DIR__.'/guest.php'; $noise=ob_get_clean();\nif (strlen($noise)>0) { fwrite(STDERR,$noise); }\n$after=array_values(array_diff(get_defined_functions()['user'],$before));\n$fn=$req['function'];\nif (!in_array(strtolower($fn),array_map('strtolower',$after),true)) {throw new RuntimeException('Unknown declared guest export');}\n$value=$fn(...$req['args']);\necho json_encode(['abi'=>'usl.bridge.abi.v1','value'=>$value],JSON_THROW_ON_ERROR);\n"

PERL_GUEST = """use strict;use warnings;use JSON::PP;
local $/;my $req=decode_json(<STDIN>);
require './guest.pl';
my $fn=$req->{function};
my $call=USLGuest->can($fn) or die 'Missing declared Perl export';
my $value=$call->(@{$req->{args}});
print JSON::PP->new->canonical->utf8(0)->allow_nonref->encode({abi=>'usl.bridge.abi.v1',value=>$value});
"""

def _execute(node, args, workspace):
    src=node['source'];lang=node['language'];fn=node['export'];ret=node['returns']
    if lang in ('python','javascript') and 'callback' in node:
        from .live_callbacks import execute_live
        return execute_live(node,args,workspace)
    if lang=='usl':
        if len(args)>8:raise BridgeError('Too many USL arguments')
        # The source is parsed by the existing restricted interpreter; passed
        # literals are JSON serialized, never arbitrary string interpolation.
        literals=','.join(repr(x) for x in args)
        body=src.rstrip()+'\nprint('+fn+'('+literals+'))\n'
        result=Interpreter(max_ops=100_000,timeout=4).run(body)
        # Scalars only, and the interpreter's output can differ from JSON syntax.
        if ret=='i64':
            try:value=int(result.output.strip())
            except ValueError as exc:raise BridgeError('USL i64 output is invalid') from exc
        elif ret=='bool':
            output=result.output.strip()
            if output not in ('True','False'):raise BridgeError('USL boolean result invalid')
            value=(output=='True')
        elif ret=='text':value=result.output.rstrip('\n')
        else:raise BridgeError('USL bridge supports i64/bool/text returns only')
        evidence={'mode':'pure_usl_runtime','exit_code':0,'stdout':result.output,
                  'operations':result.operations,'duration_ms':result.elapsed_ms}
    elif lang=='python':
        if not shutil.which(sys.executable):raise BridgeError('Python runtime unavailable')
        with tempfile.TemporaryDirectory(prefix='usl-py-',dir=workspace) as temp:
            root=Path(temp);(root/'guest.py').write_text(src,'utf8')
            (root/'worker.py').write_text(PY_GUEST,'utf8')
            evidence=_run_process([sys.executable,'-I','-S','worker.py'],cwd=root,
                                  input_text=_json({'function':fn,'args':args}),timeout=8)
        if evidence['exit_code']!=0:raise BridgeError('Python guest failed: '+evidence['stderr'][:500])
        try:obj=json.loads(evidence['stdout'])
        except ValueError as exc:raise BridgeError('Invalid Python ABI output') from exc
        if obj.get('abi')!=ABI:raise BridgeError('Python ABI version mismatch')
        value=obj['value'];evidence['mode']='isolated_process_python'
    elif lang=='javascript':
        node_exe=shutil.which('node')
        if not node_exe:raise BridgeError('Node.js not installed')
        with tempfile.TemporaryDirectory(prefix='usl-js-',dir=workspace) as temp:
            root=Path(temp);(root/'guest.mjs').write_text(src,'utf8')
            (root/'worker.mjs').write_text(JS_GUEST,'utf8')
            evidence=_run_process([node_exe,'worker.mjs'],cwd=root,
                                  input_text=_json({'function':fn,'args':args}),timeout=8)
        if evidence['exit_code']!=0:raise BridgeError('JS guest failed: '+evidence['stderr'][:500])
        try:obj=json.loads(evidence['stdout'])
        except ValueError as exc:raise BridgeError('Invalid JS ABI output') from exc
        if obj.get('abi')!=ABI:raise BridgeError('JS ABI version mismatch')
        value=obj['value'];evidence['mode']='isolated_process_node'
    elif lang=='ruby':
        ruby=shutil.which('ruby')
        if not ruby:raise BridgeError('Ruby interpreter not installed')
        with tempfile.TemporaryDirectory(prefix='usl-ruby-',dir=workspace) as temp:
            root=Path(temp);(root/'guest.rb').write_text(src,'utf8')
            (root/'worker.rb').write_text(RUBY_GUEST,'utf8')
            evidence=_run_process([ruby,'worker.rb'],cwd=root,
                                  input_text=_json({'function':fn,'args':args}),timeout=8)
        if evidence['exit_code']!=0:raise BridgeError('Ruby guest failed: '+evidence['stderr'][:500])
        try:obj=json.loads(evidence['stdout'])
        except ValueError as exc:raise BridgeError('Invalid Ruby ABI output') from exc
        if obj.get('abi')!=ABI:raise BridgeError('Ruby ABI version mismatch')
        value=obj['value'];evidence['mode']='isolated_process_ruby'
    elif lang=='php':
        php=shutil.which('php')
        if not php:raise BridgeError('PHP interpreter not installed')
        with tempfile.TemporaryDirectory(prefix='usl-php-',dir=workspace) as temp:
            root=Path(temp);(root/'guest.php').write_text(src,'utf8')
            (root/'worker.php').write_text(PHP_GUEST,'utf8')
            evidence=_run_process([php,'worker.php'],cwd=root,
                                  input_text=_json({'function':fn,'args':args}),timeout=8)
        if evidence['exit_code']!=0:raise BridgeError('PHP guest failed: '+evidence['stderr'][:500])
        try:obj=json.loads(evidence['stdout'])
        except ValueError as exc:raise BridgeError('Invalid PHP ABI output') from exc
        if obj.get('abi')!=ABI:raise BridgeError('PHP ABI version mismatch')
        value=obj['value'];evidence['mode']='isolated_process_php'
    elif lang=='sql':
        # Read-only, single SELECT statement with SQLite parameter binding.
        # No database file, no user-defined SQL functions or extensions.
        query=src.strip()
        if not re.match(r'(?is)^SELECT\s+',query) or ';' in query or len(query)>4000:
            raise BridgeError('SQL adapter only accepts one parameterized SELECT')
        if ret not in ('i64','text','null'):
            raise BridgeError('SQL v1 returns i64/text/null only')
        started=time.perf_counter()
        conn=sqlite3.connect(':memory:')
        try:
            allowed={sqlite3.SQLITE_SELECT,sqlite3.SQLITE_FUNCTION,sqlite3.SQLITE_READ}
            conn.set_authorizer(lambda action,a,b,c,d:sqlite3.SQLITE_OK if action in allowed else sqlite3.SQLITE_DENY)
            row=conn.execute(query,args).fetchone()
            if row is None or len(row)!=1:raise BridgeError('SQL query must return one scalar row')
            value=row[0]
        except sqlite3.Error as exc:
            raise BridgeError('SQLite SELECT failed: '+str(exc)[:300]) from exc
        finally:conn.close()
        evidence={'mode':'sqlite3_readonly_query','engine':'SQLite','engine_version':sqlite3.sqlite_version,
                  'exit_code':0,'duration_ms':round((time.perf_counter()-started)*1000,3),
                  'source_sha256':digest(src)}
    elif lang in ('typescript','kotlin'):
        from .extra_native import execute_extra
        try: value,evidence=execute_extra(lang,node,args,workspace)
        except ValueError as exc:raise BridgeError(str(exc)) from exc
    elif lang=='perl':
        perl=shutil.which('perl')
        if not perl:raise BridgeError('Perl interpreter not installed')
        with tempfile.TemporaryDirectory(prefix='usl-perl-',dir=workspace) as temp:
            root=Path(temp);(root/'guest.pl').write_text(src,'utf8')
            (root/'worker.pl').write_text(PERL_GUEST,'utf8')
            evidence=_run_process([perl,'worker.pl'],cwd=root,
                input_text=_json({'function':fn,'args':args}),timeout=8)
        if evidence['exit_code']!=0:raise BridgeError('Perl guest failed: '+evidence['stderr'][:500])
        try:obj=json.loads(evidence['stdout'])
        except ValueError as exc:raise BridgeError('Invalid Perl ABI output') from exc
        if obj.get('abi')!=ABI:raise BridgeError('Perl ABI version mismatch')
        value=obj['value'];evidence['mode']='isolated_process_perl'
    elif lang in ('go','java','swift'):
        from .polyglot_native import execute_guest
        try: value,evidence=execute_guest(lang,node,args,workspace)
        except ValueError as exc: raise BridgeError(str(exc)) from exc
    elif lang=='bash':
        if any(t not in ('i64','bool','text') for t in [*node['params'],ret]):
            raise BridgeError('Bash guest supports i64/bool/text only')
        bash=shutil.which('bash')
        if not bash:raise BridgeError('Bash interpreter not installed')
        with tempfile.TemporaryDirectory(prefix='usl-bash-',dir=workspace) as temp:
            root=Path(temp);(root/'guest.sh').write_text(src,'utf8')
            (root/'worker.sh').write_text('set -euo pipefail\nsource ./guest.sh\n'+fn+' "$@"\n','utf8')
            argv=[('true' if a else 'false') if type(a) is bool else str(a) for a in args]
            evidence=_run_process([bash,'--noprofile','--norc','worker.sh',*argv],cwd=root,timeout=8)
        if evidence['exit_code']!=0:raise BridgeError('Bash guest failed: '+evidence['stderr'][:500])
        value=evidence['stdout'].rstrip('\n')
        if ret=='i64':
            if not re.fullmatch(r'-?[0-9]+',value):raise BridgeError('Bash i64 output invalid')
            value=int(value)
        elif ret=='bool':
            if value not in ('true','false'):raise BridgeError('Bash bool output invalid')
            value=value=='true'
        evidence['mode']='bash_shell_function_subprocess'
    elif lang=='awk':
        if len(args)!=len(node['params']) or len(args)!=1 or node['params'][0] not in ('i64','text') or ret not in ('i64','text','bool'):
            raise BridgeError('AWK ABI v1 requires one i64/text argument and i64/text/bool return')
        exe=shutil.which('awk')
        if not exe:raise BridgeError('AWK interpreter not installed')
        with tempfile.TemporaryDirectory(prefix='usl-awk-',dir=workspace) as temp:
            root=Path(temp)
            (root/'guest.awk').write_text(src,encoding='utf8')
            # Passed through argv, not shell interpolation. Identifiers have
            # already been checked by the shared nested-project validator.
            (root/'worker.awk').write_text('BEGIN { print '+fn+'(USL_ARG0) }\n',encoding='utf8')
            evidence=_run_process([exe,'-v','USL_ARG0='+str(args[0]),'-f','guest.awk','-f','worker.awk'],cwd=root,timeout=5)
        if evidence['exit_code']!=0:raise BridgeError('AWK guest failed: '+evidence['stderr'][:500])
        value=evidence['stdout'].rstrip('\n')
        if ret=='i64':
            if not re.fullmatch(r'-?[0-9]+',value):raise BridgeError('AWK i64 result invalid')
            value=int(value)
        elif ret=='bool':
            if value not in ('true','false'):raise BridgeError('AWK bool result invalid')
            value=value=='true'
        evidence['mode']='awk_function_subprocess'
    elif lang=='sed':
        if fn!='transform' or node['params']!=['text'] or ret!='text' or len(args)!=1:
            raise BridgeError('Sed adapter requires transform(text)->text')
        exe=shutil.which('sed')
        if not exe:raise BridgeError('Sed executable unavailable')
        if '\x00' in args[0]:raise BridgeError('NUL not supported in Sed text input')
        with tempfile.TemporaryDirectory(prefix='usl-sed-',dir=workspace) as temp:
            root=Path(temp)
            (root/'guest.sed').write_text(src,encoding='utf8')
            evidence=_run_process([exe,'-f','guest.sed'],cwd=root,input_text=args[0]+'\n',timeout=5)
        if evidence['exit_code']!=0:raise BridgeError('Sed script failed: '+evidence['stderr'][:500])
        value=evidence['stdout'].removesuffix('\n');evidence['mode']='sed_script_subprocess'
    elif lang=='fortran':
        if len(args)!=len(node['params']) or any(t!='i64' for t in node['params']) or ret!='i64':
            raise BridgeError('Fortran C interoperable ABI v1 supports only i64 arguments and returns')
        compiler=shutil.which('gfortran')
        if not compiler:raise BridgeError('GNU Fortran compiler not installed')
        with tempfile.TemporaryDirectory(prefix='usl-fortran-',dir=workspace) as temp:
            root=Path(temp)
            (root/'guest.f90').write_text(src,encoding='utf8')
            suffix='.dll' if os.name=='nt' else '.dylib' if sys.platform=='darwin' else '.so'
            output=root/('guest'+suffix)
            build=_run_process([compiler,'-shared','-fPIC','-O1','-o',str(output),str(root/'guest.f90')],cwd=root,timeout=20)
            if build['exit_code']!=0:raise BridgeError('Fortran compile failed: '+build['stderr'][:500])
            (root/'ffi_worker.py').write_text(C_GUEST,encoding='utf8')
            call=_run_process([sys.executable,'-I','-S','ffi_worker.py'],cwd=root,
                         input_text=_json({'library':output.name,'function':fn,'args':args}),timeout=5)
            if call['exit_code']!=0:raise BridgeError('Fortran guest failed (isolated process): '+call['stderr'][:500])
            try:obj=json.loads(call['stdout'])
            except ValueError as exc:raise BridgeError('Invalid Fortran C ABI response') from exc
            if obj.get('abi')!=ABI:raise BridgeError('Fortran C ABI version mismatch')
            value=obj['value']
            evidence={'mode':'compiled_fortran_iso_c_binding_isolated_process',
                      'exit_code':call['exit_code'],'compiler':Path(compiler).name,
                      'build':build,'call':call,'duration_ms':round(build['duration_ms']+call['duration_ms'],3),
                      'source_sha256':digest(src)}
    elif lang in ('c','cpp'):
        if len(args)!=len(node['params']) or any(t!='i64' for t in node['params']) or ret!='i64':
            raise BridgeError('C FFI v1 supports only i64 arguments and returns')
        cc=(shutil.which('g++') or shutil.which('clang++')) if lang=='cpp' else (shutil.which('gcc') or shutil.which('cc'))
        if not cc:raise BridgeError('Native C/C++ compiler not installed')
        with tempfile.TemporaryDirectory(prefix='usl-'+lang+'-',dir=workspace) as temp:
            root=Path(temp);srcext='.cpp' if lang=='cpp' else '.c'
            (root/('guest'+srcext)).write_text(src,'utf8')
            suffix='.dll' if os.name=='nt' else '.dylib' if sys.platform=='darwin' else '.so'
            output=root/('guest'+suffix)
            cmd=[cc,*(['-std=c++17'] if lang=='cpp' else []),'-shared','-fPIC','-O1','-o',str(output),str(root/('guest'+srcext))]
            build=_run_process(cmd,cwd=root,timeout=20)
            if build['exit_code']!=0:raise BridgeError(lang.upper()+' compile failed: '+build['stderr'][:500])
            (root/'ffi_worker.py').write_text(C_GUEST,'utf8')
            call=_run_process([sys.executable,'-I','-S','ffi_worker.py'],cwd=root,
                              input_text=_json({'library':output.name,'function':fn,'args':args}),timeout=5)
            if call['exit_code']!=0:raise BridgeError('Native '+lang.upper()+' guest failed (isolated process): '+call['stderr'][:500])
            try:obj=json.loads(call['stdout'])
            except ValueError as exc:raise BridgeError('Invalid C ABI response') from exc
            if obj.get('abi')!=ABI:raise BridgeError('C ABI version mismatch')
            value=obj['value']
            evidence={'mode':'compiled_'+lang+'_abi_isolated_process','exit_code':call['exit_code'],
                      'compiler':Path(cc).name,'build':build,'call':call,
                      'duration_ms':round(build['duration_ms']+call['duration_ms'],3),
                      'source_sha256':digest(src)}
    elif lang in __import__('usl_systems.universal_adapters',fromlist=['load_registry']).load_registry():
        from .universal_adapters import load_registry,run_adapter
        adapter=load_registry()[lang]
        if src!=adapter['source'] or fn!='transform' or node['params']!=['i64'] or ret!='i64' or len(args)!=1:
            raise BridgeError('Registered adapter accepts only exact reviewed fixture source and i64 ABI')
        execution=run_adapter(lang,args[0],authorized=True)
        value=execution['observed']
        evidence={**execution,'mode':'reviewed_registry_'+lang+'_subprocess'}
    else:raise BridgeError('Unsupported installed guest '+str(lang))
    validate_value(value,ret)
    return value,evidence

def validate_project(project):
    if not isinstance(project,dict) or project.get('schema')!=SCHEMA:raise BridgeError('Unsupported nested project schema')
    nodes=project.get('nodes')
    if not isinstance(nodes,list) or not 1<=len(nodes)<=32:raise BridgeError('1..32 nested nodes required')
    if len(_json(project).encode('utf8'))>250_000:raise BridgeError('Project exceeds 250 KB')
    byid={}
    for node in nodes:
        if not isinstance(node,dict) or set(node)-{'id','language','source','export','params','returns','args','expected','callback'}:
            raise BridgeError('Unexpected node fields')
        ident=node.get('id');fn=node.get('export');src=node.get('source');lang=node.get('language')
        if not isinstance(ident,str) or not IDENT.fullmatch(ident) or ident in byid:raise BridgeError('Invalid or duplicate node ID')
        if not isinstance(fn,str) or not IDENT.fullmatch(fn):raise BridgeError('Invalid export identifier')
        if lang not in LANGS:raise BridgeError('Unsupported native guest language '+str(lang))
        if 'callback' in node:
            if lang not in ('python','javascript'):raise BridgeError('Live callback currently supports Python and JavaScript guests only')
            from .live_callbacks import validate_callback
            validate_callback(node['callback'])
        if not isinstance(src,str) or len(src.encode('utf8'))>MAX_SOURCE:raise BridgeError('Source exceeds 16 KB')
        params=node.get('params');args=node.get('args')
        if not isinstance(params,list) or not isinstance(args,list) or len(params)!=len(args) or len(args)>8:
            raise BridgeError('ABI signature must match 0..8 arguments')
        from .abi_types import parse_spec,ABITypeError
        for typ in [*params,node.get('returns')]:
            try:parse_spec(typ)
            except (ABITypeError,TypeError) as exc:raise BridgeError('Unsupported type in ABI contract: '+str(exc)) from exc
        refs=[]
        for a,p in zip(args,params):
            if isinstance(a,dict) and set(a)=={'ref'}:
                if not isinstance(a['ref'],str):raise BridgeError('Invalid result binding')
                refs.append(a['ref'])
            elif isinstance(a,dict) and set(a)=={'literal'}:
                validate_value(a['literal'],p)
            else:validate_value(a,p)
        byid[ident]=(node,refs)
    for ident,(node,refs) in byid.items():
        for ref in refs:
            if ref not in byid or ref==ident:raise BridgeError('Missing/self reference '+ref)
            if any(typ!=byid[ref][0]['returns'] for arg,typ in zip(node['args'],node['params']) if isinstance(arg,dict) and arg.get('ref')==ref):
                raise BridgeError('ABI type mismatch '+ref+' -> '+ident)
    seen=set();visiting=set()
    def visit(key):
        if key in visiting:raise BridgeError('Dependency cycle')
        if key in seen:return
        visiting.add(key)
        for dep in byid[key][1]:visit(dep)
        visiting.remove(key);seen.add(key)
    for name in byid:visit(name)
    return byid

def run_nested(project, *, authorized=False, workers=4, workspace=None):
    if not authorized:raise BridgeError('Explicit approval required to execute foreign/native source')
    byid=validate_project(project)
    if type(workers) is not int or not 1<=workers<=8:raise BridgeError('workers must be 1..8')
    started=time.perf_counter();results={};failures={};waiting=set(byid);active={}
    with tempfile.TemporaryDirectory(prefix='usl-native-bridge-',dir=workspace) as temp:
        root=Path(temp)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            while waiting or active:
                blocked=[k for k in waiting if any(r in failures for r in byid[k][1])]
                for k in blocked:
                    waiting.remove(k);failures[k]={'status':'blocked','reason':'failed dependency'}
                ready=sorted(k for k in waiting if all(r in results for r in byid[k][1]))
                for k in ready[:max(0,workers-len(active))]:
                    node=byid[k][0];args=_resolve_args(node,results)
                    f=pool.submit(_execute,node,args,root)
                    active[f]=k;waiting.remove(k)
                if not active:
                    if waiting:raise BridgeError('Deadlocked nested graph')
                    break
                finished,_=wait(active,timeout=0.2,return_when=FIRST_COMPLETED)
                for f in finished:
                    k=active.pop(f);node=byid[k][0]
                    try:
                        value,evidence=f.result()
                        if 'expected' in node and value!=validate_value(node['expected'],node['returns']):
                            raise BridgeError('Expected result mismatch in '+k)
                        results[k]={'status':'verified','value':value,'value_sha256':digest(_json(value)),
                                    'source_sha256':digest(node['source']), 'language':node['language'],
                                    'verified_execution':True,'evidence':evidence}
                    except Exception as exc:
                        failures[k]={'status':'failed','reason':str(exc)[:500]}
    return {'schema':'usl.nested.report.v1','abi':ABI,'project_sha256':digest(_json(project)),
            'all_verified':len(results)==len(byid),'verified':len(results),'total':len(byid),
            'results':results,'failures':failures,'elapsed_ms':round((time.perf_counter()-started)*1000,3),
            'execution_claim':'verified for these exact source programs and declared ABI types, not all language semantics'}

def python_subset_import(source):
    """Actual bounded Python frontend using existing USL parser/semantic IR.

    Supports only source compatible with the USL interpreter grammar.
    Unsupported Python semantics are rejected, not approximated.
    """
    tree=ast.parse(source)
    ir=lower(source)
    return {'frontend':'python_restricted','source_sha256':digest(source),
            'ast_nodes':sum(1 for _ in ast.walk(tree)), 'ir':ir,
            'claim':'valid only for bounded USL-compatible Python subset'}

def catalog_matrix():
    """Complete 606-catalog eligibility: not a matrix of observed pairwise tests."""
    rows=load_catalog()
    if len(rows)!=606:raise BridgeError('Expected exactly 606 baseline catalog entries')
    result=[]
    for row in rows:
        aliases={row['id'],*(a.lower() for a in row.get('aliases',[]))}
        lang='javascript' if aliases&{'javascript','js'} else ('sql' if aliases&{'sqlite3','sql','sqlite'} else next((x for x in ('python','c','ruby','php','go','java','perl','swift','typescript','kotlin','cpp','bash','fortran','awk','sed',*__import__('usl_systems.universal_adapters',fromlist=['load_registry']).load_registry().keys()) if x in aliases),None))
        runtime={'python':bool(sys.executable),'javascript':bool(shutil.which('node')),
                 'go':bool(shutil.which('go')), 'java':bool(shutil.which('java') and shutil.which('javac')),
                 'perl':bool(shutil.which('perl')),'swift':bool(shutil.which('swiftc')),
                 'typescript':bool(shutil.which('tsc') and shutil.which('node')),'kotlin':bool(shutil.which('kotlinc') and shutil.which('java')),
                 'cpp':bool(shutil.which('g++') or shutil.which('clang++')), 'bash':bool(shutil.which('bash')),'fortran':bool(shutil.which('gfortran')),
                 'c':bool(shutil.which('gcc') or shutil.which('cc')), 'awk':bool(shutil.which('awk')),'sed':bool(shutil.which('sed')), 'sql':True,
                 'ruby':bool(shutil.which('ruby')), 'php':bool(shutil.which('php'))}
        from .universal_adapters import discovered
        runtime.update({key:value['toolchain_present'] for key,value in discovered().items()})
        result.append({'id':row['id'],'name':row['name'],'recognized':True,
                       'native_bridge_family':lang,
                       'native_execution_qualified':False,'interop_eligible':'conditional' if lang and runtime.get(lang) else 'unverified',
                       'qualification':'Individual source + ABI + host runtime execution required',
                       'native_toolchain_present':bool(lang and runtime.get(lang))})
    return {'schema':'usl.interop.catalog_matrix.v1','count':len(result),'entries':result,
            'matrix_policy':{'conditional':'both host/guest adapters and matching typed ABI, requires individual test',
                             'unverified':'no verified transport for this pair'},
            'shape':[606,606],
            'pairs_are_tested':False,
            'eligible_ids':[r['id'] for r in result if r['interop_eligible']=='conditional']}

def python_host_call_usl(source,export,args,params,returns):
    """Actual bidirectional host API: Python can invoke a bounded USL export."""
    node={'id':'host_call','language':'usl','source':source,'export':export,
          'args':args,'params':params,'returns':returns}
    validate_project({'schema':SCHEMA,'nodes':[node]})
    # No native execution is involved, but use the same type/result contract.
    value,evidence=_execute(node,args,None)
    return {'value':value,'abi':ABI,'evidence':evidence,'source_sha256':digest(source)}

def bridge_eligibility_matrix():
    """Sparse, exact representation of 606^2 routing cells; default unverified.

    A conditional pair is a routing *possibility*, not an observed native test.
    """
    m=catalog_matrix();ids=m['eligible_ids']
    return {'schema':'usl.bridge.pair_eligibility.v1','size':606,'entry_order':[r['id'] for r in m['entries']],
            'default':'unverified','conditional_host_guest':{key:list(ids) for key in ids},
            'conditional_pair_count':len(ids)**2,
            'total_pair_count':606*606,
            'explicit_tested_pairs':[],
            'pair_eligibility_not_conformance':True,
            'notes':'All omitted cells have default unverified status; conditional cells require actual host/guest type-ABI checks.'}
