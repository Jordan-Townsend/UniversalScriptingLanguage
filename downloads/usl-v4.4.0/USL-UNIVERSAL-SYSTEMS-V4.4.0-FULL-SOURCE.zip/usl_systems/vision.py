"""Read-only image inspection interface for future EmoVision pipelines.
Pillow is an optional dependency. No face identification or model inference.
"""
from pathlib import Path
from .language import USLError

def inspect_image(path,max_pixels=40_000_000):
    try:from PIL import Image,ImageOps
    except ImportError as exc:raise USLError('Image inspection requires the optional Pillow package') from exc
    path=Path(path).expanduser().resolve()
    if not path.is_file():raise USLError('Image file not found')
    if path.stat().st_size>40_000_000:raise USLError('Input image exceeds 40 MB maximum')
    try:
        with Image.open(path) as im:
            if im.width*im.height>max_pixels:raise USLError('Image pixel budget exceeded')
            fmt=im.format
            im=ImageOps.exif_transpose(im)
            # Deterministic 256x256 grayscale projection; no ML model implied.
            small=im.convert('L');small.thumbnail((256,256))
            hist=small.histogram()
            total=sum(hist)
            avg=sum(i*v for i,v in enumerate(hist))/max(total,1)
            return {'format':fmt,'width':im.width,'height':im.height,'mode':im.mode,
                    'sampled_pixels':total,'mean_luminance_0_255':round(avg,3),
                    'histogram_16_bins':[sum(hist[i*16:(i+1)*16]) for i in range(16)],
                    'features':['image_decode','orientation_normalization','luminance_histogram'],
                    'object_detection':False,'scene_understanding':False,'emovision_android_connected':False}
    except (OSError,ValueError) as exc:raise USLError('Could not decode image: '+str(exc)) from exc
