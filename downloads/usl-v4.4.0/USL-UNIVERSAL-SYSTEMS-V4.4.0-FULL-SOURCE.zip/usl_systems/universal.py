"""Universal USL semantic routing: one typed IR, evidence-backed backends.

The portable IR kernel works independently of target syntax-family labels.
Native lowering is admitted only when its actual observed result matches the
bounded USL reference. This is not a proof of full-language equivalence.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import json
import os
import shutil
import tempfile
import statistics
import zipfile

from .catalog import load_catalog
from .compiler import TARGETS, target_name, transpile_ir
from .ir import lower, restore
from .language import Interpreter, USLError
from .native import tool_available, verify

SCHEMA = 'usl.universal.route.v1'
MAX_SOURCE_BYTES = 100_000
NATIVE_CANDIDATES = ('python', 'javascript', 'ruby', 'php', 'go', 'java', 'cpp', 'c')

class UniversalError(USLError):
    pass


def _catalog_target(target: str):
    if not isinstance(target, str):
        raise UniversalError('Target must be a catalogued language identifier')
    k = target.lower().strip()
    if not k:
        raise UniversalError('Empty language identifier')
    matching = [r for r in load_catalog() if k == r['id'] or k in [a.lower() for a in r.get('aliases', [])]]
    if not matching:
        raise UniversalError('Unknown syntax-family or language target: '+k)
    return matching[0]


def _fingerprint(source: str):
    if not isinstance(source, str) or len(source.encode('utf8')) > MAX_SOURCE_BYTES:
        raise UniversalError('Source is invalid or exceeds 100 KB')
    return sha256(source.encode('utf8')).hexdigest()


def portable_execute(ir: dict):
    """Hash-checked IR is restored through the safe parser; no Python exec/eval."""
    import ast
    tree = restore(ir)
    return Interpreter(max_ops=100_000, timeout=4, max_output=50_000).run(ast.unparse(tree)).output


def route(source: str, target: str, *, allow_native: bool = False, optimize: bool = False,
          candidates: tuple[str, ...] | None = None):
    """Route requested catalog target through verified native or portable semantic VM.

    - 'direct_native' is offered only after the *specific provided source* passes
      actual native output equivalence, not general target-language certification.
    - A catalog target with no backend uses host-VM preservation; that does NOT
      generate executable foreign-language source.
    - Optional collapse probes use observed wall clock (compilation included),
      not claims of automatic speedup or all-input equivalence.
    """
    row = _catalog_target(target)
    digest = _fingerprint(source)
    ir = lower(source)
    expected = portable_execute(ir)
    backend = target_name(row['id'])
    result = {
        'schema': SCHEMA, 'catalog_id': row['id'], 'catalog_name': row['name'],
        'source_sha256': digest, 'ir_sha256': ir['ir_sha256'],
        'ir': ir, 'reference_stdout_sha256': sha256(expected.encode('utf8')).hexdigest(),
        'reference_output': expected,
        'mode': 'portable_semantic_vm', 'chosen_backend': 'usl_interpreter',
        'native_verified_for_this_program': False,
        'full_target_language_semantics_verified': False,
        'native_generated': None, 'attempts': [],
        'limitations': ['Portable VM requires Python 3',
                        'A catalog identifier is not an executable foreign-language compiler',
                        'Native output matching one program is not universal proof.'],
    }
    if not allow_native:
        return result
    if optimize:
        proposed = tuple(candidates) if candidates is not None else NATIVE_CANDIDATES
    else:
        proposed = (backend,)
    if not proposed or len(proposed) > 16:
        raise UniversalError('Invalid number of native candidates')
    if any(t not in TARGETS for t in proposed):
        raise UniversalError('Unknown native emitter in candidates')
    if len(set(proposed)) != len(proposed):
        raise UniversalError('Duplicate candidate')

    def probe(t):
        if not tool_available(t):
            return {'backend': t, 'status': 'toolchain_missing', 'elapsed_ms': None}
        began = perf_counter()
        try:
            checked = verify(source, t, timeout=12)
            status = checked['status']
            record = {'backend': t, 'status': status,
                      'elapsed_ms': round((perf_counter()-began)*1000, 4),
                      'native_exit_code': checked.get('native', {}).get('returncode'),
                      'native_stdout_sha256': sha256(checked.get('native', {}).get('stdout', '').replace('\r\n', '\n').encode('utf8')).hexdigest() if 'native' in checked else None,
                      'observed_stdout': checked.get('native', {}).get('stdout', '')[:800],
                      'diagnostic': str(checked.get('error') or checked.get('native', {}).get('stderr') or checked.get('build', {}).get('stderr') or '')[:800]}
            return record
        except (USLError, OSError, ValueError) as e:
            return {'backend': t, 'status': 'probe_error', 'elapsed_ms': round((perf_counter()-began)*1000, 4),
                    'diagnostic': str(e)[:800]}

    # Independent compile qualifications can use concurrent threads, each with
    # its own temp workspace and process. Bounded by the input list and 4 threads.
    with ThreadPoolExecutor(max_workers=min(4,len(proposed))) as pool:
        outcomes = {f: t for t in proposed for f in [pool.submit(probe,t)]}
        for future in as_completed(outcomes):
            result['attempts'].append(future.result())
    result['attempts'].sort(key=lambda x: proposed.index(x['backend']))
    qualified = [r for r in result['attempts'] if r['status'] == 'passed']
    if qualified:
        best = min(qualified, key=lambda r:(r['elapsed_ms'], proposed.index(r['backend']))) if optimize else qualified[0]
        generated = transpile_ir(ir,best['backend'])
        result.update({'mode': 'direct_native', 'chosen_backend': best['backend'],
                       'native_verified_for_this_program': True,
                       'native_generated': {'filename': generated.filename, 'code': generated.code},
                       'selection_note': 'Lowest observed compile+verify wall time among passing probes' if optimize else 'Requested backend matched the reference output'})
    else:
        result['selection_note'] = 'Retained exact portable semantic VM rather than emit unverified target code'
    return result


def collapse_success_all(source: str, *, targets: tuple[str,...] = NATIVE_CANDIDATES):
    """Try all named eligible emitters concurrently, preserve every measured result."""
    return route(source, 'python', allow_native=True, optimize=True, candidates=targets)


def export_portable(source: str, target: str, destination):
    """Self-contained standard-library Python runtime archive, independent of USL install.

    Foreign target name is catalog metadata; runtime remains the USL VM.
    """
    info = route(source, target)
    ir = info['ir']
    root = Path(__file__).resolve().parent
    files = {
        'payload.uslir.json': json.dumps(ir, sort_keys=True, ensure_ascii=False, indent=2)+'\n',
        'target.json': json.dumps({k: info[k] for k in ('schema','catalog_id','source_sha256',
            'ir_sha256','mode','full_target_language_semantics_verified')}, indent=2)+'\n',
        'usl_systems/__init__.py': '',
        'usl_systems/language.py': (root/'language.py').read_text(encoding='utf8'),
        'usl_systems/ir.py': (root/'ir.py').read_text(encoding='utf8'),
    }
    manifest = {name: sha256(contents.encode('utf8')).hexdigest() for name, contents in files.items()}
    launcher = '''"""Portable USL semantic runner: Python 3 standard library only."""\nfrom pathlib import Path\nimport hashlib,json,sys\nROOT=Path(__file__).resolve().parent\nmanifest=json.loads((ROOT/'PAYLOAD_MANIFEST.json').read_text(encoding='utf8'))\nfor name,digest in manifest.items():\n    if Path(name).is_absolute() or '..' in Path(name).parts: raise SystemExit('Unsafe manifest path')\n    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest: raise SystemExit('Payload integrity mismatch: '+name)\nfrom usl_systems.ir import restore\nfrom usl_systems.language import Interpreter\nimport ast\nir=json.loads((ROOT/'payload.uslir.json').read_text(encoding='utf8'))\ntree=restore(ir)\nsys.stdout.write(Interpreter(max_ops=100000,timeout=4).run(ast.unparse(tree)).output)\n'''
    files['RUN_PORTABLE.py'] = launcher
    files['RUN_PORTABLE.bat'] = '@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\nwhere py >nul 2>nul\r\nif errorlevel 1 goto run_python\r\npy -3 RUN_PORTABLE.py\r\nexit /b %errorlevel%\r\n:run_python\r\npython RUN_PORTABLE.py\r\nexit /b %errorlevel%\r\n'
    files['RUN_PORTABLE.sh'] = '#!/bin/sh\ncd "$(dirname "$0")" || exit 1\nexec python3 RUN_PORTABLE.py\n'
    manifest = {name: sha256(contents.encode('utf8')).hexdigest() for name, contents in files.items()}
    files['PAYLOAD_MANIFEST.json'] = json.dumps(manifest, indent=2, sort_keys=True)+'\n'
    dest = Path(destination)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, contents in sorted(files.items()):
            archive.writestr(name, contents)
    with zipfile.ZipFile(dest) as archive:
        if archive.testzip() is not None:
            raise UniversalError('ZIP integrity failed')
    return {'output':str(dest),'catalog_target': info['catalog_id'],
            'mode': info['mode'], 'reference_output_sha256': info['reference_stdout_sha256'],
            'files':len(files), 'bytes':dest.stat().st_size}
