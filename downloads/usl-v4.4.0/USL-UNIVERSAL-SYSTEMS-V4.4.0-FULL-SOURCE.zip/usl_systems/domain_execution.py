"""USL v4.0: executable language-family capabilities.

This is *not* a full compiler for these languages. Each reviewed operation
executes the actual installed parser, engine or tool and independently checks
its result. Only built-in, hash-pinned fixtures are allowed; this is not a
sandbox for arbitrary user-supplied code.
"""
from __future__ import annotations
import argparse, configparser, concurrent.futures, hashlib, importlib.util
import json, os, re, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCHEMA='usl.domain.execution.v1'
class DomainError(ValueError):pass

def _sha(data):return hashlib.sha256(data if isinstance(data,bytes) else data.encode('utf8')).hexdigest()

# All scripts/data are reviewed static fixtures, never interpolated shell strings.
# A scope is a concrete runnable operation with deterministic behavioral checks.
FIXTURES={
'graphviz':('diagram_compilation','digraph USL { plan -> qualify; qualify -> verified; }','svg','/usr/bin/dot'),
'markdown':('document_rendering','# USL Report\n\nVerified **language** routes.\n','html','pandoc'),
'restructuredtext':('document_rendering','USL API\n=======\n\nThis is a *verified* module.\n','html','pandoc'),
'postscript':('document_compilation','%!PS-Adobe-3.0\n/Helvetica findfont 12 scalefont setfont\n72 720 moveto (USL bridge proof 42) show\nshowpage\n','pdf','gs'),
'tex':('document_compilation','\\hsize=5in\nUSL bridge proof 42.\n\\bye\n','dvi','tex'),
'xslt':('xml_transformation','<?xml version="1.0"?><xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"><xsl:output omit-xml-declaration="yes"/><xsl:template match="/"><summary><xsl:value-of select="/root/task/@count"/></summary></xsl:template></xsl:stylesheet>','xml','xmlstarlet'),
'yaml':('structured_configuration','version: 4\nworkers:\n  - compiler\n  - verifier\n','json','python:yaml'),
'json5':('extended_json_parsing','{release: "v4", workers: ["compiler", "verifier",], /* reviewed */}','json','python:json5'),
'toml':('configuration_parsing','[execution]\nworkers=4\nmode="verified"\n','json','python:tomllib'),
'ini':('configuration_parsing','[execution]\nworkers=4\nmode=verified\n','json','python:configparser'),
'html':('dom_query','<html><body><a id="release" href="/usl/v4">verified</a></body></html>','json','python:lxml'),
'css':('css_declarations','body { color: navy; margin: 0; }','json','python:tinycss2'),
'xml':('xpath_query','<root><task status="qualified"/></root>','txt','xmlstarlet'),
'json':('schema_validated_data','{"engine":"USL","workers":4}','json','python:jsonschema'),
'yaml+jinja':('template_then_parse','execution:\n  workers: {{ workers }}\n  mode: verified\n','json','python:jinja2'),
}
# Distinct catalog identifiers and tasks, not claims of fully qualified specifications.
EXPECTED={
'graphviz':'<svg', 'markdown':'<strong>language</strong>',
'restructuredtext':'<em>verified</em>', 'postscript':'%PDF-', 'tex':'DVI',
'xslt':'<summary>17</summary>', 'yaml':'"version":4',
'json5':'"release":"v4"', 'toml':'"workers":4', 'ini':'"mode":"verified"',
'html':'"href":"/usl/v4"', 'css':'"color":"navy"',
'xml':'qualified', 'json':'"engine":"USL"', 'yaml+jinja':'"workers":5',
}
# Source variants deliberately invalid under the corresponding engine where applicable.
INVALID={
'graphviz':'digraph { a ->',
'postscript':'%!PS\nnotAnOperator\n',
'tex':'\\unrecognizedUSLControlSequence\n\\bye\n',
'xslt':'<xsl:stylesheet>INVALID',
'yaml':'!!python/object/apply:os.system ["echo unsafe"]',
'json5':'{release: ,}',
'toml':'workers=1\nworkers=2',
'ini':'[execution]\nworkers=1\nworkers=2',
'html':'<',
'css':'body { color: ; }',
'xml':'<root><task></root>',
'json':'{"engine":',
'yaml+jinja':'{{ unknown() }}',
}

def discovered():
    from .catalog import load_catalog
    ids={row['id'] for row in load_catalog()}
    if not set(FIXTURES)<=ids:raise DomainError('Fixture ID not in 606 catalog')
    if len(FIXTURES)!=len(set(FIXTURES)):raise DomainError('Duplicate catalog entry')
    out={}
    for lang,(scope,source,kind,provider) in FIXTURES.items():
        available=bool(importlib.util.find_spec(provider.split(':',1)[1])) if provider.startswith('python:') else bool(shutil.which(Path(provider).name))
        out[lang]={'catalog_id':lang,'capability_scope':scope,'provider':provider,'installed':available,
                   'source_sha256':_sha(source),'whole_specification_complete':False,'declared_output_kind':kind}
    return out

def _subprocess(argv,cwd,timeout):
    kwargs={'cwd':cwd,'stdin':subprocess.DEVNULL,'stdout':subprocess.PIPE,'stderr':subprocess.PIPE}
    if os.name=='nt':kwargs['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    else:kwargs['start_new_session']=True
    p=subprocess.Popen(argv,**kwargs)
    try: stdout,stderr=p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name=='nt':subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=3)
        else:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        p.communicate()
        raise DomainError('Engine timeout')
    if len(stdout)>2_000_000 or len(stderr)>200_000:raise DomainError('Engine output limit exceeded')
    return p.returncode,stdout,stderr

def _engine(lang,source,folder,timeout):
    import io
    name=Path(folder)/'source.txt';name.write_text(source,encoding='utf8')
    if lang=='graphviz':
        status,out,err=_subprocess([shutil.which('dot'),'-Tsvg',str(name)],folder,timeout)
        return status,out,err
    if lang in ('markdown','restructuredtext'):
        status,out,err=_subprocess([shutil.which('pandoc'),'-f','markdown' if lang=='markdown' else 'rst','-t','html',str(name)],folder,timeout)
        return status,out,err
    if lang=='postscript':
        dest=Path(folder)/'result.pdf'
        status,out,err=_subprocess([shutil.which('gs'),'-q','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=pdfwrite','-sOutputFile='+str(dest),str(name)],folder,timeout)
        return status,dest.read_bytes() if status==0 and dest.exists() else out,err
    if lang=='tex':
        src=Path(folder)/'source.tex';src.write_text(source,'utf8')
        status,out,err=_subprocess([shutil.which('tex'),'-interaction=nonstopmode','-halt-on-error',src.name],folder,timeout)
        dest=Path(folder)/'source.dvi'
        return status,(b'DVI'+dest.read_bytes() if status==0 and dest.exists() else out),err
    if lang=='xslt':
        data=Path(folder)/'data.xml';data.write_text('<root><task count="17"/></root>','utf8')
        return _subprocess([shutil.which('xmlstarlet'),'tr',str(name),str(data)],folder,timeout)
    if lang=='xml':
        return _subprocess([shutil.which('xmlstarlet'),'sel','-t','-v','/root/task/@status',str(name)],folder,timeout)
    try:
        if lang=='yaml':
            import yaml
            obj=yaml.safe_load(source)
        elif lang=='json5':
            import json5
            obj=json5.loads(source)
        elif lang=='toml':
            import tomllib
            obj=tomllib.loads(source)
        elif lang=='ini':
            parser=configparser.ConfigParser(strict=True);parser.read_string(source)
            obj={'workers':int(parser.get('execution','workers')),'mode':parser.get('execution','mode')}
        elif lang=='html':
            from lxml import html
            doc=html.fromstring(source)
            href=doc.xpath('//a[@id="release"]/@href')
            if not href:raise DomainError('DOM contract: no release link')
            obj={'href':href[0]}
        elif lang=='css':
            import tinycss2
            rules=tinycss2.parse_stylesheet(source,skip_comments=True,skip_whitespace=True)
            if len(rules)!=1 or rules[0].type!='qualified-rule':raise DomainError('CSS rule invalid')
            declarations=tinycss2.parse_declaration_list(rules[0].content,skip_comments=True,skip_whitespace=True)
            if any(d.type=='error' for d in declarations) or not declarations:raise DomainError('CSS declarations invalid')
            obj={d.name:tinycss2.serialize(d.value).strip() for d in declarations if d.type=='declaration'}
            if any(not v for v in obj.values()):raise DomainError('CSS empty value invalid')
        elif lang=='json':
            import jsonschema
            obj=json.loads(source)
            jsonschema.validate(obj,{'type':'object','required':['engine','workers'],
                'properties':{'engine':{'const':'USL'},'workers':{'type':'integer','minimum':1,'maximum':64}},'additionalProperties':False})
        elif lang=='yaml+jinja':
            import yaml,jinja2
            template=jinja2.Environment(undefined=jinja2.StrictUndefined,autoescape=False).from_string(source)
            obj=yaml.safe_load(template.render(workers=5))['execution']
        else:raise DomainError('Unimplemented reviewed capability')
        return 0,json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8'),b''
    except Exception as exc:
        return 1,b'',(type(exc).__name__+': '+str(exc)).encode('utf8')

def run(lang,*,approved=False,variant='valid',artifacts=None,timeout=15):
    if not approved:raise DomainError('Explicit approval required for executable language qualification')
    if lang not in FIXTURES:raise DomainError('No reviewed executable capability: '+str(lang))
    if variant not in ('valid','invalid'):raise DomainError('Unknown fixture variant')
    if not 0<timeout<=30:raise DomainError('Invalid timeout')
    scope,original,kind,provider=FIXTURES[lang]
    if not discovered()[lang]['installed']:raise DomainError('Actual language engine not installed: '+provider)
    if variant=='invalid' and lang not in INVALID:raise DomainError('No engine-specific invalid fixture')
    source=original if variant=='valid' else INVALID[lang]
    started=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='usl-qual-'+lang.replace('+','_')+'-') as temp:
        status,out,err=_engine(lang,source,temp,timeout)
    valid=(status==0 and EXPECTED[lang].encode() in out) if variant=='valid' else (status!=0)
    if not valid:raise DomainError('Execution qualification failed: '+lang+' exit='+str(status)+' stdout='+repr(out[-300:])+' stderr='+repr(err[-300:]))
    evidence={'language':lang,'catalog_id':lang,'verified':True,'engine':provider,'scope':scope,
       'variant':variant,'status':'qualified_executable_subset' if variant=='valid' else 'invalid_program_rejected',
       'whole_language_specification_complete':False,'source_sha256':_sha(source),
       'result_sha256':_sha(out),'observed_excerpt':out[:160].decode('utf8','replace'),
       'engine_exit_code':status,'elapsed_ms':round((time.perf_counter()-started)*1000,3),
       'checked_marker':EXPECTED[lang] if variant=='valid' else 'engine_nonzero_exit'}
    if artifacts is not None and variant=='valid':
        folder=Path(artifacts);folder.mkdir(parents=True,exist_ok=True)
        target=folder/(lang.replace('+','_')+'.'+kind)
        target.write_bytes(out)
        evidence['artifact']=target.name
    return evidence

def qualify(*,approved=False,workers=6,artifacts=None,include_negative=True):
    if not approved:raise DomainError('Approval required')
    if type(workers)!=int or not 1<=workers<=8:raise DomainError('Bounded workers 1..8')
    tasks=[(lang,'valid') for lang in sorted(FIXTURES) if discovered()[lang]['installed']]
    if include_negative:tasks.extend((lang,'invalid') for lang in sorted(INVALID) if discovered()[lang]['installed'])
    started=time.perf_counter(); results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers,thread_name_prefix='usl-partial-domain') as pool:
        future_to_job={pool.submit(run,k,approved=True,variant=v,artifacts=artifacts): (k,v) for k,v in tasks}
        for future in concurrent.futures.as_completed(future_to_job):
            lang,variant=future_to_job[future]
            try: results.append(future.result())
            except Exception as exc: results.append({'language':lang,'variant':variant,'verified':False,'error':str(exc)[:500]})
    results.sort(key=lambda r:(r['language'],r['variant']))
    passed={r['language'] for r in results if r['variant']=='valid' and r['verified']}
    return {'schema':SCHEMA,'catalog_count':606,'new_executable_subsets_qualified':len(passed),
            'qualified_catalog_ids':sorted(passed),'test_executions':len(tasks),
            'passed_executions':sum(bool(r['verified']) for r in results),'all_verified':all(r['verified'] for r in results),
            'native_specification_complete':0,'workers':workers,'elapsed_ms':round((time.perf_counter()-started)*1000,2),
            'discovered':discovered(),'results':results}

def main(argv=None):
    p=argparse.ArgumentParser(description='USL reviewed language-family executable conformance')
    p.add_argument('command',choices=['discover','qualify','execute'])
    p.add_argument('--lang');p.add_argument('--approved',action='store_true')
    p.add_argument('--workers',type=int,default=6);p.add_argument('--output');p.add_argument('--artifacts')
    p.add_argument('--variant',default='valid'); a=p.parse_args(argv)
    if a.command=='discover':result=discovered()
    elif a.command=='execute':result=run(a.lang,approved=a.approved,variant=a.variant,artifacts=a.artifacts)
    else:result=qualify(approved=a.approved,workers=a.workers,artifacts=a.artifacts)
    if a.output:
        Path(a.output).parent.mkdir(parents=True,exist_ok=True)
        Path(a.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf8')
    else:print(json.dumps(result,indent=2,ensure_ascii=False))
    if isinstance(result,dict) and result.get('all_verified') is False:return 1
    return 0
if __name__=='__main__':sys.exit(main())
