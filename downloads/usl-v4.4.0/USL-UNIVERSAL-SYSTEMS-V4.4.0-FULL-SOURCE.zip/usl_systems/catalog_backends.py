"""Versioned real-backend profiles for the dedicated full-catalog sweep.

Profiles qualify declared examples, not complete language specifications. A lexer
reference is recorded separately from an authoritative audited semantic standard.
"""
from __future__ import annotations
import importlib.metadata,json,os,shutil,signal,subprocess,sys,tempfile,time
from pathlib import Path
from .entity_memory import fingerprint
from .source_engines import runtime_file_hash

ROOT=Path(__file__).resolve().parents[1]
PROFILES={}
def add(ids,engine,mode='program',tool=None,distribution=None,host=None):
    for name in ids.split(','):
        PROFILES[name]={'engine':engine,'mode':mode,'tool':tool,'distribution':distribution,'host':host,
            'scope':'declared native-source subset; full specification unqualified'}

add('rust','rust',tool='rustc')
add('delphi','pascal',tool='fpc')
add('common-lisp','lisp',tool='sbcl')
add('scheme','scheme',tool='guile')
add('ocaml','ocaml',tool='ocaml')
add('erlang','erlang',tool='erl')
add('elixir','elixir',tool='elixir')
add('clojure','clojure',tool='clojure')
add('groovy','groovy',tool='groovy')
add('scala','scala',tool='scala')
add('csharp','csharp',tool='mcs')
add('bc','bc',tool='bc')
add('tcsh','tcsh',tool='tcsh')
add('fish','fish',tool='fish')
add('pike','pike',tool='pike')
add('splus','r',tool='Rscript')  # R branch of the S/R lexer family, not S-Plus implementation
add('prolog','prolog',tool='swipl')
add('d','d',tool='gdc')
add('ada','ada',tool='gnatmake')
add('fortranfixed','fortran_fixed',tool='gfortran')
add('verilog,systemverilog','verilog','simulation',tool='iverilog')
add('vhdl','vhdl','simulation',tool='ghdl')
add('fennel','fennel',tool='fennel')
add('asn1','asn1','schema_encode_decode',distribution='asn1tools')
add('nestedtext','nestedtext','format_parse',distribution='nestedtext')
add('terraform','hcl','configuration_parse',distribution='python-hcl2')
add('jsonnet','jsonnet','configuration_evaluate',distribution='jsonnet')
add('wast','wasm','program',distribution='wasmtime')
add('email,mime','email','protocol_parse')
add('http','http','protocol_parse')
add('urlencoded','urlencoded','format_decode')
add('debcontrol,debsources','deb822','configuration_parse',distribution='python-debian')
add('zone','dns','configuration_parse',distribution='dnspython')
add('yang','yang','schema_validate',distribution='pyang')
add('yara','yara','query_execute',distribution='yara-python')
add('abnf','abnf','grammar_parse',distribution='abnf')
add('ebnf','ebnf','grammar_parse',distribution='lark')
add('properties','properties','configuration_parse',tool='java')
add('erb,rhtml','erb','template_render',tool='ruby',host='html')
add('mako-312','mako','template_render',distribution='Mako',host='text')
add('css+mako-111','mako','template_render',distribution='Mako',host='css')
add('html+mako-220','mako','template_render',distribution='Mako',host='html')
add('xml+mako-585','mako','template_render',distribution='Mako',host='xml')
add('js+mako','mako','program',distribution='Mako',host='javascript')
add('css+genshitext','genshi_text','template_render',distribution='Genshi',host='css')
add('js+genshitext','genshi_text','program',distribution='Genshi',host='javascript')
add('ul4','ul4','template_render',distribution='ll-xist',host='text')
add('css+ul4','ul4','template_render',distribution='ll-xist',host='css')
add('html+ul4','ul4','template_render',distribution='ll-xist',host='html')
add('xml+ul4','ul4','template_render',distribution='ll-xist',host='xml')
add('js+ul4','ul4','program',distribution='ll-xist',host='javascript')
add('py+ul4','ul4','program',distribution='ll-xist',host='python')

def identity(language):
    profile=PROFILES[language]
    result={**profile,'available':True,'full_spec_qualified':False,'discovery_is_execution_evidence':False}
    if profile['tool']:
        binary=shutil.which(profile['tool'])
        if not binary:result['available']=False;return result
        result['launcher']=str(Path(binary).resolve());result['launcher_sha256']=runtime_file_hash(binary)
        # Local launchers are retained with their pinned Debian package manifests.
    if profile['distribution']:
        try:
            d=importlib.metadata.distribution(profile['distribution'])
            result['provider_version']=d.version
            result['distribution_record_sha256']=fingerprint(d.read_text('RECORD') or '')
        except importlib.metadata.PackageNotFoundError:result['available']=False
    result['python_version']=sys.version.split()[0]
    return result

def run(language,source,context=None,*,approved=False,timeout=20):
    if approved is not True:raise ValueError('explicit catalog native execution approval required')
    if language not in PROFILES or not isinstance(source,str) or not 1<=len(source.encode())<=32768:
        raise ValueError('reviewed exact profile and bounded source required')
    context={} if context is None else context
    if not isinstance(context,dict) or len(json.dumps(context,allow_nan=False))>16384 or not 0<timeout<=45:
        raise ValueError('bounded finite context and timeout required')
    provider=identity(language)
    if not provider['available']:raise ValueError('real upstream provider unavailable: '+language)
    req={'language':language,'profile':PROFILES[language],'source':source,'context':context}
    begin=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='usl-catalog-') as folder,tempfile.TemporaryFile() as out,tempfile.TemporaryFile() as err:
        proc=subprocess.Popen([sys.executable,str(ROOT/'usl_systems/catalog_worker.py')],cwd=folder,
            stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=os.name!='nt')
        try:proc.communicate(json.dumps(req).encode(),timeout=timeout)
        except subprocess.TimeoutExpired:
            if os.name!='nt':
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            else:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=5)
            proc.wait(timeout=5);raise ValueError('catalog backend deadline exceeded')
        out.seek(0);err.seek(0);stdout=out.read(524289);stderr=err.read(524289)
    if max(len(stdout),len(stderr))>524288:raise ValueError('catalog worker output bound exceeded')
    if proc.returncode:raise ValueError('actual backend rejection: '+stderr.decode(errors='replace')[-4000:])
    value=json.loads(stdout)
    return {'catalog_id':language,'value':value['value'],'backend_evidence':value.get('evidence',{}),
        'source_sha256':fingerprint(source),'context_sha256':fingerprint(context),'provider':provider,
        'actual_backend_executed':True,'full_spec_qualified':False,'elapsed_ms':(time.monotonic()-begin)*1000}
