"""Evidence-gated adaptive selection of serial vs factored USL computation.

Unlike a slogan about universal speedups, this compares measured end-to-end
operations on the SAME input and selects the least-cost VERIFIED candidate.
"""
import statistics,time
from .fractal import FactoredFractal,_work,OPERATORS,FractalError

class AdaptiveExecutor:
    def __init__(self,workers=4,leaf_size=256,max_depth=6):
        self.scheduler=FactoredFractal(workers=workers,leaf_size=leaf_size,max_depth=max_depth)

    def choose(self,values,operator='sum_squares',dimensions=('execution','cache','verification'),repeats=3,include_process=False):
        if operator not in OPERATORS:raise FractalError('Unsupported operator')
        if type(repeats)!=int or not 1<=repeats<=9:raise FractalError('repeats 1..9')
        # Copy+schema validation through the same verified scheduler route.
        baseline=self.scheduler.execute(values,operator,dimensions,mode='sync',reuse=False)
        reference=baseline['reference'];timings={};metadata={}
        strategies=[('serial','serial',False),('factored_sync','sync',True),('factored_async','async',True)]
        if include_process:
            strategies.append(('factored_process','process',True))
        for name,mode,reuse in strategies:
            samples=[];last=None
            for _ in range(repeats):
                begin=time.perf_counter()
                if mode=='serial':last=_work(operator,values)
                else:last=self.scheduler.execute(values,operator,dimensions,mode=mode,reuse=reuse)
                elapsed=(time.perf_counter()-begin)*1000
                measured=last if mode=='serial' else last['result']
                if measured!=reference:raise FractalError('Adaptive plan violated exact reference')
                samples.append(elapsed)
            timings[name]=round(statistics.median(samples),5)
            if isinstance(last,dict):
                metadata[name]={'logical_partials':last['N_logical_partials'],
                                'computed_partials':last['physically_computed_partials'],
                                'reused_partials':last['reused_identical_partials']}
        winner=min(timings,key=timings.get)
        # Measurement includes validation/serialization costs for factored paths.
        return {'selected':winner,'operator':operator,'value':reference,'verified_exact':True,
                'median_ms':timings,'trials_per_strategy':repeats,
                'observed_speedup_vs_serial':(timings['serial']/timings[winner] if timings[winner]>0 else 1),
                'candidate_work':metadata,
                'note':'Autoselection measured in this process and for these inputs only. No cross-host speedup guaranteed.'}
