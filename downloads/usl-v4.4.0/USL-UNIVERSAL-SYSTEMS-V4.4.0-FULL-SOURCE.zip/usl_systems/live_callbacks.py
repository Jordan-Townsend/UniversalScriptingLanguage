"""Live, typed Python guest -> USL callable -> Python guest bridge protocol.

The guest continues in its original process after a framed USL callback reply.
Bounded calls/deadline, explicit approval in interop.run_nested, verified types,
process-group cleanup, and no arbitrary guest code evaluation in the parent.
Not a security sandbox: guest code can still access its OS user privileges.
"""
from __future__ import annotations
import json,os,queue,signal,subprocess,sys,tempfile,threading,time
from pathlib import Path

WORKER=r'''import contextlib,importlib.util,json,sys
from pathlib import Path
WIRE=sys.stdout
req=json.loads(sys.stdin.readline())
path=Path(__file__).parent/'guest.py'
spec=importlib.util.spec_from_file_location('usl_callback_guest',path)
m=importlib.util.module_from_spec(spec)
def bridge(*args):
 WIRE.write(json.dumps({'kind':'call','name':req['callback'],'args':args},allow_nan=False)+'\n'); WIRE.flush()
 reply=json.loads(sys.stdin.readline())
 if reply.get('kind')!='return':raise RuntimeError('USL callback denied: '+str(reply.get('error','protocol error')))
 return reply['value']
with contextlib.redirect_stdout(sys.stderr):
 spec.loader.exec_module(m)
 if hasattr(m,req['callback']):raise ValueError('Guest cannot overwrite declared callback')
 setattr(m,req['callback'],bridge)
 fn=getattr(m,req['export'])
 result=fn(*req['args'])
WIRE.write(json.dumps({'kind':'result','value':result},allow_nan=False)+'\n'); WIRE.flush()
'''

JS_CALLBACK_WORKER = r'''import readline from 'node:readline';
const rl=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
let request=null, serial=0;
const pending=new Map();
function emit(obj){process.stdout.write(JSON.stringify(obj)+'\n');}
async function run(){
 try {
  const guest=await import('./guest.mjs');
  if(typeof guest[request.export]!=='function')throw Error('Missing declared JS export');
  const value=await guest[request.export](...request.args);
  emit({kind:'result',value});
  rl.close();
 } catch(error){console.error(error.stack||error); process.exitCode=5;rl.close();}
}
rl.on('line',line=>{
 try{
  const obj=JSON.parse(line);
  if(!request){
    request=obj;
    if(typeof request.callback!=='string')throw Error('callback must be declared');
    if(Object.hasOwn(globalThis,request.callback))throw Error('Callback reserved global already exists');
    globalThis[request.callback]=(...args)=>new Promise((resolve,reject)=>{
      const id=++serial;pending.set(id,{resolve,reject});
      emit({kind:'call',name:request.callback,id,args});
    });
    void run();
  } else {
    const entry=pending.get(obj.id);
    if(!entry)throw Error('Unmatched USL callback response');
    pending.delete(obj.id);
    if(obj.kind==='return')entry.resolve(obj.value);
    else entry.reject(Error('USL callback denied: '+String(obj.error||'unknown')));
  }
 } catch(error){console.error(error.stack||error);process.exitCode=5;rl.close();}
});
'''

def validate_callback(cb):
    from .interop import BridgeError,IDENT,MAX_SOURCE
    if not isinstance(cb,dict) or set(cb)-{'name','source','export','params','returns','max_calls','timeout_seconds'}:
        raise BridgeError('Invalid callback contract fields')
    for k in ('name','export'):
        if not isinstance(cb.get(k),str) or not IDENT.fullmatch(cb[k]):
            raise BridgeError('Invalid callback '+k)
    if not isinstance(cb.get('source'),str) or len(cb['source'].encode('utf8'))>MAX_SOURCE:
        raise BridgeError('Invalid callback USL source')
    params=cb.get('params')
    if not isinstance(params,list) or len(params)>8 or any(t not in ('i64','bool','text') for t in params):
        raise BridgeError('Unsupported callback parameter signature')
    if cb.get('returns') not in ('i64','bool','text'):
        raise BridgeError('Unsupported callback return ABI')
    if type(cb.get('max_calls',2)) is not int or not 1<=cb.get('max_calls',2)<=8:
        raise BridgeError('callback max_calls must be 1..8')
    if type(cb.get('timeout_seconds',5)) not in (int,float) or not .2<=cb.get('timeout_seconds',5)<=10:
        raise BridgeError('callback timeout_seconds must be 0.2..10')
    return cb

def _kill_group(proc):
    if proc.poll() is not None:return
    if os.name=='nt':
        try: subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=3)
        except Exception:proc.kill()
    else:
        try:os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
    try:proc.wait(timeout=3)
    except subprocess.TimeoutExpired:proc.kill()

def execute_live(node,args,workspace):
    from .interop import BridgeError,_execute,validate_value,digest,_json
    cb=validate_callback(node['callback'])
    started=time.perf_counter();calls=[];stdout_events=queue.Queue();err_chunks=[]
    with tempfile.TemporaryDirectory(prefix='usl-callback-',dir=workspace) as td:
        root=Path(td)
        lang=node['language']
        if lang=='javascript':
            from shutil import which
            if not which('node'):raise BridgeError('Node.js not installed')
            (root/'guest.mjs').write_text(node['source'],encoding='utf8')
            (root/'worker.mjs').write_text(JS_CALLBACK_WORKER,encoding='utf8')
            command=[which('node'),'worker.mjs']
        else:
            (root/'guest.py').write_text(node['source'],encoding='utf8')
            (root/'worker.py').write_text(WORKER,encoding='utf8')
            command=[sys.executable,'-I','-S','worker.py']
        options={'cwd':root,'stdin':subprocess.PIPE,'stdout':subprocess.PIPE,'stderr':subprocess.PIPE,
                 'text':True,'encoding':'utf8','bufsize':1}
        if os.name=='nt':options['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
        else:options['start_new_session']=True
        proc=subprocess.Popen(command,**options)
        def stdout_reader():
            try:
                for line in proc.stdout: stdout_events.put(('line',line))
            finally:stdout_events.put(('eof',None))
        def stderr_reader():
            for line in proc.stderr:
                if sum(map(len,err_chunks))<4000:err_chunks.append(line[:1000])
        threading.Thread(target=stdout_reader,daemon=True).start()
        threading.Thread(target=stderr_reader,daemon=True).start()
        deadline=time.monotonic()+cb.get('timeout_seconds',5)
        value=None;received=False
        try:
            proc.stdin.write(_json({'export':node['export'],'args':args,'callback':cb['name']})+'\n')
            proc.stdin.flush()
            while not received:
                remain=deadline-time.monotonic()
                if remain<=0:raise BridgeError('Live callback timed out')
                try:kind,line=stdout_events.get(timeout=remain)
                except queue.Empty as exc:raise BridgeError('Live callback timed out') from exc
                if kind=='eof':raise BridgeError('Guest closed callback pipe before result: '+''.join(err_chunks)[-300:])
                try:frame=json.loads(line)
                except ValueError as exc:raise BridgeError('Invalid guest callback JSON frame') from exc
                if not isinstance(frame,dict) or frame.get('kind') not in ('call','result'):
                    raise BridgeError('Unexpected guest callback frame')
                if frame['kind']=='result':
                    value=validate_value(frame.get('value'),node['returns'])
                    received=True;break
                if frame.get('name')!=cb['name']:raise BridgeError('Undeclared guest callback')
                raw=frame.get('args')
                if not isinstance(raw,list) or len(raw)!=len(cb['params']):
                    raise BridgeError('Callback ABI argument count mismatch')
                callargs=[validate_value(a,t) for a,t in zip(raw,cb['params'])]
                if len(calls)>=cb.get('max_calls',2):raise BridgeError('Callback maximum invocation count exceeded')
                uslnode={'language':'usl','source':cb['source'],'export':cb['export'],
                         'params':cb['params'],'returns':cb['returns']}
                answer,evidence=_execute(uslnode,callargs,root)
                validate_value(answer,cb['returns'])
                calls.append({'arguments_sha256':digest(_json(callargs)),
                    'result_sha256':digest(_json(answer)), 'USL_operations':evidence.get('operations'),
                    'source_sha256':digest(cb['source'])})
                proc.stdin.write(_json({'kind':'return','id':frame.get('id'),'value':answer})+'\n');proc.stdin.flush()
            remain=max(0.1,deadline-time.monotonic())
            try:code=proc.wait(timeout=remain)
            except subprocess.TimeoutExpired as exc:raise BridgeError('Guest still running after callback result') from exc
            if code!=0:raise BridgeError('Callback guest exited nonzero: '+''.join(err_chunks)[-300:])
        finally:
            _kill_group(proc)
            for pipe in (proc.stdin,proc.stdout,proc.stderr):
                try:pipe.close()
                except Exception:pass
        return value,{'mode':'live_'+lang+'_usl_callback', 'exit_code':proc.returncode,
            'callback_count':len(calls),'callbacks':calls,'source_sha256':digest(node['source']),
            'callback_source_sha256':digest(cb['source']),
            'duration_ms':round((time.perf_counter()-started)*1000,3),'stderr':''.join(err_chunks)[-300:]}
