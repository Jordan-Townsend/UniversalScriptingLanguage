"""Typed real observations and explicit sensor readiness; no invented senses."""
from __future__ import annotations
import json, math, os, platform, shutil, time, wave
from pathlib import Path

SENSES = {
    'vision': {'unit': 'feature', 'hardware': 'camera or supplied image', 'live_qualified': False},
    'hearing': {'unit': 'feature', 'hardware': 'microphone or supplied PCM WAV', 'live_qualified': False},
    'touch': {'unit': 'newton', 'hardware': 'calibrated force/tactile sensor', 'live_qualified': False},
    'proprioception': {'unit': 'radian', 'hardware': 'joint encoders and body model', 'live_qualified': False},
    'balance': {'unit': 'metre_per_second_squared', 'hardware': 'calibrated IMU', 'live_qualified': False},
    'temperature': {'unit': 'celsius', 'hardware': 'temperature sensor', 'live_qualified': False},
    'smell': {'unit': 'calibrated_sensor_response', 'hardware': 'chemical sensor array', 'live_qualified': False},
    'taste': {'unit': 'calibrated_sensor_response', 'hardware': 'electrochemical sensor array', 'live_qualified': False},
    'internal': {'unit': 'feature', 'hardware': 'machine resource/energy telemetry', 'live_qualified': False},
}

def validate_packet(packet):
    if not isinstance(packet, dict) or packet.get('sense') not in SENSES:
        raise ValueError('unknown sense')
    if not isinstance(packet.get('provider'), str) or not 1 <= len(packet['provider']) <= 128:
        raise ValueError('actual provider required')
    if packet.get('mode') not in ('live', 'recorded', 'synthetic_test'):
        raise ValueError('observation mode must be explicit')
    for key in ('timestamp', 'confidence'):
        if type(packet.get(key)) not in (int, float) or not math.isfinite(packet[key]):
            raise ValueError('finite ' + key + ' required')
    if packet['timestamp'] < 0 or not 0 <= packet['confidence'] <= 1:
        raise ValueError('timestamp/confidence range')
    if packet.get('unit') != SENSES[packet['sense']]['unit']:
        raise ValueError('unit does not match sense contract')
    features = packet.get('features')
    if not isinstance(features, list) or not 1 <= len(features) <= 4096 or any(type(x) not in (int, float) or not math.isfinite(x) for x in features):
        raise ValueError('1..4096 finite numeric features required')
    if not isinstance(packet.get('evidence'), dict) or not packet['evidence'].get('source'):
        raise ValueError('observation provenance required')
    if len(json.dumps(packet, allow_nan=False)) > 64_000:
        raise ValueError('observation packet bound exceeded')
    return packet

def packet(sense, features, provider, evidence, *, mode='recorded', confidence=1.0, timestamp=None):
    return validate_packet({'sense': sense, 'features': features, 'unit': SENSES[sense]['unit'],
        'provider': provider, 'evidence': evidence, 'mode': mode, 'confidence': confidence,
        'timestamp': time.time() if timestamp is None else timestamp})

def image_observation(path):
    from .vision import inspect_image
    from .source_engines import runtime_file_hash
    result = inspect_image(path)
    total = max(1, sum(result['histogram_16_bins']))
    features = [x / total for x in result['histogram_16_bins']] + [result['mean_luminance_0_255'] / 255]
    return packet('vision', features, 'Pillow.luminance', {'source': str(Path(path).resolve()),
        'sha256': runtime_file_hash(path), 'object_detection': False, 'scene_understanding': False})

def audio_observation(path):
    import array, sys
    from .source_engines import runtime_file_hash
    if Path(path).stat().st_size > 16_000_000:
        raise ValueError('WAV exceeds 16MB')
    with wave.open(str(path), 'rb') as wav:
        channels, width, rate, frames = wav.getnchannels(), wav.getsampwidth(), wav.getframerate(), wav.getnframes()
        if channels != 1 or width != 2 or not 8000 <= rate <= 96000 or not 1 <= frames <= rate * 30:
            raise ValueError('requires mono 16-bit PCM, 8..96kHz, <=30 seconds')
        samples = array.array('h', wav.readframes(frames))
    if sys.byteorder != 'little': samples.byteswap()
    rms = math.sqrt(sum((x / 32768) ** 2 for x in samples) / len(samples))
    peak = max(abs(x) for x in samples) / 32768
    crossings = sum((a < 0) != (b < 0) for a, b in zip(samples, samples[1:])) / max(1, len(samples)-1)
    return packet('hearing', [rms, peak, crossings, frames / rate], 'stdlib.PCM-WAV',
        {'source': str(Path(path).resolve()), 'sha256': runtime_file_hash(path), 'speech_recognition': False})

def telemetry():
    from .resources import discover
    r = discover()
    return packet('internal', [float(r.get('cpu_logical') or 0), float(r.get('memory_bytes') or 0)],
        'USL.resources', {'source': 'local resource inventory', 'units': ['cpu_count', 'installed_memory_bytes']}, mode='live')

def synchronize(packets, max_skew=0.25):
    if not isinstance(packets, list) or not 1 <= len(packets) <= 32 or type(max_skew) not in (int,float) or not 0 <= max_skew <= 30:
        raise ValueError('bounded packets/skew required')
    for p in packets: validate_packet(p)
    times = [p['timestamp'] for p in packets]
    if max(times)-min(times) > max_skew:
        raise ValueError('observations exceed synchronization skew')
    if len({p['sense'] for p in packets}) != len(packets):
        raise ValueError('one observation per sense per fusion frame')
    return {'timestamp': max(times), 'observed': {p['sense']: p for p in packets},
        'missing': sorted(set(SENSES)-{p['sense'] for p in packets}),
        'semantic_understanding_qualified': False}

def readiness():
    camera = bool(list(Path('/dev').glob('video*'))) if os.name != 'nt' else None
    return {'senses': SENSES, 'camera_device_detected': camera,
        'microphone_device_detected': Path('/dev/snd').exists() if os.name != 'nt' else None,
        'ocr_binary_available': bool(shutil.which('tesseract')), 'ffmpeg_available': bool(shutil.which('ffmpeg')),
        'human_sensory_equivalence': False, 'device_detection_is_execution_evidence': False}
