"""Trainable multi-depth feature stacking; optional PyTorch dependency.

This combines established feature-pyramid, gating and residual ideas. It is an
experimental architecture, not a claim of universal superiority or novelty.
"""
from __future__ import annotations
import copy
import torch
from torch import nn
from torch.nn import functional as F

class ConvBaseline(nn.Module):
    def __init__(self, channels=1, classes=10, widths=(16, 24, 32)):
        super().__init__()
        if not 1 <= channels <= 8 or not 2 <= classes <= 1000:
            raise ValueError('channels 1..8 and classes 2..1000')
        if len(widths) != 3 or any(type(w) is not int or not 4 <= w <= 256 for w in widths):
            raise ValueError('three widths in 4..256 required')
        self.config = {'channels': channels, 'classes': classes, 'widths': list(widths)}
        self.stages = nn.ModuleList()
        before = channels
        for i, width in enumerate(widths):
            self.stages.append(nn.Sequential(nn.Conv2d(before, width, 3, padding=1),
                nn.GELU(), nn.MaxPool2d(2) if i < 2 else nn.Identity()))
            before = width
        self.head = nn.Linear(widths[-1], classes)

    def feature_maps(self, image):
        if image.ndim != 4 or image.shape[1] != self.config['channels']:
            raise ValueError('expected BCHW tensor with configured channels')
        if min(image.shape[-2:]) < 4 or image.numel() > 4_000_000 or not torch.isfinite(image).all():
            raise ValueError('image dimensions/budget/finiteness invalid')
        maps = []
        for stage in self.stages:
            image = stage(image)
            maps.append(image)
        return maps

    def forward(self, image):
        return self.head(self.feature_maps(image)[-1].mean((-2, -1)))

class StackedFeatureFusionNet(ConvBaseline):
    """Project, spatially align, stack, gate and residually mix feature maps.

    Zero residual weights exactly recover the corresponding baseline for every
    admitted input. Training can learn a different function; quality is measured.
    """
    def __init__(self, channels=1, classes=10, widths=(16, 24, 32)):
        super().__init__(channels, classes, widths)
        width = widths[-1]
        self.projections = nn.ModuleList([nn.Conv2d(w, width, 1) for w in widths[:-1]] + [nn.Identity()])
        self.gates = nn.ModuleList([nn.Linear(width, 1) for _ in widths])
        self.mix = nn.Conv2d(width * len(widths), width, 1, bias=False)
        nn.init.zeros_(self.mix.weight)

    @classmethod
    def from_baseline(cls, baseline):
        result = cls(**baseline.config)
        result.stages = copy.deepcopy(baseline.stages)
        result.head = copy.deepcopy(baseline.head)
        return result

    def encode(self, image):
        maps = self.feature_maps(image)
        size = maps[-1].shape[-2:]
        aligned = [F.adaptive_avg_pool2d(project(x), size) for project, x in zip(self.projections, maps)]
        stack = torch.stack(aligned, dim=1)  # B, depth, channel, height, width
        weights = torch.softmax(torch.cat([gate(x.mean((-2, -1))) for gate, x in zip(self.gates, aligned)], dim=1), dim=1)
        weighted = stack * weights[:, :, None, None, None]
        fused = maps[-1] + self.mix(weighted.flatten(1, 2))
        return {'embedding': fused.mean((-2, -1)), 'stack': stack, 'gates': weights,
                'map_shapes': [list(x.shape) for x in maps]}

    def forward(self, image):
        return self.head(self.encode(image)['embedding'])

class CrossModalFusion(nn.Module):
    """Learned feature-vector fusion with explicit missing-modality masks.

    Encoders for each actual sensor are separate; this module does not invent
    absent senses. Training these fusion weights requires paired real data.
    """
    def __init__(self, dimensions, width=32):
        super().__init__()
        if not dimensions or len(dimensions) > 16 or not 4 <= width <= 256:
            raise ValueError('1..16 modalities and width 4..256 required')
        if any(not isinstance(k, str) or not k.isidentifier() or type(v) is not int or not 1 <= v <= 4096 for k, v in dimensions.items()):
            raise ValueError('invalid modality dimensions')
        self.names = sorted(dimensions)
        self.dimensions = dimensions
        self.projections = nn.ModuleDict({k: nn.Sequential(nn.Linear(v, width), nn.LayerNorm(width)) for k, v in dimensions.items()})
        self.score = nn.Linear(width, 1)

    def forward(self, features, present):
        if set(features) != set(self.names) or present.ndim != 2 or present.shape[1] != len(self.names) or present.dtype != torch.bool:
            raise ValueError('features and boolean availability mask required')
        if not present.any(dim=1).all():
            raise ValueError('at least one observed modality per sample required')
        for name in self.names:
            x = features[name]
            if x.ndim != 2 or x.shape != (present.shape[0], self.dimensions[name]) or not torch.isfinite(x).all():
                raise ValueError('invalid modality tensor: ' + name)
        stack = torch.stack([self.projections[k](features[k]) for k in self.names], dim=1)
        scores = self.score(stack).squeeze(-1).masked_fill(~present, -torch.inf)
        weights = scores.softmax(dim=1)
        return {'embedding': (stack * weights[:, :, None]).sum(dim=1), 'weights': weights}
