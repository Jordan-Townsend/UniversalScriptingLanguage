"""Explicit optional function signature contracts for linked USL projects.

Conservative local inference only: signatures are checked at known static call
sites and on direct return expressions. Unknown values are unproven, never
reported as verified. Does not rewrite source or promise type-safe native code.
"""
from __future__ import annotations
import ast,hashlib,json,re
from .module_linker import link_project,LinkError
from .language import parse
from .semantic_types import Type,UNKNOWN,NUMERIC

KINDS=frozenset(('int','float','str','bool','unknown'))
ARRAY_CONTRACT=re.compile(r'^(int|float|str|bool|unknown)\[(\d*(?:,\d+)*)\]$')

def contract_type(token):
    """Parse a restricted scalar or homogeneous 1-D array signature.

    int[] means unknown length; int[3] means exactly three elements.
    Never infer a concrete value or cast an actual input from metadata.
    """
    if not isinstance(token,str):raise LinkError('Signature type must be string')
    if token in KINDS:return Type(token)
    m=ARRAY_CONTRACT.fullmatch(token)
    if not m:raise LinkError('Unsupported signature type: '+token[:100])
    dimensions=m.group(2).split(',') if m.group(2) else []
    if len(dimensions)>3 or any(not x.isdigit() or len(x)>8 for x in dimensions):raise LinkError('Array shape exceeds dimensions or length budget')
    sizes=tuple(int(x) for x in dimensions)
    product=1
    for size in sizes:
        product*=size
        if product>100000:raise LinkError('Array shape exceeds element budget')
    return Type('array',m.group(1),sizes[0] if sizes else None,sizes or None)

def contract_match(expected,actual):
    """Return match, mismatch, or unproven; never guess unknowns."""
    if expected.kind=='unknown' or actual.kind=='unknown':return 'unproven'
    if expected.kind!=actual.kind:return 'mismatch'
    if expected.kind=='array':
        if expected.element!='unknown' and actual.element=='unknown':return 'unproven'
        if expected.element!='unknown' and expected.element!=actual.element:return 'mismatch'
        if expected.shape is not None:
            if actual.shape is None:
                if len(expected.shape)>1:return 'unproven'
                if actual.size is None:return 'unproven'
                if expected.size!=actual.size:return 'mismatch'
            else:
                if len(expected.shape)!=len(actual.shape):return 'mismatch'
                for e,a in zip(expected.shape,actual.shape):
                    if a is None:return 'unproven'
                    if e!=a:return 'mismatch'
        elif expected.size is not None:
            if actual.size is None:return 'unproven'
            if expected.size!=actual.size:return 'mismatch'
    return 'match'


def _infer(node,types,signatures):
    if isinstance(node,ast.Constant):
        return Type('bool' if type(node.value) is bool else 'int' if type(node.value) is int else 'float' if type(node.value) is float else 'str' if type(node.value) is str else 'unknown')
    if isinstance(node,ast.Name):return types.get(node.id,UNKNOWN)
    if isinstance(node,(ast.List,ast.Tuple)):
        seq=[_infer(x,types,signatures) for x in node.elts]
        if seq and all(x.kind=='array' for x in seq):
            elem=seq[0].element if all(x.element==seq[0].element for x in seq) else 'unknown'
            tails=[x.shape if x.shape is not None else ((x.size,) if x.size is not None else None) for x in seq]
            if tails[0] is not None and all(x==tails[0] for x in tails):
                return Type('array',elem,len(seq),(len(seq),*tails[0]))
            return Type('array',elem,len(seq),(len(seq),None))
        kind=seq[0].kind if seq and all(x.kind==seq[0].kind for x in seq) else 'unknown'
        return Type('array',kind,len(seq),(len(seq),))
    if isinstance(node,ast.Subscript):
        a=_infer(node.value,types,signatures)
        if a.kind!='array':return UNKNOWN
        if a.shape is not None and len(a.shape)>1:
            rest=a.shape[1:]
            return Type('array',a.element,rest[0],rest)
        return Type(a.element)
    if isinstance(node,ast.IfExp):
        left=_infer(node.body,types,signatures);right=_infer(node.orelse,types,signatures)
        return left if left==right else UNKNOWN
    if isinstance(node,ast.UnaryOp):return _infer(node.operand,types,signatures)
    if isinstance(node,ast.BinOp):
        l=_infer(node.left,types,signatures);r=_infer(node.right,types,signatures)
        if l.kind in NUMERIC and r.kind in NUMERIC:
            return Type('float' if 'float' in (l.kind,r.kind) or isinstance(node.op,ast.Div) else 'int')
        if isinstance(node.op,ast.Add) and l.kind==r.kind=='str':return Type('str')
        if isinstance(node.op,ast.Add) and l.kind==r.kind=='array':
            return Type('array',l.element if l.element==r.element else 'unknown',
                (l.size+r.size) if l.size is not None and r.size is not None else None,
                ((l.size+r.size,)+l.shape[1:]) if l.shape and r.shape and l.shape[1:]==r.shape[1:] and l.size is not None and r.size is not None else None)
        return UNKNOWN
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
        name=node.func.id
        if name in signatures:return contract_type(signatures[name]['returns'])
        if name in ('int','str','bool','float'):return Type(name)
        if name=='len':return Type('int')
    return UNKNOWN

def validate_contracts(project):
    linked=link_project(project)
    declared=project.get('contracts',{})
    if not isinstance(declared,dict) or len(declared)>256:raise LinkError('Contracts must be a limited mapping')
    funcs={x.name:x for x in parse(linked['source']).body if isinstance(x,ast.FunctionDef)}
    signatures={};contract_errors=[];verified=[];unproven=[];branch_joins=[];loop_invalidations=[]
    for qualified,sig in declared.items():
        if not isinstance(qualified,str) or '.' not in qualified:raise LinkError('Contract identifier must be module.function')
        module,name=qualified.split('.',1)
        if linked['exports'].get(name)!=module:raise LinkError('Contract has no matching exported function: '+qualified)
        if not isinstance(sig,dict) or set(sig)!=set(('params','returns')):
            raise LinkError('Contract must include params and returns only')
        params=sig['params'];ret=sig['returns']
        if not isinstance(params,list) or len(params)!=len(funcs[name].args.args) or not all(isinstance(x,str) for x in params) or not isinstance(ret,str):
            raise LinkError('Invalid signature types or arity: '+qualified)
        for token in [*params,ret]:contract_type(token)
        signatures[name]={'params':params,'returns':ret,'module':module}
    parsed=parse(linked['source'])
    def inspect(stmts,env,scope):
        for stmt in stmts:
            if isinstance(stmt,ast.Assign):
                walk_expr(stmt.value,env,scope)
                env[stmt.targets[0].id]=_infer(stmt.value,env,signatures)
            elif isinstance(stmt,ast.Expr):walk_expr(stmt.value,env,scope)
            elif isinstance(stmt,ast.Return) and stmt.value:
                walk_expr(stmt.value,env,scope)
                if scope in signatures:
                    found=_infer(stmt.value,env,signatures)
                    desired=contract_type(signatures[scope]['returns'])
                    entry={'function':scope,'line':stmt.lineno,'expected':signatures[scope]['returns'],
                           'actual':found.name(),'actual_length':found.size,'actual_shape':found.shape}
                    outcome=contract_match(desired,found)
                    if outcome=='unproven':unproven.append(entry)
                    elif outcome=='mismatch':contract_errors.append({'kind':'return_type_mismatch',**entry})
                    else:verified.append({'kind':'return','function':scope,'line':stmt.lineno})
            elif isinstance(stmt,ast.FunctionDef):
                sig=signatures.get(stmt.name)
                params={p.arg:contract_type(sig['params'][i]) if sig else UNKNOWN for i,p in enumerate(stmt.args.args)}
                inspect(stmt.body,params,stmt.name)
            elif isinstance(stmt,ast.If):
                walk_expr(stmt.test,env,scope)
                yes=dict(env);no=dict(env)
                inspect(stmt.body,yes,scope);inspect(stmt.orelse,no,scope)
                for name in set(yes)|set(no):
                    merged=yes[name] if name in yes and name in no and yes[name]==no[name] else UNKNOWN
                    env[name]=merged
                    branch_joins.append({'scope':scope,'line':stmt.lineno,'name':name,'kind':merged.kind})
            elif isinstance(stmt,(ast.While,ast.For)):
                if isinstance(stmt,ast.While):walk_expr(stmt.test,env,scope)
                else:walk_expr(stmt.iter,env,scope)
                body_env=dict(env)
                if isinstance(stmt,ast.For) and isinstance(stmt.target,ast.Name):body_env[stmt.target.id]=UNKNOWN
                inspect(stmt.body,body_env,scope)
                else_env=dict(env);inspect(stmt.orelse,else_env,scope)
                # Loop may execute zero times, an unknown number of times, or
                # mutate variables through augmented assignment. Never assume
                # its post-state equals the pre-loop state.
                for name in set(body_env)|set(else_env):
                    before=env.get(name,UNKNOWN)
                    after=body_env.get(name,UNKNOWN)
                    else_after=else_env.get(name,UNKNOWN)
                    merged=before if before==after==else_after else UNKNOWN
                    env[name]=merged
                    if merged==UNKNOWN and (after!=before or else_after!=before):
                        loop_invalidations.append({'scope':scope,'line':stmt.lineno,'name':name})
            elif isinstance(stmt,ast.AugAssign):
                walk_expr(stmt.value,env,scope);env[stmt.target.id]=UNKNOWN
    def walk_expr(root,env,scope):
        for node in ast.walk(root):
            if not isinstance(node,ast.Call) or not isinstance(node.func,ast.Name):continue
            name=node.func.id
            if name not in signatures:continue
            sig=signatures[name]
            if len(node.args)!=len(sig['params']):
                contract_errors.append({'kind':'argument_arity_mismatch','function':name,'scope':scope,'line':node.lineno,
                                       'expected':len(sig['params']),'actual':len(node.args)})
            for i,arg in enumerate(node.args[:len(sig['params'])]):
                actual=_infer(arg,env,signatures)
                expected=contract_type(sig['params'][i])
                record={'function':name,'scope':scope,'line':node.lineno,'argument':i,
                        'expected':sig['params'][i],'actual':actual.name(),'actual_length':actual.size,'actual_shape':actual.shape}
                outcome=contract_match(expected,actual)
                if outcome=='unproven':unproven.append(record)
                elif outcome=='mismatch':contract_errors.append({'kind':'argument_type_mismatch',**record})
                else:verified.append({'kind':'argument','function':name,'line':node.lineno,'argument':i})
    inspect(parsed.body,{},'main')
    digest=hashlib.sha256(json.dumps(declared,sort_keys=True).encode('utf8')).hexdigest()
    return {'schema':'usl.module.contracts.v1','linked_source_sha256':linked['output_sha256'],
            'contracts_sha256':digest,'declared_signatures':len(signatures),
            'locally_verified_checks':len(verified),'unproven_checks':unproven,
            'errors':contract_errors,'valid':not contract_errors,
            'full_type_soundness_proven':False,'native_runtime_enforces_contracts':False,
            'contracts_are_static_metadata_only':True,
            'supported_signature_types':['int','float','str','bool','unknown','T[]','T[N]','T[N,M]','T[N,M,K]'],
            'dataflow_branch_joins':branch_joins,'dataflow_loop_invalidations':loop_invalidations}
