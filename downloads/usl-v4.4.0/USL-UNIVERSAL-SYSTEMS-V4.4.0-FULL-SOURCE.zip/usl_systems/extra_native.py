"""Versioned typed subprocess adapters: actual TypeScript compiler and Kotlin/JVM.

Not a security sandbox. Toolchain invocations require caller approval and are
subprocesses; every build and run outcome is captured and checked separately.
"""
from __future__ import annotations
import base64,json,os,shutil,tempfile
from pathlib import Path
from .native_build_cache import BuildCache,verified_build
ABI='usl.bridge.abi.v1'
TS_TYPES={'i64','bool','text','i64[]'}
KT_TYPES={'i64':'Long','bool':'Boolean'}
TS_WORKER=r'''const fs=require('fs');const guest=require('./out/guest.js');
const req=JSON.parse(fs.readFileSync(0,'utf8'));
function check(t,v){
 if(t==='i64' && !(Number.isSafeInteger(v))) throw Error('i64 exceeds JS safe integer precision');
 if(t==='bool' && typeof v!=='boolean')throw Error('Expected bool');
 if(t==='text' && typeof v!=='string')throw Error('Expected text');
 if(t==='i64[]' && (!Array.isArray(v)||v.length>1024||!v.every(Number.isSafeInteger))) throw Error('Unsafe i64 array');
 function safe(x){if(typeof x==='number' && !Number.isSafeInteger(x))throw Error('Unsafe JS numeric value');if(Array.isArray(x))x.forEach(safe);else if(x!==null&&typeof x==='object')Object.values(x).forEach(safe);}
 safe(v);return v;
}
(async()=>{
 if(typeof guest[req.function]!=='function')throw Error('Missing declared TypeScript export');
 if(req.args.length!==req.params.length)throw Error('ABI signature mismatch');
 const args=req.args.map((v,i)=>check(req.params[i],v));
 const value=check(req.returns,await guest[req.function](...args));
 process.stdout.write(JSON.stringify({abi:'usl.bridge.abi.v1',value}));
})().catch(e=>{console.error(e.stack||e);process.exitCode=5;});
'''

def _kt_wrapper(export, params, ret):
    if not all(t in KT_TYPES for t in [*params,ret]):raise ValueError('Kotlin bridge only supports i64/bool ABI')
    lines=[]
    for i,t in enumerate(params):
        var=f'String(java.util.Base64.getDecoder().decode(args[{i}]),Charsets.UTF_8)'
        if t=='bool':
            lines.append(f'val tmp{i} = {var}; require(tmp{i}=="true"||tmp{i}=="false"); val v{i}:Boolean=tmp{i}.toBoolean()')
        else:lines.append(f'val v{i}:Long = {var}.toLong()')
    return '''fun main(args:Array<String>) {
    require(args.size==%d) {"Wrong Kotlin argument count"}
    %s
    val result: %s = %s(%s)
    print("{\\"abi\\":\\"usl.bridge.abi.v1\\",\\"value\\":"+result.toString()+"}")
}
'''%(len(params),'\n    '.join(lines),KT_TYPES[ret],export,','.join('v'+str(i) for i in range(len(params))))

def _ensure_safe_js_numbers(value):
    if type(value) is int and abs(value)>2**53-1:
        raise ValueError('TypeScript i64 exceeds safe JS integer precision')
    if isinstance(value,list):
        for item in value:_ensure_safe_js_numbers(item)
    if isinstance(value,dict):
        for item in value.values():_ensure_safe_js_numbers(item)

def execute_extra(lang,node,args,workspace):
    from .interop import _run_process,_json,digest
    params=node['params'];ret=node['returns'];src=node['source'];fn=node['export']
    if lang=='typescript':
        tsc=shutil.which('tsc');nodejs=shutil.which('node')
        if not tsc or not nodejs:raise ValueError('TypeScript/Node toolchain unavailable')
        from .abi_types import parse_spec
        for t in [*params,ret]:parse_spec(t)
        for a in args:_ensure_safe_js_numbers(a)
    elif lang=='kotlin':
        kotlin=shutil.which('kotlinc');java=shutil.which('java')
        if not kotlin or not java:raise ValueError('Kotlin/JVM toolchain unavailable')
        if any(t not in KT_TYPES for t in [*params,ret]):raise ValueError('Unsupported Kotlin ABI type')
    else:raise ValueError('Unsupported native backend '+lang)
    with tempfile.TemporaryDirectory(prefix='usl-'+lang+'-',dir=workspace) as td:
        root=Path(td)
        if lang=='typescript':
            (root/'guest.ts').write_text(src,encoding='utf8')
            (root/'worker.cjs').write_text(TS_WORKER,encoding='utf8')
            flags=['--target','ES2020','--module','commonjs','--strict','--pretty','false','--noEmitOnError','--outDir','out']
            output=root/'out'/'guest.js'
            build=verified_build(BuildCache(),lang,src,TS_WORKER,('tsc','node'),flags,output,
                lambda:_run_process([tsc,*flags,'guest.ts'],cwd=root,timeout=25))
            if build['exit_code']!=0:raise ValueError('TypeScript compile failed: '+(build['stdout']+build['stderr'])[:600])
            run=_run_process([nodejs,'worker.cjs'],cwd=root,
                input_text=_json({'function':fn,'args':args,'params':params,'returns':ret}),timeout=7)
            mode='typescript_tsc_compiled_node_subprocess'
        else:
            (root/'guest.kt').write_text(src,encoding='utf8')
            (root/'USLBridgeEntry.kt').write_text(_kt_wrapper(fn,params,ret),encoding='utf8')
            out=root/'guest.jar'
            generated=_kt_wrapper(fn,params,ret)
            build=verified_build(BuildCache(),lang,src,generated,('kotlinc','java'),('-include-runtime',),out,
                lambda:_run_process([kotlin,'guest.kt','USLBridgeEntry.kt','-include-runtime','-d',str(out)],cwd=root,timeout=90))
            if build['exit_code']!=0:raise ValueError('Kotlin compile failed: '+(build['stdout']+build['stderr'])[:600])
            tokens=[]
            for a,t in zip(args,params):
                raw=('true' if a else 'false') if t=='bool' else str(a)
                tokens.append(base64.b64encode(raw.encode('utf8')).decode('ascii'))
            run=_run_process([java,'-jar',str(out),*tokens],cwd=root,timeout=9)
            mode='kotlin_compiled_jvm_subprocess'
    if run['exit_code']!=0:raise ValueError(lang+' guest failed: '+run['stderr'][:600])
    try:r=json.loads(run['stdout'])
    except (ValueError,TypeError) as exc:raise ValueError(lang+' invalid ABI response') from exc
    if not isinstance(r,dict) or r.get('abi')!=ABI or 'value' not in r:
        raise ValueError(lang+' ABI protocol mismatch')
    if lang=='typescript' and ret=='i64' and (type(r['value']) is not int or abs(r['value'])>2**53-1):
        raise ValueError('TypeScript output exceeds safe JS integer precision')
    return r['value'],{'mode':mode,'build':build,'run':run,'exit_code':run['exit_code'],
                     'duration_ms':build['duration_ms']+run['duration_ms'],'source_sha256':digest(src),
                     'cache_hit':build.get('cache_hit',False),'cache_key':build.get('cache_key')}
