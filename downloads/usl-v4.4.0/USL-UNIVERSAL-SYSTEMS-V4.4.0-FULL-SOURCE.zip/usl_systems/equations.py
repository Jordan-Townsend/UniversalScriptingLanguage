"""Versioned equation catalog: provenance, use cases, symbolic and runnable entries.
No arbitrary eval; AST interpreter on whitelisted arithmetic functions only.
Previously discussed equations have source hints; entries without enough
parameters remain symbolic rather than fabricating measurements.
"""
from __future__ import annotations
import ast,math,operator
from copy import deepcopy
class EquationError(ValueError):pass

# Formula records are intentionally explicit about supported mathematics.
# "executable"=safe scalar numeric evaluation, not validation of a physical hypothesis.
REGISTRY=[]
def add(key,title,formula,use_cases,domain,status='established_math',expr=None,defaults=None,source='prior USL research and mathematical models',notes=''):
    REGISTRY.append({'id':key,'title':title,'formula':formula,'domain':domain,'status':status,
    'use_cases':use_cases.split('; '),'expression':expr,'defaults':defaults or {},'source':source,
    'notes':notes,'version':1,'executable':expr is not None})

# Exact-compute and scheduling formulations
add('sha256_identity','Content-addressed exact identity','key = SHA256(bytes)','Immutable CAS; deduplication; exact reconstruction','computation',expr=None,notes='Hash equality is a practical collision-resistant identity claim; exact bytes still verified.')
add('collapse_ratio','Serialized compression ratio','R = input_bytes / encoded_bytes','Measure actual compression; compare all codecs; packaging decisions','computation',expr='raw / encoded',defaults={'raw':1024,'encoded':500})
add('work_avoidance','Physical work avoidance fraction','A = (logical - executed) / logical','Repeated-work elimination; proof-gated cache accounting','computation',expr='(logical-executed)/logical',defaults={'logical':100,'executed':24})
add('speedup','Observed speedup','S = baseline_seconds / candidate_seconds','Independent baseline comparison; regression detection','computation',expr='baseline/candidate',defaults={'baseline':2,'candidate':1})
add('amdahl','Amdahl speedup bound','S = 1 / ((1-p)+p/n)','Parallel scaling ceiling; decide thread count','computation',expr='1/((1-p)+p/n)',defaults={'p':.9,'n':8})
add('jain','Jain fairness','J=(sum_i x_i)^2/(n sum_i x_i^2)','Fair CPU/GPU allocation; load distribution','scheduling',expr=None,source='EmoVision V63 handoff, V13 tensor discussion')
add('fairness_residual','Load imbalance residual','epsilon=1-J','Reapply weak partials; balance load across dimensions','scheduling',expr='1-J',defaults={'J':.9})
add('rho','Normalized service load','rho = required_rate / available_rate','Heterogeneous resource ratio; admission control','scheduling',expr='required/available',defaults={'required':25,'available':100})
add('rho_minmax','Minimize worst provider load','minimize max_i(rho_i)','Resource-aware placement; bottleneck mitigation','scheduling',source='EmoVision V18 handoff and fractal scheduler')
add('factor_dimensions','N partials by M dimensions','P=(partial_i, dimension_j, depth_k)','Fractal worker routing; named logical work axes','scheduling',status='design_rule',source='EmoVision Fabric V63')
add('incremental_update','Incremental state update','S_(t+1)=S_t + delta_S','Partial recompute; scene updates; reusable state','computation',expr='S+delta',defaults={'S':20,'delta':-3})
add('cached_transform','Reusable exact transform','Observed=T(known)+Residual','Exact delta reconstruction; prediction residual testing','computation',source='USL predictive/market discussions')
add('semantic_equivalence','Exactness gate','decode(encode(x))=x','Lossless compression; AST roundtrip; state replay','computation')
add('cost_min','Adaptive execution objective','min(C_compute + lambda*C_memory + mu*C_latency)','Scheduling policy selection; budget analysis','computation',expr='C_compute+lam*C_memory+mu*C_latency',defaults={'C_compute':1,'lam':.5,'C_memory':2,'mu':2,'C_latency':.2})
add('pareto','Pareto admissibility','x dominates y iff all x_i<=y_i and any x_i<y_i','Select non-dominated algorithm variants; cost trade-offs','optimization')
add('resource_reward','Resource value of a task','R_i=P_i*W_i-lambda*E_switch-mu*C_compute-nu*R_decoherence','Quantum control model experiments; energy-aware scheduling','optimization',status='research_model',expr='P*W-lam*E_switch-mu*C_compute-nu*R_decoherence',defaults={'P':.5,'W':.8,'lam':.1,'E_switch':1,'mu':.1,'C_compute':1,'nu':.1,'R_decoherence':.2},source='SU(3)/Kagome BEC lattice discussions')
# Statistics, decision systems and forecasting
add('covariance_propagation','Linear covariance propagation','Sigma_Y=M Sigma_R M^T + N','Uncertainty tracking; filter design; sensor fusion','statistics',source='USL quantum and predictive work')
add('exponential_attention','Attention memory decay','A(t+dt)=A(t)*exp(-lambda*dt)+NewAttention','News-event decay; concept memory; forecasting','statistics',expr='A*exp(-lam*dt)+new',defaults={'A':10,'lam':.2,'dt':1,'new':3})
add('normalized_attention_mismatch','Attention-flow divergence','NCD=NormalizedAttentionDirection-NormalizedCapitalFlowDirection','Finance research features; causal mismatch tests','statistics',status='research_model',expr='attention-capital',defaults={'attention':.5,'capital':-.2})
add('cvar_objective','Risk-adjusted decision objective','max E(R)-lambda1*CVaR-lambda2*Cost-lambda3*Drawdown-lambda4*CausalDebt','Backtesting and paper-trading decision research','finance',status='research_model',expr='R-l1*CVaR-l2*Cost-l3*Drawdown-l4*CausalDebt',defaults={'R':.12,'l1':.8,'CVaR':.05,'l2':.1,'Cost':.01,'l3':.6,'Drawdown':.1,'l4':.2,'CausalDebt':.03})
add('dealer_pressure','Hedging pressure proxy','HPF=sum_i Gamma_i OI_i Multiplier_i S^2 P(DealerState_i)','Derivatives exposure studies; market regime research','finance',status='research_model')
add('ewma','Exponential moving average','EMA_next=alpha*x+(1-alpha)*EMA','Prediction features; filter telemetry; rate smoothing','statistics',expr='alpha*x+(1-alpha)*EMA',defaults={'alpha':.2,'x':20,'EMA':10})
add('mean_squared_error','Mean squared error','MSE=sum((prediction-truth)^2)/n','Predictive model evaluation; optimization','statistics',expr=None)
add('rmse','Root mean square error','RMSE=sqrt(MSE)','Forecast quality; residual monitoring','statistics',expr='sqrt(MSE)',defaults={'MSE':.25})
add('bayes','Bayes theorem','P(H|E)=P(E|H)*P(H)/P(E)','Decision support; diagnostic prediction','statistics',expr='p_e_h*p_h/p_e',defaults={'p_e_h':.8,'p_h':.3,'p_e':.5})
add('entropy','Shannon entropy','H=-sum p_i log2(p_i)','Compression limits; uncertainty; feature selection','information',notes='Nonzero entropy bounds exact representation; no zero-cost universal compression.')
add('normalized_compression_distance','Normalized compression distance','NCD=(C(xy)-min(C(x),C(y)))/max(C(x),C(y))','Similarity research; compression-based clustering','information',expr='(Cxy-min(Cx,Cy))/max(Cx,Cy)',defaults={'Cxy':35,'Cx':18,'Cy':20})
# Dynamics/materials/engineering
add('kinetic_energy','Kinetic energy','E=0.5*m*v^2','Moving object energy; mechanical simulation','physics',expr='.5*m*v**2',defaults={'m':2,'v':3})
add('momentum','Linear momentum','p=m*v','Collision analysis; inertial mechanics','physics',expr='m*v',defaults={'m':2,'v':3})
add('force','Newton second law','F=m*a','Robot forces; actuator feasibility','physics',expr='m*a',defaults={'m':2,'a':3})
add('drag','Aerodynamic drag','F_d=0.5*rho*v^2*C_d*A','Drone and vehicle drag modeling; wind tunnel comparisons','physics',expr='.5*rho*v**2*Cd*A',defaults={'rho':1.225,'v':20,'Cd':.7,'A':.1})
add('elastic_energy','Stored linear elastic energy','E=0.5*k*x^2','Kagome mount energy; elastic actuator design','materials',expr='.5*k*x**2',defaults={'k':100,'x':.02})
add('damped_oscillator','Linear mass spring damper','m*x_doubleprime+c*x_prime+k*x=0','Vibration isolation baseline; control system simulation','materials')
add('transmissibility','Damped harmonic transmissibility','T=sqrt((1+(2*zeta*r)^2)/((1-r^2)^2+(2*zeta*r)^2))','Kagome vs conventional isolators; frequency response','materials',expr='sqrt((1+(2*zeta*r)**2)/((1-r**2)**2+(2*zeta*r)**2))',defaults={'zeta':.1,'r':2},source='KAGOME_ZERO_V7_ONE_SCRIPT.py')
add('fourier_heat','Fourier conduction','q=-k*A*dT/dx','Heat-exchanger design; cooling comparison','thermal',expr='-k*A*dTdx',defaults={'k':200,'A':.02,'dTdx':20})
add('newton_cooling','Convective heat transfer','Q=h*A*(T_surface-T_fluid)','Datacenter thermal budget; cold plate sizing','thermal',expr='h*A*(Ts-Tf)',defaults={'h':25,'A':2,'Ts':55,'Tf':20})
add('heat_capacity','Thermal storage','Q=m*c_p*delta_T','Heat buffers; thermal load modeling','thermal',expr='m*cp*dT',defaults={'m':2,'cp':900,'dT':20})
add('pressure_power','Pump hydraulic power','P=delta_p*volumetric_flow/efficiency','Cooling loop pump sizing; energy efficiency','thermal',expr='dp*flow/eta',defaults={'dp':20000,'flow':.001,'eta':.7})
add('cop','Coefficient of performance','COP=heat_removed/electrical_input','Thermal equipment comparison','thermal',expr='Q/P',defaults={'Q':400,'P':100})
add('pue','Power usage effectiveness','PUE=facility_power/IT_power','Datacenter infrastructure efficiency','thermal',expr='facility/IT',defaults={'facility':1200,'IT':1000})
add('water_intensity','Water use effectiveness','WUE=water_liters/IT_energy_kWh','Data-center water impact; cooling trade-offs','thermal',expr='liters/kwh',defaults={'liters':400,'kwh':1000})
add('photon_energy','Photon quantum energy','E=h*f','Optics experiments; photon engineering','quantum',expr='h*f',defaults={'h':6.62607015e-34,'f':5e14})
add('debroglie','de Broglie wavelength','lambda=h/p','Matter-wave modeling; low-temperature physics','quantum',expr='h/p',defaults={'h':6.62607015e-34,'p':1e-24})
add('lindblad','Lindblad master evolution','dot(rho)=-i/hbar[H,rho]+sum_k(L_k rho L_k† -0.5{L_k†L_k,rho})','Quantum open-system numerical modeling; decoherence estimates','quantum',notes='Symbolic matrix differential equation; not proof of room-temperature BEC or new stable hydrogen.')
add('schrodinger','Time-dependent Schrödinger equation','i*hbar*dpsi/dt=H*psi','Quantum simulation; numerical approximation','quantum',notes='Requires Hamiltonian and boundary conditions.')
add('energy_conservation','Closed-cycle energy bookkeeping','Delta_U_cycle=0 for closed conservative cycle','Reject perpetual energy claims; measurement reconciliation','physics',notes='Include all heat, work, electrical and environmental energy exchanges.')
add('bragg','Bragg condition','n*lambda=2*d*sin(theta)','Crystalline lattice diffraction; material characterization','materials',expr='2*d*sin(theta)/n',defaults={'d':2e-10,'theta':.5,'n':1})
add('lorentz','Lorentz factor','gamma=1/sqrt(1-v^2/c^2)','High-speed particle calculations','physics',expr='1/sqrt(1-(v/c)**2)',defaults={'v':1000,'c':299792458})
add('reynolds','Reynolds number','Re=rho*v*L/mu','Flow regime estimates; fan/drone aerodynamics','fluids',expr='rho*v*L/mu',defaults={'rho':1.225,'v':10,'L':.2,'mu':1.81e-5})
add('bernoulli','Bernoulli pressure relation','p+0.5*rho*v^2+rho*g*h=constant','Fluid-flow baseline; piping approximations','fluids',expr='p+.5*rho*v**2+rho*g*h',defaults={'p':101325,'rho':1.225,'v':10,'g':9.81,'h':2})
add('betz','Betz ideal wind extraction bound','P_max=(16/27)*0.5*rho*A*v^3','Wind turbine sanity bound; rotor concepts','fluids',expr='(16/27)*.5*rho*A*v**3',defaults={'rho':1.225,'A':1,'v':10})
add('gaussian_distribution','Normal distribution density','p(x)=exp(-0.5*((x-mu)/sigma)^2)/(sigma*sqrt(2*pi))','Prediction uncertainty; noise model','statistics',expr='exp(-.5*((x-mu)/sigma)**2)/(sigma*sqrt(2*pi))',defaults={'x':0,'mu':0,'sigma':1,'pi':math.pi})
add('logistic','Logistic activation','sigma(x)=1/(1+exp(-x))','AI probabilities; classification','ml',expr='1/(1+exp(-x))',defaults={'x':0})
add('softmax','Softmax probability','p_i=exp(x_i)/sum_j exp(x_j)','Neural output calibration; classification','ml')
add('gradient_descent','Gradient update','theta_next=theta-lr*gradient','Model training; numerical optimization','ml',expr='theta-lr*gradient',defaults={'theta':1,'lr':.1,'gradient':2})
add('kalman_gain','Scalar Kalman gain','K=P/(P+R)','Sensor filtering; vision tracking','ml',expr='P/(P+R)',defaults={'P':3,'R':2})
add('exponential_decay','Decay equation','y=y0*exp(-k*t)','Simulation baseline; attention decay','physics',expr='y0*exp(-k*t)',defaults={'y0':1,'k':.3,'t':2})

BUILTIN={item['id']:item for item in REGISTRY}
if len(BUILTIN)!=len(REGISTRY):raise RuntimeError('Duplicate equation identifier')
ALLOWED_FUNCS={'sqrt':math.sqrt,'exp':math.exp,'log':math.log,'log2':math.log2,'sin':math.sin,'cos':math.cos,'tanh':math.tanh,'abs':abs,'min':min,'max':max}
BINOPS={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.Pow:operator.pow}
UNARY={ast.USub:operator.neg,ast.UAdd:operator.pos}

def evaluate(identifier,params=None,extra=None):
    item=(extra or {}).get(identifier) or BUILTIN.get(identifier)
    if not item:raise EquationError('Equation not in registry')
    if not item['executable']:raise EquationError('Symbolic only: requires matrices, models, or additional formalization')
    settings=dict(item['defaults'])
    if params:
        if not isinstance(params,dict):raise EquationError('Parameters must be a mapping')
        if set(params)-set(settings):raise EquationError('Unexpected parameters: '+','.join(sorted(set(params)-set(settings))))
        settings.update(params)
    if len(item['expression'])>500:raise EquationError('Expression too large')
    for x in settings.values():
        if type(x) not in (float,int) or not math.isfinite(x):raise EquationError('Only finite scalar parameters permitted')
    tree=ast.parse(item['expression'],mode='eval')
    total=[0]
    def walk(node):
        total[0]+=1
        if total[0]>80:raise EquationError('Equation complexity bound')
        if isinstance(node,ast.Expression):return walk(node.body)
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):return node.value
        if isinstance(node,ast.Name) and node.id in settings:return settings[node.id]
        if isinstance(node,ast.BinOp) and type(node.op) in BINOPS:
            a=walk(node.left);b=walk(node.right)
            if isinstance(node.op,ast.Pow) and (abs(b)>16 or abs(a)>1e30):raise EquationError('Exponent exceeds safe bounds')
            return BINOPS[type(node.op)](a,b)
        if isinstance(node,ast.UnaryOp) and type(node.op) in UNARY:return UNARY[type(node.op)](walk(node.operand))
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ALLOWED_FUNCS and not node.keywords and len(node.args)<=4:
            return ALLOWED_FUNCS[node.func.id](*[walk(arg) for arg in node.args])
        raise EquationError('Unsupported equation AST')
    try:result=walk(tree)
    except (ArithmeticError,OverflowError,TypeError,ValueError) as exc:raise EquationError('Cannot evaluate at these parameters: '+str(exc)) from exc
    if not isinstance(result,(float,int)) or not math.isfinite(result):raise EquationError('Nonfinite equation output')
    return {'equation':identifier,'result':result,'parameters':settings,'status':item['status'],'numerical_evaluation':True,'empirical_validation':False,'notes':item['notes']}

def list_equations(query='',domain=None,extra=None):
    q=str(query).lower()
    return [deepcopy(x) for x in [*REGISTRY,*(extra or {}).values()] if (not domain or x['domain']==domain) and (not q or q in (x['title']+' '+x['id']+' '+x['formula']+' '+x['domain']+' '.join(x['use_cases'])).lower())]
