"""Isolate RDFLib's shared parser state from parallel scheduler threads."""
import json
import sys

def execute(language, source):
    import rdflib
    graph = rdflib.Graph()
    if language == 'sparql':
        graph.parse(data='@prefix ex: <urn:> . ex:task ex:workers 6 .', format='turtle')
        rows = list(graph.query(source))
        return {'workers': int(rows[0][0]), 'rows': len(rows)}
    graph.parse(data=source, format='json-ld' if language == 'jsonld' else 'turtle')
    if language == 'jsonld':
        values = list(graph.objects(rdflib.URIRef('urn:task:42'), rdflib.URIRef('http://schema.org/name')))
        return {'triples': len(graph), 'name': str(values[0])}
    values = list(graph.objects(rdflib.URIRef('urn:task'), rdflib.URIRef('urn:workers')))
    return {'triples': len(graph), 'workers': int(values[0])}

if __name__ == '__main__':
    try:
        print(json.dumps(execute(sys.argv[1], sys.argv[2]), sort_keys=True))
    except Exception as exc:
        print(f'{type(exc).__name__}: {exc}', file=sys.stderr)
        raise SystemExit(1)
