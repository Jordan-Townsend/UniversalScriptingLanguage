"""Windows/Linux CLI. No dependencies beyond Python 3.10+ for core operations."""
import argparse,json,sys,os,shutil,time,platform,urllib.request
from pathlib import Path
from .catalog import load_catalog
from .equations import list_equations,evaluate,EquationError
from .equation_import import EquationWorkspace,CustomEquationError
from .collapse import collapse_bytes,restore_bytes,ContentStore,CollapseError
from .fractal import FactoredFractal,ServiceTensorPlanner,dimensionless_load,FractalError
from .cooperative_workers import CooperativeScheduler,CooperativeError
from .incremental import CollapseCompute,IncrementalError
from .adaptive import AdaptiveExecutor
from .research_index import discover_archives
from .ir import lower,restore
from .qualification import qualification_report
from .semantic_plugins import Registry, array_qualification
from .module_linker import from_file as link_project_file, LinkError
from .semantic_types import check_types
from .module_contracts import validate_contracts
from .syntax_validation import validate_syntax,VALIDATORS
from .integrations import integration_status
from .simlab import simulate_decay,simulate_damper
from .vision import inspect_image
from .compiler import TARGETS,transpile
from .language import Interpreter,parse,USLError
from .native import verify,tool_available
from .universal import route as universal_route, collapse_success_all, export_portable, UniversalError
from .interop import run_nested, catalog_matrix, python_subset_import, BridgeError
from .pack import package,verify_package
from .adapters import AdapterRegistry,detect
from .anylang import ai_transpile
from .fabric import Fabric
from .resources import discover
from .server import start
from .store import Store
from .repair_proposals import propose_syntax_repair
from .observed_repair import ObservedRepair
from .native_syntax import check_source,available as native_syntax_availability
from .legacy_runtime import SOURCES,bundled_sources,stage_component,component_root,native_v031_run,bridge_status,shadow_health,emovision_health,run_bridge_v3,LegacyError

def main(argv=None):
    p=argparse.ArgumentParser(prog='usl',description='USL Universal Systems — semantic subset, 606 catalog entries, equations, verified compression and N-M workers')
    sub=p.add_subparsers(dest='command',required=True)
    s=sub.add_parser('cooperate',help='Run bounded cooperative factored worker DAG with verified cross-task outputs')
    s.add_argument('file');s.add_argument('--threads',type=int,default=3);s.add_argument('--processes',type=int,default=2)
    s.add_argument('--checkpoint');s.add_argument('--output');s.add_argument('--max-in-flight',type=int);s.add_argument('--i-approve-native',action='store_true')
    s=sub.add_parser('serve',help='Start local desktop web UI');s.add_argument('--port',type=int,default=8772);s.add_argument('--no-browser',action='store_true');s.add_argument('--data')
    s=sub.add_parser('stop',help='Stop authorized local service');s.add_argument('--port',type=int,default=8772);s.add_argument('--data')
    s=sub.add_parser('fetch-legacy',help='Download old USL syntax registry from your public GitHub repo (needs network)');s.add_argument('--repo',choices=['usl','Usldev'],default='Usldev')
    s=sub.add_parser('ir',help='Produce a versioned validated USL intermediate representation');s.add_argument('file');s.add_argument('--output')
    s=sub.add_parser('syntax-validate',help='Parse supported data/config/Python syntax with a real parser');s.add_argument('file');s.add_argument('--language',required=True)
    s=sub.add_parser('semantic-plugins',help='Report exact capabilities for every catalogued syntax family');s.add_argument('--output')
    s=sub.add_parser('semantic-qualify',help='Execute source-hash-pinned cross-runtime semantic behavior corpus and account for 606 languages')
    s.add_argument('--i-approve-native',action='store_true');s.add_argument('--workers',type=int,default=4);s.add_argument('--output');s.add_argument('--ledger-output')
    s=sub.add_parser('semantic-ledger',help='Report whole-specification conformance gaps for all 606 catalog entries');s.add_argument('--output')
    s=sub.add_parser('universal-route',help='USL IR -> per-target native evidence or portable semantic VM')
    s.add_argument('file');s.add_argument('--target',required=True);s.add_argument('--allow-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('collapse-success-all',help='Parallel verified native candidate search, with portable fallback')
    s.add_argument('file');s.add_argument('--targets',default='python,javascript,ruby,php,go,java,cpp,c')
    s.add_argument('--i-approve-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('universal-export',help='Export a portable IR VM archive for a catalogued target')
    s.add_argument('file');s.add_argument('--target',required=True);s.add_argument('--output',required=True)

    s=sub.add_parser('nested-run',help='Execute declared USL/Python/JS/compiled C nested bridge DAG with approval')
    s.add_argument('file');s.add_argument('--workers',type=int,default=4);s.add_argument('--i-approve-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('nested-matrix',help='Print 606-catalog language bridge adapter availability');s.add_argument('--output')
    s=sub.add_parser('adapter-discover',help='Discover reviewed versioned guest adapter manifests for available native tools')
    s.add_argument('--output')
    s=sub.add_parser('adapter-qualify',help='Parallel actual native qualification of reviewed guest adapter registry')
    s.add_argument('--workers',type=int,default=4);s.add_argument('--i-approve-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('adapter-run',help='Execute a reviewed guest adapter for bounded i64 input')
    s.add_argument('language');s.add_argument('value',type=int);s.add_argument('--i-approve-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('adapter-pair',help='Actually execute two registered guest languages in typed dependency order')
    s.add_argument('host');s.add_argument('guest');s.add_argument('--i-approve-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('adapter-capabilities',help='Produce honest 606-entry executable status report')
    s.add_argument('--qualification-report');s.add_argument('--output')
    s=sub.add_parser('matrix-qualify-guests',help='Run all installed fixture-backed language guests concurrently and write 606-entry execution evidence')
    s.add_argument('--i-approve-native',action='store_true');s.add_argument('--workers',type=int,default=4);s.add_argument('--output')
    s=sub.add_parser('matrix-execute',help='Execute one verified typed host->guest route for two catalog entries')
    s.add_argument('host');s.add_argument('guest');s.add_argument('--i-approve-native',action='store_true');s.add_argument('--output')
    s=sub.add_parser('matrix-qualify-pairs',help='Execute a JSON list of host/guest routes with cooperative concurrency')
    s.add_argument('file');s.add_argument('--i-approve-native',action='store_true');s.add_argument('--workers',type=int,default=3);s.add_argument('--output')
    s=sub.add_parser('matrix-build',help='Build dense, 367236-cell executable eligibility matrix with exact observation evidence')
    s.add_argument('--language-report');s.add_argument('--pair-report');s.add_argument('--output-prefix',required=True)
    s=sub.add_parser('matrix-cell',help='Check a cell in a verified 606x606 dense matrix artifact')
    s.add_argument('matrix_file');s.add_argument('metadata_file');s.add_argument('host');s.add_argument('guest')
    s=sub.add_parser('import-python-subset',help='Lower supported bounded Python syntax into USL IR');s.add_argument('file');s.add_argument('--output')
    s=sub.add_parser('qualify-arrays',help='Actual native array-index output checks against interpreter');s.add_argument('--targets',default='python,javascript,ruby,php');s.add_argument('--output')
    s=sub.add_parser('link-project',help='Link versioned, dependency-checked USL modules without executing');s.add_argument('file');s.add_argument('--output')
    s=sub.add_parser('type-check',help='Conservative USL primitive and array static diagnostics');s.add_argument('file');s.add_argument('--output')
    s=sub.add_parser('type-check-project',help='Link a USL module project and run bounded static diagnostics');s.add_argument('file');s.add_argument('--output')
    s=sub.add_parser('check-contracts',help='Static verification of source-bound module function signatures');s.add_argument('file');s.add_argument('--output')
    s=sub.add_parser('verify-project',help='Run linked USL modules and compare native runtime output, requires approval');s.add_argument('file');s.add_argument('--target',required=True);s.add_argument('--i-approve-native',action='store_true')
    s=sub.add_parser('qualify',help='Run actual native compiler conformance scenarios, including all 606 catalog profiles');s.add_argument('--targets',default='');s.add_argument('--output');s.add_argument('--no-profiles',action='store_true')
    s=sub.add_parser('integrations',help='Discover historical USL/Shadow/EmoVision installs without modifying them');s.add_argument('--roots',nargs='*');s.add_argument('--probe-local-bridge',action='store_true')
    s=sub.add_parser('recovered-list',help='List verified historical full-source bundles; no execution')
    s=sub.add_parser('recovered-stage',help='Safely extract a verified recovered component under user data')
    s.add_argument('component',choices=[*SOURCES,'all']);s.add_argument('--data')
    s=sub.add_parser('recovered-bridge-run',help='Start the actual V3 bridge in the foreground with explicit permission')
    s.add_argument('--data');s.add_argument('--port',type=int,default=8766);s.add_argument('--i-allow-launch',action='store_true')
    s=sub.add_parser('recovered-native',help='Build a TRUSTED typed V0.31 .usl program using recovered native compiler')
    s.add_argument('file');s.add_argument('--arg',type=int);s.add_argument('--data');s.add_argument('--timeout',type=int,default=25)
    s.add_argument('--i-allow-native',action='store_true')
    s=sub.add_parser('recovered-health',help='Authenticated Chrome Bridge / opt-in Shadow or EmoVision service probe')
    s.add_argument('component',choices=['bridge','shadow','emovision']);s.add_argument('--url')
    s.add_argument('--i-allow-unauthenticated-sdk',action='store_true')
    s=sub.add_parser('simulate',help='Run a validated classical ODE simulation');s.add_argument('model',choices=['decay','damper']);s.add_argument('--steps',type=int,default=200);s.add_argument('--seconds',type=float,default=10.0)
    s=sub.add_parser('vision-inspect',help='Read-only image properties and luminance histogram');s.add_argument('file')
    s=sub.add_parser('doctor',help='Discover tools and local data');s.add_argument('--json',action='store_true')
    s=sub.add_parser('catalog',help='List all 606 syntax families or search');s.add_argument('--search',default='');s.add_argument('--legacy',help='Import a JSON legacy template registry');s.add_argument('--json',action='store_true')
    s=sub.add_parser('run',help='Execute validated USL subset');s.add_argument('file');s.add_argument('--json',action='store_true')
    s=sub.add_parser('check',help='Parse/check USL subset');s.add_argument('file')
    s=sub.add_parser('transpile',help='Emit target-language source');s.add_argument('file');s.add_argument('--target',required=True);s.add_argument('--output')
    s=sub.add_parser('verify',help='Compare native execution with USL interpreter');s.add_argument('file');s.add_argument('--target',required=True)
    s=sub.add_parser('pack',help='Create SHA-256 verified .uslpack.zip');s.add_argument('folder');s.add_argument('output')
    s=sub.add_parser('verify-pack');s.add_argument('file')
    s=sub.add_parser('flow',help='Execute validated cross-language dependency graph');s.add_argument('file');s.add_argument('--workers',type=int,default=4);s.add_argument('--i-allow-native',action='store_true');s.add_argument('--no-cache',action='store_true')
    s=sub.add_parser('detect',help='Find all matching language syntax families from filename');s.add_argument('file')
    s=sub.add_parser('native-info',help='Show native adapter capability');s.add_argument('language')
    s=sub.add_parser('native-configure',help='Configure per-language argv array toolchain');s.add_argument('language');s.add_argument('argv_json')
    s=sub.add_parser('native-run',help='Run explicitly authorized native source');s.add_argument('language');s.add_argument('file');s.add_argument('--i-allow-execution',action='store_true');s.add_argument('--timeout',type=int,default=10)
    s=sub.add_parser('ai-transpile',help='Best-effort local-model translation to ANY catalogued target');s.add_argument('file');s.add_argument('--target',required=True);s.add_argument('--model');s.add_argument('--output',required=True)
    s=sub.add_parser('native-syntax-check',help='Opt-in installed native parser/compiler syntax check (not semantic equivalence)')
    s.add_argument('language');s.add_argument('file');s.add_argument('--i-approve-native',action='store_true')
    s=sub.add_parser('repair-observe',help='Approved monitored Python compiler process; persists exact stdout and source hash')
    s.add_argument('project');s.add_argument('file');s.add_argument('--data');s.add_argument('--i-approve-observation',action='store_true')
    s=sub.add_parser('repair-continue',help='Apply an observed compiler-grounded repair and retest; REQUIRES explicit approval')
    s.add_argument('observation_id');s.add_argument('--data');s.add_argument('--i-approve-repair',action='store_true')
    s=sub.add_parser('repair-propose',help='Read a Python compiler error and output an inert hash-pinned repair plan')
    s.add_argument('project');s.add_argument('file');s.add_argument('--data')
    s=sub.add_parser('bridge-start',help='Authorize a child process and observe its console through the running local service')
    s.add_argument('project');s.add_argument('argv_json',help='JSON array of executable and args, never a shell string')
    s.add_argument('--max-seconds',type=int,default=300);s.add_argument('--port',type=int,default=8772)
    s.add_argument('--data');s.add_argument('--i-allow-execution',action='store_true')
    s=sub.add_parser('bridge-list',help='List processes started by the local bridge')
    s.add_argument('--port',type=int,default=8772)
    s=sub.add_parser('bridge-output',help='Show actual captured child console output')
    s.add_argument('id');s.add_argument('--port',type=int,default=8772)
    s=sub.add_parser('bridge-stop',help='Stop an authorized child process')
    s.add_argument('id');s.add_argument('--port',type=int,default=8772);s.add_argument('--data')
    s=sub.add_parser('swarm-build',help='Multi-role real local-model design, execution and review')
    s.add_argument('goal');s.add_argument('--project',default='demo');s.add_argument('--targets',default='python,javascript')
    s.add_argument('--model',default='')
    s=sub.add_parser('equations',help='Show mathematical and research equation registry')
    s.add_argument('--search',default='');s.add_argument('--domain');s.add_argument('--id');s.add_argument('--params',default='{}')
    s=sub.add_parser('equations-import',help='Add reviewed formula definitions (not auto-promoted) to persistent local registry')
    s.add_argument('file');s.add_argument('--data')
    s=sub.add_parser('collapse',help='Exact, SHA-256 verified compression/reuse demo')
    s.add_argument('file');s.add_argument('--reference');s.add_argument('--mode',choices=['all','raw','zlib','delta','duplicate','partial'],default='all');s.add_argument('--output')
    s=sub.add_parser('cas',help='Immutable content-addressed store; add and verify local file')
    s.add_argument('file');s.add_argument('--data')
    s=sub.add_parser('fractal',help='Bounded N x M recursive factored-worker reduction')
    s.add_argument('--count',type=int,default=8192);s.add_argument('--repeat',type=int,default=32);s.add_argument('--workers',type=int,default=4)
    s.add_argument('--leaf',type=int,default=128);s.add_argument('--depth',type=int,default=6)
    s.add_argument('--dimensions',default='execution,cache,verification');s.add_argument('--operator',choices=['sum','sum_squares','sum_abs','sum_even','histogram'],default='sum_squares');s.add_argument('--sync',action='store_true');s.add_argument('--processes',action='store_true',help='Use real OS processes for CPU-bound work (can be slower for small work)');s.add_argument('--no-reuse',action='store_true');s.add_argument('--auto',action='store_true',help='Benchmark serial/sync/async and select verified fastest')
    s=sub.add_parser('incremental',help='Benchmark exact H0/H1/H2 update and reuse')
    s.add_argument('--count',type=int,default=100000);s.add_argument('--changes',type=int,default=100);s.add_argument('--audit',action='store_true')
    s.add_argument('--operator',choices=['sum','sum_squares','sum_abs','sum_even','histogram'],default='sum_squares')
    s=sub.add_parser('research-index',help='Discover candidate equations in recovered source archives')
    s.add_argument('--output');s.add_argument('--max',type=int,default=1000)
    s=sub.add_parser('tensor-place',help='Place N work items across M resource dimensions onto real worker capacities')
    s.add_argument('requirements_json');s.add_argument('capacities_json')
    s=sub.add_parser('resource-load',help='Dimensionless N-M service utilization / Jain fairness')
    s.add_argument('requirements_json');s.add_argument('capacity_json')
    s=sub.add_parser('bench',help='Interpreter test workload');s.add_argument('--iterations',type=int,default=100)
    s=sub.add_parser('source-engines',help='Discover exact native source-engine contracts');s.add_argument('--output')
    s=sub.add_parser('source-run',help='Parse and execute explicitly authorized imported native source')
    s.add_argument('file');s.add_argument('--language',required=True);s.add_argument('--context',default='{}');s.add_argument('--i-allow-execution',action='store_true');s.add_argument('--output')
    s=sub.add_parser('source-program',help='Run a .usl program with the explicit engine_run capability')
    s.add_argument('file');s.add_argument('--i-allow-execution',action='store_true');s.add_argument('--output');s.add_argument('--imports-file')
    for name, help_text in [('entity-plan','Execute an approved perception/learning/tool plan'),('entity-learn','Infer and qualify a bounded USL skill from labelled examples'),('entity-study','Qualify a proposed USL skill against independent cases'),('entity-program','Run .usl with explicit durable entity capabilities')]:
        s=sub.add_parser(name,help=help_text);s.add_argument('file');s.add_argument('--data');s.add_argument('--output');s.add_argument('--i-allow-execution',action='store_true')
        if name=='entity-program':s.add_argument('--imports-file')
    s=sub.add_parser('entity-memory',help='Retrieve durable evidence');s.add_argument('query');s.add_argument('--data');s.add_argument('--output')
    s=sub.add_parser('entity-recover',help='Mark interrupted runs for review; no action replay');s.add_argument('--data');s.add_argument('--output')
    s=sub.add_parser('entity-propose',help='Ask an actual configured local model for an inert USL proposal');s.add_argument('goal');s.add_argument('--model');s.add_argument('--data');s.add_argument('--output')
    s=sub.add_parser('entity-status',help='Report explicit entity, sense and language readiness');s.add_argument('--output')
    s=sub.add_parser('language-engines',help='Discover additional real upstream engines');s.add_argument('--output')
    s=sub.add_parser('language-run',help='Execute bounded source with a real upstream engine');s.add_argument('file');s.add_argument('--language',required=True);s.add_argument('--context',default='{}');s.add_argument('--i-allow-execution',action='store_true');s.add_argument('--output')
    s=sub.add_parser('neural-infer',help='Run the trained digits feature-fusion model');s.add_argument('file');s.add_argument('--bundle',required=True);s.add_argument('--output')
    s=sub.add_parser('neural-benchmark',help='Compare residual feature fusion against a matched-initialization CNN');s.add_argument('--epochs',type=int,default=24);s.add_argument('--output',default='test_results/v4.3.0_neural')
    s=sub.add_parser('catalog-sweep',help='Execute the full 523-entry USL work inventory with explicit completion gaps');s.add_argument('--file',default='examples/catalog_factored_sweep.usl');s.add_argument('--workers',type=int,default=4);s.add_argument('--output',default='test_results/v4.4.0_sweep');s.add_argument('--i-allow-execution',action='store_true')
    s=sub.add_parser('catalog-native',help='Run source with a reviewed real catalog backend');s.add_argument('file');s.add_argument('--language',required=True);s.add_argument('--context',default='{}');s.add_argument('--i-allow-execution',action='store_true');s.add_argument('--output')
    s=sub.add_parser('catalog-parse',help='Import a real upstream AST, without claiming semantic execution');s.add_argument('file');s.add_argument('--language',required=True);s.add_argument('--output')
    s=sub.add_parser('intent-prove',help='Prove an explicitly modelled pure USL integer function against its contract');s.add_argument('file');s.add_argument('--function',required=True);s.add_argument('--contract',required=True);s.add_argument('--output')
    args=p.parse_args(argv)
    try:
        if args.command in ('catalog-sweep','catalog-native','catalog-parse','intent-prove'):
            if args.command=='catalog-sweep':
                from .catalog_completion import usl_sweep
                result=usl_sweep(Path(args.file).read_text('utf8'),workers=args.workers,output=args.output,approved=args.i_allow_execution)
                print(result['usl_supervisor']['stdout'],end='')
                return 0 if result['all_606_complete'] else 2
            elif args.command=='catalog-native':
                from .catalog_backends import run
                result=run(args.language,Path(args.file).read_text('utf8'),json.loads(args.context),approved=args.i_allow_execution)
            elif args.command=='catalog-parse':
                from .catalog_parser import parse_source
                result=parse_source(args.language,Path(args.file).read_text('utf8'))
            else:
                from .intent_contracts import prove_usl
                result=prove_usl(Path(args.file).read_text('utf8'),args.function,json.loads(Path(args.contract).read_text()))
            payload=json.dumps(result,indent=2,ensure_ascii=False)
            if args.output:Path(args.output).write_text(payload+'\n',encoding='utf8')
            else:print(payload)
            return 0 if result.get('proved',True) else 2
        if args.command.startswith('entity-') or args.command in ('language-engines','language-run','neural-infer','neural-benchmark'):
            from .entity import Entity,EntitySession
            from .senses import readiness
            from .language_runtime import discover as language_discover,run as language_run
            if args.command in ('entity-plan','entity-learn','entity-study','entity-program'):
                if not args.i_allow_execution:raise USLError('Explicit entity execution approval required')
                entity=Entity(args.data)
                if args.command=='entity-program':
                    imports=json.loads(Path(args.imports_file).read_text()) if args.imports_file else {}
                    result=EntitySession(entity,imports,approved=True).interpret(Path(args.file).read_text('utf8'))
                else:
                    document=json.loads(Path(args.file).read_text('utf8'))
                    result=entity.plan(document,approved=True) if args.command=='entity-plan' else entity.learn(document) if args.command=='entity-learn' else entity.study(document)
            elif args.command=='entity-memory':result=Entity(args.data).memory.retrieve(args.query)
            elif args.command=='entity-recover':result={'needs_review':Entity(args.data).memory.recover(),'automatically_replayed':False}
            elif args.command=='entity-propose':result=Entity(args.data).propose(args.goal,args.model)
            elif args.command=='entity-status':
                from .agent import models
                result={'sensors':readiness(),'language_engines':language_discover(),'local_model':models(),
                    'learning':'bounded USL arithmetic synthesis and independently tested proposed skills',
                    'memory':'SQLite evidence retrieval and versioned skills','general_human_equivalence':False}
            elif args.command=='language-engines':result=language_discover()
            elif args.command=='language-run':result=language_run(args.language,Path(args.file).read_text('utf8'),json.loads(args.context),approved=args.i_allow_execution)
            elif args.command=='neural-infer':
                from .neural_training import infer
                result=infer(args.bundle,args.file)
            else:
                from .neural_training import benchmark
                result=benchmark(args.output,epochs=args.epochs)
                print(json.dumps({'benchmark':str(Path(args.output)/'benchmark.json'),'mean_accuracy_difference':result['mean_accuracy_difference'],'universal_superiority_proven':False}));return 0
            payload=json.dumps(result,indent=2,ensure_ascii=False)
            if args.output:Path(args.output).write_text(payload+'\n',encoding='utf8')
            else:print(payload)
            return 0
        if args.command in ('source-engines','source-run','source-program'):
            from .source_engines import CONTRACTS,provenance,execute,SourceSession
            if args.command=='source-engines':
                result={}
                for id_ in CONTRACTS:
                    try:result[id_]=provenance(id_)
                    except Exception as e:result[id_]={'available':False,'error':str(e),'full_spec_qualified':False}
            elif args.command=='source-run':
                result=execute(args.language,Path(args.file).read_text('utf8'),json.loads(args.context),approved=args.i_allow_execution)
            else:
                imports=json.loads(Path(args.imports_file).read_text('utf8')) if args.imports_file else {}
                result=SourceSession(approved=args.i_allow_execution,imports=imports).interpret(Path(args.file).read_text('utf8'))
            payload=json.dumps(result,indent=2,ensure_ascii=False)
            if args.output:Path(args.output).write_text(payload+'\n',encoding='utf8')
            else:print(payload)
            return 0
        if args.command in ('semantic-qualify','semantic-ledger'):
            from .semantic_conformance import qualify as semantic_qualify,negative_syntax,ledger as semantic_ledger
            if args.command=='semantic-qualify':
                result=semantic_qualify(authorized=args.i_approve_native,workers=args.workers)
                result['negative_syntax']=negative_syntax(authorized=args.i_approve_native)
                report=semantic_ledger(qualification=result)
                if args.ledger_output:Path(args.ledger_output).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
                okay=result['all_passed'] and result['negative_syntax']['all_passed']
            else: result=semantic_ledger();okay=True
            out=json.dumps(result,indent=2,ensure_ascii=False)
            if args.output:Path(args.output).write_text(out+'\n',encoding='utf8');print('Saved',args.output)
            else:print(out)
            return 0 if okay else 2
        if args.command in ('adapter-discover','adapter-qualify','adapter-run','adapter-pair','adapter-capabilities'):
            from .universal_adapters import discovered,qualify_registry,run_adapter,execute_extended_pair,capability_report
            if args.command=='adapter-discover':result=discovered()
            elif args.command=='adapter-qualify':result=qualify_registry(authorized=args.i_approve_native,workers=args.workers)
            elif args.command=='adapter-run':result=run_adapter(args.language,args.value,authorized=args.i_approve_native)
            elif args.command=='adapter-pair':result=execute_extended_pair(args.host,args.guest,authorized=args.i_approve_native)
            else:
                report=json.loads(Path(args.qualification_report).read_text('utf8')) if args.qualification_report else None
                result=capability_report(qualifications=report)
            content=json.dumps(result,indent=2,ensure_ascii=False)
            if args.output:Path(args.output).write_text(content+'\n',encoding='utf8');print('Saved',args.output)
            else:print(content)
            return 0 if not isinstance(result,dict) or result.get('tests',0)==result.get('passed',0) else 2
        if args.command=='nested-run':
            project=json.loads(Path(args.file).read_text(encoding='utf8'))
            result=run_nested(project,authorized=args.i_approve_native,workers=args.workers)
            output=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(output+'\n','utf8');print('Saved',args.output)
            else:print(output)
            return 0 if result['all_verified'] else 2
        if args.command in ('matrix-qualify-guests','matrix-execute','matrix-qualify-pairs','matrix-build','matrix-cell'):
            from .executable_matrix import run_language_qualifications,execute_pair,run_pairs,build_dense_matrix,cell_value
            if args.command=='matrix-qualify-guests':
                result=run_language_qualifications(authorized=args.i_approve_native,workers=args.workers)
                okay=result['failed_real_execution']==0
            elif args.command=='matrix-execute':
                result=execute_pair(args.host,args.guest,authorized=args.i_approve_native)
                okay=result.get('verified',False)
            elif args.command=='matrix-qualify-pairs':
                pairs=json.loads(Path(args.file).read_text(encoding='utf8'))
                result=run_pairs(pairs,authorized=args.i_approve_native,workers=args.workers)
                okay=result['probe_count']==result['actual_verified_pairs']
            elif args.command=='matrix-build':
                lang=json.loads(Path(args.language_report).read_text('utf8')) if args.language_report else None
                pair=json.loads(Path(args.pair_report).read_text('utf8')) if args.pair_report else None
                grid,meta=build_dense_matrix(language_evidence=lang,pair_evidence=pair)
                prefix=Path(args.output_prefix);prefix.parent.mkdir(parents=True,exist_ok=True)
                prefix.with_suffix('.bin').write_bytes(grid)
                prefix.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n','utf8')
                print(json.dumps({'matrix_file':str(prefix.with_suffix('.bin')),'metadata_file':str(prefix.with_suffix('.json')),
                        'shape':meta['shape'],'conditional':meta['count_conditional_unverified'],
                        'observed':meta['count_executed_verified']},indent=2))
                return 0
            else:
                grid=Path(args.matrix_file).read_bytes();meta=json.loads(Path(args.metadata_file).read_text('utf8'))
                if len(grid)!=606*606 or __import__('hashlib').sha256(grid).hexdigest()!=meta['matrix_sha256']:
                    raise ValueError('Matrix integrity verification failed')
                print(json.dumps({'host':args.host,'guest':args.guest,'status':cell_value(grid,meta,args.host,args.guest)}))
                return 0
            payload=json.dumps(result,indent=2,ensure_ascii=False)
            if args.output:Path(args.output).write_text(payload+'\n',encoding='utf8');print('Saved',args.output)
            else:print(payload)
            return 0 if okay else 2
        if args.command=='nested-matrix':
            result=catalog_matrix();output=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(output+'\n','utf8');print('Saved',args.output)
            else:print(output)
            return 0
        if args.command=='import-python-subset':
            result=python_subset_import(Path(args.file).read_text('utf8'));output=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(output+'\n','utf8');print('Saved',args.output)
            else:print(output)
            return 0
        if args.command=='cooperate':
            graph=json.loads(Path(args.file).read_text(encoding='utf8'))
            result=CooperativeScheduler(threads=args.threads,processes=args.processes,allow_native=args.i_approve_native,max_in_flight=args.max_in_flight).run(graph,checkpoint=args.checkpoint)
            payload=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(payload+'\n',encoding='utf8');print('Saved',args.output)
            else:print(payload)
            return 0 if result['all_verified'] else 2
        if args.command=='native-syntax-check':
            print(json.dumps(check_source(args.language,Path(args.file).read_text(encoding='utf8'),authorized=args.i_approve_native),indent=2))
            return 0
        if args.command=='repair-observe':
            print(json.dumps(ObservedRepair(Store(args.data)).observe(args.project,args.file,authorized=args.i_approve_observation),indent=2))
            return 0
        if args.command=='repair-continue':
            print(json.dumps(ObservedRepair(Store(args.data)).approve_and_verify(args.observation_id,authorized=args.i_approve_repair),indent=2))
            return 0
        if args.command=='repair-propose':
            print(json.dumps(propose_syntax_repair(Store(args.data),args.project,args.file),indent=2))
            return 0
        if args.command=='serve':return start(port=args.port,data=args.data,open_browser=not args.no_browser)
        if args.command=='stop':
            from urllib.error import URLError
            path=Store(args.data).root/'control_token'
            if not path.exists():raise USLError('Local service token not found')
            req=urllib.request.Request(f'http://127.0.0.1:{args.port}/api/shutdown',data=b'{}',
                headers={'Content-Type':'application/json','X-USL-Stop-Token':path.read_text(encoding='utf8').strip()},method='POST')
            with urllib.request.urlopen(req,timeout=5) as r:print(r.read().decode('utf8'))
            return 0
        if args.command.startswith('bridge-'):
            base=f'http://127.0.0.1:{args.port}'
            if args.command in ('bridge-list','bridge-output'):
                from urllib.parse import quote
                url=base+('/api/processes' if args.command=='bridge-list' else '/api/process?id='+quote(args.id))
                with urllib.request.urlopen(url,timeout=6) as r:obj=json.load(r)
                if args.command=='bridge-output':print(obj.get('output',''))
                else:print(json.dumps(obj,indent=2))
                return 0
            if args.command=='bridge-start' and not args.i_allow_execution:
                raise USLError('Explicit --i-allow-execution is required for native execution')
            tokenfile=Store(args.data).root/'control_token'
            if not tokenfile.is_file():raise USLError('Start the local GUI service first (missing control token)')
            headers={'Content-Type':'application/json','X-USL-Control-Token':tokenfile.read_text(encoding='utf8').strip()}
            if args.command=='bridge-start':
                payload={'project':args.project,'argv':json.loads(args.argv_json),'max_seconds':args.max_seconds}
                endpoint='/api/process/launch'
            else:
                payload={'id':args.id};endpoint='/api/process/stop'
            req=urllib.request.Request(base+endpoint,data=json.dumps(payload).encode('utf8'),headers=headers,method='POST')
            with urllib.request.urlopen(req,timeout=12) as r:print(json.dumps(json.load(r),indent=2))
            return 0
        if args.command=='swarm-build':
            import uuid
            from .swarm import build_swarm
            store=Store();ident=uuid.uuid4().hex[:18]
            jobreq={'goal':args.goal,'project':args.project,'targets':[x.strip() for x in args.targets.split(',') if x.strip()],'model':args.model}
            store.create(ident,'swarm',jobreq);store.update(ident,'running')
            try:
                result=build_swarm(jobreq,store,ident)
                store.update(ident,'completed',result)
                print(json.dumps(result,indent=2));return 0
            except Exception as exc:
                store.update(ident,'failed',{'error':str(exc)})
                raise
        if args.command=='fetch-legacy':
            url=f'https://raw.githubusercontent.com/Jordan-Townsend/{args.repo}/main/syntax_templates_fully_extended.json'
            with urllib.request.urlopen(url,timeout=20) as r:payload=r.read(5_000_000)
            data=json.loads(payload)
            if not isinstance(data,dict):raise USLError('Unexpected registry format')
            dest=Store().root/'syntax_templates_fully_extended.json'
            dest.write_bytes(payload)
            print(json.dumps({'downloaded':len(data),'destination':str(dest),'source':url}))
            return 0
        if args.command=='catalog':
            rows=load_catalog(args.legacy)
            if args.search:rows=[r for r in rows if args.search.lower() in r['name'].lower() or args.search.lower() in r['id'].lower()]
            if args.json:print(json.dumps(rows,ensure_ascii=False,indent=2))
            else:
                print(f'{len(rows)} catalogued syntax families (recognition != compilation)')
                for r in rows:print(f'{r["id"]:<24} {r["support"]:<16} {r["name"]}')
            return 0
        if args.command=='equations-import':
            print(json.dumps(EquationWorkspace(Store(args.data).root).import_file(args.file),indent=2));return 0
        if args.command=='equations':
            extra=EquationWorkspace().records()
            if args.id:print(json.dumps(evaluate(args.id,json.loads(args.params),extra=extra),indent=2))
            else:
                items=list_equations(args.search,args.domain,extra=extra)
                print(json.dumps({'count':len(items),'items':items},indent=2))
            return 0
        if args.command=='collapse':
            data=Path(args.file).read_bytes();ref=Path(args.reference).read_bytes() if args.reference else None
            record=collapse_bytes(data,ref,args.mode);result=restore_bytes(record,ref)
            if args.output:Path(args.output).write_text(json.dumps(record,indent=2),encoding='utf8')
            print(json.dumps({'codec':record['codec'],'bytes':len(data),'encoded_bytes':record['encoded_bytes'],
              'saved_bytes':record['saved_bytes'],'sha256':record['sha256'],'exact_verified':result==data,
              'output':args.output or None},indent=2));return 0
        if args.command=='cas':
            store=ContentStore(Store(args.data).root/'cas')
            data=Path(args.file).read_bytes();entry=store.put(data)
            entry['roundtrip_verified']=store.get(entry['sha256'])==data
            print(json.dumps(entry,indent=2));return 0
        if args.command=='fractal':
            count=max(0,min(500000,args.count));r=max(1,min(500000,args.repeat))
            values=[i%r for i in range(count)]
            scheduler=FactoredFractal(workers=args.workers,max_depth=args.depth,leaf_size=args.leaf)
            dims=tuple(x.strip() for x in args.dimensions.split(',') if x.strip())
            if args.auto:d=AdaptiveExecutor(workers=args.workers,max_depth=args.depth,leaf_size=args.leaf).choose(values,operator=args.operator,dimensions=dims,include_process=args.processes)
            else:d=scheduler.execute(values,operator=args.operator,dimensions=dims,mode='process' if args.processes else ('sync' if args.sync else 'async'),reuse=not args.no_reuse)
            print(json.dumps(d,indent=2));return 0
        if args.command=='incremental':
            count=max(0,min(500000,args.count));changes=max(0,min(count,args.changes))
            src=[i%101 for i in range(count)]
            core=CollapseCompute(args.operator);base=core.initialize(src)
            changed={i*count//max(1,changes):(src[i*count//max(1,changes)]+1) for i in range(changes)}
            next_=core.update(changed,audit=args.audit)
            reused=core.update({},audit=args.audit)
            print(json.dumps({'H0':base,'H2':next_,'H1':reused,'snapshot':core.snapshot()},indent=2));return 0
        if args.command=='research-index':
            result=discover_archives(Path(__file__).resolve().parent.parent/'legacy_sources',max_matches=max(1,min(10000,args.max)))
            output=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(output,encoding='utf8');print('Saved',args.output)
            else:print(output)
            return 0
        if args.command=='tensor-place':
            print(json.dumps(ServiceTensorPlanner().plan(json.loads(args.requirements_json),json.loads(args.capacities_json)),indent=2));return 0
        if args.command=='resource-load':
            print(json.dumps(dimensionless_load(json.loads(args.requirements_json),json.loads(args.capacity_json)),indent=2));return 0
        if args.command=='doctor':
            info={'version':'1.0.0','os':platform.platform(),'python':sys.version,'logical_cores':os.cpu_count(),
                  'syntax_families':len(load_catalog()),'emitters':len(TARGETS),
                  'native_toolchains':{lang:tool_available(lang) for lang in TARGETS},'data_root':str(Store().root),'resources':discover()}
            if args.json:print(json.dumps(info,indent=2))
            else:
                for key,v in info.items():print(f'{key}: {v}')
            return 0
        if args.command=='ir':
            doc=lower(Path(args.file).read_text(encoding='utf8'));payload=json.dumps(doc,ensure_ascii=False,indent=2)
            if args.output:Path(args.output).write_text(payload,encoding='utf8');print('Saved',args.output)
            else:print(payload)
            return 0
        if args.command=='syntax-validate':
            source=Path(args.file).read_text(encoding='utf8')
            result=validate_syntax(source,args.language)
            print(json.dumps(result,indent=2))
            return 0 if result['valid'] else 2
        if args.command=='check-contracts':
            raw=Path(args.file).read_text(encoding='utf8')
            if len(raw.encode('utf8'))>320000:raise ValueError('Project file exceeds size limit')
            result=validate_contracts(json.loads(raw))
            data=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(data+'\n',encoding='utf8');print('Saved',args.output)
            else:print(data)
            return 0 if result['valid'] else 2
        if args.command in ('type-check','type-check-project'):
            source=link_project_file(args.file)['source'] if args.command=='type-check-project' else Path(args.file).read_text(encoding='utf8')
            result=check_types(source);data=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(data+'\n',encoding='utf8');print('Saved',args.output)
            else:print(data)
            return 0 if result['error_count']==0 else 2
        if args.command=='link-project':
            result=link_project_file(args.file)
            source=result.pop('source')
            if args.output:Path(args.output).write_text(source,encoding='utf8')
            print(json.dumps({**result,'output_file':args.output,'linked_bytes':len(source.encode('utf8'))},indent=2))
            return 0
        if args.command=='verify-project':
            if not args.i_approve_native:raise LinkError('Native toolchain launch requires --i-approve-native')
            linked=link_project_file(args.file)
            output=verify(linked['source'],args.target)
            print(json.dumps({'link_sha256':linked['output_sha256'],'dependency_order':linked['order'],'native_result':output},indent=2))
            return 0 if output['status']=='passed' else 2
        if args.command in ('universal-route','collapse-success-all','universal-export'):
            source=Path(args.file).read_text(encoding='utf8')
            if args.command=='universal-export':
                report=export_portable(source,args.target,args.output)
            elif args.command=='universal-route':
                report=universal_route(source,args.target,allow_native=args.allow_native)
            else:
                if not args.i_approve_native:
                    raise UniversalError('Actual native probes require --i-approve-native')
                selected=tuple(t.strip() for t in args.targets.split(',') if t.strip())
                report=collapse_success_all(source,targets=selected)
            if args.command!='universal-export' and args.output:
                Path(args.output).write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
                summary={k:v for k,v in report.items() if k not in ('ir','reference_output','native_generated')}
                print(json.dumps({**summary,'report_saved':args.output},indent=2))
            else:
                print(json.dumps(report,indent=2))
            return 0
        if args.command=='semantic-plugins':
            result=Registry().report();output=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(output+'\n',encoding='utf8');print('Saved',args.output)
            else:print(output)
            return 0
        if args.command=='qualify-arrays':
            selected=[x.strip() for x in args.targets.split(',') if x.strip()]
            result=array_qualification(targets=selected);output=json.dumps(result,indent=2)
            if args.output:Path(args.output).write_text(output+'\n',encoding='utf8');print('Saved',args.output)
            else:print(output)
            return 0 if result['all_passed'] else 2
        if args.command=='qualify':
            langs=[x.strip() for x in args.targets.split(',') if x.strip()] or None
            doc=qualification_report(langs,include_catalog=not args.no_profiles)
            payload=json.dumps(doc,ensure_ascii=False,indent=2)
            if args.output:Path(args.output).write_text(payload,encoding='utf8');print('Saved',args.output)
            else:print(payload)
            return 0
        if args.command=='vision-inspect':
            print(json.dumps(inspect_image(args.file),indent=2));return 0
        if args.command=='simulate':
            if args.model=='decay':result=simulate_decay(seconds=args.seconds,steps=args.steps)
            else:result=simulate_damper(seconds=args.seconds,steps=args.steps)
            print(json.dumps(result,indent=2));return 0
        if args.command=='recovered-list':
            print(json.dumps(bundled_sources(),indent=2));return 0
        if args.command=='recovered-stage':
            data=Store(args.data).root
            items=SOURCES if args.component=='all' else [args.component]
            print(json.dumps([stage_component(name,data) for name in items],indent=2));return 0
        if args.command=='recovered-bridge-run':
            return run_bridge_v3(Store(args.data).root,port=args.port,allow=args.i_allow_launch)
        if args.command=='recovered-native':
            result=native_v031_run(args.file,Store(args.data).root,runarg=args.arg,timeout=args.timeout,allow=args.i_allow_native)
            print(json.dumps(result,indent=2));return 0 if result.get('verified') and result.get('status') in ('compiled','executed') else 2
        if args.command=='recovered-health':
            if args.component=='bridge':result=bridge_status(url=args.url or 'http://127.0.0.1:8766')
            elif args.component=='shadow':result=shadow_health(args.url or 'http://127.0.0.1:8767',allow_unauthenticated=args.i_allow_unauthenticated_sdk)
            else:result=emovision_health(args.url or 'http://127.0.0.1:8774',allow_unauthenticated=args.i_allow_unauthenticated_sdk)
            print(json.dumps(result,indent=2));return 0 if result.get('connected') else 2
        if args.command=='integrations':
            print(json.dumps(integration_status(args.roots if args.roots else None,args.probe_local_bridge),indent=2));return 0
        if args.command=='flow':
            x=Fabric(workers=args.workers).execute(args.file,allow_native=args.i_allow_native,use_cache=not args.no_cache)
            print(json.dumps(x,indent=2));return 0 if x['success'] else 2
        if args.command=='detect':print(json.dumps(detect(args.file),indent=2));return 0
        if args.command=='native-info':print(json.dumps(AdapterRegistry().info(args.language),indent=2));return 0
        if args.command=='native-configure':print(json.dumps(AdapterRegistry().configure(args.language,json.loads(args.argv_json)),indent=2));return 0
        if args.command=='native-run':
            x=AdapterRegistry().run(args.language,args.file,allow=args.i_allow_execution,timeout=args.timeout)
            print(json.dumps(x,indent=2));return 0 if x['status']=='success' else 2
        if args.command=='ai-transpile':
            result=ai_transpile(Path(args.file).read_text(encoding='utf8'),args.target,args.model)
            Path(args.output).write_text(result['code'],encoding='utf8');result.pop('code')
            print(json.dumps(result,indent=2));return 0
        if args.command=='pack':
            m=package(args.folder,args.output);print(json.dumps({'created':args.output,'files':len(m['files'])}));return 0
        if args.command=='verify-pack':print(json.dumps(verify_package(args.file)));return 0
        if args.command=='bench':
            n=max(1,min(10000,args.iterations));source='let v = 0\nfor i in range(100):\n    v += i\nassert v == 4950\n';t=time.perf_counter()
            for _ in range(n):Interpreter().run(source)
            elapsed=time.perf_counter()-t
            print(json.dumps({'iterations':n,'elapsed_seconds':round(elapsed,4),'programs_per_second':round(n/elapsed,1),'note':'local USL subset benchmark; not a comparison to other runtimes'}));return 0
        text=Path(args.file).read_text(encoding='utf8')
        if args.command=='check':parse(text);print('Valid supported USL subset');return 0
        if args.command=='run':
            r=Interpreter().run(text)
            if args.json:print(json.dumps(r.__dict__,default=str,indent=2))
            else:print(r.output,end='')
            return 0
        if args.command=='transpile':
            g=transpile(text,args.target)
            if args.output:Path(args.output).write_text(g.code,encoding='utf8');print('Saved',args.output)
            else:print(g.code,end='')
            return 0
        if args.command=='verify':
            r=verify(text,args.target);print(json.dumps(r,indent=2));return 0 if r['status']=='passed' else 2
    except (USLError,LegacyError,EquationError,CustomEquationError,CollapseError,FractalError,IncrementalError,OSError,ValueError,ImportError) as e:print(f'USL ERROR: {e}',file=sys.stderr);return 1
    return 1

if __name__=='__main__':raise SystemExit(main())
