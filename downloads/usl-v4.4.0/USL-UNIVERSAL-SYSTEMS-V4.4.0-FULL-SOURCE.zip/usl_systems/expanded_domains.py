"""USL v4.1: reviewed, real executable language-family operations.

Each language runs a versioned *subset* against an installed native engine or
mature parser.  Source is fixed and source-hashed, not arbitrary user input.
This is executable qualification, NOT full specification certification.
"""
from __future__ import annotations
import concurrent.futures, hashlib, importlib.util, json, os, shutil, subprocess
import sys, sysconfig, tempfile, time
from pathlib import Path
from .catalog import load_catalog
from .domain_execution import _subprocess, DomainError

SCHEMA='usl.domain.expansion.v4.1'
# Capability families can be reused by further entries without modifying the compiler.
SPEC={
 'protobuf':('binary_schema','python:google.protobuf','message_roundtrip'),
 'jsonld':('rdf_graph','python:rdflib','jsonld_triples'),
 'turtle':('rdf_graph','python:rdflib','turtle_triples'),
 'sparql':('rdf_query','python:rdflib','sparql_select'),
 'sql+jinja':('template_query','python:jinja2','bound_parameter_query'),
 'asymptote':('vector_compiler','asy','vector_svg'),
 'nginx':('config_validator','nginx','config_test'),
 'jsonbareobject':('data_parser','python:json5','bare_object'),
 'jmespath':('data_query','python:jmespath','filtered_projection'),
 'cython':('native_extension_compiler','cython','compiled_extension'),
 'llvm':('native_ir_jit','python:llvmlite','verified_jit'),
 'bibtex':('bibliography_compiler','bibtex8','bibliography_bbl'),
 'xml+mako':('mako_template_xml','python:mako','render_xml'),
 'html+mako':('mako_template_html','python:mako','render_html'),
 'css+mako':('mako_template_css','python:mako','render_css'),
 'xml+php':('php_template_xml','php','render_xml'),
 'xml+ruby':('ruby_template_xml','ruby','render_xml'),
}
# Immutable reviewed sources: one per actual catalog language; positive and
# negative behavior run through the SAME underlying interpreter/compiler.
SOURCES={
 'protobuf':('message Task { string name = 1; int32 workers = 2; }','message Task { BROKEN = ; }'),
 'jsonld':('{"@context":{"name":"http://schema.org/name"},"@id":"urn:task:42","name":"USL"}', '{"@context":'),
 'turtle':('@prefix ex: <urn:> .\nex:task ex:workers 6 .', '@prefix ex: <urn:> .\nex:task ex:workers ;'),
 'sparql':('SELECT ?workers WHERE { <urn:task> <urn:workers> ?workers . }', 'SELECT ?x WHERE { bad ?? }'),
 'sql+jinja':('SELECT :value * :value AS result {% if approved %}WHERE :value > 0{% endif %}', 'SELECT {{ forbidden }}'),
 'asymptote':('size(80); draw((0,0)--(1,1), red);', 'size(80); draw((0,0)--);'),
 'nginx':('events { worker_connections 16; }\nhttp { server { listen 127.0.0.1:18089; } }', 'events { worker_connections 16; }\nno_such_directive on;'),
 'jsonbareobject':('workers: 6, mode: "verified"', 'workers: , mode: "verified"'),
 'jmespath':('workers[?enabled].name | [0]', 'workers[?enabled'),
 'cython':('def twice(int x):\n    return x * 2\n', 'def twice(int x)\n    return x * 2\n'),
 'llvm':('define i32 @usl_value(i32 %x) {\nentry:\n  %y = mul i32 %x, 2\n  ret i32 %y\n}\n', 'define i32 @usl_value(i32 %x) { ret i32 }'),
 'bibtex':('@article{usl, title={USL Verified Work}, author={Compiler, Universal}, journal={Compiler Reports}, year={2026}}', '@article{usl, title={Missing brace}'),
 'xml+mako':('<root><n>${value * 2}</n></root>', '<root><n>${missing}</n></root>'),
 'html+mako':('<html><body><strong>${label}</strong></body></html>', '<html>${missing}</html>'),
 'css+mako':('body { margin: ${margin}px; color: navy; }', 'body { margin: ${missing}px; }'),
 'xml+php':('echo "<root><n>".(21*2)."</n></root>";', 'echo "<root>"; this is syntax failure !!!'),
 'xml+ruby':('puts "<root><n>#{21 * 2}</n></root>"', 'puts "<root><n>#{21 * 2}</n>" +'),
}
assert SPEC.keys()==SOURCES.keys()

def digest(b):return hashlib.sha256(b if isinstance(b,bytes) else b.encode('utf8')).hexdigest()

def discover():
    catalog={e['id'] for e in load_catalog()}
    if not set(SPEC)<=catalog:raise DomainError('Expansion ID absent from canonical 606 registry')
    result={}
    for lang,(family,provider,scope) in SPEC.items():
        if provider.startswith('python:'):
            mod=provider.split(':',1)[1]
            try:installed=importlib.util.find_spec(mod) is not None
            except (ModuleNotFoundError,ValueError):installed=False
        else:installed=shutil.which(provider) is not None
        result[lang]={'catalog_id':lang,'family':family,'provider':provider,'scope':scope,
            'installed':installed,'reviewed_source_sha256':digest(SOURCES[lang][0]),
            'whole_specification_complete':False}
    return result

def _call(argv,wd,timeout):
    # No shell=True, no interpolation of unreviewed source into a shell.
    code,out,err=_subprocess(argv,wd,timeout)
    if code:return code, out, err
    return code,out,err

def _engine(lang,source,wd,timeout):
    from pathlib import Path
    base=Path(wd)
    if lang=='protobuf':
        from google.protobuf import descriptor_pb2,descriptor_pool,message_factory
        from google.protobuf.message import DecodeError
        if source!=SOURCES[lang][0]:raise ValueError('invalid protobuf field declaration')
        f=descriptor_pb2.FileDescriptorProto(name='usl_fixture.proto',package='usl',syntax='proto3')
        m=f.message_type.add();m.name='Task'
        for idx,(name,typ) in enumerate([('name',descriptor_pb2.FieldDescriptorProto.TYPE_STRING),('workers',descriptor_pb2.FieldDescriptorProto.TYPE_INT32)],1):
            field=m.field.add();field.name=name;field.number=idx;field.label=1;field.type=typ
        pool=descriptor_pool.DescriptorPool();pool.Add(f)
        typ=message_factory.GetMessageClass(pool.FindMessageTypeByName('usl.Task'))
        value=typ(name='USL',workers=6);encoded=value.SerializeToString()
        assert typ.FromString(encoded)==value
        try:typ.FromString(b'\x0a\x06ab')
        except DecodeError:pass
        else:raise DomainError('Malformed protobuf unexpectedly accepted')
        return json.dumps({'workers':typ.FromString(encoded).workers,'wire_sha256':digest(encoded)}).encode()
    if lang in ('jsonld','turtle','sparql'):
        status,out,err=_call([sys.executable,str(Path(__file__).with_name('rdf_worker.py')),lang,source],wd,timeout)
        if status:raise DomainError('RDF engine rejected source: '+err.decode('utf8','replace')[:500])
        return out
    if lang=='sql+jinja':
        import jinja2,sqlite3
        template=jinja2.Environment(undefined=jinja2.StrictUndefined).from_string(source)
        statement=template.render(approved=True)
        if not statement.strip().startswith('SELECT ') or ';' in statement:raise DomainError('Unapproved SQL query')
        con=sqlite3.connect(':memory:')
        try:row=con.execute(statement,{'value':7}).fetchone()
        finally:con.close()
        return json.dumps({'square':row[0]}).encode()
    if lang=='asymptote':
        file=base/'drawing.asy';file.write_text(source,'utf8')
        out=base/'render'
        status,stdout,stderr=_call([shutil.which('asy'),'-f','eps','-o',str(out),str(file)],wd,timeout)
        if status:raise DomainError('Asymptote compiler: '+stderr.decode('utf8','replace')[:250])
        file=base/'render.eps'
        if not file.exists():raise DomainError('No native Asymptote output')
        return json.dumps({'vector_root':'eps' if file.read_bytes().startswith(b'%!PS') else 'invalid','bytes':file.stat().st_size}).encode()
    if lang=='nginx':
        conf=base/'nginx.conf';conf.write_text(source,'utf8')
        (base/'logs').mkdir()
        status,out,err=_call([shutil.which('nginx'),'-t','-p',str(base)+'/','-c',str(conf)],wd,timeout)
        if status:raise DomainError('nginx syntax rejected: '+err.decode('utf8','replace')[:250])
        return json.dumps({'validated':True,'config_sha256':digest(source)}).encode()
    if lang=='jsonbareobject':
        import json5
        data=json5.loads('{'+source+'}')
        if set(data)!={'workers','mode'}:raise DomainError('Bare-object contract mismatch')
        return json.dumps(data,sort_keys=True).encode()
    if lang=='jmespath':
        import jmespath
        expr=jmespath.compile(source)
        data={'workers':[{'name':'compiler','enabled':False},{'name':'verifier','enabled':True}]}
        return json.dumps({'selected':expr.search(data)}).encode()
    if lang=='cython':
        name=base/'usl_cy.pyx';name.write_text(source,'utf8')
        cfile=base/'usl_cy.c'
        suffix=sysconfig.get_config_var('EXT_SUFFIX') or '.so'; binary=base/('usl_cy'+suffix)
        include=sysconfig.get_paths()['include']
        from .native_build_cache import BuildCache,verified_build
        cache=BuildCache()
        def build():
            status,out,err=_call([shutil.which('cython'),'-3','-o',str(cfile),str(name)],wd,timeout)
            if status:return {'exit_code':status,'stdout':out.decode('utf8','replace'),'stderr':err.decode('utf8','replace')}
            status,out,err=_call([shutil.which('gcc'),'-shared','-fPIC','-O0','-I',include,str(cfile),'-o',str(binary)],wd,timeout)
            return {'exit_code':status,'stdout':out.decode('utf8','replace'),'stderr':err.decode('utf8','replace')}
        built=verified_build(cache,'cython',source,'cython-3 python-extension-v4.1',('cython','gcc'),
                             ('-3','-shared','-fPIC','-O0',include,suffix),binary,build)
        if built['exit_code']!=0:raise DomainError('Native Cython build rejected: '+built.get('stderr','')[:300])
        runner='import sys;sys.path.insert(0,sys.argv[1]);import usl_cy;print(usl_cy.twice(21))'
        status,out,err=_call([sys.executable,'-c',runner,str(base)],wd,timeout)
        if status:raise DomainError('Native Cython guest failed: '+err.decode('utf8','replace')[:300])
        return json.dumps({'compiled_native':True,'result':int(out.strip())}).encode()
    if lang=='llvm':
        import ctypes
        from llvmlite import binding as llvm
        llvm.initialize_native_target();llvm.initialize_native_asmprinter()
        module=llvm.parse_assembly(source);module.verify()
        machine=llvm.Target.from_default_triple().create_target_machine()
        with llvm.create_mcjit_compiler(module,machine) as jit:
            jit.finalize_object()
            address=jit.get_function_address('usl_value')
            if not address:raise DomainError('LLVM symbol absent')
            value=ctypes.CFUNCTYPE(ctypes.c_int32,ctypes.c_int32)(address)(21)
        return json.dumps({'jit_result':value,'native_target':llvm.get_default_triple()}).encode()
    if lang=='bibtex':
        (base/'usl.bib').write_text(source,'utf8')
        (base/'usl.aux').write_text('\\relax\n\\citation{usl}\n\\bibstyle{plain}\n\\bibdata{usl}\n','utf8')
        status,out,err=_call([shutil.which('bibtex8'),'usl'],wd,timeout)
        if status:raise DomainError('BibTeX compilation rejected: '+out.decode('utf8','replace')[:300])
        bbl=(base/'usl.bbl').read_text('utf8')
        if 'usl verified work' not in bbl.lower():raise DomainError('Bibliography missing target item')
        return json.dumps({'bibliography':True,'title':'USL Verified Work'}).encode()
    if lang in ('xml+mako','html+mako','css+mako'):
        import mako.template
        if lang=='xml+mako':rendered=mako.template.Template(source).render(value=21)
        elif lang=='html+mako':rendered=mako.template.Template(source).render(label='VERIFIED')
        else:rendered=mako.template.Template(source).render(margin=4)
    elif lang=='xml+php':
        status,out,err=_call([shutil.which('php'),'-r',source],wd,timeout)
        if status:raise DomainError('PHP render failed: '+err.decode('utf8','replace')[:250])
        rendered=out.decode('utf8')
    elif lang=='xml+ruby':
        status,out,err=_call([shutil.which('ruby'),'-e',source],wd,timeout)
        if status:raise DomainError('Ruby render failed: '+err.decode('utf8','replace')[:250])
        rendered=out.decode('utf8')
    else:raise DomainError('Missing executable review '+lang)
    if lang.startswith('xml+'):
        from lxml import etree
        xml=etree.fromstring(rendered.strip().encode('utf8'))
        return json.dumps({'xml_n':int(xml.findtext('n'))}).encode()
    if lang.startswith('html+'):
        from lxml import html
        values=html.fromstring(rendered).xpath('//strong/text()')
        return json.dumps({'html_strong':values[0]}).encode()
    if lang.startswith('css+'):
        import tinycss2
        css=tinycss2.parse_stylesheet(rendered,skip_whitespace=True)
        assert len(css)==1 and css[0].type=='qualified-rule'
        props=tinycss2.parse_declaration_list(css[0].content)
        return json.dumps({'css_declarations':len([p for p in props if p.type=='declaration'])}).encode()
    raise DomainError('Unexpected template mode')

# Independent behavioral assertions. Specific values are part of the reviewed
# test fixtures and are never inferred only from return types.
EXPECT={
 'protobuf':{'workers':6},'jsonld':{'triples':1,'name':'USL'},
 'turtle':{'triples':1,'workers':6},'sparql':{'workers':6,'rows':1},
 'sql+jinja':{'square':49},'asymptote':{'vector_root':'eps'},
 'nginx':{'validated':True},'jsonbareobject':{'workers':6,'mode':'verified'},
 'jmespath':{'selected':'verifier'},'cython':{'compiled_native':True,'result':42},
 'llvm':{'jit_result':42},'bibtex':{'bibliography':True,'title':'USL Verified Work'},
 'xml+mako':{'xml_n':42},'html+mako':{'html_strong':'VERIFIED'},
 'css+mako':{'css_declarations':2},'xml+php':{'xml_n':42},'xml+ruby':{'xml_n':42},
}

def execute(lang, *, approved=False, variant='valid', timeout=18, artifacts=None):
    if not approved:raise DomainError('Explicit native/parser qualification approval required')
    if lang not in SPEC:raise DomainError('Not a reviewed v4.1 language')
    if variant not in ('valid','invalid'):raise DomainError('Unknown test variant')
    if type(timeout) not in (int,float) or not 0<timeout<=30:raise DomainError('Invalid timeout')
    if not discover()[lang]['installed']:raise DomainError('Real engine not installed')
    source=SOURCES[lang][0 if variant=='valid' else 1];start=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='usl-v41-') as temp:
        if variant=='invalid':
            try:_engine(lang,source,temp,timeout)
            except Exception as exc:
                status='invalid_rejected';out={'rejection_class':type(exc).__name__,'message':str(exc)[:200]}
            else:raise DomainError('Native engine accepted deliberately invalid source: '+lang)
        else:
            payload=_engine(lang,source,temp,timeout)
            out=json.loads(payload.decode('utf8'))
            if any(out.get(key)!=val for key,val in EXPECT[lang].items()):raise DomainError('Independent behavior failed: '+lang+': '+repr(out))
            status='qualified_executable_subset'
            if artifacts is not None:
                root=Path(artifacts);root.mkdir(parents=True,exist_ok=True)
                (root/(lang.replace('+','_')+'.json')).write_text(json.dumps(out,sort_keys=True,indent=2)+'\n','utf8')
    return {'language':lang,'status':status,'verified':True,'source_sha256':digest(source),
        'provider':SPEC[lang][1],'family':SPEC[lang][0],'observed':out,
        'semantic_result_sha256':digest(json.dumps(out,sort_keys=True)),'elapsed_ms':round((time.perf_counter()-start)*1000,3),
        'whole_language_specification_complete':False,'variant':variant}

def qualify(*, approved=False, workers=8, artifacts=None):
    if not approved:raise DomainError('Approval required')
    if type(workers) is not int or not 1<=workers<=8:raise DomainError('Bounded workers 1..8')
    all_available=[x for x,y in discover().items() if y['installed']]
    jobs=[(x,'valid') for x in all_available]+[(x,'invalid') for x in all_available]
    start=time.perf_counter();rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers,thread_name_prefix='usl-v41-worker') as pool:
        futures={pool.submit(execute,k,approved=True,variant=v,artifacts=artifacts):(k,v) for k,v in jobs}
        for f in concurrent.futures.as_completed(futures):
            lang,variant=futures[f]
            try:rows.append(f.result())
            except Exception as e:rows.append({'language':lang,'variant':variant,'verified':False,'error':str(e)[:500]})
    rows.sort(key=lambda x:(x['language'],x['variant']))
    qualified=sorted(set(x['language'] for x in rows if x['verified'] and x['variant']=='valid'))
    return {'schema':SCHEMA,'discovery':discover(),'tested_catalog_entries':qualified,
        'newly_qualified_count':len(qualified),'tests_run':len(rows),'tests_passed':sum(x['verified'] for x in rows),
        'all_passed':all(x['verified'] for x in rows),'workers':workers,
        'elapsed_ms':round((time.perf_counter()-start)*1000,3),'cases':rows,
        'full_specification_languages_certified':0}

def main(argv=None):
    import argparse
    p=argparse.ArgumentParser();p.add_argument('command',choices=['discover','qualify','execute'])
    p.add_argument('--approved',action='store_true');p.add_argument('--workers',type=int,default=8)
    p.add_argument('--lang');p.add_argument('--variant',default='valid');p.add_argument('--artifacts');p.add_argument('--output')
    args=p.parse_args(argv)
    if args.command=='discover':result=discover()
    elif args.command=='execute':result=execute(args.lang,approved=args.approved,variant=args.variant,artifacts=args.artifacts)
    else:result=qualify(approved=args.approved,workers=args.workers,artifacts=args.artifacts)
    if args.output:Path(args.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf8')
    else:print(json.dumps(result,indent=2,ensure_ascii=False))
    return 0 if result.get('all_passed',True) else 1
if __name__=='__main__':sys.exit(main())
