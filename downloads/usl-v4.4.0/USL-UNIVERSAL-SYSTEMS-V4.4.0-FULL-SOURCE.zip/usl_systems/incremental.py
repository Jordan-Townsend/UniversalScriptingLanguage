"""USL Collapse-Success-All: exact result reuse and algebraically proven partial recompute.

Physical-work avoided is evaluated operations on input elements, not imaginary
CPUs, cached answers or a claim about inference speed. All numeric values are
bounded integers so algebraic proofs are exact, without FP reassociation.
"""
from __future__ import annotations
import hashlib,json,time
from .fractal import _work,OPERATORS,FractalError

class IncrementalError(ValueError):pass

def _fingerprint(values,operator):
    return hashlib.sha256(json.dumps([operator,values],separators=(',',':')).encode()).hexdigest()

def _delta_work(op,before,after):
    if op=='sum':return after-before
    if op=='sum_squares':return after*after-before*before
    if op=='sum_abs':return abs(after)-abs(before)
    if op=='sum_even':return (after if after%2==0 else 0)-(before if before%2==0 else 0)
    if op=='histogram':return {before:-1,after:1} if before!=after else {}
    raise IncrementalError('Unknown operator')

class CollapseCompute:
    """Stateful exact cached computation with safe incremental update modes.

    initialize() establishes full authority. update() uses an integer identity
    on changed indices. audit=True compares full authority each time. audit=False
    uses mathematical identity, not blind approximation, and never claims runtime
    proof where a baseline hasn't run.
    """
    def __init__(self,operator='sum_squares',max_items=500_000):
        if operator not in OPERATORS:raise IncrementalError('Unsupported pure operator')
        self.operator=operator;self.max_items=max_items;self.values=None;self.output=None;self.digest=None
        self.records=[]

    def initialize(self,values):
        if not isinstance(values,(list,tuple)) or len(values)>self.max_items or any(type(x)!=int or abs(x)>10**12 for x in values):
            raise IncrementalError('Expected bounded array of integers')
        now=time.perf_counter();self.values=list(values);self.output=_work(self.operator,self.values)
        self.digest=_fingerprint(self.values,self.operator)
        return self._record('H0_FULL',len(self.values),len(self.values),now,True,False)

    def _record(self,mode,logical_work,physical_work,started,correct,audited):
        rec={'mode':mode,'operator':self.operator,'fingerprint':self.digest,
             'value':self.output,'logical_work_items':logical_work,
             'physical_work_items':physical_work,'avoided_work_items':logical_work-physical_work,
             'avoided_work_fraction':(logical_work-physical_work)/max(1,logical_work),
             'elapsed_ms':round((time.perf_counter()-started)*1000,5),
             'correct':correct,'audited_against_full':audited,
             'proof':'exact bounded integer algebra / literal input digest'}
        self.records.append(rec);return rec

    def update(self,changes=None,audit=True):
        if self.values is None:raise IncrementalError('Call initialize first')
        if not isinstance(changes,(dict,type(None))):raise IncrementalError('Changes must map integer indexes to values')
        changes=changes or {}
        if len(changes)>len(self.values):raise IncrementalError('Too many changes')
        for k,v in changes.items():
            if type(k)!=int or k<0 or k>=len(self.values) or type(v)!=int or abs(v)>10**12:
                raise IncrementalError('Invalid bounded index or value')
        now=time.perf_counter();n=len(self.values)
        effective={k:v for k,v in changes.items() if self.values[k]!=v}
        original={k:self.values[k] for k in effective}
        if not effective:
            label='H1_EXACT_REUSE';new=self.output
        else:
            label='H2_PARTIAL_DELTA';new=self.output.copy() if isinstance(self.output,dict) else self.output
            for index,after in effective.items():
                before=self.values[index]
                if self.operator=='histogram':
                    if before==after:continue
                    new[before]-=1
                    if new[before]==0:del new[before]
                    new[after]=new.get(after,0)+1
                else:new+=_delta_work(self.operator,before,after)
            for index,after in effective.items():self.values[index]=after
        old=self.output;old_digest=self.digest
        self.output=new;self.digest=_fingerprint(self.values,self.operator)
        if audit:
            observed=_work(self.operator,self.values)
            if observed!=self.output:
                # Roll back the transaction before reporting inconsistency.
                for index in effective:self.values[index]=original[index]
                self.output=old;self.digest=old_digest
                raise IncrementalError('Full authority disagreed with incremental result')
        return self._record(label,n,len(effective)+(n if audit else 0),now,True,audit)

    def snapshot(self):
        if self.values is None:raise IncrementalError('Not initialized')
        return {'operator':self.operator,'size':len(self.values),'digest':self.digest,
                'current_value':self.output,'updates':len(self.records)-1,
                'last':self.records[-1]}
