"""USL v3.8: versioned reviewed guest adapter registry and native executor.

Registry manifests declare REAL runnable guest code with hashes, argument types,
argv-list launch contracts, expected behavioral operation, and output protocols.
Never treat this as a full language compiler or as an untrusted-code sandbox.
"""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import tempfile
import time
from .catalog import load_catalog

ROOT=Path(__file__).resolve().parents[1]
ADAPTER_PATH=ROOT/'guest_adapters'
ABI='usl.bridge.abi.v1'
ID=re.compile(r'^[a-z][a-z0-9_-]{0,63}$')
FILE=re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$')
class AdapterError(ValueError):pass

def _digest(v):return hashlib.sha256(v.encode('utf8') if isinstance(v,str) else v).hexdigest()
def _canonical(o):return json.dumps(o,sort_keys=True,allow_nan=False,separators=(',',':'),ensure_ascii=False)

def load_registry(root=ROOT):
    base=Path(root)/'guest_adapters'
    catalog={r['id'] for r in load_catalog()}
    result={}
    for file in sorted(base.glob('*.json')):
        d=json.loads(file.read_text('utf8'))
        keys={'schema','id','family','runtime','file','argv','source','source_sha256','params','returns','export',
              'output','result_file','operation','fixture_args','fixture_expected','validated_scope','permissions'}
        if not isinstance(d,dict) or set(d)!=keys:raise AdapterError('Invalid adapter schema keys: '+file.name)
        lang=d['id']
        if d['schema']!='usl.guest.adapter.v1' or not isinstance(lang,str) or not ID.fullmatch(lang) or lang not in catalog or file.stem!=lang:
            raise AdapterError('Unrecognized catalog adapter '+str(lang))
        if lang in result:raise AdapterError('Duplicate adapter')
        if d['family'] not in ('general_purpose','build_language','dsl','query_language'):
            raise AdapterError('Unsupported adapter category')
        if not isinstance(d['runtime'],str) or not FILE.fullmatch(d['runtime']):raise AdapterError('Invalid runtime')
        if not isinstance(d['file'],str) or not FILE.fullmatch(d['file']):raise AdapterError('Unsafe source filename')
        if not isinstance(d['argv'],list) or not 1<=len(d['argv'])<=12 or d['argv'][0]!=d['runtime']:
            raise AdapterError('Invalid process argument list')
        if any(type(x) is not str or not 1<=len(x)<=100 or not re.fullmatch(r'[A-Za-z0-9_.\-/]+',x)
               for x in d['argv']):raise AdapterError('Unsafe argv token')
        if d['file'] not in d['argv']:raise AdapterError('Source must be explicit argv item')
        if not isinstance(d['source'],str) or not 10<=len(d['source'])<=16000 or _digest(d['source'])!=d['source_sha256']:
            raise AdapterError('Source hash mismatch')
        if d['params']!=['i64'] or d['returns']!='i64' or d['export']!='transform':
            raise AdapterError('Unsupported registry bridge signature')
        if d['output'] not in ('json_stdout','json_file'):raise AdapterError('Unsafe protocol')
        if d['output']=='json_file' and (d['result_file']!='result.json' or d['result_file'] not in d['source']):
            raise AdapterError('Unsupported output file')
        if d['operation'].get('kind')!='add' or type(d['operation'].get('constant')) is not int or abs(d['operation']['constant'])>1000:
            raise AdapterError('Unknown operation oracle')
        if d['fixture_args']!=[41] or d['fixture_expected']!=41+d['operation']['constant']:
            raise AdapterError('Wrong positive fixture')
        result[lang]=d
    return result

def discovered(root=ROOT):
    return {k:{'catalog_id':k,'toolchain_present':bool(shutil.which(d['runtime'])),
               'toolchain':shutil.which(d['runtime']),'family':d['family'],
               'source_sha256':d['source_sha256'],'scope':d['validated_scope']}
            for k,d in load_registry(root).items()}

def run_adapter(language,argument,*,authorized=False,root=ROOT,timeout=8):
    if not authorized:raise AdapterError('Explicit approval required before foreign language execution')
    if type(argument) is not int or abs(argument)>1_000_000_000:
        raise AdapterError('Only bounded i64 input is supported')
    if type(timeout) not in (int,float) or not 0<timeout<=20:raise AdapterError('Timeout 0..20 seconds')
    registry=load_registry(root)
    if language not in registry:raise AdapterError('No registered executable adapter: '+str(language))
    d=registry[language];executable=shutil.which(d['runtime'])
    if not executable:raise AdapterError('Toolchain unavailable: '+d['runtime'])
    started=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='usl-adapter-'+language+'-') as temp:
        folder=Path(temp)
        (folder/d['file']).write_text(d['source'],encoding='utf8')
        argv=[executable,*d['argv'][1:]]
        env=os.environ.copy();env['USL_ARG0']=str(argument)
        try:
            proc=subprocess.run(argv,cwd=folder,env=env,stdin=subprocess.DEVNULL,
                capture_output=True,text=True,encoding='utf8',timeout=timeout,check=False)
        except subprocess.TimeoutExpired as exc:raise AdapterError('Native guest process timed out') from exc
        if proc.returncode!=0:raise AdapterError('Native guest exit '+str(proc.returncode)+': '+proc.stderr[-450:])
        if d['output']=='json_file':
            result=folder/d['result_file']
            if not result.is_file() or result.stat().st_size>16_384:raise AdapterError('Missing/oversized output file')
            body=result.read_text('utf8')
        else:body=proc.stdout.strip()
        if len(body)>16_384:raise AdapterError('Oversized guest output')
        try:obj=json.loads(body)
        except ValueError as exc:raise AdapterError('Native guest did not return valid JSON ABI') from exc
    if type(obj) is not dict or set(obj)!={'abi','value'} or obj.get('abi')!=ABI or type(obj['value']) is not int:
        raise AdapterError('Invalid native ABI data/type')
    expected=argument+d['operation']['constant']
    if obj['value']!=expected:raise AdapterError('Independent numeric oracle mismatch')
    return {'status':'observed_success','catalog_id':language,'family':d['family'],'input':argument,
        'observed':obj['value'],'expected':expected,'source_sha256':d['source_sha256'],
        'runtime':d['runtime'],'toolchain_path':executable,'argv_program':Path(executable).name,
        'exit_code':proc.returncode,'stdout_sha256':_digest(proc.stdout),'stderr_tail':proc.stderr[-200:],
        'elapsed_ms':round((time.perf_counter()-started)*1000,3),
        'claim':'verified reviewed source fixture subset; not full language semantics or sandbox'}

def qualify_registry(*,authorized=False,workers=4,root=ROOT,arguments=(41,5,-3)):
    if not authorized:raise AdapterError('Approval required')
    if type(workers) is not int or not 1<=workers<=16:raise AdapterError('Workers must be 1..16')
    entries=load_registry(root)
    jobs=[(k,arg) for k in sorted(entries) for arg in arguments]
    results=[]
    started=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers,thread_name_prefix='usl-registry') as pool:
        fut={pool.submit(run_adapter,k,arg,authorized=True,root=root):(k,arg) for k,arg in jobs}
        for f in concurrent.futures.as_completed(fut):
            key,arg=fut[f]
            try:results.append(f.result())
            except Exception as exc:results.append({'status':'failed','catalog_id':key,'input':arg,'error':str(exc)[:400]})
    results.sort(key=lambda x:(x['catalog_id'],x['input']))
    qualified={k for k in entries if all(x['status']=='observed_success' for x in results if x['catalog_id']==k)
               and len([x for x in results if x['catalog_id']==k])==len(arguments)}
    return {'schema':'usl.adapter.batch.v1','catalog_size':606,'tested_adapters':len(entries),
       'qualified_adapters':sorted(qualified),'tests':len(results),
       'passed':sum(x['status']=='observed_success' for x in results),'workers':workers,
       'elapsed_ms':round((time.perf_counter()-started)*1000,3),'results':results,
       'full_semantic_language_compilers_proven':0}

def execute_extended_pair(host,guest,*,authorized=False,root=ROOT):
    """Cooperate through actual host and guest execution, preserving a typed result."""
    if not authorized:raise AdapterError('Approval required')
    d=load_registry(root)
    if host not in d or guest not in d:raise AdapterError('Both endpoints require reviewed registry adapters')
    first=run_adapter(host,41,authorized=True,root=root)
    second=run_adapter(guest,first['observed'],authorized=True,root=root)
    return {'schema':'usl.registry.pair.v1','host':host,'guest':guest,'status':'observed_success',
         'first':first,'second':second,'bridge_abi':'i64 -> i64',
         'evidence_sha256':_digest(_canonical([first,second]))}

def capability_report(root=ROOT,qualifications=None):
    ids=[x['id'] for x in load_catalog()]
    entries=load_registry(root)
    qualified=set(qualifications.get('qualified_adapters',[])) if qualifications else set()
    result=[]
    for k in ids:
        d=entries.get(k)
        status=('observed_fixture_execution' if k in qualified else 'adapter_registered_unverified') if d else 'no_native_adapter_qualified'
        result.append({'id':k,'execution_status':status,
            'adapter':d['runtime'] if d else None,
            'native_semantic_completeness':'unverified',
            'next_dependency':('full conformance suite for semantics' if k in qualified else
                'real toolchain/fixture execution qualification' if d else
                'language-specific frontend/runtime adapter')})
    return {'schema':'usl.606.execution.capability.v38','count':len(result),'entries':result,
       'native_full_semantics_proven':0,
       'scope':'each of 606 accounted for; subset execution status is not language completeness'}
