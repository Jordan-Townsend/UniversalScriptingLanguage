"""Local subprocess console observer.

This monitors ONLY children intentionally launched by the user through this service;
it does not read arbitrary application consoles or evade OS permissions.
Launching native programs requires an explicit flag at the CLI and the service's
private control token. Output, exit status and a bounded tail persist in SQLite.
"""
import json
import os
import signal
import subprocess
import threading
import time
from pathlib import Path
from uuid import uuid4


class BridgeError(ValueError):
    pass


class ProcessBridge:
    def __init__(self, store, max_concurrent=4):
        self.store = store
        self.max_concurrent = max(1, min(8, int(max_concurrent)))
        self.lock = threading.RLock()
        self.active = {}
        with store.lock, store._db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS process_runs(
                id TEXT PRIMARY KEY, project TEXT NOT NULL, argv TEXT NOT NULL,
                status TEXT NOT NULL, exit_code INTEGER, started REAL NOT NULL,
                updated REAL NOT NULL, output TEXT NOT NULL DEFAULT '',
                truncated INTEGER NOT NULL DEFAULT 0, max_seconds INTEGER NOT NULL)''')
            db.execute("UPDATE process_runs SET status='interrupted', updated=? WHERE status IN ('starting','running','stopping')", (time.time(),))

    def _record(self, ident, status, exit_code=None, output=None, truncated=False):
        with self.store.lock, self.store._db() as db:
            if output is None:
                db.execute('UPDATE process_runs SET status=?,exit_code=?,updated=? WHERE id=?',
                           (status, exit_code, time.time(), ident))
            else:
                db.execute('UPDATE process_runs SET status=?,exit_code=?,updated=?,output=?,truncated=? WHERE id=?',
                           (status,exit_code,time.time(),output,int(truncated),ident))

    def _output(self, ident, output, truncated):
        with self.store.lock, self.store._db() as db:
            db.execute('UPDATE process_runs SET output=?,truncated=?,updated=? WHERE id=?',
                       (output,int(truncated),time.time(),ident))

    def launch(self, project, argv, max_seconds=300):
        if not isinstance(argv,list) or not 1 <= len(argv) <= 40 or not all(
            isinstance(a,str) and 0 < len(a) <= 2048 and '\x00' not in a for a in argv
        ):
            raise BridgeError('argv must be a nonempty array of 1–40 command arguments')
        if not isinstance(max_seconds,int) or not 1 <= max_seconds <= 3600:
            raise BridgeError('max_seconds must be between 1 and 3600')
        workspace=self.store.safe_project_path(project,'.')
        workspace.mkdir(parents=True,exist_ok=True)
        with self.lock:
            if len(self.active)>=self.max_concurrent:
                raise BridgeError('Concurrent process limit reached')
            ident=uuid4().hex[:18]
            now=time.time()
            with self.store.lock,self.store._db() as db:
                db.execute('INSERT INTO process_runs VALUES(?,?,?,?,?,?,?,?,?,?)',
                           (ident,project,json.dumps(argv),'starting',None,now,now,'',0,max_seconds))
            try:
                kwargs={'cwd':str(workspace),'stdin':subprocess.DEVNULL,
                        'stdout':subprocess.PIPE,'stderr':subprocess.STDOUT,
                        'text':True,'errors':'replace','bufsize':1}
                if os.name=='nt':
                    kwargs['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
                else:kwargs['start_new_session']=True
                proc=subprocess.Popen(argv,**kwargs)
            except (OSError,ValueError) as e:
                self._record(ident,'launch_failed',None,str(e))
                self.store.event('bridge_error',str(e),ident)
                return self.detail(ident)
            self.active[ident]=proc
            self._record(ident,'running')
            self.store.event('bridge','Started authorized child '+ident,ident)
            threading.Thread(target=self._watch,args=(ident,proc,max_seconds),daemon=True,name='usl-console-'+ident).start()
            return self.detail(ident)

    def _terminate(self,proc):
        if proc.poll() is not None:return
        if os.name=='nt':
            # taskkill /T handles a child process tree; no shell interpolation.
            try:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=6)
            except (OSError,subprocess.TimeoutExpired):proc.kill()
        else:
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:proc.kill()

    def _watch(self,ident,proc,max_seconds):
        deadline=time.monotonic()+max_seconds
        tail='';truncated=False
        # Reader never waits for a trailing newline and caps each read.
        def reader():
            nonlocal tail,truncated
            try:
                while True:
                    chunk=proc.stdout.readline(4096)
                    if not chunk:break
                    tail+=chunk
                    if len(tail)>65536:
                        tail=tail[-65536:];truncated=True
                    self._output(ident,tail,truncated)
            except (OSError,ValueError):pass
        thread=threading.Thread(target=reader,daemon=True,name='usl-output-'+ident)
        thread.start()
        timed_out=False
        try:
            while proc.poll() is None:
                if time.monotonic()>deadline:
                    timed_out=True
                    self._terminate(proc)
                    break
                time.sleep(0.1)
            thread.join(timeout=3)
            try:
                if not thread.is_alive():proc.stdout.close()
            except (OSError,ValueError):pass
            code=proc.poll()
            with self.lock:
                row=self.detail(ident)
                previous=row['status']
                status='timed_out' if timed_out else ('stopped' if previous=='stopping' else ('completed' if code==0 else 'failed'))
                self._record(ident,status,code,tail,truncated)
                self.active.pop(ident,None)
            self.store.event('bridge',f'Child {ident} -> {status} (exit {code})',ident)
        except Exception as exc:
            with self.lock:
                self._record(ident,'monitor_failed',proc.poll(),tail,truncated)
                self.active.pop(ident,None)
            self.store.event('bridge_error',f'{type(exc).__name__}: {exc}',ident)

    def stop(self,ident):
        with self.lock:
            proc=self.active.get(ident)
            if not proc:raise BridgeError('No running process with this ID')
            self._record(ident,'stopping')
        self._terminate(proc)
        return {'id':ident,'stopping':True}

    def detail(self,ident):
        with self.store.lock,self.store._db() as db:
            row=db.execute('SELECT * FROM process_runs WHERE id=?',(ident,)).fetchone()
        if not row:return None
        result=dict(row);result['argv']=json.loads(result['argv'])
        result['truncated']=bool(result['truncated'])
        return result

    def list(self,limit=40):
        with self.store.lock,self.store._db() as db:
            rows=db.execute('SELECT id FROM process_runs ORDER BY started DESC LIMIT ?', (min(100,max(1,int(limit))),)).fetchall()
        return [self.detail(row['id']) for row in rows]

    def shutdown(self):
        with self.lock:running=list(self.active.values())
        for proc in running:self._terminate(proc)
