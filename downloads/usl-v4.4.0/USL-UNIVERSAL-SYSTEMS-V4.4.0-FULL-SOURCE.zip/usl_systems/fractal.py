"""N logical partials across M named dimensionless service coordinates.

A verified finite map/reduce work decomposition, not fictitious hardware cores.
Exact integer operations are the default; optional identical-chunk CAS reuse is
proved against the authoritative serial implementation.
"""
from __future__ import annotations
import hashlib,json,math,os,statistics,time,multiprocessing
from concurrent.futures import ThreadPoolExecutor,ProcessPoolExecutor,as_completed
from dataclasses import dataclass

class FractalError(ValueError):pass
OPERATORS=('sum','sum_squares','sum_abs','sum_even','histogram')

def _work(operator,values):
    if operator=='sum':return sum(values)
    if operator=='sum_squares':return sum(x*x for x in values)
    if operator=='sum_abs':return sum(abs(x) for x in values)
    if operator=='sum_even':return sum(x for x in values if x%2==0)
    if operator=='histogram':
        r={}
        for x in values:r[x]=r.get(x,0)+1
        return r
    raise FractalError('Unsupported pure operator')


def _process_work(job):
    """Top-level pickleable function for Windows spawn; no closure or inherited state."""
    idx, operator, segment=job
    t0=time.perf_counter()
    return idx,_work(operator,segment),(time.perf_counter()-t0)*1000

def _merge(operator,results):
    if operator!='histogram':return sum(results)
    out={}
    for r in results:
        for k,v in r.items():out[k]=out.get(k,0)+v
    return out

def jain_fairness(values):
    a=[float(x) for x in values]
    if not a or any(not math.isfinite(x) or x<0 for x in a):raise FractalError('Invalid loads')
    total=sum(a)
    return 1.0 if total==0 else total**2/(len(a)*sum(x*x for x in a))

def dimensionless_load(requirements,capacity):
    if set(requirements)!=set(capacity) or not requirements:raise FractalError('Dimension names must match')
    rho={}
    for name,value in requirements.items():
        r=float(value);c=float(capacity[name])
        if not all(math.isfinite(x) for x in (r,c)) or r<0 or c<=0:raise FractalError('Invalid requirement/capacity')
        rho[name]=r/c
    return {'ratios':rho,'bottleneck':max(rho,key=rho.get),'max_rho':max(rho.values()),
            'fairness':jain_fairness(list(rho.values())),'balance_residual':1-jain_fairness(list(rho.values()))}

@dataclass(frozen=True)
class Partial:
    start:int
    end:int
    dimension:str
    depth:int
    identity:str

class FactoredFractal:
    def __init__(self,workers=4,max_depth=4,leaf_size=512,max_partials=10000):
        if not isinstance(workers,int) or not 1<=workers<=64:raise FractalError('workers must be 1..64')
        if not isinstance(max_depth,int) or not 0<=max_depth<=12:raise FractalError('max_depth must be 0..12')
        if not isinstance(leaf_size,int) or not 1<=leaf_size<=100000:raise FractalError('leaf_size must be 1..100000')
        self.workers=workers;self.max_depth=max_depth;self.leaf_size=leaf_size;self.max_partials=max_partials

    def _factor(self,count,dimensions):
        # N=number of partials; M=number of tagged logical dimensions.
        # Dimension names are metadata of the work coordinate, not extra hardware.
        leaves=[];splits=0
        def split(a,b,depth,dimension):
            nonlocal splits
            if b-a>self.leaf_size and depth<self.max_depth and len(leaves)+splits<self.max_partials:
                mid=(a+b)//2
                if a<mid<b:
                    splits+=1
                    split(a,mid,depth+1,dimension);split(mid,b,depth+1,dimension)
                    return
            leaves.append(Partial(a,b,dimension,depth,f'{dimension}:{a}:{b}:{depth}'))
        # Partition the data once, then tag each nonoverlapping piece with one
        # logical coordinate. Not Cartesian multiplication of duplicated work.
        m=len(dimensions)
        for i,dimension in enumerate(dimensions):
            a=count*i//m;b=count*(i+1)//m
            if a<b:split(a,b,0,dimension)
        if not leaves and count>0:raise FractalError('No work partitions')
        if sum(p.end-p.start for p in leaves)!=count:raise FractalError('Coverage violated')
        ordered=sorted(leaves,key=lambda x:x.start)
        if [(a.end,b.start) for a,b in zip(ordered,ordered[1:]) if a.end!=b.start]:raise FractalError('Overlap/gap detected')
        return leaves,splits

    def execute(self,values,operator='sum_squares',dimensions=('execution','cache','verification'),mode='async',reuse=True,verify=True):
        if operator not in OPERATORS:raise FractalError('Invalid operator')
        if mode not in ('sync','async','process'):raise FractalError('Invalid mode')
        if not isinstance(values,(tuple,list)) or len(values)>500_000:raise FractalError('Expected at most 500,000 integers')
        if any(type(x)!=int or abs(x)>10**12 for x in values):raise FractalError('Values must be bounded integers')
        if not isinstance(dimensions,(list,tuple)) or not 1<=len(dimensions)<=32 or len(set(dimensions))!=len(dimensions):raise FractalError('1..32 unique dimensions required')
        if any(not isinstance(d,str) or not d.replace('_','').isalnum() or len(d)>40 for d in dimensions):raise FractalError('Invalid dimension')
        t0=time.perf_counter();parts,splits=self._factor(len(values),dimensions)
        results=[None]*len(parts);cache={};hits=0
        # Scheduling layer intentionally separate from exact numerical operators.
        # Prehash by CONTENT, never by an arbitrary dimension label.
        keys=[]
        for part in parts:
            segment=values[part.start:part.end]
            key=hashlib.sha256(json.dumps([operator,segment],separators=(',',':')).encode()).hexdigest()
            keys.append(key)
        unique={};jobs=[]
        for i,k in enumerate(keys):
            if reuse and k in unique:
                hits+=1
            else:
                unique[k]=i;jobs.append(i)
        def compute(i):
            p=parts[i];begin=time.perf_counter()
            result=_work(operator,values[p.start:p.end])
            return i,result,(time.perf_counter()-begin)*1000
        elapsed_worker_ms=0
        if mode=='sync' or (self.workers==1 and mode!='process'):
            completed=[compute(i) for i in jobs]
        elif mode=='process':
            # Genuine OS processes; Python's GIL does not serialize CPU-bound workers.
            # A cost heuristic is NOT a false speedup guarantee: all marshaling and
            # pool startup overhead is included in end-to-end elapsed_ms.
            completed=[]
            with ProcessPoolExecutor(max_workers=self.workers,mp_context=multiprocessing.get_context('spawn')) as pool:
                futures=[pool.submit(_process_work,(i,operator,values[parts[i].start:parts[i].end])) for i in jobs]
                for f in as_completed(futures):completed.append(f.result())
        else:
            completed=[]
            with ThreadPoolExecutor(max_workers=self.workers,thread_name_prefix='usl-fractal') as pool:
                futures=[pool.submit(compute,i) for i in jobs]
                for f in as_completed(futures):completed.append(f.result())
        for i,res,t in completed:
            cache[keys[i]]=res;elapsed_worker_ms+=t
        for i,k in enumerate(keys):results[i]=cache[k]
        combined=_merge(operator,results)
        serial_t0=time.perf_counter();reference=_work(operator,values)
        serial_ms=(time.perf_counter()-serial_t0)*1000
        correct=combined==reference
        if verify and not correct:raise FractalError('Exact serial proof failed')
        loads={dimension:sum(p.end-p.start for p in parts if p.dimension==dimension) for dimension in dimensions}
        return {'operator':operator,'result':combined,'verified_exact':correct,'reference':reference,
                'N_logical_partials':len(parts),'M_named_dimensions':len(dimensions),'dimensions':list(dimensions),
                'factor_splits':splits,'max_depth_reached':max((p.depth for p in parts),default=0),
                'logical_items':len(values),'physically_computed_partials':len(jobs),'reused_identical_partials':hits,
                'physical_work_avoided_fraction':hits/max(1,len(parts)),
                'elapsed_ms':round((time.perf_counter()-t0)*1000,4),'serial_reference_ms':round(serial_ms,4),
                'worker_compute_ms_sum':round(elapsed_worker_ms,4),'mode':mode,'physical_worker_threads_max':self.workers if mode=='async' else 0,
                'physical_worker_processes_max':self.workers if mode=='process' else 0,
                'dimensionless_load_fairness':jain_fairness(list(loads.values())),
                'dimensionless_load_balance_residual':1-jain_fairness(list(loads.values())),
                'partitions':[{'start':p.start,'end':p.end,'dimension':p.dimension,'depth':p.depth} for p in parts[:100]],
                'partition_report_truncated':len(parts)>100}

class ServiceTensorPlanner:
    """N logical work items × M service dimensions → measured-capacity placement.

    Each item is assigned to exactly one REAL worker. Work demand is additive,
    never duplicated. Results are estimated normalized loads, not time savings.
    """
    def __init__(self,max_items=10000,max_dimensions=64,max_workers=64):
        self.max_items=max_items;self.max_dimensions=max_dimensions;self.max_workers=max_workers

    def plan(self,requirements,capacities):
        if not isinstance(requirements,list) or not requirements or len(requirements)>self.max_items:
            raise FractalError('Must supply 1..10000 logical work demands')
        if not isinstance(capacities,list) or not 1<=len(capacities)<=self.max_workers:
            raise FractalError('Must supply 1..64 real worker capacity vectors')
        dims=list(requirements[0]) if isinstance(requirements[0],dict) else []
        if not 1<=len(dims)<=self.max_dimensions or any(not isinstance(x,str) or not x or len(x)>40 for x in dims):
            raise FractalError('1..64 named service dimensions required')
        if len(set(dims))!=len(dims):raise FractalError('Duplicate dimension')
        for d in [*requirements,*capacities]:
            if not isinstance(d,dict) or set(d)!=set(dims):raise FractalError('Service dimensions must match')
            if any(type(x) not in (int,float) or not math.isfinite(x) for x in d.values()):
                raise FractalError('Invalid nonfinite capacity/demand')
        if any(x<0 for item in requirements for x in item.values()):raise FractalError('Negative demand')
        if any(x<=0 for cap in capacities for x in cap.values()):raise FractalError('All capacities must be positive')
        # Larger high-pressure work is placed first, with input index preserved
        # for stable tie breaking. Demand/limit is unitless.
        workers=len(capacities);order=list(range(len(requirements)))
        order.sort(key=lambda i:-max(requirements[i][d]/max(c[d] for c in capacities) for d in dims))
        alloc=[{d:0.0 for d in dims} for _ in capacities];assignment=[None]*len(requirements)
        for idx in order:
            req=requirements[idx]
            def cost(w):
                each=[(alloc[w][d]+req[d])/capacities[w][d] for d in dims]
                return (max(each),sum(each)/len(each),w)
            selected=min(range(workers),key=cost)
            assignment[idx]=selected
            for d in dims:alloc[selected][d]+=req[d]
        serial_round_robin=[{d:0.0 for d in dims} for _ in capacities]
        for i,req in enumerate(requirements):
            b=serial_round_robin[i%workers]
            for d in dims:b[d]+=req[d]
        def metrics(loads):
            unitless=[max(x[d]/capacities[j][d] for d in dims) for j,x in enumerate(loads)]
            return {'max_rho':max(unitless),'mean_rho':sum(unitless)/len(unitless),
                    'jain_fairness':jain_fairness(unitless),'worker_max_rho':unitless}
        # Verify conservation of each requested service dimension.
        for d in dims:
            original=sum(item[d] for item in requirements)
            placed=sum(item[d] for item in alloc)
            if not math.isclose(original,placed,rel_tol=1e-10,abs_tol=1e-8):
                raise FractalError('Demand conservation failed')
        return {'N_logical_items':len(requirements),'M_dimensions':len(dims),
           'real_worker_capacity_vectors':workers,'dimensions':dims,
           'planner':metrics(alloc),'round_robin_baseline':metrics(serial_round_robin),
           'assignments_exactly_once':all(x is not None for x in assignment),
           'demand_conserved':True,'assignments':assignment[:500],
           'assignments_truncated':len(assignment)>500,
           'note':'These are unitless estimated capacity-pressure ratios, NOT measured execution time.'}
