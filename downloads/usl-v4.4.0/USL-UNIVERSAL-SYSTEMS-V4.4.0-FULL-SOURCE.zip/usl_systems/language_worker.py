"""Isolated native language frontend/executor for the v4.3 engine batch."""
from __future__ import annotations
import contextlib, io, json, os, subprocess, sys
from pathlib import Path

NODE_PROGRAM = r'''
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const req = JSON.parse(fs.readFileSync(0, 'utf8'));
const provider = (name) => require(path.join(req.node_modules, name));
(async () => {
  let rendered, astKind;
  if (req.engine === 'coffeescript') {
    const coffee = provider('coffeescript');
    const ast = coffee.nodes(req.source);
    const compiled = coffee.compile(req.source, {bare: true});
    let output = '';
    vm.runInNewContext(compiled, {usl_context: req.context, console: {log: (...x) => {
      output += x.join(' ') + '\n'; if (output.length > 32768) throw Error('output bound');
    }}}, {timeout: 2000});
    process.stdout.write(JSON.stringify({value: {compiled, stdout: output}, parser: ast.constructor.name})); return;
  } else if (req.engine === 'less') {
    const result = await provider('less').render(req.source, {javascriptEnabled: false});
    rendered = result.css; astKind = 'Less.render';
  } else if (req.engine.startsWith('sass_')) {
    const sass = provider('sass');
    rendered = sass.compileString(req.source, {syntax: req.engine === 'sass_indented' ? 'indented' : 'scss'}).css;
    astKind = 'DartSass.compileString';
  } else if (req.engine === 'pug') {
    rendered = provider('pug').render(req.source, req.context); astKind = 'Pug.compile';
  } else if (req.engine.startsWith('handlebars')) {
    const handlebars = provider('handlebars');
    astKind = handlebars.parse(req.source).type;
    rendered = handlebars.compile(req.source, {strict: true})(req.context);
  } else throw Error('unknown engine');
  if (Buffer.byteLength(rendered, 'utf8') > 131072) throw Error('rendered output bound');
  process.stdout.write(JSON.stringify({value: {rendered}, parser: astKind}));
})().catch(e => { process.stderr.write(e.name + ': ' + e.message); process.exitCode = 1; });
'''

def execute(req):
    engine, source, context = req['engine'], req['source'], req['context']
    if engine in ('coffeescript','less','sass_indented','sass_scss','pug','handlebars','handlebars_html'):
        # Outer process-group and file/CPU ceilings include Node and descendants.
        result = subprocess.run(['node','--max-old-space-size=96','-e',NODE_PROGRAM],
            input=json.dumps(req).encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=8)
        if result.returncode:
            raise ValueError(result.stderr.decode(errors='replace'))
        if len(result.stdout) > 524288:
            raise ValueError('Node output bound exceeded')
        response = json.loads(result.stdout)
        if engine in ('less','sass_indented','sass_scss'):
            from source_worker import validate_host
            response['value'] = validate_host('css', response['value']['rendered'])
        elif engine in ('pug','handlebars_html'):
            from source_worker import validate_host
            response['value'] = validate_host('html', response['value']['rendered'])
        return response
    if engine == 'hy':
        import hy
        output = io.StringIO()
        forms = list(hy.read_many(source))
        with contextlib.redirect_stdout(output):
            scope = {'usl_context': context}
            for form in forms: hy.eval(form, globals=scope)
        return {'value': {'stdout': output.getvalue()}, 'parser': [type(f).__name__ for f in forms]}
    if engine == 'liquid':
        from liquid import Environment, StrictUndefined
        template = Environment(undefined=StrictUndefined).from_string(source)
        return {'value': {'rendered': template.render(**context)}, 'parser': 'Liquid.Environment.from_string'}
    if engine.startswith('genshi_'):
        from genshi.template import MarkupTemplate, NewTextTemplate
        template = NewTextTemplate(source) if engine == 'genshi_text' else MarkupTemplate(source)
        stream = template.generate(**context)
        rendered = stream.render('text' if engine == 'genshi_text' else 'html' if engine == 'genshi_html' else 'xml')
        if engine != 'genshi_text':
            from source_worker import validate_host
            value = validate_host('html' if engine == 'genshi_html' else 'xml', rendered)
        else: value = {'rendered': rendered}
        return {'value': value, 'parser': type(template).__name__}
    raise ValueError('unknown engine')

if __name__ == '__main__':
    try:
        if os.name != 'nt':
            import resource
            resource.setrlimit(resource.RLIMIT_CPU, (8,8))
            resource.setrlimit(resource.RLIMIT_FSIZE, (1048576,1048576))
        request = json.loads(sys.stdin.buffer.read(65537))
        if os.name!='nt':
            limit=8*1024**3 if request['engine'] in ('coffeescript','less','sass_indented','sass_scss','pug','handlebars','handlebars_html') else 512*1024**2
            resource.setrlimit(resource.RLIMIT_AS,(limit,limit))
        response = execute(request)
        encoded = json.dumps(response, ensure_ascii=False, allow_nan=False).encode()
        if len(encoded) > 524288: raise ValueError('worker output bound exceeded')
        sys.stdout.buffer.write(encoded)
    except Exception as exc:
        sys.stderr.write(type(exc).__name__ + ': ' + str(exc)[:4000]); sys.exit(1)
