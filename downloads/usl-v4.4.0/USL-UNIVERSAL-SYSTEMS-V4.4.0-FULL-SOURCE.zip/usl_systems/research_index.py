"""Read-only provenance index for historical research equations in bundled archives.
Candidates are not executed or silently promoted to validated physics.
"""
import hashlib,json,re,zipfile
from pathlib import Path
from .equations import list_equations

MARKERS=re.compile(r'(?i)(equation|formula|\b[A-Z_a-z][\w]{0,20}\s*[=:]\s*[-+*/().\w^]|\\frac|\\sum|\\rho|\$[^$]{3,100}\$)')
PRIVATE_LINE=re.compile(r'(?i)(password|passwd|api[_ -]?key|private[_ -]?key|authorization|bearer|credential|pairing[_ -]?token|access[_ -]?token|secret[_ -]?key|cookie)')

def discover_archives(root,max_matches=1000,max_entry_bytes=100_000):
    root=Path(root)
    if not 1<=max_matches<=10000:raise ValueError('max_matches out of range')
    records=[];archive_stats=[]
    for source in sorted(root.glob('*.zip')):
        scan=0;matched=0
        try:
            with zipfile.ZipFile(source) as z:
                for member in z.infolist():
                    if len(records)>=max_matches:break
                    if member.is_dir() or member.file_size>max_entry_bytes or member.file_size==0:continue
                    if not member.filename.lower().endswith(('.md','.txt','.tex','.usl','.json')):continue
                    if any(s in member.filename for s in ('node_modules/','vendor/','.git/')):continue
                    try:raw=z.read(member).decode('utf8','replace')
                    except (OSError,RuntimeError,ValueError):continue
                    scan+=1
                    for lineno,line in enumerate(raw.splitlines(),1):
                        if len(records)>=max_matches:break
                        line=' '.join(line.strip().split())
                        if not 12<=len(line)<=240 or not MARKERS.search(line):continue
                        if 'https://' in line or 'http://' in line or PRIVATE_LINE.search(line) or line.startswith(('import ','from ','{"','"')):continue
                        if line.count('=')>=4:continue
                        records.append({'origin_archive':source.name,'source_path':member.filename,
                            'line':lineno,'text':line,'status':'unverified_candidate',
                            'source_sha256':hashlib.sha256(line.encode()).hexdigest()})
                        matched+=1
        except (OSError,zipfile.BadZipFile,RuntimeError):
            archive_stats.append({'archive':source.name,'error':'Unreadable archive'});continue
        archive_stats.append({'archive':source.name,'files_scanned':scan,'candidate_lines':matched})
        if len(records)>=max_matches:break
    return {'builtin_equations':len(list_equations()),'discovered_candidates':len(records),
            'limited_to_first':max_matches,'archive_stats':archive_stats,'candidates':records,
            'note':'Formula-like strings from historical documents. Not independently parsed, proven, or executed.'}
