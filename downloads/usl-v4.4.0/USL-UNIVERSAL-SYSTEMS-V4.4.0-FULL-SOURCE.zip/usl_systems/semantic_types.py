"""Conservative static diagnostics for the bounded USL AST subset.

This is a monotone, finite checker for plainly inferable scalar/list errors,
not a general Hindley-Milner type system and not a proof of foreign-language
semantic equivalence. Unknown information stays unknown, never guessed.
"""
from __future__ import annotations
import ast,hashlib
from dataclasses import dataclass
from .language import parse,normalize

@dataclass(frozen=True)
class Type:
    kind:str
    element:str='unknown'
    size:int|None=None
    shape:tuple|None=None
    def name(self):return self.kind+(('['+self.element+']') if self.kind=='array' else '')

UNKNOWN=Type('unknown')
NUMERIC=('int','float')

class Checker:
    def __init__(self):self.issues=[];self.functions={};self.visited=0
    def issue(self,node,code,message):
        record={'severity':'error','line':getattr(node,'lineno',None),'code':code,'message':message}
        if record not in self.issues:self.issues.append(record)
    def infer(self,node,types):
        self.visited+=1
        if isinstance(node,ast.Constant):
            x=node.value
            return Type('bool' if type(x) is bool else 'int' if type(x) is int else 'float' if type(x) is float else 'str' if type(x) is str else 'null')
        if isinstance(node,ast.Name):return types.get(node.id,UNKNOWN)
        if isinstance(node,(ast.List,ast.Tuple)):
            members=[self.infer(item,types) for item in node.elts]
            kind=members[0].kind if members and all(t.kind==members[0].kind for t in members) else 'unknown'
            return Type('array',kind,len(members))
        if isinstance(node,ast.Subscript):
            arr=self.infer(node.value,types);idx=self.infer(node.slice,types)
            if idx.kind not in ('int','unknown'):self.issue(node,'index_not_integer','List index must be an integer')
            if arr.kind=='array':
                index_value=None
                if isinstance(node.slice,ast.Constant) and type(node.slice.value) is int:
                    index_value=node.slice.value
                elif (isinstance(node.slice,ast.UnaryOp) and isinstance(node.slice.op,ast.USub) and
                      isinstance(node.slice.operand,ast.Constant) and type(node.slice.operand.value) is int):
                    index_value=-node.slice.operand.value
                if index_value is not None and arr.size is not None:
                    if index_value>=arr.size or index_value < -arr.size:
                        self.issue(node,'index_out_of_bounds','Constant index outside inferred array bounds')
                return Type(arr.element)
            if arr.kind!='unknown':self.issue(node,'index_on_scalar','Subscript requires an indexable value')
            return UNKNOWN
        if isinstance(node,ast.UnaryOp):
            operand=self.infer(node.operand,types)
            return Type('bool') if isinstance(node.op,ast.Not) else operand
        if isinstance(node,ast.BinOp):
            left=self.infer(node.left,types);right=self.infer(node.right,types)
            if left.kind=='unknown' or right.kind=='unknown':return UNKNOWN
            if left.kind in NUMERIC and right.kind in NUMERIC:
                return Type('float' if isinstance(node.op,ast.Div) or 'float' in (left.kind,right.kind) else 'int')
            if isinstance(node.op,ast.Add) and left.kind==right.kind=='str':return Type('str')
            if isinstance(node.op,ast.Add) and left.kind==right.kind=='array':return Type('array',left.element if left.element==right.element else 'unknown',
                           (left.size+right.size) if left.size is not None and right.size is not None else None)
            # No broad assumptions about Python-style repetition, exotic types.
            if isinstance(node.op,(ast.Add,ast.Sub,ast.Div,ast.FloorDiv,ast.Mod,ast.Pow)):
                self.issue(node,'operand_type_mismatch',f'{left.name()} and {right.name()} incompatible with this operation')
            return UNKNOWN
        if isinstance(node,ast.Call):
            for arg in node.args:self.infer(arg,types)
            if isinstance(node.func,ast.Name):
                fn=node.func.id
                if fn in self.functions and len(node.args)!=len(self.functions[fn].args.args):
                    self.issue(node,'function_arity',f'{fn} expects {len(self.functions[fn].args.args)} arguments')
                if fn=='len':return Type('int')
                if fn in ('int','float','str','bool'):return Type(fn)
                if fn=='range':return Type('array','int')
            return UNKNOWN
        if isinstance(node,ast.Compare):
            self.infer(node.left,types)
            for x in node.comparators:self.infer(x,types)
            return Type('bool')
        if isinstance(node,ast.BoolOp):
            for x in node.values:self.infer(x,types)
            return UNKNOWN
        if isinstance(node,ast.IfExp):
            self.infer(node.test,types)
            a=self.infer(node.body,types);b=self.infer(node.orelse,types)
            return a if a==b else UNKNOWN
        for child in ast.iter_child_nodes(node):
            if isinstance(child,ast.expr):self.infer(child,types)
        return UNKNOWN
    def walk(self,stmts,types):
        for node in stmts:
            self.visited+=1
            if isinstance(node,ast.Assign):types[node.targets[0].id]=self.infer(node.value,types)
            elif isinstance(node,ast.AugAssign):
                inferred=self.infer(ast.BinOp(left=node.target,op=node.op,right=node.value),types)
                if isinstance(node.target,ast.Name):types[node.target.id]=inferred
            elif isinstance(node,ast.Expr):self.infer(node.value,types)
            elif isinstance(node,ast.Return) and node.value:self.infer(node.value,types)
            elif isinstance(node,ast.Assert):self.infer(node.test,types)
            elif isinstance(node,ast.FunctionDef):
                self.walk(node.body,{arg.arg:UNKNOWN for arg in node.args.args})
            elif isinstance(node,ast.If):
                self.infer(node.test,types)
                yes=dict(types);no=dict(types)
                self.walk(node.body,yes);self.walk(node.orelse,no)
                # Only keep a type when both branches definitely agree.
                for key in set(yes)|set(no):types[key]=yes[key] if key in yes and key in no and yes[key]==no[key] else UNKNOWN
            elif isinstance(node,ast.For):
                self.infer(node.iter,types)
                local=dict(types);local[node.target.id]=Type('int') if isinstance(node.iter,ast.Call) and isinstance(node.iter.func,ast.Name) and node.iter.func.id=='range' else UNKNOWN
                self.walk(node.body,local);self.walk(node.orelse,dict(types))
            elif isinstance(node,ast.While):
                self.infer(node.test,types);self.walk(node.body,dict(types));self.walk(node.orelse,dict(types))
    def check(self,source):
        tree=parse(source)
        self.functions={x.name:x for x in tree.body if isinstance(x,ast.FunctionDef)}
        self.walk(tree.body,{})
        return {'schema':'usl.static_type_diagnostics.v1','source_sha256':hashlib.sha256(source.encode('utf8')).hexdigest(),
                'source_nodes':sum(1 for _ in ast.walk(tree)),'nodes_examined':self.visited,
                'error_count':len(self.issues),'issues':self.issues,
                'static_type_proven_complete':False,
                'limitations':'Local conservative scalar/homogeneous array inference only; unknown types remain unknown; no general interprocedural soundness.'}

def check_types(source):return Checker().check(source)
