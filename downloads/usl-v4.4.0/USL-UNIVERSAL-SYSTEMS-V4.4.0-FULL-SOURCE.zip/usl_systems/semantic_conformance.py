"""USL semantic specification ledger and approved differential conformance runner.

Every test executes reviewed, source-hash-pinned REAL foreign-language code and
checks language-specific oracles (including deliberate semantic disagreements).
No finite suite proves the entirety of a language specification.  It is a
reviewable scaffold for versioned standards, profiles, and feature evidence.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import hashlib, json, os, platform, shutil, signal, subprocess, sys, time
from .catalog import load_catalog
from .universal_adapters import capability_report

ROOT=Path(__file__).resolve().parents[1]
CORPUS=ROOT/'semantic_fixtures'/'CORPUS.json'
RUNNERS={'python':(sys.executable,), 'javascript':('node',), 'ruby':('ruby',), 'php':('php',)}
DYNAMIC_FEATURES=('negative_integer_division','unicode_length','mutable_alias',
 'closure_state','exception_capture','null_roundtrip','record_and_list',
 'loop_sum','empty_list_truth','precision_boundary')
# Semantic dimensions required for honest whole-language qualification.  Not all
# apply to markup, query languages or hardware descriptions.
LANGUAGE_DIMENSIONS=(
 'lexing_and_grammar','scoping_and_binding','type_rules','numeric_semantics',
 'function_calls_and_closures','data_models_and_aliasing','object_and_module_model',
 'exceptions_and_control_flow','concurrency_async_and_memory_order',
 'io_filesystem_network','standard_library','native_foreign_abi',
 'unicode_and_encoding','implementation_defined_and_undefined_behavior',
 'versions_and_extensions','security_and_capabilities','debugging_and_tooling')
FORMAT_DIMENSIONS=('grammar_and_validation','schema_semantics','normalization',
 'roundtrip_serialization','encoding_and_unicode','version_profile',
 'invalid_input_diagnostics','security_and_expansion_limits')
SHADER_DIMENSIONS=('grammar_and_type_rules','shader_stage_linkage','layout_and_alignment',
 'device_capabilities','numeric_precision','compilation_and_validation',
 'target_execution','safety_and_resource_limits')
QUERY_DIMENSIONS=('syntax_and_binding','types_and_nulls','operators_and_aggregations',
 'schema_and_catalog','transaction_isolation','optimizer_and_determinism',
 'parameter_binding','execution_and_errors','dialect_and_version')

class ConformanceError(ValueError):pass

def _sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def corpus(root=ROOT):
    f=Path(root)/'semantic_fixtures'/'CORPUS.json'
    data=json.loads(f.read_text('utf8'))
    if data.get('schema')!='usl.semantic.corpus.v1' or set(data['languages'])!=set(RUNNERS) or set(data['cases'])!=set(DYNAMIC_FEATURES):
        raise ConformanceError('Unexpected semantic corpus declaration')
    for case,d in data['cases'].items():
        if set(d['fixtures'])!=set(RUNNERS):raise ConformanceError('Incomplete case: '+case)
        for lang,info in d['fixtures'].items():
            fn=info['file']
            if '/' in fn or '\\' in fn or '..' in fn:raise ConformanceError('Invalid fixture path')
            src=f.parent/fn
            if not src.is_file() or src.stat().st_size>4096 or _sha(src)!=info['sha256']:
                raise ConformanceError('Fixture hash mismatch: '+fn)
    return data

def _stop(proc):
    if proc.poll() is not None:return
    if os.name=='nt':
        try:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],timeout=4,capture_output=True)
        except (OSError,subprocess.TimeoutExpired):proc.kill()
    else:
        try:os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
    try:proc.wait(timeout=3)
    except subprocess.TimeoutExpired:proc.kill()

def _process(argv,cwd,timeout):
    opts={'cwd':cwd,'stdin':subprocess.DEVNULL,'stdout':subprocess.PIPE,'stderr':subprocess.PIPE,
          'env':dict(os.environ, PYTHONDONTWRITEBYTECODE='1')}
    if os.name=='nt':opts['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    else:opts['start_new_session']=True
    proc=subprocess.Popen(argv,**opts)
    try:out,err=proc.communicate(timeout=timeout);expired=False
    except subprocess.TimeoutExpired:
        expired=True;_stop(proc)
        try:out,err=proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:out=b'';err=b''
    if len(out)>65536 or len(err)>65536:raise ConformanceError('Oversized output')
    return {'exit_code':proc.returncode,'timeout':expired,
        'stdout':out.decode('utf8','replace'),'stderr':err.decode('utf8','replace')}

def run_case(language,case,*,authorized=False,timeout=8,root=ROOT):
    if authorized is not True:raise ConformanceError('Explicit permission required for source execution')
    if language not in RUNNERS or case not in DYNAMIC_FEATURES:raise ConformanceError('Unknown reviewed runtime or semantic case')
    if not isinstance(timeout,(int,float)) or not 0<timeout<=30:raise ConformanceError('Invalid timeout')
    d=corpus(root)['cases'][case];f=d['fixtures'][language]
    binary=RUNNERS[language][0]
    command=(binary if language=='python' else shutil.which(binary))
    if not command:raise ConformanceError('Runtime unavailable: '+binary)
    target=Path(root)/'semantic_fixtures'/f['file']
    started=time.perf_counter()
    result=_process([command,str(target)],str(Path(root)/'semantic_fixtures'),timeout)
    expected=d['expected']; expected=expected[language] if case in ('negative_integer_division','unicode_length','mutable_alias','empty_list_truth','precision_boundary') else expected
    value=None;protocol_ok=False
    try:
        decoded=json.loads(result['stdout'])
        protocol_ok=(type(decoded) is dict and set(decoded)=={'case','value'} and decoded['case']==case)
        if protocol_ok:value=decoded['value']
    except (ValueError,TypeError):pass
    passed=bool(not result['timeout'] and result['exit_code']==0 and protocol_ok
                and type(value) is type(expected) and value==expected)
    return {'language':language,'case':case,'status':'observed_pass' if passed else 'failed',
       'source_sha256':f['sha256'],'expected':expected,'observed':value,
       'exit_code':result['exit_code'],'timed_out':result['timeout'],
       'stdout_sha256':hashlib.sha256(result['stdout'].encode()).hexdigest(),
       'stderr_tail':result['stderr'][-1200:],
       'elapsed_ms':round((time.perf_counter()-started)*1000,3),
       'meaning':'bounded behavioral fixture, not full-language semantics'}

def qualify(*,authorized=False,workers=4,root=ROOT,features=None):
    if authorized is not True:raise ConformanceError('Explicit permission required')
    if type(workers) is not int or not 1<=workers<=16:raise ConformanceError('Workers must be 1..16')
    cases=tuple(features) if features is not None else DYNAMIC_FEATURES
    if not cases or len(set(cases))!=len(cases) or any(c not in DYNAMIC_FEATURES for c in cases):raise ConformanceError('Unknown/duplicate feature')
    corpus(root)
    started=time.perf_counter();results=[]
    jobs=[(k,c) for k in RUNNERS for c in cases]
    with ThreadPoolExecutor(max_workers=workers,thread_name_prefix='usl-semantic') as pool:
        pending={pool.submit(run_case,k,c,authorized=True,root=root):(k,c) for k,c in jobs}
        for future in as_completed(pending):
            key,case=pending[future]
            try:results.append(future.result())
            except Exception as e:results.append({'language':key,'case':case,'status':'blocked','error':str(e)[:500]})
    results.sort(key=lambda x:(x['language'],x['case']))
    statuses={k:{c:next((r['status'] for r in results if r['language']==k and r['case']==c),'not_tested') for c in DYNAMIC_FEATURES} for k in RUNNERS}
    diffs={c:{k:(corpus(root)['cases'][c]['expected'][k] if c in ('negative_integer_division','unicode_length','mutable_alias','empty_list_truth','precision_boundary') else corpus(root)['cases'][c]['expected']) for k in RUNNERS} for c in cases}
    return {'schema':'usl.semantic.differential.v1','scope':'reviewed source and language-specific oracles; no complete language specification proven',
      'platform':platform.platform(),'python':sys.version.split()[0], 'tested_languages':list(RUNNERS),
      'test_count':len(results),'passed':sum(r['status']=='observed_pass' for r in results),
      'all_passed':all(r['status']=='observed_pass' for r in results),'worker_count':workers,
      'elapsed_ms':round((time.perf_counter()-started)*1000,3),'profiles':statuses,
      'language_specific_oracles':diffs,'cases':results}

def _family(row):
    k=row['id'];ex=[str(e).lower() for e in row.get('extensions',[])]
    if k in ('json','jsonld','yaml','toml','ini','xml','html','css','csv','markdown','rst','tex','bibtex','abnf','bnf','bbcode'):
        return 'data_markup_or_grammar'
    if k in ('sql','postgresql','mysql','sqlite3','sparql','cypher'):
        return 'query_language'
    if k in ('glsl','hlsl','wgsl','metal','cuda','opencl'):
        return 'shader_or_compute_language'
    if k in ('verilog','systemverilog','vhdl'):
        return 'hardware_description_language'
    if k in ('python','javascript','ruby','php','c','cpp','java','go','typescript','swift','kotlin','perl','bash','fortran','lua','tcl','awk'):
        return 'programming_language'
    if k in ('make','cmake','basemake','docker','dockerfile'):
        return 'build_or_configuration_language'
    return 'requires_classification' # cannot certify 606 families from extension guesses

def ledger(*,root=ROOT,qualification=None):
    rows=load_catalog()
    if len(rows)!=606:raise ConformanceError('Expected exactly 606 source descriptors')
    tested={(r['language'],r['case']):r for r in (qualification or {}).get('cases',[])}
    known_entries={r['id']:r for r in rows}
    if len(known_entries)!=606:raise ConformanceError('Duplicate catalog IDs')
    results=[]
    for row in rows:
        k=row['id'];family=_family(row)
        dims=(FORMAT_DIMENSIONS if family=='data_markup_or_grammar' else QUERY_DIMENSIONS if family=='query_language' else
              SHADER_DIMENSIONS if family in ('shader_or_compute_language','hardware_description_language') else LANGUAGE_DIMENSIONS)
        cases={name:{'status':tested.get((k,name),{}).get('status','not_tested'),
                     'evidence_sha256':tested.get((k,name),{}).get('source_sha256')} for name in DYNAMIC_FEATURES}
        # Do not collapse a handful of tests into 'complete' on untested features.
        results.append({'id':k,'name':row['name'],'aliases':row.get('aliases',[]),'category':family,
          'standard_version':'not_claimed','normative_specification':'not_yet_audited',
          'implementation_version':'unknown_or_not_tested',
          'required_dimensions':{dim:'not_certified' for dim in dims},
          'reviewed_fixtures':cases,'full_semantic_status':'not_certified',
          'next_action':('audit authoritative language standard/version, map required semantic chapters, construct broad differential and edge-case conformance' if family!='requires_classification' else
                         'classify language family against authoritative spec and identify applicable compiler/validator/runtime')})
    return {'schema':'usl.semantic.accountability.v1','catalog_count':606,
     'certified_complete':0,'requires_classification':sum(e['category']=='requires_classification' for e in results),
     'feature_suite_size':len(DYNAMIC_FEATURES), 'tested_language_count':len({k for k,c in tested}),
     'meaning':'feature evidence is local and language-version-dependent; whole specification completion requires far more than fixture execution',
     'entries':results}

# The malformed sources are fixed local negative fixtures.  They must be
# REJECTED by actual installed native parsers; they are never evaluated.
INVALID_PROGRAMS={
 'python':'def broken(:\n    pass\n',
 'javascript':'function broken( {\n',
 'ruby':'def broken(\n',
 'php':'<?php function broken( {\n',
}
def negative_syntax(*,authorized=False,timeout=8):
    if authorized is not True:raise ConformanceError('Explicit approval required')
    import tempfile
    result=[]
    for lang,source in INVALID_PROGRAMS.items():
        cmd=RUNNERS[lang][0] if lang=='python' else shutil.which(RUNNERS[lang][0])
        if not cmd:
            result.append({'language':lang,'status':'blocked','reason':'runtime unavailable'});continue
        with tempfile.TemporaryDirectory(prefix='usl-negative-parser-') as tmp:
            ext={'python':'.py','javascript':'.js','ruby':'.rb','php':'.php'}[lang]
            path=Path(tmp)/('invalid'+ext);path.write_text(source,'utf8')
            argv=[cmd,*({'python':['-m','py_compile'], 'javascript':['--check'],
                         'ruby':['-c'], 'php':['-l']}[lang]),str(path)]
            p=_process(argv,tmp,timeout)
        ok=not p['timeout'] and isinstance(p['exit_code'],int) and p['exit_code']!=0
        result.append({'language':lang,'status':'rejected' if ok else 'unexpected_acceptance',
            'exit_code':p['exit_code'],'timed_out':p['timeout'],
            'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
            'diagnostic_tail':(p['stdout']+p['stderr'])[-500:]})
    return {'schema':'usl.semantic.negative.v1','passed':sum(x['status']=='rejected' for x in result),
            'total':len(result),'all_passed':all(x['status']=='rejected' for x in result),'cases':result}

def scoped_compatibility_matrix(qualification):
    """Derive scoped pair policy ONLY from two actual passed language test records.

    This is a compatibility ANALYSIS, not fabricated execution of each pair.
    No pair is certified as globally equivalent by agreeing on a case.
    """
    observations={(r.get('language'),r.get('case')):r for r in qualification.get('cases',[])}
    entries=[]
    for host in RUNNERS:
        for guest in RUNNERS:
            for case in DYNAMIC_FEATURES:
                a=observations.get((host,case),{});b=observations.get((guest,case),{})
                both=a.get('status')==b.get('status')=='observed_pass'
                same=both and type(a.get('observed')) is type(b.get('observed')) and a['observed']==b['observed']
                entries.append({'host':host,'guest':guest,'feature':case,
                    'status':'direct_fixture_equivalence' if same else 'semantic_shim_required' if both else 'unverified',
                    'host_source_sha256':a.get('source_sha256'),
                    'guest_source_sha256':b.get('source_sha256'),
                    'equivalence_claim':'this fixture only, not language-wide or pairwise callback success'})
    return {'schema':'usl.semantic.scoped_compatibility.v1','dimensions':[len(RUNNERS),len(RUNNERS),len(DYNAMIC_FEATURES)],
      'cells':len(entries),'direct_fixture_equivalence':sum(x['status']=='direct_fixture_equivalence' for x in entries),
      'shim_needed_for_fixture':sum(x['status']=='semantic_shim_required' for x in entries),
      'unverified':sum(x['status']=='unverified' for x in entries),
      'definition':'each cell derived from two independent actual guest executions; not a full nested bridge test',
      'entries':entries}

def qualify_python_js_shim(*,authorized=False,root=ROOT,timeout=8):
    """Run real Node shim and compare five Python semantic oracles; explicit typed bigint."""
    if authorized is not True:raise ConformanceError('Explicit permission required')
    exe=shutil.which('node')
    if not exe:raise ConformanceError('Node unavailable')
    source=Path(root)/'semantic_fixtures'/'compat_python_to_javascript.js'
    if not source.is_file():raise ConformanceError('Missing reviewed compatibility source')
    digest=_sha(source)
    p=_process([exe,str(source)],str(source.parent),timeout)
    if p['timeout'] or p['exit_code']!=0:raise ConformanceError('Compatibility guest failure: '+p['stderr'][-250:])
    try:values=json.loads(p['stdout'])
    except ValueError as e:raise ConformanceError('Invalid shim output') from e
    expected={'negative_integer_division':-3,'unicode_length':2,'empty_list_truth':False,
        'precision_boundary':{'kind':'bigint','decimal':'9007199254740993'},'mutable_alias':9}
    passed=type(values) is dict and set(values)==set(expected) and all(type(values[k]) is type(expected[k]) and values[k]==expected[k] for k in expected)
    return {'schema':'usl.semantic.shim_evidence.v1','source':'python_scoped','target':'javascript',
       'source_sha256':digest,'expected':expected,'observed':values,'status':'observed_pass' if passed else 'failed',
       'exit_code':p['exit_code'],'runtime_path':exe,
       'scope':'5 bounded operations only; tagged bigint for exact transport; not a Python implementation'}
