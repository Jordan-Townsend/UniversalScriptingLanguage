"""Explicitly reviewed, persistent, user-extensible equation registry.

Historical candidates are never automatically promoted into executable math.
A proposed expression is parsed by the safe numeric AST in equations.py.
"""
import json,math,os,re,threading
from pathlib import Path
from .equations import BUILTIN,evaluate,EquationError
from .store import Store

class CustomEquationError(EquationError):pass

class EquationWorkspace:
    def __init__(self,root=None):
        self.root=Path(root if root is not None else Store().root).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.file=self.root/'user_equations.json'
        self.lock=threading.RLock()
    def records(self):
        if not self.file.exists():return {}
        if self.file.stat().st_size>2_000_000:raise CustomEquationError('Equation registry exceeds 2MB limit')
        try:rows=json.loads(self.file.read_text('utf8'))
        except (OSError,ValueError) as e:raise CustomEquationError('Corrupted local equation registry') from e
        if not isinstance(rows,list) or len(rows)>1000:raise CustomEquationError('Invalid equation registry')
        return {entry['id']:self._valid(entry) for entry in rows}
    def _valid(self,item):
        if not isinstance(item,dict):raise CustomEquationError('Equation must be a JSON object')
        identifier=item.get('id','')
        if not isinstance(identifier,str) or not re.fullmatch('[a-z][a-z0-9_]{1,60}',identifier):raise CustomEquationError('Invalid equation ID')
        def short(field,size):
            val=item.get(field)
            if not isinstance(val,str) or not 1<=len(val)<=size:raise CustomEquationError(f'Invalid {field}')
            return val
        title=short('title',160);formula=short('formula',2000);domain=short('domain',60);source=short('source',250)
        use_cases=item.get('use_cases',[])
        if not isinstance(use_cases,list) or not 1<=len(use_cases)<=20 or any(not isinstance(x,str) or not 1<=len(x)<=350 for x in use_cases):
            raise CustomEquationError('Invalid use cases')
        defaults=item.get('defaults',{})
        if not isinstance(defaults,dict) or len(defaults)>32:raise CustomEquationError('Invalid parameter map')
        if any(not re.fullmatch('[A-Za-z][A-Za-z0-9_]{0,50}',str(k)) or type(v) not in (int,float) or not math.isfinite(v) for k,v in defaults.items()):
            raise CustomEquationError('Invalid numerical defaults')
        expression=item.get('expression')
        if expression is not None and (not isinstance(expression,str) or len(expression)>500):raise CustomEquationError('Invalid optional expression')
        record={'id':identifier,'title':title,'formula':formula,'domain':domain,'source':source,
                'use_cases':use_cases,'expression':expression,'defaults':defaults,
                'status':'unverified_user_hypothesis','executable':expression is not None,
                'notes':item.get('notes','') if isinstance(item.get('notes',''),str) else '', 'version':1}
        if len(record['notes'])>1000:raise CustomEquationError('Notes too long')
        if expression is not None:
            try:evaluate(identifier,{},extra={identifier:record})
            except Exception as e:raise CustomEquationError('Expression rejected by bounded scalar evaluator: '+str(e)) from e
        return record
    def import_file(self,path):
        incoming=Path(path)
        if incoming.stat().st_size>2_000_000:raise CustomEquationError('Import exceeds 2MB')
        data=json.loads(incoming.read_text('utf8'))
        if isinstance(data,dict):data=data.get('equations',[])
        if not isinstance(data,list) or not 1<=len(data)<=250:raise CustomEquationError('Expected 1..250 equation records')
        with self.lock:
            current=self.records();new={}
            for raw in data:
                rec=self._valid(raw);identifier=rec['id']
                if identifier in current or identifier in BUILTIN or identifier in new:
                    raise CustomEquationError('Duplicate equation '+identifier)
                new[identifier]=rec
            if len(current)+len(new)>1000:raise CustomEquationError('Registry full')
            content=json.dumps([*current.values(),*new.values()],ensure_ascii=False,indent=2)+'\n'
            tmp=self.file.with_name(self.file.name+'.tmp')
            try:
                tmp.write_text(content,encoding='utf8')
                os.replace(tmp,self.file)
            finally:tmp.unlink(missing_ok=True)
            return {'imported':len(new),'total_custom':len(current)+len(new),'local_registry':str(self.file),
                    'note':'User-submitted equations remain unverified hypotheses.'}
