"""Bounded local-model code generation, real USL execution, and persisted artifacts.
No cloud access; explicit local Ollama route only. No pretend agents.
"""
import json,os,re,urllib.request,urllib.error
from .language import Interpreter,USLError
from .compiler import transpile,UnsupportedCompile,TARGETS
from .native import verify

OLLAMA=os.environ.get('USL_OLLAMA_URL','http://127.0.0.1:11434').rstrip('/')

def _url(path):
    from urllib.parse import urlsplit
    parts=urlsplit(OLLAMA)
    if parts.hostname not in ('127.0.0.1','localhost','::1') or parts.scheme!='http':
        raise ValueError('Only loopback HTTP model endpoints are supported')
    return OLLAMA+path

def models():
    try:
        with urllib.request.urlopen(_url('/api/tags'),timeout=3) as r:
            data=json.load(r)
            return {'connected':True,'models':[m['name'] for m in data.get('models',[])], 'endpoint':OLLAMA}
    except (OSError,ValueError,KeyError,urllib.error.URLError) as e:
        return {'connected':False,'models':[], 'reason':str(e)[:220], 'endpoint':OLLAMA}

def ask_model(prompt,model=None,timeout=120):
    info=models()
    if not info['connected']:raise USLError('Local Ollama unavailable: '+info.get('reason','unknown'))
    chosen=model or (info['models'][0] if info['models'] else None)
    if not chosen:raise USLError('Ollama has no installed models; install one first')
    if chosen not in info['models']:raise USLError('Model is not installed: '+chosen)
    data=json.dumps({'model':chosen,'prompt':prompt,'stream':False,'options':{'temperature':0.15,'num_predict':1800}}).encode('utf8')
    req=urllib.request.Request(_url('/api/generate'),data=data,headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            return json.load(r)['response']
    except (OSError,KeyError,ValueError) as e:raise USLError('Ollama inference failed: '+str(e)[:350]) from e

def strip_fence(s):
    s=re.sub(r'^.*?```(?:usl|python)?\s*','',s.strip(),count=1,flags=re.S) if '```' in s else s.strip()
    if '```' in s:s=s.split('```',1)[0]
    return s.strip()+'\n'

SYSTEM='''Write a complete, runnable program in a minimal USL dialect only. No commentary or fences.\nSyntax: let x = 5; print(x); if x > 0: (indented body); for i in range(5): (indented body); function f(x): (indented body); return x; while with bounded loops; assert expr.\nOnly arithmetic, strings, booleans, arrays, numeric comparisons, print, range, int, float, str, len, sum. No imports, classes, attributes, files, networking or external libraries. Prefer 5-30 lines and include one assertion of expected behavior if possible.\nGoal:\n'''

def build(request,store,task_id):
    goal=str(request.get('goal','')).strip()
    project=str(request.get('project','demo')).strip()
    if not goal or len(goal)>3000:raise USLError('Goal is empty or exceeds 3000 characters')
    targets=request.get('targets',['python','javascript'])
    if not isinstance(targets,list) or len(targets)>16:raise USLError('Invalid list of target languages')
    targets=list(dict.fromkeys(str(t).lower() for t in targets))
    model=request.get('model') or None
    repair_feedback='';attempts=[]
    for attempt in range(1,4):
        store.event('agent',f'Generation attempt {attempt}',task_id)
        source=strip_fence(ask_model(SYSTEM+goal+'\n'+repair_feedback,model))
        try:
            run=Interpreter(timeout=4).run(source)
            attempts.append({'attempt':attempt,'executed':True,'operations':run.operations,'output':run.output[-2000:]})
            break
        except (USLError,TypeError,ValueError) as e:
            attempts.append({'attempt':attempt,'executed':False,'error':str(e)})
            repair_feedback='\nEarlier source failed with error: '+str(e)+'\nRewrite the entire program to fix it.'
    else:raise USLError('Model failed three bounded, verified USL attempts: '+str(attempts))
    result={'source':source,'usl_result':{'output':run.output,'operations':run.operations,'elapsed_ms':run.elapsed_ms},'attempts':attempts,'targets':{},'intent_review_required':True}
    store.save(project,'main.usl',source)
    for t in targets:
        try:
            g=transpile(source,t)
            store.save(project,'generated/'+g.filename,g.code)
            # Verify against the USL interpreter using available real toolchains.
            status=verify(source,t)
            result['targets'][t]={'filename':g.filename,'emitter_tier':g.tier,'verification':status['status'],
                                   'native_result':status.get('native',{}).get('returncode'), 'error':status.get('error',status.get('build',{}).get('stderr',''))[:1000]}
        except (USLError,ValueError) as e:
            result['targets'][t]={'verification':'unsupported_construct','error':str(e)}
    store.event('agent','Source executed. Generated targets reported with native validation status.',task_id)
    return result
