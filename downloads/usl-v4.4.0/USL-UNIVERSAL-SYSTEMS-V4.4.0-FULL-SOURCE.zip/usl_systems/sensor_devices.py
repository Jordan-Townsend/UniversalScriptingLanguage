"""Opt-in real device/model adapters; absence is a failure, not simulated success."""
from __future__ import annotations
import json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path
from .senses import image_observation, audio_observation, packet, validate_packet

def _approved(value):
    if value is not True: raise ValueError('explicit sensor/device access approval required')

def capture(kind, destination, *, approved=False, index=0, seconds=2):
    _approved(approved)
    if kind not in ('camera','microphone') or type(index) is not int or not 0 <= index <= 16 or type(seconds) not in (int,float) or not 0.1 <= seconds <= 10:
        raise ValueError('bounded capture parameters required')
    path = Path(destination).resolve(); path.parent.mkdir(parents=True, exist_ok=True)
    request = {'kind': kind, 'path': str(path), 'index': index, 'seconds': seconds}
    worker = Path(__file__).with_name('sensor_worker.py')
    result = subprocess.run([sys.executable, str(worker)], input=json.dumps(request).encode(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=seconds+12)
    if result.returncode: raise ValueError('actual device capture failed: ' + result.stderr.decode(errors='replace')[-2000:])
    observation = image_observation(path) if kind == 'camera' else audio_observation(path)
    observation.update(mode='live', timestamp=time.time())
    observation['evidence']['capture_adapter'] = kind
    return validate_packet(observation)

def ocr(path, *, approved=False):
    _approved(approved)
    binary = shutil.which('tesseract')
    if not binary: raise ValueError('Tesseract unavailable')
    image = Path(path).resolve()
    if not image.is_file() or image.stat().st_size > 8_000_000: raise ValueError('bounded image file required')
    result = subprocess.run([binary, str(image), 'stdout', '--psm', '6'],capture_output=True,timeout=12)
    if result.returncode: raise ValueError('OCR failed: '+result.stderr.decode(errors='replace')[-1000:])
    if len(result.stdout) > 64_000: raise ValueError('OCR output bound')
    from .source_engines import runtime_file_hash
    return {'text': result.stdout.decode('utf8'), 'provider': 'real.Tesseract',
        'source_sha256': runtime_file_hash(image), 'binary_sha256': runtime_file_hash(binary)}

def transcribe(path, model_path, *, approved=False):
    _approved(approved)
    import wave
    from vosk import Model, KaldiRecognizer
    audio_observation(path)  # validates encoding/duration before model execution
    model_root = Path(model_path).resolve()
    if not model_root.is_dir(): raise ValueError('actual downloaded Vosk model directory required')
    model = Model(str(model_root))
    with wave.open(str(path),'rb') as wav:
        recognizer = KaldiRecognizer(model, wav.getframerate())
        parts = []
        while True:
            frames = wav.readframes(4000)
            if not frames: break
            if recognizer.AcceptWaveform(frames): parts.append(json.loads(recognizer.Result()).get('text',''))
        parts.append(json.loads(recognizer.FinalResult()).get('text',''))
    return {'text': ' '.join(p for p in parts if p), 'provider': 'real.Vosk', 'model_path': str(model_root), 'live_microphone': False}

def speak(text, destination, *, approved=False):
    _approved(approved)
    if not isinstance(text,str) or not 1 <= len(text) <= 4000: raise ValueError('bounded speech text required')
    binary = shutil.which('espeak-ng') or shutil.which('espeak')
    if not binary: raise ValueError('eSpeak speech engine unavailable')
    path=Path(destination).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    result = subprocess.run([binary,'-w',str(path),'--stdin'],input=text.encode(),capture_output=True,timeout=15)
    if result.returncode: raise ValueError('speech synthesis failed')
    return {'file': str(path), 'provider': 'real.eSpeak', 'audio_played': False, 'bytes': path.stat().st_size}

def serial_observation(device, *, approved=False, baud=115200):
    _approved(approved)
    import serial
    if not isinstance(device,str) or len(device)>256 or baud not in (9600,19200,38400,57600,115200):
        raise ValueError('bounded serial configuration required')
    with serial.Serial(device,baudrate=baud,timeout=2) as connection:
        raw=connection.read_until(b'\n',size=64_001)
    if not raw or len(raw)>64_000: raise ValueError('sensor frame missing or exceeds bound')
    observation=json.loads(raw)
    observation['mode']='live';observation['timestamp']=time.time()
    observation['provider']='serial:'+device
    observation.setdefault('evidence',{})['source']='physical serial frame: '+device
    observation['evidence']['calibration_verified_by_host']=False
    return validate_packet(observation)
