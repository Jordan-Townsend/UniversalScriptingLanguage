"""Reproducible local digits benchmark and hash-verified inference bundles."""
from __future__ import annotations
import hashlib, json, statistics, time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from .feature_fusion import ConvBaseline, StackedFeatureFusionNet

def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _accuracy(model, x, y):
    model.eval()
    with torch.no_grad():
        logits = model(x)
        return float((logits.argmax(1) == y).float().mean()), float(nn.functional.cross_entropy(logits, y))

def _train(model, x, y, validation_x, validation_y, epochs, seed):
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.003, weight_decay=0.0001)
    generator = torch.Generator().manual_seed(seed)
    best = None
    best_validation = -1
    history = []
    started = time.perf_counter()
    for epoch in range(epochs):
        model.train()
        permutation = torch.randperm(len(x), generator=generator)
        for batch in permutation.split(64):
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.cross_entropy(model(x[batch]), y[batch])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
        accuracy, validation_loss = _accuracy(model, validation_x, validation_y)
        history.append({'epoch': epoch+1, 'validation_accuracy': accuracy, 'validation_loss': validation_loss})
        if accuracy > best_validation:
            best_validation = accuracy
            best = {k: v.detach().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best)
    return {'seconds': time.perf_counter()-started, 'history': history,
        'selection_rule': 'earliest epoch with highest validation accuracy; test unused'}

def benchmark(output, *, epochs=24, seeds=(7, 23, 61)):
    from sklearn.datasets import load_digits
    from sklearn.model_selection import train_test_split
    if type(epochs) is not int or not 1 <= epochs <= 80 or not 1 <= len(seeds) <= 8 or any(type(s) is not int or not 0 <= s < 2**31 for s in seeds):
        raise ValueError('bounded epochs/seeds required')
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    data = load_digits()
    indices = np.arange(len(data.target))
    train_val, test = train_test_split(indices, test_size=0.2, random_state=917, stratify=data.target)
    train, validation = train_test_split(train_val, test_size=0.2, random_state=918, stratify=data.target[train_val])
    pixels = torch.tensor(data.images[:, None] / 16, dtype=torch.float32)
    labels = torch.tensor(data.target, dtype=torch.long)
    x, y = pixels[train], labels[train]
    vx, vy = pixels[validation], labels[validation]
    tx, ty = pixels[test], labels[test]
    destination = Path(output); destination.mkdir(parents=True, exist_ok=True)
    records = []
    bundle = None
    for seed_index, seed in enumerate(seeds):
        torch.manual_seed(seed)
        baseline = ConvBaseline()
        fusion = StackedFeatureFusionNet.from_baseline(baseline)
        with torch.no_grad():
            equivalence_error = float((baseline(tx[:32])-fusion(tx[:32])).abs().max())
        if equivalence_error != 0:
            raise RuntimeError('zero-residual baseline equivalence failed')
        for name, model in [('baseline', baseline), ('stacked_fusion', fusion)]:
            training = _train(model, x, y, vx, vy, epochs, seed)
            accuracy, loss = _accuracy(model, tx, ty)
            with torch.no_grad():
                for _ in range(5): model(tx[:1])
                timings = []
                for _ in range(40):
                    started = time.perf_counter_ns(); model(tx[:1]); timings.append((time.perf_counter_ns()-started)/1e6)
            records.append({'seed': seed, 'architecture': name, 'test_accuracy': accuracy, 'test_loss': loss,
                'parameters': sum(p.numel() for p in model.parameters()),
                'single_sample_cpu_latency_median_ms': statistics.median(timings),
                'initial_baseline_equivalence_max_abs_error': equivalence_error, **training})
            if seed_index == 0 and name == 'stacked_fusion':
                bundle = destination/'digits_stacked_fusion.pt'
                torch.save({'schema': 'usl.feature_fusion.bundle.v1', 'config': model.config,
                    'state_dict': model.state_dict(), 'task': 'sklearn_8x8_digits_0_to_9',
                    'preprocessing': '8x8 grayscale values in 0..1; bright foreground',
                    'seed': seed, 'architecture_sha256': _sha(Path(__file__).with_name('feature_fusion.py'))}, bundle)
                from PIL import Image
                Image.fromarray(np.uint8(data.images[test[0]]/16*255)).save(destination/'heldout_digit.png')
                (destination/'heldout_digit_expected.json').write_text(json.dumps({'label': int(data.target[test[0]]), 'dataset_index': int(test[0])})+'\n')
    differences = []
    for seed in seeds:
        by_name = {r['architecture']: r for r in records if r['seed'] == seed}
        differences.append(by_name['stacked_fusion']['test_accuracy']-by_name['baseline']['test_accuracy'])
    mean = statistics.mean(differences)
    report = {'schema': 'usl.feature_fusion.benchmark.v1', 'task': 'sklearn handwritten digits classification',
        'dataset_sha256': hashlib.sha256(data.images.tobytes()+data.target.tobytes()).hexdigest(),
        'split_sha256': hashlib.sha256(train.tobytes()+validation.tobytes()+test.tobytes()).hexdigest(),
        'split_counts': {'train': len(train), 'validation': len(validation), 'test': len(test)},
        'protocol': 'same backbone initialization, split, shuffle order, optimizer and epochs; independent validation selection; all test runs reported',
        'epochs': epochs, 'seeds': list(seeds), 'records': records,
        'paired_test_accuracy_differences': differences, 'mean_accuracy_difference': mean,
        'observed_mean_fusion_accuracy_higher': mean > 0,
        'universal_superiority_proven': False, 'statistical_superiority_established': False,
        'limits': ['small single dataset', 'CPU only', 'fusion has more parameters', 'test runs correlated through shared split',
            'no general scene understanding', 'no human sensory equivalence', 'not a parameter-matched comparison'],
        'torch_version': torch.__version__, 'architecture_sha256': _sha(Path(__file__).with_name('feature_fusion.py')),
        'bundle': {'file': bundle.name, 'sha256': _sha(bundle), 'seed_selection': 'first preregistered seed, independent of test results'}}
    (destination/'benchmark.json').write_text(json.dumps(report, indent=2)+'\n')
    return report

def infer(bundle_dir, image_path):
    from PIL import Image
    from .senses import packet
    root = Path(bundle_dir)
    report = json.loads((root/'benchmark.json').read_text())
    name = report['bundle']['file']
    if Path(name).name != name:
        raise ValueError('invalid bundle filename')
    path = root/name
    if path.stat().st_size > 16_000_000 or _sha(path) != report['bundle']['sha256']:
        raise ValueError('bundle integrity mismatch')
    contents = torch.load(path, map_location='cpu', weights_only=True)
    architecture_hash = _sha(Path(__file__).with_name('feature_fusion.py'))
    if contents['schema'] != 'usl.feature_fusion.bundle.v1' or contents['architecture_sha256'] != architecture_hash:
        raise ValueError('inference architecture identity mismatch')
    model = StackedFeatureFusionNet(**contents['config'])
    model.load_state_dict(contents['state_dict'], strict=True); model.eval()
    if Path(image_path).stat().st_size > 8_000_000:
        raise ValueError('image exceeds inference budget')
    with Image.open(image_path) as image:
        if image.width*image.height > 4_000_000:
            raise ValueError('image pixel budget')
        values = np.asarray(image.convert('L').resize((8,8)), dtype=np.float32)/255
    with torch.no_grad():
        encoded = model.encode(torch.tensor(values[None, None]))
        probabilities = model.head(encoded['embedding']).softmax(1)[0]
    observation = packet('vision', encoded['embedding'][0].tolist(), 'trained.StackedFeatureFusionNet',
        {'source': str(Path(image_path).resolve()), 'image_sha256': _sha(image_path), 'model_sha256': report['bundle']['sha256'],
            'task': contents['task'], 'predicted_digit': int(probabilities.argmax()),
            'probabilities': probabilities.tolist(), 'gates': encoded['gates'][0].tolist(),
            'confidence_calibrated': False, 'general_scene_understanding': False})
    return observation
