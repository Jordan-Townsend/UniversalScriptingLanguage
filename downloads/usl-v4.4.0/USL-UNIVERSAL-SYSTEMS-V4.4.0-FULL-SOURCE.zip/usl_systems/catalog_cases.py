"""Explicit independently checkable cases for reviewed backend profiles."""
from .catalog_backends import PROFILES,run

def fixture(language,n=21):
    p=PROFILES[language];e=p['engine'];host=p['host'];context={};expected=str(n*2)
    if e=='rust':source=f'fn main() {{ println!("{{}}", {n} * 2); }}';bad='fn main( {'
    elif e=='pascal':source=f'program Source; begin writeln({n} * 2); end.';bad='program Source; begin writeln( end.'
    elif e=='lisp':source=f'(format t "~d~%" (* {n} 2))';bad='(format t '
    elif e=='scheme':source=f'(display (* {n} 2)) (newline)';bad='(display '
    elif e=='ocaml':source=f'print_int ({n} * 2); print_newline ();;';bad='let ='
    elif e=='erlang':source=f'io:format("~p~n",[{n}*2]),halt().';bad='io:format(,halt().'
    elif e=='elixir':source=f'IO.puts({n} * 2)';bad='IO.puts('
    elif e=='clojure':source=f'(println (* {n} 2))';bad='(println '
    elif e=='groovy':source=f'println({n} * 2)';bad='println('
    elif e=='scala':source=f'println({n} * 2)';bad='println('
    elif e=='csharp':source=f'using System; class Source {{ static void Main() {{ Console.WriteLine({n} * 2); }} }}';bad='class Source { static void Main( {'
    elif e=='bc':source=f'({n} * 2)\n';bad='(\n'
    elif e=='tcsh':source=f'@ value = {n} * 2\necho $value\n';bad='echo "unterminated'
    elif e=='fish':source=f'math "{n} * 2"';bad='echo "unterminated'
    elif e=='pike':source=f'int main() {{write("%d\\n", {n} * 2);return 0;}}';bad='int main( {'
    elif e=='r':source=f'cat({n} * 2, "\\n", sep="")';bad='cat('
    elif e=='prolog':source=f'main :- X is {n} * 2, writeln(X).';bad='main :- X is (.'
    elif e=='d':source=f'import std.stdio; void main() {{ writeln({n} * 2); }}';bad='void main( {'
    elif e=='ada':source=f'with Ada.Text_IO; use Ada.Text_IO; procedure Source is begin Put_Line(Integer\'Image({n} * 2)); end Source;';bad='procedure Source is begin Put_Line( end Source;'
    elif e=='fortran_fixed':source=f'      PROGRAM SOURCE\n      PRINT *, {n} * 2\n      END\n';bad='      PROGRAM SOURCE\n      PRINT *, (\n      END\n'
    elif e=='verilog':source=f'module source; initial begin $display("%0d", {n} * 2); $finish; end endmodule';bad='module source; initial begin $display( endmodule'
    elif e=='vhdl':source=f'entity source is end; architecture test of source is begin process begin report integer\'image({n} * 2); wait; end process; end;';bad='entity source is end; architecture test of source is begin process begin report (; end;'
    elif e=='fennel':source=f'(print (* {n} 2))';bad='(print '
    elif e=='asn1':source='USL DEFINITIONS ::= BEGIN Value ::= INTEGER END';bad='USL DEFINITIONS ::= BEGIN Value ::= INTEGER (';context={'value':n};expected=n
    elif e=='nestedtext':source=f'value: {n*2}\n';bad='value:\n   a: 1\n  b: 2';expected=str(n*2)
    elif e=='hcl':source=f'locals {{ value = {n*2} }}';bad='locals { value =';expected=n*2
    elif e=='jsonnet':source=f'{{value: {n} * 2}}';bad='{value:';expected=n*2
    elif e=='wasm':source='(module (func (export "twice") (param i32) (result i32) local.get 0 i32.const 2 i32.mul))';bad='(module (func';context={'value':n};expected=n*2
    elif e=='email':source=f'Subject: USL\nFrom: test@example.org\n\n{n*2}';bad='invalid header line\nSubject: USL\n\n42'
    elif e=='http':source=f'HTTP/1.1 200 OK\r\nContent-Length: {len(str(n*2))}\r\n\r\n{n*2}';bad='INVALID STATUS\r\n\r\n42'
    elif e=='urlencoded':source=f'value={n*2}';bad='value'
    elif e=='deb822':source=f'Package: usl\nValue: {n*2}\n';bad='not a field'
    elif e=='dns':source=f'$ORIGIN example.org.\nvalue 300 IN A 192.0.2.{abs(n)%250+1}\n';bad='value IN A not-an-address';expected=f'192.0.2.{abs(n)%250+1}'
    elif e=='yang':source=f'module source {{ namespace "urn:usl"; prefix u; leaf value {{ type int32; default {n*2}; }} }}';bad='module source { namespace "urn:usl"; prefix u; leaf value { type ; } }';expected='source'
    elif e=='yara':source=f'rule USL {{ strings: $x = "value={n*2}" condition: $x }}';bad='rule USL { condition: }';context={'text':f'value={n*2}'};expected=['USL']
    elif e=='abnf':source='value = 1*DIGIT\r\n';bad='value = (\r\n';context={'text':str(abs(n)*2)};expected=context['text']
    elif e=='ebnf':source='start: SIGNED_NUMBER\n%import common.SIGNED_NUMBER\n';bad='start: (';context={'text':str(n*2)}
    elif e=='properties':source=f'value={n*2}\n';bad='value=\\uZZZZ'
    else:
        context={'value':n*2};expected=str(n*2)
        expression={'erb':'<%= value %>','mako':'${value}','genshi_text':'${value}','ul4':'<?print value?>'}[e]
        source={'text':expression,'html':'<p>'+expression+'</p>','xml':'<p>'+expression+'</p>',
            'css':'p { margin: '+expression+'px; }','javascript':'console.log('+expression+');',
            'python':'print('+expression+')'}[host]
        bad={'erb':'<%= ( %>','mako':'${value','genshi_text':'${(}','ul4':'<?if value?>'}[e]
    return {'source':source,'invalid_source':bad,'context':context,'expected':expected}

def oracle(language,value,expected):
    p=PROFILES[language];e=p['engine'];host=p['host']
    if e=='vhdl':return '(report note): '+expected in value['stdout']
    if e=='verilog':return value['stdout'].splitlines()[0]==expected
    if p['mode'] in ('program','simulation') and 'stdout' in value:return value['stdout'].strip()==expected
    if e=='asn1':return value['decoded']==expected
    if e=='hcl':return value['locals'][0]['value']==expected
    if e=='nestedtext':return value['value']==expected
    if e=='jsonnet':return value['value']==expected
    if e=='wasm':return value['result']==expected
    if e=='email':return value['subject']=='USL' and value['body']==expected
    if e=='http':return value['status']==200 and value['body']==expected
    if e=='urlencoded':return value['value']==[expected]
    if e=='deb822':return value['Value']==expected
    if e=='dns':return value['addresses']==[expected]
    if e=='yang':return value['module']==expected and value['leaves']==['value']
    if e=='yara':return value['matches']==expected
    if e=='abnf':return value['matched']==expected
    if e=='ebnf':return value['text']==expected and 'start' in value['tree']
    if e=='properties':return value['stdout'].strip()==expected
    if host=='css':return value['declarations']==[{'name':'margin','value':expected+'px','important':False}]
    if host in ('html','xml'):return value['text'].strip()==expected
    if host in ('javascript','python'):return value['stdout'].strip()==expected
    if host=='text':return value['rendered'].strip()==expected
    raise ValueError('missing independent oracle')

def qualify(language):
    cases=[]
    for n,label in [(21,'positive'),(0,'boundary_zero'),(-7,'changed_input')]:
        f=fixture(language,n)
        try:
            r=run(language,f['source'],f['context'],approved=True)
            cases.append({'case':label,'passed':oracle(language,r['value'],f['expected']),'result':r})
        except Exception as exc:cases.append({'case':label,'passed':False,'error':str(exc)})
    f=fixture(language)
    try:
        run(language,f['invalid_source'],f['context'],approved=True)
        cases.append({'case':'syntax_negative','passed':False,'error':'invalid source accepted'})
    except ValueError as exc:
        # Require a parser/grammar diagnostic, not an absent binary or timeout.
        text=str(exc)
        markers=('syntax','Syntax','parse','Parse','read error','READ error','EOF','end of input','unexpected','Unexpected',
            'unterminated','Unterminated','expected','Expected','Error in','Error:','error:','IllegalArgumentException','BadStatusLine',
            'MissingHeaderBodySeparatorDefect','bad query field','field syntax','YangGrammarError','Premature','TemplateSyntaxError')
        admitted='actual backend rejection:' in text and any(marker in text for marker in markers)
        cases.append({'case':'syntax_negative','passed':admitted,'error':text})
    return {'catalog_id':language,'profile':PROFILES[language],'cases':cases,'passed':all(c['passed'] for c in cases),
        'qualification':'native_subset' if PROFILES[language]['mode'] in ('program','simulation','query_execute','template_render','configuration_evaluate') else 'format_or_grammar_subset',
        'full_spec_qualified':False}
