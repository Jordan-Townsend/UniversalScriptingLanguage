"""Actual bounded syntax parsing for data/config formats, not compiler emulation.

These validators make specific claims: JSON is RFC-style strict, TOML uses the
installed Python runtime, XML excludes DTD, Python uses host Python 3 grammar.
No generic syntax lexer is advertised as a semantic compiler.
"""
from __future__ import annotations
import ast
import configparser
import hashlib
from io import StringIO
import json
import sys
try:
    import tomllib
except ModuleNotFoundError:
    try:
        import tomli as tomllib  # Python 3.10 optional dependency
    except ModuleNotFoundError:
        tomllib = None
import xml.etree.ElementTree as ET

VALIDATORS={
    'json':'strict JSON parser',
    'jsonld':'JSON syntax only (JSON-LD context resolution not performed)',
    'jsonl':'one strict JSON value per nonempty line',
    'toml':'TOML 1.0 through Python tomllib',
    'ini':'strict INI/configparser',
    'xml':'XML without DTD/entity declarations',
    'python':'host Python 3 abstract syntax tree parsing',
}
ALIASES={'json-lines':'jsonl','ndjson':'jsonl','json-ld':'jsonld','cfg':'ini','configparser':'ini','py':'python'}

class SyntaxValidationError(ValueError):
    pass


def _constant_rejected(constant):
    raise SyntaxValidationError('Nonstandard JSON constant: '+constant)


def _strict_json(text):
    return json.loads(text, parse_constant=_constant_rejected)


def validate_syntax(source,language,max_bytes=1_000_000):
    if not isinstance(source,str) or not isinstance(language,str):
        raise SyntaxValidationError('Source and language must be text')
    lang=ALIASES.get(language.lower(),language.lower())
    if lang not in VALIDATORS:
        raise SyntaxValidationError('No parser-backed syntax validator for '+lang)
    data=source.encode('utf8')
    if len(data)>max_bytes:
        raise SyntaxValidationError('Input too large for in-process validator')
    result={'language':lang,'syntax_parser':VALIDATORS[lang],
            'source_sha256':hashlib.sha256(data).hexdigest(),
            'source_bytes':len(data),'valid':False,
            'semantic_compiler':False,'parser_backend':'python-stdlib'}
    try:
        if lang in ('json','jsonld'):
            value=_strict_json(source)
            result.update({'root_type':type(value).__name__,'elements':len(value) if isinstance(value,(dict,list)) else 1})
        elif lang=='jsonl':
            rows=[_strict_json(line) for line in source.splitlines() if line.strip()]
            result['records']=len(rows)
        elif lang=='toml':
            if tomllib is None:
                raise SyntaxValidationError('TOML parser unavailable; Python 3.11+ or pip install tomli')
            value=tomllib.loads(source)
            result['top_level_keys']=len(value)
        elif lang=='ini':
            ini=configparser.ConfigParser(interpolation=None,strict=True)
            ini.read_file(StringIO(source))
            result['sections']=len(ini.sections())
        elif lang=='xml':
            if '<!DOCTYPE' in source.upper() or '<!ENTITY' in source.upper():
                raise SyntaxValidationError('DTD and entity declarations are disabled')
            node=ET.fromstring(source)
            result['root_tag']=node.tag
        elif lang=='python':
            tree=ast.parse(source)
            result.update({'ast_nodes':sum(1 for _ in ast.walk(tree)),
                           'python_grammar':sys.version.split()[0]})
        result['valid']=True
    except (ValueError,SyntaxError,ET.ParseError,configparser.Error,TypeError) as exc:
        result['error']=type(exc).__name__+': '+str(exc)[:300]
    return result
