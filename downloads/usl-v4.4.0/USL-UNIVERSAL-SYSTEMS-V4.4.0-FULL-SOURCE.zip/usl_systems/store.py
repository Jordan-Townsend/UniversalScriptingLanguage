"""Project-safe SQLite task journal and persistent checkpoints."""
import os,json,sqlite3,threading,time
from contextlib import contextmanager
from pathlib import Path

class Store:
    def __init__(self,root=None):
        if root is None:
            base=os.environ.get('LOCALAPPDATA') if os.name=='nt' else os.environ.get('XDG_DATA_HOME',str(Path.home()/'.local'/'share'))
            root=Path(base)/'USL_Universal_Systems'
        self.root=Path(root).expanduser().resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.projects=self.root/'projects';self.projects.mkdir(exist_ok=True)
        self.db=self.root/'runtime.sqlite3';self.lock=threading.RLock()
        with self._db() as conn:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,kind TEXT NOT NULL,status TEXT NOT NULL,request TEXT NOT NULL,result TEXT,created REAL NOT NULL,updated REAL NOT NULL)')
            conn.execute('CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,task_id TEXT,kind TEXT,message TEXT,time REAL NOT NULL)')
            conn.execute('CREATE TABLE IF NOT EXISTS memory(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated REAL NOT NULL)')

    @contextmanager
    def _db(self):
        c=sqlite3.connect(self.db,timeout=12)
        c.row_factory=sqlite3.Row
        try:
            yield c
            c.commit()
        except Exception:
            c.rollback()
            raise
        finally:
            c.close()

    def create(self,task_id,kind,request):
        t=time.time()
        with self.lock,self._db() as c:
            c.execute('INSERT INTO jobs VALUES (?,?,?,?,?,?,?)',(task_id,kind,'queued',json.dumps(request),None,t,t))
            c.execute('INSERT INTO events(task_id,kind,message,time) VALUES (?,?,?,?)',(task_id,'queued',kind,t))

    def update(self,task_id,status,result=None):
        t=time.time()
        with self.lock,self._db() as c:
            c.execute('UPDATE jobs SET status=?,result=?,updated=? WHERE id=?',(status,json.dumps(result,default=str) if result is not None else None,t,task_id))
            c.execute('INSERT INTO events(task_id,kind,message,time) VALUES (?,?,?,?)',(task_id,status,'Task '+status,t))

    def event(self,kind,message,task_id=None):
        with self.lock,self._db() as c:
            c.execute('INSERT INTO events(task_id,kind,message,time) VALUES (?,?,?,?)',(task_id,kind,str(message)[:10000],time.time()))

    def jobs(self,limit=60):
        with self.lock,self._db() as c:
            rs=c.execute('SELECT * FROM jobs ORDER BY created DESC LIMIT ?',(min(int(limit),500),)).fetchall()
            return [self._job(r) for r in rs]

    def job(self,task_id):
        with self.lock,self._db() as c:
            r=c.execute('SELECT * FROM jobs WHERE id=?',(task_id,)).fetchone()
            return self._job(r) if r else None

    @staticmethod
    def _job(r):
        d=dict(r);d['request']=json.loads(d['request']);d['result']=json.loads(d['result']) if d['result'] else None
        return d

    def events(self,limit=60):
        with self.lock,self._db() as c:return [dict(r) for r in c.execute('SELECT * FROM events ORDER BY id DESC LIMIT ?',(min(int(limit),500),)).fetchall()]

    def remember(self,key,value):
        with self.lock,self._db() as c:
            c.execute('INSERT OR REPLACE INTO memory VALUES (?,?,?)',(key,json.dumps(value),time.time()))
    def recall(self,key):
        with self.lock,self._db() as c:
            r=c.execute('SELECT value FROM memory WHERE key=?',(key,)).fetchone();return json.loads(r['value']) if r else None

    def safe_project_path(self,project,relative):
        import re
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',project):raise ValueError('Project name must use letters, digits, hyphens, underscores')
        path=(self.projects/project/relative).resolve()
        root=(self.projects/project).resolve()
        if not path.is_relative_to(root):raise ValueError('Path traversal rejected')
        return path

    def save(self,project,relative,content):
        if len(content.encode('utf8'))>2_000_000:raise ValueError('File size exceeds 2 MB limit')
        path=self.safe_project_path(project,relative)
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(content,encoding='utf8')
        self.event('file',f'Saved {project}/{relative}')
        return {'project':project,'path':relative,'bytes':path.stat().st_size}

    def read(self,project,relative):
        path=self.safe_project_path(project,relative)
        if not path.is_file():raise FileNotFoundError(relative)
        return path.read_text(encoding='utf8')

    def list_projects(self):
        return [{'name':p.name,'files':sum(1 for _ in p.rglob('*') if _.is_file())} for p in self.projects.iterdir() if p.is_dir()]
