"""Real installed Go/JVM source -> compiled guest -> typed USL bridge v1.

Approval and validation come from `interop.run_nested`; native code can perform
arbitrary host actions: the child process is *not* a security sandbox.
"""
from __future__ import annotations
import base64,json,os,shutil,sys,tempfile
from pathlib import Path

ABI='usl.bridge.abi.v1'
GO_TYPES={'i64':'int64','bool':'bool','text':'string','i64[]':'[]int64'}
JAVA_TYPES={'i64':'long','bool':'boolean','text':'String'}
SWIFT_TYPES={'i64':'Int64','bool':'Bool','text':'String','i64[]':'[Int64]'}

def _go_wrapper(export,params):
    defs=[];args=[]
    for i,t in enumerate(params):
        defs.append(f'var p{i} {GO_TYPES[t]}\nif err:=json.Unmarshal(req.Args[{i}],&p{i});err!=nil{{fail(err)}}')
        args.append(f'p{i}')
    return '''package main
import("encoding/json";"fmt";"os")
type Request struct{ Args []json.RawMessage `json:"args"` }
func fail(err error){fmt.Fprintln(os.Stderr,err);os.Exit(5)}
func main(){ var req Request
if err:=json.NewDecoder(os.Stdin).Decode(&req);err!=nil{fail(err)}
if len(req.Args)!=%d {fail(fmt.Errorf("wrong argument count"))}
%s
value:=%s(%s)
if err:=json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"abi":"%s","value":value});err!=nil{fail(err)}
}
'''%(len(params),'\n'.join(defs),export,','.join(args),ABI)

def _java_quote():
    return r'''static String q(String s) { StringBuilder b=new StringBuilder("\"");
for(int i=0;i<s.length();i++){ char c=s.charAt(i);
switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;
case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;
case '\t':b.append("\\t");break;
default:if(c<32){b.append(String.format("\\u%04x",(int)c));} else b.append(c);}}
return b.append('"').toString();}'''

def _java_wrapper(export,params,ret):
    lines=[]
    for i,t in enumerate(params):
        val=f'new String(Base64.getDecoder().decode(args[{i}]),StandardCharsets.UTF_8)'
        if t=='i64': expr=f'Long.parseLong({val})'
        elif t=='bool':
            lines.append(f'String s{i}={val}; if(!s{i}.equals("true")&&!s{i}.equals("false"))throw new IllegalArgumentException("invalid bool");')
            expr=f'Boolean.parseBoolean(s{i})'
        elif t=='text':expr=val
        else:raise ValueError('Java guest ABI type not supported: '+t)
        lines.append(f'{JAVA_TYPES[t]} p{i}={expr};')
    if ret not in JAVA_TYPES:raise ValueError('Java guest return type not supported: '+ret)
    conversion={'i64':'Long.toString(value)','bool':'Boolean.toString(value)','text':'q(value)'}[ret]
    return '''import java.nio.charset.StandardCharsets;
import java.util.Base64;
public class USLBridgeEntry {
%s
public static void main(String[] args) {
if(args.length!=%d)throw new IllegalArgumentException("wrong argument count");
%s
%s value=Guest.%s(%s);
System.out.print("{\\"abi\\":\\"%s\\",\\"value\\":"+%s+"}");
}}
'''%(_java_quote(),len(params),'\n'.join(lines),JAVA_TYPES[ret],export,','.join(f'p{i}' for i in range(len(params))),ABI,conversion)

def _swift_wrapper(export,params,ret):
    expressions=[]
    for i,typ in enumerate(params):
        if typ=='i64': expressions.append(f'try intArg({i})')
        elif typ=='bool': expressions.append(f'try boolArg({i})')
        elif typ=='text': expressions.append(f'try textArg({i})')
        elif typ=='i64[]': expressions.append(f'try arrayArg({i})')
        else:raise ValueError('Unsupported Swift argument ABI type '+typ)
    if ret not in SWIFT_TYPES:raise ValueError('Unsupported Swift return type '+ret)
    return r'''import Foundation
import CoreFoundation
let data=FileHandle.standardInput.readDataToEndOfFile()
let raw=try JSONSerialization.jsonObject(with:data,options:[.fragmentsAllowed])
guard let args=raw as? [Any], args.count==%d else {fatalError("Invalid Swift argument count")}
func intArg(_ i:Int) throws -> Int64 {
 guard let x=args[i] as? NSNumber, CFGetTypeID(x) != CFBooleanGetTypeID() else {throw NSError(domain:"USL",code:1)}
 return x.int64Value
}
func boolArg(_ i:Int) throws -> Bool {
 guard let x=args[i] as? NSNumber, CFGetTypeID(x) == CFBooleanGetTypeID() else {throw NSError(domain:"USL",code:2)}
 return x.boolValue
}
func textArg(_ i:Int) throws -> String {
 guard let x=args[i] as? String else {throw NSError(domain:"USL",code:3)}
 return x
}
func arrayArg(_ i:Int) throws -> [Int64] {
 guard let v=args[i] as? [NSNumber] else {throw NSError(domain:"USL",code:4)}
 return try v.enumerated().map { n,x in
    if CFGetTypeID(x)==CFBooleanGetTypeID() {throw NSError(domain:"USL",code:n+5)}
    return x.int64Value
 }
}
let result: %s = %s(%s)
let reply:[String:Any] = ["abi":"usl.bridge.abi.v1","value":result]
let out=try JSONSerialization.data(withJSONObject:reply,options:[.sortedKeys,.fragmentsAllowed])
FileHandle.standardOutput.write(out)
'''%(len(params), SWIFT_TYPES[ret],export,','.join(expressions))

def execute_guest(lang,node,args,workspace):
    from .interop import _run_process,_json,digest
    params=node['params'];ret=node['returns'];src=node['source'];fn=node['export']
    if lang=='go':
        go=shutil.which('go')
        if not go:raise ValueError('Go toolchain not installed')
        if any(t not in GO_TYPES for t in [*params,ret]):
            raise ValueError('Go guest ABI type not supported')
    elif lang=='java':
        java=shutil.which('java');javac=shutil.which('javac')
        if not java or not javac:raise ValueError('Java toolchain not installed')
        if any(t not in JAVA_TYPES for t in [*params,ret]):
            raise ValueError('Java guest ABI type not supported')
    elif lang=='swift':
        swiftc=shutil.which('swiftc')
        if not swiftc:raise ValueError('Swift compiler not installed')
        if any(t not in SWIFT_TYPES for t in [*params,ret]):
            raise ValueError('Swift guest ABI type not supported')
    else:raise ValueError('Unsupported native guest')
    with tempfile.TemporaryDirectory(prefix='usl-'+lang+'-',dir=workspace) as td:
        root=Path(td)
        if lang=='go':
            if not src.lstrip().startswith('package main'):
                raise ValueError('Go guest requires package main')
            (root/'guest.go').write_text(src,encoding='utf8')
            (root/'usl_bridge.go').write_text(_go_wrapper(fn,params),encoding='utf8')
            exe=root/('guest.exe' if os.name=='nt' else 'guest')
            build=_run_process([go,'build','-o',str(exe),'guest.go','usl_bridge.go'],cwd=root,timeout=85)
            if build['exit_code']!=0:raise ValueError('Go build failed: '+build['stderr'][:600])
            run=_run_process([str(exe)],cwd=root,input_text=_json({'args':args}),timeout=7)
            mode='compiled_go_subprocess'
        elif lang=='java':
            if 'class Guest' not in src: raise ValueError('Java guest requires a class named Guest')
            (root/'Guest.java').write_text(src,encoding='utf8')
            (root/'USLBridgeEntry.java').write_text(_java_wrapper(fn,params,ret),encoding='utf8')
            build=_run_process([javac,'-encoding','UTF-8','-d',str(root),'Guest.java','USLBridgeEntry.java'],cwd=root,timeout=30)
            if build['exit_code']!=0:raise ValueError('Java compile failed: '+build['stderr'][:600])
            tokens=[]
            for a,t in zip(args,params):
                b=('true' if a else 'false') if t=='bool' else str(a)
                tokens.append(base64.b64encode(b.encode('utf8')).decode('ascii'))
            run=_run_process([java,'-cp',str(root),'USLBridgeEntry',*tokens],cwd=root,timeout=8)
            mode='compiled_java_jvm_subprocess'
        elif lang=='swift':
            (root/'guest.swift').write_text(src,encoding='utf8')
            (root/'main.swift').write_text(_swift_wrapper(fn,params,ret),encoding='utf8')
            exe=root/('guest.exe' if os.name=='nt' else 'guest')
            build=_run_process([swiftc,'guest.swift','main.swift','-o',str(exe)],cwd=root,timeout=60)
            if build['exit_code']!=0:raise ValueError('Swift build failed: '+build['stderr'][:600])
            run=_run_process([str(exe)],cwd=root,input_text=_json(args),timeout=7)
            mode='compiled_swift_subprocess'
    if run['exit_code']!=0:raise ValueError(lang+' guest failed: '+run['stderr'][:600])
    try: reply=json.loads(run['stdout'])
    except (ValueError,TypeError) as e:raise ValueError(lang+' invalid bridge response') from e
    if not isinstance(reply,dict) or reply.get('abi')!=ABI or 'value' not in reply:
        raise ValueError(lang+' ABI protocol mismatch')
    return reply['value'],{'mode':mode,'build':build,'run':run,'exit_code':run['exit_code'],
       'duration_ms':build['duration_ms']+run['duration_ms'],'source_sha256':digest(src)}
