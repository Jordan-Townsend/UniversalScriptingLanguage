"""USL Autonomous Task Controller v0.6.

Durable owner-approved, bounded observe/execute/verify/checkpoint state machine.
External processes are opt-in, never restarted automatically after a crash.
A plan is DATA; generating or submitting it does not authorize execution.
Not a general OS sandbox or arbitrary desktop accessibility driver.
"""
from __future__ import annotations
import hashlib
import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4
from .language import Interpreter
from .compiler import transpile
from .native import verify as native_verify
from .equations import evaluate
from .equation_import import EquationWorkspace
from .legacy_runtime import bridge_status, bridge_latest_report, shadow_health, emovision_health
from .agent import ask_model
from .bridge_cycle import execute_cycle
from .collapse import collapse_bytes, restore_bytes
from .fractal import FactoredFractal, ServiceTensorPlanner
from .incremental import CollapseCompute
from .fabric import Fabric
from .repairloop import RepairLoop


class AutonomyError(ValueError):
    pass


KINDS = {'usl', 'compile', 'verify', 'equation', 'process', 'bridge_health',
         'shadow_health', 'emovision_health', 'model_chat', 'collapse', 'fractal',
         'incremental', 'resource_placement', 'fabric_flow', 'bridge_report', 'bridge_cycle', 'dev_repair'}
SAFE_TO_RETRY = {'usl', 'compile', 'verify', 'equation', 'bridge_health',
                 'shadow_health', 'emovision_health', 'collapse', 'fractal',
                 'incremental', 'resource_placement', 'fabric_flow', 'bridge_report'}
TERMINAL = {'completed', 'failed', 'cancelled', 'needs_review'}
STEP_ID = re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{0,47}$')
# An approved plan can wire narrowly typed *verified* outputs to later safe steps.
# Never accept bound executable arguments, service URLs or process command lines.
BOUND_FIELDS = {
    'usl': {'source'}, 'compile': {'source'}, 'verify': {'source'},
    'equation': {'params'}, 'collapse': {'text', 'reference'},
    'fractal': {'values'}, 'incremental': {'values'},
}
BINDING_PATH = re.compile(r'^result(?:\.[A-Za-z_][A-Za-z0-9_]{0,47}){1,6}$')


def _ordered_plan(plan):
    """Stable topological plan order, retaining original order among free steps."""
    steps = plan['steps']
    by_id = {s['id']:s for s in steps}
    result=[];ready=set()
    while len(result)<len(steps):
        available=next((s for s in steps if s['id'] not in ready
                        and all(d in ready for d in s.get('depends_on', []))),None)
        if available is None:
            raise AutonomyError('Step dependencies contain a cycle')
        result.append(available);ready.add(available['id'])
    return {**plan, 'steps':result}


def _resolve_inputs(step, completed):
    """Resolve only explicitly approved, typed references from successful prior steps."""
    if not step.get('inputs'):
        return step
    copy=dict(step)
    for key, reference in step['inputs'].items():
        outcome=completed.get(reference['step'])
        if not outcome or outcome.get('successful') is not True:
            raise AutonomyError('Input dependency has no verified successful outcome')
        node=outcome
        for name in reference['path'].split('.'):
            if not isinstance(node,dict) or name not in node:
                raise AutonomyError('Bound input is missing: '+reference['step']+'.'+reference['path'])
            node=node[name]
        if isinstance(node,(dict,list)):
            if len(json.dumps(node))>60000:raise AutonomyError('Bound input exceeds size limit')
        elif type(node) not in (str,int,float,bool) and node is not None:
            raise AutonomyError('Unserializable bound input')
        elif type(node) is str and len(node)>30000:
            raise AutonomyError('Bound text exceeds size limit')
        copy[key]=node
    copy.pop('inputs',None)
    copy.pop('depends_on',None)
    # Enforce all the original static input limits after binding has completed.
    validate_plan({'format':'uslauto-1','steps':[copy]})
    return copy



def _check_expected(expected, result):
    """Comparison is precise and deterministic; never ask a model to self-grade."""
    if not expected:
        return {'passed': True, 'checks': [], 'type': 'no_assertions'}
    tests = []
    if 'output_equals' in expected:
        tests.append({'assertion': 'output_equals', 'passed': result.get('output') == expected['output_equals']})
    if 'output_contains' in expected:
        tests.append({'assertion': 'output_contains', 'passed': expected['output_contains'] in str(result.get('output', ''))})
    if 'exit_code' in expected:
        tests.append({'assertion': 'exit_code', 'passed': result.get('exit_code') == expected['exit_code']})
    if 'status' in expected:
        tests.append({'assertion': 'status', 'passed': result.get('status') == expected['status']})
    if 'field' in expected:
        cur = result
        for piece in expected['field'].split('.'):
            cur = cur.get(piece, None) if isinstance(cur, dict) else None
        tests.append({'assertion': 'field', 'passed': cur == expected['equals']})
    return {'passed': all(t['passed'] for t in tests), 'checks': tests, 'type': 'asserted'}


def validate_plan(plan):
    if not isinstance(plan, dict) or plan.get('format') != 'uslauto-1':
        raise AutonomyError('Expected uslauto-1 plan object')
    steps = plan.get('steps')
    if not isinstance(steps, list) or not 1 <= len(steps) <= 32:
        raise AutonomyError('Plan must have 1..32 steps')
    ids = set()
    # Forward references are permitted: plans are normalized into a safe DAG order.
    known_ids={s.get('id') for s in steps if isinstance(s,dict) and isinstance(s.get('id'),str)}
    allowed = {'id', 'kind', 'source', 'target', 'params', 'equation_id', 'argv',
               'project', 'timeout', 'expected', 'url', 'prompt', 'model', 'text', 'reference',
               'mode', 'values', 'operator', 'dimensions', 'changes', 'requirements',
               'capacities', 'workers', 'depth', 'leaf_size', 'path', 'audit', 'depends_on', 'inputs',
               'original_sha256', 'old', 'new', 'check'}
    for step in steps:
        if not isinstance(step, dict) or set(step) - allowed:
            raise AutonomyError('Invalid step or unsupported attributes')
        ident = step.get('id')
        if not isinstance(ident, str) or not STEP_ID.fullmatch(ident) or ident in ids:
            raise AutonomyError('Invalid or duplicate step id')
        ids.add(ident)
        deps=step.get('depends_on', [])
        if not isinstance(deps,list) or len(deps)>32 or len(set(str(x) for x in deps))!=len(deps) or any(not isinstance(x,str) or x==ident or x not in known_ids for x in deps):
            raise AutonomyError('Invalid, duplicate, unknown or self-referential dependency')
        inputs=step.get('inputs', {})
        if not isinstance(inputs,dict) or len(inputs)>8:
            raise AutonomyError('Invalid bounded input bindings')
        for dest, ref in inputs.items():
            if dest not in BOUND_FIELDS.get(step.get('kind'), set()):
                raise AutonomyError('Inputs cannot change this field or operation kind')
            if not isinstance(ref,dict) or set(ref)!={'step','path'}:
                raise AutonomyError('Invalid typed input reference')
            if ref['step'] not in deps or not isinstance(ref['path'],str) or not BINDING_PATH.fullmatch(ref['path']):
                raise AutonomyError('Input must reference a declared dependency and result field')
        kind = step.get('kind')
        if kind not in KINDS:
            raise AutonomyError('Unsupported step kind: ' + str(kind))
        expected = step.get('expected', {})
        if not isinstance(expected, dict) or set(expected) - {'output_equals', 'output_contains', 'exit_code', 'status', 'field', 'equals'}:
            raise AutonomyError('Invalid assertions')
        if any(k in expected for k in ('output_equals', 'output_contains')):
            for k in ('output_equals', 'output_contains'):
                if k in expected and (not isinstance(expected[k], str) or len(expected[k]) > 8192):
                    raise AutonomyError('Expected output must be bounded string')
        if 'exit_code' in expected and (type(expected['exit_code']) is not int or not -32768 <= expected['exit_code'] <= 32768):
            raise AutonomyError('Expected exit_code must be integer')
        if 'field' in expected and (not isinstance(expected['field'], str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', expected['field']) or 'equals' not in expected):
            raise AutonomyError('Expected field must have a value to compare')
        if kind in ('usl', 'compile', 'verify') and 'source' not in inputs and (not isinstance(step.get('source'), str) or len(step['source']) > 30000):
            raise AutonomyError('USL source must be a string up to 30,000 characters')
        if kind == 'equation' and (not isinstance(step.get('equation_id'), str) or ('params' not in inputs and not isinstance(step.get('params'), dict))):
            raise AutonomyError('Equation needs an ID and parameter object')
        if kind == 'dev_repair':
            RepairLoop.validate(step)
            if not isinstance(step.get('project'),str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',step['project']):
                raise AutonomyError('Repair requires an existing bounded project name')
        if kind == 'process':
            argv = step.get('argv')
            if not isinstance(argv, list) or not 1 <= len(argv) <= 20 or any(not isinstance(x, str) or not 1 <= len(x) <= 512 or '\x00' in x for x in argv):
                raise AutonomyError('Process argv must be 1..20 nonempty bounded strings')
            if not isinstance(step.get('project', 'autonomy'), str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', step.get('project', 'autonomy')):
                raise AutonomyError('Invalid process project')
        if kind == 'collapse' and (('text' not in inputs and (not isinstance(step.get('text'),str) or len(step['text']) > 60000)) or ('reference' not in inputs and (not isinstance(step.get('reference',''),str) or len(step.get('reference','')) > 60000))):
            raise AutonomyError('Compression input/reference must be bounded strings')
        if kind == 'fractal' and step.get('mode','async') not in ('sync','async','process'):
            raise AutonomyError('Invalid fractal scheduler mode')
        if kind in ('fractal','incremental') and 'values' not in inputs and (not isinstance(step.get('values'), list) or len(step['values']) > 50000):
            raise AutonomyError('Worker input requires 0..50,000 values')
        if kind == 'incremental' and not isinstance(step.get('changes', {}),dict):
            raise AutonomyError('Incremental changes must be a mapping')
        if kind == 'resource_placement' and (not isinstance(step.get('requirements'), list) or not isinstance(step.get('capacities'), list)):
            raise AutonomyError('Resource placement requires requirements and capacities')
        if kind == 'fabric_flow':
            if not isinstance(step.get('project'),str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',step['project']):
                raise AutonomyError('Fabric flow requires valid project')
            if not isinstance(step.get('path'),str) or len(step['path'])>200:
                raise AutonomyError('Fabric flow needs saved workflow path')
        if kind == 'bridge_cycle' and (not isinstance(step.get('prompt'),str) or not 15 <= len(step['prompt']) <= 3000):
            raise AutonomyError('Bridge cycle requires a reviewed 15..3000-character goal')
        if kind == 'model_chat' and (not isinstance(step.get('prompt'), str) or not 1 <= len(step['prompt']) <= 8000):
            raise AutonomyError('Model chat requires a bounded prompt')
        if 'url' in step and (kind not in ('shadow_health', 'emovision_health') or not isinstance(step['url'], str) or len(step['url']) > 128):
            raise AutonomyError('Invalid service URL')
        if 'timeout' in step and (type(step['timeout']) is not int or not 1 <= step['timeout'] <= 300):
            raise AutonomyError('Step timeout must be 1..300 seconds')
    if len(json.dumps(plan, ensure_ascii=False)) > 150000:
        raise AutonomyError('Plan too large')
    _ordered_plan(plan)  # validates that the DAG terminates; does not mutate the caller.
    return plan


class AutonomyController:
    def __init__(self, store, bridge=None, workers=2):
        self.store = store
        self.bridge = bridge
        self.lock = threading.RLock()
        self.pool = ThreadPoolExecutor(max_workers=max(1, min(int(workers), 3)), thread_name_prefix='usl-auto')
        self.pending = set()
        with store.lock, store._db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS autonomous_runs (
                id TEXT PRIMARY KEY, status TEXT NOT NULL, plan TEXT NOT NULL,
                cursor INTEGER NOT NULL, outcomes TEXT NOT NULL, approved INTEGER NOT NULL,
                allow_process INTEGER NOT NULL, current_child TEXT, cancel_requested INTEGER NOT NULL,
                created REAL NOT NULL, updated REAL NOT NULL)''')
            rows = db.execute("SELECT id,plan,cursor FROM autonomous_runs WHERE status='running'").fetchall()
            for row in rows:
                try:
                    kind = json.loads(row['plan'])['steps'][row['cursor']]['kind']
                except (ValueError, IndexError, KeyError):
                    kind = 'process'
                status = 'paused' if kind in SAFE_TO_RETRY else 'needs_review'
                db.execute('UPDATE autonomous_runs SET status=?, updated=? WHERE id=?', (status, time.time(), row['id']))

    def close(self):
        self.pool.shutdown(wait=False, cancel_futures=True)

    def _update(self, rid, **updates):
        if not updates:
            return
        with self.store.lock, self.store._db() as db:
            updates['updated'] = time.time()
            fields = ','.join(k + '=?' for k in updates)
            db.execute('UPDATE autonomous_runs SET ' + fields + ' WHERE id=?', [*updates.values(), rid])

    @staticmethod
    def _parse(row):
        if row is None:
            raise AutonomyError('Unknown autonomous run')
        obj = dict(row)
        obj['plan'] = json.loads(obj['plan'])
        obj['outcomes'] = json.loads(obj['outcomes'])
        obj['approved'] = bool(obj['approved'])
        obj['allow_process'] = bool(obj['allow_process'])
        obj['cancel_requested'] = bool(obj['cancel_requested'])
        return obj

    def detail(self, rid):
        with self.store.lock, self.store._db() as db:
            row = db.execute('SELECT * FROM autonomous_runs WHERE id=?', (rid,)).fetchone()
        return self._parse(row)

    def list(self, limit=40):
        with self.store.lock, self.store._db() as db:
            rows = db.execute('SELECT id,status,cursor,approved,created,updated FROM autonomous_runs ORDER BY created DESC LIMIT ?', (min(100,max(1,int(limit))),)).fetchall()
            return [dict(r) for r in rows]

    def propose(self, goal, model=None):
        """Local model proposes *data* only. Never grants approval or runs tools."""
        if not isinstance(goal,str) or not 5 <= len(goal) <= 3000:
            raise AutonomyError('Goal length must be 5..3000 characters')
        instruction=(
            'Generate one JSON object only, no markdown. Schema: '
            '{"format":"uslauto-1","name":"short title","steps":['
            '{"id":"one","kind":"usl","source":"let x = 5\\nprint(x)",'
            '"expected":{"output_contains":"5"}}]}. '
            'At most 8 steps. Allowed kinds: usl, compile, verify, equation, collapse, '
            'fractal, incremental, resource_placement, bridge_health, shadow_health, emovision_health. '
            'Use only tested USL subset syntax: let, print, assert, arithmetic, conditions, loops, functions. '
            'Include deterministic assertions for every code-producing or executing step. '
            'Never include external process launches, filesystem writes, network operations, credentials, '
            'or claims of verified physical experiments. Request:\n' + goal
        )
        response=ask_model(instruction,model=model,timeout=100)
        candidate=response.strip()
        if candidate.startswith('```'):
            candidate=candidate.split('\n',1)[-1].rsplit('```',1)[0].strip()
        try:
            plan=json.loads(candidate)
        except ValueError as exc:
            raise AutonomyError('Local model did not return a valid JSON plan') from exc
        validate_plan(plan)
        if len(plan['steps']) > 8 or any(step['kind'] in ('process','model_chat','fabric_flow') for step in plan['steps']):
            raise AutonomyError('Proposed plan includes an unapproved external operation')
        for step in plan['steps']:
            if step['kind'] in ('usl','compile','verify') and not step.get('expected'):
                raise AutonomyError('Generated executable steps require deterministic assertions')
        record=self.create(plan)
        self.store.event('autonomy','Untrusted local model plan drafted for human review; no action executed',record['id'])
        return record

    def create(self, plan):
        validate_plan(plan)
        plan=_ordered_plan(plan)
        rid = uuid4().hex[:20]
        now = time.time()
        with self.store.lock, self.store._db() as db:
            db.execute('INSERT INTO autonomous_runs VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                       (rid, 'draft', json.dumps(plan), 0, '[]', 0, 0, None, 0, now, now))
        self.store.event('autonomy', 'Draft received; execution requires explicit approval', rid)
        return self.detail(rid)

    def approve(self, rid, *, allow_process=False):
        with self.lock:
            record = self.detail(rid)
            if record['status'] != 'draft':
                raise AutonomyError('Only draft plans can be approved')
            if any(x['kind'] in ('process','bridge_cycle','dev_repair') for x in record['plan']['steps']) and not allow_process:
                raise AutonomyError('Process steps require explicit allow_process=true approval')
            self._update(rid, approved=1, allow_process=int(bool(allow_process)), status='ready')
            self.store.event('autonomy', 'Owner approved exact plan', rid)
            return self.detail(rid)

    def begin(self, rid):
        with self.lock:
            record = self.detail(rid)
            if not record['approved'] or record['status'] not in ('ready', 'paused'):
                raise AutonomyError('Run is not approved and ready/paused')
            if rid in self.pending:
                raise AutonomyError('Already executing')
            self.pending.add(rid)
            self._update(rid, status='running', cancel_requested=0)
            self.pool.submit(self._work, rid)
            return self.detail(rid)

    def cancel(self, rid):
        record = self.detail(rid)
        if record['status'] in TERMINAL:
            return record
        self._update(rid, cancel_requested=1)
        if record['status'] in ('draft', 'ready', 'paused'):
            self._update(rid, status='cancelled')
        if record['current_child'] and self.bridge:
            try:
                self.bridge.stop(record['current_child'])
            except (ValueError, OSError):
                pass
        self.store.event('autonomy', 'Cancellation requested', rid)
        return self.detail(rid)

    def _run_step(self, rid, step):
        kind = step['kind']
        if kind == 'usl':
            result = Interpreter(timeout=min(6, step.get('timeout', 6)), max_ops=100000).run(step['source'])
            return {'status':'completed', 'output': result.output, 'operations': result.operations, 'elapsed_ms': result.elapsed_ms,
                    'source_sha256': hashlib.sha256(step['source'].encode()).hexdigest()}
        if kind == 'compile':
            g = transpile(step['source'], step.get('target', 'python'))
            return {'status':'completed','language':g.target,'filename':g.filename,'code_sha256':hashlib.sha256(g.code.encode()).hexdigest(),
                    'code_preview':g.code[:1500], 'emitter_tier':g.tier}
        if kind == 'verify':
            result = native_verify(step['source'], step.get('target', 'python'))
            return {'status': result.get('status','unknown'), 'verification': result}
        if kind == 'equation':
            result = evaluate(step['equation_id'],step['params'],extra=EquationWorkspace(self.store.root).records())
            return {'status': 'completed','evaluation': result}
        if kind == 'bridge_health':
            return bridge_status()
        if kind == 'bridge_report':
            return bridge_latest_report()
        if kind == 'shadow_health':
            return shadow_health(step.get('url','http://127.0.0.1:8767'), allow_unauthenticated=True)
        if kind == 'emovision_health':
            return emovision_health(step.get('url','http://127.0.0.1:8774'), allow_unauthenticated=True)
        if kind == 'collapse':
            original=step['text'].encode('utf8')
            reference=step.get('reference','').encode('utf8') if step.get('reference') is not None else None
            compressed=collapse_bytes(original, reference, step.get('mode','all'))
            exact=restore_bytes(compressed,reference)==original
            if not exact:raise AutonomyError('Codec failed exact roundtrip')
            return {'status':'completed','codec':compressed['codec'],'raw_bytes':compressed['raw_bytes'],
                    'encoded_bytes':compressed['encoded_bytes'],'sha256':compressed['sha256'],'exact':True}
        if kind == 'fractal':
            engine=FactoredFractal(workers=step.get('workers',4),max_depth=step.get('depth',5),leaf_size=step.get('leaf_size',512))
            result=engine.execute(step['values'],operator=step.get('operator','sum_squares'),
                dimensions=step.get('dimensions',['execution','cache','verification']),mode=step.get('mode','async'))
            if result.get('verified_exact') is not True:
                raise AutonomyError('Factored worker exact reference verification was not successful')
            return {'status':'completed','work':result}
        if kind == 'incremental':
            engine=CollapseCompute(step.get('operator','sum_squares'))
            initial=engine.initialize(step['values'])
            updated=engine.update({int(k):v for k,v in step.get('changes',{}).items()},audit=step.get('audit',True))
            if not updated['correct']:raise AutonomyError('Incremental update verification failed')
            return {'status':'completed','initial':initial,'updated':updated}
        if kind == 'resource_placement':
            return {'status':'completed','placement':ServiceTensorPlanner().plan(step['requirements'],step['capacities'])}
        if kind == 'fabric_flow':
            filename=self.store.safe_project_path(step['project'],step['path'])
            report=Fabric(self.store).execute(filename,allow_native=False)
            if not report['success']:raise AutonomyError('Nested workflow failed verification')
            return {'status':'completed','flow':report}
        if kind == 'bridge_cycle':
            if not self.detail(rid)['allow_process']:
                raise AutonomyError('External bridge automation was not explicitly authorized')
            def cancelled():return bool(self.detail(rid)['cancel_requested'])
            def armed():self._update(rid,current_child='bridge_cycle:external')
            return execute_cycle(step['prompt'],timeout=step.get('timeout',45),cancel=cancelled,on_arm=armed)
        if kind == 'model_chat':
            reply = ask_model(step['prompt'],step.get('model'),timeout=step.get('timeout',90))
            return {'status': 'completed', 'output': reply[:12000], 'provider':'local-ollama'}
        if kind == 'dev_repair':
            if not self.detail(rid)['allow_process']:
                raise AutonomyError('Repair test execution requires explicit allow_process approval')
            return RepairLoop(self.store).run(step['project'],step)
        if kind == 'process':
            if not self.bridge:
                raise AutonomyError('Process bridge not available')
            if not self.detail(rid)['allow_process']:
                raise AutonomyError('Process steps were not authorized')
            result = self.bridge.launch(step.get('project','autonomy'), step['argv'], step.get('timeout',30))
            if result['status'] == 'launch_failed':
                raise AutonomyError('Launch failed: '+result.get('output','')[:300])
            ident = result['id']
            self._update(rid, current_child=ident)
            end = time.monotonic()+step.get('timeout',30)+6
            while time.monotonic() < end:
                record = self.detail(rid)
                if record['cancel_requested']:
                    try:self.bridge.stop(ident)
                    except ValueError:pass
                result = self.bridge.detail(ident)
                if result['status'] not in ('running','starting','stopping'):
                    return {'status': result['status'], 'exit_code': result['exit_code'],
                            'output': result['output'][-8192:], 'truncated': result['truncated'], 'process_id': ident}
                time.sleep(.07)
            raise AutonomyError('Process supervisor did not settle within budget')
        raise AutonomyError('Unsupported step')

    def _work(self, rid):
        try:
            record = self.detail(rid)
            steps = record['plan']['steps']
            while record['cursor'] < len(steps):
                if record['cancel_requested']:
                    self._update(rid, status='cancelled', current_child=None)
                    return
                i=record['cursor']; step=steps[i]
                self.store.event('autonomy', 'Executing '+step['id']+' ('+step['kind']+')', rid)
                try:
                    started=time.monotonic()
                    verified={x['id']:x for x in record['outcomes'] if x.get('successful') is True}
                    bound_step=_resolve_inputs(step,verified)
                    result=self._run_step(rid,bound_step)
                    proof=_check_expected(step.get('expected',{}), result)
                    ok=proof['passed'] and result.get('status') not in ('failed','timed_out','stopped','launch_failed','interrupted')
                    # For a process, only successful exit 0 counts even without explicit assertions.
                    if step['kind']=='process' and result.get('exit_code') != 0:ok=False
                    if step['kind']=='dev_repair' and result.get('verified') is not True:ok=False
                    if step['kind']=='verify' and result.get('status') not in ('passed','verified'):ok=False
                    if step['kind'] in ('bridge_report','bridge_cycle') and (result.get('status') != 'completed' or result.get('verified_task') is not True):ok=False
                    if step['kind'] in ('bridge_health','shadow_health','emovision_health') and result.get('connected') is not True:ok=False
                    outcome={'id':step['id'],'kind':step['kind'],'successful':bool(ok),'result':result,
                             'proof':proof,'elapsed_ms':round((time.monotonic()-started)*1000,3)}
                except Exception as exc:
                    outcome={'id':step['id'],'kind':step['kind'],'successful':False,
                             'error':f'{type(exc).__name__}: {str(exc)[:900]}'}
                with self.lock:
                    record=self.detail(rid)
                    outcomes=record['outcomes']+[outcome]
                    if record['cancel_requested']:
                        status='cancelled'
                    elif not outcome['successful']:
                        status='failed'
                    else:
                        status='completed' if i+1 == len(steps) else 'running'
                    self._update(rid,outcomes=json.dumps(outcomes),cursor=i+1,status=status,current_child=None)
                    self.store.event('autonomy', f'{step["id"]}: {status}',rid)
                    if status!='running':return
                    record=self.detail(rid)
        finally:
            with self.lock:
                self.pending.discard(rid)
