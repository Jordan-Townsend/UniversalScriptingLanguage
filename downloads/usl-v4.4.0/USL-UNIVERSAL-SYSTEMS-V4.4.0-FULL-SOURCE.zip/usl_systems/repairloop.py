"""Approved, deterministic repair-and-retest on a COPY of a local USL project.

Security boundary: this is *not* a sandbox. Project tests execute real user-approved
Python code with the invoking account's privileges. It never automatically runs a
model-suggested patch or edits files outside Store.projects. External side effects
must remain disabled in the projects being tested; the runner cannot enforce this.
"""
from __future__ import annotations
import hashlib
import json
import signal
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path
from .store import Store

class RepairError(ValueError):pass
_MUTEX=threading.RLock()
_SAFE=re.compile(r'^[a-zA-Z0-9_./-]{1,128}$')


def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()


def _relpath(relative):
    if not isinstance(relative,str) or not _SAFE.fullmatch(relative) or '\\' in relative:
        raise RepairError('Repair path must be a bounded relative Python filename')
    p=Path(relative)
    if p.is_absolute() or '..' in p.parts or p.suffix!='.py' or p.parts[0].startswith('.'):
        raise RepairError('Repair supports safe relative .py files only')
    return p


def _run(argv,root,seconds):
    """Launch a finite, monitored test process. Timeout kills the child tree."""
    env=dict(os.environ);env['PYTHONPATH']=str(root);env['PYTHONNOUSERSITE']='1'
    options={'cwd':root,'stdout':subprocess.PIPE,'stderr':subprocess.STDOUT,
             'text':True,'errors':'replace','env':env,'stdin':subprocess.DEVNULL}
    if os.name=='nt':options['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    else:options['start_new_session']=True
    child=subprocess.Popen(argv,**options)
    timed_out=False
    try:
        output,_=child.communicate(timeout=seconds)
    except subprocess.TimeoutExpired:
        timed_out=True
        if os.name=='nt':
            try:subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True,timeout=4)
            except (OSError,subprocess.TimeoutExpired):child.kill()
        else:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        output,_=child.communicate(timeout=4)
    return {'exit_code':child.returncode,'output':output[-12000:],
            'argv':['python',*argv[1:]],'timed_out':timed_out}


def _snapshot_project(source,dest):
    """Refuse symlinks and unbounded copies; excludes generated data and secrets."""
    n=0;total=0
    for p in source.rglob('*'):
        if p.is_symlink():raise RepairError('Symlinks are not allowed in staged repair projects')
        if p.is_dir():continue
        if not p.is_file():raise RepairError('Unsupported project file')
        rel=p.relative_to(source)
        if any(part.startswith('.') for part in rel.parts) or '__pycache__' in rel.parts:
            continue
        n+=1;size=p.stat().st_size;total+=size
        if n>500 or total>8_000_000:raise RepairError('Project copy size limit exceeded')
        target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,target)
    return {'file_count':n,'source_bytes':total}


class RepairLoop:
    def __init__(self,store:Store):self.store=store

    @staticmethod
    def validate(step):
        if not isinstance(step,dict):raise RepairError('Repair specification must be an object')
        rel=_relpath(step.get('path'))
        original=step.get('original_sha256')
        if not isinstance(original,str) or not re.fullmatch(r'[0-9a-f]{64}',original):
            raise RepairError('An exact original_sha256 is required; stale repairs must fail closed')
        for key in ('old','new'):
            if not isinstance(step.get(key),str) or not 1<=len(step[key])<=12000:
                raise RepairError('Exact old/new replacement text required (max 12KB)')
        if step['old']==step['new']:raise RepairError('No-op repair refused')
        if step.get('check','unittest') not in ('unittest','py_compile'):
            raise RepairError('Allowed checks: unittest, py_compile')
        seconds=step.get('timeout',15)
        if type(seconds) not in (int,float) or not 1<=seconds<=90:
            raise RepairError('Test timeout must be 1..90 seconds')
        return rel

    def run(self,project,step):
        rel=self.validate(step)
        # Store's safe path enforces a project namespace and resolves traversal.
        src=self.store.safe_project_path(project,'.')
        file=self.store.safe_project_path(project,rel.as_posix())
        if not file.is_file():raise RepairError('Existing source file not found')
        if file.is_symlink() or src.is_symlink():raise RepairError('Symlinks not supported')
        with _MUTEX:
            initial=file.read_bytes()
            if sha(initial)!=step['original_sha256']:raise RepairError('Source hash changed; create a fresh approved repair')
            content=initial.decode('utf8')
            if content.count(step['old'])!=1:raise RepairError('Old text must appear exactly once')
            candidate=content.replace(step['old'],step['new'],1).encode('utf8')
            if len(candidate)>2_000_000:raise RepairError('Candidate file exceeds 2MB')
            evidence={'project':project,'path':rel.as_posix(),'original_sha256':sha(initial),
                      'candidate_sha256':sha(candidate),'status':'not_applied'}
            with tempfile.TemporaryDirectory(prefix='usl-repair-') as t:
                staged=Path(t)/'project';staged.mkdir()
                evidence['snapshot']=_snapshot_project(src,staged)
                original_stage=staged/rel
                original_stage.write_bytes(initial)
                before=_run([sys.executable,'-m','py_compile',rel.as_posix()],staged,step.get('timeout',15))
                evidence['baseline_syntax']=before
                original_stage.write_bytes(candidate)
                compilecheck=_run([sys.executable,'-m','py_compile',rel.as_posix()],staged,step.get('timeout',15))
                evidence['candidate_syntax']=compilecheck
                if compilecheck['exit_code']!=0:
                    return evidence
                if step.get('check','unittest')=='unittest':
                    result=_run([sys.executable,'-m','unittest','discover','-s','tests','-p','test*.py'],staged,step.get('timeout',15))
                    evidence['tests']=result
                    if result['exit_code']!=0 or result['timed_out'] or not re.search(r'Ran [1-9][0-9]* tests?',result['output']):
                        return evidence
                # Still inside mutation lock; check original file again before applying.
                if sha(file.read_bytes())!=evidence['original_sha256']:
                    raise RepairError('Source modified during verification')
                backups=self.store.root/'repair_backups'/project
                backups.mkdir(parents=True,exist_ok=True)
                bpath=backups/(uuid.uuid4().hex+'.bak')
                bpath.write_bytes(initial)
                tmp=file.with_name(file.name+'.usl-'+uuid.uuid4().hex+'.tmp')
                try:
                    tmp.write_bytes(candidate)
                    os.replace(tmp,file)
                finally:
                    if tmp.exists():tmp.unlink()
                evidence.update({'status':'completed','verified':True,'backup':str(bpath),
                                 'source_sha256_after':sha(file.read_bytes())})
                self.store.event('repair','Verified staged repair committed: '+project+'/'+str(rel))
            return evidence
