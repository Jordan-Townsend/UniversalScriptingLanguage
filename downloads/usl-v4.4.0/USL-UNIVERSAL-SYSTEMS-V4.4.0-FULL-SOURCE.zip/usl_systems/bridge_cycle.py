"""Owner-approved Chrome Bridge V3 automation cycle with verified completion.

Starting an upstream cycle is a side effect. Never automatically replay it after
an interrupted run, and never infer a completed task from network connectivity.
"""
from __future__ import annotations
import json, os, time, urllib.request, urllib.error
from pathlib import Path
from .legacy_runtime import _safe_local_service, LegacyError, bridge_latest_report

DEFAULT_URL='http://127.0.0.1:8766'


def _pairing_token():
    token=os.environ.get('USL_BRIDGE_TOKEN','').strip()
    if not token:
        folder=Path(os.environ.get('USL_BRIDGE_DATA',str(Path.home()/'USL_Chrome_Bridge_Data')))
        f=folder/'pairing_token.txt'
        if f.is_file():token=f.read_text(encoding='utf8').strip()
    if not 16<=len(token)<=512 or any(x in token for x in '\r\n'):
        raise LegacyError('A valid local Chrome Bridge pairing token is required')
    return token


def _post(path, data=None, *, url=DEFAULT_URL, timeout=3):
    # The shared read adapter validates the exact loopback authority, without DNS.
    from urllib.parse import urlsplit
    p=urlsplit(url)
    if p.scheme!='http' or p.hostname!='127.0.0.1' or not p.port or p.port<1024 or p.username or p.password or p.path not in ('','/') or p.query or p.fragment:
        raise LegacyError('Chrome Bridge must use literal loopback IPv4 HTTP URL with explicit port')
    payload=json.dumps(data if data is not None else {},ensure_ascii=False).encode('utf8')
    request=urllib.request.Request(url.rstrip('/')+path, data=payload, method='POST',
             headers={'Authorization':'Bearer '+_pairing_token(),'Content-Type':'application/json','Accept':'application/json'})
    try:
        with urllib.request.urlopen(request,timeout=min(5,max(.2,float(timeout)))) as r:
            blob=r.read(65537)
            if len(blob)>65536:raise LegacyError('Bridge response exceeds size limit')
            obj=json.loads(blob)
            if not isinstance(obj,dict) or obj.get('ok') is not True:
                raise LegacyError('Bridge rejected request')
            return obj
    except (urllib.error.URLError, OSError, TimeoutError, ValueError) as exc:
        raise LegacyError('Authenticated bridge request failed: '+type(exc).__name__) from exc


def _snapshot(url):
    # Bridge protocol does not return a correlation id when a cycle is armed.
    # Capture prior report ID so stale completed jobs cannot be mistaken as new.
    obj=_safe_local_service(url,'/api/latest',token=_pairing_token())
    if obj.get('ok') is not True:raise LegacyError('Bridge does not expose latest report')
    report=obj.get('report')
    return report.get('id') if isinstance(report,dict) else None


def execute_cycle(goal, timeout=45, *, url=DEFAULT_URL, cancel=None, on_arm=None, poll_interval=.25):
    """Run an explicitly approved cycle; require fresh upstream proof to succeed.

    `on_arm` fires BEFORE the side-effecting network request, so the journal can
    record potential in-flight external work even if the request times out.
    """
    if not isinstance(goal,str) or not 15<=len(goal)<=3000:
        raise LegacyError('Bridge automation goal must be 15..3000 characters')
    if type(timeout) not in (int,float) or not 1<=timeout<=300:
        raise LegacyError('Bridge cycle timeout must be 1..300 seconds')
    if not 0.02<=poll_interval<=5:raise LegacyError('Invalid polling interval')
    prior=_snapshot(url)
    # Never reset another already-armed browser cycle. V3's start endpoint would
    # otherwise replace its goal and report queue without a correlation ID.
    before=_safe_local_service(url,'/api/status',token=_pairing_token())
    if before.get('ok') is not True:
        raise LegacyError('Bridge status unavailable before cycle authorization')
    existing=before.get('automation') or {}
    if isinstance(existing,dict) and existing.get('active') is True:
        raise LegacyError('Another browser automation is already active; do not overwrite it')
    if cancel and cancel():return {'status':'cancelled','verified_task':False}
    if on_arm:on_arm()
    # Start is *inside* finally: an accepted request can lose its HTTP reply,
    # and must still get a best-effort stop, avoiding orphaned active cycles.
    probes=0
    try:
        _post('/api/automation_start',{'goal':goal},url=url)
        until=time.monotonic()+timeout
        while time.monotonic()<until:
            if cancel and cancel():
                return {'status':'cancelled','verified_task':False,'probes':probes}
            # Real upstream report. No client-generated success or inferred status.
            report=_safe_local_service(url,'/api/latest',token=_pairing_token()).get('report')
            state=_safe_local_service(url,'/api/status',token=_pairing_token())
            probes+=1
            if isinstance(report,dict):
                rid=report.get('id')
                if rid is not None and rid!=prior:
                    # Real recovered V3 reports contain id/text/status/at, NOT
                    # verified/success. Its acceptance gate lives in /api/status.
                    auto=state.get('automation',{})
                    if (state.get('ok') is True and state.get('completed') is True
                        and isinstance(auto,dict) and auto.get('phase') == 'verified'
                        and any(str(job.get('id'))==str(rid) and job.get('status')=='finished'
                                for job in state.get('jobs',[]) if isinstance(job,dict))):
                        return {'status':'completed','verified_task':True,'report_id':str(rid)[:128],'probes':probes}
                    if report.get('status') in ('failed','cancelled','rejected'):
                        return {'status':'failed','verified_task':False,'report_id':str(rid)[:128],'probes':probes}
            time.sleep(min(poll_interval,max(0,until-time.monotonic())))
        return {'status':'timed_out','verified_task':False,'probes':probes}
    finally:
        # Explicitly stop the automation on early exit, including timeout and cancellation.
        # This only stops the browser cycle; it does not terminate external child programs.
        try:_post('/api/automation_stop',{},url=url)
        except LegacyError:pass
