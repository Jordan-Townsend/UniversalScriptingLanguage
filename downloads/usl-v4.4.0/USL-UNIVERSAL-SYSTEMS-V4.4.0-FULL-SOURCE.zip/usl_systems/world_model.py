"""Grounded object-state tracking with a bounded constant-velocity prediction.

This is a small spatial model, not general causal understanding. Positions must
come from a calibrated external detector or a explicitly labelled test source.
"""
import math, re

class WorldModel:
    def __init__(self, memory): self.memory=memory

    def update(self, observation):
        if not isinstance(observation,dict) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',observation.get('object_id','')):
            raise ValueError('bounded object identity required')
        position=observation.get('position');timestamp=observation.get('timestamp')
        if not isinstance(position,list) or len(position)!=3 or any(type(x) not in (int,float) or not math.isfinite(x) or abs(x)>1e6 for x in position):
            raise ValueError('finite 3D position in metres required')
        if type(timestamp) not in (int,float) or not math.isfinite(timestamp) or timestamp<0 or observation.get('unit')!='metre':
            raise ValueError('timestamp and metre coordinate contract required')
        if not isinstance(observation.get('frame'),str) or not isinstance(observation.get('evidence'),dict) or not observation['evidence'].get('source'):
            raise ValueError('coordinate frame and observation provenance required')
        key='entity.world.'+observation['object_id']
        previous=self.memory.store.recall(key)
        velocity=None;prediction_error=None
        if previous:
            if previous['frame']!=observation['frame'] or timestamp<=previous['timestamp']:
                raise ValueError('same coordinate frame and increasing timestamps required')
            dt=timestamp-previous['timestamp']
            velocity=[(b-a)/dt for a,b in zip(previous['position'],position)]
            if previous['velocity'] is not None:
                predicted=[p+v*dt for p,v in zip(previous['position'],previous['velocity'])]
                prediction_error=math.sqrt(sum((a-b)**2 for a,b in zip(predicted,position)))
        state={**observation,'velocity':velocity,'prediction_error_metres':prediction_error,
            'model':'constant_velocity_from_observations','general_causal_model':False}
        self.memory.store.remember(key,state)
        return state

    def predict(self, object_id, seconds):
        if not isinstance(object_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',object_id) or type(seconds) not in (int,float) or not math.isfinite(seconds) or not 0<=seconds<=10:
            raise ValueError('bounded identity and 0..10 second horizon required')
        state=self.memory.store.recall('entity.world.'+object_id)
        if not state or state['velocity'] is None: raise ValueError('two grounded observations required before prediction')
        return {'object_id':object_id,'position':[p+v*seconds for p,v in zip(state['position'],state['velocity'])],
            'unit':'metre','frame':state['frame'],'timestamp':state['timestamp']+seconds,
            'hypothesis':True,'model':state['model'],'evidence':state['evidence']}
