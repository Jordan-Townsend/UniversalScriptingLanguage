"""Evidence-preserving 606 expansion planning and executable typed-artifact matrix.

No untested language is labeled executable. Predictive family routing is work
scheduling only, not an assertion of source translation or semantic coverage.
"""
import concurrent.futures,hashlib,json
from pathlib import Path
from .catalog import load_catalog
from .expanded_domains import SPEC, SOURCES, digest, discover
from .domain_execution import discovered as old_discovered

ROOT=Path(__file__).resolve().parents[1]
SCHEMA='usl.extrapolation.v4.1'

def _family(id_):
    if '+' in id_:
        parts=id_.split('+')
        return ('composite_template_or_preprocessor',{'host':parts[0], 'embedded':'+'.join(parts[1:])},
                'Implement exact template renderer then validate generated source with the real host-language engine')
    if id_ in ('capnp','thrift','asn1','protobuf','smithy','cddl','rng-compact','webidl','jsonld','json','json5','toml','yaml','xml'):
        return ('structured_schema',{},'Discover authoritative parser/schema implementation and qualify binary/text mapping')
    if id_ in ('sparql','cypher','sql','gsql','graphql','googlesql','mysql','postgresql','sqlite3','tsql','xquery','xpath','jmespath','rego','promql'):
        return ('query_language',{},'Discover actual query engine and qualify correct dialect semantics')
    if id_ in ('llvm','llvm-mir','llvm-mir-body','glsl','wgsl','hlsl','cuda','amdgpu','spirv','ptx','gas','nasm','zig','cython','cpp','c','rust'):
        return ('native_compilation',{},'Discover actual compatible compiler version, parse and lower supported source')
    if id_ in ('nginx','apacheconf','lighttpd','squidconf','systemd','docker','nginx','terraform','nixos','pkgconfig','gitconfig'):
        return ('configuration_or_build',{},'Discover true interpreter/validator with isolated side-effect checks')
    if id_ in ('tex','bibtex','asymptote','graphviz','postscript','markdown','restructuredtext','groff','pov','typst','lilypond'):
        return ('document_artifact',{},'Discover native document/graphics engine, independent output oracle')
    return ('unclassified_specification',{},'Inventory authoritative grammar, version, runtime and legal toolchain availability')

def plan(domain_report,*,prior=None):
    if prior is None:prior=json.loads((ROOT/'test_results/v4.0.0_language_606_qualification.json').read_text('utf8'))
    if len(prior['entries'])!=606:raise ValueError('Invalid v4.0 qualification baseline')
    earlier={row['catalog_id'] for row in prior['entries'] if row['qualification']!='unverified_execution'}
    new={x['language'] for x in domain_report['cases'] if x.get('verified') and x.get('variant')=='valid'}
    negatives={x['language'] for x in domain_report['cases'] if x.get('verified') and x.get('variant')=='invalid'}
    if not domain_report['all_passed'] or new!=negatives or new!=set(SPEC) or earlier&new:
        raise ValueError('New adapter positive/negative source proof missing or duplicates prior')
    catalog=load_catalog()
    groups={};rows=[]
    for item in catalog:
        id_=item['id'];family,components,need=_family(id_)
        if id_ in new:
            level='verified_new_executable_subset'
            evidence=next(x for x in domain_report['cases'] if x['language']==id_ and x['variant']=='valid')
            source_hash=evidence['source_sha256'];family=SPEC[id_][0]
            need='Map formal specification chapters; strengthen behavioral/property/concurrency tests and general source import'
        elif id_ in earlier:
            level='previously_verified_executable_subset';source_hash=None
            need='Expand beyond prior reviewed fixture, qualify complete versioned grammar/stdlib'
        else:
            level='unverified_execution';source_hash=None;groups.setdefault(family,[]).append(id_)
        rows.append({'catalog_id':id_,'qualification':level,'family':family,
            'components':components,'source_sha256':source_hash,
            'whole_specification_complete':False,'next_implementation_step':need})
    if len(rows)!=606 or len({x['catalog_id'] for x in rows})!=606:raise ValueError('606 inventory invalid')
    total=len(earlier|new)
    return {'schema':SCHEMA,'catalog_total':606,'historical_qualifications':len(earlier),
        'newly_executed_catalog_entries':len(new),'total_executable_subsets':total,
        'unqualified_entries':606-total,'fully_semantically_complete':0,
        'catalog_ids_new':sorted(new),'pending_reusable_families':{k:{'count':len(v),'ids':v} for k,v in sorted(groups.items())},
        'entries':rows,
        'strategy':'Reuse approved adapter family, then run parser/runtime/negative/specification qualifications per individual catalog entry. Never infer execution from syntax recognition.'}

def _probe_pair(host,guest,data):
    # A *typed artifact transport* after both engines have independently run.
    # It is not evidence of native host->guest code invocation.
    envelope={'schema':'usl.typed.artifact.handoff.v1','host':host,'guest':guest,'payload':data[host]}
    raw=json.dumps(envelope,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf8')
    restored=json.loads(raw)
    if restored['host']!=host or restored['guest']!=guest or restored['payload']!=data[host]:raise ValueError('Corrupt transfer')
    return {'host':host,'guest':guest,'qualification':'verified_typed_json_artifact_handoff_only',
            'payload_sha256':digest(raw),'verified':True}

def matrix(artifacts,qualified_report,*,workers=8):
    if type(workers) is not int or not 1<=workers<=8:raise ValueError('bounded 1..8 workers')
    if not qualified_report.get('all_passed'):raise ValueError('Qualification has not passed')
    expected=set(SPEC)
    data={x:json.loads((Path(artifacts)/(x.replace('+','_')+'.json')).read_text('utf8')) for x in expected}
    if set(qualified_report['tested_catalog_entries'])!=expected:raise ValueError('Subset catalog mismatch')
    cases={x['language']:x for x in qualified_report['cases'] if x.get('variant')=='valid'}
    for lang in expected:
        evidence=cases.get(lang)
        if not evidence or not evidence.get('verified') or evidence['source_sha256']!=digest(SOURCES[lang][0]):
            raise ValueError('Unverified/stale language source evidence: '+lang)
        if data[lang]!=evidence.get('observed') or digest(json.dumps(data[lang],sort_keys=True))!=evidence['semantic_result_sha256']:
            raise ValueError('Tampered executed artifact: '+lang)
    # 606 x 606 cells are addressable from default + overrides. Evidence below
    # is only for proven JSON artifact transport, never invented native FFI.
    cells=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(_probe_pair,h,g,data) for h in sorted(expected) for g in sorted(expected)]
        for future in concurrent.futures.as_completed(futures):cells.append(future.result())
    cells.sort(key=lambda c:(c['host'],c['guest']))
    if len(cells)!=17*17 or any(not x['verified'] for x in cells):raise ValueError('Incomplete typed transport test')
    return {'schema':'usl.expansion.typed.matrix.v4.1','catalog_ids':606,'ordered_cells':606*606,
      'implicit_cell_default':'unverified_no_native_code_route','tested_typed_handoff_cells':len(cells),
      'previous_native_routing_evidence':'v3.8 401 restricted historical eligible pair probes; retained separately, not freshly executed here',
      'qualification_scope':'17 actual guest engines; serialized typed JSON artifact transfer, not native source-code interoperability',
      'cells':cells}
