"""Separate device capture process so missing/busy devices have a deadline."""
import json, sys, wave

if __name__ == '__main__':
    try:
        request=json.loads(sys.stdin.buffer.read(4097))
        if request['kind']=='camera':
            import cv2
            camera=cv2.VideoCapture(request['index'])
            try:
                if not camera.isOpened(): raise ValueError('camera did not open')
                success,image=camera.read()
                if not success or image is None: raise ValueError('no actual camera frame')
                if image.size>12_000_000 or not cv2.imwrite(request['path'],image): raise ValueError('camera image output failed')
            finally: camera.release()
        elif request['kind']=='microphone':
            import sounddevice as sd
            rate=16000
            audio=sd.rec(int(request['seconds']*rate),samplerate=rate,channels=1,dtype='int16',device=request['index'])
            sd.wait()
            with wave.open(request['path'],'wb') as wav:
                wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(rate);wav.writeframes(audio.tobytes())
        else: raise ValueError('unknown capture device')
        print(json.dumps({'actual_capture':True}))
    except Exception as exc:
        sys.stderr.write(type(exc).__name__+': '+str(exc));sys.exit(1)
