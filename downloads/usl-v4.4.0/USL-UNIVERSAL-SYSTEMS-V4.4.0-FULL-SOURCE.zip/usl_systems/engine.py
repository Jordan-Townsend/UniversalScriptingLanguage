"""Asynchronous job manager with durable audit records and bounded concurrency."""
from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4
from .language import Interpreter,USLError
from .compiler import transpile
from .native import verify
from .agent import build
from .anylang import ai_transpile
from .fabric import Fabric
from .swarm import build_swarm

class Engine:
    def __init__(self,store):
        self.store=store
        self.pool=ThreadPoolExecutor(max_workers=3,thread_name_prefix='usl-worker')
        # Tasks present at shutdown are marked interrupted, never falsely completed.
        with store.lock,store._db() as c:
            c.execute("UPDATE jobs SET status='interrupted' WHERE status IN ('running','queued')")

    def submit(self,kind,request):
        if kind not in ('run','compile','verify','build','ai-transpile','flow','swarm'):raise USLError('Unsupported job type: '+kind)
        task_id=uuid4().hex[:18];self.store.create(task_id,kind,request)
        self.pool.submit(self._process,task_id,kind,request)
        return {'task_id':task_id,'status':'queued'}

    def _process(self,task_id,kind,request):
        self.store.update(task_id,'running')
        try:
            source=request.get('source','')
            if not isinstance(source,str) or len(source)>50000:raise USLError('Source must be a string <= 50,000 characters')
            if kind=='run':
                r=Interpreter(max_ops=100000,timeout=4).run(source)
                result={'output':r.output,'variables':r.variables,'operations':r.operations,'elapsed_ms':r.elapsed_ms}
            elif kind=='compile':
                g=transpile(source,request.get('target','python'))
                result={'target':g.target,'filename':g.filename,'code':g.code,'tier':g.tier,'note':g.note}
            elif kind=='verify':result=verify(source,request.get('target','python'))
            elif kind=='ai-transpile':
                result=ai_transpile(source,request.get('target','python'),request.get('model'))
                project=request.get('project','demo')
                path='generated/from_ai'+result['extension']
                self.store.save(project,path,result['code'])
                result['saved_project_path']=project+'/'+path
            elif kind=='swarm':
                result=build_swarm(request,self.store,task_id)
            elif kind=='flow':
                path=self.store.safe_project_path(request.get('project','demo'),request.get('path','integrated.uslflow.json'))
                result=Fabric(self.store,workers=request.get('workers',4)).execute(path,allow_native=False)
            else:result=build(request,self.store,task_id)
            self.store.update(task_id,'completed',result)
        except Exception as e:
            self.store.event('error',f'{type(e).__name__}: {e}',task_id)
            self.store.update(task_id,'failed',{'error':f'{type(e).__name__}: {e}'})
