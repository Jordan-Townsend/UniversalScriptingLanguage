"""Read-only discovery of independently-installed historical USL/Shadow products.

This adapter does NOT pretend to import unpublished Windows sources or attach
arbitrarily to programs. It records evidence and exposes an explicit contract
for later migrations performed on the Windows host with owner permission.
"""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

FAMILIES={
    'usl_v031': {'markers': ('INSTALL-USL-WINDOWS.cmd','WINDOWS-USL.ps1','usl_native.c','USL*.usl'), 'keywords':('USL-V031','USL-V0.31')},
    'chrome_bridge': {'markers': ('bridge.py','manifest.json','dashboard.html'), 'keywords':('CHROME-BRIDGE','Chrome_Bridge')},
    'shadow_runtime': {'markers': ('shadow.py','SHADOW*.py','ollama*.py'), 'keywords':('SHADOW','HOLOOS')},
    'emovision': {'markers': ('app/build.gradle','app/build.gradle.kts','build.gradle','MainActivity.kt'), 'keywords':('EMOVISION','EMOVISION-SHADOW')},
}


def _default_roots():
    roots=[]
    env=os.environ.get('USL_LEGACY_ROOTS','')
    roots.extend(Path(p.strip('" ')) for p in env.split(os.pathsep) if p.strip())
    if os.name=='nt':
        for drive in ('C:/','D:/','E:/','F:/'):
            try:
                base=Path(drive)
                if not base.is_dir():continue
                for pattern in ('USL*','SHADOW*','EmoVision','EMOVISION*'):
                    roots.extend(p for p in base.glob(pattern) if p.is_dir())
            except (OSError,PermissionError):continue
    return roots


def _bounded_files(root,depth=3,limit=1200):
    stack=[(root,0)];seen=0
    while stack and seen<limit:
        directory,n=stack.pop()
        try:children=sorted(directory.iterdir(),key=lambda p:p.name.lower())
        except (OSError,PermissionError):continue
        for p in children:
            try:
                if p.is_symlink():continue
                if p.is_file():
                    seen+=1
                    yield p.relative_to(root).as_posix()
                    if seen>=limit:break
                elif p.is_dir() and n<depth and p.name.lower() not in ('node_modules','.git','venv','.venv','build','.gradle','__pycache__'):
                    stack.append((p,n+1))
            except (OSError,PermissionError):continue


def scan(roots=None,limit_roots=60):
    paths=list(_default_roots() if roots is None else roots)
    seen=set();records=[]
    for item in paths[:limit_roots]:
        root=Path(item).expanduser().resolve()
        if str(root).lower() in seen or not root.is_dir():continue
        seen.add(str(root).lower())
        files=list(_bounded_files(root))
        names={x.casefold() for x in files}
        bybase={Path(f).name.casefold() for f in files}
        matches=[]; evidence={}
        for family,rule in FAMILIES.items():
            hits=[x for x in rule['markers'] if ('*' not in x and (x.casefold() in names or x.casefold() in bybase)) or ('*' in x and any(Path(p).match(x) for p in files))]
            label=any(k.lower() in root.name.lower() for k in rule['keywords'])
            if label or len(hits)>=2:
                matches.append(family);evidence[family]={'markers':hits,'name_match':label}
        records.append({'root':str(root),'families':matches,'evidence':evidence,'enumerated_files':len(files),
                        'file_listing_capped':len(files)>=1200,'connection':'discovered_only',
                        'executed':False,'imported':False})
    return {'roots_scanned':len(records),'detected':[r for r in records if r['families']],
            'warning':'Read-only discovery; installed systems were NOT merged, started, updated, or verified.'}


def legacy_bridge_probe(timeout=0.8):
    """Strictly bounded HTTP GET on known loopback port; no tokens or actions."""
    url='http://127.0.0.1:8766/'
    try:
        with urlopen(Request(url,headers={'User-Agent':'USL-Compatibility-Probe/0.3'}),timeout=min(3,max(.1,timeout))) as r:
            content_type=r.headers.get('Content-Type','')
            r.read(512)
            return {'endpoint':url,'responding':True,'http_status':r.status,'content_type':content_type,
                    'connected':False,'note':'HTTP presence is not authenticated bridge interoperability.'}
    except HTTPError as e:
        return {'endpoint':url,'responding':True,'http_status':e.code,'connected':False,'note':'Server exists; no handshake was performed.'}
    except (URLError,OSError,TimeoutError,ValueError) as e:
        return {'endpoint':url,'responding':False,'connected':False,'reason':type(e).__name__}


def integration_status(roots=None,network_probe=False):
    records=scan(roots)
    if network_probe:records['chrome_bridge_http_probe']=legacy_bridge_probe()
    records['required_contracts']={
      'usl_v031':'Provide original native dispatcher source, build commands, ABI version, and validated conformance suite.',
      'chrome_bridge':'Provide extension/service source and authenticated action schema; require explicit pairing and authorized scope.',
      'shadow_runtime':'Provide service source/model adapters, state schema, persistent storage mapping, and capability registry.',
      'emovision':'Provide Android/ONNX source, manifests, model licenses, device permissions, and validated input/output interface.'}
    return records
