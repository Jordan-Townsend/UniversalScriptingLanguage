"""Actual toolchain syntax-check adapters for trusted source, not 606 semantic compilers.
No shell, bounded input and timeout, no claimed equivalence. Toolchains are not
safe sandboxes and must only be invoked with explicit user authorization.
"""
from __future__ import annotations
import hashlib
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile

CAPABILITIES={
 'javascript':{'binary':'node','suffix':'.js','args':['--check'],'claim':'Node.js JavaScript syntax check, not runtime semantics'},
 'ruby':{'binary':'ruby','suffix':'.rb','args':['-c'],'claim':'Ruby parser/syntax check, not runtime semantics'},
 'php':{'binary':'php','suffix':'.php','args':['-l'],'claim':'PHP lint syntax, not runtime semantics'},
 'go':{'binary':'gofmt','suffix':'.go','args':['-e'],'claim':'gofmt Go parser, not go build/typecheck'},
 'c':{'binary':'clang','suffix':'.c','args':['-std=c11','-fsyntax-only'],'claim':'Clang C11 front-end syntax/type check'},
 'cpp':{'binary':'clang++','suffix':'.cpp','args':['-std=c++17','-fsyntax-only'],'claim':'Clang C++17 front-end syntax/type check'},
 'java':{'binary':'javac','suffix':'.java','args':['-proc:none'],'claim':'javac compilation diagnostics; annotation processors disabled'},
 'typescript':{'binary':'tsc','suffix':'.ts','args':['--noEmit','--strict','--skipLibCheck','--target','ES2020'],'claim':'TypeScript strict parser and static type diagnostics; no emitted runtime artifact'},
 'swift':{'binary':'swiftc','suffix':'.swift','args':['-typecheck'],'claim':'Swift parser and typechecker diagnostics; no program execution'},
 'fortran':{'binary':'gfortran','suffix':'.f90','args':['-std=f2018','-fsyntax-only'],'claim':'GNU Fortran 2018 parser and semantic front end; no executable output'},
 'perl':{'binary':'perl','suffix':'.pl','args':['-c'],'claim':'Perl compile-only diagnostics; BEGIN blocks and compile-time code MAY execute; trusted source only'},
 'bash':{'binary':'bash','suffix':'.sh','args':['-n'],'claim':'Bash parser -n; syntax completeness only; no shell script execution'},
 'kotlin':{'binary':'kotlinc','suffix':'.kt','args':['-nowarn'],'claim':'Kotlin compiler diagnostics; compilation may invoke plugins and is not a sandbox'},
}
ALIASES={'js':'javascript','c++':'cpp','rb':'ruby','golang':'go','ts':'typescript','f90':'fortran','kt':'kotlin','sh':'bash','swift5':'swift'}
class NativeSyntaxError(ValueError):pass

def available():
 return {k:{'installed':bool(shutil.which(v['binary'])),'tool':v['binary'],
             'claim':v['claim']} for k,v in CAPABILITIES.items()}

def _terminate(proc):
 if proc.poll() is not None:return
 if os.name=='nt':
  try:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=4)
  except (OSError,subprocess.TimeoutExpired):proc.kill()
 else:
  try:os.killpg(proc.pid,signal.SIGKILL)
  except ProcessLookupError:pass
 try:proc.wait(timeout=3)
 except subprocess.TimeoutExpired:proc.kill()

def check_source(language,source,*,authorized=False,timeout=8):
 if authorized is not True:raise NativeSyntaxError('Explicit toolchain invocation approval required')
 if not isinstance(language,str):raise NativeSyntaxError('Invalid language')
 key=ALIASES.get(language.lower(),language.lower())
 if key not in CAPABILITIES:raise NativeSyntaxError('No qualified native validator for '+key)
 if not isinstance(source,str):raise NativeSyntaxError('Source must be text')
 raw=source.encode('utf8')
 if len(raw)>262144:raise NativeSyntaxError('Maximum input size 256 KiB')
 if not isinstance(timeout,int) or not 1<=timeout<=30:raise NativeSyntaxError('Timeout must be 1..30 seconds')
 cfg=CAPABILITIES[key];tool=shutil.which(cfg['binary'])
 if not tool:raise NativeSyntaxError('Required installed toolchain not found: '+cfg['binary'])
 with tempfile.TemporaryDirectory(prefix='usl-native-validate-') as tmp:
  work=Path(tmp)
  file=work/('USLCheck'+cfg['suffix'] if key=='java' else 'input'+cfg['suffix'])
  file.write_bytes(raw)
  if key=='java':args=[tool,*cfg['args'],'-d',str(work),str(file)]
  elif key=='kotlin':
   (work/'classes').mkdir()
   args=[tool,*cfg['args'],str(file),'-d',str(work/'classes')]
  elif key in ('javascript','ruby','php'):args=[tool,*cfg['args'],str(file)]
  else:args=[tool,*cfg['args'],str(file)]
  opts={'cwd':work,'stdin':subprocess.DEVNULL,'stdout':subprocess.PIPE,'stderr':subprocess.STDOUT}
  if os.name=='nt':opts['creationflags']=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
  else:opts['start_new_session']=True
  proc=subprocess.Popen(args,**opts)
  expired=False
  try:output,_=proc.communicate(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;_terminate(proc)
   try:output,_=proc.communicate(timeout=3)
   except subprocess.TimeoutExpired:output=b''
  return {'language':key,'installed_toolchain':cfg['binary'],'toolchain_path':tool,
          'claim':cfg['claim'],'source_sha256':hashlib.sha256(raw).hexdigest(),
          'source_bytes':len(raw),'syntax_valid':proc.returncode==0 and not expired,
          'exit_code':proc.returncode,'timed_out':expired,
          'console_tail':output.decode('utf8','replace')[-8192:],
          'semantic_equivalence_proven':False,'source_executed':False,
          'compile_time_code_may_execute':key in ('perl','kotlin','swift','java','typescript'),
          'verification_kind':'static_type_and_syntax' if key in ('typescript','swift','fortran','kotlin','java','c','cpp') else 'syntax_or_compile_check'}
