"""Exact, evidence-gated content reuse and compression (not an entropy-law bypass).

Design: duplicate CAS-> zlib -> optional reversible XOR/delta-> verified commit.
For every candidate, reconstruct bytes and check SHA-256 before selecting. Supports
partial segment reuse and a best-of-all mode, with honest wire/container overhead.
"""
from __future__ import annotations
import base64, hashlib, json, os, threading, zlib
from pathlib import Path

class CollapseError(ValueError):pass

def digest(data):return hashlib.sha256(data).hexdigest()

def xor_bytes(a,b):return bytes(x^y for x,y in zip(a,b))

def collapse_bytes(data:bytes,reference:bytes|None=None,mode:str='all'):
    if not isinstance(data,bytes) or (reference is not None and not isinstance(reference,bytes)):
        raise CollapseError('Input and reference must be bytes')
    if len(data)>16_000_000:raise CollapseError('Input exceeds 16 MB bounded operation')
    if mode not in ('all','raw','zlib','delta','duplicate','partial'):raise CollapseError('Unknown mode')
    candidates=[]
    def add(name,body,**opts):
        record={'codec':name,'payload':base64.b64encode(body).decode('ascii'),**opts}
        try:
            if restore_bytes(record,reference,verify_digest=False)!=data:return
        except CollapseError:return
        record['sha256']=digest(data);record['original_size']=len(data)
        candidates.append(record)
    add('raw',data)
    if mode in ('all','zlib','partial'):
        for level in (1,6,9):add('zlib',zlib.compress(data,level),level=level)
    if reference is not None and len(data)==len(reference):
        refhash=digest(reference)
        if mode in ('all','duplicate') and data==reference:add('duplicate',b'',reference_sha256=refhash)
        if mode in ('all','delta'):add('xor_zlib',zlib.compress(xor_bytes(data,reference),1),reference_sha256=refhash)
    if mode in ('all','partial') and len(data)>=128:
        # Every segment is independently verifiable. Repeated segments may
        # reuse a SAME-POSITION reference segment without hidden state.
        segments=[];size=4096
        for offset in range(0,len(data),size):
            chunk=data[offset:offset+size];refchunk=None
            if reference is not None and offset+len(chunk)<=len(reference):refchunk=reference[offset:offset+len(chunk)]
            sub=collapse_bytes(chunk,refchunk,'all' if len(chunk)<128 else 'zlib')
            if refchunk is not None and chunk==refchunk:
                sub={'codec':'duplicate','payload':'','reference_sha256':digest(refchunk),'sha256':digest(chunk),'original_size':len(chunk)}
            segments.append(sub)
        record={'codec':'partial','payload':'','segments':segments,'sha256':digest(data),'original_size':len(data)}
        try:
            if restore_bytes(record,reference)==data:candidates.append(record)
        except CollapseError:pass
    if mode in ('raw','zlib','delta','duplicate','partial'):
        choices=[r for r in candidates if r['codec']==mode or (mode=='delta' and r['codec']=='xor_zlib') or (mode=='zlib' and r['codec']=='raw') or (mode=='partial' and r['codec']=='raw')]
        if not choices:raise CollapseError('Requested transform cannot be applied exactly')
    else:choices=candidates
    # Cost is serialized wire bytes (includes verification metadata):
    best=min(choices,key=lambda r:(len(json.dumps(r,separators=(',',':'))),r['codec']))
    best=dict(best)
    # Byte cost of the persistent codec record (includes codec and SHA proof
    # metadata), BEFORE adding caller-only diagnostic fields. Including a field
    # that reports its own length is not always mathematically self-consistent.
    encoded=len(json.dumps(best,separators=(',',':')).encode('utf8'))
    best['encoded_bytes']=encoded
    best['raw_bytes']=len(data)
    best['saved_bytes']=len(data)-encoded
    best['exact_verified']=restore_bytes(best,reference)==data
    best['cost_scope']='serialized_codec_record_excluding_diagnostics'
    return best

def restore_bytes(record:dict,reference:bytes|None=None,verify_digest=True):
    if not isinstance(record,dict):raise CollapseError('Invalid record')
    codec=record.get('codec');payload=record.get('payload','')
    if not isinstance(payload,str):raise CollapseError('Invalid payload')
    try:encoded=base64.b64decode(payload.encode('ascii'),validate=True)
    except Exception as e:raise CollapseError('Invalid base64 payload') from e
    if codec=='raw':result=encoded
    elif codec=='zlib':
        try:
            out=zlib.decompressobj()
            limit=int(record.get('original_size',16_000_000))
            if limit<0 or limit>16_000_000:raise CollapseError('Decompression exceeds limit')
            result=out.decompress(encoded,limit+1)
            if out.unconsumed_tail or len(result)>limit or not out.eof or out.unused_data:raise CollapseError('Invalid compressed frame')
            result+=out.flush()
        except zlib.error as e:raise CollapseError('Invalid zlib payload') from e
    elif codec in ('duplicate','xor_zlib'):
        if reference is None or digest(reference)!=record.get('reference_sha256'):
            raise CollapseError('Missing or mismatched reference content')
        if codec=='duplicate':result=reference
        else:
            try:
                ob=zlib.decompressobj();delta=ob.decompress(encoded,len(reference)+1)
                if not ob.eof or ob.unconsumed_tail or ob.unused_data or len(delta)!=len(reference):raise CollapseError('Invalid delta frame')
            except zlib.error as e:raise CollapseError('Corrupted delta') from e
            result=xor_bytes(delta,reference)
    elif codec=='partial':
        segments=record.get('segments',[])
        if not isinstance(segments,list) or len(segments)>4096:raise CollapseError('Too many partial segments')
        out=[];offset=0
        for segment in segments:
            size=segment.get('original_size',0)
            if not isinstance(size,int) or size<0 or size>4096:raise CollapseError('Bad segment length')
            ref=reference[offset:offset+size] if reference is not None and offset+size<=len(reference) else None
            resultsegment=restore_bytes(segment,ref)
            if len(resultsegment)!=size:raise CollapseError('Segment size mismatch')
            out.append(resultsegment);offset+=size
        result=b''.join(out)
    else:raise CollapseError('Unknown codec')
    if verify_digest:
        if len(result)!=record.get('original_size'):raise CollapseError('Length proof failed')
        if digest(result)!=record.get('sha256'):raise CollapseError('SHA-256 proof failed')
    return result

class ContentStore:
    """Immutable CAS with atomic writes and repeatable integrity checks."""
    def __init__(self,root):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock()
    def _path(self,sha):
        if len(sha)!=64 or any(x not in '0123456789abcdef' for x in sha):raise CollapseError('Invalid digest')
        return self.root/sha[:2]/sha[2:]
    def put(self,data):
        sha=digest(data);p=self._path(sha)
        with self.lock:
            p.parent.mkdir(parents=True,exist_ok=True)
            if p.is_file():
                if digest(p.read_bytes())!=sha:raise CollapseError('Stored content corrupted')
                return {'sha256':sha,'reused':True,'bytes':len(data)}
            temp=p.with_name(p.name+f'.{os.getpid()}.{threading.get_ident()}.tmp')
            try:
                temp.write_bytes(data)
                if digest(temp.read_bytes())!=sha:raise CollapseError('Write verification failed')
                os.replace(temp,p)
            finally:temp.unlink(missing_ok=True)
        return {'sha256':sha,'reused':False,'bytes':len(data)}
    def get(self,sha):
        p=self._path(sha)
        if not p.is_file():raise CollapseError('CAS object not found')
        data=p.read_bytes()
        if digest(data)!=sha:raise CollapseError('CAS integrity mismatch')
        return data
