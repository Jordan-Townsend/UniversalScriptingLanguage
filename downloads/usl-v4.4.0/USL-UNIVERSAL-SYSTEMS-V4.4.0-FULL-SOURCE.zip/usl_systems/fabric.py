"""Validated DAG orchestration across USL, generated targets and native sources.

No arbitrary eval. Native source tasks require explicit launch consent. Jobs are
persistent in SQLite, optional safe compile/run caching, bounded concurrency.
"""
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
import hashlib,json,re,threading,time
from pathlib import Path
from .language import Interpreter,USLError
from .compiler import transpile
from .native import verify
from .adapters import AdapterRegistry
from .store import Store
from .equations import evaluate
from .equation_import import EquationWorkspace
from .collapse import collapse_bytes,restore_bytes
from .fractal import FactoredFractal
from .incremental import CollapseCompute

class FabricError(USLError):pass


def validate_flow(plan):
    if plan.get('format')!='uslflow-1':raise FabricError('Expected format uslflow-1')
    nodes=plan.get('tasks')
    if not isinstance(nodes,list) or not nodes or len(nodes)>512:raise FabricError('Flow requires 1..512 tasks')
    if any(not isinstance(x,dict) or not re.fullmatch(r'[a-zA-Z0-9_\-]{1,64}',str(x.get('id',''))) for x in nodes):raise FabricError('Invalid task ID')
    ids=[x['id'] for x in nodes]
    if len(set(ids))!=len(ids):raise FabricError('Duplicate task IDs')
    graph={x['id']:x.get('depends',[]) for x in nodes}
    if any(not isinstance(ds,list) or any(not isinstance(k,str) or k not in ids for k in ds) for ds in graph.values()):
        raise FabricError('Invalid dependency')
    order=[];temporary=set();permanent=set()
    def visit(n):
        if n in permanent:return
        if n in temporary:raise FabricError('Cycle detected involving '+n)
        temporary.add(n)
        for dep in graph[n]:visit(dep)
        temporary.remove(n);permanent.add(n);order.append(n)
    for i in ids:visit(i)
    if any(x.get('kind') not in ('run','compile','verify','native','equation','collapse','fractal','incremental') for x in nodes):raise FabricError('Invalid task kind')
    if any(not isinstance(x.get('source'),str) for x in nodes):raise FabricError('All tasks require a source path')
    return order

class Fabric:
    def __init__(self,store=None,workers=4):
        self.store=store or Store();self.workers=max(1,min(16,int(workers)))
        self.cache_lock=threading.Lock()

    def execute(self,flow_path,allow_native=False,use_cache=True):
        planfile=Path(flow_path).resolve()
        plan=json.loads(planfile.read_text(encoding='utf8'))
        order=validate_flow(plan)
        base=planfile.parent
        byid={x['id']:x for x in plan['tasks']}
        status={};results={};futures={}
        start=time.monotonic()
        self.store.event('fabric','Starting '+str(plan.get('name','unnamed')))
        def task(node):
            path=(base/node['source']).resolve()
            if not path.is_relative_to(base):raise FabricError('Source escapes workflow directory: '+node['source'])
            if not path.is_file():raise FabricError('Missing source: '+node['source'])
            raw=path.read_text(encoding='utf8')
            kind=node['kind'];target=node.get('target','python')
            seed=json.dumps({'source':raw,'kind':kind,'target':target,'version':'0.5.0'},sort_keys=True)
            if kind=='equation':
                registry=EquationWorkspace(self.store.root).records()
                seed+='|eq.registry='+hashlib.sha256(json.dumps(registry,sort_keys=True).encode('utf8')).hexdigest()
            key='fabric.cache.'+hashlib.sha256(seed.encode('utf8')).hexdigest()
            if use_cache and kind in ('compile','run','equation','collapse','fractal','incremental'):
                with self.cache_lock:cached=self.store.recall(key)
                if cached is not None:return {'status':'cached','result':cached}
            if kind=='run':
                r=Interpreter().run(raw)
                output={'stdout':r.output,'operations':r.operations,'elapsed_ms':r.elapsed_ms}
            elif kind=='compile':
                g=transpile(raw,target)
                output={'language':g.target,'filename':g.filename,'code':g.code,'tier':g.tier}
            elif kind=='verify':output=verify(raw,target)
            elif kind=='equation':
                cfg=json.loads(raw)
                if not isinstance(cfg,dict):raise FabricError('Equation must be an object')
                output=evaluate(cfg.get('id'),cfg.get('params',{}),extra=EquationWorkspace(self.store.root).records())
            elif kind=='collapse':
                blob=raw.encode('utf8')
                reference=None
                if 'reference' in node:
                    rpath=(base/node['reference']).resolve()
                    if not rpath.is_relative_to(base) or not rpath.is_file():raise FabricError('Invalid reference path')
                    reference=rpath.read_bytes()
                record=collapse_bytes(blob,reference,node.get('mode','all'))
                output={'codec':record['codec'],'encoded_bytes':record['encoded_bytes'],
                     'raw_bytes':len(blob),'saved_bytes':record['saved_bytes'],
                     'verified':restore_bytes(record,reference)==blob,'sha256':record['sha256']}
            elif kind=='fractal':
                cfg=json.loads(raw)
                if not isinstance(cfg,dict):raise FabricError('Fractal plan must be an object')
                scheduler=FactoredFractal(workers=self.workers,max_depth=cfg.get('depth',4),leaf_size=cfg.get('leaf_size',512))
                output=scheduler.execute(cfg.get('values',[]),operator=cfg.get('operator','sum_squares'),
                  dimensions=cfg.get('dimensions',['execution','verification']),mode=cfg.get('mode','async'))
            elif kind=='incremental':
                cfg=json.loads(raw)
                if not isinstance(cfg,dict):raise FabricError('Incremental plan must be an object')
                engine=CollapseCompute(cfg.get('operator','sum_squares'))
                initial=engine.initialize(cfg.get('values',[]))
                change=cfg.get('changes',{})
                if not isinstance(change,dict):raise FabricError('Changes must be mapping')
                updated=engine.update({int(k):v for k,v in change.items()},audit=cfg.get('audit',True))
                output={'initial':initial,'updated':updated,'verified':updated['correct'], 'snapshot':engine.snapshot()}
            elif kind=='native':
                if not allow_native:raise FabricError('Native tasks are disabled by default; explicit opt-in required')
                output=AdapterRegistry(self.store).run(node.get('language',target),path,allow=True)
                if output['status']!='success':raise FabricError('Native step failed: '+output['status'])
            else:raise FabricError('Unrecognized task')
            if use_cache and kind in ('compile','run','equation','collapse','fractal','incremental'):
                with self.cache_lock:self.store.remember(key,output)
            return {'status':'completed','result':output}
        with ThreadPoolExecutor(max_workers=self.workers,thread_name_prefix='usl-fabric') as pool:
            while len(status)<len(order):
                progressed=False
                for nodeid in order:
                    if nodeid in status or nodeid in futures:continue
                    deps=byid[nodeid].get('depends',[])
                    if any(d not in status for d in deps):continue
                    if any(status[d] not in ('completed','cached') for d in deps):
                        status[nodeid]='blocked';results[nodeid]={'error':'One or more dependencies failed'};progressed=True
                        self.store.event('fabric','Blocked '+nodeid)
                    else:
                        futures[nodeid]=pool.submit(task,byid[nodeid]);progressed=True
                        self.store.event('fabric','Scheduled '+nodeid)
                if futures:
                    done,_=wait(futures.values(),return_when=FIRST_COMPLETED)
                    for fid,future in list(futures.items()):
                        if future not in done:continue
                        try:
                            res=future.result();status[fid]=res['status'];results[fid]=res['result']
                        except Exception as e:
                            status[fid]='failed';results[fid]={'error':f'{type(e).__name__}: {e}'}
                        self.store.event('fabric',f'{fid} -> {status[fid]}')
                        del futures[fid]
                        progressed=True
                if not progressed:raise FabricError('Scheduler deadlocked unexpectedly')
        elapsed=round((time.monotonic()-start)*1000,3)
        report={'flow':plan.get('name','unnamed'),'elapsed_ms':elapsed,'tasks':len(order),
                'status':status,'results':results,'success':all(v in ('completed','cached') for v in status.values()),
                'workers':self.workers}
        self.store.event('fabric','Flow complete: success='+str(report['success']))
        return report
