"""Deterministic compiler-diagnostic-driven *inert* repair suggestions.

Currently supports only a narrow family of actual Python SyntaxErrors.
No source edits, test execution, or automatic approval happen in this module.
The returned exact hash-pinned plan can be inspected, explicitly approved,
and executed by the staged RepairLoop elsewhere in the product.
"""
from __future__ import annotations
import hashlib
import re
from .repairloop import RepairError, _relpath

_HEADER=re.compile(r'^\s*(?:async\s+def|def|class|if|elif|else|for|async\s+for|while|try|except|finally|with|async\s+with)\b')


def propose_syntax_repair(store,project,path):
    if not isinstance(project,str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}",project):
        raise RepairError("Invalid project name")
    rel=_relpath(path)
    source=store.safe_project_path(project,rel.as_posix())
    if source.is_symlink() or not source.is_file():
        raise RepairError('Only existing regular Python source can be diagnosed')
    data=source.read_bytes()
    if len(data)>2_000_000:raise RepairError('Source exceeds 2MB proposal limit')
    try:content=data.decode('utf8')
    except UnicodeDecodeError as e:raise RepairError('Source must be UTF-8') from e
    error=None
    try:compile(content,str(rel),'exec')
    except SyntaxError as exc:error=exc
    else:raise RepairError('This file compiles; no supported syntax-repair proposal available')
    if error.lineno is None or error.msg not in ('expected \' :\'',"expected ':'",'invalid syntax'):
        raise RepairError('Unsupported Python syntax failure: '+error.msg)
    lines=content.splitlines(keepends=True)
    if not 0<error.lineno<=len(lines):raise RepairError('Compiler diagnostic has no usable source line')
    idx=error.lineno-1
    # 'expected : ' may be reported on the *following* line after the actual header.
    candidates=[idx,idx-1] if idx else [idx]
    for j in candidates:
        if j<0:continue
        line=lines[j]
        if not _HEADER.match(line):continue
        body=line.rstrip('\r\n')
        if '#' in body or body.rstrip().endswith(':') or not body.strip():continue
        if body.count('(')!=body.count(')'):continue
        # No multiline header, no comment editing or ambiguous bare lines.
        new=body.rstrip()+':'+line[len(body):]
        tentative=list(lines);tentative[j]=new
        text=''.join(tentative)
        try:compile(text,str(rel),'exec')
        except SyntaxError:continue
        if content.count(line)!=1:continue
        sha=hashlib.sha256(data).hexdigest()
        plan={'format':'uslauto-1','name':'Compiler-grounded Python syntax repair',
          'steps':[{'id':'fix_syntax','kind':'dev_repair','project':project,'path':str(rel),
                    'original_sha256':sha,'old':line,'new':new,'check':'unittest',
                    'timeout':20,'expected':{'status':'completed'}}]}
        return {'status':'proposal_only','diagnostic':{
           'exception':'SyntaxError','message':error.msg,'line':error.lineno,'offset':error.offset,
           'actual_source_line':error.text.strip() if error.text else '',
           'fixed_header_line':j+1},
           'source_sha256':sha,'requires_owner_approval':True,'process_execution_authorized':False,
           'source_modified':False,'plan':plan}
    raise RepairError('No bounded, compiler-verified single-line repair rule matched')
