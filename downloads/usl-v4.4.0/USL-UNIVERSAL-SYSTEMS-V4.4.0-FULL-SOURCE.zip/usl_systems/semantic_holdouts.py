"""Deterministic held-out USL subset behavioral equivalence checks.

These tests prove matching output for generated programs on installed target runtimes.
They do NOT prove target-language completeness or arbitrary program equivalence.
Source inputs are generated from a small audited template set; native executables are
not sandboxed and should never be used with untrusted arbitrary input.
"""
from __future__ import annotations
from pathlib import Path
from hashlib import sha256
import json,random,time
from .native import verify,tool_available

TARGETS=('python','javascript','ruby','php','go','java','cpp','c')

def cases(seed=20261012,count=4):
    if not isinstance(seed,int) or not isinstance(count,int) or not 1<=count<=24:
        raise ValueError('Use integer seed and 1..24 cases')
    rng=random.Random(seed)
    for i in range(count):
        a,b,c=[rng.randint(1,30) for _ in range(3)]
        variant=i%4
        if variant==0:
            expression='(a + b) * c'
            source=f'let a = {a}\nlet b = {b}\nlet c = {c}\nprint({expression})'
        elif variant==1:
            source=f'let a = {a}\nlet b = {b}\nlet c = {c}\nprint((a - b) * (c + 2))'
        elif variant==2:
            source=f'let a = {a}\nlet b = {b}\nlet c = {c}\nif a > b:\n    print(a * c + b)\nelse:\n    print(b * c + a)'
        else:
            source=f'function twice(x):\n    return x * 2\nlet a = {a}\nlet b = {b}\nprint(twice(a+b))'
        yield {'id':f'seed_{seed}_case_{i}','source':source,
               'source_sha256':sha256(source.encode()).hexdigest(),'variant':variant}

def qualification(seed=20261012,count=4,targets=None,timeout=12):
    selected=list(targets or TARGETS)
    if not selected or any(target not in TARGETS for target in selected):
        raise ValueError('Unsupported native conformance target requested')
    outcomes=[]
    for case in cases(seed,count):
        for target in selected:
            t0=time.monotonic()
            result=verify(case['source'],target,timeout=timeout)
            record={'case':case['id'],'variant':case['variant'],'source_sha256':case['source_sha256'],
                    'target':target,'status':result['status'],
                    'elapsed_ms':round((time.monotonic()-t0)*1000,2),
                    'expected_output':result.get('expected_output'),
                    'native_output':result.get('native',{}).get('stdout'),
                    'native_exit_code':result.get('native',{}).get('returncode'),
                    'compiler_diagnostic':str(result.get('error') or result.get('build',{}).get('stderr') or result.get('native',{}).get('stderr') or '')[-1600:]}
            outcomes.append(record)
    tested=[row for row in outcomes if row['status']!='toolchain_missing']
    return {'schema':'usl.semantic.holdouts.v1','seed':seed,'case_count':count,
            'target_count':len(selected),'actual_native_executions':len(tested),
            'passes':sum(row['status']=='passed' for row in tested),
            'skipped':len(outcomes)-len(tested),'all_tested_passed':bool(tested) and all(x['status']=='passed' for x in tested),
            'semantic_equivalence_proven_only_for_test_cases':True,
            'all_606_semantic_compilers_completed':False,'results':outcomes}
