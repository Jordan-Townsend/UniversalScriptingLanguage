"""Versioned native source imports, typed results and explicit USL host capabilities.

An installed full upstream parser is used, but qualification covers declared
features only. Child processes are bounded; they are not an OS security sandbox.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from hashlib import sha256
import importlib.metadata, importlib.util, json, os, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path

SCHEMA='usl.foreign.source.v1'
ROOT=Path(__file__).resolve().parents[1]
CONTRACTS={}
for engine,ids in {
    'django':('django','css+django','html+django','javascript+django','xml+django'),
    'cheetah':('cheetah','html+cheetah','javascript+cheetah','xml+cheetah'),
    'mako':('mako','javascript+mako'),
    'php':('css+php','html+php','javascript+php'),
    'ruby':('css+ruby','javascript+ruby'),
    'graphql':('graphql',),'dtd':('dtd',),
}.items():
    for catalog_id in ids:
        host=catalog_id.split('+',1)[0] if '+' in catalog_id else 'text'
        CONTRACTS[catalog_id]={'catalog_id':catalog_id,'engine':engine,'host':host,'contract_version':1,
            'full_spec_qualified':False,'source_import':'upstream_parser_plus_preserved_source',
            'typed_result':'finite_json_object','side_effects':'explicit execution permission; native hosts may execute code',
            'reference':{'django':'https://docs.djangoproject.com/en/stable/topics/templates/',
             'cheetah':'https://cheetahtemplate.org/users_guide/', 'mako':'https://docs.makotemplates.org/en/latest/syntax.html',
             'php':'https://www.php.net/manual/en/langref.php','ruby':'https://docs.ruby-lang.org/en/master/syntax_rdoc.html',
             'graphql':'https://spec.graphql.org/October2021/','dtd':'https://www.w3.org/TR/xml/'}[engine]}

class SourceError(ValueError):pass
@lru_cache(maxsize=64)
def _file_hash(path,size,mtime_ns):
    h=sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()

def runtime_file_hash(path):
    path=Path(path).resolve();stat=path.stat()
    return _file_hash(str(path),stat.st_size,stat.st_mtime_ns)
def digest(value):
    raw=value if isinstance(value,bytes) else value.encode() if isinstance(value,str) else json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()
    return sha256(raw).hexdigest()

def discover():
    """Inert metadata discovery: no importing or executing provider source."""
    result={}
    for id_,contract in CONTRACTS.items():
        engine=contract['engine']
        package={'django':'django','cheetah':'cheetah3','mako':'mako','graphql':'graphql-core','dtd':'lxml'}.get(engine)
        try:
            version=importlib.metadata.version(package) if package else None
            installed=bool(version) if package else bool(shutil.which(engine))
        except importlib.metadata.PackageNotFoundError:version=None;installed=False
        if contract['host']=='javascript':installed=installed and bool(shutil.which('node'))
        for dependency in ('lxml',) if contract['host'] in ('html','xml') else ('tinycss2',) if contract['host']=='css' else ():
            try:importlib.metadata.version(dependency)
            except importlib.metadata.PackageNotFoundError:installed=False
        result[id_]={**contract,'provider_available':installed,'provider_version':version,
            'execution_qualified':False,'discovery_is_execution_evidence':False}
    return result

def provenance(catalog_id):
    if not isinstance(catalog_id,str) or catalog_id not in CONTRACTS:raise SourceError('Unknown exact catalog ID')
    c=CONTRACTS[catalog_id];engine=c['engine']
    package={'django':'django','cheetah':'cheetah3','mako':'mako','graphql':'graphql-core','dtd':'lxml'}.get(engine)
    if package:
        dist=importlib.metadata.distribution(package)
        # Distribution RECORD is independently included in the actual runtime identity.
        record=dist.read_text('RECORD') or ''
        native={'provider':package,'version':dist.version,'distribution_record_sha256':digest(record)}
        prefixes={'django':'django/template/base.py','cheetah':'Cheetah/Template.py','mako':'mako/template.py',
            'graphql':'graphql/execution/execute.py','dtd':'lxml/etree.'}
        primary=[f for f in (dist.files or []) if str(f)==prefixes[engine] or (engine=='dtd' and str(f).startswith(prefixes[engine]) and str(f).endswith(('.so','.pyd')))]
        if not primary:raise SourceError('Actual parser runtime file is missing: '+package)
        native['parser_files_sha256']={str(f):runtime_file_hash(dist.locate_file(f)) for f in primary}
    else:
        binary=shutil.which(engine)
        if not binary:raise SourceError('Runtime unavailable: '+engine)
        result=subprocess.run([binary,'--version'],capture_output=True,text=True,timeout=5)
        if result.returncode:raise SourceError('Runtime version probe failed')
        executable=binary
        if engine=='php':executable=subprocess.check_output([binary,'-r','echo PHP_BINARY;'],text=True,timeout=5)
        native={'provider':engine,'version':result.stdout.splitlines()[0],
            'launcher_sha256':runtime_file_hash(binary),'executable_sha256':runtime_file_hash(executable)}
    host_dependencies={}
    for package in ('lxml','tinycss2') if c['host'] in ('html','xml','css') else ():
        host_dependencies[package]=importlib.metadata.version(package)
    if c['host']=='javascript':
        binary=shutil.which('node')
        if not binary:raise SourceError('JavaScript host unavailable')
        host_dependencies['node']=subprocess.check_output([binary,'--version'],text=True,timeout=5).strip()
        host_dependencies['node_executable_sha256']=runtime_file_hash(binary)
    return {**c,'runtime':native,'host_dependencies':host_dependencies,
        'worker_sha256':digest((ROOT/'usl_systems/source_worker.py').read_bytes())}

def execute(catalog_id,source,context=None,*,approved=False,timeout=12):
    if not approved:raise SourceError('Explicit source execution permission required')
    if not isinstance(source,str) or not 0<len(source.encode())<=32768:raise SourceError('Source size 1..32768 UTF-8 bytes required')
    if type(timeout) not in (int,float) or not 0<timeout<=15:raise SourceError('Timeout must be 0..15 seconds')
    if context is None:context={}
    if not isinstance(context,dict):raise SourceError('Context must be a finite JSON object')
    try:context_raw=json.dumps(context,ensure_ascii=False,allow_nan=False)
    except (ValueError,TypeError,RecursionError) as e:raise SourceError('Invalid context') from e
    if len(context_raw.encode())>16384:raise SourceError('Context size exceeded')
    meta=provenance(catalog_id)
    request={'source':source,'context':context,'engine':meta['engine'],'host':meta['host']}
    raw=json.dumps(request,ensure_ascii=False).encode()
    start=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='usl-source-') as work:
        p=subprocess.Popen([sys.executable,str(ROOT/'usl_systems/source_worker.py')],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=work,start_new_session=os.name!='nt')
        try:
            stdout,stderr_raw=p.communicate(raw,timeout=timeout)
        except subprocess.TimeoutExpired as e:
            if os.name!='nt':os.killpg(p.pid,signal.SIGKILL)
            else:p.kill()
            p.communicate()
            raise SourceError('Native source execution timed out') from e
        finally:
            if os.name!='nt':
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
    stderr=stderr_raw.decode('utf8','replace')
    if p.returncode:raise SourceError(f'{catalog_id} rejected source (exit {p.returncode}): '+stderr[-1500:])
    if len(stdout)>524288:raise SourceError('Worker output exceeded bound')
    try:result=json.loads(stdout)
    except (ValueError,UnicodeError) as e:raise SourceError('Invalid native result') from e
    ir={'schema':SCHEMA,'catalog_id':catalog_id,'engine_contract':meta,'source':source,'source_sha256':digest(source),
        'context_sha256':digest(context),'ast':result['ast'],
        'source_map':{'path':'<imported>','start_line':1,'end_line':source.count('\n')+1,'column_precision':'engine dependent; whole-source fallback'},
        'lowering':'opaque_native_source_with_typed_result; not translated USL semantics'}
    ir['integrity_sha256']=digest(ir)
    return {'schema':'usl.native.source.result.v1','catalog_id':catalog_id,'source_ir':ir,'ir_sha256':digest(ir),
        'value':result['value'],'value_sha256':digest(result['value']),'context_sha256':digest(context),
        'runtime':meta,'exit_code':p.returncode,'stdout':stdout.decode(),'stderr':stderr,
        'elapsed_ms':round((time.perf_counter()-start)*1000,3),'source_execution_verified':True,'full_spec_qualified':False}

def restore(ir):
    if not isinstance(ir,dict) or ir.get('schema')!=SCHEMA:raise SourceError('Unknown source IR schema')
    if digest({k:v for k,v in ir.items() if k!='integrity_sha256'})!=ir.get('integrity_sha256'):raise SourceError('Source IR metadata integrity failure')
    if ir.get('catalog_id') not in CONTRACTS or digest(ir.get('source',''))!=ir.get('source_sha256'):raise SourceError('Source IR integrity failure')
    if ir.get('engine_contract')!=provenance(ir['catalog_id']):raise SourceError('Source IR runtime changed')
    return ir['source']

class SourceSession:
    def __init__(self,*,approved=False,max_calls=32,imports=None):
        if type(max_calls) is not int or not 1<=max_calls<=32:raise SourceError('1..32 engine calls required')
        self.approved=approved;self.max_calls=max_calls;self.evidence=[]
        try:self.imports=json.loads(json.dumps({} if imports is None else imports,allow_nan=False))
        except (ValueError,TypeError,RecursionError) as e:raise SourceError('Imports must be finite JSON') from e
        if not isinstance(self.imports,dict) or len(json.dumps(self.imports).encode())>262144:raise SourceError('Typed imports must be a bounded JSON object')
        self.deadline=time.monotonic()+120
    def artifact(self,name):
        if name not in self.imports:raise SourceError('Missing declared artifact: '+str(name))
        return json.loads(json.dumps(self.imports[name]))
    def run(self,catalog_id,source,context):
        if len(self.evidence)>=self.max_calls:raise SourceError('Source capability call budget exceeded')
        remaining=self.deadline-time.monotonic()
        if remaining<=0:raise SourceError('Source session deadline exceeded')
        result=execute(catalog_id,source,context,approved=self.approved,timeout=min(12,remaining))
        self.evidence.append(result)
        return result
    def interpret(self,source):
        from .language import Interpreter
        if not isinstance(source,str) or not 0<len(source.encode())<=65536:raise SourceError('USL source size 1..65536 bytes required')
        result=Interpreter(timeout=120,capabilities={'engine_run':self.run,'artifact':self.artifact}).run(source)
        return {'stdout':result.output,'operations':result.operations,'evidence':self.evidence,
            'scores':result.variables.get('scores',[]),
            'dashboard_html':result.variables.get('dashboard_html'),
            'source_sha256':digest(source),'engine_calls':len(self.evidence),'full_spec_qualified':False}
