"""Durable evidence retrieval, observations and versioned executable skills."""
from __future__ import annotations
import hashlib, json, math, re, time, uuid
from .store import Store

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(',', ':'))

def fingerprint(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

class EntityMemory:
    def __init__(self, root=None):
        self.store = Store(root)
        with self.store._db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS entity_memory(id TEXT PRIMARY KEY, kind TEXT, text TEXT, evidence TEXT, confidence REAL, created REAL)')
            db.execute('CREATE VIRTUAL TABLE IF NOT EXISTS entity_search USING fts5(id UNINDEXED, text)')
            db.execute('CREATE TABLE IF NOT EXISTS entity_observations(id TEXT PRIMARY KEY, sensor TEXT, timestamp REAL, payload TEXT, sha256 TEXT)')
            db.execute('CREATE TABLE IF NOT EXISTS entity_skills(name TEXT, version INTEGER, document TEXT, sha256 TEXT, PRIMARY KEY(name,version))')
            db.execute('CREATE TABLE IF NOT EXISTS entity_active(name TEXT PRIMARY KEY, version INTEGER)')
            db.execute('CREATE TABLE IF NOT EXISTS entity_runs(id TEXT PRIMARY KEY, state TEXT, document TEXT, updated REAL)')
            db.execute('CREATE TABLE IF NOT EXISTS entity_claims(claim_key TEXT, memory_id TEXT, value TEXT, PRIMARY KEY(claim_key,memory_id))')

    def remember(self, text, evidence, confidence=0.5, kind='knowledge'):
        if kind not in ('knowledge', 'experience', 'hypothesis', 'skill', 'correction'):
            raise ValueError('unknown memory kind')
        if not isinstance(text, str) or not 1 <= len(text) <= 16_000:
            raise ValueError('memory text bound 1..16000')
        if not isinstance(evidence, dict) or not isinstance(evidence.get('source'), str) or not evidence['source']:
            raise ValueError('traceable evidence source required')
        if type(confidence) not in (int, float) or not math.isfinite(confidence) or not 0 <= confidence <= 1:
            raise ValueError('confidence must be finite in 0..1')
        if len(canonical(evidence)) > 32_000:
            raise ValueError('evidence exceeds bound')
        identity = fingerprint({'text': text, 'evidence': evidence, 'kind': kind})
        with self.store.lock, self.store._db() as db:
            exists = db.execute('SELECT id FROM entity_memory WHERE id=?', (identity,)).fetchone()
            if not exists:
                db.execute('INSERT INTO entity_memory VALUES(?,?,?,?,?,?)', (identity, kind, text, canonical(evidence), confidence, time.time()))
                db.execute('INSERT INTO entity_search VALUES(?,?)', (identity, text))
        return identity

    def retrieve(self, query, limit=8):
        if not isinstance(query, str) or len(query) > 2000 or type(limit) is not int or not 1 <= limit <= 30:
            raise ValueError('query/limit bound')
        tokens = re.findall(r'\w+', query, flags=re.UNICODE)[:24]
        if not tokens:
            return []
        match = ' OR '.join('"' + t.replace('"', '""') + '"' for t in tokens)
        with self.store._db() as db:
            rows = db.execute('SELECT m.*, bm25(entity_search) AS rank FROM entity_search JOIN entity_memory m ON m.id=entity_search.id WHERE entity_search MATCH ? ORDER BY rank,m.created DESC LIMIT ?', (match, limit)).fetchall()
        return [{**dict(r), 'evidence': json.loads(r['evidence'])} for r in rows]

    def remember_fact(self, subject, predicate, value, evidence, confidence=0.5):
        if any(not isinstance(x,str) or not 1<=len(x)<=256 for x in (subject,predicate)):
            raise ValueError('bounded fact subject/predicate required')
        raw=canonical(value)
        if len(raw)>4000:raise ValueError('fact value exceeds bound')
        key=fingerprint([subject,predicate])
        identity=self.remember(subject+' '+predicate+' '+raw,evidence,confidence)
        with self.store.lock,self.store._db() as db:
            previous=db.execute('SELECT memory_id,value FROM entity_claims WHERE claim_key=?',(key,)).fetchall()
            conflicts=[r['memory_id'] for r in previous if r['value']!=raw]
            db.execute('INSERT OR IGNORE INTO entity_claims VALUES(?,?,?)',(key,identity,raw))
        return {'memory_id':identity,'conflicting_memory_ids':conflicts,'settled_truth':False}

    def study_document(self, path):
        from pathlib import Path
        document=Path(path).resolve()
        if not document.is_file() or document.stat().st_size>256_000 or document.suffix.lower() not in ('.md','.txt','.json','.csv','.usl'):
            raise ValueError('bounded UTF-8 study document required')
        text=document.read_text('utf8')
        source_hash=hashlib.sha256(document.read_bytes()).hexdigest()
        identities=[]
        # Exact passages retain provenance; quotations do not become verified facts.
        for offset in range(0,len(text),2000):
            passage=text[offset:offset+2000]
            if passage.strip():
                identities.append(self.remember(passage,{'source':str(document),'source_sha256':source_hash,
                    'character_span':[offset,offset+len(passage)],'status':'source_statement_not_independently_verified'},0.5))
        return {'source_sha256':source_hash,'memory_ids':identities,'read_characters':len(text),
            'model_weights_changed':False,'source_claims_independently_verified':False}

    def observe(self, packet):
        from .senses import validate_packet
        validate_packet(packet)
        raw = canonical(packet)
        identity = fingerprint(packet)
        with self.store.lock, self.store._db() as db:
            db.execute('INSERT OR IGNORE INTO entity_observations VALUES(?,?,?,?,?)', (identity, packet['sense'], packet['timestamp'], raw, identity))
        return identity

    def observations(self, limit=30):
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError('observation limit 1..100')
        with self.store._db() as db:
            rows = db.execute('SELECT payload FROM entity_observations ORDER BY timestamp DESC LIMIT ?', (limit,)).fetchall()
        return [json.loads(r['payload']) for r in rows]

    def install_skill(self, name, document):
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}', name):
            raise ValueError('invalid skill name')
        raw = canonical(document)
        if len(raw) > 128_000:
            raise ValueError('skill document exceeds bound')
        with self.store.lock, self.store._db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT MAX(version) AS n FROM entity_skills WHERE name=?', (name,)).fetchone()
            version = (row['n'] or 0) + 1
            db.execute('INSERT INTO entity_skills VALUES(?,?,?,?)', (name, version, raw, fingerprint(document)))
            db.execute('INSERT OR REPLACE INTO entity_active VALUES(?,?)', (name, version))
        return version

    def skill(self, name, version=None):
        with self.store._db() as db:
            if version is None:
                active = db.execute('SELECT version FROM entity_active WHERE name=?', (name,)).fetchone()
                if not active:
                    raise ValueError('skill is not installed: ' + str(name))
                version = active['version']
            row = db.execute('SELECT * FROM entity_skills WHERE name=? AND version=?', (name, version)).fetchone()
        if not row:
            raise ValueError('skill version is not installed')
        document = json.loads(row['document'])
        if fingerprint(document) != row['sha256']:
            raise ValueError('skill integrity mismatch')
        return {'name': name, 'version': version, 'document': document, 'sha256': row['sha256']}

    def rollback(self, name, version):
        skill = self.skill(name, version)
        with self.store.lock, self.store._db() as db:
            db.execute('INSERT OR REPLACE INTO entity_active VALUES(?,?)', (name, version))
        return skill

    def save_run(self, identity, state, document):
        if state not in ('prepared', 'running', 'completed', 'failed', 'needs_review'):
            raise ValueError('invalid run state')
        raw = canonical(document)
        if len(raw) > 256_000:
            raise ValueError('run evidence bound exceeded')
        with self.store.lock, self.store._db() as db:
            db.execute('INSERT OR REPLACE INTO entity_runs VALUES(?,?,?,?)', (identity, state, raw, time.time()))

    def run(self, identity):
        with self.store._db() as db:
            row = db.execute('SELECT * FROM entity_runs WHERE id=?', (identity,)).fetchone()
        if not row:
            raise ValueError('run not found')
        return {**dict(row), 'document': json.loads(row['document'])}

    def recover(self):
        # A crash during an external/native action cannot be replayed as if pure.
        with self.store.lock, self.store._db() as db:
            rows = db.execute('SELECT id FROM entity_runs WHERE state="running"').fetchall()
            db.execute('UPDATE entity_runs SET state="needs_review",updated=? WHERE state="running"', (time.time(),))
        return [r['id'] for r in rows]
