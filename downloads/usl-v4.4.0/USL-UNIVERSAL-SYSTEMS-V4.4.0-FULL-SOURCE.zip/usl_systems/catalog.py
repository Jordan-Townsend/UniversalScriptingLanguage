"""606 real catalogued Pygments lexer/syntax families + optional legacy USL registries.
Lexing/recognition does not imply semantic transpilation. This is explicit in API.
"""
import json
from pathlib import Path
from .compiler import TARGETS,ALIASES,target_name

BASE=Path(__file__).parent

def syntax_catalog():
    with (BASE/'syntax_catalog.json').open(encoding='utf-8') as f: return json.load(f)

def load_catalog(legacy_path=None):
    if legacy_path is None:
        import os
        from .store import Store
        candidate=Store().root/'syntax_templates_fully_extended.json'
        if candidate.exists():legacy_path=candidate
    rows=[];ids=set()
    for row in syntax_catalog():
        id_=row['id'].lower()
        if id_ in ids: id_=id_+'-'+str(len(rows))
        ids.add(id_)
        canon=target_name(id_)
        rows.append({**row,'id':id_,'support':'emitter' if canon in TARGETS else 'recognition',
                     'emitter':canon if canon in TARGETS else None,'legacy_template':False})
    if legacy_path:
        legacy=json.loads(Path(legacy_path).read_text(encoding='utf-8'))
        if not isinstance(legacy,dict):raise ValueError('Legacy registry must contain a JSON object')
        for lang,template in legacy.items():
            if not isinstance(template,dict):continue
            lang=str(lang).lower()
            candidates=[r for r in rows if r['id']==lang or lang in r['aliases']]
            if candidates:
                candidates[0]['legacy_template']=True
            else:
                rows.append({'id':lang,'name':lang,'aliases':[lang],'extensions':template.get('file_extensions',[]),
                             'mimetypes':[],'support':'legacy_template','emitter':None,'legacy_template':True})
    return rows


def native_extension(name):
    for row in syntax_catalog():
        if name.lower() in (row['id'],*[a.lower() for a in row['aliases']]):
            pats=row['extensions'];e=next((p[1:] for p in pats if p.startswith('*.') and '*' not in p[1:]),None)
            return e or '.txt'
    return '.txt'
