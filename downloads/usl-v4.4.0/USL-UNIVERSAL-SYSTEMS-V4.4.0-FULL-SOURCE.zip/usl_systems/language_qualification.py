"""Independent positive, boundary, changed-input and parser-negative evidence."""
from concurrent.futures import ThreadPoolExecutor
from .language_runtime import CONTRACTS, run, catalog_readiness
from .entity_memory import fingerprint

def fixture(language, value=21):
    engine=CONTRACTS[language]['engine']
    context={'value':value}
    if engine=='coffeescript':source='console.log usl_context.value * 2';bad='if )'
    elif engine=='hy':source='(print (* (get usl_context "value") 2))';bad='(print'
    elif engine=='less':source=f'@value: {value}; body {{ margin: (@value * 2px); }}';bad='body { margin: ( ;'
    elif engine=='sass_scss':source=f'$value: {value}; body {{ margin: $value * 2px; }}';bad='body { margin: ; }'
    elif engine=='sass_indented':source=f'$value: {value}\nbody\n  margin: $value * 2px';bad='body\n  margin: ('
    elif engine=='pug':source='p= value';bad='p= ('
    elif engine.startswith('handlebars'):source='<p>{{value}}</p>' if engine.endswith('html') else 'value={{value}}';bad='{{#if value}}missing'
    elif engine=='liquid':source='value={{ value }}';bad='{% if value %}'
    elif engine=='genshi_text':source='value=${value}';bad='value=${(}'
    else:source='<p>${value}</p>';bad='<p></broken>'
    return {'source':source,'context':context,'invalid_source':bad,'value':value}

def oracle(language, observed, value):
    engine=CONTRACTS[language]['engine']
    if engine in ('coffeescript','hy'):return observed['stdout']==str(value*2)+'\n'
    if engine in ('less','sass_scss','sass_indented'):
        return observed['declarations']==[{'name':'margin','value':str(value*2)+'px','important':False}]
    if engine in ('pug','handlebars_html','genshi_html'):return observed['text']==str(value)
    if engine=='genshi_xml':return observed['root']=='p' and observed['text']==str(value)
    return observed['rendered']=='value='+str(value)

def qualify_one(language):
    cases=[]
    for value,label in [(21,'positive'),(0,'boundary_zero'),(-7,'changed_input')]:
        example=fixture(language,value)
        try:
            result=run(language,example['source'],example['context'],approved=True)
            passed=oracle(language,result['value'],value) and result['actual_native_execution']
            cases.append({'case':label,'passed':passed,'result':result})
        except Exception as exc:cases.append({'case':label,'passed':False,'error':str(exc)})
    example=fixture(language)
    try:
        run(language,example['invalid_source'],example['context'],approved=True)
        cases.append({'case':'syntax_negative','passed':False,'error':'invalid source accepted'})
    except ValueError as exc:
        markers={'coffeescript':'SyntaxError','hy':'PrematureEndOfInput','less':'Error','sass_scss':'Error','sass_indented':'Error',
            'pug':'Error','handlebars':'Error','handlebars_html':'Error','liquid':'LiquidSyntaxError',
            'genshi_text':'TemplateSyntaxError','genshi_xml':'TemplateSyntaxError','genshi_html':'TemplateSyntaxError'}
        marker=markers[CONTRACTS[language]['engine']]
        passed='native parser/execution failure:' in str(exc) and marker in str(exc)
        cases.append({'case':'syntax_negative','passed':passed,'error':str(exc),'expected_parser_error':marker,
            'source_sha256':fingerprint(example['invalid_source'])})
    return {'language':language,'cases':cases,'passed':all(c['passed'] for c in cases),'full_spec_qualified':False}

def qualify(workers=3):
    if type(workers) is not int or not 1<=workers<=6:raise ValueError('workers 1..6')
    with ThreadPoolExecutor(max_workers=workers) as pool:entries=list(pool.map(qualify_one,sorted(CONTRACTS)))
    return {'schema':'usl.language.qualification.v4.3','entries':entries,'new_entries':len(entries),
        'cases':sum(len(e['cases']) for e in entries),'passed_cases':sum(c['passed'] for e in entries for c in e['cases']),
        'all_passed':all(e['passed'] for e in entries),'full_specifications_qualified':0}
