"""Full-inventory USL sweep with real backends, shared evidence and exact gaps.

Work is grouped by actual frontend/backend family. Factoring, compression and
adaptive reduction reuse verified bookkeeping; they do not solve missing semantics.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import collections,json,time
from .catalog import load_catalog
from .catalog_backends import PROFILES,identity
from .catalog_cases import qualify,fixture
from .catalog_parser import mappings,parse_source
from .entity_memory import fingerprint
from .collapse import collapse_bytes,restore_bytes,ContentStore
from .fractal import FactoredFractal,dimensionless_load
from .adaptive import AdaptiveExecutor
from .language import Interpreter

ROOT=Path(__file__).resolve().parents[1]

def audit():
    from pygments.lexers import get_lexer_by_name
    baseline=json.loads((ROOT/'test_results/v4.3.0_606_coverage.json').read_text())
    historical={r['id'] for r in baseline['entries'] if r['historical_subset_evidence'] or r['new_subset_evidence']}
    parsers=mappings();rows=[]
    for row in load_catalog():
        name=row['id'];reference=None;lexer_class=None;error=None
        try:
            if row['aliases']:
                lexer=get_lexer_by_name(row['aliases'][0]);reference=getattr(lexer,'url',None)
                lexer_class=type(lexer).__module__+'.'+type(lexer).__name__
            else:error='catalog entry has no lexer alias; exact reference needs manual resolution'
        except Exception as exc:error=str(exc)
        profile=PROFILES.get(name)
        rows.append({'catalog_id':name,'name':row['name'],'historical_subset_evidence':name in historical,
            'reference_url':reference,'reference_is_audited_semantic_standard':False,'lexer_class':lexer_class,
            'reference_issue':error,'execution_profile':profile,'backend':identity(name) if profile else None,
            'parser':parsers.get(name),'full_spec_qualified':False,
            'mode':profile['mode'] if profile else 'exact_execution_mode_requires_specification_review',
            'completion_gate':'versioned specification, real compatible backend, independent conformance and interoperability evidence'})
    if len(rows)!=606 or len({r['catalog_id'] for r in rows})!=606:raise ValueError('full inventory mismatch')
    return rows

def sweep(*,workers=4,output=None,approved=False):
    if approved is not True:raise ValueError('explicit full-sweep native execution approval required')
    if type(workers) is not int or not 1<=workers<=8:raise ValueError('workers 1..8')
    output=Path(output or ROOT/'test_results/v4.4.0_sweep');output.mkdir(parents=True,exist_ok=True)
    rows=audit();remaining=[r for r in rows if not r['historical_subset_evidence']]
    if len(remaining)!=523:raise ValueError('initial 523-entry task inventory mismatch')
    (output/'initial_523_inventory.json').write_text(json.dumps(remaining,indent=2)+'\n')
    grouped=collections.defaultdict(list)
    for row in remaining:
        key=row['execution_profile']['engine'] if row['execution_profile'] else row['lexer_class'] or row['catalog_id']
        grouped[key].append(row['catalog_id'])
    (output/'worker_sets.json').write_text(json.dumps(dict(grouped),indent=2)+'\n')
    begin=time.monotonic();completed=[]
    # Fresh native execution for qualification; cache never replaces a run.
    selected=[r['catalog_id'] for r in remaining if r['catalog_id'] in PROFILES]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(qualify,name):name for name in selected}
        for future in as_completed(futures):
            name=futures[future]
            try:result=future.result()
            except Exception as exc:result={'catalog_id':name,'passed':False,'error':str(exc),'cases':[]}
            completed.append(result)
            (output/(name.replace('+','_plus_')+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    completed.sort(key=lambda r:r['catalog_id'])
    results={r['catalog_id']:r for r in completed};parser_evidence={}
    # Independently demonstrate available frontends using real backend fixtures;
    # installed grammar metadata alone never becomes parser qualification.
    for name in selected:
        if not mappings().get(name):continue
        f=fixture(name)
        try:
            positive=parse_source(name,f['source'])
            rejected=False
            try:parse_source(name,f['invalid_source'])
            except ValueError as exc:rejected='upstream grammar rejected source:' in str(exc)
            parser_evidence[name]={'positive':positive,'native_invalid_source_rejected':rejected,
                'qualified_case_pair':rejected,'dialect_profile_only':True,'semantic_execution':False}
        except ValueError as exc:parser_evidence[name]={'qualified_case_pair':False,'error':str(exc)}
    for row in rows:
        result=results.get(row['catalog_id'])
        row['new_subset_evidence']=bool(result and result['passed'])
        row['parser_case_evidence']=parser_evidence.get(row['catalog_id'])
        row['required_completion_gates']={
            'exact_versioned_standard_audited':False,'full_grammar_qualified':False,
            'native_backend_case_evidence':bool(result and result['passed']) or row['historical_subset_evidence'],
            'complete_types_and_runtime_semantics':False,'standard_library_coverage_complete':False,
            'arbitrary_source_semantic_translation':False,'ownership_exceptions_concurrency_preserved':False,
            'generated_program_intent_proved':False,'upstream_conformance_suite_complete':False,
            'claimed_platforms_qualified':False}
        if row['historical_subset_evidence'] or row['new_subset_evidence']:
            row['status']='subset_observed_full_conformance_pending'
        elif result:
            row['status']='backend_qualification_failed';row['blocker']='review actual case diagnostics and repair runtime/semantics'
        else:
            row['status']='execution_backend_unqualified'
            row['blocker']='no reviewed executable profile or exact format-processing contract; installed parser/lexer cannot substitute for it'
    subtotal=sum(r['historical_subset_evidence'] or r['new_subset_evidence'] for r in rows)
    passed_cases=[sum(c['passed'] for c in r.get('cases',[])) for r in completed]
    factored=FactoredFractal(workers=workers,leaf_size=4,max_depth=5).execute(passed_cases,operator='sum',
        dimensions=['grammar','runtime','independent_oracle','provenance'],mode='async',reuse=True,verify=True)
    adaptive=AdaptiveExecutor(workers=workers,leaf_size=4).choose(passed_cases,operator='sum',repeats=3)
    raw=json.dumps(rows,sort_keys=True,ensure_ascii=False).encode();collapsed=collapse_bytes(raw)
    if restore_bytes(collapsed)!=raw:raise ValueError('inventory collapse roundtrip failed')
    cas=ContentStore(output/'evidence-cas');identity_=cas.put(raw)['sha256']
    if cas.get(identity_)!=raw:raise ValueError('content-addressed evidence retrieval failed')
    summary={'schema':'usl.catalog.completion.sweep.v4.4','initial_remaining':523,'inventory_accounted_for':606,
        'worker_sets':len(grouped),'workers':workers,'new_profiles_attempted':len(completed),
        'new_profiles_passed':sum(r['passed'] for r in completed),'native_and_format_cases_passed':sum(passed_cases),
        'parser_case_pairs_passed':sum(e['qualified_case_pair'] for e in parser_evidence.values()),
        'historical_plus_new_subsets':subtotal,'unqualified_entries':606-subtotal,
        'full_specifications_qualified':0,'all_606_complete':False,'initial_task_complete':False,
        'elapsed_seconds':time.monotonic()-begin,'factored':factored,'adaptive':adaptive,
        'dimensionless_admission':dimensionless_load({'admitted_processes':workers},{'admitted_processes':workers}),
        'collapse':{k:v for k,v in collapsed.items() if k not in ('payload','data','reference','segments')},
        'evidence_cas_sha256':identity_,'entries':rows,'results':completed,'parser_evidence':parser_evidence}
    (output/'full_606_sweep.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    (output/'remaining_blockers.json').write_text(json.dumps([r for r in rows if not(r['historical_subset_evidence'] or r['new_subset_evidence'])],indent=2)+'\n')
    return summary

def usl_sweep(source,*,workers=4,output=None,approved=False):
    result={}
    def execute_sweep():
        nonlocal result
        result=sweep(workers=workers,output=output,approved=approved)
        return {k:result[k] for k in ('inventory_accounted_for','initial_remaining','new_profiles_attempted','new_profiles_passed','historical_plus_new_subsets','unqualified_entries','all_606_complete')}
    r=Interpreter(max_ops=10000,timeout=300,capabilities={'catalog_sweep':execute_sweep}).run(source)
    result['usl_supervisor']={'stdout':r.output,'operations':r.operations,'source_sha256':fingerprint(source)}
    Path(output or ROOT/'test_results/v4.4.0_sweep','full_606_sweep.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    return result
