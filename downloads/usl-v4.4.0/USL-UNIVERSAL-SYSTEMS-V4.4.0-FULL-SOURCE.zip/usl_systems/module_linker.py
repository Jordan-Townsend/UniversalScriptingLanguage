"""Closed-world, content-addressed USL module linking.

No imports from the host filesystem or Python runtime. Modules are pure function
libraries and the entry module owns all actions. Source is parsed with the
existing restricted USL grammar; dependency cycles and name collisions fail
before execution. This is a source linker, not a general dynamic module loader.
"""
from __future__ import annotations
from hashlib import sha256
import ast,json,re
from .language import parse,normalize,BUILTINS,USLError

SCHEMA='usl.module_project.v1'
IDENT=re.compile(r'^[a-zA-Z][a-zA-Z0-9_]{0,63}$')
USE=re.compile(r'^use\s+([A-Za-z][A-Za-z0-9_]{0,63})\s*$')
class LinkError(USLError):pass

def _inspect_module(name,source):
    if not isinstance(source,str) or len(source.encode('utf8'))>65536:
        raise LinkError('Module '+name+' exceeds 64 KiB source limit')
    imports=[];body=[];in_uses=True
    for line in source.replace('\r\n','\n').split('\n'):
        stripped=line.strip()
        if not stripped or stripped.startswith('#'):
            body.append(line);continue
        match=USE.fullmatch(line)
        if match:
            if not in_uses:raise LinkError('use directives must precede executable source')
            dep=match.group(1)
            if dep not in imports:imports.append(dep)
            continue
        if stripped.startswith('use ') or stripped=='use':
            raise LinkError('Invalid or indented use declaration')
        in_uses=False;body.append(line)
    text='\n'.join(body)
    tree=parse(text)
    return {'imports':imports,'body':text,'tree':tree,'sha256':sha256(source.encode('utf8')).hexdigest()}

def link_project(project):
    if not isinstance(project,dict) or project.get('schema')!=SCHEMA:
        raise LinkError('Incorrect project schema')
    entry=project.get('entry');mods=project.get('modules')
    if not isinstance(entry,str) or not isinstance(mods,dict) or not 1<=len(mods)<=64 or entry not in mods:
        raise LinkError('Invalid entry/module mapping')
    if any(not isinstance(k,str) or not IDENT.fullmatch(k) for k in mods):
        raise LinkError('Module identifiers must be simple names')
    if sum(len(str(v).encode('utf8')) for v in mods.values())>262144:
        raise LinkError('Project exceeds 256 KiB source budget')
    parsed={k:_inspect_module(k,v) for k,v in mods.items()}
    visiting=set();visited=set();order=[]
    def visit(name):
        if name in visiting:raise LinkError('Dependency cycle involving '+name)
        if name in visited:return
        visiting.add(name)
        for dep in parsed[name]['imports']:
            if dep not in parsed:raise LinkError('Missing imported module '+dep)
            visit(dep)
        visiting.remove(name);visited.add(name);order.append(name)
    visit(entry)
    if len(order)>64:raise LinkError('Too many reachable modules')
    symbols={};parts=[]
    for name in order:
        module=parsed[name]
        nodes=module['tree'].body
        if name!=entry and any(not isinstance(node,ast.FunctionDef) for node in nodes):
            raise LinkError('Imported modules may contain only pure function definitions')
        if name!=entry and any(isinstance(expr,ast.Call) and isinstance(expr.func,ast.Name) and expr.func.id=='print' for expr in ast.walk(module['tree'])):
            raise LinkError('Imported library functions cannot print')
        for node in nodes:
            if isinstance(node,ast.FunctionDef):
                if node.name in symbols or node.name in BUILTINS or node.name in ('print','range'):
                    raise LinkError('Duplicate/reserved function: '+node.name)
                symbols[node.name]=name
        parts.append('# module: '+name+' sha256: '+module['sha256']+'\n'+normalize(module['body']))
    output='\n\n'.join(parts)+'\n'
    tree=parse(output)
    # Fail early on direct calls to missing project functions. The native
    # compiler is free to reject unsupported constructs separately.
    calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)]
    for call in calls:
        if call.func.id not in symbols and call.func.id not in BUILTINS and call.func.id!='print':
            raise LinkError('Unresolved function '+call.func.id)
        if call.func.id in symbols:
            fn=next(x for x in ast.walk(tree) if isinstance(x,ast.FunctionDef) and x.name==call.func.id)
            if len(call.args)!=len(fn.args.args):raise LinkError('Argument count mismatch for '+call.func.id)
    return {'schema':'usl.linked_project.v1','entry':entry,'order':order,
            'modules':[{'name':name,'sha256':parsed[name]['sha256'],
                        'imports':parsed[name]['imports']} for name in order],
            'output_sha256':sha256(output.encode('utf8')).hexdigest(),
            'source':output,'exports':symbols,'source_files_used':len(order),
            'host_imports_executed':False,'general_module_system_complete':False}

def from_file(path):
    from pathlib import Path
    p=Path(path)
    if p.stat().st_size>320000:raise LinkError('Project file exceeds 320 KiB')
    return link_project(json.loads(p.read_text(encoding='utf8')))
