"""Portable, versioned semantic IR for the *implemented* USL language subset.

The AST is losslessly represented as JSON rather than substituting text templates.
Every future target backend can consume the same validated representation. This
is infrastructure for language support, not 606 claims of semantic equivalence.
"""
from __future__ import annotations
import ast
import hashlib
import json
from dataclasses import dataclass
from .language import parse, normalize, BUILTINS, USLError

IR_VERSION = 1
MAX_NODES = 10000


def _encode(value):
    if isinstance(value, ast.AST):
        return {'node': value.__class__.__name__, 'fields': {k: _encode(v) for k, v in ast.iter_fields(value)}}
    if isinstance(value, list):
        return [_encode(x) for x in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise USLError(f'Unexpected IR field type: {type(value).__name__}')


def _decode(value):
    if isinstance(value, dict):
        if set(value) != {'node', 'fields'}:raise USLError('Invalid IR node schema')
        cls=getattr(ast,value['node'],None)
        if not isinstance(cls,type) or not issubclass(cls,ast.AST):raise USLError('Unknown AST node')
        if not isinstance(value['fields'],dict) or set(value['fields'])!=set(cls._fields):raise USLError('IR fields do not match AST grammar')
        return cls(**{k:_decode(v) for k,v in value['fields'].items()})
    if isinstance(value,list):return [_decode(x) for x in value]
    if value is None or isinstance(value,(str,int,float,bool)):return value
    raise USLError('Invalid IR literal')


class Analyzer:
    """Conservative name-resolution diagnostics, not a full static type checker."""
    def __init__(self):
        self.diagnostics=[]
        self.known=set(BUILTINS)|{'print'}
        self.functions={}

    def issue(self,node,code,message):
        self.diagnostics.append({'severity':'warning','code':code,'line':getattr(node,'lineno',None),'message':message})

    def expressions(self,node,known):
        if isinstance(node,ast.Name) and isinstance(node.ctx,ast.Load):
            if node.id not in known:self.issue(node,'POSSIBLY_UNDEFINED',node.id+' is not definitely defined')
        elif isinstance(node,ast.Call):
            if not isinstance(node.func,ast.Name) or node.func.id not in known:
                self.issue(node,'UNRESOLVED_CALL','Function is not defined at this point')
            for arg in node.args:self.expressions(arg,known)
        else:
            for child in ast.iter_child_nodes(node):self.expressions(child,known)

    def block(self,nodes,known):
        known=set(known)
        for node in nodes:
            if isinstance(node,ast.FunctionDef):
                known.add(node.name)
                self.block(node.body,set(known)|{a.arg for a in node.args.args})
            elif isinstance(node,ast.Assign):
                self.expressions(node.value,known)
                known.add(node.targets[0].id)
            elif isinstance(node,ast.AugAssign):
                self.expressions(node.target,known)
                self.expressions(node.value,known)
            elif isinstance(node,ast.If):
                self.expressions(node.test,known)
                yes=self.block(node.body,known)
                no=self.block(node.orelse,known) if node.orelse else known
                known=yes & no
            elif isinstance(node,(ast.While,ast.For)):
                if isinstance(node,ast.For):
                    self.expressions(node.iter,known)
                    self.block(node.body,known|{node.target.id})
                else:
                    self.expressions(node.test,known)
                    self.block(node.body,known)
                # Loops may run zero times, so their assignments aren't definite.
            elif isinstance(node,ast.Assert):self.expressions(node.test,known)
            elif isinstance(node,ast.Return):
                if node.value:self.expressions(node.value,known)
            elif isinstance(node,ast.Expr):self.expressions(node.value,known)
        return known

    def analyze(self,tree):
        # Top-level functions may reference other functions defined later.
        funcs={x.name for x in tree.body if isinstance(x,ast.FunctionDef)}
        self.block(tree.body,self.known|funcs)
        return self.diagnostics


def lower(source):
    if not isinstance(source,str) or len(source)>100000:raise USLError('Invalid source size')
    tree=parse(source)
    nodes=sum(1 for _ in ast.walk(tree))
    if nodes>MAX_NODES:raise USLError('AST node count exceeds limit')
    normalized=normalize(source)
    body=_encode(tree)
    fingerprint=hashlib.sha256(json.dumps(body,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
    return {'schema':'usl.semantic_ir','version':IR_VERSION,'normalized_source_sha256':hashlib.sha256(normalized.encode('utf-8')).hexdigest(),
            'ir_sha256':fingerprint,'node_count':nodes,'body':body,'diagnostics':Analyzer().analyze(tree),
            'claims':{'semantic_execution':'USL interpreter subset','foreign_language_equivalence':'must be tested with each native toolchain'}}


def restore(ir):
    if not isinstance(ir,dict) or ir.get('schema')!='usl.semantic_ir' or ir.get('version')!=IR_VERSION:
        raise USLError('Unsupported semantic IR schema/version')
    encoded=ir.get('body')
    if not isinstance(encoded,dict):raise USLError('Missing IR AST')
    actual=hashlib.sha256(json.dumps(encoded,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()
    if actual!=ir.get('ir_sha256'):raise USLError('IR integrity mismatch')
    tree=_decode(encoded)
    if not isinstance(tree,ast.Module):raise USLError('IR root is not a module')
    if sum(1 for _ in ast.walk(tree))>MAX_NODES:raise USLError('IR node count exceeds limit')
    ast.fix_missing_locations(tree)
    # Re-parse the printed source to enforce all of the language's safety rules.
    return parse(ast.unparse(tree))


def from_json(data):
    if isinstance(data,str):data=json.loads(data)
    return restore(data)
