"""One native parser/engine per process; no shared mutable parser state."""
from __future__ import annotations
import io, json, os, subprocess, sys, tempfile
from pathlib import Path

def native(argv, input_text=''):
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        p=subprocess.run(argv,input=input_text.encode(),stdout=out,stderr=err,timeout=8)
        out.seek(0);err.seek(0)
        stdout=out.read(524289);stderr=err.read(524289)
    if len(stdout)>524288 or len(stderr)>524288:raise ValueError('Native output bound exceeded')
    if p.returncode:raise ValueError('Native engine rejected source: '+stderr.decode('utf8','replace')+stdout.decode('utf8','replace'))
    return stdout.decode('utf8')

def validate_host(host, rendered):
    if host=='text':return {'rendered':rendered}
    if host=='javascript':
        p=Path('rendered.js');p.write_text(rendered,encoding='utf8')
        node=['node','--max-old-space-size=64','--max-semi-space-size=4','--disable-wasm-trap-handler']
        native([*node,'--check',str(p)])
        return {'rendered':rendered,'stdout':native([*node,str(p)]),'host':'javascript'}
    if host=='xml':
        from lxml import etree
        root=etree.fromstring(rendered.encode(),parser=etree.XMLParser(resolve_entities=False,no_network=True))
        if root.getroottree().docinfo.doctype:raise ValueError('External/DTD XML sources not admitted by this contract')
        return {'rendered':rendered,'root':root.tag,'text':''.join(root.itertext()),'host':'xml'}
    if host=='html':
        from lxml import html
        root=html.fromstring(rendered)
        return {'rendered':rendered,'text':root.text_content(),'host':'html'}
    if host=='css':
        import tinycss2
        rules=tinycss2.parse_stylesheet(rendered,skip_whitespace=True,skip_comments=True)
        declarations=[]
        for rule in rules:
            if rule.type!='qualified-rule':raise ValueError('This CSS contract admits style rules only')
            for item in tinycss2.parse_declaration_list(rule.content,skip_whitespace=True,skip_comments=True):
                if item.type!='declaration':raise ValueError('CSS declaration parser rejected output')
                value=tinycss2.serialize(item.value).strip()
                if not value:raise ValueError('Empty CSS declaration')
                declarations.append({'name':item.name,'value':value,'important':item.important})
        return {'rendered':rendered,'declarations':declarations,'host':'css'}
    raise ValueError('Unknown host contract')

def execute(req):
    source=req['source'];context=req['context'];engine=req['engine'];host=req['host']
    if engine=='django':
        from django.template import Engine, Context
        from django.conf import settings
        if not settings.configured:settings.configure(USE_I18N=False,USE_TZ=False)
        template=Engine(debug=True).from_string(source)
        nodes=[{'kind':type(n).__name__,'line':getattr(getattr(n,'token',None),'lineno',1)} for n in template.nodelist]
        rendered=template.render(Context(context,use_l10n=False,use_tz=False))
    elif engine=='cheetah':
        from Cheetah.Template import Template
        template=Template.compile(source=source)
        nodes=[{'kind':'compiled_template','line':1}]
        rendered=str(template(searchList=[context]))
    elif engine=='mako':
        from mako.template import Template
        from mako.lexer import Lexer
        tree=Lexer(source).parse()
        nodes=[{'kind':type(n).__name__,'line':getattr(n,'lineno',1)} for n in tree.nodes]
        rendered=Template(source,strict_undefined=True).render(**context)
    elif engine=='php':
        p=Path('source.php');p.write_text(source,encoding='utf8')
        native(['php','-l',str(p)])
        nodes=json.loads(native(['php','-r','echo json_encode(array_map(fn($t)=>is_array($t)?[token_name($t[0]),$t[1],$t[2]]:["punctuation",$t,null],token_get_all(file_get_contents($argv[1]),TOKEN_PARSE)),JSON_THROW_ON_ERROR);',str(p)]))
        rendered=native(['php','-r','$usl_context=json_decode(stream_get_contents(STDIN),true,512,JSON_THROW_ON_ERROR); require $argv[1];',str(p)],json.dumps(context))
    elif engine=='ruby':
        p=Path('source.rb');p.write_text(source,encoding='utf8')
        native(['ruby','-c',str(p)])
        nodes=json.loads(native(['ruby','-rjson','-rripper','-e','puts JSON.generate(Ripper.sexp(File.read(ARGV[0])))',str(p)]))
        rendered=native(['ruby','-rjson','-e','USL_CONTEXT=JSON.parse(STDIN.read);load ARGV[0]',str(p)],json.dumps(context))
    elif engine=='graphql':
        from graphql import parse, build_schema, graphql_sync
        schema=build_schema('type Query { twice(x: Int!): Int!, echo(text: String!): String! }')
        schema.query_type.fields['twice'].resolve=lambda obj,info,x:x*2
        schema.query_type.fields['echo'].resolve=lambda obj,info,text:text
        tree=parse(source)
        result=graphql_sync(schema,source,variable_values=context)
        if result.errors:raise ValueError('; '.join(str(e) for e in result.errors))
        return {'value':{'data':result.data},'ast':[{'kind':d.kind,'line':d.loc.start_token.line} for d in tree.definitions]}
    elif engine=='dtd':
        from lxml import etree
        # No remote/file entity resolution in the bounded document contract.
        if 'SYSTEM' in source or 'PUBLIC' in source:raise ValueError('External DTD entities require a separate IO contract')
        dtd=etree.DTD(io.StringIO(source))
        xml=context.get('document','<task><value>42</value></task>')
        root=etree.fromstring(xml.encode(),parser=etree.XMLParser(resolve_entities=False,no_network=True))
        if root.getroottree().docinfo.doctype:raise ValueError('Document DOCTYPE not admitted')
        if not dtd.validate(root):raise ValueError(str(dtd.error_log))
        return {'value':{'validated':True,'root':root.tag,'text':''.join(root.itertext())},'ast':[{'kind':'element','name':e.name,'line':1} for e in dtd.iterelements()]}
    else:raise ValueError('Unknown actual engine')
    return {'value':validate_host(host,rendered),'ast':nodes}

if __name__=='__main__':
    try:
        if os.name!='nt':
            import resource
            resource.setrlimit(resource.RLIMIT_CPU,(8,8))
            resource.setrlimit(resource.RLIMIT_FSIZE,(1024*1024,1024*1024))
        raw=sys.stdin.buffer.read(65537)
        if len(raw)>65536:raise ValueError('Request too large')
        request=json.loads(raw)
        if os.name!='nt':
            # V8 reserves a large virtual address range independently of its
            # capped 64 MiB heap. Keep a separate bound for that host.
            address_limit=(8*1024 if request['host']=='javascript' else 512)*1024*1024
            resource.setrlimit(resource.RLIMIT_AS,(address_limit,address_limit))
        result=execute(request)
        encoded=json.dumps(result,sort_keys=True,ensure_ascii=False,allow_nan=False)
        if len(encoded.encode())>524288:raise ValueError('Engine result too large')
        print(encoded)
    except Exception as exc:
        print(f'{type(exc).__name__}: {exc}',file=sys.stderr)
        raise SystemExit(1)
