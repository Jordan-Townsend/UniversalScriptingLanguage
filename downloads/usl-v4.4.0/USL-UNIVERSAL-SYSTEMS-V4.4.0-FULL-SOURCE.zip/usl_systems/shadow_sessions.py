"""Persistent local Shadow chat: real Ollama API, bounded context, strict turns.

No invented memory, no autonomous tool use, no model-generated operating-system
commands. A durable pending turn is not automatically resubmitted after crash.
"""
from __future__ import annotations
import json, re, threading, time
from uuid import uuid4
from .agent import models, _url
from .language import USLError

class ShadowInterrupted(USLError):pass
import urllib.request

ID=re.compile(r'^[0-9a-f]{24}$')

class ShadowSessions:
    def __init__(self,store,invoke=None):
        self.store=store
        self.invoke=invoke or self._ollama
        self._guard=threading.RLock()
        self._locks={}
        self._cancellations={}
        self._default_provider=invoke is None
        with store.lock,store._db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS shadow_sessions (
              id TEXT PRIMARY KEY, created REAL NOT NULL, updated REAL NOT NULL, model TEXT)''')
            db.execute('''CREATE TABLE IF NOT EXISTS shadow_turns (
              id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL,
              role TEXT NOT NULL, content TEXT NOT NULL, status TEXT NOT NULL,
              created REAL NOT NULL, FOREIGN KEY(session_id) REFERENCES shadow_sessions(id))''')
            db.execute("UPDATE shadow_turns SET status='interrupted' WHERE status='pending'")

    def new(self,model=None):
        if model is not None and (not isinstance(model,str) or len(model)>120):raise ValueError('Invalid model name')
        key=uuid4().hex[:24];now=time.time()
        with self.store.lock,self.store._db() as db:
            db.execute('INSERT INTO shadow_sessions VALUES (?,?,?,?)',(key,now,now,model))
        return {'id':key,'model':model,'turns':[]}

    def history(self,ident):
        if not isinstance(ident,str) or not ID.fullmatch(ident):raise ValueError('Invalid session')
        with self.store.lock,self.store._db() as db:
            record=db.execute('SELECT * FROM shadow_sessions WHERE id=?',(ident,)).fetchone()
            if not record:raise ValueError('Unknown session')
            messages=db.execute('SELECT role,content,status,created FROM shadow_turns WHERE session_id=? ORDER BY id DESC LIMIT 30',(ident,)).fetchall()
        return {'id':ident,'model':record['model'],'turns':[dict(x) for x in reversed(messages)]}

    def list(self,limit=20):
        with self.store.lock,self.store._db() as db:
            return [dict(x) for x in db.execute('SELECT id,created,updated,model FROM shadow_sessions ORDER BY updated DESC LIMIT ?', (min(50,max(1,int(limit))),)).fetchall()]

    @staticmethod
    def _ollama(history,model=None,timeout=80):
        info=models()
        if not info['connected']:raise USLError('Ollama unavailable')
        chosen=model or next(iter(info['models']),None)
        if not chosen or chosen not in info['models']:
            raise USLError('Requested Ollama model is not installed')
        body=json.dumps({'model':chosen,'messages':history,'stream':False,
                'options':{'num_predict':1024,'temperature':0.3}},ensure_ascii=False).encode('utf8')
        req=urllib.request.Request(_url('/api/chat'),data=body,headers={'Content-Type':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=min(180,max(2,timeout))) as response:
                if response.status!=200:raise USLError('Ollama returned unsuccessful status')
                blob=response.read(65537)
            if len(blob)>65536:raise USLError('Ollama response exceeds 64 KiB')
            answer=json.loads(blob)['message']['content']
            if not isinstance(answer,str) or not answer.strip():raise USLError('Ollama returned no message')
            return answer[:12000],chosen
        except (OSError,KeyError,ValueError) as exc:
            raise USLError('Ollama conversation failed: '+type(exc).__name__) from exc

    @staticmethod
    def _ollama_stream(history,model,stop_event,timeout=80):
        """Read Ollama NDJSON in bounded segments, require terminal done=true.

        Connection has a finite per-read timeout to permit cancellation and to avoid
        permanently stalled chat turns. Server may still work after client cancellation.
        """
        info=models()
        if not info['connected']:raise USLError('Ollama unavailable')
        chosen=model or next(iter(info['models']),None)
        if not chosen or chosen not in info['models']:
            raise USLError('Requested Ollama model is not installed')
        if stop_event.is_set():raise ShadowInterrupted('Cancellation requested')
        body=json.dumps({'model':chosen,'messages':history,'stream':True,
                          'options':{'num_predict':1024,'temperature':0.3}},ensure_ascii=False).encode('utf8')
        request=urllib.request.Request(_url('/api/chat'),data=body,
                         headers={'Content-Type':'application/json'},method='POST')
        answer=[];total=0;done=False;deadline=time.monotonic()+max(2,min(180,timeout))
        try:
            with urllib.request.urlopen(request,timeout=2.0) as response:
                if response.status!=200:raise USLError('Ollama response was not HTTP 200')
                for _ in range(1024):
                    if stop_event.is_set():raise ShadowInterrupted('Cancellation requested')
                    if time.monotonic()>deadline:raise USLError('Ollama conversation deadline exceeded')
                    line=response.readline(65537)
                    if len(line)>65536:raise USLError('Ollama NDJSON line exceeds size limit')
                    if not line:break
                    total+=len(line)
                    if total>131072:raise USLError('Ollama stream exceeds 128 KiB')
                    packet=json.loads(line)
                    if not isinstance(packet,dict):raise USLError('Malformed Ollama packet')
                    if packet.get('error'):raise USLError('Ollama error packet received')
                    msg=packet.get('message',{})
                    if not isinstance(msg,dict):raise USLError('Malformed Ollama message')
                    chunk=msg.get('content','')
                    if not isinstance(chunk,str):raise USLError('Non-text Ollama response chunk')
                    answer.append(chunk)
                    if sum(map(len,answer))>12000:raise USLError('Ollama answer exceeds 12K characters')
                    if packet.get('done') is True:
                        done=True;break
            if stop_event.is_set():raise ShadowInterrupted('Cancellation requested')
            text=''.join(answer)
            if not done or not text.strip():raise USLError('Ollama stream ended without a complete answer')
            return text,chosen
        except ShadowInterrupted:raise
        except (OSError,TimeoutError,ValueError,KeyError) as exc:
            if stop_event.is_set():raise ShadowInterrupted('Cancellation requested') from exc
            raise USLError('Ollama streaming error: '+type(exc).__name__) from exc

    def cancel(self,ident):
        # Validate even on a missing/nonactive session: never create IDs on cancellation.
        self.history(ident)
        with self._guard:
            signal=self._cancellations.get(ident)
            if signal is None:return {'id':ident,'cancellation_requested':False,'active':False}
            signal.set()
            return {'id':ident,'cancellation_requested':True,'active':True}

    def send(self,ident,prompt,model=None):
        if not isinstance(prompt,str) or not 1<=len(prompt.strip())<=8000:
            raise ValueError('Message must be 1..8000 characters')
        if model is not None and (not isinstance(model,str) or len(model)>120):raise ValueError('Invalid model')
        with self._guard:lock=self._locks.setdefault(ident,threading.Lock())
        if not lock.acquire(blocking=False):raise ValueError('Session currently processing a turn')
        cancel_event=threading.Event()
        with self._guard:self._cancellations[ident]=cancel_event
        try:
            session=self.history(ident)
            prior=[{'role':x['role'],'content':x['content']} for x in session['turns']
                   if x['status']=='completed' and x['role'] in ('user','assistant')][-16:]
            now=time.time()
            with self.store.lock,self.store._db() as db:
                db.execute('INSERT INTO shadow_turns(session_id,role,content,status,created) VALUES (?,?,?,?,?)',
                           (ident,'user',prompt,'pending',now))
            try:
                if self._default_provider:
                    answer,selected=self._ollama_stream(prior+[{'role':'user','content':prompt}],model or session['model'],cancel_event)
                else:
                    answer,selected=self.invoke(prior+[{'role':'user','content':prompt}],model or session['model'])
                if cancel_event.is_set():raise ShadowInterrupted('Cancellation requested')
                if not isinstance(answer,str) or not 1<=len(answer)<=12000:
                    raise USLError('Invalid model response')
            except Exception:
                with self.store.lock,self.store._db() as db:
                    db.execute("UPDATE shadow_turns SET status=? WHERE session_id=? AND role='user' AND status='pending'",
                        ('interrupted' if cancel_event.is_set() else 'failed',ident))
                raise
            with self.store.lock,self.store._db() as db:
                db.execute("UPDATE shadow_turns SET status='completed' WHERE session_id=? AND role='user' AND status='pending'",(ident,))
                db.execute('INSERT INTO shadow_turns(session_id,role,content,status,created) VALUES (?,?,?,?,?)',
                           (ident,'assistant',answer,'completed',time.time()))
                db.execute('UPDATE shadow_sessions SET updated=?,model=? WHERE id=?',(time.time(),selected,ident))
            return {'id':ident,'reply':answer,'model':selected,'turns':len(prior)+2,'verified_provider_response':True}
        finally:
            with self._guard:self._cancellations.pop(ident,None)
            lock.release()
