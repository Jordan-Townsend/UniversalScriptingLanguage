"""Opt-in best-effort AI generation for any 606 catalogued syntaxes.
Requires Ollama. This is explicitly unverified without an installed native toolchain.
"""
from pathlib import Path
from .adapters import AdapterRegistry
from .agent import ask_model,strip_fence
from .language import Interpreter,USLError
from .catalog import native_extension

def ai_transpile(source,target,model=None):
    Interpreter().run(source)  # Confirm input has real executable USL semantics.
    reg=AdapterRegistry();entry=reg.info(target)
    prompt=f'''You are translating a restricted programming language (USL) to a requested native language.
Target language/syntax: {entry['name']} (identifier {entry['id']}).
Output ONLY code written in the target language, no markdown or explanation.
Preserve the exact printing order, loops, operations and values. Do not invent imports unrelated to the standard language runtime.
If the target is a markup/configuration language not able to represent executable logic, respond exactly UNSUPPORTED_TARGET.
This translation is unverified and must be compiled/tested with an actual target language toolchain.
USL source:\n{source[:20000]}'''
    text=strip_fence(ask_model(prompt,model))
    if text.strip()=='UNSUPPORTED_TARGET':raise USLError(f'{target} cannot express this program as executable code')
    if not text or len(text)>100000:raise USLError('Empty or excessively large generation')
    return {'target':entry['id'],'name':entry['name'],'extension':native_extension(entry['id']),
            'code':text,'verification':'unverified','code_generation':'local_model',
            'warning':'Native language translation is NOT validated until an actual toolchain and equivalence test pass.'}
