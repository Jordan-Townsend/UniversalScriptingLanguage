"""Additional upstream language engines and conservative full-catalog readiness.

No fallback interprets a foreign-language label as USL. Actual unavailable engines
remain unavailable; qualification is restricted to independently checked cases.
"""
from __future__ import annotations
import importlib.metadata, json, os, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path
from .entity_memory import fingerprint
from .source_engines import runtime_file_hash

ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = {
    'coffeescript': {'engine': 'coffeescript', 'package': 'coffeescript', 'reference': 'https://coffeescript.org/'},
    'less': {'engine': 'less', 'package': 'less', 'reference': 'https://lesscss.org/'},
    'sass': {'engine': 'sass_indented', 'package': 'sass', 'reference': 'https://sass-lang.com/documentation/'},
    'scss': {'engine': 'sass_scss', 'package': 'sass', 'reference': 'https://sass-lang.com/documentation/'},
    'pug': {'engine': 'pug', 'package': 'pug', 'reference': 'https://pugjs.org/api/getting-started.html'},
    'handlebars': {'engine': 'handlebars', 'package': 'handlebars', 'reference': 'https://handlebarsjs.com/'},
    'html+handlebars': {'engine': 'handlebars_html', 'package': 'handlebars', 'reference': 'https://handlebarsjs.com/'},
    'hylang': {'engine': 'hy', 'distribution': 'hy', 'reference': 'https://hylang.org/'},
    'liquid': {'engine': 'liquid', 'distribution': 'python-liquid', 'reference': 'https://jg-rp.github.io/liquid/'},
    'genshi': {'engine': 'genshi_xml', 'distribution': 'Genshi', 'reference': 'https://genshi.edgewall.org/'},
    'genshitext': {'engine': 'genshi_text', 'distribution': 'Genshi', 'reference': 'https://genshi.edgewall.org/'},
    'html+genshi': {'engine': 'genshi_html', 'distribution': 'Genshi', 'reference': 'https://genshi.edgewall.org/'},
}

def node_modules():
    return Path(os.environ.get('USL_NODE_MODULES', str(ROOT/'native_engines'/'node_modules'))).resolve()

def discover():
    result = {}
    for name, contract in CONTRACTS.items():
        try:
            if 'package' in contract:
                manifest = node_modules()/contract['package']/'package.json'
                version = json.loads(manifest.read_text())['version']
                available = bool(shutil.which('node'))
                identity = runtime_file_hash(manifest)
                files=sorted(p for p in manifest.parent.rglob('*') if p.is_file() and 'node_modules' not in p.relative_to(manifest.parent).parts)
                source_identity=fingerprint({p.relative_to(manifest.parent).as_posix():runtime_file_hash(p) for p in files})
                lock=node_modules().parent/'package-lock.json'
                lock_identity=runtime_file_hash(lock) if lock.exists() else None
            else:
                distribution = importlib.metadata.distribution(contract['distribution'])
                version = distribution.version
                available = True
                identity = fingerprint(distribution.read_text('RECORD') or '')
                source_identity=fingerprint({str(p):runtime_file_hash(distribution.locate_file(p)) for p in (distribution.files or []) if str(p).endswith(('.py','.so','.pyd')) and distribution.locate_file(p).is_file()})
                lock_identity=None
            result[name] = {**contract, 'available': available, 'version': version, 'distribution_identity': identity,
                'actual_provider_source_sha256':source_identity,'dependency_lock_sha256':lock_identity,
                'native_host_sha256':runtime_file_hash(shutil.which('node')) if 'package' in contract and available else runtime_file_hash(sys.executable),
                'execution_qualified': False, 'full_spec_qualified': False, 'discovery_is_execution_evidence': False}
        except (OSError, ValueError, importlib.metadata.PackageNotFoundError):
            result[name] = {**contract, 'available': False, 'execution_qualified': False, 'full_spec_qualified': False}
    return result

def run(language, source, context=None, *, approved=False, timeout=12):
    if approved is not True:
        raise ValueError('explicit native language execution approval required')
    if language not in CONTRACTS or not isinstance(source, str) or not 1 <= len(source.encode()) <= 32_000:
        raise ValueError('known exact language and bounded source required')
    context = {} if context is None else context
    raw = json.dumps(context, allow_nan=False)
    if not isinstance(context, dict) or len(raw) > 16_000 or type(timeout) not in (int,float) or not 0 < timeout <= 30:
        raise ValueError('bounded context/timeout required')
    provider = discover()[language]
    if not provider['available']:
        raise ValueError('upstream language engine unavailable: ' + language)
    request = {'engine': CONTRACTS[language]['engine'], 'source': source, 'context': context, 'node_modules': str(node_modules())}
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='usl-language-') as folder, tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as error:
        argv = [sys.executable, str(ROOT/'usl_systems'/'language_worker.py')]
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=output, stderr=error,
            cwd=folder, start_new_session=os.name != 'nt')
        try:
            process.communicate(json.dumps(request, allow_nan=False).encode(), timeout=timeout)
        except subprocess.TimeoutExpired:
            if os.name != 'nt':
                try: os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError: pass
            else:
                subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=5)
            process.wait(timeout=5)
            raise ValueError('native language deadline exceeded')
        output.seek(0); error.seek(0)
        stdout, stderr = output.read(524289), error.read(524289)
    if len(stdout) > 524288 or len(stderr) > 524288:
        raise ValueError('native language output bound exceeded')
    if process.returncode:
        raise ValueError('native parser/execution failure: ' + stderr.decode(errors='replace')[-4000:])
    result = json.loads(stdout)
    source_record = {'language': language, 'source': source, 'source_sha256': fingerprint(source),
        'context_sha256': fingerprint(context), 'runtime': provider,
        'semantic_lowering': 'opaque_native_source_envelope', 'full_spec_qualified': False}
    return {'language': language, 'value': result['value'], 'parser': result['parser'],
        'source_record': source_record, 'value_sha256': fingerprint(result['value']),
        'actual_native_execution': True, 'elapsed_ms': (time.monotonic()-started)*1000}

def catalog_readiness(evidence=None):
    from .catalog import load_catalog
    baseline_path = ROOT/'test_results'/'v4.2.0_606_coverage.json'
    baseline = json.loads(baseline_path.read_text())
    prior = {r['catalog_id']: r for r in baseline['entries']}
    qualified = {r['language'] for r in (evidence or {}).get('entries', []) if r.get('passed')}
    installed = discover()
    rows = []
    for item in load_catalog():
        name = item['id']
        historical = prior.get(name, {}).get('qualification', 'unverified_execution') != 'unverified_execution'
        rows.append({'id': name, 'name': item['name'], 'historical_subset_evidence': historical,
            'new_subset_evidence': name in qualified,
            'engine': installed.get(name), 'full_spec_qualified': False,
            'next_step': 'expand versioned conformance' if historical or name in qualified else 'resolve exact specification and install real compatible upstream engine'})
    if len(rows) != 606:
        raise ValueError('catalog changed; audit required')
    total = sum(r['historical_subset_evidence'] or r['new_subset_evidence'] for r in rows)
    return {'catalog_total': 606, 'subset_evidence': total, 'unqualified_entries': 606-total,
        'full_specifications_qualified': 0, 'entries': rows}
