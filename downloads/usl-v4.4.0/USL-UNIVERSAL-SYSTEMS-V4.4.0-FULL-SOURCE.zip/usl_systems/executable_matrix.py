"""Executable, evidence-led routing matrix for the 606-entry USL catalog.

The matrix is a *program*: it can inspect each cell and launch exact, reviewed
host/guest fixtures. Catalog recognition NEVER implies executable success.

Codes: 0=unverified/no qualified transport, 1=conditionally routable but untested,
2=actual paired program executed and verified with hashes and exact typed values.
The dense matrix has exactly 606**2 bytes, in stable catalog order.
"""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import time
from .catalog import load_catalog
from .interop import SCHEMA, BridgeError, run_nested, catalog_matrix

SCHEMA_NAME='usl.routing.executable.v1'
ROOT=Path(__file__).resolve().parents[1]
EXTRAS={
 'awk':{'language':'awk','source':'function transform(x) { return x + 9 }\n','export':'transform','params':['i64'],'args':[41],'returns':'i64','expected':50},
 'sed':{'language':'sed','source':'s/cat/dog/g\n','export':'transform','params':['text'],'args':['cat here'],'returns':'text','expected':'dog here'},
}

def _canon(obj):
    return json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)

def _hash(obj):return hashlib.sha256(_canon(obj).encode('utf8')).hexdigest()

def fixtures(root=ROOT, *, include_registry=False):
    """Real original nested-source fixtures; input/expected from prior run, freshly re-executed."""
    root=Path(root)
    project=json.loads((root/'examples/nested_sixteen_languages.uslnest.json').read_text('utf8'))
    prior=json.loads((root/'test_results/v3.7.0_sixteen_native.json').read_text('utf8'))
    if not prior.get('all_verified') or prior.get('verified')!=16:
        raise ValueError('Missing verified baseline sixteen-stage evidence')
    result={}
    for node in project['nodes']:
        lang=node['language'];fresh={k:v for k,v in node.items() if k!='id'}
        fresh['args']=[prior['results'][item['ref']]['value'] if isinstance(item,dict) and set(item)=={'ref'} else item for item in node['args']]
        fresh['expected']=prior['results'][node['id']]['value']
        if _hash(fresh['source'])!=_hash(node['source']):raise ValueError('Fixture changed unexpectedly')
        result[lang]=fresh
    if len(result)!=16:raise ValueError('Fixture languages repeated')
    result.update(EXTRAS)
    if include_registry:
        from .universal_adapters import load_registry
        for name,adapter in load_registry(root).items():
            result[name]={'language':name,'source':adapter['source'],'export':'transform',
                'params':['i64'],'args':list(adapter['fixture_args']),'returns':'i64',
                'expected':adapter['fixture_expected']}
    return result

def _one(lang,node, authorized):
    doc={'schema':SCHEMA,'nodes':[{'id':'probe',**node}]}
    result=run_nested(doc,authorized=authorized,workers=1)
    entry=result['results'].get('probe',{})
    return {'language':lang,'status':'verified' if result['all_verified'] else 'failed',
            'source_sha256':entry.get('source_sha256') or hashlib.sha256(node['source'].encode()).hexdigest(),
            'value_sha256':entry.get('value_sha256'), 'expected':node['expected'],
            'observed_value':entry.get('value'),'evidence':entry.get('evidence'),
            'error':result['failures'].get('probe'),'elapsed_ms':result['elapsed_ms'],
            'fixture_sha256':_hash(node)}

def run_language_qualifications(*, authorized=False, workers=4, root=ROOT, include=None, include_registry=False):
    """Concurrent actual guest execution; no reuse of historical "success" labels."""
    if not authorized:raise BridgeError('Explicit approval required for executable matrix qualification')
    if type(workers) is not int or not 1<=workers<=8:raise ValueError('workers must be 1..8')
    fx=fixtures(root,include_registry=include_registry)
    selected=sorted(fx if include is None else include)
    if set(selected)-fx.keys():raise ValueError('No executable fixture for catalog family '+repr(sorted(set(selected)-fx.keys())))
    started=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers,thread_name_prefix='usl-nm-lang') as pool:
        futures={pool.submit(_one,lang,fx[lang],True):lang for lang in selected}
        rows={}
        for f in concurrent.futures.as_completed(futures):
            lang=futures[f]
            try:rows[lang]=f.result()
            except Exception as exc:rows[lang]={'language':lang,'status':'failed','error':str(exc)[:500],
                      'fixture_sha256':_hash(fx[lang]),'source_sha256':hashlib.sha256(fx[lang]['source'].encode()).hexdigest()}
    ids=[r['id'] for r in load_catalog()]
    catalog=[{'id':id_,'catalog_index':i,'status':
               'verified_executable_subset' if rows.get(id_,{}).get('status')=='verified' else
               'failed_executable_subset' if id_ in rows else 'not_yet_executable_qualified',
              'fixture_present':id_ in fx,'evidence_sha256':_hash(rows[id_]) if id_ in rows else None,
              'reason':None if id_ in rows else 'No approved executable guest source/adapter qualified for this catalog entry'}
             for i,id_ in enumerate(ids)]
    return {'schema':'usl.matrix.language_qualification.v1','total_entries':606,
       'attempted_real_execution':len(selected),'verified_exact_subsets':sum(x['status']=='verified' for x in rows.values()),
       'failed_real_execution':sum(x['status']!='verified' for x in rows.values()),
       'status_by_language':dict(sorted(rows.items())),'catalog':catalog,
       'runtime_platform':platform.platform(),'workers':workers,
       'elapsed_ms':round((time.perf_counter()-started)*1000,3),
       'qualifier':'real subprocess or native ABI output matched fixture, not full language completeness'}

def _fixture_oracle(lang, value):
    """Independent specification for the exact reviewed demo fixture subset.

    This does not claim arbitrary foreign-source equivalence; it is the oracle
    for the single source hash in the corresponding fixture.
    """
    if lang=='sed':
        if type(value) is not str:raise ValueError('Sed fixture oracle expects text')
        return value.replace('cat','dog')
    if type(value) is not int:raise ValueError('Numeric fixture oracle expects int')
    if lang in ('python','cpp'):return value*2
    if lang in ('javascript','sql','usl'):return value+1
    if lang in ('ruby','java','kotlin'):return value+3
    if lang=='php':return value-1
    if lang in ('go','typescript','fortran'):return value+2
    if lang in ('perl','bash'):return value+5
    if lang=='swift':return value+6
    if lang=='awk':return value+9
    if lang=='c':return value*value
    from .universal_adapters import load_registry
    if lang in load_registry():
        operation=load_registry()[lang]['operation']
        if operation['kind']=='add':return value+operation['constant']
    raise ValueError('No independent oracle for '+lang)

def pair_eligibility(host, guest, fx=None, installed=None):
    fx=fx or fixtures()
    if host not in fx or guest not in fx:return 'unverified'
    if installed is not None and (host not in installed or guest not in installed):return 'unverified'
    a,b=fx[host],fx[guest]
    if len(b['params'])!=1 or b['params'][0]!=a['returns']:
        return 'incompatible_declared_abi'
    return 'conditionally_routable'

def execute_pair(host, guest, *, authorized=False, workers=2, root=ROOT, include_registry=False):
    """Run actual two-language DAG, with guest arg bound to verified host output."""
    if not authorized:raise BridgeError('Explicit approval required for foreign/native pair execution')
    ids={x['id'] for x in load_catalog()}
    if (host not in ids and host!='usl') or (guest not in ids and guest!='usl'):raise ValueError('Unknown catalog id')
    fx=fixtures(root,include_registry=include_registry)
    state=pair_eligibility(host,guest,fx)
    if state!='conditionally_routable':return {'host':host,'guest':guest,'status':state,'verified':False}
    a={k:v for k,v in fx[host].items() if k!='expected'}
    b={k:v for k,v in fx[guest].items() if k!='expected'}
    # Independent fixture-specific oracle values become run_nested acceptance
    # gates. A guest that only returns the right TYPE is not enough.
    expected_host=_fixture_oracle(host,a['args'][0])
    expected_guest=_fixture_oracle(guest,expected_host)
    a['expected']=expected_host
    b['expected']=expected_guest
    b['args']=[{'ref':'host'}]
    doc={'schema':SCHEMA,'nodes':[{'id':'host',**a},{'id':'guest',**b}]}
    outcome=run_nested(doc,authorized=True,workers=workers)
    success=bool(outcome['all_verified'] and outcome['verified']==2)
    return {'host':host,'guest':guest,'status':'observed_success' if success else 'failed',
      'verified':success,'project_sha256':outcome['project_sha256'],
      'oracle_expected':{'host':expected_host,'guest':expected_guest},
      'actual_values':{k:v['value'] for k,v in outcome['results'].items()},
      'native_modes':{k:v['evidence'].get('mode') for k,v in outcome['results'].items()},
      'source_sha256':{k:v['source_sha256'] for k,v in outcome['results'].items()},
      'failures':outcome['failures'],'elapsed_ms':outcome['elapsed_ms']}

def run_pairs(pairs,*,authorized=False,workers=3,root=ROOT,include_registry=False):
    if not authorized:raise BridgeError('Explicit approval required for executable matrix probes')
    if type(workers) is not int or not 1<=workers<=8:raise ValueError('workers must be 1..8')
    pairs=list(pairs)
    if len(pairs)>606*606:raise ValueError('Too many pairs')
    if len(set(map(tuple,pairs)))!=len(pairs):raise ValueError('Duplicate pair')
    started=time.perf_counter();out=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers,thread_name_prefix='usl-nm-pair') as pool:
        fut={pool.submit(execute_pair,a,b,authorized=True,root=root,include_registry=include_registry):(a,b) for a,b in pairs}
        for f in concurrent.futures.as_completed(fut):
            a,b=fut[f]
            try:out.append(f.result())
            except Exception as exc:out.append({'host':a,'guest':b,'status':'failed','verified':False,'error':str(exc)[:500]})
    return {'schema':'usl.matrix.pair_probes.v1','probe_count':len(out),
       'actual_verified_pairs':sum(x.get('verified',False) for x in out),
       'elapsed_ms':round((time.perf_counter()-started)*1000,3),'workers':workers,
       'pairs':sorted(out,key=lambda x:(x['host'],x['guest']))}

def build_dense_matrix(*, language_evidence=None,pair_evidence=None,root=ROOT,include_registry=False):
    """606 x 606 executable table; sparse successes are individually evidence-backed."""
    catalog=load_catalog();ids=[r['id'] for r in catalog];index={k:i for i,k in enumerate(ids)}
    if len(ids)!=606 or len(index)!=606:raise ValueError('Catalog must contain exactly 606 distinct IDs')
    fx=fixtures(root,include_registry=include_registry);installed=set()
    if language_evidence:
        for k,entry in language_evidence['status_by_language'].items():
            if entry['status']=='verified':installed.add(k)
    else:
        installed={row['native_bridge_family'] for row in catalog_matrix()['entries'] if row['native_toolchain_present']}
        installed.add('usl')
    n=len(ids);grid=bytearray(n*n);conditional=0
    for a in installed&set(index):
        for b in installed&set(index):
            if pair_eligibility(a,b,fx)=='conditionally_routable':
                grid[index[a]*n+index[b]]=1;conditional+=1
    observed=[];external=[]
    if pair_evidence:
        for row in pair_evidence['pairs']:
            if row.get('verified'):
                a,b=row['host'],row['guest']
                evidence={'host':a,'guest':b,'execution_sha256':_hash(row),
                   'observed_values':row['actual_values'],'modes':row['native_modes']}
                if a not in index or b not in index:
                    if not ({a,b}-set(index)) <= {'usl'}:raise ValueError('Unexpected external catalog pair')
                    external.append(evidence);continue
                if grid[index[a]*n+index[b]]!=1:raise ValueError('Unverified/incompatible pair falsely claimed successful')
                grid[index[a]*n+index[b]]=2
                observed.append(evidence)
    return bytes(grid),{'schema':SCHEMA_NAME,'shape':[606,606], 'entry_order':ids,
      'cells':606*606,'encoding':'row-major unsigned byte; 0=unverified; 1=conditional not tested; 2=exact observed successful pair',
      'count_unverified':grid.count(0),'count_conditional_unverified':grid.count(1),
      'count_executed_verified':grid.count(2), 'observed_pairs':observed,
      'observed_pairs_with_external_usl_runtime':external,
      'no_inferred_native_equivalence':True,'matrix_sha256':hashlib.sha256(grid).hexdigest(),
      'execution_interface':'python -m usl_systems matrix-execute HOST GUEST --i-approve-native'}

def cell_value(grid, metadata, host, guest):
    order=metadata['entry_order'];i=order.index(host);j=order.index(guest)
    return ('unverified','conditional_not_executed','observed_verified')[grid[i*606+j]]
