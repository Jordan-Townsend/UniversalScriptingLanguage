"""Evidence-bound local subprocess observation and approved Python-project repair.

Projects are NOT sandboxed: Python tests can have real side effects. An operator must
approve both observation and commit on trusted code. No automatic replay of an
external command after a crash. This module observes only self-launched children.
"""
from __future__ import annotations
import re
import sys
import time
from .bridge import ProcessBridge
from .repairloop import RepairLoop,RepairError,_relpath,sha
from .repair_proposals import propose_syntax_repair

class ObserveError(RepairError):pass

class ObservedRepair:
    def __init__(self,store,bridge=None):
        self.store=store
        self.bridge=bridge or ProcessBridge(store)

    def _claim_observation(self,observation_id):
        """SQLite UNIQUE constraint makes consumption durable across processes."""
        with self.store.lock,self.store._db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS observed_repair_claims (id TEXT PRIMARY KEY, status TEXT NOT NULL, updated REAL NOT NULL)')
            try:
                db.execute('INSERT INTO observed_repair_claims VALUES(?,?,?)',(observation_id,'claimed',time.time()))
            except Exception as exc:
                # An already-claimed observation is not safe to replay after crashes.
                if db.execute('SELECT id FROM observed_repair_claims WHERE id=?',(observation_id,)).fetchone():
                    raise ObserveError('Observation already claimed; automatic replay prohibited') from exc
                raise

    def _mark_claim(self,observation_id,status):
        with self.store.lock,self.store._db() as db:
            db.execute('UPDATE observed_repair_claims SET status=?,updated=? WHERE id=?',
                       (status,time.time(),observation_id))

    def _wait(self,ident,seconds):
        deadline=time.monotonic()+seconds+5
        while time.monotonic()<deadline:
            row=self.bridge.detail(ident)
            if not row:raise ObserveError('Missing process record')
            if row['status'] not in ('starting','running','stopping'):
                return row
            time.sleep(.05)
        try:self.bridge.stop(ident)
        except Exception:pass
        raise ObserveError('Process observation deadline exceeded; no automatic replay')

    def observe(self,project,path,*,authorized=False,seconds=15):
        if authorized is not True:raise ObserveError('Explicit observation approval required')
        relative=_relpath(path)
        if not isinstance(seconds,int) or not 1<=seconds<=60:
            raise ObserveError('Observation timeout must be 1..60 seconds')
        file=self.store.safe_project_path(project,relative.as_posix())
        if file.is_symlink() or not file.is_file():
            raise ObserveError('Only an existing regular project Python file may be observed')
        before=sha(file.read_bytes())
        argv=[sys.executable,'-B','-m','py_compile',relative.as_posix()]
        child=self.bridge.launch(project,argv,max_seconds=seconds)
        evidence=self._wait(child['id'],seconds)
        if sha(file.read_bytes())!=before:
            raise ObserveError('Source changed during compiler observation')
        result={'schema':'usl.observe.repair.v1','project':project,'path':relative.as_posix(),
             'source_sha256':before,'observed_process_id':evidence['id'],
             'exit_code':evidence['exit_code'],'status':evidence['status'],
             'stdout_stderr_tail':evidence['output'],'timed_out':evidence['status']=='timed_out',
             'provenance':'actual monitored subprocess; Python py_compile'}
        if evidence['status']=='failed' and evidence['exit_code'] not in (None,0):
            try:
                proposal=propose_syntax_repair(self.store,project,relative.as_posix())
                # Cross-bind repair proposal to the observed on-disk revision.
                if proposal['source_sha256']!=before:
                    raise ObserveError('Proposal source hash differs from observed version')
                result['proposal']=proposal
            except RepairError as exc:result['unhandled_diagnostic']=str(exc)
        self.store.remember('repair_observation_'+evidence['id'],result)
        return result

    def approve_and_verify(self,observation_id,*,authorized=False,seconds=20):
        if authorized is not True:raise ObserveError('Explicit repair and retest approval required')
        if not isinstance(observation_id,str) or not re.fullmatch('[0-9a-f]{18}',observation_id):
            raise ObserveError('Invalid observation ID')
        observed=self.store.recall('repair_observation_'+observation_id)
        actual=self.bridge.detail(observation_id)
        if not observed or not actual or actual['status']!='failed' or actual['exit_code'] in (0,None):
            raise ObserveError('No verified failed process observation with this ID')
        if actual['project']!=observed['project'] or observed['observed_process_id']!=observation_id:
            raise ObserveError('Observation correlation mismatch')
        if time.time()-actual['started']>900:
            raise ObserveError('Observation expired; observe the current source again')
        if 'proposal' not in observed:raise ObserveError('No supported compiler-grounded proposal exists')
        proposal=observed['proposal']
        if proposal['status']!='proposal_only' or proposal['source_sha256']!=observed['source_sha256']:
            raise ObserveError('Unverified repair proposal')
        steps=proposal['plan']['steps']
        if len(steps)!=1:raise ObserveError('Only a single reviewed source edit is supported')
        step=steps[0]
        if step['project']!=observed['project'] or step['path']!=observed['path'] or step['original_sha256']!=observed['source_sha256']:
            raise ObserveError('Repair scope differs from observed failure')
        # Exactly-once gate for this observed failure; retain evidence across restarts.
        claim='repair_completed_'+observation_id
        if self.store.recall(claim) is not None:
            raise ObserveError('Observation already consumed; no implicit repair replay')
        file=self.store.safe_project_path(observed['project'],observed['path'])
        if sha(file.read_bytes())!=step['original_sha256']:
            raise ObserveError('Stale on-disk revision; observe again')
        self._claim_observation(observation_id)
        result=RepairLoop(self.store).run(observed['project'],step)
        finished={'observation_id':observation_id,'repair':result,'status':'repair_not_committed',
                 'verified_continuation':False}
        if result.get('status')=='completed' and result.get('verified'):
            # A new actual process, not merely a cached assertion from staged tests.
            argv=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test*.py']
            run=self.bridge.launch(observed['project'],argv,max_seconds=max(1,min(60,int(seconds))))
            check=self._wait(run['id'],seconds)
            finished['continuation']={'id':check['id'],'status':check['status'],
                   'exit_code':check['exit_code'],'stdout_stderr_tail':check['output'],
                   'source_sha256':sha(file.read_bytes())}
            # Note: the initial staged verification already required at least one test.
            good=check['status']=='completed' and check['exit_code']==0 and re.search(r'Ran [1-9][0-9]* tests?',check['output'])
            finished['verified_continuation']=bool(good)
            finished['status']='verified_completed' if good else 'postcheck_failed_needs_review'
        self.store.remember(claim,finished)
        self._mark_claim(observation_id,finished['status'])
        self.store.event('observed_repair',finished['status'],observation_id)
        return finished
