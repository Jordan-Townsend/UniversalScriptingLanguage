"""First-class support for ALL catalogued native source syntaxes.

Each of 606 catalog entries can be detected, recorded, packaged, and linked to
an explicit user-configured native toolchain. No fake transpilation or unsafe
implicit shell execution. Toolchain integration is opt-in and transparent.
"""
import fnmatch,json,os,subprocess,shutil
from pathlib import Path
from .catalog import load_catalog
from .store import Store
from .language import USLError

PREFERRED={
 'python':['{python}','{file}'],
 'javascript':['node','{file}'],
 'ruby':['ruby','{file}'],
 'php':['php','{file}'],
 'lua':['lua','{file}'],
 'powershell':['pwsh','-NoProfile','-File','{file}'],
 'bash':['bash','{file}'],
 'perl':['perl','{file}'],
 'r':['Rscript','{file}'],
}

def detect(path,legacy=None):
    name=Path(path).name
    hits=[]
    for row in load_catalog(legacy):
        if any(fnmatch.fnmatch(name,pattern) for pattern in row.get('extensions',[]) if pattern):
            hits.append({'id':row['id'],'name':row['name'],'mode':row['support']})
    return hits

class AdapterRegistry:
    def __init__(self,store=None):
        self.store=store or Store();self.path=self.store.root/'native_toolchains.json'
        self.catalog={x['id']:x for x in load_catalog()}
        self.adapters=json.loads(self.path.read_text(encoding='utf8')) if self.path.exists() else {}

    def canonical(self,language):
        lang=str(language).lower()
        for key,row in self.catalog.items():
            if lang==key or lang in (a.lower() for a in row['aliases']):return key
        raise USLError(f'Not a known catalog language/syntax: {language}')

    def info(self,language):
        key=self.canonical(language);row=self.catalog[key]
        return {**row,'native_command':self.adapters.get(key,{}).get('argv') or PREFERRED.get(key),
                'configured':key in self.adapters,'note':'Native source integration; independent of USL transpilation.'}

    def configure(self,language,argv):
        key=self.canonical(language)
        if not isinstance(argv,list) or not argv or len(argv)>24 or any(not isinstance(x,str) or not x or len(x)>350 for x in argv):
            raise USLError('Toolchain argv must be an array of 1-24 strings (no shell)')
        if '{file}' not in argv:raise USLError('Toolchain command must contain a standalone {file} argument')
        if any('{' in x and x!='{file}' and x!='{python}' for x in argv):raise USLError('Only {file}/{python} placeholders are allowed')
        self.adapters[key]={'argv':argv,'user_configured':True}
        self.path.write_text(json.dumps(self.adapters,indent=2),encoding='utf8')
        return {'language':key,'argv':argv}

    def run(self,language,source_path,allow=False,timeout=10):
        if not allow:raise USLError('Native source execution requires explicit allow_native_execute=True')
        i=self.info(language);argv=i['native_command']
        if not argv:raise USLError('No native toolchain command configured for '+i['id'])
        src=Path(source_path).resolve()
        if not src.is_file():raise FileNotFoundError(src)
        import sys
        cmd=[sys.executable if part=='{python}' else str(src) if part=='{file}' else part for part in argv]
        if not shutil.which(cmd[0]):raise USLError('Executable not on PATH: '+cmd[0])
        try:
            result=subprocess.run(cmd,shell=False,cwd=src.parent,text=True,capture_output=True,
                timeout=max(1,min(60,int(timeout))),check=False)
            return {'language':i['id'],'status':'success' if result.returncode==0 else 'failure',
                    'exit_code':result.returncode,'stdout':result.stdout[-25000:],'stderr':result.stderr[-25000:],
                    'argv_executed':cmd}
        except subprocess.TimeoutExpired:
            return {'language':i['id'],'status':'timeout','timeout_seconds':timeout,'argv_executed':cmd}
