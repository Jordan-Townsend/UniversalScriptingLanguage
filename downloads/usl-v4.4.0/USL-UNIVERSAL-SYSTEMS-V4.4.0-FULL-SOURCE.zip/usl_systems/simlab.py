"""Deterministic numerical experimentation foundation. No speculative materials claims."""
from __future__ import annotations
import math
from .language import USLError


def rk4_step(f, t, state, dt):
    def add(x,k,c):return tuple(a+c*b for a,b in zip(x,k))
    a=f(t,state)
    b=f(t+dt/2,add(state,a,dt/2))
    c=f(t+dt/2,add(state,b,dt/2))
    d=f(t+dt,add(state,c,dt))
    return tuple(v+(dt/6)*(i+2*j+2*k+l) for v,i,j,k,l in zip(state,a,b,c,d))


def simulate_decay(initial=1.0,rate=0.5,seconds=10.0,steps=200):
    """Solve dy/dt=-k*y, and compare with an analytic reference."""
    vals=(float(initial),float(rate),float(seconds))
    if not all(math.isfinite(x) for x in vals):raise USLError('Parameters must be finite')
    if rate<0 or seconds<0 or int(steps)!=steps or not 1<=steps<=100000:raise USLError('Invalid rate/time/step count')
    dt=seconds/int(steps)
    state=(initial,)
    for i in range(int(steps)):
        state=rk4_step(lambda t,v:(-rate*v[0],),i*dt,state,dt)
        if not math.isfinite(state[0]):raise USLError('Numerical instability')
    exact=initial*math.exp(-rate*seconds)
    return {'model':'first_order_decay','solver':'RK4','final_value':state[0],
            'analytic_reference':exact,'absolute_error':abs(state[0]-exact),
            'steps':steps,'seconds':seconds,'verified_against_analytic_solution':True}


def simulate_damper(mass=1.0,spring=10.0,damping=0.8,initial_x=1.0,initial_v=0.0,seconds=10.0,steps=400):
    """Mass-spring-damper m*x''+c*x'+k*x=0; outputs numerical trajectory.
    This is a mathematical baseline, not a prediction for an uncharacterized material.
    """
    pars=[float(x) for x in (mass,spring,damping,initial_x,initial_v,seconds)]
    if not all(math.isfinite(x) for x in pars):raise USLError('Parameters must be finite')
    mass,spring,damping,initial_x,initial_v,seconds=pars
    if mass<=0 or spring<0 or damping<0 or seconds<0 or int(steps)!=steps or not 1<=steps<=100000:raise USLError('Invalid mechanical parameters')
    dt=seconds/steps;state=(initial_x,initial_v)
    trace=[];max_energy=0
    def f(t,s):return (s[1],(-spring*s[0]-damping*s[1])/mass)
    stride=max(1,steps//150)
    for i in range(steps+1):
        t=i*dt
        energy=(spring*state[0]**2+mass*state[1]**2)/2
        if not all(math.isfinite(x) for x in (*state,energy)):raise USLError('Numerical instability')
        max_energy=max(max_energy,energy)
        if i%stride==0 or i==steps:
            trace.append({'seconds':round(t,6),'position_m':state[0],'velocity_m_s':state[1],'energy_j':energy})
        if i<steps:state=rk4_step(f,t,state,dt)
    return {'model':'linear_mass_spring_damper','solver':'RK4','parameters':{'mass_kg':mass,'spring_n_per_m':spring,'damping_n_s_per_m':damping},
            'final_position_m':state[0],'final_velocity_m_s':state[1],
            'max_energy_j':max_energy,'trace':trace,
            'limitations':'Illustrative idealized 1D linear dynamics; no CAD, finite-element mesh or material measurement.'}
