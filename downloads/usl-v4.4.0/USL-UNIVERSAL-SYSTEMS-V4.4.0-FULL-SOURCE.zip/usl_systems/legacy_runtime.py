"""Reproducible recovered-source staging and explicit, bounded local service adapters.

This is not a security sandbox. It will never execute recovered code merely by
staging a ZIP or probing its presence. Native compilation requires explicit opt-in.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

SOURCE_DIR = Path(__file__).resolve().parents[1] / 'legacy_sources'
SOURCES = {
    'usl_v031': ('USL-V031-WINDOWS-REGRESSION-REPAIR.zip', 'cd26208bb16ea949eb3191b1192a0f3ba454dc39fd10de650a46c274296bd89c', 'master/usl.py'),
    'bridge_v3': ('USL-CHROME-BRIDGE-AUTONOMOUS-V3.0.0.zip', '01277c4a9a6858103b706651f2c253dc490c55e64f41b5dea513c72287aff48c', 'bridge.py'),
    'bridge_v221': ('USL-CHROME-BRIDGE-STABLE-V2.2.1.zip', '2160d6da138329de98e64b625ca2536463c01bc3482cf55f43d18bff755e1681', 'bridge.py'),
    'shadow_v87': ('USL_SHADOW_DEVELOPMENT_STUDIO_V87_NATURAL_CONVERSATION_OS_FULL.zip', '20c704fef2009a7a8f064f22a63aeb98775cdb32fef62c19380bf24904138335', 'studio/providers.py'),
    'emovision_v63': ('EmoVision_Fabric_V63_NM_FRACTAL_DEVELOPMENT.zip', '5ff96c9fa342092b28cca4c62b122861069dd9dd5009e374ca2d4625bdbf693c', 'emovision_fabric/server.py'),
    'meta_v53': ('SHADOW-META-USL-X-V53-SINGLE-FLAT-SDK-REPAIR.zip', '43d4d3a6cb1dac325995668ef017a315b9006d55a7fcf1d5f484069bab40ddd9', 'app/src/main/java/com/emovision/glasses/MainActivity.kt'),
}

class LegacyError(ValueError):
    pass


def _hash(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def bundled_sources():
    result = {}
    for name, (archive, expected, marker) in SOURCES.items():
        path = SOURCE_DIR / archive
        present = path.is_file()
        digest = _hash(path) if present else None
        result[name] = {'archive':archive, 'available':present, 'sha256_matches':digest == expected,
                        'bytes':path.stat().st_size if present else 0, 'marker':marker}
    return result


def _safe_members(z):
    if len(z.infolist()) > 4000:raise LegacyError('Too many ZIP members')
    total=0; found=set()
    for entry in z.infolist():
        n=entry.filename.replace('\\','/')
        p=PurePosixPath(n)
        if n.startswith('/') or n.startswith('//') or ':' in n.split('/')[0] or any(x in ('..', '') for x in p.parts):
            raise LegacyError('Unsafe archive pathname: '+n)
        # Upstream EmoVision bundles three captured Windows drive paths inside
        # the ZIP. Never normalize them into the filesystem: skip these runtime
        # state snapshots while retaining the canonical source archive intact.
        if n.startswith('\\') or '\\' in entry.filename:continue
        if stat.S_ISLNK(entry.external_attr >> 16):raise LegacyError('Symlinks cannot be imported')
        if not p.parts:continue
        key=p.as_posix().casefold()
        if key in found:raise LegacyError('Case-insensitive duplicate: '+n)
        found.add(key)
        if entry.file_size > 32*1024*1024:raise LegacyError('Oversized ZIP member')
        total+=entry.file_size
        if total > 150*1024*1024:raise LegacyError('Excessive uncompressed archive size')
        yield entry,p


def stage_component(name, data_dir, force=False):
    """Copy recovered source into isolated local persistent state; never execute it."""
    if name not in SOURCES:raise LegacyError('Unknown recovered component')
    archive, digest, marker=SOURCES[name]
    src=SOURCE_DIR/archive
    if not src.is_file():raise LegacyError('Source archive missing: '+archive)
    if _hash(src)!=digest:raise LegacyError('Archive SHA-256 mismatch: '+archive)
    root=Path(data_dir).expanduser().resolve()/'legacy_components'
    root.mkdir(parents=True,exist_ok=True)
    final=root/name
    if final.exists() and not force:
        check=final/'STAGED_SOURCE.json'
        if check.is_file():
            manifest=json.loads(check.read_text(encoding='utf8'))
            if manifest.get('sha256')==digest:
                # Staged entry may have been locally edited; do not silently trust it.
                try:component_root(name,data_dir)
                except LegacyError:raise LegacyError('Staged entry changed; original archive is still intact')
                return {'component':name, 'path':str(final), 'status':'already-staged', 'sha256':digest}
        raise LegacyError('Existing staged component differs; refuse overwrite')
    with tempfile.TemporaryDirectory(prefix='usl-stage-',dir=root) as temp:
        staging=Path(temp)/'source';staging.mkdir()
        with zipfile.ZipFile(src) as z:
            members=list(_safe_members(z))
            # Store original tree exactly, including any upstream top-level directory.
            for entry,p in members:
                dst=staging.joinpath(*p.parts)
                if entry.is_dir():dst.mkdir(parents=True,exist_ok=True);continue
                dst.parent.mkdir(parents=True,exist_ok=True)
                with z.open(entry) as read, dst.open('wb') as out:
                    shutil.copyfileobj(read,out,length=1024*1024)
        hits=list(staging.rglob(marker))
        if len(hits)!=1:raise LegacyError('Expected unique source entry absent after extraction: '+marker)
        (staging/'STAGED_SOURCE.json').write_text(json.dumps({'component':name,'source_archive':archive,'sha256':digest,'executed':False,
            'original_paths_preserved':True, 'marker':marker, 'entry_sha256':_hash(hits[0]),'extracted_members':len(members)},indent=2),encoding='utf8')
        if final.exists():
            if not force:raise LegacyError('Existing stage; refuse overwrite')
            # Never destroy local edits: rotate to a deterministic backup name.
            backup=root/(name+'.backup')
            if backup.exists():raise LegacyError('Existing backup prevents replacing staged files')
            final.rename(backup)
        staging.rename(final)
    return {'component':name,'path':str(final),'status':'staged','sha256':digest}


def component_root(name, data_dir):
    base=Path(data_dir).expanduser().resolve()/'legacy_components'/name
    if not (base/'STAGED_SOURCE.json').is_file():raise LegacyError('Run legacy-stage first for '+name)
    expected=SOURCES[name][1]
    if json.loads((base/'STAGED_SOURCE.json').read_text()).get('sha256') != expected:
        raise LegacyError('Staged source manifest mismatch')
    hits=list(base.rglob(SOURCES[name][2]))
    if len(hits)!=1:raise LegacyError('Ambiguous component source path')
    manifest=json.loads((base/'STAGED_SOURCE.json').read_text())
    if not manifest.get('entry_sha256') or _hash(hits[0]) != manifest['entry_sha256']:
        raise LegacyError('Source entry modified after verified staging')
    marker=Path(SOURCES[name][2])
    return hits[0].parents[len(marker.parts)-1]


def _safe_local_service(url, path, token=None, timeout=2):
    from urllib.parse import urlsplit
    parsed=urlsplit(url)
    if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or parsed.username or parsed.password or parsed.path not in ('','/'):
        raise LegacyError('Only literal 127.0.0.1 HTTP base URLs are allowed')
    if parsed.port is None or parsed.port<1024 or parsed.port>65535:raise LegacyError('Invalid local port')
    req=urllib.request.Request(url.rstrip('/')+path,headers={'Accept':'application/json',**({'Authorization':'Bearer '+token} if token else {})})
    try:
        with urllib.request.urlopen(req,timeout=min(5,max(.2,float(timeout)))) as response:
            content=response.read(65537)
            if len(content)>65536:raise LegacyError('Remote response exceeds size limit')
            return json.loads(content)
    except (urllib.error.URLError,TimeoutError,OSError,ValueError) as exc:
        raise LegacyError(type(exc).__name__+': '+str(exc)[:180]) from exc


def bridge_status(data_dir=None,url='http://127.0.0.1:8766'):
    """Genuine V3 authenticated service handshake; excludes token from output."""
    token=os.environ.get('USL_BRIDGE_TOKEN','').strip()
    if not token:
        folder=Path(os.environ.get('USL_BRIDGE_DATA',str(Path.home()/'USL_Chrome_Bridge_Data')))
        token_file=folder/'pairing_token.txt'
        if token_file.is_file():token=token_file.read_text(encoding='utf8').strip()
    if not token:raise LegacyError('Bridge pairing token unavailable; pair Chrome Bridge first')
    obj=_safe_local_service(url,'/api/status',token=token)
    if obj.get('ok') is not True:raise LegacyError('Bridge returned unsuccessful status')
    return {'component':'bridge_v3','authenticated':True,'live':obj.get('live'),
            'controller_paused':obj.get('controller_paused'),'active_job':obj.get('active_job'),
            'automation':{k:v for k,v in (obj.get('automation') or {}).items() if k in ('active','phase','updated_at','error')},
            'extension':{k:v for k,v in (obj.get('extension') or {}).items() if k in ('enabled','last_seen','tab_last_seen')},
            'connected':True}


def bridge_latest_report(url='http://127.0.0.1:8766'):
    """Observe the real V3 outbox without acknowledging, launching, or mutating it.

    A successful HTTP handshake is not evidence a browser task succeeded. The
    returned snapshot keeps the report's source status separate from connection.
    """
    token=os.environ.get('USL_BRIDGE_TOKEN','').strip()
    if not token:
        folder=Path(os.environ.get('USL_BRIDGE_DATA',str(Path.home()/'USL_Chrome_Bridge_Data')))
        token_file=folder/'pairing_token.txt'
        if token_file.is_file():token=token_file.read_text(encoding='utf8').strip()
    if not token:raise LegacyError('Bridge pairing token unavailable')
    payload=_safe_local_service(url,'/api/latest',token=token)
    if not isinstance(payload,dict) or payload.get('ok') is not True:
        raise LegacyError('Bridge latest-report endpoint did not confirm success')
    report=payload.get('report')
    if report is None:
        return {'component':'bridge_v3','connected':True,'status':'no_report','report':None,'verified_task':False}
    if not isinstance(report,dict):raise LegacyError('Unexpected bridge report format')
    # Only minimal metadata; browser outputs may contain secrets or user data.
    allowed=('id','status','created_at','updated_at','job','verified','success','completed')
    summary={k:v for k,v in report.items() if k in allowed and type(v) in (str,int,float,bool)}
    summary={k:v[:128] if type(v) is str else v for k,v in summary.items()}
    status=summary.get('status','unknown')
    # Recovered V3's report is id/text/status/at; real independent acceptance
    # evidence is /api/status.completed plus the corresponding finished job.
    state=_safe_local_service(url,'/api/status',token=token)
    jobs=state.get('jobs',[])
    auto=state.get('automation',{})
    verified=(state.get('ok') is True and state.get('completed') is True
              and isinstance(auto,dict) and auto.get('phase') == 'verified'
              and isinstance(jobs,list)
              and any(isinstance(job,dict) and str(job.get('id'))==str(report.get('id'))
                      and job.get('status')=='finished' for job in jobs))
    return {'component':'bridge_v3','connected':True,'status':'completed',
            'report':summary,'verified_task':bool(verified),'upstream_status':status}


def shadow_health(url='http://127.0.0.1:8767',allow_unauthenticated=False):
    # V87 SDK has no authentication, so never query it implicitly.
    if not allow_unauthenticated:raise LegacyError('Shadow V87 SDK unauthenticated; explicit opt-in required')
    obj=_safe_local_service(url,'/health')
    return {'component':'shadow_v87','connected':bool(obj.get('ok')),'sdk_running':bool((obj.get('sdk') or {}).get('running')),
            'provider_available':bool((obj.get('provider') or {}).get('available'))}


def emovision_health(url='http://127.0.0.1:8774',allow_unauthenticated=False):
    if not allow_unauthenticated:raise LegacyError('EmoVision V63 API unauthenticated; explicit opt-in required')
    obj=_safe_local_service(url,'/health')
    return {'component':'emovision_v63','connected':isinstance(obj,dict),'health_reachable':True}


def native_v031_run(source_file, data_dir, runarg=None, timeout=25, allow=False):
    """Compile trusted V0.31 typed USL source with recovered native compiler.

    The v0.31 compiler generates a native executable. This is NOT a sandbox.
    """
    if not allow:raise LegacyError('Explicit --i-allow-native is required')
    if not shutil.which('gcc'):raise LegacyError('gcc is needed to compile v0.31 source')
    root=component_root('usl_v031',data_dir)
    compiler=root/'master'/'usl.py'
    source=Path(source_file).resolve()
    if not source.is_file() or source.stat().st_size>131072 or source.suffix.lower()!='.usl':
        raise LegacyError('Input must be a small existing .usl file')
    # Keep all emitted objects and caches confined to a temporary directory.
    timeout=max(1,min(120,int(timeout)))
    with tempfile.TemporaryDirectory(prefix='usl-v031-',dir=Path(data_dir).expanduser().resolve()) as temp:
        wd=Path(temp); exe=wd/('native.exe' if os.name=='nt' else 'native')
        cmd=[sys.executable,str(compiler),str(source),'--cache',str(wd/'cache'),'-o',str(exe)]
        try:build=subprocess.run(cmd,cwd=wd,capture_output=True,text=True,timeout=timeout)
        except subprocess.TimeoutExpired: return {'status':'timeout','phase':'compile','verified':False}
        if build.returncode:
            return {'status':'compile_failed','returncode':build.returncode,'stderr':build.stderr[-5000:], 'stdout':build.stdout[-10000:],'verified':False}
        result={'status':'compiled','compiler':'usl_v031','build':build.stdout[-12000:], 'verified':exe.exists()}
        if runarg is not None:
            try:run=subprocess.run([str(exe),str(int(runarg))],cwd=wd,capture_output=True,text=True,timeout=timeout)
            except subprocess.TimeoutExpired:return {**result,'status':'timeout','phase':'execute','verified':False}
            result.update({'status':'executed','exit_code':run.returncode,'stdout':run.stdout[-5000:], 'stderr':run.stderr[-5000:]})
        return result


def run_bridge_v3(data_dir,port=8766,allow=False):
    """Run the actual recovered browser bridge in the foreground; Ctrl+C stops."""
    if not allow:raise LegacyError('Explicit --i-allow-launch required')
    port=int(port)
    if port<1024 or port>65535:raise LegacyError('Invalid listening port')
    root=component_root('bridge_v3',data_dir)
    env=os.environ.copy()
    # Historical pairing and config survive upgrades; avoid replacing old data.
    env.setdefault('USL_BRIDGE_DATA',str(Path.home()/'USL_Chrome_Bridge_Data'))
    env.setdefault('USL_OPEN_DASHBOARD','0')
    return subprocess.call([sys.executable,str(root/'bridge.py'),'--port',str(port)],cwd=root,env=env)
