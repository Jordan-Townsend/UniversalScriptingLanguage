"""Bounded structural type parser for the JSON USL bridge ABI.

Canonical text specs: i64, bool, text, null, i64[], optional<T>,
list<T>, record{field:T,...}. These contracts are structural and explicitly
limited. No ability to execute embedded arbitrary type expressions.
"""
from __future__ import annotations
from functools import lru_cache
import json,re
class ABITypeError(ValueError):pass
IDENT=re.compile(r'[A-Za-z][A-Za-z0-9_]{0,60}')
PRIMITIVES={'i64','bool','text','null','i64[]'}
@lru_cache(maxsize=256)
def parse_spec(spec):
    if not isinstance(spec,str) or len(spec)>180 or not spec or any(c.isspace() for c in spec):
        raise ABITypeError('Invalid ABI type expression')
    p=0
    def take(token):
        nonlocal p
        if not spec.startswith(token,p):raise ABITypeError('Malformed ABI type '+repr(spec))
        p+=len(token)
    def word():
        nonlocal p
        m=IDENT.match(spec,p)
        if not m:raise ABITypeError('Invalid ABI identifier')
        p=m.end();return m.group()
    def parse(depth):
        nonlocal p
        if depth>5:raise ABITypeError('ABI type nesting too deep')
        name=word()
        if name=='i64' and spec.startswith('[]',p):take('[]');return ('i64[]',)
        if name in PRIMITIVES:return (name,)
        if name in ('optional','list'):
            take('<');child=parse(depth+1);take('>');return (name,child)
        if name=='record':
            take('{');fields=[]
            while True:
                if len(fields)>=16:raise ABITypeError('ABI record field count exceeds 16')
                label=word();take(':')
                if any(x[0]==label for x in fields):raise ABITypeError('Duplicate ABI record field')
                fields.append((label,parse(depth+1)))
                if p<len(spec) and spec[p]==',':take(',');continue
                break
            take('}')
            return ('record',tuple(fields))
        raise ABITypeError('Unsupported ABI type '+repr(name))
    result=parse(0)
    if p!=len(spec):raise ABITypeError('Trailing ABI type bytes')
    return result

def validate(value,spec):
    tree=parse_spec(spec)
    try:payload=json.dumps(value,ensure_ascii=False,allow_nan=False,default=lambda o:(_ for _ in ()).throw(TypeError())).encode('utf8')
    except (TypeError,ValueError) as exc:raise ABITypeError('ABI value not JSON encodable') from exc
    if len(payload)>65536:raise ABITypeError('ABI value exceeds 64 KB')
    def check(v,t,depth):
        if depth>6:raise ABITypeError('ABI value nesting too deep')
        tag=t[0]
        if tag=='i64':
            if type(v) is not int or not -(1<<63)<=v<1<<63:raise ABITypeError('i64 requires signed 64-bit integer')
        elif tag=='bool':
            if type(v) is not bool:raise ABITypeError('Expected bool')
        elif tag=='text':
            if type(v) is not str or len(v.encode('utf8'))>32000:raise ABITypeError('Expected <=32 KB Unicode text')
        elif tag=='null':
            if v is not None:raise ABITypeError('Expected explicit null')
        elif tag=='i64[]':
            if type(v) is not list or len(v)>1024:raise ABITypeError('Expected bounded i64 array')
            for part in v:check(part,('i64',),depth+1)
        elif tag=='optional':
            if v is not None:check(v,t[1],depth+1)
        elif tag=='list':
            if type(v) is not list or len(v)>1024:raise ABITypeError('Expected bounded list')
            for part in v:check(part,t[1],depth+1)
        elif tag=='record':
            if type(v) is not dict:raise ABITypeError('Expected record object')
            fields=t[1]
            if set(v)!=set(x[0] for x in fields):raise ABITypeError('Record fields do not match declared ABI')
            for name,typ in fields:check(v[name],typ,depth+1)
        else:raise ABITypeError('Unrecognized ABI contract')
    check(value,tree,0)
    return value
