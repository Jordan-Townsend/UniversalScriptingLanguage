"""Native, evidence-driven compiler conformance and complete catalog coverage report."""
from __future__ import annotations
import json
import time
from collections import Counter
from .catalog import load_catalog
from .compiler import TARGETS, target_name
from .native import verify,tool_available
from .syntax_validation import VALIDATORS
from .native_syntax import CAPABILITIES as NATIVE_VALIDATORS, available as native_validator_availability

# Independent scenarios exercise language behavior, not just syntactic emission.
SAMPLES={
 'arithmetic':'let a = 9\nlet b = 4\nprint(a+b*3)',
 'loop':'let total = 0\nfor i in range(5):\n    total += i\nprint(total)',
 'branch':'let x = 5\nif x > 3:\n    print("large")\nelse:\n    print("small")',
 'function':'function twice(x):\n    return x * 2\nprint(twice(21))',
 'while':'let x = 0\nwhile x < 3:\n    x += 1\nprint(x)',
}

def profiles(legacy=None):
    rows=load_catalog(legacy)
    native_availability=native_validator_availability()
    for row in rows:
        backend=target_name(row['id'])
        t=TARGETS.get(backend)
        yield {'id':row['id'],'name':row['name'],'aliases':row['aliases'],
               'catalogued':True,'built_in_semantic_backend':bool(t),
               'native_toolchain_detected':tool_available(backend) if t else False,
               'support_level':'restricted_emitter' if t else 'syntax_recognition_only',
               'complete_semantic_compiler':False,
               'validation':'run qualification suite for the installed backend' if t else 'backend and target-specific conformance required',
               'legacy_template':row.get('legacy_template',False),
               'parser_backed_syntax_validation':row['id'] in VALIDATORS,
               'syntax_parser':VALIDATORS.get(row['id']),
               'native_syntax_or_typecheck_available':row['id'] in NATIVE_VALIDATORS and native_availability[row['id']]['installed'],
               'native_frontend_qualification_claim':native_availability[row['id']]['claim'] if row['id'] in NATIVE_VALIDATORS else None}

def qualification_report(targets=None,timeout=7,include_catalog=True):
    if targets is None:targets=list(TARGETS)
    selected=[]
    for lang in targets:
        key=target_name(lang)
        if key not in TARGETS:raise ValueError(f'No built-in compiler backend: {lang}')
        if key not in selected:selected.append(key)
    outcomes={}
    for lang in selected:
        installed=tool_available(lang)
        cases={}
        for name,source in SAMPLES.items():
            if not installed:
                cases[name]={'status':'toolchain_missing'}
                continue
            t0=time.monotonic()
            result=verify(source,lang,timeout=timeout)
            cases[name]={'status':result['status'], 'elapsed_ms':round((time.monotonic()-t0)*1000,2)}
            if result['status'] not in ('passed','toolchain_missing','unsupported_construct'):
                cases[name]['error']=(result.get('error') or result.get('build',{}).get('stderr') or result.get('native',{}).get('stderr') or '')[-1200:]
        outcomes[lang]={'toolchain_installed':installed,'cases':cases,
                        'passed':sum(v['status']=='passed' for v in cases.values()),
                        'total':len(cases),
                        'all_cases_passed':all(v['status']=='passed' for v in cases.values())}
    result={'schema':'usl.compiler_qualification','version':1,
            'definitions':{'catalogue':'syntax recognition not compilation',
                'built_in_emitter':'restricted USL subset code generator, not a complete target language compiler',
                'native_pass':'output equals USL interpreter on a specific test input'},
            'catalog_count':len(load_catalog()),'built_in_emitter_count':len(TARGETS),
            'qualification':outcomes,
            'complete_semantic_compilers_proven':0,
            'all_catalogued_languages_compiled':False}
    if include_catalog:result['all_syntax_profiles']=list(profiles())
    return result
