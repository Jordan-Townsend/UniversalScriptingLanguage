"""Bounded separate native grammar process, preserving node spans and kinds."""
import json,sys

if __name__=='__main__':
    try:
        import tree_sitter_language_pack as pack
        request=json.loads(sys.stdin.buffer.read(65537))
        tree=pack.get_parser(request['grammar']).parse(request['source'].encode())
        root=tree.root_node
        if root.has_error:raise ValueError('native AST contains error or missing nodes')
        stack=[root];nodes=[]
        while stack:
            node=stack.pop()
            nodes.append({'kind':node.type,'start':node.start_byte,'end':node.end_byte,'named':node.is_named})
            if len(nodes)>6000:raise ValueError('AST node budget exceeded')
            stack.extend(reversed(node.children))
        raw=json.dumps({'root':root.type,'nodes':nodes,'source_map':'UTF-8 byte ranges'}).encode()
        if len(raw)>524288:raise ValueError('AST JSON budget exceeded')
        sys.stdout.buffer.write(raw)
    except Exception as exc:sys.stderr.write(type(exc).__name__+': '+str(exc));sys.exit(1)
