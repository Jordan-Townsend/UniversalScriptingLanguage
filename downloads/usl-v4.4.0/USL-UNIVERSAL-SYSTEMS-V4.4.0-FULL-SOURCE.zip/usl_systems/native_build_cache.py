"""Exact content-addressed native artifact cache, separate from execution cache.

Only successful compiler output can be stored. Cache reads verify SHA-256 and
source/toolchain/ABI build metadata. A hit skips rebuilding but **always reruns**
the authorized guest, verifying the live output; cached guest source is not
proof of semantic correctness. Caching is not a security sandbox.
"""
from __future__ import annotations
from contextlib import contextmanager
import hashlib,json,os,platform,shutil,sys,tempfile,time
from pathlib import Path

SCHEMA='usl.native.build.cache.v1'
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')

class BuildCache:
    def __init__(self,root=None):
        if root is None:
            var=os.environ.get('USL_NATIVE_CACHE_ROOT')
            if var:root=Path(var)
            else:
                from .store import Store
                root=Store().root/'native_build_cache'
        self.root=Path(root).expanduser().resolve()
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
    def fingerprint(self,language,source,generated,tools,flags=()):
        binaries=[]
        for name in tools:
            p=shutil.which(name)
            if not p:raise ValueError('Native toolchain missing: '+name)
            stat=Path(p).stat()
            binaries.append({'program':name,'path':str(Path(p).resolve()),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns})
        meta={'schema':SCHEMA,'language':language,'source_sha256':sha(source.encode('utf8')),
              'generated_sha256':sha(generated.encode('utf8')),
              'tools':binaries,'flags':list(flags),'platform':platform.platform(),
              'python_abi':f'{sys.version_info.major}.{sys.version_info.minor}'}
        return sha(canonical(meta)),meta
    def entry(self,key):
        if not isinstance(key,str) or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):raise ValueError('Invalid artifact hash')
        return self.root/key[:2]/key
    @contextmanager
    def _lock(self,key):
        p=self.root/'locks';p.mkdir(parents=True,exist_ok=True)
        path=p/(key+'.lock')
        fd=os.open(path,os.O_CREAT|os.O_RDWR,0o600)
        try:
            if os.name=='nt':
                import msvcrt
                os.write(fd,b'\0');os.lseek(fd,0,os.SEEK_SET)
                msvcrt.locking(fd,msvcrt.LK_LOCK,1)
            else:
                import fcntl
                fcntl.flock(fd,fcntl.LOCK_EX)
            yield
        finally:
            try:
                if os.name=='nt':
                    os.lseek(fd,0,os.SEEK_SET);msvcrt.locking(fd,msvcrt.LK_UNLCK,1)
                else:fcntl.flock(fd,fcntl.LOCK_UN)
            finally:os.close(fd)
    def _restore_locked(self,key,meta,out):
        e=self.entry(key)
        artifact=e/'artifact.bin';mfile=e/'manifest.json'
        if not artifact.is_file() or not mfile.is_file() or artifact.is_symlink() or mfile.is_symlink():return False
        try:
            manifest=json.loads(mfile.read_text('utf8'))
            if manifest.get('schema')!=SCHEMA or manifest.get('key')!=key or manifest.get('meta')!=meta:return False
            data=artifact.read_bytes()
            if not data or len(data)>25_000_000 or manifest.get('sha256')!=sha(data):return False
            out.parent.mkdir(parents=True,exist_ok=True)
            out.write_bytes(data)
            out.chmod(out.stat().st_mode | 0o100)
            return sha(out.read_bytes())==manifest['sha256']
        except (OSError,ValueError,TypeError):return False
    def restore(self,key,meta,out):
        with self._lock(key):return self._restore_locked(key,meta,Path(out))
    def store(self,key,meta,artifact):
        artifact=Path(artifact)
        data=artifact.read_bytes()
        if not 0<len(data)<=25_000_000:raise ValueError('Native artifact exceeds 25 MB or is empty')
        e=self.entry(key)
        with self._lock(key):
            e.mkdir(parents=True,exist_ok=True,mode=0o700)
            with tempfile.NamedTemporaryFile(dir=e,prefix='.partial-',delete=False) as f:
                temp=Path(f.name);f.write(data);f.flush();os.fsync(f.fileno())
            os.replace(temp,e/'artifact.bin')
            doc={'schema':SCHEMA,'key':key,'meta':meta,'sha256':sha(data),'bytes':len(data)}
            with tempfile.NamedTemporaryFile(dir=e,mode='w',encoding='utf8',prefix='.manifest-',delete=False) as f:
                mf=Path(f.name);json.dump(doc,f,sort_keys=True);f.flush();os.fsync(f.fileno())
            os.replace(mf,e/'manifest.json')
        return key

def verified_build(cache,language,source,generated,toolchains,flags,output,build_fn):
    started=time.perf_counter()
    key,meta=cache.fingerprint(language,source,generated,toolchains,flags)
    if cache.restore(key,meta,output):
        return {'exit_code':0,'stdout':'','stderr':'','command_program':'verified-build-cache',
                'duration_ms':round((time.perf_counter()-started)*1000,3),
                'cache_hit':True,'cache_key':key}
    build=build_fn()
    build['cache_hit']=False;build['cache_key']=key
    if build.get('exit_code')==0 and Path(output).is_file():cache.store(key,meta,output)
    return build
