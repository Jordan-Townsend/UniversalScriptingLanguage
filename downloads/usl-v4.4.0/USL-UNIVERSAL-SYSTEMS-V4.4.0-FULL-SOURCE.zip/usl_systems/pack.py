"""Reproducible hash-checked USL project packaging."""
import json,zipfile,hashlib
from pathlib import Path

def package(project_root,output):
    root=Path(project_root).resolve();dest=Path(output)
    if not root.is_dir():raise FileNotFoundError(root)
    files=[p for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and p.resolve()!=dest.resolve()]
    manifest={'format':'uslpack-1','files':{},'purpose':'project artifacts; no automatic code execution during unpack'}
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:
            rel=p.relative_to(root).as_posix()
            if '..' in Path(rel).parts:raise ValueError('Unsafe path')
            content=p.read_bytes()
            manifest['files'][rel]={'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)}
            z.writestr(rel,content)
        z.writestr('USLPACK_MANIFEST.json',json.dumps(manifest,indent=2))
    return manifest

def verify_package(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist();m=json.loads(z.read('USLPACK_MANIFEST.json'))
        if len(names)!=len(set(names)):raise ValueError('Duplicate archive entries')
        if set(names)!=(set(m['files'])|{'USLPACK_MANIFEST.json'}):raise ValueError('Manifest does not match archive entries')
        for name,meta in m['files'].items():
            if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Unsafe archive path')
            if hashlib.sha256(z.read(name)).hexdigest()!=meta['sha256']:raise ValueError('Hash mismatch: '+name)
    return {'verified':True,'files':len(m['files'])}
