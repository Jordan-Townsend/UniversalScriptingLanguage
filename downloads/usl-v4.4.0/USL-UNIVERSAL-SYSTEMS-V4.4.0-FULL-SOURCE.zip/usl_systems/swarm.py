"""Real bounded sequential agent-role pipeline through a local model.

The roles are individual inference calls with explicit evidence, not claims of
independent sentient entities. Source is saved only after interpreter success.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from . import agent
from .language import Interpreter,USLError
from .native import verify
from .compiler import TARGETS


def build_swarm(request,store,task_id):
    goal=request.get('goal','')
    if not isinstance(goal,str) or not 1<=len(goal.strip())<=3000:
        raise USLError('Goal must contain 1–3000 characters')
    project=request.get('project','demo')
    targets=request.get('targets',['python','javascript'])
    if not isinstance(targets,list) or not targets or len(targets)>13:
        raise USLError('Targets must be a nonempty list of at most 13 emitters')
    targets=list(dict.fromkeys(str(x).lower().strip() for x in targets))
    if any(x not in TARGETS for x in targets):
        raise USLError('Swarm native verification requires built-in emitter targets; use AI-transpile for other catalog entries')
    model=request.get('model') or None
    def role(name,prompt):
        store.event('swarm',name+' started',task_id)
        result=agent.ask_model(prompt,model,timeout=120)
        store.event('swarm',name+' completed',task_id)
        return result
    plan=role('architect','You are a software architect. Create a succinct, testable implementation plan (under 400 words) for this goal. Do not claim implementation or results. Goal:\n'+goal)
    notes='';attempts=[];verified=None
    for i in range(1,4):
        source=agent.strip_fence(role('implementer',agent.SYSTEM+goal+'\nArchitect plan:\n'+plan[:2000]+'\n'+notes))
        record={'attempt':i,'source_chars':len(source)}
        try:
            result=Interpreter(timeout=4,max_ops=100000).run(source)
            record['interpreter']='passed';record['output']=result.output[:3000]
        except (USLError,TypeError,ValueError) as exc:
            record['interpreter']='failed';record['error']=str(exc)[:1000]
            notes='Correct this error: '+str(exc)
            attempts.append(record)
            store.event('swarm','QA interpreter failed attempt '+str(i),task_id)
            continue
        # QA verifies actually installed native runtimes concurrently. Missing
        # toolchains remain explicit, not false passes.
        with ThreadPoolExecutor(max_workers=min(4,len(targets))) as pool:
            futures={pool.submit(verify,source,t):t for t in targets}
            native={}
            for f in as_completed(futures):
                target=futures[f]
                try:
                    item=f.result()
                    native[target]={k:v for k,v in item.items() if k in ('status','error','expected','actual','build','native')}
                except Exception as exc:
                    native[target]={'status':'verification_error','error':str(exc)[:800]}
        record['targets']={t:x.get('status') for t,x in native.items()}
        bad={t:v for t,v in record['targets'].items() if v not in ('passed','toolchain_missing')}
        record['failed_target_count']=len(bad)
        attempts.append(record)
        if bad:
            notes='Native checks failed: '+str(bad)[:1300]+'. Produce a correct restricted USL program compatible with target subset.'
            store.event('swarm','QA native verification failed attempt '+str(i),task_id)
            continue
        verified=(source,result,native)
        break
    if verified is None:
        raise USLError('No verified candidate after 3 attempts; inspected results: '+str(attempts)[:2000])
    source,result,native=verified
    review=role('reviewer',f'''Review the following USL program against the original user goal.
Do not claim to have run tests; the runtime has separately verified execution.
Identify likely missing requirements and edge cases. Return a short review only.
GOAL:\n{goal}\nSOURCE:\n{source[:12000]}''')
    # The review is advisory, not programmatically treated as a success claim.
    store.save(project,'main.usl',source)
    store.save(project,'swarm/architect_plan.txt',plan)
    store.save(project,'swarm/review.txt',review)
    from .compiler import transpile
    for target,item in native.items():
        if item['status'] in ('passed','toolchain_missing'):
            try:
                generated=transpile(source,target)
                store.save(project,'generated/'+generated.filename,generated.code)
            except (USLError,ValueError):pass
    store.event('swarm','Integrated artifact saved; human intent review required',task_id)
    return {'project':project,'source':source,'plan':plan,'review':review,
            'attempts':attempts,'targets':native,'interpreter_output':result.output,
            'source_interpreter_verified':True,'user_intent_verified':False,
            'agent_architecture':'sequential local-model architect, implementer, QA and reviewer roles'}
