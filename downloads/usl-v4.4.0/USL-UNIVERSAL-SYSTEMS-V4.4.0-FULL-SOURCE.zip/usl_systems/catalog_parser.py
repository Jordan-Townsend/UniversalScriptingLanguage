"""Actual available upstream grammar parsing, separate from language execution."""
from __future__ import annotations
import importlib.metadata,json,os,subprocess,sys
from pathlib import Path
from .catalog import load_catalog
from .entity_memory import fingerprint

EXACT_NAMES={'common-lisp':'commonlisp','csharp':'csharp','cpp':'cpp','clojurescript':'clojure',
 'shell':'bash','bash':'bash','fennel':'fennel','hylang':'hy','objective-c':'objc','objective-c++':'objc',
 'fortranfixed':'fortran','fortran':'fortran','splus':'r','delphi':'pascal','nixos':'nix',
 'nimrod':'nim','robotframework':'robot','terraform':'hcl','systemverilog':'verilog','wast':'wat',
 'scss':'scss'}

def mappings():
    try:
        import tree_sitter_language_pack as pack
        installed=set(pack.downloaded_languages())
    except ImportError:return {}
    result={}
    for row in load_catalog():
        name=row['id'];target=EXACT_NAMES.get(name,name.replace('-','_'))
        if target in installed:
            result[name]={'grammar':target,'available':True,'parser_version':importlib.metadata.version('tree-sitter-language-pack'),
                'native_execution':False,'semantic_conformance':False,'mapping_needs_dialect_review':name!=target}
    return result

def parse_source(language,source):
    if not isinstance(source,str) or not 1<=len(source.encode())<=32768:raise ValueError('bounded nonempty source required')
    mapping=mappings().get(language)
    if not mapping:raise ValueError('no installed upstream grammar mapping for '+str(language))
    req={'grammar':mapping['grammar'],'source':source}
    try:
        result=subprocess.run([sys.executable,str(Path(__file__).with_name('catalog_parser_worker.py'))],
            input=json.dumps(req).encode(),capture_output=True,timeout=6)
    except subprocess.TimeoutExpired:raise ValueError('grammar parse deadline exceeded')
    if result.returncode:raise ValueError('upstream grammar rejected source: '+result.stderr.decode(errors='replace')[-1000:])
    if len(result.stdout)>524288:raise ValueError('AST output bound exceeded')
    parsed=json.loads(result.stdout)
    return {'catalog_id':language,'grammar':mapping,'source_sha256':fingerprint(source),
        'ast':parsed,'native_execution':False,'typed_semantic_lowering':False}
