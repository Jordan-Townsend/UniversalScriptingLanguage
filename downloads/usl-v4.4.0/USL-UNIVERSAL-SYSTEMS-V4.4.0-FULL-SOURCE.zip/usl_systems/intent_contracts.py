"""Fail-closed proofs for explicit bounded integer postconditions.

Only the declared pure arithmetic AST is modelled. Unsupported features stay
unproved. A proof of a function/postcondition is not proof of arbitrary user intent.
"""
from __future__ import annotations
import ast,re
from .entity_memory import fingerprint
from .language import parse

class IntentError(ValueError):pass

def _expression(node,scope,z3,intermediates):
    if isinstance(node,ast.Constant) and type(node.value) in (int,bool):return z3.BoolVal(node.value) if type(node.value) is bool else z3.IntVal(node.value)
    if isinstance(node,ast.Name) and node.id in scope:return scope[node.id]
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.USub,ast.UAdd,ast.Not)):
        x=_expression(node.operand,scope,z3,intermediates)
        return -x if isinstance(node.op,ast.USub) else x if isinstance(node.op,ast.UAdd) else z3.Not(x)
    if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult)):
        a=_expression(node.left,scope,z3,intermediates);b=_expression(node.right,scope,z3,intermediates)
        value=a+b if isinstance(node.op,ast.Add) else a-b if isinstance(node.op,ast.Sub) else a*b
        intermediates.append(value);return value
    if isinstance(node,ast.Compare) and len(node.ops)==1:
        a=_expression(node.left,scope,z3,intermediates);b=_expression(node.comparators[0],scope,z3,intermediates)
        op=node.ops[0]
        if isinstance(op,ast.Eq):return a==b
        if isinstance(op,ast.NotEq):return a!=b
        if isinstance(op,ast.Lt):return a<b
        if isinstance(op,ast.LtE):return a<=b
        if isinstance(op,ast.Gt):return a>b
        if isinstance(op,ast.GtE):return a>=b
    if isinstance(node,ast.BoolOp):
        values=[_expression(n,scope,z3,intermediates) for n in node.values]
        return z3.And(*values) if isinstance(node.op,ast.And) else z3.Or(*values)
    raise IntentError('Unmodelled semantic operation: '+type(node).__name__)

def prove_expression(expression,contract):
    import z3
    if not isinstance(contract,dict) or contract.get('schema')!='usl.intent.integer.v1':raise IntentError('explicit versioned intent contract required')
    inputs=contract.get('inputs')
    if not isinstance(inputs,dict) or not 1<=len(inputs)<=8:raise IntentError('1..8 named bounded integer inputs required')
    scope={};constraints=[]
    for name,bounds in inputs.items():
        if not isinstance(name,str) or not name.isidentifier() or name.startswith('_') or name=='result':raise IntentError('invalid intent input')
        if not isinstance(bounds,dict) or type(bounds.get('min')) is not int or type(bounds.get('max')) is not int or not -2**31<=bounds['min']<=bounds['max']<2**31:raise IntentError('finite int32 input bounds required')
        scope[name]=z3.Int(name);constraints.extend([scope[name]>=bounds['min'],scope[name]<=bounds['max']])
    if not isinstance(expression,str) or len(expression)>4096 or not isinstance(contract.get('postcondition'),str) or len(contract['postcondition'])>4096:raise IntentError('bounded expression/postcondition required')
    tree=ast.parse(expression,mode='eval');post=ast.parse(contract['postcondition'],mode='eval')
    if len(list(ast.walk(tree)))+len(list(ast.walk(post)))>256:raise IntentError('symbolic AST budget exceeded')
    intermediates=[];result=_expression(tree.body,scope,z3,intermediates);scope['result']=result
    if not z3.is_int(result):raise IntentError('model requires an integer return value')
    intermediates.append(result)
    postcondition=_expression(post.body,scope,z3,[])
    if not z3.is_bool(postcondition):raise IntentError('postcondition must be boolean')
    solver=z3.Solver();solver.set(timeout=5000);solver.add(*constraints)
    domain=solver.check()
    if domain!=z3.sat:raise IntentError('input domain must be demonstrably satisfiable')
    # Guarantee primitive signed-int32 operations do not overflow on this domain.
    overflow=z3.Or(*[z3.Or(v < -(2**31),v >= 2**31) for v in intermediates]) if intermediates else z3.BoolVal(False)
    solver.add(z3.Or(z3.Not(postcondition),overflow));status=solver.check()
    output={'schema':'usl.intent.proof.v1','contract_sha256':fingerprint(contract),'expression_sha256':fingerprint(expression),
        'solver':z3.get_version_string(),'proved':status==z3.unsat,'domain':'bounded int32 inputs and overflow-free primitive arithmetic',
        'modelled_operations':['integer literals','variables','add','subtract','multiply','unary signs','comparisons','boolean connectives'],
        'whole_language_conformance':False,'arbitrary_natural_language_intent_proven':False,'solver_result':str(status)}
    if status==z3.sat:
        model=solver.model();output['counterexample']={name:str(model.evaluate(scope[name],model_completion=True)) for name in inputs}
    return output

def prove_usl(source,function,contract):
    tree=parse(source)
    functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==function]
    if len(functions)!=1:raise IntentError('one exact named function required')
    fn=functions[0]
    if [a.arg for a in fn.args.args]!=list(contract.get('inputs',{})) or len(fn.body)!=1 or not isinstance(fn.body[0],ast.Return):
        raise IntentError('proof requires matching input signature and one pure return expression')
    expression=ast.unparse(fn.body[0].value)
    proof=prove_expression(expression,contract);proof['source_sha256']=fingerprint(source)
    return proof

def native_expression(source,language,function,inputs):
    import tree_sitter_language_pack as pack
    if language not in ('python','javascript','typescript','c','cpp','go','rust','ruby','php','java','lua','csharp'):
        raise IntentError('native semantic extractor not implemented for '+str(language))
    tree=pack.get_parser(language).parse(source.encode())
    if tree.root_node.has_error:raise IntentError('actual native grammar rejected generated source')
    data=source.encode();stack=[tree.root_node];candidates=[]
    kinds={'function_definition','function_declaration','function_item','method','method_declaration'}
    while stack:
        node=stack.pop();stack.extend(reversed(node.named_children))
        if node.type not in kinds:continue
        name=node.child_by_field_name('name')
        if name is None and language in ('c','cpp'):
            declarator=node.child_by_field_name('declarator')
            name=declarator.child_by_field_name('declarator') if declarator else None
        if name and data[name.start_byte:name.end_byte].decode()==function:candidates.append(node)
    if len(candidates)!=1:raise IntentError('one native function definition required')
    fn=candidates[0];body=fn.child_by_field_name('body')
    native_type=fn.child_by_field_name('return_type') if language=='rust' else fn.child_by_field_name('result') if language=='go' else fn.child_by_field_name('type')
    if native_type is not None:
        spelling=data[native_type.start_byte:native_type.end_byte].decode().strip()
        if spelling not in ('int','i32','number'):
            raise IntentError('native return conversion/type is not modelled: '+spelling)
    header=data[fn.start_byte:body.start_byte].decode() if body else ''
    if re.search(r'\b(async|unsigned|double|float|bool|char)\b',header):
        raise IntentError('native parameter/return semantics outside the integer profile')
    parameters=fn.child_by_field_name('parameters')
    if parameters is None and language in ('c','cpp'):
        parameters=fn.child_by_field_name('declarator').child_by_field_name('parameters')
    if parameters is None:raise IntentError('native parameter signature missing')
    parameter_spelling=data[parameters.start_byte:parameters.end_byte].decode()
    if re.search(r'\b(unsigned|double|float|bool|char|string)\b',parameter_spelling):
        raise IntentError('native parameter conversion is outside the integer profile')
    pending=[parameters];names=[]
    while pending:
        node=pending.pop();pending.extend(reversed(node.named_children))
        if node.type in ('identifier','name') and not node.named_children:
            names.append(data[node.start_byte:node.end_byte].decode())
    if names!=list(inputs):raise IntentError('native parameter names do not match the intent signature')
    if body is None:raise IntentError('native function body missing')
    allowed_wrappers={'block','body_statement','compound_statement','statement_block','statement_list','expression_statement'}
    while body.type in allowed_wrappers:
        if len(body.named_children)!=1:raise IntentError('native function must contain exactly one pure return')
        body=body.named_children[0]
    if body.type not in ('return_statement','return_expression','return') or len(body.named_children)!=1:
        raise IntentError('native return shape not modelled')
    expression=data[body.named_children[0].start_byte:body.named_children[0].end_byte].decode()
    # Native parser establishes structure; the model accepts only the shared
    # primitive arithmetic spelling. Calls, attributes, division and casts fail.
    expression=re.sub(r'\$([A-Za-z][A-Za-z0-9_]*)',r'\1',expression)
    return expression

def prove_native(source,language,function,contract):
    expression=native_expression(source,language,function,contract.get('inputs',{}))
    proof=prove_expression(expression,contract)
    proof.update(native_source_sha256=fingerprint(source),language=language,
        extraction='actual upstream AST, one pure integer return expression',
        proof_scope='function arithmetic; native ABI/library/IO/compiler correctness are additional obligations')
    return proof
