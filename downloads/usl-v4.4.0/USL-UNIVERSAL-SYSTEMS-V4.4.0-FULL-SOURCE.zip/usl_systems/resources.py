"""Read-only CPU, memory, and GPU inventory. No unsupported acceleration claims."""
import os,platform,subprocess,shutil,json
from pathlib import Path

def _command(argv,timeout=5):
    try:
        x=subprocess.run(argv,capture_output=True,text=True,timeout=timeout,check=False)
        return x.stdout.strip() if x.returncode==0 else ''
    except (FileNotFoundError,OSError,subprocess.TimeoutExpired):return ''

def memory_bytes():
    if os.name=='nt':
        import ctypes
        class MEM(ctypes.Structure):
            _fields_=[('dwLength',ctypes.c_ulong),('dwMemoryLoad',ctypes.c_ulong),('ullTotalPhys',ctypes.c_ulonglong),
                      ('ullAvailPhys',ctypes.c_ulonglong),('ullTotalPageFile',ctypes.c_ulonglong),('ullAvailPageFile',ctypes.c_ulonglong),
                      ('ullTotalVirtual',ctypes.c_ulonglong),('ullAvailVirtual',ctypes.c_ulonglong),('ullAvailExtendedVirtual',ctypes.c_ulonglong)]
        m=MEM();m.dwLength=ctypes.sizeof(m)
        try:return {'total':m.ullTotalPhys,'available':m.ullAvailPhys} if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)) else None
        except (AttributeError,OSError):return None
    try:
        d={}
        for line in Path('/proc/meminfo').read_text().splitlines():
            k,_,v=line.partition(':')
            if k in ('MemTotal','MemAvailable'):d[k]=int(v.strip().split()[0])*1024
        if d:return {'total':d.get('MemTotal'), 'available':d.get('MemAvailable')}
    except (FileNotFoundError,ValueError):pass
    try:
        page=os.sysconf('SC_PAGE_SIZE');total=os.sysconf('SC_PHYS_PAGES')
        return {'total':page*total,'available':None}
    except (AttributeError,ValueError,OSError):return None

def gpu_inventory():
    gpu=[]
    if shutil.which('nvidia-smi'):
        raw=_command(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader,nounits'])
        for row in raw.splitlines():
            parts=[x.strip() for x in row.split(',')]
            if len(parts)==3:gpu.append({'name':parts[0],'vendor':'NVIDIA','memory_mib':parts[1],'driver':parts[2],'detection':'nvidia-smi'})
    if os.name=='nt':
        pwsh=shutil.which('powershell') or shutil.which('pwsh')
        if pwsh:
            data=_command([pwsh,'-NoProfile','-NonInteractive','-Command','Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion | ConvertTo-Json -Compress'],timeout=8)
            if data:
                try:
                    decoded=json.loads(data)
                    if isinstance(decoded,dict):decoded=[decoded]
                    for g in decoded:
                        name=g.get('Name','unknown')
                        if any(i['name']==name for i in gpu):continue
                        gpu.append({'name':name,'driver':g.get('DriverVersion'), 'memory_bytes_reported':g.get('AdapterRAM'), 'detection':'Windows CIM'})
                except (ValueError,TypeError):pass
    return gpu

def discover():
    return {'platform':platform.platform(),'machine':platform.machine(),
            'cpu_logical':os.cpu_count(),'memory_bytes':memory_bytes(),
            'gpus_detected':gpu_inventory(),
            'acceleration_claim':'Read-only hardware discovery; no USL GPU kernel execution or throughput claims.'}
