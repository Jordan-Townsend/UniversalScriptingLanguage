@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title USL Universal Systems 0.7.0 - Install and Start
color 0A
echo ==========================================================
echo  USL UNIVERSAL SYSTEMS 0.7.0 - WINDOWS STARTUP
echo ==========================================================
echo Project: %CD%
echo Persistent state: %%LOCALAPPDATA%%\USL_Universal_Systems
echo.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
  if not errorlevel 1 (
    set "PY_CMD=py -3"
    goto :start
  )
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
  if not errorlevel 1 (
    set "PY_CMD=python"
    goto :start
  )
)
echo ERROR: Python 3.10 or newer is required.
echo Install Python from https://www.python.org/downloads/windows/
echo Enable "Add python.exe to PATH" if prompted.
pause
exit /b 1
:start
echo [1/5] Python available: %PY_CMD%
%PY_CMD% -m compileall -q usl_systems
if errorlevel 1 (
  echo ERROR: USL source validation failed.
  pause
  exit /b 2
)
echo [2/5] Checking recovered full-source inventory...
%PY_CMD% -m usl_systems recovered-list >nul
if errorlevel 1 (
 echo WARNING: Could not check recovered archive integrity.
)
echo [3/5] Staging original recovered sources safely...
%PY_CMD% -m usl_systems recovered-stage all
if errorlevel 1 (
 echo ERROR: A historical source archive could not be staged safely.
 echo Existing installations and user state were NOT overwritten.
 pause
 exit /b 4
)
echo [4/5] Checking core environment...
%PY_CMD% -m usl_systems doctor
if errorlevel 1 (
  echo ERROR: Environment diagnostics failed.
  pause
  exit /b 3
)
echo.
echo [5/5] Launching local GUI at http://127.0.0.1:8772/
echo Close with Ctrl+C or STOP.bat. User data is preserved.
echo.
%PY_CMD% -m usl_systems serve
if errorlevel 1 (
  echo USL closed with an error; check output and RUN_TESTS.bat.
  pause
)
endlocal
