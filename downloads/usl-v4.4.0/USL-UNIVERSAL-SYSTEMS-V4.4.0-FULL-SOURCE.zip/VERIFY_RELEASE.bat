@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 tools\verify_release.py) else (python tools\verify_release.py)
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" echo WARNING: files do not match this release's checksum manifest.
endlocal & exit /b %CODE%
