@echo off
cd /d "%~dp0"
python tools\benchmark_feature_fusion.py
