@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m usl_systems link-project examples\modules.uslproject.json --output "%TEMP%\usl_linked_modules.usl"
if errorlevel 1 exit /b 1
%PY% -m usl_systems verify-project examples\modules.uslproject.json --target python --i-approve-native
exit /b %errorlevel%
