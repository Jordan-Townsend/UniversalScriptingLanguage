@echo off
setlocal
cd /d "%~dp0"
py -3 -m usl_systems nested-run examples\nested_fifteen_languages.uslnest.json --i-approve-native --output test_results\v3.6.0_fifteen_native_windows.json
pause
