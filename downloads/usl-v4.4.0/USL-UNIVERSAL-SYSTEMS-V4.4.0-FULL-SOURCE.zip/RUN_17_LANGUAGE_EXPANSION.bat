@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m usl_systems.expanded_domains qualify --approved --workers 8 --artifacts test_results\v4.1.0_artifacts --output test_results\v4.1.0_domains.json
) else (
  python -m usl_systems.expanded_domains qualify --approved --workers 8 --artifacts test_results\v4.1.0_artifacts --output test_results\v4.1.0_domains.json
)
set "CODE=%ERRORLEVEL%"
if not "%CODE%"=="0" echo USL v4.1 command failed with exit code %CODE%
endlocal & exit /b %CODE%
