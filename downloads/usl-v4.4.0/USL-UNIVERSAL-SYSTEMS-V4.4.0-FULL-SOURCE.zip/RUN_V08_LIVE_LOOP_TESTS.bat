@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m unittest tests.test_v08_live_loop tests.test_v08_compute_ollama -v
if errorlevel 1 (echo V0.8 live-loop tests FAILED & exit /b 1)
echo V0.8 local integration tests PASSED. Windows Chrome extension and real model still require live device checks.
