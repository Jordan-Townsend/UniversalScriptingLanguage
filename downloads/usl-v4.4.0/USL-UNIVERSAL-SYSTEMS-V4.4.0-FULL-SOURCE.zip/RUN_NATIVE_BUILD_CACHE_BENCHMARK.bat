@echo off
setlocal
cd /d "%~dp0"
py -3 tools\benchmark_native_cache.py
pause
