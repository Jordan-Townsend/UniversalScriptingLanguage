@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 tools\discover_next_language_engines.py
) else (
 python tools\discover_next_language_engines.py
)
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
