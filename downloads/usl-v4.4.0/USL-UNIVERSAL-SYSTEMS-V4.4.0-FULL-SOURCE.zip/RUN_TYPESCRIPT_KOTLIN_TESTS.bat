@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v32_typescript_kotlin.py -v
pause
