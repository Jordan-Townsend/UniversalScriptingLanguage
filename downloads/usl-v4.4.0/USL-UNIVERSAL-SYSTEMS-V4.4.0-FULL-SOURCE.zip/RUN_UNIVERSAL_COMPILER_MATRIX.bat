@echo off
setlocal
pushd "%~dp0"
python tools\qualify_extended_matrix_v38.py
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%
