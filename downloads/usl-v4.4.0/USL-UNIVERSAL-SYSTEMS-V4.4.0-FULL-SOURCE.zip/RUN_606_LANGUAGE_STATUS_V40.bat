@echo off
setlocal
cd /d "%~dp0"
echo Generate 606-entry evidence-ledger including new executed subsets.
where py >nul 2>nul
if not errorlevel 1 (
  set "USL_PY=py -3"
) else (
  set "USL_PY=python"
)
%USL_PY% tools\update_v40_606_ledger.py
set "CODE=%ERRORLEVEL%"
echo Exit code: %CODE%
endlocal & exit /b %CODE%
