@echo off
cd /d "%~dp0"
python -m usl_systems entity-plan examples/entity_plan.json --data .\entity-data --i-allow-execution
if errorlevel 1 exit /b 1
python -m usl_systems entity-memory "double integer" --data .\entity-data
