@echo off
setlocal
cd /d "%~dp0"
echo Compiling trusted V0.31 integer function to native code and running with input 5.
echo Expected native stdout: 7
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems recovered-native examples\recovered_native.usl --arg 5 --i-allow-native) else (python -m usl_systems recovered-native examples\recovered_native.usl --arg 5 --i-allow-native)
if errorlevel 1 (echo Native demo failed. First run RECOVER_SOURCE_COMPONENTS.bat and install GCC. & pause)
endlocal
