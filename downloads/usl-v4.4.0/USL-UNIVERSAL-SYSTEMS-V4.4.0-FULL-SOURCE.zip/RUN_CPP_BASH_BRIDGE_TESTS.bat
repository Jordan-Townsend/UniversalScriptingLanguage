@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v36_cpp_bash_bridges.py -v
pause
