@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 tools\qualify_v42_release.py
exit /b %errorlevel%
:python
python tools\qualify_v42_release.py
exit /b %errorlevel%
