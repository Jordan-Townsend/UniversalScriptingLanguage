@echo off
setlocal
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m usl_systems semantic-plugins --output test_results\semantic_plugin_606.json
if errorlevel 1 exit /b 1
%PY% -m usl_systems qualify-arrays --output test_results\array_qualification_local.json
exit /b %errorlevel%
