@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 tools\qualify_semantic_holdouts.py
) else (
 python tools\qualify_semantic_holdouts.py
)
endlocal & exit /b %ERRORLEVEL%
