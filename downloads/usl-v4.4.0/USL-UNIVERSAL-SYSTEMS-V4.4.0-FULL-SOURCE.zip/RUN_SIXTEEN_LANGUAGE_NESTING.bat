@echo off
setlocal
pushd "%~dp0"
python -m usl_systems nested-run examples\nested_sixteen_languages.uslnest.json --i-approve-native
popd
pause
