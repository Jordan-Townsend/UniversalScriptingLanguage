import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from usl_systems.interop import run_nested
project=json.loads((Path(__file__).parent/'nested_languages.uslnest.json').read_text('utf8'))
result=run_nested(project,authorized=True)
print(json.dumps(result,indent=2))
if not result['all_verified']:raise SystemExit(1)
