"""Run a real, approved repair of a deliberately broken Python project."""
import hashlib,json,tempfile,time
from pathlib import Path
from usl_systems.autonomy import AutonomyController
from usl_systems.store import Store
with tempfile.TemporaryDirectory() as d:
    store=Store(Path(d)/'data')
    main=store.safe_project_path('calculator','main.py')
    main.parent.mkdir(parents=True,exist_ok=True)
    main.write_text('def add(x, y)\n    return x + y\n')
    tests=main.parent/'tests';tests.mkdir()
    (tests/'test_add.py').write_text('import unittest\nfrom main import add\nclass TestAdd(unittest.TestCase):\n def test_arithmetic(self):\n  self.assertEqual(add(12,5),17)\n')
    step={'id':'repair_syntax','kind':'dev_repair','project':'calculator','path':'main.py',
       'original_sha256':hashlib.sha256(main.read_bytes()).hexdigest(),
       'old':'def add(x, y)\n','new':'def add(x, y):\n',
       'check':'unittest','expected':{'status':'completed'}}
    ctl=AutonomyController(store)
    try:
        run=ctl.create({'format':'uslauto-1','name':'Verified repair','steps':[step]})
        ctl.approve(run['id'],allow_process=True) # explicit demo consent
        ctl.begin(run['id'])
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            state=ctl.detail(run['id'])
            if state['status'] in ('completed','failed','needs_review','cancelled'):break
            time.sleep(.05)
        evidence=state['outcomes']
        summary={'status':state['status'],'source_sha256':hashlib.sha256(main.read_bytes()).hexdigest(),
                 'successful_steps':sum(int(s.get('successful',False)) for s in evidence),
                 'observations':evidence}
        print(json.dumps(summary,indent=2))
        if state['status']!='completed':raise SystemExit(1)
    finally:
        ctl.close()
