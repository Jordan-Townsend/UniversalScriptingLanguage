"""Python host -> verified bounded USL function, with typed result."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from usl_systems.interop import python_host_call_usl
out=python_host_call_usl('def triple(x):\n    return x * 3\n','triple',[14],['i64'],'i64')
print(json.dumps(out,indent=2))
assert out['value']==42
