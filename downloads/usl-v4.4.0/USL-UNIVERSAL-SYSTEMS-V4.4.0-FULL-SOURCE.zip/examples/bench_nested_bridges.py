"""Real one-pass observations, not repeatable hardware speedup guarantees."""
import json,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from usl_systems.interop import run_nested,SCHEMA
base={'schema':SCHEMA,'nodes':[
 {'id':'py','language':'python','source':'def f(x):\n    return x + 2\n','export':'f','params':['i64'],'returns':'i64','args':[40]},
 {'id':'js','language':'javascript','source':'export function f(x){return x+2;}\n','export':'f','params':['i64'],'returns':'i64','args':[40]},
 {'id':'sql','language':'sql','source':'SELECT ? + 2','export':'f','params':['i64'],'returns':'i64','args':[40]}]}
rows=[]
for workers in (1,3):
    measures=[]
    for _ in range(3):
        r=run_nested(base,authorized=True,workers=workers)
        if not r['all_verified'] or any(v['value']!=42 for v in r['results'].values()):raise RuntimeError('Runtime mismatch')
        measures.append(r['elapsed_ms'])
    rows.append({'workers':workers,'ms_runs':measures,'median_ms':statistics.median(measures),'verified_equal':True})
report={'schema':'usl.benchmark.v1','workload':'3 independent Python/JS/SQL nested guest calls','measurements':rows,
        'note':'Child startup, JSON and verification included; no guarantee parallel always faster.'}
output=Path(__file__).resolve().parents[1]/'test_results/v28_parallel_routes_benchmark.json'
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
