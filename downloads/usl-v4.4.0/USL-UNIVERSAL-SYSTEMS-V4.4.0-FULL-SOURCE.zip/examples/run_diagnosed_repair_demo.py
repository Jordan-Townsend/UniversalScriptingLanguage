"""Real Python SyntaxError -> machine-generated draft -> demo approval -> tests -> commit.

This script explicitly grants process permission for a tiny temporary trusted project.
The main GUI never grants this permission automatically.
"""
import hashlib,json,tempfile,time
from pathlib import Path
from usl_systems.store import Store
from usl_systems.autonomy import AutonomyController
from usl_systems.repair_proposals import propose_syntax_repair
with tempfile.TemporaryDirectory() as temp:
    s=Store(Path(temp)/'state')
    source=s.safe_project_path('demo','main.py');source.parent.mkdir(parents=True,exist_ok=True)
    source.write_text('def volume(x, y)\n    return x * y\n')
    tests=source.parent/'tests';tests.mkdir()
    (tests/'test_volume.py').write_text('import unittest\nfrom main import volume\nclass Correctness(unittest.TestCase):\n def test_result(self):\n  self.assertEqual(volume(4,7),28)\n')
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    suggested=propose_syntax_repair(s,'demo','main.py')
    assert before==hashlib.sha256(source.read_bytes()).hexdigest()
    control=AutonomyController(s)
    try:
        draft=control.create(suggested['plan'])
        assert control.detail(draft['id'])['status']=='draft'
        control.approve(draft['id'],allow_process=True)  # explicitly authorized demo
        control.begin(draft['id'])
        stop=time.monotonic()+30
        while time.monotonic()<stop:
            state=control.detail(draft['id'])
            if state['status'] in ('completed','failed','needs_review','cancelled'):break
            time.sleep(.05)
        after=hashlib.sha256(source.read_bytes()).hexdigest()
        evidence={'diagnostic':suggested['diagnostic'],'proposed_without_mutation':True,
          'owner_authorization':'explicit in demo script', 'status':state['status'],
          'before_sha256':before,'after_sha256':after,
          'first_step':state['outcomes'][0] if state['outcomes'] else None}
        print(json.dumps(evidence,indent=2))
        if state['status']!='completed':raise SystemExit(1)
    finally:control.close()
