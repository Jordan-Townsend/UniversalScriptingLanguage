"""Local, opt-in demonstration. Generates and executes Python code in a TEMP directory.
No user projects are accessed. Tests are executed by the current Python interpreter.
"""
import json
import tempfile
from pathlib import Path
from usl_systems.store import Store
from usl_systems.bridge import ProcessBridge
from usl_systems.observed_repair import ObservedRepair
with tempfile.TemporaryDirectory(prefix='usl-observed-repair-demo-') as t:
    store=Store(Path(t)/'state')
    file=store.safe_project_path('example','main.py');file.parent.mkdir(parents=True)
    file.write_text('def add(a,b)\n    return a+b\n')
    tests=file.parent/'tests';tests.mkdir()
    (tests/'test_main.py').write_text('import unittest\nfrom main import add\nclass T(unittest.TestCase):\n def test_add(self): self.assertEqual(add(2,3),5)\n')
    bridge=ProcessBridge(store)
    observed=ObservedRepair(store,bridge).observe('example','main.py',authorized=True)
    print('OBSERVED ACTUAL EXIT CODE:',observed['exit_code'])
    print('APPROVED DEMO: exact ephemeral syntax repair, unit-test verification')
    result=ObservedRepair(store,bridge).approve_and_verify(observed['observed_process_id'],authorized=True)
    print(json.dumps({'status':result['status'],'observed_exit':observed['exit_code'],
                      'continuation_exit':result['continuation']['exit_code'],
                      'verified_continuation':result['verified_continuation']},indent=2))
    bridge.shutdown()
    if not result['verified_continuation']:raise SystemExit(1)
