"""Self-contained, real autonomous task demo; leaves installed persistent data untouched."""
import json
import sys
import tempfile
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from usl_systems.store import Store
from usl_systems.bridge import ProcessBridge
from usl_systems.autonomy import AutonomyController


def main():
    with tempfile.TemporaryDirectory(prefix='usl-v06-demo-') as temp:
        store=Store(temp)
        bridge=ProcessBridge(store)
        auto=AutonomyController(store,bridge)
        try:
            reports=[]
            for name in ('autonomy_verified.uslauto.json','autonomy_research.uslauto.json'):
                plan=json.loads((Path(__file__).parent/name).read_text(encoding='utf8'))
                record=auto.create(plan)
                print('DRAFT',record['id'],record['status'])
                record=auto.approve(record['id'])
                print('APPROVED',record['id'],record['status'])
                auto.begin(record['id'])
                end=time.monotonic()+15
                while time.monotonic()<end:
                    record=auto.detail(record['id'])
                    if record['status'] in ('completed','failed','cancelled'):
                        break
                    time.sleep(.04)
                else:raise RuntimeError('Task execution did not settle')
                report={'name':name,'status':record['status'],'steps':len(record['outcomes']),
                        'proofs':[r.get('proof',{}) for r in record['outcomes']],
                        'all_verified':all(r['successful'] and r['proof']['passed'] for r in record['outcomes'])}
                reports.append(report)
                print(json.dumps(report,indent=2))
            if not all(x['status']=='completed' and x['all_verified'] for x in reports):
                return 1
            print('AUTONOMY DEMONSTRATION PASSED: real verified steps, journal, no local Ollama required')
            return 0
        finally:
            bridge.shutdown()
            auto.close()

if __name__=='__main__':sys.exit(main())
