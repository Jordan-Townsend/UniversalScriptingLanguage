USL skills are versioned programs qualified against independently supplied examples.

A zero residual makes the stacked convolutional feature-fusion network reproduce its baseline exactly. Training quality must be measured separately.
