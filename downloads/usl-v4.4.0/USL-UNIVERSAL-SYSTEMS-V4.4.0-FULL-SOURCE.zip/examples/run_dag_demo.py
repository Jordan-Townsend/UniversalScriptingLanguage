"""Runs a reviewed, bounded demonstration without real processes or network."""
import json
import sys
import tempfile
import time
from pathlib import Path
from usl_systems.autonomy import AutonomyController
from usl_systems.store import Store


def main():
    path=Path(__file__).parent/'autonomy_bound_dag.uslauto.json'
    plan=json.loads(path.read_text(encoding='utf8'))
    with tempfile.TemporaryDirectory(prefix='usl-v07-dag-') as root:
        ctl=AutonomyController(Store(root))
        try:
            run=ctl.create(plan)
            ctl.approve(run['id'])
            ctl.begin(run['id'])
            for _ in range(200):
                record=ctl.detail(run['id'])
                if record['status'] in ('completed','failed','needs_review','cancelled'):
                    break
                time.sleep(.05)
            else:raise RuntimeError('Demo did not complete within 10 seconds')
            result={'status':record['status'],'steps':[{'id':x['id'],'successful':x['successful']} for x in record['outcomes']],
                    'normalization':[x['id'] for x in record['plan']['steps']]}
            print(json.dumps(result,indent=2))
            return 0 if record['status']=='completed' and all(x['successful'] for x in record['outcomes']) else 2
        finally:ctl.close()

if __name__=='__main__':sys.exit(main())
