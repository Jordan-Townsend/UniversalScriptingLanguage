#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 -m pip install -r requirements-engines.txt
python3 -m usl_systems source-engines
