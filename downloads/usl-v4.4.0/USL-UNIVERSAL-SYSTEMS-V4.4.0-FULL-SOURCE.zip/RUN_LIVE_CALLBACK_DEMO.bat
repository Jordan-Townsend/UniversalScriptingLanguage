@echo off
setlocal
cd /d "%~dp0"
py -3 -m usl_systems nested-run examples\nested_callback_bridge.json --i-approve-native --output test_results\v3.3.0_callback_windows.json
pause
