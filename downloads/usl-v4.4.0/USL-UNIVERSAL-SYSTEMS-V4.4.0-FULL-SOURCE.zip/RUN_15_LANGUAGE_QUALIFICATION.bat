@echo off
setlocal
cd /d "%~dp0"
echo Execute 15 reviewed language-family operations and negative cases.
where py >nul 2>nul
if not errorlevel 1 (
  set "USL_PY=py -3"
) else (
  set "USL_PY=python"
)
%USL_PY% -m usl_systems.domain_execution qualify --approved --workers 8 --output "test_results\v4.0.0_domains_first_run.json" --artifacts "test_results\v4.0.0_artifacts"
set "CODE=%ERRORLEVEL%"
echo Exit code: %CODE%
endlocal & exit /b %CODE%
