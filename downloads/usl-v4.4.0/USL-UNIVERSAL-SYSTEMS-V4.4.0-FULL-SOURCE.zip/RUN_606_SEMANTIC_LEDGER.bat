@echo off
setlocal
cd /d "%~dp0"
if not exist test_results mkdir test_results
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -m usl_systems semantic-ledger --output "test_results\v3.9.0_semantic_606_ledger.json"
) else (
 python -m usl_systems semantic-ledger --output "test_results\v3.9.0_semantic_606_ledger.json"
)
set "CODE=%ERRORLEVEL%"
endlocal & exit /b %CODE%
