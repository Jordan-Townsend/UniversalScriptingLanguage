@echo off
setlocal
pushd "%~dp0"
python -m unittest discover -s tests -p "test_v37_executable_matrix.py" -v
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%
