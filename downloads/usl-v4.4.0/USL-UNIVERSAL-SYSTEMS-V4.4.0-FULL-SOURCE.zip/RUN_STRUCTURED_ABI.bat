@echo off
setlocal
cd /d "%~dp0"
py -3 -m usl_systems nested-run examples\nested_structured_abi.json --i-approve-native --output test_results\v3.4.0_structured_windows.json
pause
