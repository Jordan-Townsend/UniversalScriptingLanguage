@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v31_perl_swift_bridge.py -v
pause
