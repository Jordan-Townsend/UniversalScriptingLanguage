@echo off
setlocal
cd /d "%~dp0"
echo USL v0.3 - native semantic conformance tests
if not exist "test_results" mkdir "test_results"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -m usl_systems qualify --output "test_results\compiler_qualification_full.json"
) else (
 python -m usl_systems qualify --output "test_results\compiler_qualification_full.json"
)
set "CODE=%ERRORLEVEL%"
echo Results: test_results\compiler_qualification_full.json
endlocal & exit /b %CODE%
