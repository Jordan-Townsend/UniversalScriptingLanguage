@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul && (py -3 tools\qualify_nested_arrays.py) || (python tools\qualify_nested_arrays.py)
if errorlevel 1 exit /b 1
endlocal
