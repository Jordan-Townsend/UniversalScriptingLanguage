@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems serve) else (python -m usl_systems serve)
endlocal
