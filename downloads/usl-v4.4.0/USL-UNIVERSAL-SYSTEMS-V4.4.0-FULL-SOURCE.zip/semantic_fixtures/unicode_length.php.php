<?php
$value = strlen("A😀");

echo json_encode(["case" => "unicode_length", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
