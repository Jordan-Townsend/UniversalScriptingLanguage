import json
try:
    raise ValueError("sentinel")
except ValueError:
    value = "caught"

print(json.dumps({"case":"exception_capture","value":value}, ensure_ascii=False, separators=(",",":")))
