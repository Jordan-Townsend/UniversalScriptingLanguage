<?php
$a = [1,2]; $b = $a; $b[0] = 9; $value = $a[0];

echo json_encode(["case" => "mutable_alias", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
