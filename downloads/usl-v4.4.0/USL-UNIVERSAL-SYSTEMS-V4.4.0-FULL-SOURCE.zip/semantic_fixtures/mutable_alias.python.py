import json
a = [1, 2]
b = a
b[0] = 9
value = a[0]

print(json.dumps({"case":"mutable_alias","value":value}, ensure_ascii=False, separators=(",",":")))
