let value; try { throw new Error("sentinel"); } catch(e) { value="caught"; }

console.log(JSON.stringify({case:"exception_capture",value}));
