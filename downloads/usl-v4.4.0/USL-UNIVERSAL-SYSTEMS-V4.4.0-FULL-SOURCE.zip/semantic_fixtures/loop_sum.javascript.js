let value=0; for(let i=1;i<5;i++){value+=i*i;}

console.log(JSON.stringify({case:"loop_sum",value}));
