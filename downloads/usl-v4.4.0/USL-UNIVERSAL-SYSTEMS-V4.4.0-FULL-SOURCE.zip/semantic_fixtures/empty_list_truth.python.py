import json
value = bool([])

print(json.dumps({"case":"empty_list_truth","value":value}, ensure_ascii=False, separators=(",",":")))
