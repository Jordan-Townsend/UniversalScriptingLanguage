const a = [1,2]; const b = a; b[0] = 9; const value = a[0];

console.log(JSON.stringify({case:"mutable_alias",value}));
