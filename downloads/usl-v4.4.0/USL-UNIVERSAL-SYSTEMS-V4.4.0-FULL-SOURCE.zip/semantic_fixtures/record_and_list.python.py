import json
r = {"numbers": [3, 5, 8]}; value = {"sum": r["numbers"][0] + r["numbers"][2], "length": len(r["numbers"])}

print(json.dumps({"case":"record_and_list","value":value}, ensure_ascii=False, separators=(",",":")))
