<?php
$value = (bool)[];

echo json_encode(["case" => "empty_list_truth", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
