<?php
$r = ["numbers" => [3,5,8]]; $value = ["sum" => $r["numbers"][0]+$r["numbers"][2], "length" => count($r["numbers"])];

echo json_encode(["case" => "record_and_list", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
