const r = {numbers:[3,5,8]}; const value = {sum: r.numbers[0]+r.numbers[2], length:r.numbers.length};

console.log(JSON.stringify({case:"record_and_list",value}));
