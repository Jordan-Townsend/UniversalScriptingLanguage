const value = Boolean([]);

console.log(JSON.stringify({case:"empty_list_truth",value}));
