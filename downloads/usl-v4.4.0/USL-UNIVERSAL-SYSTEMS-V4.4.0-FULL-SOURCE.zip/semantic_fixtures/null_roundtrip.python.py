import json
value = {"present": True, "data": None}

print(json.dumps({"case":"null_roundtrip","value":value}, ensure_ascii=False, separators=(",",":")))
