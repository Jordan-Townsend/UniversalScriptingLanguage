import json
value = sum(i*i for i in range(1, 5))

print(json.dumps({"case":"loop_sum","value":value}, ensure_ascii=False, separators=(",",":")))
