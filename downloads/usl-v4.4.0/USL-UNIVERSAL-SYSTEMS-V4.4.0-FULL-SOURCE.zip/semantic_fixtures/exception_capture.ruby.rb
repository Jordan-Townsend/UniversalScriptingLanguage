require "json"
begin
  raise ArgumentError, "sentinel"
rescue ArgumentError
  value = "caught"
end

puts JSON.generate({"case" => "exception_capture", "value" => value})
