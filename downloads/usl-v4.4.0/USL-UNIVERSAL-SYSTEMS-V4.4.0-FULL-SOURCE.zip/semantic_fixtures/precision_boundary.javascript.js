const value = 9007199254740992 + 1;

console.log(JSON.stringify({case:"precision_boundary",value}));
