require "json"
value = (1...5).sum { |i| i*i }

puts JSON.generate({"case" => "loop_sum", "value" => value})
