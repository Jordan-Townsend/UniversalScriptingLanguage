require "json"
value = {"present" => true, "data" => nil}

puts JSON.generate({"case" => "null_roundtrip", "value" => value})
