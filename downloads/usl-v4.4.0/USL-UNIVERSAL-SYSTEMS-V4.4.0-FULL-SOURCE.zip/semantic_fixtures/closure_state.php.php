<?php
$make = function() { $v=1; return function() use (&$v) { return ++$v; }; }; $f = $make(); $f(); $value = $f();

echo json_encode(["case" => "closure_state", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
