<?php
$value = ["present" => true, "data" => null];

echo json_encode(["case" => "null_roundtrip", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
