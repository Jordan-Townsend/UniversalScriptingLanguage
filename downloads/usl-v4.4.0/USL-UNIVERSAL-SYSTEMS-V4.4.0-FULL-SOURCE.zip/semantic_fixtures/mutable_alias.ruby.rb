require "json"
a = [1, 2]
b = a
b[0] = 9
value = a[0]

puts JSON.generate({"case" => "mutable_alias", "value" => value})
