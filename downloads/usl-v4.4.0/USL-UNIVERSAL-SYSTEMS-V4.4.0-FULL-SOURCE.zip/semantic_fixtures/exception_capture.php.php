<?php
try { throw new RuntimeException("sentinel"); } catch (RuntimeException $e) { $value="caught"; }

echo json_encode(["case" => "exception_capture", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
