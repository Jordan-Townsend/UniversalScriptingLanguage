<?php
$value=0; for($i=1;$i<5;$i++){$value+=$i*$i;}

echo json_encode(["case" => "loop_sum", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
