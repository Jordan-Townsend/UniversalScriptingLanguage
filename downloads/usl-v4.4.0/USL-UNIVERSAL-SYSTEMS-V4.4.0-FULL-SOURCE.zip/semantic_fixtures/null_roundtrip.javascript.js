const value = {present: true, data: null};

console.log(JSON.stringify({case:"null_roundtrip",value}));
