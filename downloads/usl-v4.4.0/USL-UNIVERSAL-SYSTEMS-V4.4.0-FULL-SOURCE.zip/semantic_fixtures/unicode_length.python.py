import json
value = len("A😀")

print(json.dumps({"case":"unicode_length","value":value}, ensure_ascii=False, separators=(",",":")))
