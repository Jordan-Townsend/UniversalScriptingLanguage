require "json"
value = "A😀".length

puts JSON.generate({"case" => "unicode_length", "value" => value})
