require "json"
def make
  v = 1
  -> { v += 1; v }
end
f = make
f.call
value = f.call

puts JSON.generate({"case" => "closure_state", "value" => value})
