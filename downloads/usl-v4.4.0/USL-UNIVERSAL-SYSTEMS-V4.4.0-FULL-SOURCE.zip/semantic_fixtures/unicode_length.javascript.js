const value = "A😀".length;

console.log(JSON.stringify({case:"unicode_length",value}));
