import json
value = -7 // 3

print(json.dumps({"case":"negative_integer_division","value":value}, ensure_ascii=False, separators=(",",":")))
