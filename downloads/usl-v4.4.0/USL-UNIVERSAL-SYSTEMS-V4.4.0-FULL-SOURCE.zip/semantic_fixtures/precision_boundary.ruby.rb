require "json"
value = 9007199254740992 + 1

puts JSON.generate({"case" => "precision_boundary", "value" => value})
