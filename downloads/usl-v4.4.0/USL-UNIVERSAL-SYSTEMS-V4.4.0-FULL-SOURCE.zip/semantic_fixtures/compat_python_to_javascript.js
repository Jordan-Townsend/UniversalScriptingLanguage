"use strict";
// Reviewed *bounded* emulation of five Python semantics in a JavaScript host.
// This is NOT a full Python compatibility runtime.
function pyFloorDivSafe(a, b) {
  if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b) || b === 0) throw new RangeError('unsupported inputs');
  return Math.floor(a / b);
}
function pyUnicodeLength(s) { return Array.from(s).length; }
function pyListTruth(a) { if (!Array.isArray(a)) throw new TypeError('expected list'); return a.length !== 0; }
function pyBigIntAdd(a,b) { return {kind:'bigint', decimal:(BigInt(a)+BigInt(b)).toString()}; }
const values = [1,2];const alias = values;alias[0] = 9;
const result = {
  negative_integer_division: pyFloorDivSafe(-7,3),
  unicode_length: pyUnicodeLength('A😀'),
  empty_list_truth: pyListTruth([]),
  precision_boundary: pyBigIntAdd('9007199254740992','1'),
  mutable_alias: values[0]
};
console.log(JSON.stringify(result));
