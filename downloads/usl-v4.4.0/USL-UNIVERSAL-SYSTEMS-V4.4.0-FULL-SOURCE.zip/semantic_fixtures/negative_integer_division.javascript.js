const value = Math.trunc(-7 / 3);

console.log(JSON.stringify({case:"negative_integer_division",value}));
