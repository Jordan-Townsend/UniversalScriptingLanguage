import json
def make():
    v = 1
    def inc():
        nonlocal v
        v += 1
        return v
    return inc
f = make()
f()
value = f()

print(json.dumps({"case":"closure_state","value":value}, ensure_ascii=False, separators=(",",":")))
