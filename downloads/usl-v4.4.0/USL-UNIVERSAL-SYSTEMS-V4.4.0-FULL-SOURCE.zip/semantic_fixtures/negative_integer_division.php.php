<?php
$value = intdiv(-7, 3);

echo json_encode(["case" => "negative_integer_division", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
