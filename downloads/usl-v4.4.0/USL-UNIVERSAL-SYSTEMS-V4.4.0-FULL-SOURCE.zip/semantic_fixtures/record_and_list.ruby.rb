require "json"
r = {"numbers" => [3,5,8]}; value = {"sum" => r["numbers"][0]+r["numbers"][2], "length" => r["numbers"].length}

puts JSON.generate({"case" => "record_and_list", "value" => value})
