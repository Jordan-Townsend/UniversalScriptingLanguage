function make(){let v=1;return ()=>{v++;return v;};} const f=make(); f(); const value=f();

console.log(JSON.stringify({case:"closure_state",value}));
