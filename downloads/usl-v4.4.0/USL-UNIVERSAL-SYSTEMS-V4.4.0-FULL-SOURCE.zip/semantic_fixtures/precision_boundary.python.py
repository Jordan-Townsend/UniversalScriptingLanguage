import json
value = 9007199254740992 + 1

print(json.dumps({"case":"precision_boundary","value":value}, ensure_ascii=False, separators=(",",":")))
