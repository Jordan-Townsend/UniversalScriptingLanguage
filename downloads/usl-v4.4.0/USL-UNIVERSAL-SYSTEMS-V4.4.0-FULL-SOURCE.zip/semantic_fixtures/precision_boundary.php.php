<?php
$value = 9007199254740992 + 1;

echo json_encode(["case" => "precision_boundary", "value" => $value], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), "\n";
