require "json"
value = !![]

puts JSON.generate({"case" => "empty_list_truth", "value" => value})
