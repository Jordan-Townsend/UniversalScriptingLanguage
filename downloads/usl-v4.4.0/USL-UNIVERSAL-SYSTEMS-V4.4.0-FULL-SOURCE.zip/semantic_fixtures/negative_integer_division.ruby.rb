require "json"
value = -7.div(3)

puts JSON.generate({"case" => "negative_integer_division", "value" => value})
