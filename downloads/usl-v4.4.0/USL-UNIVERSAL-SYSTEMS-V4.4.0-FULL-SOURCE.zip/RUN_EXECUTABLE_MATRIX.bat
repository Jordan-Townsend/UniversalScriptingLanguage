@echo off
setlocal
pushd "%~dp0"
if not exist "test_results" mkdir "test_results"
echo =============================================================
echo  USL v3.7 - ACTUAL EXECUTION QUALIFICATION / ALL 606 ACCOUNTED
 echo =============================================================
echo Actual native processes are launched. Run only reviewed source.
python tools\qualify_all_eligible_pairs_v37.py
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Some native routes failed or toolchains are absent. See test_results\v3.7.0_parallel_pair_execution.json
popd
endlocal & exit /b %RC%
