@echo off
setlocal
pushd "%~dp0"
python -m usl_systems matrix-build --output-prefix "test_results\runtime_matrix_status"
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" echo This status-only matrix has CONDITIONAL routes; it does NOT execute native code.
popd
endlocal & exit /b %RC%
