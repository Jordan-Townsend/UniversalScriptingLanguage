@echo off
setlocal
pushd "%~dp0"
call RUN_606_RUNTIME_QUALIFICATION.bat
set "CODE=%ERRORLEVEL%"
popd
endlocal & exit /b %CODE%
