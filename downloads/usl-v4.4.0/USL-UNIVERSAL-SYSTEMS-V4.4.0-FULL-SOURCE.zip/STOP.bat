@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems stop) else (python -m usl_systems stop)
if errorlevel 1 (
  echo Unable to reach controller. Use Ctrl+C in its console if open.
  pause
)
endlocal
