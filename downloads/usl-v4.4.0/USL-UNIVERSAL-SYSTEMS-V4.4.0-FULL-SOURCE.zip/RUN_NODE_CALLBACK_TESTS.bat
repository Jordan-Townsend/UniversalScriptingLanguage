@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v34_structural_abi_node_callbacks.py -v
pause
