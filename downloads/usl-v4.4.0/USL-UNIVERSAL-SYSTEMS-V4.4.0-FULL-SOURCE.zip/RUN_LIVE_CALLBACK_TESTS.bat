@echo off
setlocal
cd /d "%~dp0"
py -3 -m unittest discover -s tests -p test_v33_live_callbacks.py -v
pause
