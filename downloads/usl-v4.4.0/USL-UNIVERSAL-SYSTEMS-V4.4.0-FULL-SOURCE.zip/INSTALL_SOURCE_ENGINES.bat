@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 -m pip install -r requirements-engines.txt
if errorlevel 1 exit /b %errorlevel%
py -3 -m usl_systems source-engines
exit /b %errorlevel%
:python
python -m pip install -r requirements-engines.txt
if errorlevel 1 exit /b %errorlevel%
python -m usl_systems source-engines
exit /b %errorlevel%
