@echo off
setlocal
cd /d "%~dp0"
echo Reuse all 15 verified output artifacts in the USL task graph.
where py >nul 2>nul
if not errorlevel 1 (
  set "USL_PY=py -3"
) else (
  set "USL_PY=python"
)
%USL_PY% tools\reuse_discovered_abilities.py
set "CODE=%ERRORLEVEL%"
echo Exit code: %CODE%
endlocal & exit /b %CODE%
