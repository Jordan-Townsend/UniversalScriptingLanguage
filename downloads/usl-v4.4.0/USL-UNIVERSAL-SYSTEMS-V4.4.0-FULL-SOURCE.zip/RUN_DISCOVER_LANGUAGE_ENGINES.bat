@echo off
setlocal
cd /d "%~dp0"
echo Discover reviewed language-family engines; no code execution.
where py >nul 2>nul
if not errorlevel 1 (
  set "USL_PY=py -3"
) else (
  set "USL_PY=python"
)
%USL_PY% -m usl_systems.domain_execution discover
set "CODE=%ERRORLEVEL%"
echo Exit code: %CODE%
endlocal & exit /b %CODE%
