@echo off
setlocal
cd /d "%~dp0"
echo USL non-destructive repair / integrity check
echo Python compile check and regression tests (user state untouched).
where py >nul 2>nul
if not errorlevel 1 (py -3 -m compileall -q usl_systems) else (python -m compileall -q usl_systems)
if errorlevel 1 (echo ERROR: Python module compilation failed.&pause&exit /b 1)
call VERIFY_RELEASE.bat
if errorlevel 1 echo Release source was modified; review before running untrusted code.
call RUN_TESTS.bat
endlocal
