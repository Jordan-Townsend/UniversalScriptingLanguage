@echo off
setlocal
cd /d "%~dp0"
echo Starting real recovered Chrome Bridge V3.0 on localhost port 8766.
echo It retains existing pairing data. Trusted execution remains disabled by default.
where py >nul 2>nul
if not errorlevel 1 (py -3 -m usl_systems recovered-bridge-run --i-allow-launch) else (python -m usl_systems recovered-bridge-run --i-allow-launch)
if errorlevel 1 (echo Bridge exited with an error. Run RECOVER_SOURCE_COMPONENTS.bat first. & pause)
endlocal
