#!/usr/bin/env ruby
#
# /tmp/usl-v4115-clean-readiness/fresh/grammar_hosts/fresh/antlr-ruby/literal/Probe.g
# --
# Generated using ANTLR version: 3.5
# Ruby runtime library version: 1.10.0
# Input grammar file: /tmp/usl-v4115-clean-readiness/fresh/grammar_hosts/fresh/antlr-ruby/literal/Probe.g
# Generated at: 2026-10-15 04:53:18
#

# ~~~> start load path setup
this_directory = File.expand_path( File.dirname( __FILE__ ) )
$LOAD_PATH.unshift( this_directory ) unless $LOAD_PATH.include?( this_directory )

antlr_load_failed = proc do
  load_path = $LOAD_PATH.map { |dir| '  - ' << dir }.join( $/ )
  raise LoadError, <<-END.strip!

Failed to load the ANTLR3 runtime library (version 1.10.0):

Ensure the library has been installed on your system and is available
on the load path. If rubygems is available on your system, this can
be done with the command:

  gem install antlr3

Current load path:
#{ load_path }

  END
end

defined?( ANTLR3 ) or begin

  # 1: try to load the ruby antlr3 runtime library from the system path
  require 'antlr3'

rescue LoadError

  # 2: try to load rubygems if it isn't already loaded
  defined?( Gem ) or begin
    require 'rubygems'
  rescue LoadError
    antlr_load_failed.call
  end

  # 3: try to activate the antlr3 gem
  begin
    defined?( gem ) and gem( 'antlr3', '~> 1.10.0' )
  rescue Gem::LoadError
    antlr_load_failed.call
  end

  require 'antlr3'

end
# <~~~ end load path setup

module Probe
  # TokenData defines all of the token type integer values
  # as constants, which will be included in all
  # ANTLR-generated recognizers.
  const_defined?( :TokenData ) or TokenData = ANTLR3::TokenScheme.new

  module TokenData

    # define the token constants
    define_tokens( :EOF => -1, :A => 4, :B => 5, :C => 6 )


    # register the proper human-readable name or literal value
    # for each token type
    #
    # this is necessary because anonymous tokens, which are
    # created from literal values in the grammar, do not
    # have descriptive names
    register_names( "A", "B", "C" )


  end


  class Parser < ANTLR3::Parser
    @grammar_home = Probe

    RULE_METHODS = [ :start ].freeze

    include TokenData

    begin
      generated_using( "/tmp/usl-v4115-clean-readiness/fresh/grammar_hosts/fresh/antlr-ruby/literal/Probe.g", "3.5", "1.10.0" )
    rescue NoMethodError => error
      # ignore
    end

    def initialize( input, options = {} )
      super( input, options )
    end
    # - - - - - - - - - - - - Rules - - - - - - - - - - - - -

    #
    # parser rule start
    #
    # (in /tmp/usl-v4115-clean-readiness/fresh/grammar_hosts/fresh/antlr-ruby/literal/Probe.g)
    # 3:8: public start : A B EOF ;
    #
    def start
      # -> uncomment the next line to manually enable rule tracing
      # trace_in( __method__, 1 )


      begin
      # at line 3:16: A B EOF
      match( A, TOKENS_FOLLOWING_A_IN_start_20 )
      match( B, TOKENS_FOLLOWING_B_IN_start_22 )
      match( EOF, TOKENS_FOLLOWING_EOF_IN_start_24 )

      rescue ANTLR3::Error::RecognitionError => re
        report_error(re)
        recover(re)

      ensure
        # -> uncomment the next line to manually enable rule tracing
        # trace_out( __method__, 1 )


      end

      return 
    end

    public :start rescue nil




    TOKENS_FOLLOWING_A_IN_start_20 = Set[ 5 ]
    TOKENS_FOLLOWING_B_IN_start_22 = Set[  ]
    TOKENS_FOLLOWING_EOF_IN_start_24 = Set[ 1 ]

  end # class Parser < ANTLR3::Parser

  at_exit { Parser.main( ARGV ) } if __FILE__ == $0

end
