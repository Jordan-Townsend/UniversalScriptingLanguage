"""Create a separate Python environment for the 19 pure translation adapters."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import venv

ROOT=Path(__file__).resolve().parent


def setup(prefix):
    prefix=Path(prefix).absolute()
    if any(p.is_symlink() for p in [prefix,*prefix.parents]):raise ValueError('Virtual environment path cannot contain symlinks')
    prefix=prefix.resolve()
    if prefix.is_relative_to(ROOT) or ROOT.is_relative_to(prefix):raise ValueError('Virtual environment must not overlap source')
    if sys.platform!='linux' or platform.machine()!='x86_64' or sys.version_info<(3,12):
        raise ValueError('This pinned wheel workflow requires Linux x86_64 and Python3.12 or newer')
    if prefix.exists():raise ValueError('Use a new virtual environment directory; existing contents are preserved')
    runtime=ROOT/'bundled_runtime/usl_systems/language.py'
    expected='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'
    if hashlib.sha256(runtime.read_bytes()).hexdigest()!=expected:raise ValueError('Bundled interpreter identity mismatch')
    venv.EnvBuilder(with_pip=True).create(prefix)
    python=prefix/'bin/python'
    subprocess.run([str(python),'-m','pip','install','--disable-pip-version-check','--no-cache-dir',
                    '--only-binary=:all:','--require-hashes','--no-deps','-r',str(ROOT/'requirements-portable.txt')],check=True,timeout=180)
    subprocess.run([str(python),'-m','pip','check'],check=True,timeout=30)
    print(json.dumps({'python':str(python),'runtime_root':str(ROOT/'bundled_runtime'),
                      'native_original_hosts_installed':False,'selected_adapters':19,
                      'example_command':[str(python),str(ROOT/'translate.py'),'request.json',
                         '--source-root',str(ROOT/'bundled_runtime'),'--output','new-output','--run-usl']}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--venv',required=True,type=Path)
    args=parser.parse_args();setup(args.venv)
