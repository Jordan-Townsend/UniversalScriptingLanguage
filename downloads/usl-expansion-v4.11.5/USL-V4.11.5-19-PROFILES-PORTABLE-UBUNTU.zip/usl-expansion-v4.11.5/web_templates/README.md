# Vue and Angular2-family native-to-USL template profiles

Three original catalog IDs now have bounded semantic translation profiles:
`vue`, `ng2`, and `html+ng2`. Actual upstream Vue3.5.22 SFC parsing/SSR and
Angular4.4.7 JIT/server rendering execute source freshly. Each selected template
also lowers through a typed, bounded shared template IR into executable `.usl`.
The tests compare both native and USL results against hand-authored expected HTML
DOM trees. This qualifies the stated subset, not either complete framework,
a whole programming language, or arbitrary natural-language intent.

`vue` means template-only Vue Single-File Component source:

```vue
<template><section><p v-if="shown">Hello {{name}}</p><ul><li v-for="item in items">{{item}}</li></ul></section></template>
```

`ng2` and `html+ng2` select the same Angular2-family template dialect, with
independent catalog receipts:

```html
<section><p *ngIf="shown">Hello {{name}}</p><ul><li *ngFor="let item of items">{{item}}</li></ul></section>
```

The `ng2` Pygments lexer describes generic Angular2 template syntax;
`html+ng2` delegates that lexer alongside HTML. Angular4.4.7 is the exact selected
native implementation of that Angular2-family subset. This does not substitute
AngularJS1, claim Angular2.0 binary compatibility, or translate TypeScript source.
The installed Pygments class definitions and exact source identities are recorded
in `REFERENCES.json`. The unavailable v4.angular.io URL was replaced by its
working version-pinned Angular4.4.7 documentation source on GitHub. The Vue
reference pages are retrieval snapshots; they can document newer releases, so
the pinned compiler/runtime implementation remains the concrete selected version.
A complete normative audit remains open.

Bindings are plain string, Boolean and string-list inputs. Strings have at most
4096 characters, lists at most 16 strings. Interpolation expressions are simple,
lowercase identifiers only. Conditions require exact external Booleans; loops
require exact external string lists. Aliases have lexical scope and cannot shadow
external bindings or existing aliases. Text and attribute values are escaped by
actual `.usl` functions, rather than interpolated by a Python template engine.

Accepted source has one unconditional root, paired lowercase allowlisted tags
(`div/section/article/ul/ol/li/p/span/strong/em/h1/h2/a/label/button`), quoted
attributes, static `id/class/title/data-note/aria-label`, and exact-string bound
attributes using Vue `:title` or Angular `[attr.title]` syntax. Nested `v-if` and
`v-for` or `*ngIf` and `*ngFor` are supported; putting both directives on the same
element is rejected. Only the five XML named character references are accepted.
Raw comparison brackets, source comments/declarations, control whitespace,
multiple adjacent literal spaces and outer whitespace are outside this profile.
Dynamic strings retain whitespace and Unicode. At most 65536 source UTF-8 bytes,
16 element nesting levels and 4096 expanded IR nodes are admitted. The actual USL
interpreter has a 2,000,000-operation and 4-second execution limit.

Comparison preserves element nesting, text and allowlisted attribute values.
It ignores attribute ordering, SSR structural comments, Angular generated scoped
style metadata, and formatting-only whitespace between elements or inside empty
structural containers. HTML's `title` and `title=""` both have the empty attribute
value; this browser DOM equivalence has an independent regression test. Full
serialized HTML, hydration/reactivity and client event behavior are not claimed.

## Run

Use the established USL environment (Python, Node24.19.0 and the immutable USL
runtime); the provider restorer requires only Python standard library and HTTPS.
No system package writes, lifecycle scripts, native npm binaries or downloads
outside the family provider directory occur.

```bash
source /workspace/.onboarding/activate-usl.sh
cd /workspace/usl-expansion-v4.11.5/web_templates
python restore.py
python -m unittest -v test_web_templates
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

`package-lock.json` fixes every one of 39 npm packages to a tarball and SRI digest.
`PROVIDER_FILES.json` fixes the SHA-256 of every retained provider file. Restore
checks archive integrity before extracting only JS/JSON/licenses, never executes
package install scripts, and rejects extraction differing from the frozen file
pins. Maps, declarations, source-only TS files and unused ESM trees are omitted.
The runtime/provider tree is about 24MiB and is restored under `providers/`; source
archives should omit that directory. `package.json` is configuration for the
already-frozen lock, not a request to resolve newer dependency versions.

There are 26 native/USL/independent-intent cases per catalog ID, 78 total, plus 54
explicit unsupported-profile rejection fixtures. Additional adversarial tests
cover missing/incorrectly typed bindings, scope escape/shadowing, multiplicative
expansion limits, malformed/case-mismatched syntax and an actual wrong emitted
escaping mutation caught by the independently authored HTML intent. These finite
examples are evidence for this bounded implementation, not a universal proof.

All 78 logical case actors start before a shared release. Three separate upstream
Node processes are admitted against measured available cgroup memory (128MiB
estimated reservation per process); there is no fixed round cap. Logical
concurrency does not create additional hardware. Every native render and USL
execution happens freshly. Generated `.usl` source is content-addressed, so
identical source files occupy one artifact path; execution evidence is never
reused. `results/results.json` preserves every source/input/output, expected tree,
provider/runtime identity, cost and open obligation.

Open work includes arbitrary JS/TS expressions, components, modules, lifecycle,
dependency injection, services, pipes, custom/event/two-way directives, slots,
SFC script/style compilation, AOT, DOM state and effects, reactivity/hydration,
all libraries/interoperability/platform contracts and full independent normative
qualification. Full-standard qualifications remain zero.
