"""Independent hand-authored HTML intent fixtures; no frontend-derived expected output."""
from html import escape
LANGUAGES=['vue','ng2','html+ng2']
def source(language,body):return '<template>'+body+'</template>' if language=='vue' else body
def cases():
    result=[]
    def add(language,label,body,bindings,expected):result.append({'id':language+':'+label,'language':language,'source':source(language,body),'bindings':bindings,'expected_HTML':expected})
    for language in LANGUAGES:
        for i,value in enumerate(['','world','<x>&\"\'','snowman ☃','é 日本語','  keep spaces  ','{{not_reparsed}}','a\nb','<!--comment-->']):
            add(language,'text'+str(i),'<p>Hello {{name}}!</p>',{'name':value},'<p>Hello '+escape(value,quote=False)+'!</p>')
        for i,value in enumerate(['','plain','<x>&\"\'','a b','☃','line\nnext']):
            directive=':title' if language=='vue' else '[attr.title]'
            add(language,'attribute'+str(i),'<p '+directive+'="name">word</p>',{'name':value},'<p title="'+escape(value,quote=True)+'">word</p>')
        add(language,'literal-entity','<div title="&lt;&amp;&quot;">&lt;x&gt;&amp;end</div>',{},'<div title="&lt;&amp;&quot;">&lt;x&gt;&amp;end</div>')
        for flag in [False,True]:
            directive='v-if' if language=='vue' else '*ngIf'
            add(language,'condition'+str(flag),'<section><p '+directive+'="shown">{{name}}</p><span>end</span></section>',{'shown':flag,'name':'<yes>'},'<section>'+('<p>&lt;yes&gt;</p>' if flag else '')+'<span>end</span></section>')
        for i,values in enumerate([[],['one'],['one','<two>','&three'],['','x','x'],['one']*16]):
            directive='v-for="item in items"' if language=='vue' else '*ngFor="let item of items"'
            add(language,'loop'+str(i),'<ul><li '+directive+'>{{item}}</li></ul>',{'items':values},'<ul>'+''.join('<li>'+escape(v,quote=False)+'</li>' for v in values)+'</ul>')
        directive='v-for="item in items"' if language=='vue' else '*ngFor="let item of items"';condition='v-if' if language=='vue' else '*ngIf'
        add(language,'nested-control','<div><section '+condition+'="shown"><p '+directive+'>{{item}}:{{suffix}}</p></section></div>',{'shown':True,'items':['a','b'],'suffix':'!'},'<div><section><p>a:!</p><p>b:!</p></section></div>')
        add(language,'adjacent-text','<p>A{{x}}B<strong>{{y}}</strong>C</p>',{'x':'&','y':'<z>'},'<p>A&amp;B<strong>&lt;z&gt;</strong>C</p>')
        add(language,'multiple-attributes','<p id="hello" class="red" title="note">hello</p>',{},'<p class="red" title="note" id="hello">hello</p>')
    return result

def unsupported():
    result=[]
    for language in LANGUAGES:
        for body,bindings in [('<p>{{x + y}}</p>',{'x':'a','y':'b'}),('<p>{{x.upper()}}</p>',{'x':'a'}),('<script>alert(1)</script>',{}),('<p title="{{x}}">x</p>',{'x':'a'}),('<p onclick="evil()">x</p>',{}),('<p>{{constructor}}</p>',{}),('<div><p></div></p>',{}),('<p id="x" id="y">x</p>',{}),('<p>  condense</p>',{}),('<p>{{missing}}</p>',{}),('<p>{{x}}</p>',{'x':12}),('<p>{{x}}</p>',{'x':['x']}),('<p><br/></p>',{}),('<p><!--x-->x</p>',{}),('<p>{{x}}</p>',{'x':'x'*4097})]:
            result.append((language,source(language,body),bindings))
        if language=='vue':
            result.extend([(language,'<template><p>x</p></template><script>evil()</script>',{}),(language,source(language,'<p v-html="x"></p>'),{'x':'<x>'}),(language,source(language,'<div><p v-for="x in xs" v-if="flag">x</p></div>'),{'xs':[],'flag':True})])
        else:result.extend([(language,source(language,'<p *ngif="flag">x</p>'),{'flag':True}),(language,source(language,'<p (click)="x()">x</p>'),{}),(language,source(language,'<p [(ngModel)]="x">x</p>'),{'x':'a'})])
    return result
