"""Fail-closed SFC/Angular template profile, typed shared IR and USL lowering."""
from html.parser import HTMLParser
import re
TAGS={'div','section','article','ul','ol','li','p','span','strong','em','h1','h2','a','label','button'}
ATTRS={'title','id','class','data-note','aria-label'}
NAME=r'[a-z][a-z0-9_]*'
RESERVED={'true','false','null','undefined','constructor','prototype','__proto__','this','let','of','in','if','else','return','for','while','var','function'}
class ProfileError(ValueError):pass
def need(ok,message):
    if not ok:raise ProfileError(message)
def name(s):
    need(re.fullmatch(NAME,s) is not None and s not in RESERVED,'Unsupported expression/name');return s
def parts(text):
    result=[];position=0
    for m in re.finditer(r'{{ *('+NAME+r') *}}',text):
        if m.start()>position:result.append(['literal',text[position:m.start()]])
        result.append(['binding',name(m[1])]);position=m.end()
    if position<len(text):result.append(['literal',text[position:]])
    need(all('{{' not in value and '}}' not in value for kind,value in result if kind=='literal'),'Unsupported interpolation expression')
    need(all(not any(c.isspace() and c!=' ' for c in value) and '  ' not in value for kind,value in result if kind=='literal'),'Literal whitespace outside exact profile')
    return result
class Parser(HTMLParser):
    def __init__(self,language):super().__init__(convert_charrefs=True);self.language=language;self.root=[];self.stack=[self.root];self.tags=[]
    def handle_starttag(self,tag,attrs):
        need(tag in TAGS and len(self.tags)<16,'Unsupported element/depth');raw=self.get_starttag_text()
        need(raw.startswith('<'+tag) and not raw.endswith('/>'),'Canonical lowercase paired elements required')
        # HTMLParser lowercases names; inspect original names to reject mis-cased Angular directives.
        pattern=r'''\s+([^\s=/>]+)\s*=\s*("[^"<>]*"|'[^'<>]*')'''
        cursor=len(tag)+1;original=[]
        while cursor<len(raw)-1:
            m=re.match(pattern,raw[cursor:]);need(m is not None,'Quoted valued attributes only')
            original.append(m[1]);cursor+=m.end()
        need(cursor==len(raw)-1 and len(original)==len(attrs),'Malformed attributes')
        need(len({k for k,v in attrs})==len(attrs),'Duplicate attribute')
        node={'kind':'element','tag':tag,'attributes':[],'parts':[],'children':[]};condition=None;loop=None
        for original_key,(key,value) in zip(original,attrs):
            if key in ATTRS:
                need(original_key==key and '{{' not in value and '}}' not in value,'Static attribute interpolation outside profile');node['attributes'].append([key,['literal',value]])
            elif self.language=='vue' and key.startswith(':'):
                need(original_key==key,'Canonical case required')
                need(key[1:] in ATTRS,'Unsupported bound attribute');node['attributes'].append([key[1:],['binding',name(value.strip(' '))]])
            elif self.language!='vue' and key.startswith('[attr.') and key.endswith(']'):
                need(original_key==key,'Canonical case required')
                attr=key[6:-1];need(attr in ATTRS,'Unsupported bound attribute');node['attributes'].append([attr,['binding',name(value.strip(' '))]])
            elif key==('v-if' if self.language=='vue' else '*ngif'):
                need(original_key==('v-if' if self.language=='vue' else '*ngIf'),'Directive case mismatch');condition=name(value.strip(' '))
            elif key==('v-for' if self.language=='vue' else '*ngfor'):
                need(original_key==('v-for' if self.language=='vue' else '*ngFor'),'Directive case mismatch')
                syntax=r'('+NAME+r') in ('+NAME+r')' if self.language=='vue' else r'let ('+NAME+r') of ('+NAME+r')'
                m=re.fullmatch(syntax,value.strip(' '));need(m is not None,'Unsupported loop expression');loop=(name(m[1]),name(m[2]))
            else:raise ProfileError('Unsupported directive/attribute: '+original_key)
        need(len({a[0] for a in node['attributes']})==len(node['attributes']),'Duplicate emitted attribute')
        need(not(condition and loop),'Combined conditional/loop directive outside profile')
        wrapped=node
        if condition:wrapped={'kind':'if','binding':condition,'yes':[node],'no':[]}
        if loop:wrapped={'kind':'each','alias':loop[0],'binding':loop[1],'children':[node]}
        self.stack[-1].append(wrapped);self.stack.append(node['children']);self.tags.append(tag)
    def handle_startendtag(self,*args):raise ProfileError('Self-closing tag outside profile')
    def handle_endtag(self,tag):
        need(bool(self.tags) and self.tags[-1]==tag,'Unbalanced/misnested tags');self.tags.pop();self.stack.pop()
    def handle_data(self,data):
        if data:self.stack[-1].append({'kind':'text','parts':parts(data)})
    def handle_comment(self,data):raise ProfileError('Source comments outside profile')
    def handle_decl(self,data):raise ProfileError('Source declaration outside profile')
    def handle_pi(self,data):raise ProfileError('Source processing instruction outside profile')
    def unknown_decl(self,data):raise ProfileError('Source unknown declaration outside profile')
def frontend(source,catalog_id):
    need(catalog_id in {'vue','ng2','html+ng2'} and type(source) is str and len(source.encode())<=65536,'Source/language limit')
    need('\x00' not in source and not any(ord(c)<32 for c in source),'Control characters outside profile')
    if catalog_id=='vue':
        m=re.fullmatch(r'<template>(.*)</template>',source,re.DOTALL);need(m is not None,'Vue profile requires a single template-only SFC');source=m[1]
    need(bool(source) and not source.startswith(' ') and not source.endswith(' '),'Empty/outer-space template outside profile')
    need('&' not in re.sub(r'&(?:amp|lt|gt|quot|apos);','',source),'Only the five XML named character references are in profile')
    plain=re.sub(r'</?[a-z][^<>]*>','',source)
    need('<' not in plain and '>' not in plain,'Raw comparison brackets/malformed tags outside profile')
    parser=Parser(catalog_id);parser.feed(source);parser.close();need(not parser.tags,'Unclosed source tag')
    need(len(parser.root)==1 and parser.root[0]['kind']=='element','One unconditional root element required')
    return parser.root


def validate_bindings(nodes,bindings,language=None):
    need(type(bindings) is dict and all(type(k) is str for k in bindings),'Expected plain binding map')
    if False:
        for value in bindings.values():
            values=value if type(value) is list else [value]
            need(all(type(item) is not str or '-->' not in item for item in values),'Mask SSR model-comment termination outside safe profile')
    def reference(expression,scope,attribute=False):
        kind,key=expression
        if kind=='literal':values=[key]
        else:
            need(key in scope or key in bindings,'Missing required binding: '+key)
            values=scope[key] if key in scope else [bindings[key]]
        for value in values:
            need(type(value) is str and len(value)<=4096,'Text/attribute binding must be a bounded exact string')
            if language=='mask' and attribute:need('&' not in value,'Mask native attributes do not preserve ampersand entities; outside profile')
    def walk(items,scope):
        for node in items:
            kind=node['kind']
            if kind in {'text','element'}:
                for item in node['parts']:reference(item,scope)
            if kind=='element':
                for key,expression in node['attributes']:reference(expression,scope,True)
                walk(node['children'],scope)
            elif kind=='if':
                need(node['binding'] in bindings and type(bindings[node['binding']]) is bool,'Condition requires exact Boolean external binding')
                walk(node['yes'],scope);walk(node['no'],scope)
            elif kind=='each':
                need(node['binding'] in bindings,'Missing list binding')
                values=bindings[node['binding']];need(type(values) is list and len(values)<=16 and all(type(v) is str and len(v)<=4096 for v in values),'Loop requires bounded list of exact strings')
                alias=node['alias'];need(alias not in bindings and alias not in scope,'Loop alias must not shadow existing bindings')
                walk(node['children'],scope|{alias:values})
    walk(nodes,{})
    expanded_nodes=0
    def expansion(items):
        nonlocal expanded_nodes
        for node in items:
            expanded_nodes+=1;need(expanded_nodes<=4096,'Expanded template node budget exceeded')
            if node['kind']=='element':expansion(node['children'])
            elif node['kind']=='if':expansion(node['yes']);expansion(node['no'])
            elif node['kind']=='each':
                for item in bindings[node['binding']]:expansion(node['children'])
    expansion(nodes)


def emit_usl(nodes):
    lines=['function escape_html(value):','    let escaped = ""','    for character in value:',
           '        if character == "&":','            escaped = escaped + "&amp;"',
           '        elif character == "<":','            escaped = escaped + "&lt;"',
           '        elif character == ">":','            escaped = escaped + "&gt;"',
           '        elif character == "\\\"":','            escaped = escaped + "&quot;"',
           '        elif character == "\'":','            escaped = escaped + "&#39;"',
           '        else:','            escaped = escaped + character','    return escaped','let rendered = ""']
    count=0
    def expression(value,scope):
        kind,data=value
        return repr(data) if kind=='literal' else scope.get(data,'template_binding('+repr(data)+')')
    def append(value,depth):lines.append('    '*depth+'rendered = rendered + '+value)
    def walk(items,scope,depth):
        nonlocal count
        for node in items:
            kind=node['kind']
            if kind=='element':
                append(repr('<'+node['tag']),depth)
                for key,value in node['attributes']:
                    append(repr(' '+key+'="'),depth);append('escape_html('+expression(value,scope)+')',depth);append(repr('"'),depth)
                append(repr('>'),depth)
                for item in node['parts']:append('escape_html('+expression(item,scope)+')',depth)
                walk(node['children'],scope,depth);append(repr('</'+node['tag']+'>'),depth)
            elif kind=='text':
                for item in node['parts']:append('escape_html('+expression(item,scope)+')',depth)
            elif kind=='if':
                lines.append('    '*depth+'if template_binding('+repr(node['binding'])+'):');walk(node['yes'],scope,depth+1)
                if node['no']:lines.append('    '*depth+'else:');walk(node['no'],scope,depth+1)
            elif kind=='each':
                local='template_item'+str(count);count+=1;lines.append('    '*depth+'for '+local+' in template_binding('+repr(node['binding'])+'):')
                walk(node['children'],scope|{node['alias']:local},depth+1)
    walk(nodes,{},0);return '\n'.join(lines)+'\n'


def run_usl(source,language,bindings):
    from usl_systems.language import Interpreter
    nodes=frontend(source,language);validate_bindings(nodes,bindings,language);generated=emit_usl(nodes)
    execution=Interpreter(capabilities={'template_binding':lambda key:bindings[key]},timeout=4,max_ops=2_000_000).run(generated)
    return execution.variables['rendered'],{'actual_USL_execution':True,'operations':execution.operations,'generated_source':generated}


class HTMLTree(HTMLParser):
    def __init__(self,mask=False):super().__init__(convert_charrefs=True);self.root=['root',[],[]];self.stack=[self.root];self.mask=mask
    def handle_starttag(self,tag,attrs):
        need(tag in TAGS,'Unexpected native output element')
        attrs=sorted((key,'' if value is None else value) for key,value in attrs if not(key.startswith('_ngcontent-') or key.startswith('_nghost-') or key=='ng-version'))
        node=[tag,attrs,[]];self.stack[-1][2].append(node);self.stack.append(node)
    def handle_endtag(self,tag):need(len(self.stack)>1 and self.stack[-1][0]==tag,'Native HTML tag mismatch');self.stack.pop()
    def handle_data(self,data):
        children=self.stack[-1][2]
        if children and type(children[-1]) is str:children[-1]+=data
        else:children.append(data)
    def tree(self):
        need(len(self.stack)==1,'Unclosed rendered HTML')
        def clean(node):
            children=node[2];contains_elements=any(type(c) is list for c in children)
            return [node[0],node[1],[clean(c) if type(c) is list else c for c in children if type(c) is list or c.strip() or (not contains_elements and node[0] not in {'root','div','section','article','ul','ol'})]]
        return clean(self.root)


def html_tree(text,mask=False):
    parser=HTMLTree(mask);parser.feed(text);parser.close();return parser.tree()
