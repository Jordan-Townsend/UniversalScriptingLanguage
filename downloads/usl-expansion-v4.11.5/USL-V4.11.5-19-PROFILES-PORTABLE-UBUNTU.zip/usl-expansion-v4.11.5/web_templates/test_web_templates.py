import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
from semantics import ProfileError,frontend,validate_bindings,emit_usl,run_usl,html_tree
from cases import cases,unsupported,source,LANGUAGES
from run import native_batch,providers
class WebTemplateTests(unittest.TestCase):
    def test_independent_intent_fixtures(self):
        for row in cases():
            with self.subTest(row=row['id']):
                output,receipt=run_usl(row['source'],row['language'],row['bindings'])
                self.assertEqual(html_tree(row['expected_HTML']),html_tree(output));self.assertGreater(receipt['operations'],0)
    def test_all_unsupported_rejected(self):
        for language,text,bindings in unsupported():
            with self.subTest(language=language,text=text[:100]):
                with self.assertRaises(ProfileError):validate_bindings(frontend(text,language),bindings,language)
    def test_native_compilers_and_USL_independent_corner_intents(self):
        for language in LANGUAGES:
            fixtures=[r for r in cases() if r['language']==language and r['id'].split(':')[1] in ['text2','attribute0','attribute2','conditionFalse','loop2','nested-control','literal-entity']]
            native=native_batch(language,fixtures)
            for row,actual in zip(fixtures,native['observations']):self.assertEqual(html_tree(row['expected_HTML']),html_tree(actual['output']))
    def test_alias_lexical_shadow_and_scope(self):
        for language in LANGUAGES:
            directive='v-for="item in items"' if language=='vue' else '*ngFor="let item of items"'
            text=source(language,'<div><p '+directive+'>{{item}}</p><p>{{item}}</p></div>')
            with self.assertRaises(ProfileError):validate_bindings(frontend(text,language),{'items':['a']},language)
            with self.assertRaises(ProfileError):validate_bindings(frontend(text,language),{'items':['a'],'item':'outer'},language)
    def test_binding_types_and_resource_limits(self):
        for language in LANGUAGES:
            condition='v-if' if language=='vue' else '*ngIf';loop='v-for="item in items"' if language=='vue' else '*ngFor="let item of items"'
            for value in [0,1,'true',[],None]:
                with self.assertRaises(ProfileError):validate_bindings(frontend(source(language,'<div><p '+condition+'="shown">x</p></div>'),language),{'shown':value},language)
            for value in [['x']*17,[True],['x'*4097],'array',None]:
                with self.assertRaises(ProfileError):validate_bindings(frontend(source(language,'<ul><li '+loop+'>{{item}}</li></ul>'),language),{'items':value},language)
            with self.assertRaises(ProfileError):frontend(source(language,'<p>'+'x'*65537+'</p>'),language)
            with self.assertRaises(ProfileError):frontend(source(language,'<div>'*17+'x'+'</div>'*17),language)
    def test_mutated_emitter_is_detected_by_independent_intent(self):
        from usl_systems.language import Interpreter
        row=next(r for r in cases() if r['id']=='vue:text2');nodes=frontend(row['source'],row['language']);generated=emit_usl(nodes)
        mutated=generated.replace('escaped = escaped + "&lt;"','escaped = escaped + "["')
        self.assertNotEqual(generated,mutated)
        output=Interpreter(capabilities={'template_binding':lambda key:row['bindings'][key]},timeout=4,max_ops=2000000).run(mutated).variables['rendered']
        self.assertNotEqual(html_tree(row['expected_HTML']),html_tree(output))
    def test_attribute_empty_lexical_forms_have_same_DOM_value(self):
        self.assertEqual(html_tree('<p title>word</p>'),html_tree('<p title="">word</p>'))
    def test_malformed_or_noncanonical_source_rejected(self):
        for language in LANGUAGES:
            bad=['<p>&unknown;</p>','<p>&#0;</p>','<p>x< broken</p>','<p><![CDATA[x]]></p>']
            bad.append('<p :TITLE="x">x</p>' if language=='vue' else '<p [ATTR.TITLE]="x">x</p>')
            for text in bad:
                with self.subTest(language=language,text=text):
                    with self.assertRaises(ProfileError):frontend(source(language,text),language)
    def test_expanded_node_budget_prevents_multiplicative_work(self):
        for language in LANGUAGES:
            if language=='vue':directives=['v-for="a in xs"','v-for="b in ys"','v-for="c in zs"']
            else:directives=['*ngFor="let a of xs"','*ngFor="let b of ys"','*ngFor="let c of zs"']
            text=source(language,'<div><section '+directives[0]+'><p '+directives[1]+'><span '+directives[2]+'>{{c}}</span></p></section></div>')
            with self.assertRaises(ProfileError):validate_bindings(frontend(text,language),{'xs':['x']*16,'ys':['y']*16,'zs':['z']*16},language)
    def test_locked_providers(self):
        identity=providers();self.assertTrue(identity['no_lifecycle_scripts']);self.assertEqual(39,len(identity['packages']))
    def test_provider_tamper_rejected_and_restored(self):
        path=ROOT/'providers/node_modules/vue/LICENSE';original=path.read_bytes()
        try:
            path.write_bytes(original+b'\nchanged\n')
            with self.assertRaises(ValueError):providers()
        finally:path.write_bytes(original)
        self.assertTrue(providers()['no_lifecycle_scripts'])
    def test_actual_generated_USL_not_python_template_replay(self):
        nodes=frontend('<template><p>{{name}}</p></template>','vue');generated=emit_usl(nodes)
        self.assertIn('template_binding',generated);self.assertIn('function escape_html',generated)
        from usl_systems.language import Interpreter
        for name in ['first','second','<third>']:
            result=Interpreter(capabilities={'template_binding':lambda key:name},max_ops=2000000,timeout=4).run(generated)
            self.assertEqual(html_tree('<p>'+name.replace('<','&lt;').replace('>','&gt;')+'</p>'),html_tree(result.variables['rendered']))
if __name__=='__main__':unittest.main()
