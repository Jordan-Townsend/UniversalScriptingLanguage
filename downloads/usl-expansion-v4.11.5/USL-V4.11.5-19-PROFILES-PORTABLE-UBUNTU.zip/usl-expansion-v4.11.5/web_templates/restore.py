"""Restore exact npm lockfile artifacts without executing package lifecycle scripts."""
import base64,hashlib,io,json,os,shutil,tarfile,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREFIX=ROOT/'providers'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def restore():
    lock=json.loads((ROOT/'package-lock.json').read_text());PREFIX.mkdir(exist_ok=True)
    records={}
    for folder,p in lock['packages'].items():
        if not folder:continue
        if not folder.startswith('node_modules/') or '..' in Path(folder).parts or Path(folder).is_absolute():raise ValueError('Unsafe package directory')
        integrity=p['integrity'];algorithm,encoded=integrity.split('-',1)
        if algorithm not in {'sha512','sha256'}:raise ValueError('Weak package hash')
        with urllib.request.urlopen(p['resolved'],timeout=50) as response:data=response.read()
        if hashlib.new(algorithm,data).digest()!=base64.b64decode(encoded):raise ValueError('Package integrity mismatch')
        target=PREFIX/folder;target.mkdir(parents=True,exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                bits=Path(member.name).parts
                if not bits or bits[0]!='package' or '..' in bits or not member.isfile():continue
                path=Path(*bits[1:]);name=path.name
                if not (name.endswith(('.js','.cjs','.mjs','.json')) or name.lower().startswith(('license','copying'))):continue
                if name.endswith('.min.js') or '/esm' in '/'+str(path):continue
                output=target/path;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(archive.extractfile(member).read())
        files={str(p.relative_to(target)):sha(p) for p in sorted(target.rglob('*')) if p.is_file()}
        records[folder]={'version':p['version'],'url':p['resolved'],'integrity':integrity,'archive_sha256':hashlib.sha256(data).hexdigest(),'files':files}
    report={'lock_sha256':sha(ROOT/'package-lock.json'),'packages':records,'no_lifecycle_scripts':True,'native_binaries_shipped':False}
    expected=ROOT/'PROVIDER_FILES.json'
    if expected.exists() and report!=json.loads(expected.read_text()):raise ValueError('Extracted provider identity differs from frozen file pins')
    (PREFIX/'IDENTITY.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
    r=restore();print(json.dumps({'packages':len(r['packages']),'lock_sha256':r['lock_sha256']}))
