"""Fresh Vue SFC/Angular2-family SSR versus generated USL and independent intent."""
import argparse,asyncio,hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from cases import LANGUAGES,cases,unsupported
from semantics import ProfileError,frontend,validate_bindings,run_usl,html_tree
ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def providers():
    prefix=ROOT/'providers';receipt=json.loads((prefix/'IDENTITY.json').read_text())
    if receipt['lock_sha256']!=sha(ROOT/'package-lock.json'):raise ValueError('Lock identity mismatch')
    if receipt!=json.loads((ROOT/'PROVIDER_FILES.json').read_text()):raise ValueError('Provider receipt differs from frozen source pins')
    lock=json.loads((ROOT/'package-lock.json').read_text())
    if set(receipt['packages'])!=set(lock['packages'])-{''}:raise ValueError('Missing/extra restored packages')
    for folder,item in receipt['packages'].items():
        frozen=lock['packages'][folder]
        if any(item[key]!=frozen[other] for key,other in [('version','version'),('url','resolved'),('integrity','integrity')]):raise ValueError('Restored provider differs from lock')
        actual={str(p.relative_to(prefix/folder)):sha(p) for p in sorted((prefix/folder).rglob('*')) if p.is_file()}
        if actual!=item['files']:raise ValueError('Provider source changed: '+folder)
    return receipt

def native_batch(language,fixtures):
    payload=json.dumps([{key:c[key] for key in ['id','language','source','bindings']} for c in fixtures]).encode()
    command=['node',str(ROOT/'native.cjs')]
    completed=subprocess.run(command,input=payload,capture_output=True,timeout=60)
    if completed.returncode:raise ValueError('Native upstream failed: '+completed.stderr.decode(errors='replace')[:2000])
    result=json.loads(completed.stdout)
    if [r['id'] for r in result['observations']]!=[c['id'] for c in fixtures]:raise ValueError('Native batch IDs differ')
    result['execution_receipt']={'fresh_native_processes':1,'fresh_native_render_observations':len(fixtures),'native_execution_replayed':False,
      'stdin_sha256':hashlib.sha256(payload).hexdigest(),'stdout_sha256':hashlib.sha256(completed.stdout).hexdigest(),
      'stderr_hex':completed.stderr.hex(),'command':command,'exit_status':completed.returncode,
      'executable_sha256':sha(result['toolchain']['executable'])}
    return result

def admitted_workers(jobs):
    def read(path,default):
        try:return int(Path(path).read_text().strip())
        except (ValueError,OSError):return default
    limit=read('/sys/fs/cgroup/memory.max',1<<30);used=read('/sys/fs/cgroup/memory.current',0)
    available=max(0,limit-used);slots=max(1,min(jobs,max(1,available//(128<<20))))
    return {'observed_memory_limit_bytes':limit,'observed_memory_current_bytes':used,'reservation_estimate_bytes':128<<20,'admitted_threads':slots,'distinct_native_jobs':jobs,'virtual_workers_create_physical_capacity':False}

async def execute(source_root,output):
    source_root=Path(source_root).resolve();sys.path.insert(0,str(source_root));output=Path(output);output.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter();fixtures=cases();sources={n:sha(ROOT/n) for n in ['semantics.py','cases.py','run.py','restore.py','native.cjs','package.json','package-lock.json','PROVIDER_FILES.json','test_web_templates.py']}
    identity=providers();ready=asyncio.Event();begun=0;active=0;peak=0;admission=admitted_workers(len(LANGUAGES));loop=asyncio.get_running_loop();executor=ThreadPoolExecutor(max_workers=admission['admitted_threads'])
    async def native_job(language):
        await ready.wait();return await loop.run_in_executor(executor,native_batch,language,[c for c in fixtures if c['language']==language])
    jobs={language:asyncio.create_task(native_job(language)) for language in LANGUAGES}
    async def case_actor(case):
        nonlocal begun,active,peak
        begun+=1;active+=1;peak=max(peak,active)
        try:
            await ready.wait();native=next(r for r in (await jobs[case['language']])['observations'] if r['id']==case['id'])
            observed,receipt=run_usl(case['source'],case['language'],case['bindings']);expected=html_tree(case['expected_HTML']);native_tree=html_tree(native['output']);usl_tree=html_tree(observed)
            if not native['accepted'] or expected!=native_tree or expected!=usl_tree:raise ValueError('Independent/native/USL counterexample '+case['id']+':'+repr((expected,native_tree,usl_tree)))
            generated=receipt.pop('generated_source');key=hashlib.sha256(generated.encode()).hexdigest();folder=output/'generated';folder.mkdir(exist_ok=True);(folder/(key+'.usl')).write_text(generated)
            return dict(case,passed=True,native=native,observed_USL_output=observed,independent_expected_tree=expected,native_observed_tree=native_tree,USL_receipt=receipt,generated_source_sha256=key,full_standard_qualified=False)
        finally:active-=1
    tasks=[asyncio.create_task(case_actor(case)) for case in fixtures]
    try:
        await asyncio.sleep(0);all_started=begun==len(fixtures);ready.set();evidence=await asyncio.gather(*tasks);native={language:await job for language,job in jobs.items()}
    finally:executor.shutdown(wait=True)
    rejections=[]
    for language,source,bindings in unsupported():
        try:nodes=frontend(source,language);validate_bindings(nodes,bindings,language)
        except ProfileError as error:rejections.append({'language':language,'source':source,'bindings':bindings,'profile_rejected':True,'reason':str(error),'native_language_invalid_claim':False})
        else:raise ValueError('Unsupported case accepted')
    if providers()!=identity or any(sha(ROOT/n)!=h for n,h in sources.items()):raise ValueError('Source/provider changed during execution')
    records=[]
    for language in LANGUAGES:
        selected=[r for r in evidence if r['language']==language]
        contract={'source':'Vue3.5.22 template-only .vue SFC' if language=='vue' else 'Angular4.4.7 HTML template; Angular2-family generic ng2 syntax catalog',
          'supported':['single unconditional HTML root','allowlisted paired lowercase elements','literal and exact-string interpolated text','literal or bound string HTML attributes','external Boolean v-if/*ngIf','bounded external string-list v-for/*ngFor with lexical alias','nested elements/directives'],
          'comparison':'HTML element/attribute/text trees; attribute order ignored; structural whitespace ignored per comparator; SSR comments and Angular scoped style metadata omitted',
          'limits':{'source_UTF8_bytes':65536,'depth':16,'string_characters':4096,'loop_items':16,'expanded_IR_nodes':4096,'USL_ops':2000000,'USL_timeout_seconds':4},
          'angular_catalog_audit':'ng2 is Pygments Angular2Lexer generic template syntax; html+ng2 delegates same Angular2 syntax to HTML lexer. Same supported compiler semantics, separate catalog evidence; not AngularJS1 or TypeScript source translation.',
          'vue_catalog_audit':'Pygments VueLexer describes .vue Single-File Components. Real upstream SFC parse plus SSR; template-only SFC subset, script/style blocks fail closed.'}
        records.append({'catalog_id':language,'scoped_profile_validated':True,'full_standard_qualified':False,'exact_profile':contract['source']+'; '+', '.join(contract['supported']),
          'profile_contract':contract,'cases':len(selected),'native_executions':len(selected),'native_processes':1,'usl_executions':len(selected),
          'native_unit':'fresh upstream SSR render observations; one Node process per catalog ID','source_sha256':sources,'toolchain':native[language]['toolchain'],'native_execution_receipt':native[language]['execution_receipt'],
          'provider_lock_sha256':identity['lock_sha256'],'provider_tree_receipt_sha256':sha(ROOT/'providers/IDENTITY.json'),
          'open_obligations':['Full Vue3.5/Angular4 grammar, JavaScript/TypeScript expressions, scoping/type/effect and runtime semantics','Components, modules, dependency injection, lifecycle, event/two-way bindings, arbitrary directives/pipes, services and client DOM/reactivity','Vue SFC scripts/styles/compile-time features and Angular AOT/compiler diagnostics outside selected profile','Full standard libraries/platform/ABI/interoperability and normative conformance suites','Independent full-profile review and universal correctness; finite intent examples are not original natural-language intent proofs'],
          'records':selected})
    summary={'scoped_profile_validated':True,'new_original_catalog_IDs':len(LANGUAGES),'fresh_native_render_observations':len(evidence),'fresh_native_processes':len(LANGUAGES),'fresh_USL_executions':len(evidence),'unsupported_cases_rejected':len(rejections),
      'all_logical_case_actors_started_before_release':all_started,'peak_live_logical_case_actors':peak,'native_execution_evidence_replayed':False,'full_standards_qualified':0,'seconds':time.perf_counter()-started}
    report={'schema':'usl.web-templates-scoped-native-usl.v1','summary':summary,'resource_admission':admission,'records':records,'unsupported_rejections':rejections,'provider_identity':identity,'USL_runtime_sha256':sha(source_root/'usl_systems/language.py')}
    (output/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary));return report
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('results'));a=p.parse_args();asyncio.run(execute(a.source_root,a.output))
