'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const provider=path.join(__dirname,'providers/node_modules');
const req=(s)=>require(path.join(provider,s));
async function main(){
 const rows=JSON.parse(fs.readFileSync(0,'utf8'));const observations=[];let angularInitialized=false;
 for(const row of rows){
  let output;
  if(row.language==='vue'){
   const vue=req('vue'),sfc=req('@vue/compiler-sfc'),ssr=req('@vue/server-renderer');
   const parsed=sfc.parse(row.source,{filename:'input.vue'});
   if(parsed.errors.length||parsed.descriptor.script||parsed.descriptor.scriptSetup||parsed.descriptor.styles.length||!parsed.descriptor.template)throw Error('Not template-only Vue SFC');
   output=await ssr.renderToString(vue.createSSRApp({template:parsed.descriptor.template.content,data:()=>row.bindings}));
  }else{
   req('reflect-metadata');req('zone.js/dist/zone-node');
   const core=req('@angular/core'),browser=req('@angular/platform-browser'),server=req('@angular/platform-server');req('@angular/compiler');
   if(!angularInitialized){core.enableProdMode();angularInitialized=true;}
   function App(){Object.assign(this,row.bindings);}
   core.Component({selector:'usl-root',template:row.source})(App);
   function Module(){}
   core.NgModule({imports:[browser.BrowserModule.withServerTransition({appId:'usl'}),server.ServerModule],declarations:[App],bootstrap:[App]})(Module);
   output=await server.renderModule(Module,{document:'<usl-root></usl-root>',url:'http://localhost/'});
   const match=output.match(/<usl-root\b[^>]*>([\s\S]*)<\/usl-root>/);if(!match)throw Error('Missing rendered component root');output=match[1];
  }
  observations.push({id:row.id,output,accepted:true});
 }
 process.stdout.write(JSON.stringify({observations,toolchain:{node:process.version,executable:process.execPath,versions:{vue:'3.5.22',angular:'4.4.7'}},physical_processes:1}));
}
main().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1});
