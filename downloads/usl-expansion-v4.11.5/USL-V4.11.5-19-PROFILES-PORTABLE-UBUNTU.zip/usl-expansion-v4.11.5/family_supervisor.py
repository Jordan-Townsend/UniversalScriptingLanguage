"""Linux-only exclusive family-process tree owner and orphan reaper.

The supervisor is a dedicated process. It creates exactly one primary process,
sets PR_SET_CHILD_SUBREAPER before that creation, and owns every descendant of
that process, including descendants which start a new session. No subreaper flag
or waitpid(-1) is applied to the importing coordinator or its unrelated children.
"""
from __future__ import annotations
import ctypes
import errno
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

PR_SET_CHILD_SUBREAPER=36
PR_SET_PDEATHSIG=1


def identity(pid):
    """PID plus Linux start-time avoids signaling a reused process identity."""
    try:
        tail=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'state':tail[0],'ppid':int(tail[1]),'start_time':int(tail[19])}
    except (OSError,ValueError,IndexError):
        return None


def descendants(parent):
    entries={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            item=identity(int(path.name))
            if item is not None:entries[item['pid']]=item
    owned={parent};result={};changed=True
    while changed:
        changed=False
        for pid,item in entries.items():
            if pid not in owned and item['ppid'] in owned:
                owned.add(pid);result[pid]=item;changed=True
    return result


def signal_identity(item,signum):
    current=identity(item['pid'])
    if current is None or current['start_time']!=item['start_time'] or current['state']=='Z':return False
    try:os.kill(item['pid'],signum);return True
    except ProcessLookupError:return False


def reap_adopted():
    count=0
    while True:
        try:
            pid,status=os.waitpid(-1,os.WNOHANG)
            if pid==0:return count
            count+=1
        except ChildProcessError:return count
        except InterruptedError:continue


def drain_owned(deadline_seconds=3.0):
    started=time.monotonic();signaled=set();reaped=0
    while True:
        reaped+=reap_adopted();owned=descendants(os.getpid())
        live=[p for p in owned.values() if p['state']!='Z']
        if not owned:return {'remaining_owned_processes':0,'identities_signaled':len(signaled),'adopted_children_reaped':reaped}
        elapsed=time.monotonic()-started
        if elapsed>=deadline_seconds:
            return {'remaining_owned_processes':len(owned),'identities_signaled':len(signaled),'adopted_children_reaped':reaped}
        sig=signal.SIGTERM if elapsed<0.25 else signal.SIGKILL
        for item in live:
            if signal_identity(item,sig):signaled.add((item['pid'],item['start_time']))
        # Parents may die while their detached children are being adopted. Keep
        # the subreaper alive, rescan, and reap until the whole owned tree drains.
        time.sleep(0.01)


def main(arguments):
    if arguments and arguments[0]=='--':arguments=arguments[1:]
    if not arguments or sys.platform!='linux':
        print('Linux family supervisor requires a command',file=sys.stderr);return 125
    stopping=[None]
    def stop(signum,frame):stopping[0]=signum
    for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,stop)
    libc=ctypes.CDLL(None,use_errno=True)
    original_parent=os.getppid()
    if libc.prctl(PR_SET_CHILD_SUBREAPER,1,0,0,0)!=0:
        print('Cannot establish Linux child subreaper: '+str(ctypes.get_errno()),file=sys.stderr);return 125
    # A coordinator which dies after setup still requests orderly tree cleanup.
    if libc.prctl(PR_SET_PDEATHSIG,signal.SIGTERM,0,0,0)!=0:
        print('Cannot establish parent-death cleanup signal',file=sys.stderr);return 125
    if os.getppid()!=original_parent:stopping[0]=signal.SIGTERM
    primary=None;code=125
    try:
        if stopping[0] is None:
            primary=subprocess.Popen(arguments,start_new_session=True,stdin=subprocess.DEVNULL)
            while stopping[0] is None:
                observed=primary.poll()
                if observed is not None:
                    code=observed;break
                time.sleep(0.01)
        if stopping[0] is not None:code=128+stopping[0]
    except BaseException as exc:
        print('Family supervisor primary failure: '+type(exc).__name__+': '+str(exc),file=sys.stderr)
        code=125
    finally:
        cleanup=drain_owned()
        if primary is not None and primary.returncode is None:
            try:primary.wait(timeout=0.1)
            except subprocess.TimeoutExpired:pass
        receipt={'schema':'usl.linux.family-supervisor.v1','subreaper_established':True,
                 'primary_exit_status':code,'stop_signal':stopping[0],
                 'ownership':'exclusive descendants of dedicated per-family supervisor',**cleanup}
        print('[usl-family-supervisor]'+json.dumps(receipt,sort_keys=True),file=sys.stderr,flush=True)
    if cleanup['remaining_owned_processes']!=0:return 125
    return code if code>=0 else 128-code


if __name__=='__main__':sys.exit(main(sys.argv[1:]))
