"""Fresh native compute-shader dispatch versus emitted USL and independent intent."""
import argparse,hashlib,itertools,json,os,random,subprocess,sys,time
from pathlib import Path
from shader_profile import parse,translate,native_source,Unsupported
from restore import restore,sha
from proofs import check as prove_translation
ROOT=Path(__file__).resolve().parent
MASK=2**32-1
# These independently authored Python functions specify expected behavior; they do
# not evaluate or walk the shader IR or reuse the translation emitter.
SPECS=[
 ('add','x + y',lambda x,y:(x+y)&MASK),
 ('subtract','x - y',lambda x,y:(x-y)&MASK),
 ('multiply','x * y',lambda x,y:(x*y)&MASK),
 ('precedence','x + y * 3u',lambda x,y:(x+((y*3)&MASK))&MASK),
 ('grouping','(x + y) * 3u',lambda x,y:(((x+y)&MASK)*3)&MASK),
 ('negate','-x',lambda x,y:(-x)&MASK),
 ('complement','~x',lambda x,y:MASK-x),
 ('shift_zero','x << 0u',lambda x,y:x),
 ('shift_left','x << 1u',lambda x,y:(x*2)&MASK),
 ('shift_top','x << 31u',lambda x,y:(2**31 if x%2 else 0)),
 ('shift_right','x >> 1u',lambda x,y:x//2),
 ('top_bit','x >> 31u',lambda x,y:int(x>=2**31)),
 ('divide','x / 3u',lambda x,y:x//3),
 ('remainder','x % 7u',lambda x,y:x%7),
 ('minimum','min(x,y)',lambda x,y:x if x<=y else y),
 ('maximum','max(x,y)',lambda x,y:y if x<=y else x),
 ('clamp','clamp(x,7u,100u)',lambda x,y:7 if x<7 else 100 if x>100 else x),
 ('conditional','x < y ? x : y',lambda x,y:x if x<y else y),
 ('not_equal','!(x == y) ? 1u : 0u',lambda x,y:int(x!=y)),
 ('conjunction','(x < y && y > 3u) ? x : y',lambda x,y:x if x<y and y>3 else y),
 ('disjunction','x == y || x == 0u ? y : x',lambda x,y:y if x==y or x==0 else x),
 ('nested_true','x < y ? x == 0u ? 7u : 9u : 11u',lambda x,y:(7 if x==0 else 9) if x<y else 11),
 ('nested_false','x < y ? 7u : y < 3u ? 8u : 9u',lambda x,y:7 if x<y else 8 if y<3 else 9),
 ('wrapped_divide','(x - y) / 13u',lambda x,y:((x-y)&MASK)//13),
 ('comparison_precedence','x + 1u >= y * 3u ? (x % 3u) : (y % 5u)',lambda x,y:x%3 if ((x+1)&MASK)>=((y*3)&MASK) else y%5),
]
VALUES=[0,1,2,7,31,2**31-1,2**31,MASK-1,MASK]
def inputs():
 pairs=[list(p) for p in itertools.product(VALUES,repeat=2)]
 rng=random.Random(0x51514115);pairs.extend([[rng.randrange(2**32),rng.randrange(2**32)] for _ in range(32)])
 return pairs

def shader_source(expression,language):return ('#version 450\n' if language=='glsl' else '')+'uint evaluate(uint x, uint y) { return '+expression+'; }\n'
def write(path,data):Path(path).write_text(json.dumps(data,indent=2)+'\n')
def run(source_root,output):
 start=time.perf_counter();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
 sys.path.insert(0,str(Path(source_root).resolve()));import usl_systems.language as runtime
 if sha(runtime.__file__)!='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc':raise ValueError('USL runtime identity differs')
 binary,compiler,icd,identity=restore(output/'host');env=dict(os.environ,VK_ICD_FILENAMES=str(icd));env.pop('VK_DRIVER_FILES',None);env.pop('VK_ADD_DRIVER_FILES',None)
 pairs=inputs();stdin=' '.join(str(p[0]) for p in pairs)+'\n'+' '.join(str(p[1]) for p in pairs)+'\n';records=[];all_cases=[];native_rejections=[];proof_records=[]
 for language in ['glsl','hlsl']:
  directory=output/language;directory.mkdir(exist_ok=True);language_cases=[]
  for name,expression,oracle in SPECS:
   source=shader_source(expression,language);ir=parse(source,language);usl=translate(source,language,pairs)
   proof=prove_translation(ir,usl,runtime)
   if proof['result']!='unsat':raise ValueError('IR/generated AST equivalence not established '+language+'/'+name+': '+proof['result'])
   (directory/(name+'.smt2')).write_text(proof.pop('SMT2'));proof_records.append(dict(language=language,case=name,**proof))
   sp=directory/(name+('.comp' if language=='glsl' else '.comp.hlsl'));sp.write_text(native_source(source,language,len(pairs)));(directory/(name+'.source')).write_text(source);(directory/(name+'.usl')).write_text(usl);write(directory/(name+'.IR.json'),ir)
   spv=directory/(name+'.spv');command=[compiler,'-V','--target-env','vulkan1.0','-S','comp','-e','main']+(['-D'] if language=='hlsl' else [])+[str(sp),'-o',str(spv)]
   compiled=subprocess.run(command,text=True,capture_output=True,timeout=30);(directory/(name+'.compile.log')).write_text(compiled.stdout+compiled.stderr)
   if compiled.returncode:raise ValueError('Native compiler rejected '+language+'/'+name+': '+compiled.stderr+compiled.stdout)
   proc=subprocess.run([str(binary),str(spv),str(len(pairs))],input=stdin,capture_output=True,text=True,env=env,timeout=30)
   (directory/(name+'.native.log')).write_text(proc.stderr);(directory/(name+'.native.out')).write_text(proc.stdout)
   if proc.returncode:raise ValueError('Native Vulkan dispatch failed '+language+'/'+name+': '+proc.stderr)
   native=[int(n) for n in proc.stdout.splitlines()];executed=runtime.Interpreter(max_ops=1000000,timeout=20).run(usl);generated=executed.variables['result'];expected=[oracle(x,y) for x,y in pairs]
   if native!=expected or generated!=expected:raise ValueError('Intent/native/USL mismatch '+language+'/'+name)
   for i,(x,y) in enumerate(pairs):language_cases.append({'case':name,'x':x,'y':y,'independent_intent':expected[i],'native_observed':native[i],'USL_observed':generated[i],'source_sha256':sha(directory/(name+'.source')),'SPIRV_sha256':sha(spv),'USL_sha256':sha(directory/(name+'.usl'))})
  for name,broken in [('scope','uint evaluate(uint x,uint y){return missing;}'),('call','uint evaluate(uint x,uint y){return nonexistent(x,y);}')]:
   sp=directory/('bad-'+name+('.comp' if language=='glsl' else '.comp.hlsl'));sp.write_text(('#version 450\n' if language=='glsl' else '')+broken+('\nlayout(local_size_x=1) in; void main(){uint q=evaluate(1u,2u);}' if language=='glsl' else '\n[numthreads(1,1,1)]void main(uint3 id:SV_DispatchThreadID){uint q=evaluate(id.x,id.y);}'))
   command=[compiler,'-V','-S','comp','-e','main']+(['-D'] if language=='hlsl' else [])+[str(sp),'-o',str(directory/'bad.spv')];p=subprocess.run(command,text=True,capture_output=True,timeout=30);(directory/('bad-'+name+'.log')).write_text(p.stdout+p.stderr)
   if p.returncode==0:raise ValueError('Native invalid-source negative control accepted')
   native_rejections.append({'language':language,'case':name,'exit_status':p.returncode,'source_sha256':sha(sp),'diagnostic_sha256':sha(directory/('bad-'+name+'.log'))})
  write(directory/'cases.json',language_cases);all_cases.extend(language_cases)
  records.append({'catalog_id':language,'scoped_profile_validated':True,'full_standard_qualified':False,'exact_profile':('GLSL #version 450' if language=='glsl' else 'glslang 15.2.0 HLSL SPIR-V dialect')+' pure uint evaluate(uint,uint), explicit uint32 literals, wrapped + - *, unary + - ~, constant nonzero / %, defined 0..31 shifts, comparisons, Boolean conditionals, min/max/clamp; fixed Vulkan 1.0 CPU compute harness','cases':len(language_cases),'native_executions':len(language_cases),'usl_executions':len(SPECS),'native_process_invocations':len(SPECS),'native_observation_unit':'one uint32 result from a freshly dispatched Vulkan invocation; separate process per source expression','compiler_process_invocations':len(SPECS)+2,'open_obligations':['General GLSL/HLSL syntax and standard/dialect conformance beyond the declared pure uint32 function subset','Floating point, vectors/matrices, textures, graphics stages, resources, workgroup memory, atomics and barriers','General control flow, functions, arrays, modules, libraries and host ABI interoperability','Parser/emitter/runtime/compiler/Vulkan correctness proofs and complete normative conformance suite','Other drivers/devices/platforms, actual GPU execution, proprietary DXC/DirectX host and fresh standalone install']})
 payload={'records':records,'toolchain':identity,'USL_runtime_sha256':sha(runtime.__file__),'source_sha256':{p.name:sha(p) for p in sorted(ROOT.glob('*.py'))},'native_rejection_controls':native_rejections,'IR_to_actual_generated_AST_equivalence':proof_records,'fresh_native_observations':len(all_cases),'fresh_Vulkan_dispatch_processes':2*len(SPECS),'fresh_USL_interpreter_runs':2*len(SPECS),'all_cases':all_cases,'execution_evidence_cached':False,'full_standard_qualified':False,'elapsed_seconds':time.perf_counter()-start};write(output/'results.json',payload)
 return payload
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--source-root',required=True);a.add_argument('--output',required=True);args=a.parse_args();p=run(args.source_root,args.output);print(json.dumps({'IDs':[r['catalog_id'] for r in p['records']],'cases':p['fresh_native_observations'],'Vulkan_processes':p['fresh_Vulkan_dispatch_processes'],'USL_runs':p['fresh_USL_interpreter_runs'],'elapsed_seconds':p['elapsed_seconds']}))
