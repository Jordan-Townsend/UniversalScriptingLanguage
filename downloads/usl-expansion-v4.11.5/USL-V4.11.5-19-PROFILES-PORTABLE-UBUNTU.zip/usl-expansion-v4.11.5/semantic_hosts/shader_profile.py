"""GLSL 4.50 / glslang HLSL unsigned-32 pure compute-kernel profile.
The entire user source is parsed before an independently fixed native harness is added.
No source expression is evaluated by Python.
"""
import re
U32=2**32
class Unsupported(ValueError):pass
# Every token is consumed, including operators with maximal munch.
TOKEN=re.compile(r'\s*(?:(\d+[uU]?)|([A-Za-z_][A-Za-z_0-9]*)|(\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\||[()+*%/,?:!~<>-]))')
PREC={'||':1,'&&':2,'==':3,'!=':3,'<':4,'>':4,'<=':4,'>=':4,'<<':5,'>>':5,'+':6,'-':6,'*':7,'/':7,'%':7}
class Parser:
 def __init__(self,expression):
  self.tokens=[];pos=0
  while expression[pos:].strip():
   m=TOKEN.match(expression,pos)
   if not m:raise Unsupported('unrecognized expression token')
   self.tokens.append(next(v for v in m.groups() if v is not None));pos=m.end()
  if len(self.tokens)>96:raise Unsupported('expression token limit')
  self.i=0
 def peek(self):return self.tokens[self.i] if self.i<len(self.tokens) else None
 def pop(self):
  t=self.peek()
  if t is None:raise Unsupported('unexpected end')
  self.i+=1;return t
 def need(self,t):
  if self.pop()!=t:raise Unsupported('expected '+t)
 def expression(self,minimum=0,depth=0):
  if depth>12:raise Unsupported('expression depth')
  t=self.pop()
  if t in ['+','-','!','~']:
   child=self.expression(8,depth+1)
   if child['type']!=('bool' if t=='!' else 'uint'):raise Unsupported('unary operand type')
   node={'op':t+'unary','args':[child],'type':child['type']}
  elif t=='(':
   node=self.expression(0,depth+1);self.need(')')
  elif re.fullmatch(r'\d+[uU]?',t):
   digits=t.rstrip('uU')
   if len(digits)>10 or (len(digits)>1 and digits.startswith('0')):raise Unsupported('bounded decimal spelling; octal/leading zeros outside profile')
   value=int(digits)
   # Native GLSL unsuffixed decimal literal > INT32_MAX is not uniformly uint.
   if value>=U32 or (not t.endswith(('u','U')) and value>=2**31):raise Unsupported('uint32 literal or signed-literal boundary')
   # Require uint suffix except 0: avoids mixed signed/unsigned overload choices.
   if not t.endswith(('u','U')):raise Unsupported('explicit unsigned literal suffix required')
   node={'op':'literal','value':value,'type':'uint'}
  elif t in ['x','y']:node={'op':'variable','name':t,'type':'uint'}
  elif t in ['min','max','clamp']:
   self.need('(');args=[self.expression(0,depth+1)]
   while self.peek()==',':self.pop();args.append(self.expression(0,depth+1))
   self.need(')')
   if len(args)!=(3 if t=='clamp' else 2) or any(a['type']!='uint' for a in args):raise Unsupported('builtin overload')
   if t=='clamp' and (args[1]['op']!='literal' or args[2]['op']!='literal' or args[1]['value']>args[2]['value']):raise Unsupported('clamp literal ordered bounds required')
   node={'op':t,'args':args,'type':'uint'}
  else:raise Unsupported('identifier or expression form')
  while self.peek() in PREC and PREC[self.peek()]>=minimum:
   op=self.pop();right=self.expression(PREC[op]+1,depth+1)
   if op in ['&&','||']:
    if node['type']!='bool' or right['type']!='bool':raise Unsupported('Boolean operands required')
    typ='bool'
   else:
    if node['type']!='uint' or right['type']!='uint':raise Unsupported('uint operands required')
    typ='bool' if op in ['<','>','<=','>=','==','!='] else 'uint'
   if op in ['/','%'] and (right['op']!='literal' or right['value']==0):raise Unsupported('nonzero literal divisor required')
   if op in ['<<','>>'] and (right['op']!='literal' or right['value']>=32):raise Unsupported('literal shift 0..31 required')
   node={'op':op,'args':[node,right],'type':typ}
  if minimum==0 and self.peek()=='?':
   self.pop();yes=self.expression(0,depth+1);self.need(':');no=self.expression(0,depth+1)
   if node['type']!='bool' or yes['type']!=no['type']:raise Unsupported('conditional types')
   node={'op':'conditional','args':[node,yes,no],'type':yes['type']}
  return node

def parse(source,language):
 if language not in ['glsl','hlsl']:raise Unsupported('language')
 if type(source) is not str or len(source)>4096 or not source.isascii() or any(ord(c)<32 and c not in '\t\r\n' or ord(c)==127 for c in source):raise Unsupported('source size/type')
 if language=='glsl':
  prefix=re.match(r'\s*#version[ \t]+450[ \t]*\n',source)
  if not prefix:raise Unsupported('GLSL #version 450 required')
  source=source[prefix.end():]
 m=re.fullmatch(r'\s*uint\s+evaluate\s*\(\s*uint\s+x\s*,\s*uint\s+y\s*\)\s*\{\s*return\s+([^{};]+);\s*\}\s*',source)
 if not m:raise Unsupported('exact pure uint evaluate(uint x,uint y) single return required')
 parser=Parser(m[1]);ir=parser.expression()
 if parser.peek() is not None or ir['type']!='uint':raise Unsupported('complete uint return expression required')
 return ir

def emit_expression(ir):
 op=ir['op'];args=[emit_expression(n) for n in ir.get('args',[])]
 if op=='literal':return str(ir['value'])
 if op=='variable':return 'arg_'+ir['name']
 if op in ['+','-','*']:return '(('+args[0]+' '+op+' '+args[1]+') % 4294967296)'
 if op in ['/','%']:return '('+args[0]+(' // ' if op=='/' else ' % ')+args[1]+')'
 if op in ['<<','>>']:return '(('+args[0]+(' * ' if op=='<<' else ' // ')+str(2**ir['args'][1]['value'])+')'+(' % 4294967296)' if op=='<<' else ')')
 if op in ['<','>','<=','>=','==','!=']:return '('+args[0]+' '+op+' '+args[1]+')'
 if op in ['&&','||']:return '('+args[0]+(' and ' if op=='&&' else ' or ')+args[1]+')'
 if op=='!unary':return '(not '+args[0]+')'
 if op=='+unary':return args[0]
 if op=='-unary':return '((-'+args[0]+') % 4294967296)'
 if op=='~unary':return '(4294967295 - '+args[0]+')'
 if op=='conditional':return '('+args[1]+' if '+args[0]+' else '+args[2]+')'
 if op in ['min','max']:return op+'('+', '.join(args)+')'
 if op=='clamp':return 'min(max('+args[0]+', '+args[1]+'), '+args[2]+')'
 raise Unsupported('IR node')

def translate(source,language,inputs):
 ir=parse(source,language)
 if type(inputs) is not list or not 1<=len(inputs)<=4096:raise Unsupported('input list length')
 for pair in inputs:
  if type(pair) is not list or len(pair)!=2 or any(type(v) is not int or not 0<=v<U32 for v in pair):raise Unsupported('exact uint32 pair required')
 text='// Typed uint32 shader expression; per-operation wrap; CPU Vulkan is checked separately.\nfunction shader_evaluate(arg_x, arg_y):\n    return '+emit_expression(ir)+'\nlet result = []\n'
 for x,y in inputs:text+='result = result + [shader_evaluate('+str(x)+', '+str(y)+')]\n'
 return text

def native_source(source,language,count):
 parse(source,language)
 if type(count) is not int or not 1<=count<=4096:raise Unsupported('dispatch count')
 if language=='glsl':return source+'\nlayout(local_size_x=1) in;\nlayout(set=0,binding=0,std430) buffer Data {uint data[];};\nvoid main(){uint i=gl_GlobalInvocationID.x;data['+str(2*count)+'u+i]=evaluate(data[i],data['+str(count)+'u+i]);}\n'
 return source+'\nRWStructuredBuffer<uint> data : register(u0);\n[numthreads(1,1,1)]\nvoid main(uint3 id : SV_DispatchThreadID){uint i=id.x;data['+str(2*count)+'u+i]=evaluate(data[i],data['+str(count)+'u+i]);}\n'
