; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x63 (ite (and (< x y) (< 3 y)) x y)))
(and (distinct ?x63 ?x63) true)))
(check-sat)
