; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x60 (ite (< x y) (ite (= 0 x) 7 9) 11)))
(and (distinct ?x60 ?x60) true)))
(check-sat)
