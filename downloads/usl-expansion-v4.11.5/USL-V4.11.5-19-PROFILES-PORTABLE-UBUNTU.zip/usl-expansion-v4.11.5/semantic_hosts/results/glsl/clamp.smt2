; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let (($x27 (<= 7 x)))
(let ((?x20 (ite $x27 x 7)))
(let ((?x47 (ite (>= 100 ?x20) ?x20 100)))
(let ((?x25 (ite (> 7 x) 7 (ite (< 100 x) 100 x))))
(and (distinct ?x25 ?x47) true))))))
(check-sat)
