; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x57 (ite (< x y) x y)))
(and (distinct ?x57 ?x57) true)))
(check-sat)
