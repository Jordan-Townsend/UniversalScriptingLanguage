; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x67 (mod y 5)))
(let ((?x47 (mod x 3)))
(let ((?x43 (ite (>= (mod (+ x 1) 4294967296) (mod (* y 3) 4294967296)) ?x47 ?x67)))
(and (distinct ?x43 ?x43) true)))))
(check-sat)
