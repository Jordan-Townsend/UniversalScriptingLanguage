; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x22 (ite (or (= x y) (= 0 x)) y x)))
(and (distinct ?x22 ?x22) true)))
(check-sat)
