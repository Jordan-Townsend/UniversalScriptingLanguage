; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x37 (mod y 5)))
(let ((?x41 (mod x 3)))
(let ((?x35 (ite (>= (mod (+ x 1) 4294967296) (mod (* y 3) 4294967296)) ?x41 ?x37)))
(and (distinct ?x35 ?x35) true)))))
(check-sat)
