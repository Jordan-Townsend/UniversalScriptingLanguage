; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x13 (mod (* x 2147483648) 4294967296)))
(and (distinct ?x13 ?x13) true)))
(check-sat)
