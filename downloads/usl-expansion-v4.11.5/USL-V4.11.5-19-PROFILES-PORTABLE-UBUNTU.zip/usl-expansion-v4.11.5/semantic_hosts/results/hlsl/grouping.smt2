; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x29 (mod (* (mod (+ x y) 4294967296) 3) 4294967296)))
(and (distinct ?x29 ?x29) true)))
(check-sat)
