; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x71 (ite (and (< x y) (< 3 y)) x y)))
(and (distinct ?x71 ?x71) true)))
(check-sat)
