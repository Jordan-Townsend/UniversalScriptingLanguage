; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x41 (ite (>= x y) x y)))
(and (distinct ?x41 ?x41) true)))
(check-sat)
