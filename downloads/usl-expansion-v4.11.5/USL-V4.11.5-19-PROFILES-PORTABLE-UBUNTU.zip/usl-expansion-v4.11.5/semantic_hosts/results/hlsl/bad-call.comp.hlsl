uint evaluate(uint x,uint y){return nonexistent(x,y);}
[numthreads(1,1,1)]void main(uint3 id:SV_DispatchThreadID){uint q=evaluate(id.x,id.y);}