; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x67 (mod (+ x (mod (* y 3) 4294967296)) 4294967296)))
(and (distinct ?x67 ?x67) true)))
(check-sat)
