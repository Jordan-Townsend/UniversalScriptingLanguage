; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let (($x62 (<= 7 x)))
(let ((?x58 (ite $x62 x 7)))
(let ((?x53 (ite (>= 100 ?x58) ?x58 100)))
(let ((?x40 (ite (> 7 x) 7 (ite (< 100 x) 100 x))))
(and (distinct ?x40 ?x53) true))))))
(check-sat)
