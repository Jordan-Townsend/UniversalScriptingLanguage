uint evaluate(uint x, uint y) { return x << 1u; }

RWStructuredBuffer<uint> data : register(u0);
[numthreads(1,1,1)]
void main(uint3 id : SV_DispatchThreadID){uint i=id.x;data[226u+i]=evaluate(data[i],data[113u+i]);}
