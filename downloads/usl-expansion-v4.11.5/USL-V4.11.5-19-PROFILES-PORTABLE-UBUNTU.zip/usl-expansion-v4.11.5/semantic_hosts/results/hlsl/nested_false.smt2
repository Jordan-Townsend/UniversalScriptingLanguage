; benchmark generated from python API
(set-info :status unknown)
(declare-fun x () Int)
(declare-fun y () Int)
(assert
 (>= x 0))
(assert
 (< x 4294967296))
(assert
 (>= y 0))
(assert
 (< y 4294967296))
(assert
 (let ((?x56 (ite (< x y) 7 (ite (> 3 y) 8 9))))
(and (distinct ?x56 ?x56) true)))
(check-sat)
