"""Scoped IR-denotation / actual generated AST equivalence, conditional on parser/runtime.
This does not prove complete source-language semantics or the native compiler.
"""
import ast
import z3
LIMIT=2**32

def source_denotation(ir,variables):
 op=ir['op'];a=[source_denotation(x,variables) for x in ir.get('args',[])]
 if op=='literal':return z3.IntVal(ir['value'])
 if op=='variable':return variables[ir['name']]
 if op=='+':return (a[0]+a[1])%LIMIT
 if op=='-':return (a[0]-a[1])%LIMIT
 if op=='*':return (a[0]*a[1])%LIMIT
 if op=='/':return a[0]/a[1]
 if op=='%':return a[0]%a[1]
 if op=='<<':return (a[0]*(2**ir['args'][1]['value']))%LIMIT
 if op=='>>':return a[0]/(2**ir['args'][1]['value'])
 if op=='<':return a[0]<a[1]
 if op=='>':return a[0]>a[1]
 if op=='<=':return a[0]<=a[1]
 if op=='>=':return a[0]>=a[1]
 if op=='==':return a[0]==a[1]
 if op=='!=':return a[0]!=a[1]
 if op=='&&':return z3.And(a[0],a[1])
 if op=='||':return z3.Or(a[0],a[1])
 if op=='!unary':return z3.Not(a[0])
 if op=='+unary':return a[0]
 if op=='-unary':return (-a[0])%LIMIT
 if op=='~unary':return LIMIT-1-a[0]
 if op=='conditional':return z3.If(*a)
 if op=='min':return z3.If(a[0]<=a[1],a[0],a[1])
 if op=='max':return z3.If(a[0]>=a[1],a[0],a[1])
 if op=='clamp':return z3.If(a[0]<a[1],a[1],z3.If(a[0]>a[2],a[2],a[0]))
 raise ValueError('Unmodeled source IR')

def generated_denotation(node,variables):
 if isinstance(node,ast.Constant) and type(node.value) is int:return z3.IntVal(node.value)
 if isinstance(node,ast.Name) and node.id in variables:return variables[node.id]
 if isinstance(node,ast.BinOp):
  # Z3 integer division is total, while USL division by zero raises. Every
  # accepted emitter denominator is an explicit strictly positive literal.
  if isinstance(node.op,(ast.FloorDiv,ast.Mod)) and not (isinstance(node.right,ast.Constant) and type(node.right.value) is int and node.right.value>0):
   raise ValueError('Actual generated division/remainder needs a positive literal denominator')
  a=generated_denotation(node.left,variables);b=generated_denotation(node.right,variables)
  if isinstance(node.op,ast.Add):return a+b
  if isinstance(node.op,ast.Sub):return a-b
  if isinstance(node.op,ast.Mult):return a*b
  if isinstance(node.op,ast.Mod):return a%b
  if isinstance(node.op,ast.FloorDiv):return a/b
 if isinstance(node,ast.UnaryOp):
  a=generated_denotation(node.operand,variables)
  if isinstance(node.op,ast.USub):return -a
  if isinstance(node.op,ast.UAdd):return a
  if isinstance(node.op,ast.Not):return z3.Not(a)
 if isinstance(node,ast.Compare) and len(node.ops)==1:
  a=generated_denotation(node.left,variables);b=generated_denotation(node.comparators[0],variables);op=node.ops[0]
  if isinstance(op,ast.Eq):return a==b
  if isinstance(op,ast.NotEq):return a!=b
  if isinstance(op,ast.Lt):return a<b
  if isinstance(op,ast.LtE):return a<=b
  if isinstance(op,ast.Gt):return a>b
  if isinstance(op,ast.GtE):return a>=b
 if isinstance(node,ast.BoolOp):
  a=[generated_denotation(v,variables) for v in node.values]
  if isinstance(node.op,ast.And):return z3.And(*a)
  if isinstance(node.op,ast.Or):return z3.Or(*a)
 if isinstance(node,ast.IfExp):return z3.If(generated_denotation(node.test,variables),generated_denotation(node.body,variables),generated_denotation(node.orelse,variables))
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and len(node.args)==2 and not node.keywords:
  a,b=[generated_denotation(v,variables) for v in node.args]
  if node.func.id=='min':return z3.If(a<=b,a,b)
  if node.func.id=='max':return z3.If(a>=b,a,b)
 raise ValueError('Unmodeled actual generated AST')

def check(ir,usl,runtime):
 tree=runtime.parse(usl);functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
 if len(functions)!=1:raise ValueError('One generated function required')
 fn=functions[0]
 if len(fn.body)!=1 or not isinstance(fn.body[0],ast.Return) or [p.arg for p in fn.args.args]!=['arg_x','arg_y']:raise ValueError('Unexpected generated function contract')
 x,y=z3.Ints('x y');expected=source_denotation(ir,{'x':x,'y':y});actual=generated_denotation(fn.body[0].value,{'arg_x':x,'arg_y':y});solver=z3.Solver();solver.set(timeout=5000);solver.add(x>=0,x<LIMIT,y>=0,y<LIMIT,expected!=actual);result=solver.check()
 return {'result':str(result),'SMT2':solver.to_smt2(),'counterexample':str(solver.model()) if result==z3.sat else None,'claim':'Typed selected uint32 IR denotation equals actual emitted function return AST for all 2^64 uint32 argument pairs','assumptions':['Correct source-to-IR parser and selected source semantic model','Trusted Z3 integer arithmetic solver','USL implements modeled Python integer arithmetic/Boolean/conditional/builtin AST semantics'],'not_proved':['Parser correctness','USL interpreter correctness','Native GLSL/HLSL compiler or Vulkan implementation correctness','Independent-intent equivalence outside the authored finite native execution corpus','Full language standard conformance']}
