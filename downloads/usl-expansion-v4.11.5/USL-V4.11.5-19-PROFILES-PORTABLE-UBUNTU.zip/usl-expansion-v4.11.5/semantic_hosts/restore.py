"""Verify public text dependencies and retained upstream hosts; rebuild only host C runner."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
COMPILER_SHA='3a4fb1feabbe3f2a61a42f067d67c0d2ee6a982ea863fb02c66b7aa271f830eb'
SO_SHA='a9300a8616f7f765471b5feebe19ceeb4a5492ae69b6ec68589dd213c86c564b'
ICD_SHA='c9eef28b6b984fec220ef0abfecc40b502d46946706e47bfe97707027cb818bd'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def restore(output=None):
 for row in json.loads((ROOT/'references/HEADERS.json').read_text()):
  p=ROOT/'references'/row['file']
  if not p.is_file() or sha(p)!=row['sha256']:raise ValueError('Pinned Khronos header differs: '+str(p))
 compiler=shutil.which('glslangValidator');cc=shutil.which('gcc')
 if not compiler or sha(compiler)!=COMPILER_SHA:raise ValueError('Pinned glslang 15.2.0 compiler required')
 if not cc:raise ValueError('GCC C host compiler required')
 from provider_restore import restore_provider
 provider=restore_provider()
 icd=Path(os.environ.get('USL_VULKAN_ICD',str(provider/'vk_swiftshader_icd.json'))).resolve()
 # Khronos ICD format resolves library_path relative to this file, not cwd.
 if not icd.is_file() or sha(icd)!=ICD_SHA:raise ValueError('Pinned Chromium SwiftShader ICD JSON required')
 so=(icd.parent/json.loads(icd.read_text())['ICD']['library_path']).resolve()
 if sha(so)!=SO_SHA:raise ValueError('Pinned SwiftShader CPU Vulkan binary required')
 out=Path(output) if output else ROOT/'providers';out.mkdir(parents=True,exist_ok=True);binary=out/'vulkan_runner'
 command=[cc,'-std=c11','-O2','-Wall','-Wextra',str(ROOT/'vulkan_runner.c'),'-l:libvulkan.so.1','-o',str(binary)]
 proc=subprocess.run(command,text=True,capture_output=True,timeout=60)
 if proc.returncode:raise RuntimeError('Vulkan host build failed: '+proc.stderr[-3000:])
 identity={'compiler_path':compiler,'compiler_sha256':sha(compiler),'compiler_version':subprocess.check_output([compiler,'--version'],text=True),'ICD_path':str(icd),'ICD_sha256':sha(icd),'SwiftShader_path':str(so),'SwiftShader_sha256':sha(so),'host_source_sha256':sha(ROOT/'vulkan_runner.c'),'host_binary_sha256':sha(binary),'C_compiler_path':cc,'C_compiler_sha256':sha(cc),'C_compiler_version':subprocess.check_output([cc,'--version'],text=True).splitlines()[0],'command':command,'build_diagnostic':proc.stderr,'loader_dependencies':subprocess.check_output(['ldd',str(binary)],text=True),'native_binaries_in_source_package':False}
 (out/'RESTORE_RECEIPT.json').write_text(json.dumps(identity,indent=2)+'\n')
 return binary,compiler,icd,identity
if __name__=='__main__':
 b,c,i,identity=restore();print(json.dumps({'restored_host':str(b),'verified_shader_compiler':c,'verified_CPU_ICD':str(i)}))
