import copy,hashlib,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from shader_profile import parse,translate,native_source,Unsupported
from run import SPECS,inputs,shader_source
from proofs import check
from restore import restore
from provider_restore import authenticate,checked
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/usl-v4.10.0-clean-test')
sys.path.insert(0,str(BASE));import usl_systems.language as runtime
class ShaderProfiles(unittest.TestCase):
 def test_all_independent_intents_via_actual_USL(self):
  pairs=inputs()
  for language in ['glsl','hlsl']:
   for name,expr,oracle in SPECS:
    with self.subTest(language=language,case=name):self.assertEqual(runtime.Interpreter(max_ops=1000000,timeout=20).run(translate(shader_source(expr,language),language,pairs)).variables['result'],[oracle(x,y) for x,y in pairs])
 def test_all_actual_generated_AST_proofs(self):
  for name,expr,oracle in SPECS:
   source=shader_source(expr,'glsl');self.assertEqual(check(parse(source,'glsl'),translate(source,'glsl',[[0,0]]),runtime)['result'],'unsat',name)
 def test_missing_wrap_mutation_has_counterexample(self):
  source=shader_source('x + y','glsl');text=translate(source,'glsl',[[0,0]]).replace('((arg_x + arg_y) % 4294967296)','(arg_x + arg_y)')
  self.assertEqual(check(parse(source,'glsl'),text,runtime)['result'],'sat')
 def test_wrong_conditional_mutation_has_counterexample(self):
  source=shader_source('x < y ? x : y','glsl');text=translate(source,'glsl',[[0,0]]).replace('(arg_x < arg_y)','(arg_x > arg_y)')
  self.assertEqual(check(parse(source,'glsl'),text,runtime)['result'],'sat')
 def test_octal_and_oversized_literals_rejected(self):
  for expr in ['010u','00u','08u','09u','4294967296u','0xffffffffu','4294967295','1','9'*300+'u']:
   for lang in ['glsl','hlsl']:
    with self.subTest(expression=expr,language=lang):
     with self.assertRaises(Unsupported):parse(shader_source(expr,lang),lang)
  self.assertEqual(parse(shader_source('0U','glsl'),'glsl')['value'],0)
 def test_maximal_munch_increment_rejected(self):
  for expr in ['++x','--x','x++','x--','x+++y','x---y']:
   with self.assertRaises(Unsupported):parse(shader_source(expr,'glsl'),'glsl')
 def test_effectful_and_unsupported_programs_rejected(self):
  for body in ['return texture(a,b);','while(true) {} return x;','uint z=x; return z;','return x; return y;','return float(x);','return x & y;','return x / y;','return x % 0u;','return x << 32u;','return x >> y;','return clamp(x,100u,7u);','return __import__(x);','return !x;','return x < y;','return x ? y : 1u;','return x + (x < y);','return x 1u;']:
   with self.subTest(body=body):
    with self.assertRaises(Unsupported):parse('#version 450\nuint evaluate(uint x,uint y){'+body+'}','glsl')
  for suffix in ['\nvoid main(){}','\n#define x 9','\n// trailing comment unsupported']:
   with self.assertRaises(Unsupported):parse(shader_source('x','glsl')+suffix,'glsl')
 def test_unicode_source_rejected_before_native_disagreement(self):
  for expression in ['١u','２u','x\u00a0+y','x\u2003+y','x\v+y','x\f+y']+['x'+chr(i)+'+y' for i in range(28,32)]:
   for language in ['glsl','hlsl']:
    with self.subTest(expression=expression,language=language),self.assertRaises(Unsupported):parse(shader_source(expression,language),language)
 def test_actual_generated_undefined_division_rejected(self):
  source=shader_source('x + y','glsl');original=translate(source,'glsl',[[0,0]])
  for suffix in [' + 0 * (1 // 0)',' + 0 * (1 % 0)',' + 0 * (1 // arg_x)',' + 0 * (1 % arg_y)',' + 0 * (1 // -1)']:
   text=original.replace('return ((arg_x + arg_y) % 4294967296)','return ((arg_x + arg_y) % 4294967296)'+suffix)
   with self.subTest(suffix=suffix),self.assertRaises(ValueError):check(parse(source,'glsl'),text,runtime)
 def test_input_domain_exact_types_and_lengths(self):
  source=shader_source('x','glsl')
  for values in [[],[(1,2)],[[True,2]],[[-1,2]],[[2**32,0]],[[1]],[[1.0,2]],[[1,2,3]]]:
   with self.assertRaises(Unsupported):translate(source,'glsl',values)
 def test_size_and_depth_limits(self):
  for expr in ['('*20+'x'+')'*20,'+'.join(['x']*100)]:
   with self.assertRaises(Unsupported):parse(shader_source(expr,'glsl'),'glsl')
  with self.assertRaises(Unsupported):parse('x'*4097,'hlsl')
 def test_signature_index_and_package_pin_rejection(self):
  with tempfile.TemporaryDirectory() as d:
   out=Path(d);(out/'references').mkdir()
   for name in ['DEBIAN_INRELEASE.asc','DEBIAN_RELEASE.txt']:shutil.copyfile(ROOT/'references'/name,out/'references'/name)
   pin=json.loads((ROOT/'PROVIDER.json').read_text());(out/'PROVIDER.json').write_text(json.dumps(pin));bad=out/'index';bad.write_text('tampered')
   with self.assertRaises(ValueError):authenticate(root=out,index=bad)
   pin['Version']='forged';(out/'PROVIDER.json').write_text(json.dumps(pin))
   with self.assertRaises(ValueError):authenticate(root=out)
   signed=out/'references/DEBIAN_INRELEASE.asc';b=signed.read_bytes().replace(b'Hash: SHA256',b'Hash: SHA512');signed.write_bytes(b)
   # Preserve the outer pin to test unconditional cryptographic signature verification.
   pin['signed_release_sha256']=hashlib.sha256(b).hexdigest();(out/'PROVIDER.json').write_text(json.dumps(pin))
   with self.assertRaises((ValueError,subprocess.CalledProcessError)):authenticate(root=out)
 def test_provider_integrity_rejects_tampering(self):
  with self.assertRaises(ValueError):checked(b'broken','0'*64,6)
 def test_native_octal_regression_and_dialect_execution(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);binary,compiler,icd,identity=restore(d/'host');env=dict(os.environ,VK_ICD_FILENAMES=str(icd));env.pop('VK_DRIVER_FILES',None);env.pop('VK_ADD_DRIVER_FILES',None)
   for lang in ['glsl','hlsl']:
    # Native octal is outside our profile. Replace a valid decimal token only in native fixture.
    source=native_source(shader_source('8u',lang),lang,1).replace('return 8u','return 010u');p=d/('fixture.comp'+('.hlsl' if lang=='hlsl' else ''));p.write_text(source);spv=d/(lang+'.spv')
    compiled=subprocess.run([compiler,'-V','-S','comp','-e','main']+(['-D'] if lang=='hlsl' else [])+[str(p),'-o',str(spv)],text=True,capture_output=True,timeout=20);self.assertEqual(compiled.returncode,0,compiled.stdout+compiled.stderr)
    executed=subprocess.run([str(binary),str(spv),'1'],input='0 0\n',text=True,capture_output=True,env=env,timeout=20);self.assertEqual(executed.returncode,0,executed.stderr);self.assertEqual(executed.stdout.strip(),'8');self.assertIn('type=4',executed.stderr)
if __name__=='__main__':unittest.main()
