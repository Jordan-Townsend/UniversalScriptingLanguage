"""Authenticated exact-package extraction, limited to three named regular files."""
import hashlib,io,json,lzma,re,subprocess,tarfile,tempfile,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FIELDS=('Package','Version','Filename','Size','SHA256')
def sha(data):return hashlib.sha256(data).hexdigest()
def checked(data,digest,size):
 if sha(data)!=digest or len(data)!=int(size):raise ValueError('Provider integrity mismatch')
 return data
def fetch(url):
 with urllib.request.urlopen(url,timeout=45) as r:return r.read()
def release_item(text,path):
 section=text.split('\nSHA256:\n',1)[1]
 for line in section.splitlines():
  if not line.startswith(' '):break
  p=line.split()
  if len(p)==3 and p[2]==path and re.fullmatch('[a-f0-9]{64}',p[0]):return p[0],int(p[1])
 raise ValueError('Missing signed release SHA256 entry')
def authenticate(root=ROOT,index=None,keyring='/usr/share/keyrings/debian-archive-keyring.pgp'):
 root=Path(root);pin=json.loads((root/'PROVIDER.json').read_text());signed=root/'references/DEBIAN_INRELEASE.asc';checked(signed.read_bytes(),pin['signed_release_sha256'],signed.stat().st_size)
 with tempfile.TemporaryDirectory(prefix='usl-shader-debian-auth-') as d:
  verified=Path(d)/'release';subprocess.run(['sqv','--keyring',str(keyring),'--cleartext','--output',str(verified),str(signed)],capture_output=True,check=True);release=verified.read_bytes()
 checked(release,pin['release_sha256'],len(release))
 if release!=(root/'references/DEBIAN_RELEASE.txt').read_bytes():raise ValueError('Frozen release differs')
 digest,size=release_item(release.decode(),'main/binary-amd64/Packages')
 if digest!=pin['index_sha256']:raise ValueError('Index identity differs')
 index=Path(index) if index else Path('/workspace/.onboarding/apt/lists/deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages')
 if index.exists():body=index.read_bytes()
 else:
  compressed_hash,compressed_size=release_item(release.decode(),'main/binary-amd64/Packages.xz');compressed=checked(fetch('https://deb.debian.org/debian/dists/trixie/main/binary-amd64/by-hash/SHA256/'+compressed_hash),compressed_hash,compressed_size);body=lzma.decompress(compressed)
 checked(body,digest,size);found=[]
 for block in body.decode().split('\n\n'):
  if block.startswith('Package: '+pin['Package']+'\n'):
   fields={k:v for line in block.splitlines() if ': ' in line and not line.startswith(' ') for k,v in [line.split(': ',1)]};found.append({k:fields[k] for k in FIELDS})
 if found!=[{k:pin[k] for k in FIELDS}]:raise ValueError('Exact upstream Debian package pin differs')
 return pin

def extract_files(archive,pin,target):
 if archive[:8]!=b'!<arch>\n':raise ValueError('Debian ar archive magic')
 target=Path(target);offset=8;found={};wanted={r['member']:name for name,r in pin['extracted_files'].items()}
 while offset<len(archive):
  header=archive[offset:offset+60]
  if len(header)!=60 or header[58:60]!=b'`\n':raise ValueError('Malformed ar member')
  size=int(header[48:58]);name=header[:16].decode().strip().rstrip('/');payload=archive[offset+60:offset+60+size];offset+=60+size+(size%2)
  if name.startswith('data.tar.'):
   with tarfile.open(fileobj=io.BytesIO(payload),mode='r:*') as tf:
    for member in tf:
     if member.name in wanted:
      if not member.isfile() or member.name in found:raise ValueError('Provider must be unique regular file')
      filename=wanted[member.name];record=pin['extracted_files'][filename];data=checked(tf.extractfile(member).read(),record['sha256'],record['bytes']);found[member.name]=data
 if set(found)!=set(wanted):raise ValueError('Missing provider members')
 target.mkdir(parents=True,exist_ok=True)
 for member,data in found.items():(target/wanted[member]).write_bytes(data)
 return target

def restore_provider(target=None):
 pin=authenticate();target=Path(target) if target else ROOT/'providers'
 valid=all((target/n).is_file() and sha((target/n).read_bytes())==r['sha256'] and (target/n).stat().st_size==r['bytes'] for n,r in pin['extracted_files'].items())
 if not valid:
  archive=checked(fetch(pin['url']),pin['SHA256'],pin['Size']);extract_files(archive,pin,target)
 receipt={'package':{k:pin[k] for k in FIELDS},'verification':'sqv signature -> SHA256 package index -> exact package/version/hash -> exact regular-file member hashes','files':pin['extracted_files'],'native_binaries_in_source_package':False}
 (target/'PACKAGE_RESTORE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');return target
