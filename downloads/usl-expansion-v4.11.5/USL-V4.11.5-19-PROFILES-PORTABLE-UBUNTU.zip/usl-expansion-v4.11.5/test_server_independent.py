"""Independent native/intent probes in fresh interpreters to avoid generic-module collisions."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parent
SERVER=ROOT/'server_config'
BASE=Path(os.environ.get('USL_SOURCE_ROOT','/workspace/usl-v4.10.0-clean-test'))
EVIDENCE=[]
CHILD=r'''
import hashlib,json,sys
from pathlib import Path
server=Path(sys.argv[1]);base=Path(sys.argv[2]);data=json.load(sys.stdin)
sys.path.insert(0,str(server))
from frontends import frontend,Unsupported,check_path
from native import process,ACTIVE
sys.path.insert(0,str(base))
from usl_systems.language import Interpreter
runtime=base/'usl_systems/language.py'
assert hashlib.sha256(runtime.read_bytes()).hexdigest()=='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'
result={'action':data['action'],'catalog_id':data['catalog_id']}
if data['action']=='native-rejection':
    try: frontend(data['catalog_id'],data['source'])
    except Unsupported as error: result['frontend_rejected']=True;result['frontend_error']=str(error)
    else: result['frontend_rejected']=False
    try: process(data['catalog_id'],data['source'],['/a'])
    except RuntimeError as error: result['native_rejected']=True;result['native_error']=str(error)
    else: result['native_rejected']=False
elif data['action']=='domain':
    _,generated=frontend(data['catalog_id'],data['source']);rows=[]
    for path in data['paths']:
        row={'path':path}
        try:check_path(path)
        except Unsupported:row['python_rejected']=True
        else:row['python_rejected']=False
        try:Interpreter().run(generated+'result=respond('+repr(path)+')\n')
        except Exception:row['USL_rejected']=True
        else:row['USL_rejected']=False
        rows.append(row)
    result['rows']=rows
elif data['action']=='source-rejection':
    rows=[]
    for source in data['sources']:
        try:frontend(data['catalog_id'],source)
        except Unsupported as error:rows.append({'source':source,'rejected':True,'error':str(error)})
        else:rows.append({'source':source,'rejected':False})
    result['rows']=rows
else:
    ir,generated=frontend(data['catalog_id'],data['source'])
    program=generated+'result=['+', '.join('respond('+repr(path)+')' for path in data['paths'])+']\n'
    result['generated_sha256']=hashlib.sha256(program.encode()).hexdigest()
    result['USL']=Interpreter(max_ops=2000000,timeout=5).run(program).variables['result']
    result['IR']=ir;result['native']=process(data['catalog_id'],data['source'],data['paths'])
    result['native_values']=[row['observed'] for row in result['native']['observations']]
    if 'mutation' in data:
        before,after=data['mutation'];mutated=program.replace(before,after)
        assert mutated!=program
        result['mutated_USL']=Interpreter(max_ops=2000000,timeout=5).run(mutated).variables['result']
        result['mutation_applied']=True
result['no_active_native_processes']=not ACTIVE
result['reviewed_source_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in server.iterdir() if p.is_file() and p.suffix=='.py'}
print(json.dumps(result))
'''


def probe(**payload):
    completed=subprocess.run([sys.executable,'-c',CHILD,str(SERVER),str(BASE)],input=json.dumps(payload),capture_output=True,text=True,timeout=50)
    if completed.returncode:
        raise AssertionError('Independent probe failed: '+completed.stderr[-6000:])
    value=json.loads(completed.stdout)
    if not value['no_active_native_processes']:raise AssertionError('Native process was not cleaned up')
    EVIDENCE.append({'request':payload,'response':value})
    return value


def full_vcl(body):
    return 'vcl 4.1; backend default none; sub vcl_recv {'+body+'} sub vcl_synth {return(deliver);}'


class IndependentServerSemantics(unittest.TestCase):
    def differential(self,identifier,source,paths,expected,mutation=None):
        payload={'action':'differential','catalog_id':identifier,'source':source,'paths':paths,'independent_expected':expected}
        if mutation:payload['mutation']=mutation
        result=probe(**payload)
        self.assertEqual(result['native_values'],expected)
        self.assertEqual(result['USL'],expected)
        if mutation:self.assertNotEqual(result['mutated_USL'],expected)
        return result

    def test_apache_ordered_segment_suffix_and_case_intent(self):
        source='Redirect 308 /ab/c https://specific.invalid/dest\nRedirect temp /ab https://first.invalid/start\nRedirect gone /gone\n'
        paths=['/ab/c','/ab/c/X_9','/ab','/ab/d','/abc','/AB','/gone','/gone/child','/gonefish']
        expected=[[308,'https://specific.invalid/dest'],[308,'https://specific.invalid/dest/X_9'],[302,'https://first.invalid/start'],[302,'https://first.invalid/start/d'],[404,''],[404,''],[410,''],[410,''],[404,'']]
        self.differential('apacheconf',source,paths,expected,('https://first.invalid/start','https://wrong.invalid/start'))

    def test_lighttpd_anchoring_case_and_target_literal_intent(self):
        source='url.redirect-code=307\nurl.redirect=("^/a-b_9$"=>"https://safe.invalid/P_9", "^/A$"=>"https://other.invalid/final")'
        paths=['/a-b_9','/a-b_9/child','/a-b_90','/A','/a','/none']
        expected=[[307,'https://safe.invalid/P_9'],[404,''],[404,''],[307,'https://other.invalid/final'],[404,''],[404,'']]
        self.differential('lighttpd',source,paths,expected,('return [307,','return [308,'))

    def test_vcl_nested_partial_branches_and_reason_spaces(self):
        reason='A'+' '*62+'Z'
        body='if (!(req.url == "/a" || req.url == "/b") && req.url != "/c") {return(synth(599,"'+reason+'"));} else {if (req.url == "/b") {return(synth(202,"B route"));}} return(synth(207,"Fallback"));'
        paths=['/a','/b','/c','/other','/A'];expected=[[207,'Fallback'],[202,'B route'],[207,'Fallback'],[599,reason],[599,reason]]
        self.differential('vclsnippets',body,paths,expected,('return [202,','return [500,'))
        self.differential('vcl',full_vcl(body),paths,expected)

    def test_vcl_native_consecutive_not_counterexample_is_rejected(self):
        for prefix in ['!!','! !']:
            body='if ('+prefix+'(req.url == "/a")) {return(synth(200,"Yes"));} return(synth(404,"No"));'
            value=probe(action='native-rejection',catalog_id='vclsnippets',source=body)
            self.assertTrue(value['frontend_rejected'])
            self.assertTrue(value['native_rejected'])
            self.assertIn("Unknown token '!'",value['native_error'])

    def test_vcl_parenthesized_double_not_native_positive(self):
        body='if (!(!(req.url == "/a"))) {return(synth(200,"Twice"));} return(synth(404,"Other"));'
        self.differential('vclsnippets',body,['/a','/b'],[[200,'Twice'],[404,'Other']])

    def test_vcl_decimal_leading_zeros_and_status_boundaries(self):
        body='if(req.url=="/a"){return(synth(0200,"Leading zero"));} if(req.url=="/b"){return(synth(0204,"No content"));} return(synth(599,"Upper bound"));'
        self.differential('vclsnippets',body,['/a','/b','/c'],[[200,'Leading zero'],[204,'No content'],[599,'Upper bound']])

    def test_paths_with_normalization_or_nonstring_values_are_rejected(self):
        paths=['/a%2fb','/a/./b','//a','/a//b','/a?x=1','/a#x','/a/','/a\r\nInjected: yes','/é','/',True,1,None,['/a'],'/'+('a'*96)]
        sources={'apacheconf':'Redirect 301 /a https://target.invalid/to','lighttpd':'url.redirect=("^/a$"=>"https://target.invalid/to")','vclsnippets':'return(synth(200,"OK"));'}
        for identifier,source in sources.items():
            value=probe(action='domain',catalog_id=identifier,source=source,paths=paths)
            self.assertTrue(all(row['python_rejected'] and row['USL_rejected'] for row in value['rows']))

    def test_regex_escape_quote_and_effectful_source_are_rejected(self):
        sources={
          'apacheconf':['RedirectMatch 302 ^/a https://target.invalid/to','Redirect 302 /a https://target.invalid/to?x=1','Redirect 302 /a https://target.invalid/to\nInclude /etc/passwd','Redirect 302 /a "https://target.invalid/to"'],
          'lighttpd':['url.redirect=("^/a.*$"=>"https://target.invalid/to")','url.redirect=("^/a$"=>"https://target.invalid/to$1")','url.redirect=("^/a\\.b$"=>"https://target.invalid/to")','url.redirect=("^/a$"=>"https://target.invalid/to")\ninclude "/etc/passwd"'],
          'vclsnippets':['return(synth(200,"bad\\\"quote"));','return(synth(200,"Trailing "));','return(synth(199,"Below"));','return(synth(600,"Above"));','set req.url="/a"; return(synth(200,"OK"));','return(synth(200,"OK")); return(synth(201,"Dead"));']}
        for identifier,examples in sources.items():
            value=probe(action='source-rejection',catalog_id=identifier,sources=examples)
            self.assertTrue(all(row['rejected'] for row in value['rows']))


if __name__=='__main__':
    program=unittest.main(exit=False)
    if os.environ.get('USL_SERVER_REVIEW_OUTPUT'):
        Path(os.environ['USL_SERVER_REVIEW_OUTPUT']).write_text(json.dumps({'passed':program.result.wasSuccessful(),'tests_run':program.result.testsRun,'evidence':EVIDENCE},indent=2)+'\n')
    sys.exit(0 if program.result.wasSuccessful() else 1)
