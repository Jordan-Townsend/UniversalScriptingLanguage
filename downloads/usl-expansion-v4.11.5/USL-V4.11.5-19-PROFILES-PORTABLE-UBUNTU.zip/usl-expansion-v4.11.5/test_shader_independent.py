"""Independent native shader/intent checks; no shader-owned files are written."""
from __future__ import annotations
import hashlib,importlib.util,json,os,pathlib,shutil,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parent
SHADER=ROOT/'semantic_hosts'
def module(name,file):
 spec=importlib.util.spec_from_file_location(name,SHADER/file);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
profile=module('_shader_independent_profile','shader_profile.py')
proof=module('_shader_independent_proofs','proofs.py')
provider=module('_shader_independent_provider','provider_restore.py')
sys.path.insert(0,os.environ.get('USL_SOURCE_ROOT','/workspace/usl-v4.10.0-clean-test'))
import usl_systems.language as runtime
OBSERVATIONS=[]
MASK=(1<<32)-1
PAIRS=[[0,0],[0,1],[1,0],[1,1],[3,9],[9,3],[7,7],[2147483647,2147483648],[2147483648,2147483647],[MASK,MASK],[MASK,1],[1,MASK],[MASK-1,17],[17,MASK-1]]
# Authored from arithmetic intent; neither parser IR nor proof denotation is used.
CASES=[
 ('add-before-shift','x + 1u << 2u',lambda x,y:((x+1)*4)&MASK),
 ('left-subtraction','x - y - 1u',lambda x,y:(x-y-1)&MASK),
 ('quotient-remainder','x / 3u * 3u + x % 3u',lambda x,y:x),
 ('spaced-unary-minus','x - - y',lambda x,y:(x+y)&MASK),
 ('double-spaced-negation','- - x',lambda x,y:x),
 ('nested-true','x > y ? x < 7u ? 0u : x : y',lambda x,y:(0 if x<7 else x) if x>y else y),
 ('bool-conditional','(x == y ? x < 7u : x > 7u) ? 5u : 11u',lambda x,y:5 if (x<7 if x==y else x>7) else 11),
 ('complement-product','~(x * y)',lambda x,y:MASK-((x*y)&MASK)),
 ('clamp-boundaries','max(0u, clamp(x,1u,4294967295u))',lambda x,y:max(1,x)),
 ('negate-top-bit','-(x << 31u)',lambda x,y:(1<<31) if x%2 else 0),
 ('boolean-precedence','(x >= y && !(x == 0u) || y < 7u) ? x : y',lambda x,y:x if x>=y and x!=0 or y<7 else y),
 ('ternary-else-shift','x < y ? 0u : x + 1u << 1u',lambda x,y:0 if x<y else ((x+1)*2)&MASK),
]
COMPILER_SHA='3a4fb1feabbe3f2a61a42f067d67c0d2ee6a982ea863fb02c66b7aa271f830eb'
SO_SHA='a9300a8616f7f765471b5feebe19ceeb4a5492ae69b6ec68589dd213c86c564b'
ICD_SHA='c9eef28b6b984fec220ef0abfecc40b502d46946706e47bfe97707027cb818bd'
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def source(expression,language):return ('#version 450\n' if language=='glsl' else '')+'uint evaluate(uint x,uint y){return '+expression+';}\n'
def independent_native_source(user_source,language,count):
 # Separately authored buffer/entry harness, without calling profile.native_source.
 if language=='glsl':
  return user_source+'\nlayout(local_size_x=1,local_size_y=1,local_size_z=1) in;\nlayout(std430,set=0,binding=0) buffer Samples {uint payload[];};\nvoid main(){uint lane=gl_GlobalInvocationID.x;payload['+str(2*count)+'u+lane]=evaluate(payload[lane],payload['+str(count)+'u+lane]);}\n'
 return user_source+'\nRWStructuredBuffer<uint> payload:register(u0);\n[numthreads(1,1,1)] void main(uint3 lane:SV_DispatchThreadID){payload['+str(2*count)+'u+lane.x]=evaluate(payload[lane.x],payload['+str(count)+'u+lane.x]);}\n'
def compile_source(user_source,language,directory,count=1):
 p=directory/'independent.comp';p.write_text(independent_native_source(user_source,language,count));spv=directory/'independent.spv';compiler=shutil.which('glslangValidator')
 if not compiler or digest(compiler)!=COMPILER_SHA:raise AssertionError('independent native compiler identity differs')
 cmd=[compiler,'-V','--target-env','vulkan1.0','-S','comp','-e','main']+(['-D'] if language=='hlsl' else [])+[str(p),'-o',str(spv)]
 proc=subprocess.run(cmd,text=True,errors='replace',capture_output=True,timeout=20)
 return proc,spv,cmd
class ShaderIndependent(unittest.TestCase):
 def test_actual_native_additional_intent_corpus(self):
  hostdir=tempfile.TemporaryDirectory(prefix='usl-independent-host-');self.addCleanup(hostdir.cleanup);binary=pathlib.Path(hostdir.name)/'vulkan_runner';icd=SHADER/'providers/vk_swiftshader_icd.json';so=SHADER/'providers/libvk_swiftshader.so'
  self.assertEqual(digest(icd),ICD_SHA);self.assertEqual(digest(so),SO_SHA)
  command=[shutil.which('gcc'),'-std=c11','-O2','-Wall','-Wextra',str(SHADER/'vulkan_runner.c'),'-l:libvulkan.so.1','-o',str(binary)];built=subprocess.run(command,text=True,capture_output=True,timeout=30);self.assertEqual(built.returncode,0,built.stderr)
  OBSERVATIONS.append({'kind':'host_build','command':command,'source_sha256':digest(SHADER/'vulkan_runner.c'),'C_compiler_launch_sha256':digest(shutil.which('gcc')),'binary_sha256':digest(binary),'returncode':built.returncode,'stdout':built.stdout,'stderr':built.stderr})
  env=dict(os.environ,VK_ICD_FILENAMES=str(icd));env.pop('VK_DRIVER_FILES',None);env.pop('VK_ADD_DRIVER_FILES',None)
  for language in ['glsl','hlsl']:
   for name,expression,oracle in CASES:
    with self.subTest(language=language,case=name),tempfile.TemporaryDirectory(prefix='usl-shader-independent-') as d:
     text=source(expression,language);ir=profile.parse(text,language);generated=profile.translate(text,language,PAIRS);directory=pathlib.Path(d)
     compiled,spv,cmd=compile_source(text,language,directory,len(PAIRS));self.assertEqual(compiled.returncode,0,compiled.stdout+compiled.stderr)
     nativecmd=[str(binary),str(spv),str(len(PAIRS))];stdin=' '.join(str(x) for x,y in PAIRS)+'\n'+' '.join(str(y) for x,y in PAIRS)+'\n'
     native=subprocess.run(nativecmd,input=stdin,text=True,capture_output=True,env=env,timeout=20);self.assertEqual(native.returncode,0,native.stderr);self.assertIn('type=4',native.stderr)
     observed=[int(x) for x in native.stdout.splitlines()];usl=runtime.Interpreter(max_ops=1000000,timeout=10).run(generated).variables['result'];expected=[oracle(x,y) for x,y in PAIRS]
     self.assertEqual(observed,expected);self.assertEqual(usl,expected)
     checked=proof.check(ir,generated,runtime);self.assertEqual(checked['result'],'unsat')
     OBSERVATIONS.append({'kind':'native_execution','language':language,'case':name,'source':text,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'generated_sha256':hashlib.sha256(generated.encode()).hexdigest(),'SPIRV_sha256':digest(spv),'inputs':PAIRS,'independent_expected':expected,'native_observed':observed,'USL_observed':usl,'compile_command':cmd,'compile_returncode':compiled.returncode,'compile_stdout':compiled.stdout,'compile_stderr':compiled.stderr,'native_command':nativecmd,'native_returncode':native.returncode,'device_receipt':native.stderr,'scoped_function_AST_proof':checked})
 def test_unicode_and_control_source_fail_closed(self):
  for language in ['glsl','hlsl']:
   for expr in ['١u','２u','x\u00a0+ y','x\u0085+ y','x\v+ y','x\f+ y','x\x1c+ y','x\x1d+ y','x\x1e+ y','x\x1f+ y']:
    with self.subTest(language=language,expression=repr(expr)):
     with self.assertRaises(profile.Unsupported):profile.parse(source(expr,language),language)
 def test_native_rejects_unicode_and_control_tokens(self):
  for language in ['glsl','hlsl']:
   for expr in ['١u','２u','x\u00a0+ y','x\v+ y','x\f+ y','x\x1c+ y']:
    with self.subTest(language=language,expression=repr(expr)),tempfile.TemporaryDirectory(prefix='usl-shader-bad-') as d:
     text=source(expr,language);p,spv,cmd=compile_source(text,language,pathlib.Path(d));self.assertNotEqual(p.returncode,0)
     OBSERVATIONS.append({'kind':'native_rejection','language':language,'expression':expr,'compile_command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 def test_comments_and_other_lexical_extensions_rejected(self):
  for language in ['glsl','hlsl']:
   for expression in ['x/*not part of profile*/+y','x // not part of profile\n+y','1ufoo','1e2u','0x10u','x++ + y','x-- - y','x += y','x << = y','x ? 1u : 0u','x == y == 0u']:
    with self.subTest(language=language,expression=expression),self.assertRaises(profile.Unsupported):profile.parse(source(expression,language),language)
 def test_input_domain_including_upper_limit(self):
  text=source('x','glsl');good=[[0,0],[MASK,MASK]]
  self.assertEqual(runtime.Interpreter().run(profile.translate(text,'glsl',good)).variables['result'],[0,MASK])
  for bad in [None,True,[],[[True,0]],[[False,0]],[[0,-1]],[[0,MASK+1]],[[0,0.0]],[[0]],[[0,1,2]],[(0,1)],[[0,0]]*4097]:
   with self.subTest(value=repr(bad)[:60]),self.assertRaises(profile.Unsupported):profile.translate(text,'glsl',bad)
 def test_actual_AST_zero_division_mutants_rejected(self):
  text=source('x+y','glsl');ir=profile.parse(text,'glsl');valid=profile.translate(text,'glsl',[[1,2]])
  for extra in ['0 * (1 // 0)','0 * (1 % 0)','0 * (1 // -3)','0 * (1 % -3)']:
   bad=valid.replace('return ((arg_x + arg_y) % 4294967296)','return ((arg_x + arg_y) % 4294967296) + '+extra)
   with self.subTest(extra=extra):
    rejected=False
    try:rejected=proof.check(ir,bad,runtime)['result']!='unsat'
    except (ValueError,TypeError):rejected=True
    self.assertTrue(rejected,'Z3 totalized division must not certify partial or differently modeled runtime arithmetic')
    if extra in ['0 * (1 // 0)','0 * (1 % 0)']:
     with self.assertRaises(runtime.USLError):runtime.Interpreter().run(bad)
 def test_missing_wrap_mutation_fails_intent(self):
  text=source('x+y','glsl');valid=profile.translate(text,'glsl',[[MASK,1]]);bad=valid.replace('((arg_x + arg_y) % 4294967296)','(arg_x + arg_y)')
  self.assertEqual(runtime.Interpreter().run(valid).variables['result'],[0]);self.assertNotEqual(runtime.Interpreter().run(bad).variables['result'],[0]);self.assertEqual(proof.check(profile.parse(text,'glsl'),bad,runtime)['result'],'sat')
 def test_proof_scope_excludes_call_marshalling(self):
  # This deliberately records the proof's limit: function-return equivalence
  # does not establish correctness of every top-level invocation/input binding.
  text=source('x-y','glsl');ir=profile.parse(text,'glsl');valid=profile.translate(text,'glsl',[[1,2]]);bad=valid.replace('shader_evaluate(1, 2)','shader_evaluate(2, 1)')
  self.assertEqual(proof.check(ir,bad,runtime)['result'],'unsat');self.assertEqual(runtime.Interpreter().run(valid).variables['result'],[MASK]);self.assertEqual(runtime.Interpreter().run(bad).variables['result'],[1])
 def test_actual_provider_authentication_and_member_hashes(self):
  pin=provider.authenticate()
  for filename,row in pin['extracted_files'].items():
   p=SHADER/'providers'/filename;self.assertEqual(digest(p),row['sha256']);self.assertEqual(p.stat().st_size,row['bytes'])
  with tempfile.TemporaryDirectory(prefix='usl-shader-auth-review-') as d:
   root=pathlib.Path(d);(root/'references').mkdir()
   for name in ['DEBIAN_INRELEASE.asc','DEBIAN_RELEASE.txt']:shutil.copyfile(SHADER/'references'/name,root/'references'/name)
   (root/'PROVIDER.json').write_text((SHADER/'PROVIDER.json').read_text());(root/'references/DEBIAN_RELEASE.txt').write_text('forged metadata')
   with self.assertRaises(ValueError):provider.authenticate(root=root)
if __name__=='__main__':unittest.main()
