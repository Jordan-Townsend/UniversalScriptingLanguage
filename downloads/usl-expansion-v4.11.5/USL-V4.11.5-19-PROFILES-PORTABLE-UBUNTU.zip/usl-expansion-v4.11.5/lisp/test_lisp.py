import sys
import itertools
import unittest
from pathlib import Path

from cases import cirru_cases,lisp_cases
from frontend import BOUND,ProfileError,cirru_parse,emit,emit_cirru,evaluate,parse
from run import native,restriction_checks


class TypedFrontendTests(unittest.TestCase):
    def test_independent_arithmetic_and_native_intent(self):
        for language in ['janet','newlisp']:
            cases=lisp_cases(language)
            actual,receipt=native(language,[case['source'] for case in cases])
            self.assertEqual(receipt['fresh_process_invocations'],1)
            for case,result in zip(cases,actual):
                with self.subTest(language=language,name=case['name']):
                    ir=parse(case['source'],language)
                    self.assertIs(type(result),type(case['expected']))
                    self.assertEqual(result,case['expected'])
                    self.assertEqual(evaluate(ir),case['expected'])

    def test_restrictions_fail_closed(self):
        for language in ['janet','newlisp','cirru']:
            self.assertTrue(all(row['rejected'] for row in restriction_checks(language)))

    def test_lexical_scope_and_parallel_difference(self):
        self.assertEqual(evaluate(parse('(let [x 3 y (+ x 2)] (* x y))','janet')),15)
        with self.assertRaises(ProfileError):parse('(let ((x 3) (y (+ x 2))) (* x y))','newlisp')
        for language,bindings in [('janet','[x 3]'),('newlisp','((x 3))')]:
            with self.assertRaises(ProfileError):parse('(let '+bindings+' (let '+bindings+' x))',language)

    def test_short_circuit_and_integer_boundaries(self):
        for language,false in [('janet','false'),('newlisp','nil')]:
            self.assertEqual(evaluate(parse('(if true 2 (* 1073741824 3))',language)),2)
            self.assertFalse(evaluate(parse('(and '+false+' (= (* 1073741824 3) 0))',language)))
            with self.assertRaises(ProfileError):parse('(* 1073741824 3)',language)
            self.assertEqual(evaluate(parse('(- -1073741824 0)',language)),-BOUND)

    def test_cirru_independent_trees_and_native_parser(self):
        cases=cirru_cases();native_values,_=native('cirru',[row['source'] for row in cases])
        for row,observed in zip(cases,native_values):
            with self.subTest(name=row['name']):
                self.assertTrue(observed['accepted'])
                self.assertEqual(cirru_parse(row['source']),row['expected'])
                self.assertEqual(observed['tree'],row['expected'])

    def test_generated_usl_executes_with_lazy_let(self):
        sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')
        from usl_systems.language import Interpreter
        for language in ['janet','newlisp']:
            bindings='[x 7]' if language=='janet' else '((x 7))'
            source='(if true (let '+bindings+' (+ x 2)) (* 1073741824 2))'
            result=Interpreter().run(emit(parse(source,language)))
            self.assertEqual(result.variables['value'],9)
        tree=cirru_parse('a\n  b c\n')
        self.assertEqual(Interpreter().run(emit_cirru(tree)).variables['value'],[['a',['b','c']]])

    def test_malformed_and_adversarial_sources(self):
        for language in ['janet','newlisp']:
            for source in ['(+ 1 2]',')','(',"(__import__ os)",'(+ 1.0 2)','(+ 0x10 2)','(+ 1 2)\n(exit 0)','(+ 1 "x")','(+ 1 2)\x00','('*40+'1'+')'*40]:
                with self.subTest(language=language,source=source),self.assertRaises(ProfileError):parse(source,language)
        for source in ['a\n    b\n','a\n b\n','a (b\n','a \\x\n','a "x"\n','a\r\n','é\n']:
            with self.subTest(source=source),self.assertRaises(ProfileError):cirru_parse(source)

    def test_cirru_lexical_counterexamples_and_native_boundary_search(self):
        for source in ['a()\n','a$a\n','$aa\n','$$a\n','a (b)c\n']:
            with self.subTest(source=source),self.assertRaises(ProfileError):cirru_parse(source)
        accepted=[]
        for tokens in itertools.product(['a','b','(',')','$'],repeat=4):
            for separator in ['',' ']:
                source=separator.join(tokens)+'\n'
                try:accepted.append((source,cirru_parse(source)))
                except ProfileError:pass
        observed,_=native('cirru',[source for source,tree in accepted])
        for (source,tree),value in zip(accepted,observed):
            with self.subTest(source=source):
                self.assertTrue(value['accepted'])
                self.assertEqual(tree,value['tree'])

    def test_native_binding_names_and_comment_boundaries(self):
        for language in ['janet','newlisp']:
            sources=[]
            for name in ['x','y','z']+['v'+str(i) for i in range(16)]:
                bindings=f'[{name} 7]' if language=='janet' else f'(({name} 7))'
                source='(let '+bindings+' (+ '+name+' 3))'
                self.assertEqual(evaluate(parse(source,language)),10)
                sources.append(source)
            values,_=native(language,sources)
            self.assertEqual(values,[10]*len(sources))
            marker='#' if language=='janet' else ';'
            with self.assertRaises(ProfileError):parse('true'+marker+'adjacent',language)
            with self.assertRaises(ProfileError):parse('(let '+('[abs 1]' if language=='janet' else '((abs 1))')+' abs)',language)


if __name__=='__main__':unittest.main()
