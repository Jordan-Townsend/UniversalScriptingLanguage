const fs = require('node:fs');
const parser = require('./providers/cirru/package/lib/parser.js');
const requests = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const result = requests.map(source => {
  try { return {accepted: true, tree: parser.pare(source, 'case.cirru')}; }
  catch (error) { return {accepted: false, error: String(error.message)}; }
});
process.stdout.write(JSON.stringify(result));
