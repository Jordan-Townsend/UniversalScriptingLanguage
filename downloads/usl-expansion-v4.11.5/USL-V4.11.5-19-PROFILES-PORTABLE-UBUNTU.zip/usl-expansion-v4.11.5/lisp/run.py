"""Fresh native originals versus generated USL and separate arithmetic/tree intent."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

from cases import cirru_cases,lisp_cases
from frontend import ProfileError,cirru_parse,emit,emit_cirru,parse

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def native(language,sources):
    with tempfile.TemporaryDirectory(prefix='usl-lisp-native-') as temporary:
        path=Path(temporary)/'original.source'
        if language=='cirru':
            path.write_text(json.dumps(sources))
            argv=['node',str(ROOT/'cirru_host.cjs'),str(path)]
        elif language=='janet':
            path.write_text('\n'.join('(print '+source+')' for source in sources)+'\n')
            argv=[str(ROOT/'providers/janet/build/janet'),str(path)]
        else:
            path.write_text('\n'.join('(println '+source+')' for source in sources)+'\n(exit 0)\n')
            argv=[str(ROOT/'providers/newlisp/usr/bin/newlisp'),'-n',str(path)]
        result=subprocess.run(argv,capture_output=True,text=True,timeout=20)
        receipt={'argv_without_temporary_filename':argv[:-1], 'returncode':result.returncode,
                 'stdout':result.stdout,'stderr':result.stderr,'input_sha256':sha(path),
                 'fresh_process_invocations':1,'original_source_observations':len(sources)}
        if result.returncode:raise ValueError('Native host failed: '+json.dumps(receipt))
        if language=='cirru':observed=json.loads(result.stdout)
        else:
            observed=[]
            for line in result.stdout.splitlines():
                if line in ('true','false','nil'):observed.append(line=='true')
                else:observed.append(int(line))
        if len(observed)!=len(sources):raise ValueError('Native output cardinality mismatch')
        return observed,receipt


def identities(language):
    if language=='janet':
        binary=ROOT/'providers/janet/build/janet'
        version=subprocess.check_output([str(binary),'-v'],text=True).strip()
        paths=[binary,ROOT/'janet-source-hashes.json']
    elif language=='newlisp':
        binary=ROOT/'providers/newlisp/usr/bin/newlisp'
        version=subprocess.check_output([str(binary),'-v'],text=True).strip()
        paths=[binary,ROOT/'provider-hashes.json']
    else:
        version='Cirru parser0.10.8; '+subprocess.check_output(['node','--version'],text=True).strip()
        paths=[Path(shutil.which('node')).resolve(),ROOT/'providers/cirru/package/lib/parser.js',ROOT/'providers/cirru/package/lib/tree.js']
    return {'version':version,'files':{str(p):sha(p) for p in paths}}


def validate(language,output):
    from usl_systems.language import Interpreter
    cases=cirru_cases() if language=='cirru' else lisp_cases(language)
    observed,native_receipt=native(language,[case['source'] for case in cases])
    rows=[]
    generated_dir=output/'generated'/language;generated_dir.mkdir(parents=True,exist_ok=True)
    for index,(case,original) in enumerate(zip(cases,observed)):
        if language=='cirru':
            ir=cirru_parse(case['source']);program=emit_cirru(ir)
            native_value=original.get('tree') if original.get('accepted') else None
            typed_ir={'category':'List[List[Atom|Tree]]','tree':ir}
        else:
            ir=parse(case['source'],language);program=emit(ir)
            native_value=original;typed_ir={'result_type':ir.type,'representation':repr(ir)}
        result=Interpreter(max_ops=20000,timeout=2).run(program)
        generated_value=result.variables['value']
        passed=type(generated_value) is type(case['expected']) and type(native_value) is type(case['expected']) and native_value==generated_value==case['expected']
        generated_path=generated_dir/(str(index)+'.usl');generated_path.write_text(program)
        row={**case,'native_value':native_value,'generated_value':generated_value,'typed_IR':typed_ir,
             'generated_USL':str(generated_path.relative_to(output)),'generated_USL_sha256':sha(generated_path),
             'USL_operations':result.operations,'passed':passed,
             'intent_origin':'Independent arithmetic or explicitly constructed tree oracle in cases.py; not frontend evaluation'}
        rows.append(row)
        if not passed:raise ValueError('Counterexample: '+json.dumps(row))
    restrictions=restriction_checks(language)
    if not all(r['rejected'] for r in restrictions):raise ValueError('Unsupported source silently accepted')
    exact={'janet':'Janet1.39.1 commit e9c6678614ef731d5c4e9bf7915c48224eb0aeb1; pure closed Bool/bounded-Int expressions, binary arithmetic/comparisons, typed if/not/and/or, sequential let, comments; every evaluated integer intermediate in[-2^30,2^30]',
           'newlisp':'newLISP10.7.5 Debian10.7.5-3 Linux amd64; pure closed Bool/bounded-Int expressions, binary arithmetic/comparisons, typed if/not/and/or, parallel let, comments; every evaluated integer intermediate in[-2^30,2^30]',
           'cirru':'Cirru parser0.10.8 syntax-tree processing; ASCII bare atoms, two-space layout, parentheses and dollar tails; tree identity lowered to generated USL lists; no Cirru runtime/evaluation claim'}[language]
    record={'catalog_id':language,'scoped_profile_validated':True,'full_standard_qualified':False,
            'exact_profile':exact,'cases':len(rows),'native_executions':len(rows),'usl_executions':len(rows),
            'native_unit':'original expression result observations in one fresh native interpreter process' if language!='cirru' else 'document tree observations in one fresh upstream Node parser process',
            'fresh_native_process_invocations':1,'independent_intent_cases':len(rows),
            'heldout_cases':sum(bool(r.get('heldout')) for r in rows),'unsupported_source_rejections':len(restrictions),
            'tool_identity':identities(language),'source_identity':source_identity(),
            'open_obligations':['Complete grammar and specification audit','Full native type/dynamic, numeric, string and collection semantics',
                                'Functions, closures, mutation, modules and standard libraries','Effects, exceptions, concurrency, foreign ABI and platform conformance',
                                'Upstream full-standard conformance and independent review','Universal parser/translation correctness and intent proof'],
            'claim_limits':['Fresh finite differential observations establish only this exact bounded profile',
                            'Independent intent cases do not prove correctness of arbitrary generated programs',
                            'Native host, USL interpreter, parser implementation and arithmetic/tree oracle remain trusted'],
            'native_receipt':native_receipt,'case_records':rows,'restriction_checks':restrictions}
    (output/(language+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    return record


def source_identity():
    return {p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in {'.py','.cjs','.json'} and p.name!='SOURCE_SHA256.json'}


def restriction_checks(language):
    if language=='cirru':
        sources=['a "quoted"\n','a \\escape\n','a , b\n','a\n   b\n','  root\n','a\n    skipped\n','a (b\n','a )\n','a $\n','a\tb\n']
        parser=cirru_parse
    else:
        false='false' if language=='janet' else 'nil'
        sources=['(+ 1 true)','(/ 3 2)','(+ 1073741824 1)','(* 1073741824 2)','(+ 1 2) 3','(if 0 1 2)',
                 '(if true 1 '+false+')','(fn [x] x)','[1 2]','(import os)','(not 0)','(+ 1)','(+ 01 2)','x','(and true 7)',
                 '(let '+('[x 1 x 2]' if language=='janet' else '((x 1) (x 2))')+' x)',
                 '(let '+('[true 1]' if language=='janet' else '((true 1))')+' 1)']
        if language=='newlisp':sources.append('(let ((x 2) (y x)) y)')
        parser=lambda text:parse(text,language)
    result=[]
    for source in sources:
        try:parser(source);result.append({'source':source,'rejected':False})
        except ProfileError as error:result.append({'source':source,'rejected':True,'reason':str(error)})
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();sys.path.insert(0,str(args.source_root.resolve()))
    args.output.mkdir(parents=True,exist_ok=True)
    start=time.monotonic();records=[validate(language,args.output) for language in ['janet','newlisp','cirru']]
    result={'records':records,'elapsed_seconds':time.monotonic()-start,'full_standard_qualifications':0,
            'USL_runtime_sha256':sha(args.source_root/'usl_systems/language.py')}
    (args.output/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'languages':3,'cases':sum(r['cases'] for r in records),'native_processes':3,'elapsed_seconds':result['elapsed_seconds']}))


if __name__=='__main__':main()
