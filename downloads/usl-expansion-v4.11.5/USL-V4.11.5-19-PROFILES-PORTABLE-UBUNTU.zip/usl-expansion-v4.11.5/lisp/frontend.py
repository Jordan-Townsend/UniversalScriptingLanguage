"""Fail-closed, typed, pure expression profiles; no eval of source text."""
from dataclasses import dataclass
import json
import re

BOUND = 2**30


class ProfileError(ValueError):
    pass


@dataclass(frozen=True)
class Expr:
    kind: str
    type: str
    value: object
    children: tuple = ()


def tokenize(source, language):
    if language not in {'janet', 'newlisp'}:
        raise ProfileError('Unknown language')
    if not isinstance(source, str) or not source.isascii() or len(source) > 8192:
        raise ProfileError('ASCII source of at most8192 characters required')
    if any((ord(c)<32 and c not in '\t\r\n') or ord(c)==127 for c in source):
        raise ProfileError('Unsupported ASCII control character')
    marker = '#' if language == 'janet' else ';'
    for line in source.splitlines():
        position=line.find(marker)
        if position>0 and not line[position-1].isspace():
            raise ProfileError('Comment marker requires token boundary')
    source = re.sub(re.escape(marker) + r'[^\n]*', '', source)
    tokens = re.findall(r'[^\s()\[\]]+|[()\[\]]', source)
    return tokens


def parse(source, language):
    tokens = tokenize(source, language)
    index = 0
    def read(depth=0):
        nonlocal index
        if depth > 32 or index >= len(tokens):
            raise ProfileError('Missing expression or nesting limit')
        token = tokens[index]; index += 1
        if token in ('(', '['):
            closing = ')' if token == '(' else ']'
            values = []
            while index < len(tokens) and tokens[index] != closing:
                if tokens[index] in (')', ']'):
                    raise ProfileError('Mismatched delimiter')
                values.append(read(depth + 1))
            if index == len(tokens):
                raise ProfileError('Unclosed delimiter')
            index += 1
            return (token, values)
        if token in (')', ']'):
            raise ProfileError('Unexpected delimiter')
        return token
    raw = read()
    if index != len(tokens):
        raise ProfileError('Exactly one pure expression required')
    def typed(node, env, depth=0):
        if depth > 32:
            raise ProfileError('Type nesting limit')
        if isinstance(node, str):
            bools = {'true': True, ('false' if language == 'janet' else 'nil'): False}
            if node in bools:
                return Expr('literal', 'Bool', bools[node])
            if re.fullmatch(r'-?(0|[1-9][0-9]*)', node):
                if len(node.lstrip('-'))>10:
                    raise ProfileError('Integer literal outside bounded profile')
                value = int(node)
                if abs(value) > BOUND:
                    raise ProfileError('Integer literal outside bounded profile')
                return Expr('literal', 'Int', value)
            if node in env:
                return Expr('variable', env[node], node)
            raise ProfileError('Unsupported or unbound symbol: ' + node)
        delimiter, items = node
        if delimiter != '(' or not items or not isinstance(items[0], str):
            raise ProfileError('Expected supported call')
        op, args = items[0], items[1:]
        if op == 'let':
            if len(args) != 2 or isinstance(args[0], str):
                raise ProfileError('let requires bindings and one body')
            delimiter, bindings = args[0]
            if language == 'janet':
                if delimiter != '[' or len(bindings) % 2:
                    raise ProfileError('Janet let requires flat binding tuple')
                pairs = list(zip(bindings[::2], bindings[1::2]))
            else:
                if delimiter != '(':
                    raise ProfileError('newLisp let requires binding list')
                pairs = []
                for binding in bindings:
                    if isinstance(binding, str) or binding[0] != '(' or len(binding[1]) != 2:
                        raise ProfileError('Malformed newLisp binding')
                    pairs.append(tuple(binding[1]))
            if not pairs or len(pairs) > 16:
                raise ProfileError('let requires1..16 bindings')
            bound = []; local = dict(env)
            for name, value in pairs:
                if not isinstance(name, str) or name not in {'x','y','z',*('v'+str(i) for i in range(16))}:
                    raise ProfileError('Restricted binding identifier')
                if name in local or name in {'true','false','nil','if','let','not','and','or'}:
                    raise ProfileError('Shadowed or reserved binding')
                # Janet let is sequential; newLisp let initializes in the outer environment.
                expression = typed(value, local if language == 'janet' else env, depth+1)
                local[name] = expression.type; bound.append((name, expression))
            body = typed(args[1], local, depth+1)
            return Expr('let', body.type, tuple(bound), (body,))
        arity = 3 if op == 'if' else 1 if op == 'not' else 2
        if op not in {'+','-','*','=','<','<=','>','>=','if','not','and','or'} or len(args) != arity:
            raise ProfileError('Unsupported operator or arity: ' + op)
        children = tuple(typed(a, env, depth+1) for a in args)
        types = [a.type for a in children]
        if op in {'+','-','*','=','<','<=','>','>='}:
            if types != ['Int','Int']:
                raise ProfileError('Numeric operands required')
            kind = 'Int' if op in {'+','-','*'} else 'Bool'
        elif op == 'if':
            if types[0] != 'Bool' or types[1] != types[2]:
                raise ProfileError('Typed Boolean conditional required')
            kind = types[1]
        else:
            if any(t != 'Bool' for t in types):
                raise ProfileError('Boolean operands required')
            kind = 'Bool'
        return Expr(op, kind, None, children)
    result = typed(raw, {})
    # Closed programs are qualified only when every evaluated integer intermediate fits.
    evaluate(result)
    return result


def evaluate(node, env=None):
    env = {} if env is None else env
    if node.kind == 'literal':
        value = node.value
    elif node.kind == 'variable':
        value = env[node.value]
    elif node.kind == 'let':
        local = dict(env)
        # Each initializer IR already records its lexical variable references;
        # newLisp parallel initializers cannot refer to introduced names.
        for name, expression in node.value:
            local[name] = evaluate(expression, local)
        value = evaluate(node.children[0], local)
    elif node.kind == 'if':
        value = evaluate(node.children[1 if evaluate(node.children[0], env) else 2], env)
    elif node.kind in {'and','or'}:
        first = evaluate(node.children[0], env)
        value = (first and evaluate(node.children[1], env)) if node.kind == 'and' else (first or evaluate(node.children[1], env))
    elif node.kind == 'not':
        value = not evaluate(node.children[0], env)
    else:
        a, b = (evaluate(n, env) for n in node.children)
        value = {'+':lambda:a+b,'-':lambda:a-b,'*':lambda:a*b,'=':lambda:a==b,
                 '<':lambda:a<b,'<=':lambda:a<=b,'>':lambda:a>b,'>=':lambda:a>=b}[node.kind]()
    if type(value) is int and abs(value) > BOUND:
        raise ProfileError('Evaluated intermediate outside integer domain')
    return value


def emit(node):
    lines = []
    counter = 0
    def expression(n, env):
        nonlocal counter
        if n.kind == 'literal':
            return ('True' if n.value else 'False') if n.type == 'Bool' else str(n.value)
        if n.kind == 'variable':
            return env[n.value]
        if n.kind == 'let':
            local = dict(env)
            for name, value in n.value:
                generated = expression(value, local)
                target = 'binding_' + str(counter); counter += 1
                lines.append(target + ' = ' + generated)
                local[name] = target
            return expression(n.children[0], local)
        if n.kind == 'if':
            # Function bodies preserve branch laziness even when a branch includes let.
            condition = expression(n.children[0], env)
            target = 'choice_' + str(counter); counter += 1
            lines.append('if ' + condition + ':')
            start = len(lines)
            yes = expression(n.children[1], env)
            nested = lines[start:]; del lines[start:]
            lines.extend('    ' + line for line in nested)
            lines.append('    ' + target + ' = ' + yes)
            lines.append('else:')
            start = len(lines)
            no = expression(n.children[2], env)
            nested = lines[start:]; del lines[start:]
            lines.extend('    ' + line for line in nested)
            lines.append('    ' + target + ' = ' + no)
            return target
        if n.kind in {'and','or'}:
            # Lower to a typed conditional so a let-containing second operand remains lazy.
            boolean = Expr('literal', 'Bool', n.kind == 'or')
            replacement = Expr('if','Bool',None,(n.children[0],boolean,n.children[1])) if n.kind == 'or' else Expr('if','Bool',None,(n.children[0],n.children[1],boolean))
            return expression(replacement,env)
        if n.kind == 'not':
            return '(not ' + expression(n.children[0],env) + ')'
        a,b=(expression(c,env) for c in n.children)
        return '('+a+' '+('==' if n.kind=='=' else n.kind)+' '+b+')'
    value = expression(node,{})
    lines.append('value = ' + value)
    return '\n'.join(lines) + '\n'


def cirru_parse(source):
    """Selected Cirru layout/parenthesis/$ grammar, independent of native provider."""
    if not isinstance(source,str) or not source.isascii() or len(source)>8192:
        raise ProfileError('Cirru ASCII/resource bound')
    if any((ord(c)<32 and c!='\n') or ord(c)==127 for c in source):
        raise ProfileError('Cirru permits space and LF only as whitespace')
    if any(c in source for c in '\r\t"\\,'):
        raise ProfileError('Unsupported Cirru string/comma/escape/whitespace syntax')
    if re.search(r'(?<!\s)\$|\$(?!\s)',source):
        raise ProfileError('Cirru dollar requires whitespace on both sides')
    if re.search(r'[^\s(]\(|\)[^\s)]',source):
        raise ProfileError('Cirru parenthesis token boundary required')
    rows=[]
    for line in source.splitlines():
        if not line:
            continue
        spaces=len(line)-len(line.lstrip(' '))
        if not line.strip() or spaces%2:
            raise ProfileError('Two-space Cirru layout required')
        tokens=re.findall(r'[()$]|[^\s()$]+',line.strip())
        if any(not re.fullmatch(r'[A-Za-z0-9_+*/=<>!?:.\-]+|[()$]',token) for token in tokens):
            raise ProfileError('Restricted Cirru atom')
        index=0
        def group(closing=False,depth=0):
            nonlocal index
            if depth>32:raise ProfileError('Cirru nesting limit')
            result=[]
            while index<len(tokens):
                token=tokens[index];index+=1
                if token==')':
                    if not closing:raise ProfileError('Unexpected Cirru parenthesis')
                    return result
                if token=='(':
                    result.append(group(True,depth+1))
                elif token=='$':
                    if index==len(tokens):raise ProfileError('Empty Cirru dollar tail')
                    result.append(group(closing,depth+1))
                    return result
                else:result.append(token)
            if closing:raise ProfileError('Unclosed Cirru parenthesis')
            return result
        tree=group()
        if not tree:raise ProfileError('Empty Cirru line')
        rows.append((spaces,tree))
    if not rows or rows[0][0]!=0:raise ProfileError('Cirru root indentation')
    result=[];stack=[(-2,result)]
    for indent,tree in rows:
        while stack[-1][0]>=indent:stack.pop()
        if indent!=stack[-1][0]+2:raise ProfileError('Skipped Cirru indentation level')
        stack[-1][1].append(tree)
        stack.append((indent,tree))
    return result


def emit_cirru(tree):
    return 'value = '+json.dumps(tree,ensure_ascii=True)+'\n'
