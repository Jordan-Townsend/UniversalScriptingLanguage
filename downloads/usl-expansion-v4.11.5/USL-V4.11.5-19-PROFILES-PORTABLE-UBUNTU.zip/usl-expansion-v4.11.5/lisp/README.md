# Janet, newLISP and Cirru bounded profiles

This family adds three distinct catalog IDs. It does not qualify any full language standard. Janet and newLISP translate executable expressions into the existing USL interpreter. Cirru is a syntax notation: its contract is faithful syntax-tree processing, without a claim that this parser executes Cirru programs.

Run on the prepared Linux amd64 environment:

```bash
source /workspace/.onboarding/activate-usl.sh
cd /workspace/usl-expansion-v4.11.5/lisp
python restore.py
python -m unittest discover -v
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

`restore.py` fetches public, pinned providers into `providers/`. It makes no global installation and does not modify prior releases. Exclude `providers/` and `__pycache__/` from the portable source package. A C99 compiler, make, git, dpkg-deb, Node, Python3.12, Linux amd64 libc and libffi8 must be installed. Janet is built locally after exact source-file verification and a clean build. Installed newLISP and Cirru files are verified against pinned hashes. The Debian package is SHA256-pinned; this helper does not assert a separately verified Debian archive signature. The Cirru npm tarball is SHA256- and SHA512/SRI-pinned. Rerun all observations when a provider or platform changes.

## Executable expression semantics

The native hosts are Janet1.39.1 at commit `e9c6678614ef731d5c4e9bf7915c48224eb0aeb1` and newLISP10.7.5 from Debian package10.7.5-3. Janet's local build suffix does not change that pinned source identity. These independent source syntaxes share a typed IR after parsing.

Each source contains exactly one closed expression. Supported values are Boolean and exact integers. Supported operators are binary `+`, `-`, `*`, `=`, `<`, `<=`, `>`, `>=`; `not`; two-operand Boolean `and`/`or`; three-operand `if`; and lexical `let` with one body. All comparison operands are integers. Logical operands and conditions must be Boolean. Conditional branches have the same static type. Short-circuiting preserves the unevaluated branch. Every evaluated integer intermediate must lie within [-2^30,2^30]. Literals also obey that bound, including unevaluated literals. This avoids float precision and signed-overflow disagreements between hosts. Source is ASCII, at most8192 characters, with nesting depth at most32.

Janet uses `true`/`false` and flat binding tuples, for example `(let [x 3 y (+ x 4)] (* x y))`. Janet initializers see earlier bindings. newLISP uses `true`/`nil` and binding lists, for example `(let ((x 3) (y 4)) (* x y))`. newLISP initializers see the outer environment. The frontend rejects references to sibling initializers in newLISP. Bindings are limited to the verified unprotected native names `x`, `y`, `z`, `v0` through `v15`; no shadowing or duplicate bindings is accepted. This prevents protected native builtin names from silently changing semantics. Comments use Janet `#` or newLISP `;`, at the start of a line or preceded by whitespace.

Numeric truthiness, mixed types, general calls, functions, recursion, mutation, other numeric domains, strings, collections, modules, effects, libraries, ABI and concurrency remain outside this profile. Unsupported or uncertain syntax is rejected before translation. This is a closed-expression translator, not a general Lisp compiler.

## Cirru tree processing

The native implementation is `cirru-parser`0.10.8, gitHead `4b8af115285a396ea16f9080527fa281b7792f84`, running on actual Node. The independent frontend supports plain ASCII atoms from `[A-Za-z0-9_+*/=<>!?:.\-]+`, parentheses, `$` tail nesting and two-space indentation. A dollar must have whitespace on both sides; opening parentheses cannot adjoin a preceding atom, and closing parentheses cannot adjoin a following atom. These boundaries are checked explicitly after native counterexamples exposed a lexer difference. Space and LF are the only accepted whitespace; blank empty lines are allowed. Indentation starts at zero and advances one two-space level at a time.

`cirru_parse` produces a typed nested list of atom strings; `emit_cirru` emits the corresponding USL list construction. Actual native trees and generated USL values must equal independently authored expected trees. Quoted strings, escapes, comma transformations, general language evaluation, macros and other Cirru dialects are open obligations. No meaning is inferred for arbitrary atom names.

## Evidence and limits

`results/results.json` retains all source cases, native observed values, independent expectations, generated-USL hashes, provider identities, restrictions and outstanding obligations. Generated `.usl` files are under `results/generated/`. `native_executions` counts original expression/document result observations, not processes: each profile batches its trusted cases in one fresh native process. `fresh_native_process_invocations` is therefore1 per profile. Native outputs and USL execution evidence are always fresh; they are not replayed from a cache.

Intent oracles in `cases.py` are independent arithmetic functions or explicit syntax-tree constructions. They do not call the frontend, IR evaluator or generated program. The tests add native binding-name checks, selected lexical boundary search, malformed input, scope differences, integer bounds and lazy-branch checks. `COUNTEREXAMPLES.json` records discovered Cirru lexical failures and repaired rejection behavior.

Finite differential tests establish these scoped observations. They do not prove arbitrary source translation, parser correctness, host correctness, interpreter correctness, complete standards or arbitrary original intent. There are no full-standard qualifications in this family. The runner emits those limitations and open gates for each catalog ID.

Reference entry points, paired with the exact pinned implementation source:

- Janet documentation: https://janet-lang.org/docs/ and https://github.com/janet-lang/janet/tree/e9c6678614ef731d5c4e9bf7915c48224eb0aeb1
- newLISP reference: https://www.newlisp.org/downloads/newlisp_manual.html and Debian package https://deb.debian.org/debian/pool/main/n/newlisp/newlisp_10.7.5-3_amd64.deb
- Cirru syntax and parser: https://cirru.org/ and https://github.com/Cirru/parser.coffee/tree/4b8af115285a396ea16f9080527fa281b7792f84
