"""Hash-pinned providers in a private directory; no global installation."""
from pathlib import Path
import base64
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request

ROOT=Path(__file__).resolve().parent
COMMIT='e9c6678614ef731d5c4e9bf7915c48224eb0aeb1'
NEWLISP_URL='https://deb.debian.org/debian/pool/main/n/newlisp/newlisp_10.7.5-3_amd64.deb'
NEWLISP_SHA='36d53dd550f3fe1663130ab1ffd5a23a2244c6489e273c86ef86878d43db07ed'
CIRRU_URL='https://registry.npmjs.org/cirru-parser/-/cirru-parser-0.10.8.tgz'
CIRRU_SHA='b884e3aa06feef10f23857755e712d68abff2baa3f31b5f95abaff0feeffff98'
CIRRU_SRI='q05/qHIm3LRHoJFOx74I/fb/0VapFw9LZTYIZH5W5sJfSz4Fe6xedO3/T7HqmVHTBEkpvnCYECUMd1ZnvcYM0w=='


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def download(url,expected):
    with urllib.request.urlopen(url,timeout=45) as response:data=response.read(12*1024*1024)
    if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('Provider archive digest mismatch')
    return data


def main():
    providers=ROOT/'providers';providers.mkdir(exist_ok=True)
    target=providers/'janet'
    hashes=json.loads((ROOT/'janet-source-hashes.json').read_text())
    if not target.exists():
        with tempfile.TemporaryDirectory(prefix='janet-',dir=providers) as temporary:
            path=Path(temporary)/'source'
            subprocess.run(['git','init','-q',str(path)],check=True)
            subprocess.run(['git','-C',str(path),'fetch','-q','--depth','1','https://github.com/janet-lang/janet.git',COMMIT],check=True)
            subprocess.run(['git','-C',str(path),'checkout','-q','--detach','FETCH_HEAD'],check=True)
            actual=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
            if actual!=COMMIT:raise ValueError('Janet commit mismatch')
            shutil.rmtree(path/'.git')
            shutil.move(str(path),str(target))
    for relative,digest in hashes.items():
        if sha(target/relative)!=digest:raise ValueError('Janet source changed: '+relative)
    actual_files={str(p.relative_to(target)) for p in target.rglob('*') if p.is_file() and not str(p.relative_to(target)).startswith('build/')}
    if actual_files!=set(hashes):raise ValueError('Unexpected or missing Janet source file')
    # No forced slot count: source compilation uses the actual cgroup CPU allowance.
    jobs=len(os.sched_getaffinity(0))
    try:
        quota,period=Path('/sys/fs/cgroup/cpu.max').read_text().split()
        if quota!='max':jobs=min(jobs,max(1,int(quota)//int(period)))
    except (OSError,ValueError):pass
    subprocess.run(['make','clean'],cwd=target,check=True)
    subprocess.run(['make','build/janet','CFLAGS=-O2','-j'+str(jobs)],cwd=target,check=True)
    if not (providers/'newlisp/usr/bin/newlisp').exists():
        data=download(NEWLISP_URL,NEWLISP_SHA)
        with tempfile.TemporaryDirectory(prefix='newlisp-',dir=providers) as temporary:
            archive=Path(temporary)/'newlisp.deb';archive.write_bytes(data)
            subprocess.run(['dpkg-deb','-x',str(archive),str(providers/'newlisp')],check=True)
    if not (providers/'cirru/package/lib/parser.js').exists():
        data=download(CIRRU_URL,CIRRU_SHA)
        if base64.b64encode(hashlib.sha512(data).digest()).decode()!=CIRRU_SRI:raise ValueError('Cirru SRI mismatch')
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            archive.extractall(providers/'cirru',filter='data')
    pinned=json.loads((ROOT/'provider-hashes.json').read_text())
    for relative,digest in pinned.items():
        if sha(providers/relative)!=digest:raise ValueError('Provider installed-file mismatch: '+relative)
    identity={'Janet_commit':COMMIT,'Janet_verified_source_files':len(hashes),
              'Janet_binary_sha256':sha(target/'build/janet'),'newLisp_archive_sha256':NEWLISP_SHA,
              'Cirru_archive_sha256':CIRRU_SHA,'Cirru_SRI':'sha512-'+CIRRU_SRI,
              'installed_provider_hashes':pinned,
              'platform':'Linux amd64; rerun execution evidence after restoration',
              'required_external_tools':['Python3.12','Node','git','make','C99 compiler','dpkg-deb','libffi8 and libc6']}
    (providers/'RESTORE_RECEIPT.json').write_text(json.dumps(identity,indent=2)+'\n')
    print(json.dumps(identity))


if __name__=='__main__':main()
