"""Intent cases authored as arithmetic contracts, separately from frontend logic."""
import itertools
import random


def lisp_cases(language):
    false='false' if language=='janet' else 'nil'
    def boolean(value):return 'true' if value else false
    cases=[]
    def add(label,source,expected,heldout=False):
        cases.append({'name':label,'source':source,'expected':expected,'heldout':heldout})
    values=[-101,-17,-2,-1,0,1,2,7,31,99]
    for index,(a,b) in enumerate(itertools.product(values,repeat=2)):
        # Independent result definitions: no frontend/interpreter functions are called here.
        for op,result in [('+',a+b),('-',a-b),('*',a*b),('=',a==b),('<',a<b)]:
            add(op+str(index),f'({op} {a} {b})',result,index%7==3)
    rng=random.Random(194047)
    for index in range(43):
        a,b,c=[rng.randrange(-100,101) for _ in range(3)]
        add('nested-'+str(index),f'(if (<= {a} {b}) (+ {a} (* {b} {c})) (- {a} {c}))',a+b*c if a<=b else a-c,True)
        binding=f'[x {a} y {b}]' if language=='janet' else f'((x {a}) (y {b}))'
        add('binding-'+str(index),f'(let {binding} (if (> x y) (- x y) (+ x y)))',a-b if a>b else a+b,True)
    for a,b in itertools.product([False,True],repeat=2):
        add('and-'+str(a)+str(b),f'(and {boolean(a)} {boolean(b)})',a and b)
        add('or-'+str(a)+str(b),f'(or {boolean(a)} {boolean(b)})',a or b)
    for a in [False,True]:add('not-'+str(a),f'(not {boolean(a)})',not a)
    for value in [-(2**30),2**30]:add('boundary'+str(value),f'(+ {value} 0)',value,True)
    add('lazy-if',f'(if true 17 (* {2**30} 2))',17,True)
    add('lazy-and',f'(and {false} (= (* {2**30} 2) 0))',False,True)
    add('lazy-or',f'(or true (= (* {2**30} 2) 0))',True,True)
    add('nested-let',f'(let '+('[x 7]' if language=='janet' else '((x 7))')+' (let '+('[y (+ x 3)]' if language=='janet' else '((y (+ x 3)))')+' (* x y)))',70,True)
    if language=='janet':add('sequential-let','(let [x 3 y (+ x 4)] (* x y))',21,True)
    marker='#' if language=='janet' else ';'
    add('comments',f'(+ 7 {marker} commented ) tokens\n 3)',10,True)
    return cases


def cirru_cases():
    cases=[{'name':'flat','source':'add 1 2\n','expected':[['add','1','2']]},
           {'name':'nested-layout','source':'root\n  a 1\n    b 2\n  c 3\nnext 4\n','expected':[['root',['a','1',['b','2']],['c','3']],['next','4']]},
           {'name':'parentheses','source':'a (b c) d\n','expected':[['a',['b','c'],'d']]},
           {'name':'dollar','source':'a $ b c\n','expected':[['a',['b','c']]]},
           {'name':'dollar-chain','source':'a $ b $ c d\n','expected':[['a',['b',['c','d']]]]},
           {'name':'blank-line','source':'a b\n\nc d\n','expected':[['a','b'],['c','d']]},
           {'name':'empty-group','source':'a () b\n','expected':[['a',[],'b']]}]
    rng=random.Random(420610)
    for index in range(101):
        a,b,c=[str(rng.randrange(-999,1000)) for _ in range(3)]
        cases.extend([{'name':'flat-'+str(index),'source':f'op {a} {b} {c}\n','expected':[['op',a,b,c]],'heldout':True},
                      {'name':'layout-'+str(index),'source':f'root {a}\n  child {b}\n  sibling\n    leaf {c}\n','expected':[['root',a,['child',b],['sibling',['leaf',c]]]],'heldout':True},
                      {'name':'inline-'+str(index),'source':f'root ({a} {b}) $ child {c}\n','expected':[['root',[a,b],['child',c]]],'heldout':True}])
    return cases
