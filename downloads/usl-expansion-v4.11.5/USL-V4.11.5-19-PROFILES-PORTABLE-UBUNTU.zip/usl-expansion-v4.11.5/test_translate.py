"""Public CLI integration: real parsers/runtime, user intent and data protection."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/usl-v4.10.0-clean-test')
class TranslationTests(unittest.TestCase):
    def setUp(self):self.temporary=tempfile.TemporaryDirectory(prefix='usl-cli-test-');self.folder=Path(self.temporary.name);self.count=0
    def tearDown(self):self.temporary.cleanup()
    def call(self,request,run=True,extra=(),output=None,raw=None):
        self.count+=1;path=self.folder/('request'+str(self.count)+'.json');path.write_bytes(raw if raw is not None else json.dumps(request).encode());out=output or self.folder/('output'+str(self.count));before=path.read_bytes()
        existed=out.exists();command=[sys.executable,str(ROOT/'translate.py'),str(path),'--output',str(out)]
        if run:command.append('--run-usl')
        observed=subprocess.run(command+list(extra),capture_output=True,text=True,timeout=30,cwd=self.folder)
        self.assertEqual(path.read_bytes(),before)
        receipt=json.loads((out/'receipt.json').read_text()) if not existed and out.is_dir() and (out/'receipt.json').is_file() else None
        return observed,receipt,out
    def success(self,request,extra=()):
        observed,receipt,out=self.call(request,extra=extra);self.assertEqual(observed.returncode,0,observed.stdout+observed.stderr);self.assertTrue(receipt['ok']);self.assertFalse(receipt['qualification_created']);self.assertFalse(receipt['native_original_executed']);self.assertTrue(receipt['USL_executed']);self.assertEqual(hashlib.sha256((out/'generated.usl').read_bytes()).hexdigest(),receipt['generated_sha256']);return receipt
    def test_real_native_profile_translation(self):
        for language,source in [('nimrod','var x = 2\necho x + 3\n'),('icon','procedure main()\nlocal x\nx := 2\nwrite(x + 3)\nend\n'),('vala','int main() {\nint64 x = 2;\nPosix.printf("%lld\\n", (int64)(x + 3));\nreturn 0;\n}\n')]:
            with self.subTest(language=language):self.success({'catalog_id':language,'source':source,'expected':{'stdout':'5\n'}})
    def test_lisp_and_processing_ir_isolation(self):
        self.success({'catalog_id':'janet','source':'(let [x 7] (* x 3))','expected':{'result':21}})
        self.success({'catalog_id':'newlisp','source':'(let ((x 7)) (* x 3))','expected':{'result':21}})
        self.success({'catalog_id':'cirru','source':'add 1 2\n','expected':{'result':[['add','1','2']]}})
    def test_actual_server_config_translation(self):
        self.success({'catalog_id':'apacheconf','source':'Redirect 302 /r https://example.invalid/to\n','inputs':{'paths':['/r/x','/rx']},'expected':{'result':[[302,'https://example.invalid/to/x'],[404,'']]}})
        self.success({'catalog_id':'lighttpd','source':'url.redirect = ("^/r$" => "https://example.invalid/to")\n','inputs':{'path':'/r'},'expected':{'result':[301,'https://example.invalid/to']}})
        for id,source in [('vclsnippets','return(synth(201,"Made"));'),('vcl','vcl 4.1;\nbackend default none;\nsub vcl_recv { return(synth(201,"Made")); }\nsub vcl_synth { return(deliver); }\n')]:self.success({'catalog_id':id,'source':source,'inputs':{'path':'/anything'},'expected':{'result':[201,'Made']}})
    def test_actual_grammar_translations(self):
        self.success({'catalog_id':'treetop','source':'grammar Probe\nrule start\n"ab"\nend\nend\n','inputs':{'text':'ab'},'expected':{'result':True}})
        for id,target in [('antlr-ruby','Ruby'),('antlr-csharp','CSharp2')]:self.success({'catalog_id':id,'source':'grammar Probe;\noptions { language='+target+'; }\nstart: A B EOF;\nA: \'a\';\nB: \'b\';\n','inputs':{'text':'ab'},'expected':{'result':True}})
        self.success({'catalog_id':'jasmin','source':'.class public Program\n.super java/lang/Object\n.method public static run(I)I\n.limit stack 2\n.limit locals 1\niload_0\nbipush 7\niadd\nireturn\n.end method\n','inputs':{'argument':2147483647},'expected':{'result':-2147483642}})
    def test_shader_translation_and_explicit_limited_proof(self):
        for language in ['glsl','hlsl']:
            r=self.success({'catalog_id':language,'source':('#version 450\n' if language=='glsl' else '')+'uint evaluate(uint x,uint y){return x + y;}','inputs':{'pairs':[[4294967295,2],[7,3]]},'expected':{'result':[1,10]}},extra=['--prove-ir'])
            self.assertEqual(r['shader_IR_equivalence']['result'],'unsat');self.assertTrue(r['shader_IR_equivalence']['assumptions']);self.assertTrue(r['shader_IR_equivalence']['not_proved']);self.assertFalse(r['intent_proved'])
    def test_no_execution_without_flag(self):
        p,r,out=self.call({'catalog_id':'nimrod','source':'var x = 2\necho x\n'},run=False);self.assertEqual(p.returncode,0);self.assertFalse(r['USL_executed']);self.assertNotIn('observed',r)
    def test_actual_template_translation_embeds_bindings(self):
        for language in ['vue','ng2','html+ng2']:
            source='<p>Hello {{name}}</p>'
            if language=='vue':source='<template>'+source+'</template>'
            r=self.success({'catalog_id':language,'source':source,'inputs':{'bindings':{'name':'<world>&'}},'expected':{'result':'<p>Hello &lt;world&gt;&amp;</p>'}})
            self.assertEqual(r['result_variable'],'rendered')
    def test_template_rejects_executable_script_and_binding_injection(self):
        for source in ['<template><p>{{name}}</p><script>doAnything()</script></template>','<template><p>{{name.upper()}}</p></template>']:
            p,r,out=self.call({'catalog_id':'vue','source':source,'inputs':{'bindings':{'name':'x'}}});self.assertNotEqual(p.returncode,0);self.assertFalse(r['ok'])
        self.success({'catalog_id':'ng2','source':'<p>{{name}}</p>','inputs':{'bindings':{'name':"'); __import__('os'); ('"}},'expected':{'result':'<p>&#39;); __import__(&#39;os&#39;); (&#39;</p>'}})
    def test_unknown_id_and_non_allowlisted_module_rejected(self):
        for id in ['python','../../os','nim','__import__']:
            p,r,out=self.call({'catalog_id':id,'source':'x'});self.assertNotEqual(p.returncode,0);self.assertIsNone(r);self.assertFalse(out.exists())
    def test_unsupported_source_emits_error_without_generated_code(self):
        marker=self.folder/'must-not-exist'
        p,r,out=self.call({'catalog_id':'nimrod','source':'import os\nexecShellCmd("touch '+str(marker)+'")\n'});self.assertNotEqual(p.returncode,0);self.assertFalse(r['ok']);self.assertFalse((out/'generated.usl').exists());self.assertFalse(marker.exists())
    def test_user_intent_mismatch_is_failed_test_with_debuggable_source(self):
        p,r,out=self.call({'catalog_id':'janet','source':'(+ 2 3)','expected':{'result':6}});self.assertEqual(p.returncode,1);self.assertFalse(r['expected_matched']);self.assertEqual(r['observed']['result'],5);self.assertTrue((out/'generated.usl').is_file());self.assertFalse(r['qualification_created'])
    def test_boolean_is_not_integer_expected_result(self):
        p,r,out=self.call({'catalog_id':'janet','source':'1','expected':{'result':True}});self.assertEqual(p.returncode,1);self.assertFalse(r['expected_matched'])
    def test_strict_request_schema_duplicate_keys_and_limits(self):
        for raw in [b'{"catalog_id":"janet","catalog_id":"newlisp","source":"1"}',b'{"catalog_id":"janet","source":"1","module":"os"}',b'{"catalog_id":"janet","source":"1","inputs":{"text":"x"}}',b'{"catalog_id":"glsl","source":"x","inputs":{"pairs":[[true,0]]}}',b'{"catalog_id":"janet","source":"1","expected":{"result":NaN}}',b' '*65537]:
            p,r,out=self.call(None,raw=raw);self.assertNotEqual(p.returncode,0);self.assertFalse(out.exists())
    def test_expected_requires_actual_run(self):
        p,r,out=self.call({'catalog_id':'janet','source':'1','expected':{'result':1}},run=False);self.assertNotEqual(p.returncode,0);self.assertFalse(r['ok']);self.assertIn('--run-usl',r['error'])
    def test_request_file_cannot_be_output(self):
        self.count+=1;path=self.folder/('request'+str(self.count)+'.json');request={'catalog_id':'janet','source':'1'};body=json.dumps(request).encode();path.write_bytes(body)
        p=subprocess.run([sys.executable,str(ROOT/'translate.py'),str(path),'--output',str(path)],capture_output=True,text=True);self.assertNotEqual(p.returncode,0);self.assertEqual(path.read_bytes(),body)
    def test_previous_runtime_and_release_sources_preserved(self):
        for parent in [ROOT,BASE,Path('/workspace/usl-expansion-v4.11.4'),Path('/workspace/usl-planning-v4.11.2')]:
            target=parent/'must-not-create-cli-test';p,r,out=self.call({'catalog_id':'janet','source':'1'},output=target);self.assertNotEqual(p.returncode,0);self.assertFalse(target.exists())
    def test_existing_output_and_symlinks_preserved(self):
        target=self.folder/'existing';target.mkdir();sentinel=target/'receipt.json';sentinel.write_text('preserve me')
        p,r,out=self.call({'catalog_id':'janet','source':'1'},output=target);self.assertNotEqual(p.returncode,0);self.assertEqual(sentinel.read_text(),'preserve me')
        link=self.folder/'link';link.symlink_to(target,target_is_directory=True);p,r,out=self.call({'catalog_id':'janet','source':'1'},output=link/'new');self.assertNotEqual(p.returncode,0);self.assertFalse((target/'new').exists())
    def test_runtime_mismatch_rejected(self):
        fake=self.folder/'bad-runtime';(fake/'usl_systems').mkdir(parents=True);(fake/'usl_systems/language.py').write_text('raise Exception("must not execute")')
        p,r,out=self.call({'catalog_id':'janet','source':'1'},extra=['--source-root',str(fake)]);self.assertNotEqual(p.returncode,0);self.assertIn('SHA256',r['error'])
    def test_authenticated_runtime_does_not_import_untrusted_package_init(self):
        fake=self.folder/'runtime';package=fake/'usl_systems';package.mkdir(parents=True);shutil.copyfile(BASE/'usl_systems/language.py',package/'language.py');(package/'__init__.py').write_text('raise Exception("package init must not run")')
        self.success({'catalog_id':'janet','source':'(+ 2 3)','expected':{'result':5}},extra=['--source-root',str(fake)])
if __name__=='__main__':unittest.main()
