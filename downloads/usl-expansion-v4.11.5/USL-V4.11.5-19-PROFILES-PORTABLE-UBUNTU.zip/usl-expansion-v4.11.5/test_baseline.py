"""Historical ledger loss, identity substitution and forged-count controls."""
import copy
import unittest
from pathlib import Path
import tempfile
from baseline import derive, build


class HistoricalLedgerTests(unittest.TestCase):
    def test_self_consistent_replacement_manifest_cannot_reanchor_history(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'MANIFEST.json').write_text('{"files":{}}')
            with self.assertRaisesRegex(ValueError,'published v4.11.4 identity'):
                build(root,root/'must-not-be-written.json')
            self.assertFalse((root/'must-not-be-written.json').exists())

    def fixture(self):
        original=[dict(catalog_id=f'id-{i:03d}',original_catalog=True,
                       validated_bounded_profile=i<247,full_standard_qualified=False,
                       external_dependencies=[{'kind':'fixture-host'}],
                       specific_semantic_focus=['Closures, allocation and errors']) for i in range(606)]
        rows=[]
        for i in range(247,606):
            row=dict(catalog_id=f'id-{i:03d}',full_standard_qualified=False,evidence_checked=i<277)
            if i<277:
                row.update(new_bounded_profile=dict(catalog_id=row['catalog_id'],scoped_profile_validated=True,
                    full_standard_qualified=False,exact_profile='Historical bounded profile',
                    open_obligations=['Complete normative semantics remains open']),fresh_receipt_sha256='a'*64)
            rows.append(row)
        return ({'records':original+[dict(catalog_id='usl',original_catalog=False)]},
                {'records':rows},dict(bounded_original_profiles=277,
                    new_validated_bounded_profiles=30,original_IDs_without_bounded_profile=329))

    def test_preserves_all_original_ids_obligations_and_inputs(self):
        args=self.fixture();before=copy.deepcopy(args);rows=derive(*args)
        self.assertEqual(args,before)
        self.assertEqual(len(rows),606)
        self.assertEqual(sum(r['validated_bounded_profile'] for r in rows),277)
        self.assertTrue(all(r['external_dependencies']==[{'kind':'fixture-host'}] for r in rows))
        self.assertTrue(all(r['historical_profiles_requalified_now'] is False for r in rows))

    def test_omission_duplicate_and_substitution_cannot_compact_away_ids(self):
        for mutation in ['omit','duplicate','substitute']:
            args=self.fixture();rows=args[1]['records']
            if mutation=='omit':rows.pop()
            elif mutation=='duplicate':rows[-1]=copy.deepcopy(rows[0])
            else:rows[-1]['catalog_id']='external-id'
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):derive(*args)

    def test_raw_summary_claim_cannot_add_profiles(self):
        args=self.fixture();args[2]['bounded_original_profiles']=606
        with self.assertRaises(ValueError):derive(*args)

    def test_full_qualification_claim_is_rejected_at_both_boundaries(self):
        for boundary in ['catalog','progress','profile']:
            args=self.fixture()
            if boundary=='catalog':args[0]['records'][0]['full_standard_qualified']=True
            elif boundary=='progress':args[1]['records'][0]['full_standard_qualified']=True
            else:args[1]['records'][0]['new_bounded_profile']['full_standard_qualified']=True
            with self.subTest(boundary=boundary),self.assertRaises(ValueError):derive(*args)

    def test_profile_identity_cannot_be_borrowed_from_another_language(self):
        args=self.fixture();args[1]['records'][0]['new_bounded_profile']['catalog_id']='different-id'
        with self.assertRaises(ValueError):derive(*args)

    def test_historical_obligations_cannot_be_erased(self):
        args=self.fixture();args[1]['records'][0]['new_bounded_profile']['open_obligations']=[]
        with self.assertRaises(ValueError):derive(*args)


if __name__=='__main__':unittest.main()
