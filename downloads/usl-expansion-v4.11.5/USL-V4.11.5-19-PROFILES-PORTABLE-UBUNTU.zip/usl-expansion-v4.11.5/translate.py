"""Translate a strict JSON request into runnable USL using an isolated adapter."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from translation_worker import decode_request,FAMILIES,MAX_REQUEST,RequestError,adapter_available

ROOT=Path(__file__).resolve().parent
DEFAULT_RUNTIME=Path('/workspace/usl-v4.10.0-clean-test')
def digest(body):return hashlib.sha256(body).hexdigest()
def output_path(path,request_path,source_root):
    original=Path(path).absolute()
    for part in [original,*original.parents]:
        if part.is_symlink():raise RequestError('Output path must not contain symlinks')
    resolved=original.resolve()
    protected=[ROOT,Path(source_root).resolve(),Path('/workspace/usl-expansion-v4.11.4'),Path('/workspace/usl-planning-v4.11.2'),Path('/workspace/usl-qualification-v4.11.3')]
    if any(resolved==root or root in resolved.parents for root in protected):raise RequestError('Output must be outside release, previous-source and runtime directories')
    if resolved==request_path.resolve():raise RequestError('Output would overwrite request input')
    if resolved.exists():raise RequestError('Output must be a new directory; existing output is preserved')
    if not resolved.parent.is_dir():raise RequestError('Output parent must already exist')
    return resolved
def translate(request_path,output,source_root=DEFAULT_RUNTIME,run_usl=False,prove_ir=False):
    request_path=Path(request_path)
    if not request_path.is_file():raise RequestError('Request file does not exist')
    with request_path.open('rb') as stream:body=stream.read(MAX_REQUEST+1)
    request=decode_request(body);destination=output_path(output,request_path,source_root)
    command=[sys.executable,'-I',str(ROOT/'translation_worker.py'),'--source-root',str(Path(source_root).resolve())]
    if run_usl:command.append('--run-usl')
    if prove_ir:command.append('--prove-ir')
    started=time.monotonic()
    try:
        child=subprocess.run(command,input=body,capture_output=True,timeout=25,cwd=ROOT)
        if len(child.stdout)>4<<20:raise RequestError('Worker response limit4 MiB')
        try:payload=json.loads(child.stdout)
        except (ValueError,UnicodeError) as error:raise RequestError('Translation worker failed without valid receipt: '+child.stderr.decode(errors='replace')[:500]) from error
        if type(payload) is not dict or type(payload.get('ok')) is not bool:raise RequestError('Invalid worker receipt')
        if child.returncode not in (0,1):raise RequestError('Translation worker exited with status '+str(child.returncode))
    except subprocess.TimeoutExpired as error:raise RequestError('Translation worker exceeded25-second deadline') from error
    if request_path.read_bytes()!=body:raise RequestError('Request changed during translation; no artifacts written')
    generated=payload.pop('generated_USL',None)
    payload.update({'schema':'usl.user-translation.v1','catalog_id':request['catalog_id'],'request_sha256':digest(body),'source_sha256':digest(request['source'].encode()),'worker_sha256':digest((ROOT/'translation_worker.py').read_bytes()),'CLI_sha256':digest(Path(__file__).read_bytes()),'elapsed_seconds':time.monotonic()-started,'selected_profile_only':True,'full_standard_qualified':False,'qualification_created':False,'native_original_executed':False})
    if generated is not None:payload['generated_file']='generated.usl';payload['generated_sha256']=digest(generated.encode())
    # Exclusive creation makes repeat invocations fail without replacing files.
    destination.mkdir()
    if generated is not None:
        with (destination/'generated.usl').open('x',encoding='utf-8') as stream:stream.write(generated)
    with (destination/'receipt.json').open('x',encoding='utf-8') as stream:json.dump(payload,stream,indent=2,ensure_ascii=True,allow_nan=False);stream.write('\n')
    return payload
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('request',type=Path,nargs='?');parser.add_argument('--output',type=Path);parser.add_argument('--source-root',type=Path,default=DEFAULT_RUNTIME);parser.add_argument('--run-usl',action='store_true');parser.add_argument('--prove-ir',action='store_true');parser.add_argument('--list',action='store_true');args=parser.parse_args()
    if args.list:
        print(json.dumps({'catalog_ids':{key:{'family':family,'adapter_source_present':adapter_available(family)} for key,family in FAMILIES.items()},'profile_scope':'Selected strict v4.11.5 profiles only; adapter source presence is not qualification'},indent=2));return 0
    if args.request is None or args.output is None:parser.error('request file and --output new-directory are required')
    try:receipt=translate(args.request,args.output,args.source_root,args.run_usl,args.prove_ir)
    except Exception as error:
        print(json.dumps({'ok':False,'error_type':type(error).__name__,'error':str(error)[:2000]}),file=sys.stderr);return 2
    print(json.dumps({'ok':receipt['ok'],'catalog_id':receipt.get('catalog_id'),'generated_file':receipt.get('generated_file'),'USL_executed':receipt.get('USL_executed',False),'expected_matched':receipt.get('expected_matched'),'receipt':str(args.output/'receipt.json'),'error':receipt.get('error')}))
    return 0 if receipt['ok'] else 1
if __name__=='__main__':raise SystemExit(main())
