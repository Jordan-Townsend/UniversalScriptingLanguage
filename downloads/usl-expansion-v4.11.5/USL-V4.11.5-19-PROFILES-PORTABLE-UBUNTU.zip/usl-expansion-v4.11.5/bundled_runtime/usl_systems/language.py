"""Safe, budgeted USL subset interpreter; never exec/eval arbitrary Python source."""
from __future__ import annotations
import ast
import operator
import re
import time
from dataclasses import dataclass

class USLError(Exception):
    pass

class LimitExceeded(USLError):
    pass

class ReturnSignal(Exception):
    def __init__(self, value): self.value = value

class BreakSignal(Exception): pass
class ContinueSignal(Exception): pass


def normalize(source: str) -> str:
    """Support current 'let/function/print' and legacy Symbolic: lines."""
    out=[]
    for line in source.replace('\r\n','\n').split('\n'):
        prefix=line[:len(line)-len(line.lstrip())]
        rest=line.lstrip()
        m=re.match(r'Symbolic(?:\[[^]]+\])?:\s*(.*)',rest)
        if m: rest=m.group(1)
        if rest.startswith('//'):rest='#'+rest[2:]
        rest=re.sub(r'^let\s+','',rest)
        rest=re.sub(r'^function\s+','def ',rest)
        if re.match(r'^print\s+.+',rest) and not rest.startswith('print('):
            rest='print('+rest[6:]+')'
        out.append(prefix+rest)
    return '\n'.join(out)

SUPPORTED_STMTS = (ast.Expr,ast.Assign,ast.AugAssign,ast.If,ast.While,ast.For,ast.FunctionDef,ast.Return,ast.Break,ast.Continue,ast.Assert,ast.Pass)
SUPPORTED_EXPRS = (ast.Constant,ast.Name,ast.List,ast.Tuple,ast.Dict,ast.BinOp,ast.UnaryOp,ast.Compare,ast.BoolOp,ast.IfExp,ast.Subscript,ast.Call,ast.JoinedStr,ast.FormattedValue)
BINOPS = {ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.FloorDiv:operator.floordiv,ast.Mod:operator.mod,ast.Pow:operator.pow}
CMPOPS = {ast.Eq:operator.eq,ast.NotEq:operator.ne,ast.Lt:operator.lt,ast.LtE:operator.le,ast.Gt:operator.gt,ast.GtE:operator.ge,ast.In:lambda a,b:a in b,ast.NotIn:lambda a,b:a not in b}
UNARYOPS={ast.USub:operator.neg,ast.UAdd:operator.pos,ast.Not:operator.not_}
BUILTINS={'len':len,'str':str,'int':int,'float':float,'bool':bool,'sum':sum,'abs':abs,'round':round,'min':min,'max':max,'sorted':sorted,'range':range}


def parse(source: str) -> ast.Module:
    try: tree=ast.parse(normalize(source))
    except SyntaxError as e: raise USLError(f'Parse error line {e.lineno}: {e.msg}') from e
    for node in ast.walk(tree):
        if isinstance(node,ast.stmt) and not isinstance(node,SUPPORTED_STMTS):
            raise USLError(f'Unsupported statement {type(node).__name__} on line {getattr(node,"lineno", "?")}')
        if isinstance(node,ast.expr) and not isinstance(node,SUPPORTED_EXPRS):
            raise USLError(f'Unsafe/unsupported expression {type(node).__name__} on line {getattr(node,"lineno", "?")}')
        if isinstance(node,ast.Call) and (not isinstance(node.func,ast.Name) or node.keywords):
            raise USLError('Only direct named calls with positional arguments are permitted')
        if isinstance(node,ast.Name) and (node.id.startswith('_') or '__' in node.id):
            raise USLError('Private identifiers are prohibited')
        if isinstance(node,ast.Assign) and (len(node.targets)!=1 or not isinstance(node.targets[0],ast.Name)):
            raise USLError('Assignment target must be one variable')
        if isinstance(node,ast.For) and not isinstance(node.target,ast.Name):
            raise USLError('Loop target must be one variable')
        if isinstance(node,ast.FunctionDef) and (node.decorator_list or node.returns or node.args.kwarg or node.args.vararg or node.args.defaults or node.args.kwonlyargs or node.args.posonlyargs):
            raise USLError('Function accepts simple positional parameters only')
        if isinstance(node,ast.FunctionDef) and any(x.annotation for x in node.args.args):
            raise USLError('Typed function parameters are not supported in this interpreter')
        if isinstance(node,ast.BinOp) and type(node.op) not in BINOPS: raise USLError('Unsupported binary operator')
        if isinstance(node,ast.UnaryOp) and type(node.op) not in UNARYOPS: raise USLError('Unsupported unary operator')
        if isinstance(node,ast.Compare) and any(type(x) not in CMPOPS for x in node.ops): raise USLError('Unsupported comparison')
        if isinstance(node,ast.Subscript) and isinstance(node.slice,ast.Slice): raise USLError('Slices not supported')
        if isinstance(node,(ast.ListComp,ast.SetComp,ast.DictComp,ast.GeneratorExp)):
            raise USLError('Comprehensions are not supported')
    return tree

@dataclass
class Result:
    output: str
    variables: dict
    operations: int
    elapsed_ms: float

class Interpreter:
    def __init__(self, max_ops=100000, timeout=4.0, max_output=50000, max_depth=50, capabilities=None):
        self.max_ops=max_ops;self.timeout=timeout;self.max_output=max_output;self.max_depth=max_depth
        self.operations=0;self.start=0;self.lines=[];self.env={};self.depth=0;self.charcount=0
        self.capabilities=dict(capabilities or {})
        if any(not isinstance(k,str) or not k.isidentifier() or k.startswith('_') or '__' in k or k in BUILTINS or k=='print' or not callable(v) for k,v in self.capabilities.items()):
            raise USLError('Invalid explicit host capability')

    def tick(self):
        self.operations+=1
        if self.operations>self.max_ops: raise LimitExceeded('Maximum operation budget exceeded')
        if (self.operations % 256 == 0 or self.operations==1) and time.monotonic()-self.start>self.timeout:
            raise LimitExceeded('Execution time budget exceeded')

    def val(self,node,scope):
        self.tick()
        if isinstance(node,ast.Constant): return node.value
        if isinstance(node,ast.Name):
            if node.id in scope:return scope[node.id]
            if node.id in self.env:return self.env[node.id]
            raise USLError('Undefined variable: '+node.id)
        if isinstance(node,(ast.List,ast.Tuple)):
            x=[self.val(v,scope) for v in node.elts];return tuple(x) if isinstance(node,ast.Tuple) else x
        if isinstance(node,ast.Dict):return {self.val(k,scope):self.val(v,scope) for k,v in zip(node.keys,node.values)}
        if isinstance(node,ast.BinOp):
            a,b=self.val(node.left,scope),self.val(node.right,scope)
            if isinstance(node.op,ast.Pow) and (abs(b)>64 or (isinstance(a,(int,float)) and abs(a)>1e12)):
                raise LimitExceeded('Exponentiation size limit exceeded')
            if isinstance(node.op,ast.Mult) and any(isinstance(t,(str,list,tuple)) and len(t)>100000 for t in (a,b)):
                raise LimitExceeded('Multiplication size limit exceeded')
            try:r=BINOPS[type(node.op)](a,b)
            except (ValueError,TypeError,ZeroDivisionError,OverflowError) as e: raise USLError(str(e)) from e
            if isinstance(r,(str,list,tuple,dict)) and len(r)>100000:raise LimitExceeded('Value size limit exceeded')
            return r
        if isinstance(node,ast.UnaryOp):return UNARYOPS[type(node.op)](self.val(node.operand,scope))
        if isinstance(node,ast.Compare):
            cur=self.val(node.left,scope)
            for op,right in zip(node.ops,node.comparators):
                nextval=self.val(right,scope)
                if not CMPOPS[type(op)](cur,nextval):return False
                cur=nextval
            return True
        if isinstance(node,ast.BoolOp):
            if isinstance(node.op,ast.And):
                x=True
                for v in node.values:
                    x=self.val(v,scope)
                    if not x:return x
                return x
            x=False
            for v in node.values:
                x=self.val(v,scope)
                if x:return x
            return x
        if isinstance(node,ast.IfExp):return self.val(node.body if self.val(node.test,scope) else node.orelse,scope)
        if isinstance(node,ast.Subscript):
            x=self.val(node.value,scope);i=self.val(node.slice,scope)
            try:return x[i]
            except (TypeError,IndexError,KeyError) as e:raise USLError(str(e)) from e
        if isinstance(node,ast.JoinedStr):return ''.join(str(self.val(v,scope)) for v in node.values)
        if isinstance(node,ast.FormattedValue):
            if node.format_spec:raise USLError('Format specifications not supported')
            return str(self.val(node.value,scope))
        if isinstance(node,ast.Call):
            name=node.func.id
            args=[self.val(a,scope) for a in node.args]
            if name in self.capabilities:
                try:return self.capabilities[name](*args)
                except Exception as e:raise USLError('Host capability '+name+': '+str(e)) from e
            if name=='print':
                s=' '.join(str(a) for a in args)+'\n'
                self.charcount+=len(s)
                if self.charcount>self.max_output:raise LimitExceeded('Output size limit exceeded')
                self.lines.append(s);return None
            if name in BUILTINS:
                if name=='range':
                    try: r=range(*args)
                    except (ValueError,TypeError) as e: raise USLError(str(e)) from e
                    if len(r)>self.max_ops: raise LimitExceeded('Range exceeds operation budget')
                    return r
                try:return BUILTINS[name](*args)
                except (ValueError,TypeError,OverflowError) as e:raise USLError(str(e)) from e
            if name in self.env and isinstance(self.env[name],ast.FunctionDef):
                fn=self.env[name]
                if len(args)!=len(fn.args.args):raise USLError(f'{name} requires {len(fn.args.args)} arguments')
                if self.depth>=self.max_depth:raise LimitExceeded('Maximum function call depth exceeded')
                self.depth+=1
                try:
                    localscope=dict(zip((a.arg for a in fn.args.args),args))
                    try:self.statements(fn.body,localscope)
                    except ReturnSignal as ret:return ret.value
                    return None
                finally:self.depth-=1
            raise USLError('Call to unsupported function: '+name)
        raise USLError('Expression not implemented: '+type(node).__name__)

    def statements(self,statements,scope):
        for node in statements:
            self.tick()
            if isinstance(node,ast.Expr):self.val(node.value,scope)
            elif isinstance(node,ast.Assign):scope[node.targets[0].id]=self.val(node.value,scope)
            elif isinstance(node,ast.AugAssign):
                if not isinstance(node.target,ast.Name):raise USLError('Augmented assignment requires variable')
                if type(node.op) not in BINOPS:raise USLError('Unsupported augmented operator')
                name=node.target.id
                if name not in scope: raise USLError('Undefined variable: '+name)
                scope[name]=BINOPS[type(node.op)](scope[name],self.val(node.value,scope))
            elif isinstance(node,ast.If):self.statements(node.body if self.val(node.test,scope) else node.orelse,scope)
            elif isinstance(node,ast.While):
                while self.val(node.test,scope):
                    try:self.statements(node.body,scope)
                    except BreakSignal:break
                    except ContinueSignal:continue
                else:self.statements(node.orelse,scope)
            elif isinstance(node,ast.For):
                seq=self.val(node.iter,scope)
                if not isinstance(seq,(range,list,tuple,str)):raise USLError('For loop needs a finite sequence')
                if len(seq)>self.max_ops:raise LimitExceeded('Loop sequence too long')
                for item in seq:
                    self.tick();scope[node.target.id]=item
                    try:self.statements(node.body,scope)
                    except BreakSignal:break
                    except ContinueSignal:continue
                else:self.statements(node.orelse,scope)
            elif isinstance(node,ast.FunctionDef):
                if self.depth:raise USLError('Nested functions not supported')
                self.env[node.name]=node
            elif isinstance(node,ast.Return):raise ReturnSignal(self.val(node.value,scope) if node.value else None)
            elif isinstance(node,ast.Assert):
                if not self.val(node.test,scope):raise USLError('Assertion failed'+(': '+str(self.val(node.msg,scope)) if node.msg else ''))
            elif isinstance(node,ast.Break):raise BreakSignal()
            elif isinstance(node,ast.Continue):raise ContinueSignal()
            elif isinstance(node,ast.Pass):pass
            else:raise USLError('Unsupported statement: '+type(node).__name__)

    def run(self,source: str) -> Result:
        tree=parse(source);self.start=time.monotonic()
        try:self.statements(tree.body,self.env)
        except (ReturnSignal,BreakSignal,ContinueSignal) as e:raise USLError(f'Unexpected control statement: {type(e).__name__}')
        return Result(''.join(self.lines),{k:v for k,v in self.env.items() if not isinstance(v,ast.FunctionDef)},self.operations,round((time.monotonic()-self.start)*1000,3))
