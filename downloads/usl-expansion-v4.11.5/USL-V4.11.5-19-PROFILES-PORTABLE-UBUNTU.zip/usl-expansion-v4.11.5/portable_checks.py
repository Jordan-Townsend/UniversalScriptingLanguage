"""Exercise every public adapter using only the bundled interpreter and pip pins."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time
import unittest
import test_translate

ROOT=Path(__file__).resolve().parent
test_translate.BASE=ROOT/'bundled_runtime'


class PortableTranslationTests(test_translate.TranslationTests):
    def call(self,request,run=True,extra=(),output=None,raw=None):
        if '--source-root' not in extra:extra=(*extra,'--source-root',str(ROOT/'bundled_runtime'))
        return super().call(request,run,extra,output,raw)


if __name__=='__main__':
    started=time.monotonic();suite=unittest.defaultTestLoader.loadTestsFromTestCase(PortableTranslationTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    receipt={'passed':result.wasSuccessful(),'tests_run':result.testsRun,'failures':len(result.failures),
             'errors':len(result.errors),'python_version':platform.python_version(),'python_executable':sys.executable,
             'python_prefix':sys.prefix,'os_release':Path('/etc/os-release').read_text(),'architecture':platform.machine(),
             'packages':{n:importlib.metadata.version(n) for n in ['lark','z3-solver']},
             'bundled_runtime_sha256':hashlib.sha256((ROOT/'bundled_runtime/usl_systems/language.py').read_bytes()).hexdigest(),
             'all19_selected_adapters_exercised':result.wasSuccessful(),'native_original_hosts_installed_by_this_workflow':False,
             'retained_codex_python_or_node_required':False,'scope':'Pure supported source-to-USL adapters, caller tests and limited shader IR proofs; native/conformance suites remain separate',
             'elapsed_seconds':time.monotonic()-started}
    print(json.dumps(receipt));sys.exit(0 if result.wasSuccessful() else 1)
