"""Native counterexamples and separate HTML-value oracles for template adapters."""
import importlib.util
import json
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parent
FAMILY=ROOT/'web_templates'
spec=importlib.util.spec_from_file_location('reviewed_template_semantics',FAMILY/'semantics.py')
frontend=importlib.util.module_from_spec(spec);spec.loader.exec_module(frontend)
sys.path.insert(0,'/workspace/usl-v4.10.0-clean-test')


def source(language,html):return '<template>'+html+'</template>' if language=='vue' else html


def native(rows):
    p=subprocess.run(['node',str(FAMILY/'native.cjs')],input=json.dumps(rows),
                     text=True,capture_output=True,timeout=30)
    return p


class Values(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.tags=[];self.attributes=[];self.text=''
    def handle_starttag(self,tag,attrs):
        self.tags.append(tag)
        self.attributes.append({k:('' if v is None else v) for k,v in attrs
            if not k.startswith('_ng') and k!='ng-version'})
    def handle_data(self,text):self.text+=text


class IndependentTemplateTests(unittest.TestCase):
    def test_native_rejected_unicode_expression_whitespace_is_rejected(self):
        for language in ['vue','ng2','html+ng2']:
            attribute=':title' if language=='vue' else '[attr.title]'
            for html in ['<p '+attribute+'="\u0085name">x</p>','<p>{{\u0085name}}</p>']:
                row={'id':'C1-whitespace','language':language,'source':source(language,html),'bindings':{'name':'VALUE'}}
                with self.subTest(language=language,html=html):
                    p=native([row]);self.assertNotEqual(p.returncode,0,'Actual framework unexpectedly accepted counterexample')
                    with self.assertRaises(frontend.ProfileError):frontend.frontend(row['source'],language)

    def test_fresh_native_and_usl_values_against_separate_html_oracle(self):
        values=['',' ', '&<>"\' &amp; 中文 😀', '</p><script>alert(1)</script>']
        for language in ['vue','ng2','html+ng2']:
            attribute=':title' if language=='vue' else '[attr.title]'
            text=source(language,'<p '+attribute+'="name">前{{name}}後</p>')
            rows=[{'id':str(i),'language':language,'source':text,'bindings':{'name':value}} for i,value in enumerate(values)]
            p=native(rows);self.assertEqual(p.returncode,0,p.stderr);observed=json.loads(p.stdout)['observations']
            for row,value,actual in zip(rows,values,observed):
                generated,_=frontend.run_usl(row['source'],language,row['bindings'])
                for output in [actual['output'],generated]:
                    parsed=Values();parsed.feed(output);parsed.close()
                    self.assertEqual(parsed.tags,['p'])
                    self.assertEqual(parsed.attributes,[{'title':value}])
                    self.assertEqual(parsed.text,'前'+value+'後')

    def test_comparator_preserves_text_and_attribute_differences(self):
        for left,right in [('<p>a b</p>','<p>ab</p>'),('<p title="a">x</p>','<p title="b">x</p>'),
                           ('<p> </p>','<p></p>'),('<div><p>x</p><p>y</p></div>','<div><p>xy</p></div>')]:
            self.assertNotEqual(frontend.html_tree(left),frontend.html_tree(right))


if __name__=='__main__':unittest.main()
