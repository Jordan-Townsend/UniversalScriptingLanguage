"""Shared typed integer/control IR after separate native parsers; adapted v4.11.4.
No native syntax is inferred from this common representation.
"""
BOUND = 2**26
class ProfileError(ValueError): pass
RESERVED = set("addr and as asm bind block bool break case cast char concept const continue converter defer discard distinct div do elif else end enum except export false finally float for from func generic if import in include int int64 interface is isnot iterator let local macro method mixin mod new nil not notin object of or out proc procedure ptr raise ref return shl shr static template then true try tuple type uint using var when while with without xor yield write stdout main result self this typeof sizeof lock null signal class namespace public private protected void".split())
RESERVED.update("by to global link record create default all every fail initial invocable next repeat suspend until base catch construct delete foreach get params set switch throw abstract delegate dynamic ensures extern inline internal override owned requires throws unowned virtual volatile weak yields errordomain struct int8 int16 int32 uint8 uint16 uint32 uint64 float32 float64 double long short string uchar ulong unichar ushort range array seq echo".split())

def lower(nodes, language):
    bindings={};typed=[]
    def expression(node):
        kind=node[0]
        if kind=='constant':
            value=node[1]
            if type(value) is int and abs(value)>BOUND: raise ProfileError('Literal outside bounded exact-integer profile')
            return {'kind':'literal','type':'Bool' if type(value) is bool else 'ExactInt','value':value}
        if kind=='variable':
            if node[1] not in bindings: raise ProfileError('Unbound variable: '+node[1])
            name,typ=bindings[node[1]]
            return {'kind':'variable','type':typ,'name':name}
        if kind=='negative':
            value=expression(node[1])
            if value['type']!='ExactInt': raise ProfileError('Numeric negation requires ExactInt')
            return {'kind':'negative','type':'ExactInt','operand':value}
        left,right=expression(node[2]),expression(node[3])
        if left['type']!=right['type']: raise ProfileError('Mixed comparison or arithmetic types')
        if kind=='binary' and left['type']!='ExactInt': raise ProfileError('Arithmetic requires ExactInt')
        if kind=='compare' and node[1] not in {'==','!='} and left['type']!='ExactInt':
            raise ProfileError('Ordering requires ExactInt')
        return {'kind':kind,'type':'Bool' if kind=='compare' else 'ExactInt','operator':node[1],'left':left,'right':right}
    def statements(rows, depth=0):
        if depth>12: raise ProfileError('Control nesting limit12')
        result=[]
        for row in rows:
            kind=row[0]
            if kind in {'declare','assign'}:
                name=row[1];value=expression(row[2]);declaration=kind=='declare' or language=='moonscript' and name not in bindings
                if name in RESERVED: raise ProfileError('Reserved syntax or observation binding: '+name)
                if declaration:
                    if depth: raise ProfileError('Nested declarations excluded; blocks may update existing bindings')
                    if name in bindings: raise ProfileError('Duplicate declaration')
                    bindings[name]=('v'+str(len(bindings)),value['type'])
                    if len(bindings)>32: raise ProfileError('Binding limit32')
                if name not in bindings: raise ProfileError('Assignment requires an existing binding')
                target,typ=bindings[name]
                if typ!=value['type']: raise ProfileError('Assignment changes declared type')
                result.append({'kind':'declare' if declaration else 'assign','name':target,'type':typ,'value':value})
            elif kind=='output':result.append({'kind':'output','value':expression(row[1])})
            else:
                condition=expression(row[1])
                if condition['type']!='Bool': raise ProfileError('Control requires Bool')
                result.append({'kind':kind,'condition':condition,'body':statements(row[2],depth+1),
                               'otherwise':statements(row[3],depth+1) if kind=='condition' else []})
        return result
    typed=statements(nodes)
    return {'schema':'usl.bounded-imperative.typed-IR.v1','language':language,'numeric_domain':[-BOUND,BOUND],
            'maximum_live_bindings':32,'maximum_control_nesting':12,'statements':typed}


def emit(ir):
    lines=['function exact(n):','    assert abs(n) <= '+str(BOUND)+', "profile:integer-domain"','    return n']
    def expression(row):
        kind=row['kind']
        if kind=='literal':return repr(row['value'])
        if kind=='variable':return row['name']
        if kind=='negative':return 'exact(-('+expression(row['operand'])+'))'
        text='('+expression(row['left'])+' '+row['operator']+' '+expression(row['right'])+')'
        return 'exact('+text+')' if kind=='binary' else text
    def statements(rows,depth=0):
        if not rows:lines.append('    '*depth+'pass')
        for row in rows:
            prefix='    '*depth;kind=row['kind']
            if kind in {'declare','assign'}:lines.append(prefix+('let ' if kind=='declare' else '')+row['name']+' = '+expression(row['value']))
            elif kind=='output':
                value=expression(row['value'])
                lines.append(prefix+'print('+('("true" if '+value+' else "false")' if row['value']['type']=='Bool' else value)+')')
            else:
                lines.append(prefix+('if ' if kind=='condition' else 'while ')+expression(row['condition'])+':')
                statements(row['body'],depth+1)
                if kind=='condition' and row['otherwise']:
                    lines.append(prefix+'else:');statements(row['otherwise'],depth+1)
    statements(ir['statements'])
    return '\n'.join(lines)+'\n'
