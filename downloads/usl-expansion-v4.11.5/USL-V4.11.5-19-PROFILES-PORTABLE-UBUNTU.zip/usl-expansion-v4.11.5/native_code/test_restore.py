import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import restore

class AuthenticationTests(unittest.TestCase):
    def test_signed_upstream_indexes_authenticate(self):
        pins=json.loads((restore.ROOT/'PROVIDERS.json').read_text())
        self.assertEqual(len(restore.authenticate('trixie',pins['trixie'])),7)
        self.assertEqual(len(restore.authenticate('bookworm',pins['bookworm'])),1)
    def test_release_signature_tampering_rejected_even_with_rehashed_pin(self):
        pins=json.loads((restore.ROOT/'PROVIDERS.json').read_text())
        with tempfile.TemporaryDirectory(prefix='usl-auth-negative-') as d:
            root=Path(d)
            for name in ['DEBIAN_TRIXIE_INRELEASE.asc','DEBIAN_TRIXIE_RELEASE.txt']:shutil.copyfile(restore.ROOT/name,root/name)
            p=root/'DEBIAN_TRIXIE_INRELEASE.asc';body=p.read_bytes().replace(b'Suite:',b'Suxte:',1);p.write_bytes(body)
            pin=copy.deepcopy(pins['trixie']);pin['signed_release_sha256']=hashlib.sha256(body).hexdigest()
            with patch.object(restore,'ROOT',root),self.assertRaises(subprocess.CalledProcessError):restore.authenticate('trixie',pin)
    def test_package_pin_tampering_rejected(self):
        pin=json.loads((restore.ROOT/'PROVIDERS.json').read_text())['trixie'];pin['packages'][0]['SHA256']='0'*64
        with self.assertRaisesRegex(ValueError,'package mismatch'):restore.authenticate('trixie',pin)
    def test_size_and_sha_both_required(self):
        with self.assertRaises(ValueError):restore.check(b'a',hashlib.sha256(b'a').hexdigest(),2)
        with self.assertRaises(ValueError):restore.check(b'a','0'*64,1)
if __name__=='__main__':unittest.main()
