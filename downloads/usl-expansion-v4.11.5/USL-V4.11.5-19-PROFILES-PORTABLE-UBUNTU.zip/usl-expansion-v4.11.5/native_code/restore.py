"""Private, signed-index-authenticated native providers. No global install."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import tempfile
import urllib.request

ROOT=Path(__file__).resolve().parent

def sha(body):return hashlib.sha256(body).hexdigest()
def fetch(url):
    with urllib.request.urlopen(url,timeout=60) as response:return response.read()
def check(body,digest,size=None):
    if sha(body)!=digest or size is not None and len(body)!=int(size):raise ValueError('Provider integrity mismatch')
def item(text,path):
    for line in text.split('\nSHA256:\n',1)[1].splitlines():
        if not line.startswith(' '):break
        parts=line.split()
        if len(parts)==3 and parts[2]==path and re.fullmatch('[a-f0-9]{64}',parts[0]):return parts[0],int(parts[1])
    raise ValueError('Missing authenticated index item')
def authenticate(release,pin):
    signed=ROOT/('DEBIAN_'+release.upper()+'_INRELEASE.asc')
    check(signed.read_bytes(),pin['signed_release_sha256'])
    with tempfile.TemporaryDirectory(prefix='usl-native-auth-') as d:
        clear=Path(d)/'Release'
        subprocess.run(['sqv','--keyring','/usr/share/keyrings/debian-archive-keyring.pgp','--cleartext','--output',str(clear),str(signed)],check=True,capture_output=True)
        body=clear.read_bytes()
    check(body,pin['release_sha256'])
    if body!=(ROOT/('DEBIAN_'+release.upper()+'_RELEASE.txt')).read_bytes():raise ValueError('Frozen release mismatch')
    expected,size=item(body.decode(),'main/binary-amd64/Packages')
    if expected!=pin['index_sha256']:raise ValueError('Index pin mismatch')
    local=Path('/workspace/.onboarding/apt/lists/deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages') if release=='trixie' else Path('/workspace/.onboarding/apt-bookworm/lists/Packages.xz')
    if local.exists():
        index=local.read_bytes();index=lzma.decompress(index) if local.suffix=='.xz' else index
    else:
        compressed,compressed_size=item(body.decode(),'main/binary-amd64/Packages.xz')
        data=fetch('https://deb.debian.org/debian/dists/'+release+'/main/binary-amd64/by-hash/SHA256/'+compressed)
        check(data,compressed,compressed_size);index=lzma.decompress(data)
    check(index,expected,size)
    wanted={r['Package']:r for r in pin['packages']};found={}
    for block in index.decode().split('\n\n'):
        data=dict(line.split(': ',1) for line in block.splitlines() if ': ' in line and not line.startswith(' '))
        if data.get('Package') in wanted:
            row={k:data[k] for k in ('Package','Version','Filename','Size','SHA256')}
            if row!=wanted[row['Package']] or row['Package'] in found:raise ValueError('Provider package mismatch')
            found[row['Package']]=row
    if found!=wanted:raise ValueError('Incomplete package index')
    return list(found.values())
def main():
    pins=json.loads((ROOT/'PROVIDERS.json').read_text());rows=[]
    for release,pin in pins.items():rows.extend(authenticate(release,pin))
    prefix=ROOT/'providers';prefix.mkdir(exist_ok=True)
    for row in rows:
        body=fetch('https://deb.debian.org/debian/'+row['Filename']);check(body,row['SHA256'],row['Size'])
        with tempfile.TemporaryDirectory(prefix='usl-native-deb-') as d:
            p=Path(d)/'package.deb';p.write_bytes(body)
            subprocess.run(['dpkg-deb','-x',str(p),str(prefix)],check=True,capture_output=True)
    print(json.dumps({'packages':[r['Package'] for r in rows],'signed_release_verified':True,'index_and_archives_verified':True,'native_binaries_not_portable_source':True}))
if __name__=='__main__':main()
