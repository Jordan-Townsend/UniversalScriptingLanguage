"""Fresh independent intent/native/generated-USL agreement for three profiles."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
from cases import LANGUAGES,cases,restrictions,syntax
from frontend import parse,emit,ProfileError,BOUND
from native import execute,batch_source,split_batch,identity,digest

ROOT=Path(__file__).resolve().parent
RUNTIME_SHA='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'
def qualify(language,output):
    from usl_systems.language import Interpreter,USLError
    fixtures=cases(language);native_source=batch_source(language,fixtures)
    observed=execute(language,native_source);native_rows=split_batch(observed,len(fixtures));rows=[]
    for fixture,native_output in zip(fixtures,native_rows):
        ir=parse(fixture['source'],language);generated=emit(ir)
        result=Interpreter(max_ops=200000,timeout=2).run(generated)
        row={**fixture,'native_stdout':native_output,'typed_IR':ir,'generated_USL':generated,'generated_USL_sha256':hashlib.sha256(generated.encode()).hexdigest(),'generated_stdout':result.output.splitlines(),'USL_operations':result.operations,'fresh_execution':True}
        row['passed']=row['native_stdout']==row['generated_stdout']==row['expected_stdout'];rows.append(row)
    rejected=[]
    for name,source in restrictions(language):
        try:parse(source,language);raise AssertionError('Restriction accepted: '+name)
        except ProfileError as error:rejected.append({'name':name,'source':source,'profile_error':str(error),'passed':True})
    # Native-valid input outside this bounded profile must not broaden the claim.
    outside=syntax(language,[('x',BOUND)],[('print','x + 1')]);native_outside=execute(language,outside)
    try:Interpreter().run(emit(parse(outside,language)));overflow_rejected=False
    except USLError as error:overflow_rejected='profile:integer-domain' in str(error)
    overflow={'source':outside,'native':native_outside,'USL_domain_rejection':overflow_rejected,'passed':native_outside.get('stdout')==str(BOUND+1)+'\n' and overflow_rejected}
    # Invalid original source is genuinely rejected by each selected upstream host.
    invalid_source=syntax(language,[],[('print','1 +')]);native_invalid=execute(language,invalid_source)
    if native_invalid['compile_returncode']==0:raise AssertionError('Malformed original unexpectedly accepted: '+language)
    type_source=syntax(language,[],[('print','1 + "x"')]);native_type=execute(language,type_source)
    if native_type['compile_returncode']==0 and native_type.get('returncode')==0:raise AssertionError('Numeric/string original unexpectedly accepted: '+language)
    native_processes=sum(r['native_processes'] for r in [observed,native_outside,native_invalid,native_type])
    record={'catalog_id':language,'scoped_profile_validated':all(r['passed'] for r in rows+rejected+[overflow]),'full_standard_qualified':False,'profile_kind':'code-expression',
      'exact_profile':{'icon':'Icon 9.5.24b integer-only procedure main, explicit locals, goal comparisons only as control conditions; no Icon boolean-value fiction',
       'nimrod':'Catalog Nimrod/Nim aliases, pinned Nim 1.6.10 modern dialect; lowercase ASCII identifiers without underscores, var, integer expressions and indentation controls; spaces around binary arithmetic and attached unary minus',
       'vala':'Vala 0.56.18 POSIX profile, int64 locals and Posix.printf with explicit int64 observation cast; native C backend; nested unary negation excluded for observed C-emitter host gap'}[language]+'; decimal literals without leading zeros, bounded integers ±2^26 at every literal/intermediate; +,-,*, numeric comparisons, mutable bindings, if/else and while; source16 KiB/bindings32/nesting12/USL200000 operations2 seconds; native compilation90 seconds/execution10 seconds',
      'cases':len(rows),'native_executions':len(rows)+3,'usl_executions':len(rows)+1,'heldout_cases':sum(r['heldout'] for r in rows),'native_unit':'case observations/host rejection attempts (one fresh batched native program plus separate overflow, syntax-invalid and type-invalid probes); native process count separate',
      'native_processes':native_processes,'native_host':identity(language),'native_batch':{'source':native_source,'result':observed,'case_marker_protocol':'CASE:<ordinal> inserted by harness, case bodies preserved; outputs split independently of frontend'},
      'records':rows,'profile_restrictions':rejected,'intermediate_overflow_probe':overflow,'native_invalid_probe':{'source':invalid_source,'result':native_invalid},'native_type_error_probe':{'source':type_source,'result':native_type},
      'open_obligations':['Complete versioned normative grammar and semantics, including historical Nimrod compatibility separately','Strings, floating point, containers, functions, closures, modules and standard libraries','Icon failure/backtracking/generators/co-expressions and non-condition comparison results; Vala objects/ownership/GLib; Nim macros/effects/FFI','Exceptions, concurrency, ABI, linkage, platform/device and dependency matrices','Upstream full conformance and independent review','Universal equivalence and original-intent proofs: finite tests are evidence, not proof for arbitrary programs']}
    output.mkdir(parents=True,exist_ok=True);(output/(language+'.json')).write_text(json.dumps(record,indent=2)+'\n');return record
def main():
    p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    source_root=args.source_root.resolve()
    if digest(source_root/'usl_systems/language.py')!=RUNTIME_SHA:raise SystemExit('Pinned USL runtime identity mismatch')
    sys.path.insert(0,str(source_root));started=time.perf_counter();records=[qualify(language,args.output) for language in LANGUAGES]
    report={'schema':'usl.native-code.qualification.v1','records':records,'passed':all(r['scoped_profile_validated'] for r in records),'full_standard_qualifications':0,'seconds':time.perf_counter()-started,'runtime_sha256':RUNTIME_SHA,'execution_evidence_cached':False,'source_sha256':{p.name:digest(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.py','.json','.asc','.txt','.md'}}}
    (args.output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'seconds':report['seconds'],'profiles':[{k:r[k] for k in ('catalog_id','cases','native_executions','native_processes','usl_executions')} for r in records]}))
    if not report['passed']:raise SystemExit(1)
if __name__=='__main__':main()
