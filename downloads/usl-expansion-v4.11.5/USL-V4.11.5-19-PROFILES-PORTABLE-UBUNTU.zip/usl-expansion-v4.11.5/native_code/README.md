# Icon, Nimrod/Nim and Vala native semantic tranche

These are three executable bounded profiles, not three full-standard
qualifications. They parse native source into a shared typed integer/control IR,
generate actual `.usl`, execute it using the hash-pinned v4.10 runtime, and compare
fresh native outputs with independently authored intent fixtures. Shared IR does
not imply interchangeable native syntax or an unproved language guarantee.

| Catalog ID | Exact selected dialect/host | Selected rules |
|---|---|---|
| `icon` | Icon 9.5.24b, native `icont`/`iconx` | `procedure main()`, explicit initialized locals, integer expression arithmetic, `:=`, `write`, `if ... then`/`else` and `while ... do`; numeric comparisons are success/failure goals only in control position |
| `nimrod` | Nim 1.6.10; catalog lexer explicitly aliases `nimrod` and `nim` and describes Nim source | lowercase ASCII identifiers without underscores, `var`, assignment, `echo`, two-space `if`/`else`/`while`; spaces around binary arithmetic and attached unary minus |
| `vala` | Vala 0.56.18 `--profile=posix --pkg=posix`, native GCC backend | `int main()`, `int64` locals, integer operators, assignment, C-style control blocks; `Posix.printf` uses an explicit `int64` argument cast |

All use decimal literals without leading zeros and integers in `[-2^26,2^26]`
at each literal and intermediate operation. Comparisons support `== != < <= > >=`
in Nim/Vala, and `= ~= < <= > >=` in Icon. There are no Boolean values in this
profile: Icon comparison results must not be mistaken for ordinary Boolean
values. Variable types, initialized bindings, resource bounds and control
nesting are checked before or during generated execution. Unsupported syntax
fails closed. Historical Nimrod versions are not qualified by modern Nim.
Unicon is a separate catalog ID and remains unimplemented by this directory.

51 intent programs per ID exercise signed arithmetic, precedence, all six
comparisons including equality boundaries, branches, mutation, empty/repeated/
nested loops, positive/negative domain boundaries, negative literal output and
identifier keyword prefixes. Native originals run in one freshly compiled batch
per language, with separate compiler/type-error and native-valid domain probes.
The harness inserts ordinal markers and preserves each program body; it never
inserts expected results. `.usl` executes each original case independently.
Complete original source, generated source, typed IR, independent expected
results, outputs, versions and identity hashes are retained in `results/`.

Each ID has 51 successful native case observations plus three probe observations
or host-rejection attempts, and 52 USL runs including the domain rejection.
Those observation counts are not process counts: native work uses 7 processes
for Icon and 6 each for Nim/Vala, excluding separate identity queries and tests.
No execution evidence is replayed from a cache. Counts do not establish arbitrary
source equivalence or mathematical proof of the source's original intent.

Actual validation found a Vala 0.56.18 code-generation failure for nested unary
negation such as `-(-7)`: its C output contains invalid decrement syntax. The
exact observation is in `KNOWN_HOST_LIMITS.json`; the frontend rejects nested
unary negation. This is an explicit host/profile limitation, not a claim that
Vala's normative semantics prohibit that expression. Leading-zero literals,
adjacent symbolic operators, Nim spacing variants and uncast Vala printf values
are also excluded to avoid real native lexer/ABI differences.

Run on the prepared Linux/POSIX environment:

```bash
source /workspace/.onboarding/activate-usl.sh
cd /workspace/usl-expansion-v4.11.5/native_code
python restore.py
python -m unittest discover -v
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

`restore.py` installs eight exact Debian amd64 package pins privately in
`providers/` (approximately 31 MiB). It unconditionally verifies the bundled
signed release using `sqv` and the trusted Debian archive keyring, authenticates
the complete package index, checks exact package identity/size/SHA256, and then
extracts archives. Installed binaries are excluded from the portable source
release. Prerequisites include compatible Linux x86-64, glibc, X11/Xpm for Icon,
GLib and its existing runtime dependencies for the Vala compiler, GCC, `sqv`,
`dpkg-deb`, Python with Lark, and the specified USL runtime. Vala POSIX output
does not require GLib development headers. Source-only restoration and Ubuntu
26 integration must be validated by the parent release before those claims
are made. No macOS, Windows or alternate-architecture claim is made here.

`REFERENCES.json` identifies the catalog lexer files and authoritative public
sources. The Nim 1.6.10 manual and Vala 0.56.18 manual/parser/operator source are
included with hashes; failed first URLs have working upstream replacements.
Icon's official third-edition book index links the full language-reference
appendix. Debian upstream identities are authenticated in `PROVIDERS.json`.

Outstanding qualification gates include complete grammar and type/effect rules;
Icon generators/backtracking/co-expressions and other goal contexts; Nim
macros/metaprogramming/FFI; Vala ownership/objects/GLib; strings, floating point,
containers, functions, modules, standard libraries, exceptions and concurrency;
ABI and interoperability; upstream conformance; platform/version matrices;
independent review; and general semantic/intent proofs. No full-standard gate
is closed by this tranche.
