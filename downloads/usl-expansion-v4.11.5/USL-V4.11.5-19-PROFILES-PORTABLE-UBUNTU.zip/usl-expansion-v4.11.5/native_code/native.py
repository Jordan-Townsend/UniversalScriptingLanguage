"""Fresh native compile and execution, preserving exact original case bodies."""
import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parent
PROVIDERS=ROOT/'providers'
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def environment():
    env=dict(os.environ)
    env['LD_LIBRARY_PATH']=str(PROVIDERS/'usr/lib/x86_64-linux-gnu/vala-0.56')+':'+str(PROVIDERS/'usr/lib/x86_64-linux-gnu')+':'+env.get('LD_LIBRARY_PATH','')
    env['PATH']=str(PROVIDERS/'usr/bin')+':'+env['PATH']
    env['ICONX']=str(PROVIDERS/'usr/bin/iconx')
    return env
def identity(language):
    binary=PROVIDERS/'usr/bin'/({'icon':'icont','nimrod':'nim','vala':'valac'}[language])
    args=[str(binary),'-V' if language=='icon' else '--version']
    p=subprocess.run(args,env=environment(),capture_output=True,text=True,timeout=10)
    libs=subprocess.check_output(['ldd',str(binary)],env=environment(),text=True)
    paths=[]
    for line in libs.splitlines():
        match=re.search(r'=> (/\S+)',line)
        if match:paths.append(Path(match.group(1)).resolve())
    gcc=Path(shutil.which('gcc')).resolve()
    return {'version':p.stdout+p.stderr,'version_returncode':p.returncode,'binary_sha256':digest(binary),'binary_path':str(binary),'provider_manifest_sha256':digest(ROOT/'PROVIDERS.json'),'gcc_version':subprocess.check_output(['gcc','--version'],text=True).splitlines()[0],'gcc_binary_sha256':digest(gcc),'dynamic_libraries':{str(p):digest(p) for p in paths},'ldd':libs}
def execute(language,source):
    with tempfile.TemporaryDirectory(prefix='usl-native-code-') as d:
        work=Path(d);path=work/('program.'+{'icon':'icn','nimrod':'nim','vala':'vala'}[language]);path.write_text(source)
        binary=work/'program';env=environment()
        if language=='icon':args=[str(PROVIDERS/'usr/bin/icont'),'-s','-o',str(binary),str(path)]
        elif language=='nimrod':args=[str(PROVIDERS/'usr/bin/nim'),'c','--hints:off','--verbosity:0','--lib:'+str(PROVIDERS/'usr/lib/nim/lib'),'--nimcache:'+str(work/'cache'),'--out:'+str(binary),str(path)]
        else:args=[str(PROVIDERS/'usr/bin/valac'),'--profile=posix','--vapidir='+str(PROVIDERS/'usr/share/vala-0.56/vapi'),'--pkg=posix','-o',str(binary),str(path)]
        compile_result=subprocess.run(args,env=env,capture_output=True,text=True,timeout=90,cwd=work)
        row={'compile_returncode':compile_result.returncode,'compile_stdout':compile_result.stdout,'compile_stderr':compile_result.stderr,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'native_processes':1,'execution_evidence_cached':False}
        if compile_result.returncode==0:
            command=[str(PROVIDERS/'usr/bin/iconx'),str(binary)] if language=='icon' else [str(binary)]
            result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=10,cwd=work)
            row.update({'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'native_processes':2})
        return row
def batch_source(language,rows):
    if language=='icon':
        pieces=[r['source'].replace('procedure main()','procedure case'+str(i)+'()',1) for i,r in enumerate(rows)]
        pieces+=['procedure main()\n'+''.join('write("CASE:'+str(i)+'")\ncase'+str(i)+'()\n' for i in range(len(rows)))+'end\n']
        return '\n'.join(pieces)
    if language=='nimrod':return '\n'.join('echo "CASE:'+str(i)+'"\nblock:\n'+''.join('  '+line+'\n' for line in r['source'].splitlines()) for i,r in enumerate(rows))
    return 'int main() {\n'+''.join('Posix.printf("CASE:'+str(i)+'\\n");\n{\n'+r['source'].split('\n',1)[1].rsplit('return 0;',1)[0]+'}\n' for i,r in enumerate(rows))+'return 0;\n}\n'
def split_batch(result,count):
    if result.get('returncode')!=0:raise AssertionError('Native batch failed: '+str(result))
    outputs=[]
    for line in result['stdout'].splitlines():
        if line.startswith('CASE:'):
            if line!='CASE:'+str(len(outputs)):raise AssertionError('Native case ordering mismatch')
            outputs.append([])
        elif outputs:outputs[-1].append(line)
        else:raise AssertionError('Native output before first case')
    if len(outputs)!=count:raise AssertionError('Incomplete native case output')
    return outputs
