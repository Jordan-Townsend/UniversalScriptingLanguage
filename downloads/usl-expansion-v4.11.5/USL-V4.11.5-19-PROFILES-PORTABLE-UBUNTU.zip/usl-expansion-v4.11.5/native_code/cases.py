"""Independent arithmetic, control, mutation and boundary intent contracts."""
import itertools

LANGUAGES=('icon','nimrod','vala')
def syntax(language,declarations,body):
    """Render fixture syntax; does not call the frontend or typed IR."""
    def statement(row,depth):
        pad='  '*depth;kind=row[0]
        if kind=='set':return [pad+row[1]+(' := ' if language=='icon' else ' = ')+row[2]+(';' if language=='vala' else '')]
        if kind=='print':return [pad+({'icon':'write('+row[1]+')','nimrod':'echo '+row[1],'vala':'Posix.printf("%lld\\n", (int64)('+row[1]+'));'}[language])]
        condition=row[1]
        if language=='icon':condition=condition.replace('!=','~=').replace('==','=')
        if language=='nimrod':
            out=[pad+kind+' '+condition+':']
            for child in row[2]:out+=statement(child,depth+1)
            if len(row)>3:
                out+=[pad+'else:']
                for child in row[3]:out+=statement(child,depth+1)
            return out
        out=[pad+(kind+' '+condition+(' then {' if kind=='if' else ' do {') if language=='icon' else kind+' ('+condition+') {')]
        for child in row[2]:out+=statement(child,depth+1)
        if len(row)>3:
            out+=[pad+'} else {']
            for child in row[3]:out+=statement(child,depth+1)
        return out+[pad+'}']
    if language=='icon':lines=['procedure main()']+['local '+name for name,_ in declarations]+[name+' := '+str(value) for name,value in declarations]
    elif language=='nimrod':lines=['var '+name+' = '+str(value) for name,value in declarations]
    else:lines=['int main() {']+['int64 '+name+' = '+str(value)+';' for name,value in declarations]
    for row in body:lines+=statement(row,0)
    if language=='icon':lines+=['end']
    if language=='vala':lines+=['return 0;','}']
    return '\n'.join(lines)+'\n'

def cases(language):
    rows=[]
    def add(name,bindings,body,expected,heldout=False):rows.append({'name':name,'source':syntax(language,bindings,body),'expected_stdout':[str(x) for x in expected],'heldout':heldout})
    for a,b in itertools.product((-11,0,1,13),(-7,0,2,9)):
        add('arith-'+str(a)+'-'+str(b),[('x',a),('y',b)],[('print','x + y'),('print','x - y'),('print','x * y')],[a+b,a-b,a*b],a==13)
    for operator,oracle in [('==',lambda a,b:a==b),('!=',lambda a,b:a!=b),('<',lambda a,b:a<b),('<=',lambda a,b:a<=b),('>',lambda a,b:a>b),('>=',lambda a,b:a>=b)]:
        for a,b in [(-2,3),(3,-2),(3,3),(0,0)]:
            add('guard-'+operator+'-'+str(a)+'-'+str(b),[('x',a),('y',b),('z',0)],[('if','x '+operator+' y',[('set','z','17')],[('set','z','23')]),('print','z')],[17 if oracle(a,b) else 23],a==3)
    add('precedence',[],[('print','2 + 3 * 4'),('print','(2 + 3) * 4'),('print','0 - (0 - 7)')],[14,20,7])
    add('left-association',[],[('print','20 - 5 - 3'),('print','20 - (5 - 3)')],[12,18])
    add('mutation-old-value',[('x',5),('y',2)],[('set','x','x * y + x'),('set','y','x - y'),('print','x'),('print','y')],[15,13])
    add('zero-loop',[('x',4)],[('while','x < 3',[('set','x','x + 1')]),('print','x')],[4])
    add('sum-loop',[('x',0),('total',0)],[('while','x < 7',[('set','total','total + x'),('set','x','x + 1')]),('print','total'),('print','x')],[21,7],True)
    add('nested',[('x',0),('y',0),('total',0)],[('while','x < 4',[('set','y','0'),('while','y < 3',[('if','x > y',[('set','total','total + 1')],[('set','total','total - 1')]),('set','y','y + 1')]),('set','x','x + 1')]),('print','total')],[0],True)
    add('positive-bound',[('x',67108863)],[('print','x + 1')],[67108864],True)
    add('negative-bound',[('x',-67108863)],[('print','x - 1')],[-67108864],True)
    add('negative-multiply',[('x',-8192),('y',8192)],[('print','x * y')],[-67108864],True)
    add('negative-literal-output',[],[('print','-7'),('print','-67108864'),('print','0 - 1')],[-7,-67108864,-1],True)
    add('identifier-prefixes',[('letter',9),('whilex',7)],[('print','letter + whilex')],[16],True)
    return rows

def restrictions(language):
    return [
      ('unbound',syntax(language,[],[('print','unknown')])),
      ('keyword-binding',syntax(language,[('while',2)],[('print','while')])),
      ('outside-integer',syntax(language,[('x',67108865)],[('print','x')])),
      ('division',syntax(language,[('x',6)],[('print','x / 2')])),
      ('comparison-value',syntax(language,[('x',6)],[('print','x < 2')])),
      ('call',syntax(language,[('x',6)],[('print','abs(x)')])),
      ('nonascii',syntax(language,[('x',6)],[('print','é')])),
      ('implicit-declaration',syntax(language,[],[('set','x','1'),('print','x')])),
    ]
