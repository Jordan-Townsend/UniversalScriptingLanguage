import os
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parent))
from cases import LANGUAGES,cases,restrictions,syntax
from frontend import parse,emit,ProfileError
from native import execute,batch_source,split_batch
sys.path.insert(0,os.environ.get('USL_SOURCE_ROOT','/workspace/usl-v4.10.0-clean-test'))
from usl_systems.language import Interpreter,USLError

class FrontendTests(unittest.TestCase):
    def test_independent_intent_all_sources(self):
        for language in LANGUAGES:
            for case in cases(language):
                with self.subTest(language=language,name=case['name']):self.assertEqual(Interpreter(max_ops=200000).run(emit(parse(case['source'],language))).output.splitlines(),case['expected_stdout'])
    def test_restrictions(self):
        for language in LANGUAGES:
            for name,source in restrictions(language):
                with self.subTest(language=language,name=name),self.assertRaises(ProfileError):parse(source,language)
    def test_reserved_bindings(self):
        for language in LANGUAGES:
            for name in ['fail','initial','suspend','echo','stdout','main','float64','ensures','foreach']:
                with self.subTest(language=language,name=name),self.assertRaises(ProfileError):parse(syntax(language,[(name,2)],[('print',name)]),language)
    def test_intermediate_domain(self):
        for language in LANGUAGES:
            with self.subTest(language=language),self.assertRaisesRegex(USLError,'profile:integer-domain'):Interpreter().run(emit(parse(syntax(language,[('x',67108864)],[('print','x * 2')]),language)))
    def test_assignment_requires_initialized_binding(self):
        for language in LANGUAGES:
            with self.subTest(language=language),self.assertRaises(ProfileError):parse(syntax(language,[],[('while','0 < 1',[('set','x','1')])]),language)
    def test_nim_layout_rejects_tabs_and_missing_bodies(self):
        for source in ['var x = 1\nif x < 2:\necho x\n','var x = 1\nif x < 2:\n\techo x\n','var x = 1\nif x < 2:\n','var x = 1\nelse:\n  echo x\n']:
            with self.assertRaises(ProfileError):parse(source,'nimrod')
    def test_nim_style_insensitive_names_excluded(self):
        for source in ['var x_y = 1\necho x_y\n','var X = 1\necho X\n','var x = 1\nvar X = 2\necho X\n']:
            with self.assertRaises(ProfileError):parse(source,'nimrod')
    def test_symbolic_operator_boundaries(self):
        for language in LANGUAGES:
            for expression in ['x--2','x*-2','x++2','x**2']:
                with self.subTest(language=language,expression=expression),self.assertRaises(ProfileError):parse(syntax(language,[('x',3)],[('print',expression)]),language)
        for expression in ['x+ 2','x +2','- x']:
            with self.assertRaises(ProfileError):parse(syntax('nimrod',[('x',3)],[('print',expression)]),'nimrod')
    def test_vala_nested_unary_host_gap(self):
        with self.assertRaises(ProfileError):parse(syntax('vala',[],[('print','-(-7)')]),'vala')
    def test_leading_zero_native_dialect_difference_rejected(self):
        for language in LANGUAGES:
            with self.assertRaises(ProfileError):parse(syntax(language,[],[('print','012')]),language)
    def test_icon_comparison_only_goal(self):
        for expression in ['1 < 2','1 = 2','1 ~= 2']:
            with self.assertRaises(ProfileError):parse(syntax('icon',[],[('print',expression)]),'icon')
    def test_icon_local_initialization(self):
        for source in ['procedure main()\nlocal x\nwrite(x)\nend\n','procedure main()\nlocal x\nlocal x\nx := 1\nend\n']:
            with self.assertRaises(ProfileError):parse(source,'icon')
    def test_other_native_features_fail_closed(self):
        for language in LANGUAGES:
            for expression in ['1 / 2','1.5','"abc"','1 + true','[1,2]','x[0]','2 ** 3']:
                with self.subTest(language=language,expression=expression),self.assertRaises(ProfileError):parse(syntax(language,[('x',1)],[('print',expression)]),language)
    def test_source_and_binding_limits(self):
        for language in LANGUAGES:
            with self.assertRaises(ProfileError):parse(' '*16385,language)
            with self.assertRaises(ProfileError):parse(syntax(language,[('x'+str(i),i) for i in range(33)],[('print','x0')]),language)
    def test_crlf_equivalent(self):
        for language in LANGUAGES:
            source=cases(language)[0]['source'];self.assertEqual(parse(source,language),parse(source.replace('\n','\r\n'),language))
class NativeTests(unittest.TestCase):
    def test_actual_compiler_batch_and_independent_intent(self):
        for language in LANGUAGES:
            selected=[cases(language)[0],cases(language)[-5],cases(language)[-1]]
            observed=execute(language,batch_source(language,selected));self.assertEqual(split_batch(observed,len(selected)),[r['expected_stdout'] for r in selected])
    def test_native_rejects_malformed_original(self):
        for language in LANGUAGES:self.assertNotEqual(execute(language,syntax(language,[],[('print','1 +')]))['compile_returncode'],0)
    def test_native_rejects_numeric_string_type_error(self):
        for language in LANGUAGES:
            row=execute(language,syntax(language,[],[('print','1 + "x"')]))
            self.assertTrue(row['compile_returncode']!=0 or row.get('returncode')!=0)
    def test_negative_control_generated_operator_mutation(self):
        for language in LANGUAGES:
            case=cases(language)[0];generated=emit(parse(case['source'],language));mutated=generated.replace('v0 + v1','v0 - v1')
            self.assertNotEqual(mutated,generated);self.assertNotEqual(Interpreter().run(mutated).output.splitlines(),case['expected_stdout'])
if __name__=='__main__':unittest.main()
