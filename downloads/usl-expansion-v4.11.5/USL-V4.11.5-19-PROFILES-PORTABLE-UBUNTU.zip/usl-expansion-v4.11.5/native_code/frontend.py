"""Separate strict Icon 9, Nim 1.6 and Vala POSIX parsers → shared typed IR.

Only integer values; comparisons are control goals/conditions. In particular,
Icon comparison values are never misrepresented as booleans in value position.
"""
import re
from lark import Lark,Transformer
from shared_ir import BOUND,ProfileError,lower,emit

EXPRESSIONS=r'''
?expr: product (ADD product)* -> chain
?product: unary (MUL unary)* -> chain
?unary: "-" unary -> negative
      | NUMBER -> number
      | NAME -> variable
      | "(" expr ")"
condition: expr COMP expr -> comparison
ADD: "+" | "-"
MUL: "*"
NUMBER: /[0-9]+/
NAME: /[a-z][a-z0-9]*/
_NL: /\r?\n/
%import common.WS_INLINE
%ignore WS_INLINE
'''
ICON=r'''
start: "procedure" "main" "(" ")" _NL+ locals (statement _NL+)* "end" _NL*
locals: ("local" NAME _NL+)*
?statement: NAME ":=" expr -> assign
          | "write" "(" expr ")" -> output
          | "if" condition "then" block ("else" block)? -> condition
          | "while" condition "do" block -> loop
block: "{" _NL+ (statement _NL+)* "}"
COMP: "~=" | "<=" | ">=" | "=" | "<" | ">"
'''
VALA=r'''
start: "int" "main" "(" ")" "{" _NL* (statement _NL*)* "return" "0" ";" _NL* "}" _NL*
?statement: "int64" NAME "=" expr ";" -> declare
          | NAME "=" expr ";" -> assign
          | "Posix.printf" "(" /"%lld\\n"/ "," "(" "int64" ")" "(" expr ")" ")" ";" -> vala_output
          | "if" "(" condition ")" block ("else" block)? -> condition
          | "while" "(" condition ")" block -> loop
block: "{" _NL* (statement _NL*)* "}"
COMP: "==" | "!=" | "<=" | ">=" | "<" | ">"
'''
NIM=r'''
start: _NL* (statement _NL+)*
?statement: "var" NAME "=" expr -> declare
          | NAME "=" expr -> assign
          | "echo" expr -> output
          | "if" condition block ("else" block)? -> condition
          | "while" condition block -> loop
block: "{" _NL+ (statement _NL+)* "}"
COMP: "==" | "!=" | "<=" | ">=" | "<" | ">"
'''
class Tree(Transformer):
    def start(self,rows):return list(rows)
    def block(self,rows):return list(rows)
    def locals(self,rows):return ('locals',[str(x) for x in rows])
    def number(self,args):return ('constant',int(args[0]))
    def variable(self,args):return ('variable',str(args[0]))
    def negative(self,args):return ('negative',args[0])
    def chain(self,args):
        node=args[0]
        for i in range(1,len(args),2):node=('binary',str(args[i]),node,args[i+1])
        return node
    def comparison(self,args):
        operator={'=':'==','~=':'!='}.get(str(args[1]),str(args[1]))
        return ('compare',operator,args[0],args[2])
    def declare(self,args):return ('declare',str(args[0]),args[1])
    def assign(self,args):return ('assign',str(args[0]),args[1])
    def output(self,args):return ('output',args[0])
    def vala_output(self,args):return ('output',args[-1])
    def condition(self,args):return ('condition',args[0],args[1],args[2] if len(args)>2 else [])
    def loop(self,args):return ('loop',args[0],args[1])
PARSERS={name:Lark(grammar+EXPRESSIONS,parser='lalr',transformer=Tree()) for name,grammar in [('icon',ICON),('nimrod',NIM),('vala',VALA)]}

def nim_layout(source):
    lines=[];opened=0;header=False
    for line in source.splitlines():
        if not line.strip():continue
        if '\t' in line:raise ProfileError('Two-space indentation; tabs excluded')
        spaces=len(line)-len(line.lstrip(' '))
        if spaces%2:raise ProfileError('Two-space indentation required')
        level=spaces//2
        if level>opened or header and level!=opened:raise ProfileError('Invalid indentation/body')
        while opened>level:lines.append('}');opened-=1
        text=line.strip();header=False
        if text.startswith(('if ','while ')) and text.endswith(':'):
            lines.append(text[:-1]+' {');opened+=1;header=True
        elif text=='else:':
            if not lines or lines[-1]!='}':raise ProfileError('Orphan else')
            lines[-1]+=' else {';opened+=1;header=True
        elif '{' in text or '}' in text:raise ProfileError('Braces not Nim source syntax')
        else:lines.append(text)
    if header:raise ProfileError('Missing control body')
    return '\n'.join(lines+['}']*opened)+'\n'

def parse(source,language):
    if language not in PARSERS:raise ProfileError('Unsupported language')
    if not isinstance(source,str) or not source.isascii() or len(source)>16384:raise ProfileError('ASCII source limit16384')
    if '\r' in source.replace('\r\n','') or any(c in source for c in '\v\f\x1c\x1d\x1e\x1f'):raise ProfileError('LF/CRLF source only')
    if re.search(r'\b0[0-9]+\b',source):raise ProfileError('Decimal spelling without leading zeros required; Vala has octal literals')
    # Nim and Icon use maximal symbolic operators; C/Vala has decrement.
    # A parser that splits x--y into x - (-y) silently changes the language.
    for operator in re.findall(r'[+*<>=!~:-]+',source):
        if operator not in {'+','-','*','<','>','=','==','!=','<=','>=','~=','~',':',':='}:
            raise ProfileError('Unsupported symbolic operator token: '+operator)
    # Nim's operator spacing affects parsing. This selected surface requires
    # spaces around binary arithmetic, and attached unary minus only.
    if language=='nimrod':
        for match in re.finditer(r'[+*-]',source):
            before=source[:match.start()].rstrip();following=source[match.end():]
            unary=match.group()=='-' and (not before or before[-1] in '=(*+-' or before.endswith('echo'))
            if unary:
                if not following or following[0].isspace():raise ProfileError('Attached unary minus required')
            elif match.start()==0 or not source[match.start()-1].isspace() or not following or not following[0].isspace():
                raise ProfileError('Spaces around binary arithmetic required')
    try:nodes=PARSERS[language].parse(nim_layout(source) if language=='nimrod' else source+'\n')
    except ProfileError:raise
    except Exception as error:raise ProfileError('Source outside exact profile: '+str(error)[:140]) from error
    if language=='icon':
        declared=nodes.pop(0)[1]
        if len(set(declared))!=len(declared):raise ProfileError('Duplicate local')
        seen=set();converted=[]
        for node in nodes:
            if node[0]=='assign' and node[1] not in seen:
                if node[1] not in declared:raise ProfileError('Assignment without local')
                seen.add(node[1]);node=('declare',node[1],node[2])
            converted.append(node)
        if seen!=set(declared):raise ProfileError('Each local needs top-level initialization before control')
        nodes=converted
    result=lower(nodes,language)
    if language=='vala':
        def validate(value):
            if isinstance(value,dict):
                if value.get('kind')=='negative' and value['operand'].get('kind')=='negative':raise ProfileError('Vala0.56.18 C emitter rejects nested unary-minus constants; excluded profile surface')
                for child in value.values():validate(child)
            elif isinstance(value,list):
                for child in value:validate(child)
        validate(result)
    return result
