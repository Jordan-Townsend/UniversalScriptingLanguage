"""Verify or derive the private Java image from retained hash-pinned JDK inputs."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
PREFIX=Path('/workspace/.onboarding/ubuntu26-java21')


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def restore():
    data=json.loads((ROOT/'JAVA_IMAGE.json').read_text())
    if not PREFIX.exists():
        for name,expected in data['retained_build_inputs'].items():
            if sha(name)!=expected:raise ValueError('Retained Java build-input identity mismatch: '+name)
        command=[data['jlink'],'-J-Xmx512m','--module-path',data['jmods'],
                 '--add-modules','java.desktop,jdk.compiler','--strip-debug',
                 '--no-header-files','--no-man-pages','--compress=2','--output',str(PREFIX)]
        subprocess.run(command,check=True,timeout=180)
    for name,expected in data['image_files_sha256'].items():
        path=PREFIX/name
        if not path.resolve().is_relative_to(PREFIX) or sha(path)!=expected:
            raise ValueError('Private retained Java image mismatch: '+name)
    versions={}
    for tool in ['java','javac']:
        p=subprocess.run([str(PREFIX/'bin'/tool),'-version'],capture_output=True,text=True,check=True,timeout=15)
        versions[tool]=(p.stdout+p.stderr).strip()
    result={'verified_image_files':len(data['image_files_sha256']),'prefix':str(PREFIX),
            'versions':versions,'native_binaries_shipped':False,
            'scope':'Derived from retained Debian JDK21; requires matching inputs for reconstruction'}
    print(json.dumps(result));return result


if __name__=='__main__':restore()
