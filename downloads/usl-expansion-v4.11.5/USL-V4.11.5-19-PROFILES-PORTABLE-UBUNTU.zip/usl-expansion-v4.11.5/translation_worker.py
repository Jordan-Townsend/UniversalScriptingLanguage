"""One isolated, allowlisted frontend per process; JSON stdin/stdout protocol."""
import argparse
import dataclasses
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys

ROOT=Path(__file__).resolve().parent
RUNTIME_SHA='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'
MAX_REQUEST=65536
FAMILIES={**dict.fromkeys(['icon','nimrod','vala'],'native_code'),**dict.fromkeys(['janet','newlisp','cirru'],'lisp'),**dict.fromkeys(['apacheconf','lighttpd','vcl','vclsnippets'],'server_config'),**dict.fromkeys(['treetop','antlr-ruby','antlr-csharp','jasmin'],'grammar_hosts'),**dict.fromkeys(['glsl','hlsl'],'semantic_hosts'),**dict.fromkeys(['vue','ng2','html+ng2'],'web_templates')}
REQUIRED_FILES={'native_code':['frontend.py','shared_ir.py'],'lisp':['frontend.py'],'server_config':['frontends.py'],'grammar_hosts':['recognizer.py','treetop_profile.py','antlr_profile.py','jasmin_profile.py'],'semantic_hosts':['shader_profile.py','proofs.py'],'web_templates':['semantics.py']}
def adapter_available(family):return all((ROOT/family/name).is_file() for name in REQUIRED_FILES[family])
class RequestError(ValueError):pass
class AdapterUnavailable(RequestError):pass
def duplicate_free(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise RequestError('Duplicate JSON key: '+key)
        result[key]=value
    return result
def json_value(value,depth=0):
    if depth>20:raise RequestError('JSON nesting limit20')
    if value is None or type(value) in (str,bool):return
    if type(value) is int:
        if abs(value)>2**64:raise RequestError('JSON integer magnitude limit2^64')
        return
    if type(value) is float:raise RequestError('Floating-point request values are outside current profiles')
    if type(value) is list:
        if len(value)>512:raise RequestError('JSON list length limit512')
        for child in value:json_value(child,depth+1)
        return
    if type(value) is dict:
        if len(value)>128 or any(type(k) is not str for k in value):raise RequestError('JSON object key limit/type')
        for child in value.values():json_value(child,depth+1)
        return
    raise RequestError('Not a supported JSON value')
def decode_request(body):
    if len(body)>MAX_REQUEST:raise RequestError('Request size limit65536 bytes')
    try:request=json.loads(body,object_pairs_hook=duplicate_free,parse_constant=lambda value:(_ for _ in ()).throw(RequestError('Nonfinite JSON constant')))
    except (UnicodeError,json.JSONDecodeError) as error:raise RequestError('Invalid UTF-8 JSON request') from error
    validate_request(request);return request
def validate_request(request):
    json_value(request)
    if type(request) is not dict or set(request)-{'catalog_id','source','inputs','expected'}:raise RequestError('Request keys: catalog_id,source,inputs,expected only')
    if type(request.get('catalog_id')) is not str or request['catalog_id'] not in FAMILIES:raise RequestError('Unknown catalog_id; no implicit language aliases')
    if type(request.get('source')) is not str or not request['source'] or len(request['source'].encode())>16384:raise RequestError('Nonempty source string required, at most16384 UTF-8 bytes')
    inputs=request.get('inputs',{})
    if type(inputs) is not dict:raise RequestError('inputs must be an object')
    language=request['catalog_id'];family=FAMILIES[language]
    allowed={'native_code':set(),'lisp':set(),'server_config':{'path','paths'},'grammar_hosts':{'argument'} if language=='jasmin' else {'text'},'semantic_hosts':{'pairs'},'web_templates':{'bindings'}}[family]
    if set(inputs)-allowed:raise RequestError('Unsupported input key for '+language)
    if family=='server_config':
        if set(inputs) not in ({'path'},{'paths'}):raise RequestError('Supply exactly inputs.path or inputs.paths')
        paths=[inputs['path']] if 'path' in inputs else inputs['paths']
        if type(paths) is not list or not 1<=len(paths)<=64 or any(type(p) is not str for p in paths):raise RequestError('Supply1..64 string paths')
    elif family=='grammar_hosts':
        if language=='jasmin':
            if set(inputs)!={'argument'} or type(inputs['argument']) is not int or not -2**31<=inputs['argument']<2**31:raise RequestError('inputs.argument must be exact signed32 integer')
        elif set(inputs)!={'text'} or type(inputs['text']) is not str or len(inputs['text'])>128:raise RequestError('inputs.text string up to128 characters required')
    elif family=='semantic_hosts':
        pairs=inputs.get('pairs')
        if type(pairs) is not list or not 1<=len(pairs)<=256 or any(type(p) is not list or len(p)!=2 or any(type(v) is not int or not 0<=v<2**32 for v in p) for p in pairs):raise RequestError('inputs.pairs requires1..256 exact uint32 pairs')
    elif family=='web_templates' and (set(inputs)!={'bindings'} or type(inputs['bindings']) is not dict):raise RequestError('inputs.bindings object required')
    if 'expected' in request:
        expected=request['expected']
        if type(expected) is not dict or not expected or set(expected)-{'stdout','result'}:raise RequestError('expected must contain stdout and/or result')
        if 'stdout' in expected and type(expected['stdout']) is not str:raise RequestError('expected.stdout must be an exact string')
        if family=='native_code' and 'result' in expected:raise RequestError('Native integer programs expose stdout; expected.result unavailable')
    return request
def checked_runtime(source_root):
    path=Path(source_root).resolve()/'usl_systems/language.py'
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=RUNTIME_SHA:raise RequestError('Pinned USL runtime SHA256 mismatch')
    # Load the authenticated, stdlib-only file directly. Do not execute an
    # arbitrary package __init__.py supplied beside it.
    spec=importlib.util.spec_from_file_location('usl_translation_runtime',path);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module
def serializable(value):
    if dataclasses.is_dataclass(value):return {field.name:serializable(getattr(value,field.name)) for field in dataclasses.fields(value)}
    if type(value) in (list,tuple):return [serializable(child) for child in value]
    if type(value) is dict:return {key:serializable(child) for key,child in value.items()}
    return value
def adapt(request,runtime,prove=False):
    language=request['catalog_id'];family=FAMILIES[language];directory=ROOT/family
    if not adapter_available(family):raise AdapterUnavailable('Selected adapter source is not installed completely: '+family)
    sys.path.insert(0,str(directory));source=request['source'];inputs=request.get('inputs',{});proof=None
    if family=='native_code':
        from frontend import parse,emit
        ir=parse(source,language);generated=emit(ir);result_variable=None
    elif family=='lisp':
        import frontend
        if language=='cirru':ir=frontend.cirru_parse(source);generated=frontend.emit_cirru(ir)
        else:ir=frontend.parse(source,language);generated=frontend.emit(ir)
        result_variable='value'
    elif family=='server_config':
        from frontends import frontend,check_path
        paths=[inputs['path']] if 'path' in inputs else inputs['paths']
        for path in paths:check_path(path)
        ir,generated=frontend(language,source)
        expression='respond('+repr(paths[0])+')' if 'path' in inputs else '['+', '.join('respond('+repr(path)+')' for path in paths)+']'
        generated+='\nlet result = '+expression+'\n';result_variable='result'
    elif family=='grammar_hosts':
        if language=='jasmin':
            import jasmin_profile as frontend
            ir=frontend.parse(source);generated=frontend.translate(source,inputs['argument'])
        elif language=='treetop':
            import treetop_profile as frontend
            ir=frontend.parse(source);generated=frontend.translate(source,inputs['text'])
        else:
            import antlr_profile as frontend
            target='Ruby' if language=='antlr-ruby' else 'CSharp2'
            ir=frontend.parse(source,target);generated=frontend.translate(source,inputs['text'],target)
        result_variable='result'
    elif family=='semantic_hosts':
        from shader_profile import parse,translate
        ir=parse(source,language);generated=translate(source,language,inputs['pairs']);result_variable='result'
        if prove:
            from proofs import check
            proof=check(ir,generated,runtime)
            if proof['result']!='unsat':raise RequestError('Shader typed-IR/emitted-AST equivalence was not established: '+proof['result'])
    else:
        try:import semantics as frontend
        except ModuleNotFoundError as error:raise AdapterUnavailable('Template adapter is not installed') from error
        ir=frontend.frontend(source,language);frontend.validate_bindings(ir,inputs['bindings']);generated='function template_binding(key):\n    return '+repr(inputs['bindings'])+'[key]\n'+frontend.emit_usl(ir);result_variable='rendered'
    if not isinstance(generated,str) or not generated or len(generated.encode())>1048576:raise RequestError('Generated source limit1 MiB')
    runtime.parse(generated)
    return generated,serializable(ir),result_variable,proof
def strict_equal(left,right):
    if type(left) is not type(right):return False
    if type(left) is list:return len(left)==len(right) and all(strict_equal(a,b) for a,b in zip(left,right))
    if type(left) is dict:return left.keys()==right.keys() and all(strict_equal(left[k],right[k]) for k in left)
    return left==right
def process(request,source_root,run_usl=False,prove=False):
    validate_request(request)
    if 'expected' in request and not run_usl:raise RequestError('Expected outputs require --run-usl')
    if prove and request['catalog_id'] not in {'glsl','hlsl'}:raise RequestError('--prove-ir is available only for selected GLSL/HLSL profiles')
    runtime=checked_runtime(source_root);generated,ir,result_variable,proof=adapt(request,runtime,prove)
    adapter=ROOT/FAMILIES[request['catalog_id']]
    payload={'ok':True,'catalog_id':request['catalog_id'],'family':FAMILIES[request['catalog_id']],'generated_USL':generated,'typed_or_processing_IR':ir,'result_variable':result_variable,'runtime_sha256':RUNTIME_SHA,'adapter_source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(adapter.glob('*.py'))},'full_standard_qualified':False,'native_original_executed':False,'qualification_created':False,'intent_proved':False,'shader_IR_equivalence':proof,'USL_executed':False}
    if run_usl:
        result=runtime.Interpreter(max_ops=1000000,timeout=5,max_depth=120).run(generated)
        payload['USL_executed']=True;payload['observed']={'stdout':result.output,'result':result.variables[result_variable] if result_variable else None};payload['USL_operations']=result.operations
        if 'expected' in request:
            checks={key:strict_equal(value,payload['observed'][key]) for key,value in request['expected'].items()};payload['expected_checks']=checks;payload['expected_matched']=all(checks.values());payload['ok']=payload['expected_matched'];payload['caller_test_is_qualification_or_proof']=False
    return payload
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-root',required=True);parser.add_argument('--run-usl',action='store_true');parser.add_argument('--prove-ir',action='store_true');args=parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU,(18,20));resource.setrlimit(resource.RLIMIT_AS,(768<<20,768<<20));resource.setrlimit(resource.RLIMIT_FSIZE,(2<<20,2<<20));resource.setrlimit(resource.RLIMIT_NOFILE,(128,128))
    try:
        request=decode_request(sys.stdin.buffer.read(MAX_REQUEST+1));payload=process(request,args.source_root,args.run_usl,args.prove_ir)
    except Exception as error:payload={'ok':False,'error_type':type(error).__name__,'error':str(error)[:2000],'qualification_created':False}
    print(json.dumps(payload,ensure_ascii=True,allow_nan=False))
    return 0 if payload['ok'] else 1
if __name__=='__main__':raise SystemExit(main())
