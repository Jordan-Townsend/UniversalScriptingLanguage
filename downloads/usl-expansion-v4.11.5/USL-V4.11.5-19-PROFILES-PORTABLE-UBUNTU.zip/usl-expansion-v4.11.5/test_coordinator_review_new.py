"""Independent lifecycle, ownership, integrity and resource-admission controls.
All execution fixtures are harmless Python processes, not language qualifications.
"""
import asyncio
import copy
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest.mock import patch
import coordinator
import test_coordinator_independent as previous_review
alive=previous_review.alive
SOURCE=previous_review.SOURCE


def make_family(root,name,script=None,test=None):
    family=root/name;family.mkdir()
    (family/'test_fixture.py').write_text(test or 'import unittest\nclass Test(unittest.TestCase):\n def test_ok(self):self.assertTrue(True)\n')
    if script is None:
        record={'catalog_id':'lang-000','scoped_profile_validated':True,'full_standard_qualified':False,
                'exact_profile':'Independent lifecycle fixture, not a real language profile','cases':1,
                'native_executions':1,'usl_executions':1,'open_obligations':['All language implementation remains open']}
        script='import argparse,json,pathlib\np=argparse.ArgumentParser();p.add_argument("--source-root");p.add_argument("--output");a=p.parse_args();out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True);(out/"results.json").write_text('+repr(json.dumps({'records':[record]}))+')\n'
    (family/'run.py').write_text(script)
    return {'directory':name,'catalog_ids':['lang-000'],'source_sha256':coordinator.source_files(family),'native_unit':'harmless Python fixture'}


async def wait_for_file(path,timeout=5):
    deadline=asyncio.get_running_loop().time()+timeout
    while not path.exists():
        if asyncio.get_running_loop().time()>deadline:raise AssertionError('Lifecycle fixture did not start: '+str(path))
        await asyncio.sleep(0.01)


class IntegrityAndResources(unittest.TestCase):
    def test_directory_symlinks_cannot_hide_executed_source(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root=base/'family';root.mkdir();other=base/'outside';other.mkdir();(other/'helper.py').write_text('value=1\n');(root/'hidden').symlink_to(other,target_is_directory=True)
            with self.assertRaises(ValueError):coordinator.source_files(root)
            (root/'hidden').unlink();(root/'inside').mkdir();(root/'inside/helper.py').write_text('value=1\n');(root/'hidden').symlink_to(root/'inside',target_is_directory=True)
            with self.assertRaises(ValueError):coordinator.source_files(root)
    def test_clean_reclaim_cannot_manufacture_more_than_memory_limit(self):
        unit=256<<20
        for maximum,current,inactive,dirty,writeback in [(8,5,100,0,0),(8,10,100,0,0),(8,5,4,9,2)]:
            value=coordinator.admission_counts(40,maximum*unit,current*unit,inactive*unit,dirty*unit,writeback*unit,1024)
            self.assertLessEqual(value['available_after_estimated_reclaim_bytes'],maximum*unit)
            self.assertLessEqual(value['clean_inactive_file_estimate_bytes'],current*unit)
            self.assertTrue(value['reclaim_is_not_guaranteed'])
            self.assertTrue(value['estimate_is_not_a_proved_peak_memory_bound'])


class IndependentLifecycleReview(unittest.IsolatedAsyncioTestCase):
    def fixture(self,base):return previous_review.IndependentAsyncReview.fixture(self,base)
    def registry(self,root,registry,job):
        registry['families']=[job];(root/'REGISTERED_FAMILIES.json').write_text(json.dumps(registry))
    async def test_cancellation_before_actor_release_reaps_every_created_task(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root,previous,registry=self.fixture(base);self.registry(root,registry,make_family(root,'family'))
            original_sleep=asyncio.sleep;before=set(asyncio.all_tasks())
            async def cancel_at_start(delay,*args,**kwargs):
                if delay==0:asyncio.current_task().cancel()
                return await original_sleep(delay,*args,**kwargs)
            try:
                with patch.object(coordinator,'ROOT',root),patch.object(asyncio,'sleep',cancel_at_start),self.assertRaises(asyncio.CancelledError):
                    await coordinator.run(previous,SOURCE,base/'output')
                leaked=[t for t in asyncio.all_tasks() if t not in before and not t.done()]
                self.assertEqual(leaked,[],'Startup cancellation leaked family futures / logical actors')
            finally:
                remaining=[t for t in asyncio.all_tasks() if t not in before and not t.done()]
                for task in remaining:task.cancel()
                await asyncio.gather(*remaining,return_exceptions=True)
    async def test_ancestor_output_cannot_write_logs_inside_immutable_root(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root,previous,registry=self.fixture(base)
            # output/source resolves to ROOT itself: descendant-only checks missed this.
            self.registry(root,registry,make_family(root,root.name))
            with patch.object(coordinator,'ROOT',root),patch.object(asyncio,'create_subprocess_exec',side_effect=ValueError('Fixture stops after attempted log creation')),self.assertRaises(ValueError):
                await coordinator.run(previous,SOURCE,base)
            self.assertFalse((root/'tests.log').exists(),'Ancestor output wrote into immutable source')
    async def test_historical_evidence_mutation_during_family_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root,previous,registry=self.fixture(base);job=make_family(root,'family');run=root/'family/run.py';run.write_text(run.read_text()+'\nfrom pathlib import Path\nPath('+repr(str(previous/'SUMMARY.json'))+').write_text("changed historical evidence")\n');job['source_sha256']=coordinator.source_files(root/'family');self.registry(root,registry,job)
            with patch.object(coordinator,'ROOT',root),self.assertRaisesRegex(ValueError,'Immutable baseline evidence or runtime'):
                await coordinator.run(previous,SOURCE,base/'output')
            self.assertFalse((base/'output/SUMMARY.json').exists(),'Mutation still produced a successful joined summary')
    async def test_primary_death_reaps_detached_new_session_descendant(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root,previous,registry=self.fixture(base);pidfile=base/'detached.pid'
            script=textwrap.dedent(f'''\
                import os,pathlib,signal,subprocess,sys
                child=subprocess.Popen([sys.executable,'-c','import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(60)'],start_new_session=True)
                pathlib.Path({str(pidfile)!r}).write_text(str(child.pid))
                os.kill(os.getpid(),signal.SIGKILL)
                ''');self.registry(root,registry,make_family(root,'family',script=script))
            try:
                with patch.object(coordinator,'ROOT',root),self.assertRaises(ValueError):await coordinator.run(previous,SOURCE,base/'output')
                self.assertTrue(pidfile.exists());self.assertFalse(alive(int(pidfile.read_text())),'Detached child survived primary process death')
            finally:
                if pidfile.exists() and alive(int(pidfile.read_text())):os.kill(int(pidfile.read_text()),signal.SIGKILL)
    async def test_cancellation_cleans_detached_children_and_preserves_unrelated_processes(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root,previous,registry=self.fixture(base);pidfile=base/'detached.pid';parentfile=base/'parent.pid'
            script=textwrap.dedent(f'''\
                import os,pathlib,subprocess,sys,time
                child=subprocess.Popen([sys.executable,'-c','import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(60)'],start_new_session=True)
                pathlib.Path({str(pidfile)!r}).write_text(str(child.pid));pathlib.Path({str(parentfile)!r}).write_text(str(os.getpid()))
                time.sleep(60)
                ''');self.registry(root,registry,make_family(root,'family',script=script));unrelated=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True);later=None;task=None
            try:
                with patch.object(coordinator,'ROOT',root):
                    task=asyncio.create_task(coordinator.run(previous,SOURCE,base/'output'));await wait_for_file(pidfile)
                    # This separate process is created during the coordinator run;
                    # a broad root-level subreaper sweep must not kill it either.
                    later=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
                    task.cancel()
                    with self.assertRaises(asyncio.CancelledError):await task
                self.assertFalse(alive(int(pidfile.read_text())));self.assertFalse(alive(int(parentfile.read_text())));self.assertIsNone(unrelated.poll());self.assertIsNone(later.poll())
            finally:
                if task is not None and not task.done():task.cancel();await asyncio.gather(task,return_exceptions=True)
                for proc in [unrelated,later]:
                    if proc is not None:
                        if proc.poll() is None:proc.kill()
                        proc.wait()
                for p in [pidfile,parentfile]:
                    if p.exists() and alive(int(p.read_text())):os.kill(int(p.read_text()),signal.SIGKILL)
    async def test_cancellation_during_async_spawn_does_not_lose_process_handle(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root,previous,registry=self.fixture(base);pidfile=base/'detached.pid';spawned=asyncio.Event();release=asyncio.Event();original=asyncio.create_subprocess_exec
            test=textwrap.dedent(f'''\
                import pathlib,subprocess,sys,time,unittest
                class Test(unittest.TestCase):
                    def test_wait(self):
                        child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
                        pathlib.Path({str(pidfile)!r}).write_text(str(child.pid));time.sleep(60)
                ''');self.registry(root,registry,make_family(root,'family',test=test));children=[];task=None
            async def delayed_return(*args,**kwargs):
                child=await original(*args,**kwargs);children.append(child);spawned.set();await release.wait();return child
            try:
                with patch.object(coordinator,'ROOT',root),patch.object(asyncio,'create_subprocess_exec',delayed_return):
                    task=asyncio.create_task(coordinator.run(previous,SOURCE,base/'output'));await spawned.wait();await wait_for_file(pidfile);task.cancel();release.set()
                    with self.assertRaises(asyncio.CancelledError):await task
                self.assertFalse(alive(int(pidfile.read_text())));self.assertTrue(all(c.returncode is not None for c in children))
            finally:
                release.set()
                if task is not None and not task.done():task.cancel();await asyncio.gather(task,return_exceptions=True)
                for child in children:
                    if child.returncode is None:child.kill()
                    await child.wait()
                if pidfile.exists() and alive(int(pidfile.read_text())):os.kill(int(pidfile.read_text()),signal.SIGKILL)

if __name__=='__main__':unittest.main()
