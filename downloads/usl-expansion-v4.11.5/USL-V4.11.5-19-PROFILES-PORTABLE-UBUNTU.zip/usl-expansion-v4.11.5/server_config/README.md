# Native HTTP configuration profiles

Four additional original catalog IDs now have narrow executable processing contracts: `apacheconf`, `lighttpd`, `vcl`, `vclsnippets`. These are configuration languages; a syntax-highlight lexer alone is insufficient. Actual pinned upstream Apache 2.4.68, lighttpd 1.4.79 and Varnish 7.7.0 processes compile/load the fixture configuration and answer fresh HTTP requests on temporary loopback ports. Independently authored intent fixtures and executable generated USL functions must agree with those native responses.

```bash
source /workspace/.onboarding/activate-usl.sh
cd /workspace/usl-expansion-v4.11.5/server_config
python restore.py
python -m unittest discover -v
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

The source package contains no native binaries. `restore.py` authenticates the included signed Debian trixie InRelease with `sqv` and the Debian archive keyring, authenticates the SHA256 package index, and matches every exact package/version/path/size/hash pin in `PROVIDERS.json`. Only seven packages are extracted under `providers/` (approximately 12 MB), without installation scripts or system configuration changes. This needs Linux x86-64, `sqv`, the Debian public archive keyring, `dpkg-deb`, a compatible C compiler/development headers for VCL compilation, and compatible shared libraries. Existing `LD_LIBRARY_PATH` and optional `USL_COMPAT_LIBDIR` are retained. Every installed provider file is hashed in fresh evidence; actual resolved library and compiler identities are recorded as well. Compatibility on a different OS requires its own native execution evidence.

`frontends.frontend(catalog_id, source)` returns a typed profile IR and generated `.usl` source defining `respond(arg_path)`. Append `let result = respond('/r')` to execute it with the hash-pinned original USL interpreter. There are no Python evaluation hooks, external capabilities or precomputed HTTP result lookups in generated USL. Apache prefix/suffix selection is implemented using USL character loops; VCL predicate and branch structure is preserved in USL expressions and control flow.

## Exact contracts

- `apacheconf`: 1–32 ordered, case-insensitive `Redirect` directives, statuses 301/302/303/307/308 and 410, plus permanent/temp/seeother/gone aliases. Native complete path-segment prefix matching, first-match precedence and suffix concatenation are translated. Destinations are absolute HTTPS URLs under `.invalid` and use restricted literal paths. Gone produces no Location. Request output is `[status, Location-or-empty-string]`; unmatched paths have 404 in the isolated empty-document-root fixture.
- `lighttpd`: `url.redirect-code` (selected 301/302/303/307/308; default 301) and a single 1–32-entry global `url.redirect` map. Keys are fully anchored literal PCRE paths, values are literal `.invalid` HTTPS URLs. Duplicate keys, captures and other regex syntax fail closed. Output is `[status, Location-or-empty-string]`; unmatched paths have 404 in the same explicit fixture context.
- `vcl`: exact VCL 4.1 source form with `backend default none`, `sub vcl_recv` and fixed `sub vcl_synth { return(deliver); }`. Bounded nested if/else and typed `req.url ==/!=` literals with `!`, `&&`, `||` and parentheses; all paths must return `synth(status,reason)`, statuses 200–599 and selected printable ASCII reasons. Native precedence, first return and branching are translated. Statically unreachable source is rejected.
- `vclsnippets`: the same VCL receive statements, executed inside the explicitly recorded VCL 4.1/backend-none/synth-deliver host. This does not claim a snippet is a complete standalone VCL program. Output for both VCL profiles is `[HTTP-status, HTTP-reason]`.

The qualified request domain is **GET of a plain ASCII absolute path with nonempty segments `[A-Za-z0-9_-]`, maximum length 96, and no trailing slash**. Both the pure Python request validator and generated USL reject percent escapes (including `%61`), dot segments, repeated slashes, query strings, fragments, controls and Unicode. HTTP implementations normalize those inputs differently. Fresh excluded-domain probes retain actual results for `/%61`, `/a/../b`, `//a`, `/a?x=1`, `/a#frag`, `/a/`; these observations are separate from the passing profile matrix and confer no translation guarantee for such requests.

No redirects are followed. HTTP Date/Server headers, default HTML response bodies and unrelated headers are outside the declared contract; their raw header fields, body length and SHA256 are retained for audit. Original fixture source, actual wrapper configuration hash, native command/log, source/intent/generated hashes and USL operation counts remain available per case. No real web server configuration, privileged port, system service or external backend is changed. Local native process groups are terminated and reaped even on startup errors; the runner also cleans them on SIGTERM/SIGINT.

## Evidence and limits

The finite matrix contains 36 independent source configurations and 18 request paths each: **648 fresh native HTTP observations and 648 USL function calls in 36 native configurations/interpreter invocations**. Four additional native configurations provide 24 excluded-domain observations. The 19 tests cover signed provenance/tamper rejection, request-domain rejection, native HTTP execution/cleanup, upstream syntax rejection and generated status/target/precedence mutation counterexamples. Test execution itself adds separate native calls and does not replace the fresh matrix.

This is finite conformance and differential evidence, not a universal proof of semantic preservation or original intent. All four full-standard flags remain false. Other directives, regexes, modules, TLS/authentication, real file/backend access, VCL VMODs and caching, general URI/HTTP processing, resource/concurrency guarantees, complete versioned normative obligations and formal preservation remain open. References include successful upstream document/source retrievals with hashes, including replacements for blocked documentation sites; they do not imply the whole standard was audited.
