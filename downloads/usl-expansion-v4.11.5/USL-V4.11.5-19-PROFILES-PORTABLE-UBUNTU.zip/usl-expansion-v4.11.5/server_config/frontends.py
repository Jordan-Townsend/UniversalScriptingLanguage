"""Closed, typed HTTP configuration profiles. Unsupported syntax fails closed."""
import re
class Unsupported(ValueError):pass
PATH=r'/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*'
URL=r'https://[a-z][a-z0-9-]*\.invalid'+PATH
REAS=r'[A-Za-z0-9](?:[A-Za-z0-9 _-]{0,62}[A-Za-z0-9_-])?'
STATUS={"permanent":301,"temp":302,"seeother":303,"gone":410}

def check_path(path):
    if not isinstance(path,str) or len(path)>96 or not re.fullmatch(PATH,path):raise Unsupported('Request is outside the ASCII segment path domain')

def bounded(source):
    if not isinstance(source,str) or len(source)>32768 or '\x00' in source:raise Unsupported('Configuration source boundary')
    if any(ord(c)>126 or ord(c)<32 and c not in '\n\t\r' for c in source):raise Unsupported('ASCII configuration required')
    return '\n'.join(x for x in source.splitlines() if not x.strip().startswith('#')).strip()

def apache(source):
    rows=[]
    for line in bounded(source).splitlines():
        if not line.strip():continue
        m=re.fullmatch(r'\s*(?i:Redirect)\s+(permanent|temp|seeother|gone|301|302|303|307|308|410)\s+('+PATH+r')(?:\s+('+URL+r'))?\s*',line)
        if not m:raise Unsupported('Only selected ordered Redirect directives are supported')
        status,path,url=m.groups();status=STATUS[status] if status in STATUS else int(status)
        if (status==410)!=(url is None):raise Unsupported('Gone takes no destination; redirect requires one')
        if len(path)>48 or url is not None and len(url)>128:raise Unsupported('Path/URL bounds')
        rows.append({'path':path,'status':status,'target':url or ''})
    if not 1<=len(rows)<=32:raise Unsupported('1..32 redirect rules required')
    return {'kind':'apache-prefix','rules':rows,'default':[404,'']}

def lighttpd(source):
    source=bounded(source);m=re.fullmatch(r'(?:url\.redirect-code\s*=\s*(301|302|303|307|308)\s*)?url\.redirect\s*=\s*\((.*)\)\s*',source,re.S)
    if not m:raise Unsupported('Only global literal-anchored redirect map/code is supported')
    code,body=m.groups();code=int(code or '301');rows=[]
    pattern=re.compile(r'\s*"\^('+PATH+r')\$"\s*=>\s*"('+URL+r')"\s*(,|$)')
    while body.strip():
        q=pattern.match(body)
        if not q:raise Unsupported('Map key must be an anchored ASCII literal path, target an absolute .invalid HTTPS URL')
        path,url,comma=q.groups();check_path(path)
        if any(row['path']==path for row in rows):raise Unsupported('Duplicate mapping excluded')
        rows.append({'path':path,'status':code,'target':url});body=body[q.end():]
    if not 1<=len(rows)<=32:raise Unsupported('1..32 exact redirect rules required')
    return {'kind':'lighttpd-exact','rules':rows,'default':[404,'']}

TOKEN=re.compile(r'\s*("[^"\\\n]*"|req\.url|[A-Za-z_][A-Za-z_0-9]*|[0-9]+(?:\.[0-9]+)?|==|!=|&&|\|\||[;(){},!])')
class Parser:
    def __init__(self,text):
        self.t=[];i=0
        while text[i:].strip():
            m=TOKEN.match(text,i)
            if not m:raise Unsupported('Unsupported VCL token at '+str(i))
            self.t.append(m.group(1));i=m.end()
        if len(self.t)>2048:raise Unsupported('VCL token budget')
        self.i=0;self.depth=0
    def pop(self,want=None):
        if self.i>=len(self.t):raise Unsupported('Unexpected end of VCL')
        t=self.t[self.i];self.i+=1
        if want is not None and t!=want:raise Unsupported('Expected '+want+', got '+t)
        return t
    def peek(self):return self.t[self.i] if self.i<len(self.t) else None
    def literal(self,pattern):
        t=self.pop()
        if len(t)<2 or t[0]!='"' or t[-1]!='"' or not re.fullmatch(pattern,t[1:-1]):raise Unsupported('Literal outside exact profile')
        return t[1:-1]
    def condition(self,minprec=0):
        self.depth+=1
        if self.depth>24:raise Unsupported('Predicate depth budget')
        if self.peek()=='!':
            self.pop()
            if self.peek()=='!':raise Unsupported('Adjacent unary negations are not valid VCL BOOL syntax')
            left=['not',self.condition(3)]
        elif self.peek()=='(':
            self.pop();left=self.condition();self.pop(')')
        else:
            self.pop('req.url');op=self.pop()
            if op not in {'==','!='}:raise Unsupported('Only exact path comparisons')
            path=self.literal(PATH);check_path(path);left=[op,path]
        while self.peek() in {'&&','||'} and {'||':1,'&&':2}[self.peek()]>=minprec:
            op=self.pop();left=[op,left,self.condition({'||':1,'&&':2}[op]+1)]
        self.depth-=1;return left
    def statements(self,depth=0):
        if depth>8:raise Unsupported('Statement depth budget')
        out=[]
        while self.peek() not in {None,'}'}:
            if terminal(out):raise Unsupported('Statically unreachable statements excluded')
            if self.peek()=='return':
                self.pop();self.pop('(');self.pop('synth');self.pop('(');n=self.pop()
                if not n.isdecimal() or not 200<=int(n)<=599:raise Unsupported('Synthetic HTTP status200..599 required')
                self.pop(',');reason=self.literal(REAS);self.pop(')');self.pop(')');self.pop(';');out.append(['return',int(n),reason])
            elif self.peek()=='if':
                self.pop();self.pop('(');cond=self.condition();self.pop(')');self.pop('{');yes=self.statements(depth+1);self.pop('}');no=[]
                if self.peek()=='else':self.pop();self.pop('{');no=self.statements(depth+1);self.pop('}')
                out.append(['if',cond,yes,no])
            else:raise Unsupported('Only conditional synth returns')
        return out

def terminal(nodes):
    if not nodes:return False
    return any(n[0]=='return' or n[0]=='if' and terminal(n[2]) and terminal(n[3]) for n in nodes)

def vcl(source,snippet=False):
    p=Parser(bounded(source))
    if not snippet:
        for t in ['vcl','4.1',';','backend','default','none',';','sub','vcl_recv','{']:p.pop(t)
    nodes=p.statements()
    if not snippet:
        for t in ['}','sub','vcl_synth','{','return','(','deliver',')',';','}']:p.pop(t)
    if p.peek() is not None or not terminal(nodes):raise Unsupported('Complete bounded source with all paths returning synth required')
    return {'kind':'vcl-synth','statements':nodes,'source_form':'snippet' if snippet else 'vcl4.1'}

def predicate(node):
    if node[0] in {'==','!='}:return '(arg_path '+node[0]+' '+repr(node[1])+')'
    if node[0]=='not':return '(not '+predicate(node[1])+')'
    return '('+predicate(node[1])+(' and ' if node[0]=='&&' else ' or ')+predicate(node[2])+')'

def emit(ir):
    lines=['function respond(arg_path):','    assert arg_path == str(arg_path)',"    assert len(arg_path) <= 96 and len(arg_path) > 1 and arg_path[0] == '/' and arg_path[len(arg_path)-1] != '/' and '//' not in arg_path",'    for char in arg_path:',"        assert char in '/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-'",'']
    if ir['kind']=='vcl-synth':
        def block(nodes,indent):
            for n in nodes:
                if n[0]=='return':lines.append(indent+'return '+repr(n[1:]))
                else:
                    lines.append(indent+'if '+predicate(n[1])+':');block(n[2],indent+'    ')
                    if not n[2]:lines.append(indent+'    pass')
                    if n[3]:lines.append(indent+'else:');block(n[3],indent+'    ')
        block(ir['statements'],'    ')
    else:
        for row in ir['rules']:
            path=row['path']
            if ir['kind']=='apache-prefix':
                lines.extend(['    prefix = ""','    for index in range(min(len(arg_path), '+str(len(path))+')):','        prefix = prefix + arg_path[index]',f'    if prefix == {path!r} and (len(arg_path) == {len(path)} or arg_path[{len(path)}] == "/"):',f'        tail = ""',f'        for index in range({len(path)}, len(arg_path)):', '            tail = tail + arg_path[index]',f'        return [{row["status"]}, '+(repr(row['target'])+' + tail' if row['status']!=410 else '""')+']'])
            else:lines.extend([f'    if arg_path == {path!r}:',f'        return [{row["status"]}, {row["target"]!r}]'])
        lines.append('    return '+repr(ir['default']))
    return '\n'.join(lines)+'\n'

def frontend(identifier,source):
    if identifier=='apacheconf':ir=apache(source)
    elif identifier=='lighttpd':ir=lighttpd(source)
    elif identifier in {'vcl','vclsnippets'}:ir=vcl(source,identifier=='vclsnippets')
    else:raise Unsupported('Unknown catalog ID')
    return ir,emit(ir)
