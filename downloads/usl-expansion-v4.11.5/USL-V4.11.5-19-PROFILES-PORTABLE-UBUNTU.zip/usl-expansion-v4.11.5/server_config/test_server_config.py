import copy, hashlib, json, os, sys, tempfile, unittest
from pathlib import Path
from frontends import frontend,Unsupported,check_path
from cases import fixtures,UNSUPPORTED
from native import process,ACTIVE
from restore import authenticate,check_bytes,release_item,ROOT
sys.path.insert(0,os.environ.get('USL_SOURCE_ROOT','/workspace/usl-v4.10.0-clean-test'))
from usl_systems.language import Interpreter

class FrontendTests(unittest.TestCase):
    def test_independent_intent_matrix(self):
        for c in fixtures():
            with self.subTest(id=c['catalog_id'],name=c['name']):
                _,g=frontend(c['catalog_id'],c['source']);r=Interpreter(max_ops=2_000_000).run(g+'let result = ['+', '.join('respond('+repr(p)+')' for p in c['paths'])+']\n')
                self.assertEqual(c['expected'],r.variables['result'])
    def test_all_explicit_unsupported_constructs(self):
        for id,examples in UNSUPPORTED.items():
            for source in examples:
                with self.subTest(id=id,source=source),self.assertRaises(Unsupported):frontend(id,source)
    def test_request_boundary_python_and_generated_agree(self):
        _,g=frontend('apacheconf','Redirect temp /r https://target.invalid/to')
        for path in [None,123,['/','r'],{'path':'/r'},True,'/','/r/','/r//x','r','/r?x=1','/r%2Fx','/%61','/a/../b','//a','/a#frag','/r/..','/r\nX: y','/é','/'+('x'*96)]:
            with self.subTest(path=path):
                with self.assertRaises(Unsupported):check_path(path)
                with self.assertRaises(Exception):Interpreter().run(g+'let result = respond('+repr(path)+')\n')
    def test_prefix_segment_boundary_and_order(self):
        _,g=frontend('apacheconf','Redirect 302 /r https://target.invalid/first\nRedirect 301 /r/x https://target.invalid/second')
        result=Interpreter().run(g+'let result=[respond("/r/x"), respond("/rx")]').variables['result']
        self.assertEqual(result,[[302,'https://target.invalid/first/x'],[404,'']])
    def test_operator_precedence_counterexample(self):
        s='if(req.url == "/r" || req.url == "/m" && req.url != "/r") { return(synth(200,"Yes")); } return(synth(404,"No"));'
        _,g=frontend('vclsnippets',s)
        self.assertEqual(Interpreter().run(g+'let result=respond("/r")').variables['result'],[200,'Yes'])
        # A left-associative instead of precedence-correct emitter fails intent.
        broken=g.replace("((arg_path == '/r') or ((arg_path == '/m') and (arg_path != '/r')))","(((arg_path == '/r') or (arg_path == '/m')) and (arg_path != '/r'))")
        self.assertNotEqual(broken,g)
        self.assertNotEqual(Interpreter().run(broken+'let result=respond("/r")').variables['result'],[200,'Yes'])
    def test_status_mutation_is_detected(self):
        c=next(c for c in fixtures() if c['catalog_id']=='vclsnippets' and c['name']=='constant');_,g=frontend(c['catalog_id'],c['source'])
        wrong=g.replace("return [201, 'Made']","return [500, 'Made']")
        self.assertNotEqual(Interpreter().run(wrong+'let result=respond("/r")').variables['result'],c['expected'][0])
    def test_location_mutation_is_detected(self):
        _,g=frontend('lighttpd','url.redirect=("^/r$"=>"https://target.invalid/to")')
        self.assertNotEqual(Interpreter().run(g.replace('target.invalid','wrong.invalid')+'let result=respond("/r")').variables['result'],[301,'https://target.invalid/to'])
    def test_unreachable_and_unterminated_control_flow_rejected(self):
        for s in ['return(synth(200,"Yes")); return(synth(500,"No"));','if(req.url=="/r"){return(synth(200,"Yes"));}','if(req.url=="/r"){return(synth(200,"Yes"));} else {return(synth(404,"No"));} return(synth(500,"Dead"));']:
            with self.assertRaises(Unsupported):frontend('vclsnippets',s)
    def test_depth_and_size_limits(self):
        with self.assertRaises(Unsupported):frontend('vclsnippets','if('+('!'*30)+'(req.url == "/r")){return(synth(200,"Yes"));}return(synth(404,"No"));')
        with self.assertRaises(Unsupported):frontend('apacheconf',' '*32769)
    def test_named_alias_matches_numeric_IR(self):
        for word,code in [('permanent',301),('temp',302),('seeother',303)]:self.assertEqual(frontend('apacheconf',f'Redirect {word} /r https://target.invalid/to')[0],frontend('apacheconf',f'Redirect {code} /r https://target.invalid/to')[0])

class ProvenanceTests(unittest.TestCase):
    def test_real_signed_release_and_exact_packages(self):self.assertEqual(len(authenticate()['packages']),7)
    def test_package_corruption_rejected(self):
        with self.assertRaises(ValueError):check_bytes(b'changed','0'*64,7,'package')
    def test_signed_release_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            for name in ['PROVIDERS.json','DEBIAN_RELEASE.txt','DEBIAN_INRELEASE.asc']:(d/name).write_bytes((ROOT/name).read_bytes())
            (d/'DEBIAN_INRELEASE.asc').write_bytes((d/'DEBIAN_INRELEASE.asc').read_bytes()+b'changed')
            with self.assertRaises(ValueError):authenticate(d)
    def test_same_hash_tampering_cannot_skip_crypto(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            for name in ['PROVIDERS.json','DEBIAN_RELEASE.txt','DEBIAN_INRELEASE.asc']:(d/name).write_bytes((ROOT/name).read_bytes())
            signed=(d/'DEBIAN_INRELEASE.asc').read_bytes().replace(b'Origin: Debian',b'Origin: Bogus!',1)
            (d/'DEBIAN_INRELEASE.asc').write_bytes(signed);m=json.loads((d/'PROVIDERS.json').read_text());m['signed_release_sha256']=hashlib.sha256(signed).hexdigest();(d/'PROVIDERS.json').write_text(json.dumps(m))
            with self.assertRaises(Exception):authenticate(d)
    def test_release_sha256_only(self):
        with self.assertRaises(ValueError):release_item('SHA256:\n '+('f'*64)+' 1 unrelated\n','wanted')

class NativeTests(unittest.TestCase):
    def test_apache_real_http_and_cleanup(self):
        r=process('apacheconf','Redirect 307 /r https://target.invalid/to',['/r/x','/rx']);self.assertEqual([x['observed'] for x in r['observations']],[[307,'https://target.invalid/to/x'],[404,'']]);self.assertFalse(ACTIVE)
    def test_lighttpd_real_http_and_cleanup(self):
        r=process('lighttpd','url.redirect-code=308\nurl.redirect=("^/r$"=>"https://target.invalid/to")',['/r','/r/x']);self.assertEqual([x['observed'] for x in r['observations']],[[308,'https://target.invalid/to'],[404,'']]);self.assertFalse(ACTIVE)
    def test_vcl_real_http_and_cleanup(self):
        r=process('vclsnippets','if(req.url=="/r"){return(synth(202,"Chosen"));}return(synth(404,"Missing"));',['/r','/m']);self.assertEqual([x['observed'] for x in r['observations']],[[202,'Chosen'],[404,'Missing']]);self.assertFalse(ACTIVE)
    def test_native_syntax_rejection_and_cleanup(self):
        for id,s in [('apacheconf','NotARealDirective yes'),('lighttpd','server.port = "not-an-integer"'),('vclsnippets','return(synth("bad","Reason"));')]:
            with self.subTest(id=id),self.assertRaises(RuntimeError):process(id,s,['/r'])
            self.assertFalse(ACTIVE)
if __name__=='__main__':unittest.main()
