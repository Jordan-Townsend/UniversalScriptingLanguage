"""Isolated loopback native HTTP carriers, with process-group cleanup."""
import contextlib, hashlib, http.client, json, os, signal, socket, subprocess, tempfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREFIX=ROOT/'providers'
ACTIVE=set()
def stop_all():
    for pid in tuple(ACTIVE):
        with contextlib.suppress(ProcessLookupError):os.killpg(pid,signal.SIGKILL)

def environment():
    env=os.environ.copy();env['LC_ALL']='C'
    env['LD_LIBRARY_PATH']=os.pathsep.join(filter(None,[str(PREFIX/'usr/lib/x86_64-linux-gnu'),env.get('USL_COMPAT_LIBDIR'),env.get('LD_LIBRARY_PATH')]))
    return env

def process(identifier,source,paths):
    with tempfile.TemporaryDirectory(prefix='usl-http-') as temp:
        d=Path(temp);(d/'www').mkdir();(d/'www/index.html').write_text('fixture')
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        if identifier=='apacheconf':
            modules=PREFIX/'usr/lib/apache2/modules'
            conf=f'ServerRoot "{d}"\nPidFile "{d}/pid"\nListen 127.0.0.1:{port}\nServerName fixture.invalid\nErrorLog "{d}/error.log"\nDocumentRoot "{d}/www"\n'
            conf+=''.join(f'LoadModule {name}_module "{modules}/mod_{name}.so"\n' for name in ['mpm_event','authz_core','alias'])
            conf+='StartServers 1\nServerLimit 1\nThreadsPerChild 2\nMinSpareThreads 1\nMaxSpareThreads 2\nMaxRequestWorkers 2\n'
            conf+='<Directory "'+str(d/'www')+'">\nRequire all granted\n</Directory>\n'+source
            command=[str(PREFIX/'usr/sbin/apache2'),'-X','-f',str(d/'config')]
        elif identifier=='lighttpd':
            conf=f'server.document-root = "{d}/www"\nserver.bind = "127.0.0.1"\nserver.port = {port}\nserver.errorlog = "{d}/error.log"\nserver.pid-file = "{d}/pid"\nserver.modules = ( "mod_redirect" )\n'+source
            command=[str(PREFIX/'usr/sbin/lighttpd'),'-D','-m',str(PREFIX/'usr/lib/lighttpd'),'-f',str(d/'config')]
        else:
            conf=source if identifier=='vcl' else 'vcl 4.1;\nbackend default none;\nsub vcl_recv {\n'+source+'\n}\nsub vcl_synth { return(deliver); }\n'
            command=[str(PREFIX/'usr/sbin/varnishd'),'-F','-n',str(d/'instance'),'-f',str(d/'config'),'-a',f'127.0.0.1:{port}','-s','malloc,8m','-p','vsl_space=1M','-p','thread_pool_min=5','-p','thread_pool_max=10','-p','vcc_feature=+err_unref','-p','vcl_path='+str(PREFIX/'usr/share/varnish/vcl'),'-p','vmod_path='+str(PREFIX/'usr/lib/x86_64-linux-gnu/varnish/vmods')]
        (d/'config').write_text(conf)
        with (d/'process.log').open('wb') as log:
            p=subprocess.Popen(command,cwd=d,env=environment(),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            ACTIVE.add(p.pid)
            responses=[];started=time.monotonic()
            try:
                deadline=started+15
                while True:
                    if p.poll() is not None:raise RuntimeError('Native startup failed: '+(d/'process.log').read_text(errors='replace')+'\n'+((d/'error.log').read_text(errors='replace') if (d/'error.log').exists() else ''))
                    try:
                        with socket.create_connection(('127.0.0.1',port),timeout=.1):break
                    except OSError:
                        if time.monotonic()>deadline:raise TimeoutError('Native readiness timeout')
                        time.sleep(.02)
                for path in paths:
                    conn=http.client.HTTPConnection('127.0.0.1',port,timeout=5)
                    try:
                        conn.request('GET',path,headers={'Host':'fixture.invalid','Connection':'close'})
                        r=conn.getresponse();body=r.read()
                        selected=[r.status,r.reason] if identifier in {'vcl','vclsnippets'} else [r.status,r.getheader('Location') or '']
                        responses.append({'path':path,'observed':selected,'all_headers':r.getheaders(),'body_sha256':hashlib.sha256(body).hexdigest(),'body_bytes':len(body)})
                    finally:conn.close()
            finally:
                with contextlib.suppress(ProcessLookupError):os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    with contextlib.suppress(ProcessLookupError):os.killpg(p.pid,signal.SIGKILL)
                    p.wait(timeout=3)
                ACTIVE.discard(p.pid)
            return {'observations':responses,'command':command,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'native_configuration_sha256':hashlib.sha256(conf.encode()).hexdigest(),'native_process_invocations':1,'native_http_observations':len(responses),'elapsed_seconds':time.monotonic()-started,'native_process_log':(d/'process.log').read_text(errors='replace'),'fixture_scope':'temporary files and loopback only; HTTP redirects never followed; process group terminated/reaped'}
