"""Intent fixtures authored independently of frontend IR and lowering."""
PATHS=['/r','/r/x','/r/x/y','/rx','/R','/r_x','/r-1','/m','/m/r','/missing','/a/b','/a','/b','/c','/d','/none','/r2','/z']
def fixtures():
    out=[]
    def add(id,name,source,expected):out.append({'catalog_id':id,'name':name,'source':source,'paths':PATHS,'expected':expected})
    for status in [301,302,303,307,308]:
        exp=[[status,'https://target.invalid/to'+p[2:]] if p in {'/r','/r/x','/r/x/y'} else [404,''] for p in PATHS]
        add('apacheconf','status-'+str(status),f'Redirect {status} /r https://target.invalid/to\n',exp)
    for alias,status in [('permanent',301),('temp',302),('seeother',303)]:
        exp=[[status,'https://target.invalid/to'+p[2:]] if p in {'/r','/r/x','/r/x/y'} else [404,''] for p in PATHS]
        add('apacheconf','alias-'+alias,f'# native aliases\nredirect {alias} /r https://target.invalid/to\n',exp)
    for gone in ['gone','410']:
        add('apacheconf','gone-'+gone,'Redirect '+gone+' /r\n',[[410,''] if p in {'/r','/r/x','/r/x/y'} else [404,''] for p in PATHS])
    add('apacheconf','ordered-first-prefix','Redirect 302 /r https://first.invalid/f\nRedirect 301 /r/x https://second.invalid/s\n',[[302,'https://first.invalid/f'+p[2:]] if p in {'/r','/r/x','/r/x/y'} else [404,''] for p in PATHS])
    add('apacheconf','ordered-specific-first','Redirect 301 /r/x https://second.invalid/s\nRedirect 302 /r https://first.invalid/f\n',[[301,'https://second.invalid/s'+p[4:]] if p in {'/r/x','/r/x/y'} else ([302,'https://first.invalid/f'] if p=='/r' else [404,'']) for p in PATHS])
    for code in [301,302,303,307,308]:
        add('lighttpd','code-'+str(code),f'url.redirect-code = {code}\nurl.redirect = ("^/r$" => "https://target.invalid/to", "^/m$" => "https://other.invalid/there")\n',[[code,'https://target.invalid/to'] if p=='/r' else ([code,'https://other.invalid/there'] if p=='/m' else [404,'']) for p in PATHS])
    add('lighttpd','default-code','url.redirect = ("^/r$" => "https://target.invalid/to",)\n',[[301,'https://target.invalid/to'] if p=='/r' else [404,''] for p in PATHS])
    programs=[
      ('constant','return(synth(201,"Made"));',lambda p:[201,'Made']),
      ('equal','if (req.url == "/r") { return(synth(202,"Chosen")); } return(synth(404,"Absent"));',lambda p:[202,'Chosen'] if p=='/r' else [404,'Absent']),
      ('not-equal','if (req.url != "/r") { return(synth(403,"Denied")); } return(synth(200,"Allowed"));',lambda p:[200,'Allowed'] if p=='/r' else [403,'Denied']),
      ('not','if (!(req.url == "/r")) { return(synth(410,"Gone")); } else { return(synth(200,"Here")); }',lambda p:[200,'Here'] if p=='/r' else [410,'Gone']),
      ('or','if (req.url == "/r" || req.url == "/m") { return(synth(203,"Either route")); } return(synth(404,"Missing"));',lambda p:[203,'Either route'] if p in {'/r','/m'} else [404,'Missing']),
      ('and','if (req.url != "/r" && req.url != "/m") { return(synth(418,"Teapot")); } return(synth(204,"Empty"));',lambda p:[204,'Empty'] if p in {'/r','/m'} else [418,'Teapot']),
      ('precedence','if (req.url == "/r" || req.url == "/m" && req.url != "/m") { return(synth(205,"Left only")); } return(synth(404,"Missing"));',lambda p:[205,'Left only'] if p=='/r' else [404,'Missing']),
      ('grouping','if ((req.url == "/r" || req.url == "/m") && req.url != "/m") { return(synth(206,"Group route")); } return(synth(500,"Other"));',lambda p:[206,'Group route'] if p=='/r' else [500,'Other']),
      ('nested','if (req.url != "/m") { if (req.url == "/r") { return(synth(200,"Inner")); } } else { return(synth(503,"Unavailable")); } return(synth(404,"Outer fallback"));',lambda p:[200,'Inner'] if p=='/r' else ([503,'Unavailable'] if p=='/m' else [404,'Outer fallback'])),
      ('unreachable','return(synth(200,"First")); return(synth(500,"Unreachable"));',lambda p:[200,'First'])
    ]
    # VCL native compiler rejects statically unreachable statements, deliberately
    # leave that construct in unsupported cases rather than profile fixtures.
    programs=programs[:-1]
    for name,body,expect in programs:
        add('vclsnippets',name,body,[expect(p) for p in PATHS])
        add('vcl',name,'vcl 4.1;\nbackend default none;\nsub vcl_recv {\n'+body+'\n}\nsub vcl_synth { return(deliver); }\n',[expect(p) for p in PATHS])
    return out

UNSUPPORTED={
'apacheconf':['Include /etc/apache2/*','Redirect 302 /r https://target.invalid/to\nSetEnv SECRET 1','Redirect 302 /r https://target.invalid/to?x=1','Redirect gone /r https://target.invalid/to','Redirect 301 /r','RedirectMatch 301 ^/r https://target.invalid/to'],
'lighttpd':['include "secret"','url.redirect = ("/r" => "https://target.invalid/to")','url.redirect = ("^/r.*$" => "https://target.invalid/to")','url.redirect = ("^/r$"=>"https://target.invalid/to", "^/r$"=>"https://target.invalid/other")','url.redirect-code = 999\nurl.redirect = ("^/r$"=>"https://target.invalid/to")'],
'vclsnippets':['if(!!req.url == "/r"){return(synth(200,"Double"));}return(synth(404,"Missing"));','if(! !(req.url == "/r")){return(synth(200,"Double"));}return(synth(404,"Missing"));','set req.http.X = "a"; return(synth(200,"OK"));','return(synth(100,"Continue"));','return(synth(200,"Trailing "));','if(req.url == "/r") { return(synth(200,"OK")); }','return(synth(200,"OK")); import std;','if(req.url ~ "/r") { return(synth(200,"OK")); } return(synth(404,"Missing"));'],
'vcl':['vcl 4.0; backend default none; sub vcl_recv { return(synth(200,"OK")); }','vcl 4.1; backend default { .host="127.0.0.1"; } sub vcl_recv { return(pass); }']
}
