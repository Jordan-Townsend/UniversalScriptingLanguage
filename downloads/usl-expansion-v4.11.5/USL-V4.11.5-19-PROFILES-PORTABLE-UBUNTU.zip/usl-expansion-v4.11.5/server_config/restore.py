"""Recreate local providers from exact, authenticated Debian package pins.

Frozen source and provenance files are read-only. Only the provider directory is
created; every invocation verifies the signed release, package index, and debs.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parent
APT_LISTS = Path('/workspace/.onboarding/apt/lists')
INDEX_NAME = 'deb.debian.org_debian_dists_trixie_main_binary-amd64_Packages'
KEYRING = Path('/usr/share/keyrings/debian-archive-keyring.pgp')
FIELDS = ('Package', 'Version', 'Filename', 'Size', 'SHA256')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fetch(url):
    with urllib.request.urlopen(url, timeout=60) as response:
        return response.read()


def release_item(release, path):
    # Restrict lookup to the SHA256 section; never accept an MD5/SHA1 entry.
    parts = release.split('\nSHA256:\n', 1)
    if len(parts) != 2:raise ValueError('Missing authenticated SHA256 section')
    section = parts[1]
    for line in section.splitlines():
        if not line.startswith(' '):
            break
        parts = line.split()
        if len(parts) == 3 and parts[2] == path and re.fullmatch('[a-f0-9]{64}', parts[0]):
            return parts[0], int(parts[1])
    raise ValueError('Missing authenticated SHA256 entry: ' + path)


def check_bytes(body, checksum, size, description):
    if sha(body) != checksum or len(body) != int(size):
        raise ValueError(description + ' integrity failure')


def authenticate(root=ROOT, index=None, keyring=KEYRING):
    root = Path(root)
    manifest = json.loads((root / 'PROVIDERS.json').read_text())
    signed = root / 'DEBIAN_INRELEASE.asc'
    if sha(signed.read_bytes()) != manifest['signed_release_sha256']:
        raise ValueError('Pinned signed Debian release integrity failure')
    with tempfile.TemporaryDirectory(prefix='usl-debian-auth-') as temporary:
        authenticated = Path(temporary) / 'release'
        # This is deliberately unconditional, including when frozen cleartext exists.
        subprocess.run(['sqv', '--keyring', str(keyring), '--cleartext',
                        '--output', str(authenticated), str(signed)],
                       check=True, capture_output=True)
        release_bytes = authenticated.read_bytes()
    if sha(release_bytes) != manifest['release_sha256']:
        raise ValueError('Pinned authenticated Debian release mismatch')
    if (root / 'DEBIAN_RELEASE.txt').read_bytes() != release_bytes:
        raise ValueError('Frozen Debian release provenance mismatch')
    release = release_bytes.decode()
    expected, size = release_item(release, 'main/binary-amd64/Packages')
    if expected != manifest['index_sha256']:
        raise ValueError('Frozen provider index pin mismatch')
    index = Path(index) if index is not None else APT_LISTS / INDEX_NAME
    if index.exists():
        index_bytes = index.read_bytes()
    else:
        compressed_hash, compressed_size = release_item(release, 'main/binary-amd64/Packages.xz')
        compressed = fetch('https://deb.debian.org/debian/dists/trixie/main/binary-amd64/by-hash/SHA256/' + compressed_hash)
        check_bytes(compressed, compressed_hash, compressed_size, 'Compressed Debian index')
        index_bytes = lzma.decompress(compressed)
    check_bytes(index_bytes, expected, size, 'Authenticated Debian package index')
    wanted = {row['Package']: row for row in manifest['packages']}
    if len(wanted) != 7 or set(wanted) != {'apache2-bin','libapr1t64','libaprutil1t64','lighttpd','varnish','libvarnishapi3','libjemalloc2'}:
        raise ValueError('Unexpected pinned provider set')
    found = {}
    for block in index_bytes.decode().split('\n\n'):
        data = {}
        for line in block.splitlines():
            if ': ' in line and not line.startswith(' '):
                key, value = line.split(': ', 1)
                data[key] = value
        name = data.get('Package')
        if name in wanted:
            row = {key: data[key] for key in FIELDS}
            if row != wanted[name] or name in found:
                raise ValueError('Exact Debian provider pin mismatch: ' + name)
            found[name] = row
    if set(found) != set(wanted):
        raise ValueError('Missing pinned Debian provider')
    return manifest


def restore(root=ROOT, index=None, keyring=KEYRING):
    root = Path(root)
    manifest = authenticate(root, index, keyring)
    prefix = root / 'providers'
    prefix.mkdir(exist_ok=True)
    def install(row):
        # Temporary package bodies are not bundled and cannot survive an error.
        body = fetch('https://deb.debian.org/debian/' + row['Filename'])
        check_bytes(body, row['SHA256'], row['Size'], 'Debian provider ' + row['Package'])
        with tempfile.TemporaryDirectory(prefix='usl-debian-provider-') as temporary:
            package = Path(temporary) / 'provider.deb'
            package.write_bytes(body)
            subprocess.run(['dpkg-deb', '-x', str(package), str(prefix)],
                           check=True, capture_output=True)
        return row['Package']
    with ThreadPoolExecutor(max_workers=len(manifest['packages'])) as pool:
        installed = list(pool.map(install, manifest['packages']))
    return {'schema': 'usl.server-config.restore.v1', 'installed': installed,
            'signature_verified': True, 'index_verified': True,
            'all_package_hashes_verified': True, 'frozen_provenance_unchanged': True,
            'index_sha256': manifest['index_sha256']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--index', type=Path, help='optional authenticated-index cache path')
    parser.add_argument('--keyring', type=Path, default=KEYRING)
    args = parser.parse_args()
    print(json.dumps(restore(index=args.index, keyring=args.keyring)))


if __name__ == '__main__':
    main()
