"""Fresh native/USL/independent-intent validation; never replay HTTP evidence."""
import argparse, asyncio, hashlib, json, os, re, shutil, signal, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from frontends import frontend,Unsupported,check_path
from cases import fixtures,UNSUPPORTED
from native import process,stop_all,PREFIX,environment
ROOT=Path(__file__).resolve().parent
IDS=['apacheconf','lighttpd','vcl','vclsnippets']
PROFILES={
'apacheconf':'Apache2.4.68 isolated HTTP GET ordered Redirect aliases/status301/302/303/307/308/410 and complete-segment prefix/suffix semantics, ASCII paths; observed status and Location only',
'lighttpd':'lighttpd1.4.79 global url.redirect/code selected301/302/303/307/308 and literal anchored PCRE path map; isolated HTTP GET status/Location only',
'vcl':'Varnish7.7 VCL4.1 backend none, complete recv/synth source; bounded exact-path ==/!= Boolean predicates, nested if/else and complete synth returns200..599; actual HTTP status/reason only',
'vclsnippets':'Varnish7.7 VCL recv statement snippets in explicit fixed VCL4.1/backend-none/synth-deliver host; bounded exact-path predicates/nestedif/complete synth returns200..599; actual HTTP status/reason only'}
RUNTIME_SHA='28572d10c70421c71777a4562bbdd075acf6077d5ea4c3b9ebca3278e6dc76cc'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def admission(n):
    available=128<<20
    try:
        maximum=Path('/sys/fs/cgroup/memory.max').read_text().strip();used=int(Path('/sys/fs/cgroup/memory.current').read_text())
        if maximum!='max':available=max(0,int(maximum)-used)
        else:available=int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])*1024
    except (OSError,ValueError,StopIteration):pass
    return {'logical_case_actors':len(fixtures()),'physical_native_slots':max(1,min(n,available//(128<<20))),'reservation_estimate_bytes':128<<20,'observed_available_bytes':available,'fixed_worker_cap':None,'shared_native_work':'sequential configurations per compatible native-host family, fresh HTTP for every request'}
async def validate(source_root,output):
    source_root=Path(source_root).resolve();runtime=source_root/'usl_systems/language.py'
    if sha(runtime)!=RUNTIME_SHA:raise ValueError('USL runtime identity mismatch')
    sys.path.insert(0,str(source_root));from usl_systems.language import Interpreter
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True);(output/'generated').mkdir(exist_ok=True)
    cases=fixtures();gate=asyncio.Event();started=[];policy=admission(len(IDS));pool=ThreadPoolExecutor(max_workers=policy['physical_native_slots']);loop=asyncio.get_running_loop()
    # Each native configuration is fresh; multiplex compatible language families.
    def family(id):
        observed={}
        for row in cases:
            if row['catalog_id']==id:
                frontend(id,row['source']) # fail closed before native carrier side effects
                observed[row['name']]=process(id,row['source'],row['paths'])
        return observed
    async def job(id):await gate.wait();return await loop.run_in_executor(pool,family,id)
    jobs={id:asyncio.create_task(job(id)) for id in IDS}
    async def actor(case):
        started.append(case['catalog_id']+'/'+case['name']);await gate.wait();id=case['catalog_id']
        ir,generated=frontend(id,case['source']);generated+='let result = ['+', '.join('respond('+repr(p)+')' for p in case['paths'])+']\n'
        result=Interpreter(max_ops=2_000_000,timeout=5).run(generated)
        native=(await jobs[id])[case['name']];actual=[r['observed'] for r in native['observations']]
        if result.variables['result']!=case['expected'] or actual!=case['expected']:raise ValueError('Native/intent/USL counterexample '+id+'/'+case['name']+': '+repr((case['expected'],actual,result.variables['result'])))
        filename=id+'--'+case['name']+'.usl';(output/'generated'/filename).write_text(generated)
        return dict(case,passed=True,IR=ir,source_sha256=hashlib.sha256(case['source'].encode()).hexdigest(),intent_sha256=digest(case['expected']),generated_source=filename,generated_sha256=hashlib.sha256(generated.encode()).hexdigest(),USL_operations=result.operations,USL_observed=result.variables['result'],USL_interpreter_invocations=1,native=native)
    tasks=[asyncio.create_task(actor(c)) for c in cases];await asyncio.sleep(0)
    if len(started)!=len(cases):raise AssertionError('All logical actors must start before release')
    policy['all_actors_started_before_release']=True;start=time.monotonic();gate.set()
    try:rows=await asyncio.gather(*tasks)
    finally:
        stop_all();pool.shutdown(wait=True,cancel_futures=True)
    rejects=[]
    for id,examples in UNSUPPORTED.items():
        for source in examples:
            try:frontend(id,source)
            except Unsupported as e:rejects.append({'catalog_id':id,'source':source,'rejected':True,'reason':str(e),'native_executed':False})
            else:raise AssertionError('Unsupported source was accepted')
    excluded_paths=['/%61','/a/../b','//a','/a?x=1','/a#frag','/a/']
    for path in excluded_paths:
        try:check_path(path)
        except Unsupported:pass
        else:raise AssertionError('Normalization-sensitive path escaped request boundary')
    probe_sources={'apacheconf':'Redirect 301 /a https://target.invalid/to\nRedirect 302 /b https://other.invalid/there','lighttpd':'url.redirect=("^/a$"=>"https://target.invalid/to","^/b$"=>"https://other.invalid/there")','vclsnippets':'if(req.url=="/a"){return(synth(200,"Route a"));}return(synth(404,"Other"));'}
    probe_sources['vcl']='vcl 4.1;backend default none;sub vcl_recv{'+probe_sources['vclsnippets']+'}sub vcl_synth{return(deliver);}'
    excluded_probes=[dict(catalog_id=id,translator_rejects_all=True,native=process(id,probe_sources[id],excluded_paths),within_qualified_domain=False) for id in IDS]
    tools=[PREFIX/'usr/sbin'/x for x in ['apache2','lighttpd','varnishd']]
    import subprocess
    versions={}
    for p in tools:
        v=subprocess.run([str(p),'-V' if p.name=='varnishd' else '-v'],capture_output=True,env=environment(),check=True)
        versions[p.name]=(v.stdout+v.stderr).decode()
    dependencies={}
    modules=[PREFIX/'usr/lib/apache2/modules'/('mod_'+x+'.so') for x in ['mpm_event','authz_core','alias']]
    for tool in tools+modules:
        found=subprocess.run(['ldd',str(tool)],env=environment(),check=True,capture_output=True).stdout.decode()
        if 'not found' in found:raise ValueError('Missing native dependency: '+found)
        dependencies[str(tool)]={'ldd_stdout':found,'resolved_library_hashes':{m:sha(m) for m in re.findall(r'(?:=> )?(/[^ ]+) \(0x',found)}}
    cc=Path(shutil.which('cc') or '/usr/bin/cc').resolve()
    dependencies['VCL_native_compiler']={'path':str(cc),'sha256':sha(cc),'version':subprocess.run([str(cc),'--version'],check=True,capture_output=True,env=environment()).stdout.decode()}
    source_hashes={p.name:sha(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.py','.json','.md','.asc','.txt'} and p.name not in {'RESTORE_TEST.json','SOURCE_SHA256.json'}}
    native_hashes={str(p.relative_to(PREFIX)):sha(p) for p in PREFIX.rglob('*') if p.is_file() and not p.is_symlink()}
    records=[]
    for id in IDS:
        selected=[r for r in rows if r['catalog_id']==id]
        records.append({'catalog_id':id,'category':'category_processing','scoped_profile_validated':True,'full_standard_qualified':False,'exact_profile':PROFILES[id],'cases':sum(len(r['paths']) for r in selected),'native_executions':sum(len(r['paths']) for r in selected),'native_unit':'fresh loopback HTTP response observations; process invocations recorded separately','native_process_invocations':len(selected),'usl_executions':len(selected),'usl_function_calls':sum(len(r['paths']) for r in selected),'unsupported_rejections':sum(x['catalog_id']==id for x in rejects),'open_obligations':['Complete authoritative version/specification and normative obligations audit','Every directive, grammar, type/effect and runtime feature beyond this exact profile','Full source-to-USL preservation proof and independent review','All libraries, module interactions, deployment/TLS/security/platform obligations','General requests, headers, bodies, encoded paths, queries, methods, caching/backend networking and concurrency semantics'],'case_records':selected})
    result={'schema':'usl.server-config.native-profiles.v1','records':records,'source_hashes':source_hashes,'native_provider_file_hashes':native_hashes,'native_versions':versions,'resolved_native_dependencies':dependencies,'excluded_domain_native_probes':excluded_probes,'excluded_domain_native_processes':len(excluded_probes),'excluded_domain_http_observations':sum(len(p['native']['observations']) for p in excluded_probes),'runtime_sha256':sha(runtime),'native_process_invocations':sum(r['native_process_invocations'] for r in records),'native_http_observations':sum(r['native_executions'] for r in records),'usl_interpreter_invocations':len(rows),'usl_function_calls':sum(r['usl_function_calls'] for r in records),'unsupported_source_records':rejects,'resource_admission':policy,'elapsed_seconds':time.monotonic()-start,'formal_semantic_preservation_proved':False,'intent_claim':'Independent finite fixture matrix and native differential behavior, not a proof for all inputs or all source programs','qualified_request_domain':'ASCII absolute nonempty path segments [A-Za-z0-9_-], no trailing slash or query/encoding, <=96 characters; GET only; generated USL rejects outside domain'}
    (output/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['native_process_invocations','native_http_observations','usl_interpreter_invocations','usl_function_calls','elapsed_seconds']}))
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-root',default='/workspace/usl-v4.10.0-clean-test');p.add_argument('--output',default=str(ROOT/'results'));args=p.parse_args()
    def terminate(signum,frame):stop_all();raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
    asyncio.run(validate(args.source_root,args.output))
if __name__=='__main__':main()
