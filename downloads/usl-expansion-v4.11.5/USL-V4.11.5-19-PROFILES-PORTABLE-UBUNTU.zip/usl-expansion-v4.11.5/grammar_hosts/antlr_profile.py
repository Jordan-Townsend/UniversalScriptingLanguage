"""ANTLR3 Ruby/CSharp2 no-action LL(1) single-character-token recognizer."""
import re
import recognizer
Unsupported=recognizer.Unsupported
RESERVED=set("grammar lexer parser tree protected public private fragment returns locals throws catch finally scope options tokens import EOF EOR DOWN UP HIDDEN DEFAULT_TOKEN_CHANNEL class module def end begin if else elsif unless while until for do return break next redo retry yield super self nil true false alias and or not case when then rescue ensure undef defined namespace event object string int double bool new this base void initialize reset match recover emit report_error display_recognition_error token_names".split())

def parse(source,target):
    if target not in ('Ruby','CSharp2'):raise Unsupported('ANTLR3 target')
    if type(source) is not str or len(source)>8192:raise Unsupported('source type/limit')
    m=re.fullmatch(r'\s*grammar ([A-Z][A-Za-z0-9_]*);\s*options\s*\{\s*language\s*=\s*'+target+r'\s*;\s*\}\s*(.*?)\s*',source,re.S)
    if not m:raise Unsupported('exact ANTLR3 grammar and language target required')
    name,body=m.groups()
    if name!='Probe':raise Unsupported('audited grammar namespace is Probe')
    raw=[];lex={};start=None
    for decl in body.split(';'):
        if not decl.strip():continue
        d=re.fullmatch(r'\s*(?:public\s+)?([a-zA-Z][a-zA-Z0-9_]*)\s*:\s*(.*?)\s*',decl,re.S)
        if not d:raise Unsupported('plain rule declaration')
        n,expr=d.groups()
        if n in RESERVED:raise Unsupported('reserved grammar/runtime/target name')
        if n in lex or any(x[0]==n for x in raw):raise Unsupported('duplicate rule')
        if n[0].isupper():
            l=re.fullmatch(r"'([a-z])'",expr)
            if not l or l[1] in lex.values():raise Unsupported('distinct one-letter lexer tokens only')
            lex[n]=l[1]
        else:
            if start is None:
                start=n
                if n!='start':raise Unsupported('entry rule must be named start')
                if not re.search(r'\sEOF$',expr):raise Unsupported('start rule must end with explicit EOF')
                expr=re.sub(r'\sEOF$','',expr)
            if not re.fullmatch(r'[a-zA-Z0-9_()|*+? \t\r\n]+',expr) or 'EOF' in expr:raise Unsupported('no actions/literals/recovery/predicates/imports')
            raw.append((n,expr))
    if not raw or not lex:raise Unsupported('parser/lexer rules required')
    lines=[]
    for n,expr in raw:
        parts=re.findall(r'[A-Za-z][A-Za-z0-9_]*|[()|*+?]',expr)
        out=[]
        for p in parts:
            if p[0].isupper():
                if p not in lex:raise Unsupported('undefined lexer token')
                out.append(repr(lex[p]))
            else:out.append('/' if p=='|' else p)
        lines.append(n+' = '+' '.join(out))
    g=recognizer.parse('\n'.join(lines))
    # LL(1) FIRST/FOLLOW check: PEG ordered choices are equivalent here only
    # when alternatives and greedy suffixes make unambiguous token decisions.
    rules=g['rules']
    def first(n):
        k,v=n
        if k=='lit':return set(v[:1])
        if k=='ref':return first(rules[v])
        if k in ('star','plus','opt'):return first(v)
        if k=='choice':return set().union(*(first(x) for x in v))
        ans=set()
        for x in v:
            ans|=first(x)
            if not nullable(x):break
        return ans
    def nullable(n):
        k,v=n
        if k=='lit':return v==''
        if k=='ref':return nullable(rules[v])
        if k=='seq':return all(nullable(x) for x in v)
        if k=='choice':return any(nullable(x) for x in v)
        return k in ('star','opt') or nullable(v)
    def check(n,follow):
        k,v=n
        if k=='ref':check(rules[v],follow)
        elif k=='choice':
            seen=set()
            for x in v:
                fs=first(x)|(follow if nullable(x) else set())
                if fs&seen:raise Unsupported('non-LL(1) alternatives')
                seen|=fs;check(x,follow)
        elif k=='seq':
            aft=set(follow)
            for x in reversed(v):
                check(x,aft);aft=first(x)|(aft if nullable(x) else set())
        elif k in ('opt','star','plus'):
            if first(v)&follow:raise Unsupported('non-LL(1) repetition/follow')
            check(v,follow|first(v) if k in ('star','plus') else follow)
    check(rules[start],{'$'})
    return name,g,lex

def translate(source,text,target):
    _,g,_=parse(source,target)
    if type(text) is not str or len(text)>128 or any(ord(c)>127 for c in text):raise Unsupported('ASCII input <=128')
    return recognizer.RUNTIME+'\nlet rules = '+repr(g['rules'])+'\nlet text = '+repr(text)+'\nlet hit = recognize(rules['+repr(g['start'])+'], text, 0, rules)\nlet result = hit[0] and hit[1] == len(text)\n'
