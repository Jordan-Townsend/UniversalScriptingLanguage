#!/usr/bin/env python3
"""Private pinned small providers; no global runtime mutation."""
import hashlib,json,os,pathlib,subprocess,urllib.request,zipfile
ROOT=pathlib.Path(__file__).resolve().parent

def restore():
    base=ROOT/'providers';base.mkdir(exist_ok=True);spec=json.loads((ROOT/'PROVIDERS.json').read_text());receipts=[]
    for item in spec['providers']:
        path=base/item['filename']
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
            data=urllib.request.urlopen(item['url'],timeout=60).read()
            if hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('provider digest mismatch '+item['name'])
            path.write_bytes(data)
        if item['filename'].endswith('.gem'):
            command=['ruby','-S','gem','install','--local',str(path),'--install-dir',str(base/'gems'),'--no-document','--ignore-dependencies','--force']
            p=subprocess.run(command,check=True,text=True,capture_output=True,timeout=60)
        elif item['filename'].endswith('.nupkg'):
            with zipfile.ZipFile(path) as z:
                for name in ['lib/net40-client/Antlr3.Runtime.dll','lib/net40-client/Antlr3.Runtime.xml']:
                    target=base/'csharp'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
        receipts.append({'name':item['name'],'version':item['version'],'sha256':item['sha256']})
    # Runtime source tree hashes bind extracted Ruby code and ANTLR bundled generator.
    pins=json.loads((ROOT/'EXTRACTED_SHA256.json').read_text())
    for rel,sha in pins.items():
        p=base/rel
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:raise ValueError('extracted identity mismatch '+rel)
    result={'providers':receipts,'extracted_files_verified':len(pins),'global_installs':False}
    (base/'RESTORE_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':print(json.dumps(restore()))
