import pathlib,sys,tempfile,unittest,subprocess,json,os
import antlr_profile,jasmin_profile,treetop_profile,run
sys.path.insert(0,os.environ.get('USL_SOURCE_ROOT','/workspace/usl-v4.10.0-clean-test'))
from usl_systems.language import Interpreter

class SourceBoundaryTests(unittest.TestCase):
    def test_treetop_unsupported_ruby_and_regex(self):
        for expression in ['[a-z]+','"a" { def x; 1; end }','x:"a"','"#{1}"','"a\\n"','&"a"*','!("a")?']:
            with self.subTest(expression=expression),self.assertRaises(treetop_profile.Unsupported):treetop_profile.parse(run.treetop_source(expression))
    def test_treetop_cycles_unknown_duplicate(self):
        for expression in ['start','undefined','"a"*\nRULE start = "b"','maybe*\nRULE maybe = "a"?']:
            with self.subTest(expression=expression),self.assertRaises(treetop_profile.Unsupported):treetop_profile.parse(run.treetop_source(expression))
    def test_treetop_predicate_precedence_native_rejects(self):
        source=run.treetop_source('&"a"* "a"*')
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d);run.write(p/'g.tt',source);run.write(p/'inputs.json',['a'])
            command=['ruby',str(run.ROOT/'treetop_runner.rb'),str(p/'g.tt'),'Probe',str(p/'inputs.json')]
            result=subprocess.run(command,cwd=p,env=run.gemenv(),text=True,capture_output=True,timeout=15)
            self.assertNotEqual(result.returncode,0);self.assertIn('Expected one of',result.stderr)
    def test_antlr_target_is_exact(self):
        with self.assertRaises(antlr_profile.Unsupported):antlr_profile.parse(run.antlr_source('A','CSharp3'),'CSharp2')
        with self.assertRaises(antlr_profile.Unsupported):antlr_profile.parse(run.antlr_source('A','Ruby'),'CSharp2')
    def test_antlr_ll1_and_empty_repetition_rejected(self):
        for expr in ['A | A B','A* A','A? A','(A?)*','start','missing']:
            with self.subTest(expr=expr),self.assertRaises(antlr_profile.Unsupported):antlr_profile.parse(run.antlr_source(expr,'Ruby'),'Ruby')
    def test_antlr_source_actions_lexer_collision_rejected(self):
        source=run.antlr_source('A','Ruby')
        for altered in [source.replace('A EOF','A {puts 1} EOF'),source.replace("B: 'b'","B: 'a'"),source.replace(' EOF',''),source.replace("A: 'a'","A: 'aa'"),source+'A: \'d\';']:
            with self.subTest(source=altered),self.assertRaises(antlr_profile.Unsupported):antlr_profile.parse(altered,'Ruby')
    def test_jasmin_stack_local_join_and_directive_rejection(self):
        invalid=['iadd\nireturn','iload_1\nireturn','iconst_1\niconst_2\nireturn','iload_0\nifeq yes\niconst_1\nyes:\nireturn','goto missing','ldc 2147483648\nireturn','bipush 128\nireturn','iinc 0 128\niload_0\nireturn','iconst_0\nistore 7\niload_0\nireturn','invokevirtual thing','getstatic java/lang/System/out Ljava/io/PrintStream;']
        for body in invalid:
            with self.subTest(body=body),self.assertRaises(jasmin_profile.Unsupported):jasmin_profile.parse(run.asm(body))
    def test_jasmin_definite_init_after_branch(self):
        source=run.asm('iload_0\nifeq yes\niconst_1\nistore_1\nyes:\niload_1\nireturn')
        with self.assertRaises(jasmin_profile.Unsupported):jasmin_profile.parse(source)
    def test_jasmin_argument_types(self):
        for value in [True,1.0,'1',2**31,-2**31-1]:
            with self.subTest(value=value),self.assertRaises(jasmin_profile.Unsupported):jasmin_profile.translate(run.asm('iload_0\nireturn'),value)

class IndependentIntentTests(unittest.TestCase):
    def test_jvm_truncation_and_remainder(self):
        for opcode,want in [('idiv',-2),('irem',-1)]:
            source=run.asm('iload_0\niconst_3\n'+opcode+'\nireturn');value,_=run.execute(jasmin_profile.translate(source,-7),Interpreter);self.assertEqual(value,want)
    def test_jvm_overflow_extremes(self):
        for body,arg,want in [('iload_0\niconst_1\niadd',2147483647,-2147483648),('iload_0\nineg',-2147483648,-2147483648),('iload_0\niconst_m1\nidiv',-2147483648,-2147483648),('iload_0\niconst_m1\nirem',-2147483648,0)]:
            value,_=run.execute(jasmin_profile.translate(run.asm(body+'\nireturn'),arg),Interpreter);self.assertEqual(value,want)
    def test_wrong_wrap_mutation_fails_intent(self):
        generated=jasmin_profile.translate(run.asm('iload_0\niconst_1\niadd\nireturn'),2147483647)
        wrong=generated.replace('return (value + 2147483648) % 4294967296 - 2147483648','return value')
        actual,_=run.execute(wrong,Interpreter);self.assertNotEqual(actual,-2147483648)
    def test_ordered_choice_is_not_backtracking(self):
        source=run.treetop_source('("a" / "ab") "c"')
        result,_=run.execute(treetop_profile.translate(source,'abc'),Interpreter);self.assertIs(result,False)
    def test_native_jvm_verifier_rejects_bad_stack(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d);source=run.asm('iload_0\niadd\nireturn');run.write(p/'Program.j',source)
            run.host(['java','-jar',run.ROOT/'providers/jasmin.jar','-d',p,p/'Program.j'],p)
            run.host(['javac','-cp',p,'-d',p,run.ROOT/'JasminHarness.java'],p)
            native=subprocess.run(['java','-Xverify:all','-cp',str(p),'JasminHarness','1'],text=True,capture_output=True,timeout=15)
            self.assertNotEqual(native.returncode,0);self.assertIn('VerifyError',native.stderr)
    def test_batch_cases_contract(self):
        source=run.antlr_source('A B*','CSharp2');_,g,_=antlr_profile.parse(source,'CSharp2')
        values,_=run.execute(run.batch_usl(g,['a','ab','abb','a b','ad','b','']),Interpreter)
        self.assertEqual(values,[True,True,True,False,False,False,False])

class NativeBoundaryRegressionTests(unittest.TestCase):
    def test_jasmin_leading_zero_is_decimal(self):
        # Independent native assembler checks distinguish octal/decimal spellings.
        for body,want in [('ldc 010\nireturn',10),('bipush 010\nireturn',10),('sipush 010\nireturn',10),('iinc 0 010\niload_0\nireturn',11)]:
            with self.subTest(body=body),tempfile.TemporaryDirectory() as d:
                p=pathlib.Path(d);source=run.asm(body);run.write(p/'Program.j',source)
                run.host(['java','-jar',run.ROOT/'providers/jasmin.jar','-d',p,p/'Program.j'],p)
                run.host(['javac','-cp',p,'-d',p,run.ROOT/'JasminHarness.java'],p)
                result=run.host(['java','-Xverify:all','-cp',p,'JasminHarness','1'],p)
                self.assertEqual(int(result['stdout'].strip()),want)
                translated,_=run.execute(jasmin_profile.translate(source,1),Interpreter);self.assertEqual(translated,want)
    def test_antlr_reserved_words_fail_closed(self):
        for name in ['grammar','returns','scope','class','initialize','EOF','HIDDEN']:
            src=run.antlr_source('A','Ruby')+name+": 'd';\n"
            with self.subTest(name=name),self.assertRaises(antlr_profile.Unsupported):antlr_profile.parse(src,'Ruby')
        # Native grammar keywords are syntax errors as well, not ordinary names.
        for name in ['grammar','returns','scope']:
            with self.subTest(native_name=name),tempfile.TemporaryDirectory() as d:
                p=pathlib.Path(d);run.write(p/'Probe.g',run.antlr_source('A','Ruby')+name+": 'd';\n")
                z=subprocess.run(['java','-jar',str(run.ROOT/'providers/gems/gems/antlr3-1.11.0/java/antlr-full-3.5.jar'),str(p/'Probe.g')],text=True,capture_output=True,timeout=15)
                self.assertNotEqual(z.returncode,0);self.assertIn('error(',z.stderr)
    def test_treetop_grouped_negative_predicate_native_defect_recorded(self):
        source=run.treetop_source('!("a"?) "b"*')
        with self.assertRaises(treetop_profile.Unsupported):treetop_profile.parse(source)
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d);run.write(p/'g.tt',source);run.write(p/'i.json',['b'])
            z=subprocess.run(['ruby',str(run.ROOT/'treetop_runner.rb'),str(p/'g.tt'),'Probe',str(p/'i.json')],env=run.gemenv(),cwd=p,text=True,capture_output=True,timeout=15)
            self.assertNotEqual(z.returncode,0);self.assertIn('NoMethodError',z.stderr)

if __name__=='__main__':unittest.main()
