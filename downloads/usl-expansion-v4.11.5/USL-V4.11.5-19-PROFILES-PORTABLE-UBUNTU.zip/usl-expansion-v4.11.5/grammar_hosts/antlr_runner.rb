require 'json'
require File.expand_path('ProbeLexer.rb')
require File.expand_path('ProbeParser.rb')
values = JSON.parse(File.read(ARGV[0])).map do |text|
  errors = []
  lexer = Probe::Lexer.new(text)
  lexer.define_singleton_method(:report_error) { |e| errors << e.class.to_s }
  parser = Probe::Parser.new(lexer)
  parser.define_singleton_method(:report_error) { |e| errors << e.class.to_s }
  begin
    parser.start
    errors.empty?
  rescue ANTLR3::Error::RecognitionError
    false
  end
end
puts JSON.generate(values)
