"""Jasmin 3.0.3 integer JVM assembler profile -> explicit USL machine."""
import re
class Unsupported(ValueError):pass
BRANCH={'ifeq','ifne','iflt','ifle','ifgt','ifge','if_icmpeq','if_icmpne','if_icmplt','if_icmple','if_icmpgt','if_icmpge','goto'}
ZERO={'iadd','isub','imul','idiv','irem','ineg','dup','pop','swap','ireturn','nop'}

def parse(source):
    if type(source) is not str or len(source)>8192 or any(ord(c)>127 for c in source):raise Unsupported('ASCII source <=8192')
    lines=[s.split(';',1)[0].strip() for s in source.splitlines()];lines=[s for s in lines if s]
    if lines[:3]!=['.class public Program','.super java/lang/Object','.method public static run(I)I'] or lines[-1:]!=['.end method']:raise Unsupported('one static Program.run(I)I method required')
    if len(lines)<7 or not re.fullmatch(r'\.limit stack (?:[1-9]|[12][0-9]|3[0-2])',lines[3]) or not re.fullmatch(r'\.limit locals [1-8]',lines[4]):raise Unsupported('stack<=32 locals<=8 explicit limits/order')
    stacklimit=int(lines[3].split()[-1]);localcount=int(lines[4].split()[-1]);code=[];labels={}
    for line in lines[5:-1]:
        if re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*:',line):
            if line[:-1] in labels:raise Unsupported('duplicate label')
            labels[line[:-1]]=len(code);continue
        words=line.split();op=words[0];args=words[1:]
        if re.fullmatch('iconst_[0-5m][0-9]?',op):
            if op not in ['iconst_m1']+['iconst_'+str(i) for i in range(6)] or args:raise Unsupported('iconst syntax')
            code.append(['const',-1 if op=='iconst_m1' else int(op[-1])]);continue
        if op in ['bipush','sipush','ldc']:
            if len(args)!=1 or not re.fullmatch('-?[0-9]+',args[0]):raise Unsupported('integer constant')
            value=int(args[0]);low,high={'bipush':(-128,127),'sipush':(-32768,32767),'ldc':(-2147483648,2147483647)}[op]
            if not low<=value<=high:raise Unsupported('constant opcode range')
            code.append(['const',value]);continue
        if re.fullmatch(r'i(load|store)_[0-3]',op):
            if args:raise Unsupported('local syntax')
            args=[op[-1]];op=op[:-2]
        if op in ['iload','istore']:
            if len(args)!=1 or not re.fullmatch('[0-7]',args[0]) or int(args[0])>=localcount:raise Unsupported('local bounds')
            code.append([op,int(args[0])]);continue
        if op=='iinc':
            if len(args)!=2 or not re.fullmatch('[0-7]',args[0]) or int(args[0])>=localcount or not re.fullmatch('-?[0-9]+',args[1]) or not -128<=int(args[1])<=127:raise Unsupported('narrow iinc operands')
            code.append([op,[int(x) for x in args]]);continue
        if op in BRANCH:
            if len(args)!=1 or not re.fullmatch('[A-Za-z][A-Za-z0-9_]*',args[0]):raise Unsupported('branch label')
            code.append([op,args[0]]);continue
        if op in ZERO and not args:code.append([op,0]);continue
        raise Unsupported('opcode/directive outside int profile: '+line)
    if not code or len(code)>128:raise Unsupported('1..128 instructions')
    for ins in code:
        if ins[0] in BRANCH:
            if ins[1] not in labels or labels[ins[1]]>=len(code):raise Unsupported('undefined/out-of-body target')
            ins[1]=labels[ins[1]]
    # JVM int-only verifier: definite local initialization and equal stack height
    # at each join; iterate to fixed point so backward edges cannot bypass checks.
    states={0:(0,frozenset({0}))};work=[0]
    while work:
        pc=work.pop();height,initial=states[pc];op,arg=code[pc];need=0;delta=0;init=set(initial)
        if op in ['const','iload']:delta=1
        if op=='iload' and arg not in init:raise Unsupported('uninitialized local load')
        if op in ['istore','pop']:need=1;delta=-1
        if op=='istore':init.add(arg)
        if op=='iinc' and arg[0] not in init:raise Unsupported('uninitialized local increment')
        if op in ['iadd','isub','imul','idiv','irem']:need=2;delta=-1
        if op in ['ineg','ireturn']:need=1
        if op=='dup':need=1;delta=1
        if op=='swap':need=2
        if op.startswith('if_icmp'):need=2;delta=-2
        elif op.startswith('if'):need=1;delta=-1
        if height<need:raise Unsupported('operand stack underflow')
        h=height+delta
        if h>stacklimit:raise Unsupported('declared operand stack overflow')
        if op=='ireturn':
            if height!=1:raise Unsupported('profile requires exactly one return operand')
            continue
        successors=[arg] if op=='goto' else ([arg,pc+1] if op in BRANCH else [pc+1])
        for to in successors:
            if to>=len(code):raise Unsupported('reachable method fallthrough')
            new=(h,frozenset(init))
            if to in states:
                if states[to][0]!=h:raise Unsupported('inconsistent join stack height')
                new=(h,states[to][1]&new[1])
            if states.get(to)!=new:states[to]=new;work.append(to)
    return code,localcount

RUNTIME='''function wrap(value):
    return (value + 2147483648) % 4294967296 - 2147483648
function cut(items, n):
    let out = []
    for i in range(len(items) - n):
        let out = out + [items[i]]
    return out
function put(items, index, value):
    let out = []
    for i in range(len(items)):
        let out = out + [value if i == index else items[i]]
    return out
function jvm(code, argument, count):
    let locals = [argument]
    for i in range(count - 1):
        let locals = locals + [0]
    let stack = []
    let pc = 0
    let steps = 0
    while True:
        let steps = steps + 1
        assert steps <= 10000
        let op = code[pc][0]
        let arg = code[pc][1]
        let next = pc + 1
        if op == 'const':
            let stack = stack + [arg]
        elif op == 'iload':
            let stack = stack + [locals[arg]]
        elif op == 'istore':
            let locals = put(locals, arg, stack[-1])
            let stack = cut(stack, 1)
        elif op == 'iinc':
            let locals = put(locals, arg[0], wrap(locals[arg[0]] + arg[1]))
        elif op == 'dup':
            let stack = stack + [stack[-1]]
        elif op == 'pop':
            let stack = cut(stack, 1)
        elif op == 'swap':
            let stack = cut(stack, 2) + [stack[-1], stack[-2]]
        elif op == 'ineg':
            let stack = cut(stack, 1) + [wrap(-stack[-1])]
        elif op in ['iadd', 'isub', 'imul', 'idiv', 'irem']:
            let left = stack[-2]
            let right = stack[-1]
            if op == 'iadd':
                let value = left + right
            elif op == 'isub':
                let value = left - right
            elif op == 'imul':
                let value = left * right
            else:
                assert right != 0
                let quotient = abs(left) // abs(right)
                if (left < 0) != (right < 0):
                    let quotient = -quotient
                let value = quotient if op == 'idiv' else left - quotient * right
            let stack = cut(stack, 2) + [wrap(value)]
        elif op == 'ireturn':
            return stack[-1]
        elif op == 'goto':
            let next = arg
        elif op != 'nop':
            let left = stack[-2] if op in ['if_icmpeq','if_icmpne','if_icmplt','if_icmple','if_icmpgt','if_icmpge'] else stack[-1]
            let right = stack[-1] if op in ['if_icmpeq','if_icmpne','if_icmplt','if_icmple','if_icmpgt','if_icmpge'] else 0
            let stack = cut(stack, 2 if op in ['if_icmpeq','if_icmpne','if_icmplt','if_icmple','if_icmpgt','if_icmpge'] else 1)
            let good = False
            if op in ['ifeq','if_icmpeq']:
                let good = left == right
            elif op in ['ifne','if_icmpne']:
                let good = left != right
            elif op in ['iflt','if_icmplt']:
                let good = left < right
            elif op in ['ifle','if_icmple']:
                let good = left <= right
            elif op in ['ifgt','if_icmpgt']:
                let good = left > right
            elif op in ['ifge','if_icmpge']:
                let good = left >= right
            if good:
                let next = arg
        let pc = next
'''

def translate(source,argument):
    if type(argument) is not int or not -2147483648<=argument<=2147483647:raise Unsupported('signed32 argument')
    code,count=parse(source)
    return RUNTIME+'\nlet result = jvm('+repr(code)+', '+str(argument)+', '+str(count)+')\n'
