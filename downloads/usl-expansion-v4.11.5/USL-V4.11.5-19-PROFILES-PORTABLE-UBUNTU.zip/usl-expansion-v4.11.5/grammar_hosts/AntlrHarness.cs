using System;
using Antlr.Runtime;
public class CheckedLexer : ProbeLexer {
    public int Errors=0;
    public CheckedLexer(ICharStream input):base(input){}
    public override void DisplayRecognitionError(string[] tokenNames,RecognitionException e){Errors++;}
}
public class CheckedParser : ProbeParser {
    public int Errors=0;
    public CheckedParser(ITokenStream input):base(input){}
    public override void DisplayRecognitionError(string[] tokenNames,RecognitionException e){Errors++;}
}
public class AntlrHarness {
    public static void Main(string[] args){
        foreach(string encoded in System.IO.File.ReadAllLines(args[0])){
            string text=System.Text.Encoding.ASCII.GetString(Convert.FromBase64String(encoded));
            var lexer=new CheckedLexer(new ANTLRStringStream(text));
            var parser=new CheckedParser(new CommonTokenStream(lexer));
            bool good=true;
            try{parser.start();}catch(RecognitionException){good=false;}
            Console.WriteLine(good && lexer.Errors==0 && parser.Errors==0 ? "true":"false");
        }
    }
}
