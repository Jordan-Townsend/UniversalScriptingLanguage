"""Independent PEG-to-USL recognizer for a declared Parsimonious 0.10.0 grammar subset."""
from __future__ import annotations
import ast,re
from pathlib import Path
TOKEN=re.compile(r'''\s*(?:(\#[^\n]*\n)|([A-Za-z][A-Za-z0-9_]*)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|([=/()*+?!&]))''')
class Unsupported(ValueError):pass

def parse(source):
    if type(source) is not str or len(source)>8192:raise Unsupported('grammar source limit/type')
    rules={};order=[]
    # Deliberately one complete rule per line; newline is a rule delimiter.
    for raw in source.splitlines():
        line=raw.strip()
        if not line or line.startswith('#'):continue
        tokens=[];p=0
        while p<len(line):
            if not line[p:].strip():break
            m=TOKEN.match(line,p)
            if not m:raise Unsupported('unsupported PEG syntax at '+line[p:])
            p=m.end()
            if m[1]:continue
            tokens.append(m[2] or m[3] or m[4])
        if len(tokens)<3 or not tokens[0].isidentifier() or tokens[1]!='=':raise Unsupported('rule declaration')
        name=tokens[0]
        if name in rules:raise Unsupported('duplicate rule')
        pos=2
        def choice():
            nonlocal pos
            seqs=[sequence()]
            while pos<len(tokens) and tokens[pos]=='/':pos+=1;seqs.append(sequence())
            return seqs[0] if len(seqs)==1 else ['choice',seqs]
        def sequence():
            nonlocal pos
            seqs=[]
            while pos<len(tokens) and tokens[pos] not in ['/',')']:
                prefix=''
                if tokens[pos] in ['!','&']:prefix=tokens[pos];pos+=1
                if pos>=len(tokens):raise Unsupported('missing operand')
                token=tokens[pos];pos+=1
                if token=='(':
                    item=choice()
                    if pos>=len(tokens) or tokens[pos]!=')':raise Unsupported('unclosed group')
                    pos+=1
                elif token[:1] in ['"',"'"]:
                    try:value=ast.literal_eval(token)
                    except Exception as exc:raise Unsupported('literal') from exc
                    if type(value) is not str or any(ord(c)>127 or c=='\x00' for c in value):raise Unsupported('ASCII non-NUL literals only')
                    item=['lit',value]
                elif token.isidentifier():item=['ref',token]
                else:raise Unsupported('invalid atom')
                if pos<len(tokens) and tokens[pos] in ['?','*','+']:
                    item=[{'?':'opt','*':'star','+':'plus'}[tokens[pos]],item];pos+=1
                # Parsimonious applies repetition to the atom before the
                # lookahead: &"a"* means &("a"*), not (&"a")*.
                if prefix:item=['not' if prefix=='!' else 'and',item]
                seqs.append(item)
            if not seqs:raise Unsupported('empty sequence; use empty literal')
            return seqs[0] if len(seqs)==1 else ['seq',seqs]
        rules[name]=choice();order.append(name)
        if pos!=len(tokens):raise Unsupported('trailing grammar tokens')
    if not order or len(order)>32:raise Unsupported('rule count')
    def refs(n):
        if n[0]=='ref':return {n[1]}
        if n[0] in ['seq','choice']:return set().union(*(refs(x) for x in n[1]))
        if n[0] in ['lit']:return set()
        return refs(n[1])
    for n in rules.values():
        if not refs(n)<=rules.keys():raise Unsupported('undefined rule')
    # Detect all reference cycles, not only left recursion: this bounded profile
    # supports DAG rule reuse and rejects recursive grammars before host execution.
    visiting=set();done=set()
    def visit(name):
        if name in visiting:raise Unsupported('recursive grammar outside DAG profile')
        if name in done:return
        visiting.add(name)
        for r in refs(rules[name]):visit(r)
        visiting.remove(name);done.add(name)
    for n in rules:visit(n)
    def nullable(n):
        k,v=n
        if k=='lit':return v==''
        if k=='ref':return nullable(rules[v])
        if k=='seq':return all(nullable(x) for x in v)
        if k=='choice':return any(nullable(x) for x in v)
        if k in ['star','opt','not','and']:return True
        return nullable(v)
    def check(n):
        if n[0] in ['star','plus'] and nullable(n[1]):raise Unsupported('nullable repetition')
        if n[0] in ['seq','choice']:
            for x in n[1]:check(x)
        elif n[0] not in ['lit','ref']:check(n[1])
    for n in rules.values():check(n)
    return {'start':order[0],'rules':rules}

RUNTIME='''function recognize(node, text, pos, rules):
    let kind = node[0]
    let value = node[1]
    if kind == 'lit':
        if pos + len(value) > len(text):
            return [False, pos]
        let good = True
        for i in range(len(value)):
            if text[pos + i] != value[i]:
                let good = False
        return [good, pos + len(value) if good else pos]
    if kind == 'ref':
        return recognize(rules[value], text, pos, rules)
    if kind == 'seq':
        let at = pos
        for item in value:
            let hit = recognize(item, text, at, rules)
            if not hit[0]:
                return [False, pos]
            let at = hit[1]
        return [True, at]
    if kind == 'choice':
        for item in value:
            let hit = recognize(item, text, pos, rules)
            if hit[0]:
                return hit
        return [False, pos]
    if kind == 'and' or kind == 'not':
        let hit = recognize(value, text, pos, rules)
        return [hit[0] if kind == 'and' else not hit[0], pos]
    if kind == 'opt':
        let hit = recognize(value, text, pos, rules)
        return hit if hit[0] else [True, pos]
    let at = pos
    let count = 0
    let hit = recognize(value, text, at, rules)
    while hit[0]:
        assert hit[1] > at
        let at = hit[1]
        let count = count + 1
        let hit = recognize(value, text, at, rules)
    return [count > 0 or kind == 'star', at if count > 0 or kind == 'star' else pos]
'''

def translate(source,text):
    grammar=parse(source)
    if type(text) is not str or len(text)>128 or any(ord(c)>127 for c in text):raise Unsupported('ASCII input <=128')
    return RUNTIME+'\nlet rules = '+repr(grammar['rules'])+'\nlet text = '+repr(text)+'\nlet hit = recognize(rules['+repr(grammar['start'])+'], text, 0, rules)\nlet result = hit[0] and hit[1] == len(text)\n'
