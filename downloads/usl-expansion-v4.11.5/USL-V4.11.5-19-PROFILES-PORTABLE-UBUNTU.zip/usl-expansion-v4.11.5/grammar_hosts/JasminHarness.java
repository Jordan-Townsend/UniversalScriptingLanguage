public class JasminHarness {
    public static void main(String[] args) {
        for(String a:args) {
            try {System.out.println(Program.run(Integer.parseInt(a)));}
            catch(ArithmeticException e){System.out.println("ArithmeticException");}
        }
    }
}
