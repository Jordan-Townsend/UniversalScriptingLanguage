#!/usr/bin/env python3
"""Four actual native upstream hosts compared with emitted executable USL and intent."""
import argparse,base64,hashlib,itertools,json,os,pathlib,shutil,subprocess,sys,time
import antlr_profile,jasmin_profile,recognizer,treetop_profile
ROOT=pathlib.Path(__file__).resolve().parent

def sha(data):return hashlib.sha256(data.encode() if isinstance(data,str) else data).hexdigest()
def write(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(obj if isinstance(obj,str) else json.dumps(obj,indent=2)+'\n')
def host(command,cwd,env=None):
    start=time.perf_counter();p=subprocess.run([str(x) for x in command],cwd=cwd,env=env,text=True,capture_output=True,timeout=25)
    r={'command':[str(x) for x in command],'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'elapsed_seconds':time.perf_counter()-start}
    if p.returncode:raise AssertionError(r)
    return r

def words():return [''.join(x) for n in range(5) for x in itertools.product('abc',repeat=n)]+['a'*40,'c'*40,'d','ab d','a\n']
def grammars():
    # Intent predicates are independently authored, never copied from a parser.
    yield 'literal','"ab"',lambda s:s=='ab'
    yield 'dag','head tail\nRULE head = "a" / "b"\nRULE tail = "b"*',lambda s:len(s)>=1 and s[0] in 'ab' and set(s[1:])<=set('b')
    yield 'ordered-short','("a" / "ab") "c"',lambda s:s=='ac'
    yield 'ordered-long','("ab" / "a") "c"',lambda s:s in {'ac','abc'}
    yield 'one-or-more','("ab")+',lambda s:len(s)>0 and len(s)%2==0 and s=='ab'*(len(s)//2)
    yield 'optional','"a" "b"? "c"',lambda s:s in {'ac','abc'}
    yield 'greedy-star','"a"* "a"',lambda s:False
    yield 'greedy-optional','"a"? "a"',lambda s:s=='aa'
    yield 'positive','&"a" ("a" / "b")+',lambda s:bool(s) and s[0]=='a' and set(s)<=set('ab')
    yield 'negative','!"b" ("a" / "b")*',lambda s:not s or (s[0]=='a' and set(s)<=set('ab'))
    yield 'empty','""',lambda s:s==''

def antlr_grammars():
    yield 'literal','A B',lambda s:s=='ab'
    yield 'optional-choice','(A B? | C+)',lambda s:s in {'a','ab'} or bool(s) and set(s)=={'c'}
    yield 'star','A B*',lambda s:bool(s) and s[0]=='a' and set(s[1:])<=set('b')
    yield 'optional','A? B',lambda s:s in {'ab','b'}
    yield 'nested','(A B | C A)*',lambda s:len(s)%2==0 and all(s[i:i+2] in {'ab','ca'} for i in range(0,len(s),2))
    yield 'dag','head tail\nRULE head = A | C\nRULE tail = B*',lambda s:bool(s) and s[0] in 'ac' and set(s[1:])<=set('b')
    yield 'plus','(A B)+ C?',lambda s:(s[:-1] if s.endswith('c') else s) in {'ab'*i for i in range(1,65)}

def treetop_source(expr):
    parts=expr.split('\nRULE ');rules=[('start',parts[0])]+[tuple(x.split(' = ',1)) for x in parts[1:]]
    return 'grammar Probe\n'+''.join('  rule '+n+'\n    '+v+'\n  end\n' for n,v in rules)+'end\n'
def antlr_source(expr,target):
    parts=expr.split('\nRULE ');rules=[('start',parts[0]+' EOF')]+[tuple(x.split(' = ',1)) for x in parts[1:]]
    return 'grammar Probe;\noptions { language='+target+'; }\n'+''.join(('public ' if n=='start' else '')+n+' : '+v+';\n' for n,v in rules)+"A: 'a';\nB: 'b';\nC: 'c';\n"

def batch_usl(grammar,inputs):
    return recognizer.RUNTIME+'\nlet rules = '+repr(grammar['rules'])+'\nlet result = []\nfor text in '+repr(inputs)+':\n    let hit = recognize(rules['+repr(grammar['start'])+'], text, 0, rules)\n    let result = result + [hit[0] and hit[1] == len(text)]\n'
def execute(generated,Interpreter):
    p=Interpreter(max_ops=6000000,timeout=15,max_output=100000,max_depth=120).run(generated)
    return p.variables['result'],{'operations':p.operations,'elapsed_ms':p.elapsed_ms}
def gemenv():
    e=dict(os.environ);e['GEM_HOME']=str(ROOT/'providers/gems');e['GEM_PATH']=e['GEM_HOME'];return e

def peg_run(out,Interpreter,lang):
    records=[];receipts=[];casecount=0;uslcount=0;inputs=words();target={'antlr-ruby':'Ruby','antlr-csharp':'CSharp2'}.get(lang)
    enum=grammars() if lang=='treetop' else antlr_grammars()
    for name,expr,predicate in enum:
        folder=out/lang/name;folder.mkdir(parents=True,exist_ok=True)
        if lang=='treetop':
            source=treetop_source(expr);n,g=treetop_profile.parse(source);original=folder/'original.tt';write(original,source);write(folder/'inputs.json',inputs)
            native=host(['ruby',ROOT/'treetop_runner.rb',original,n,folder/'inputs.json'],folder,gemenv());nativevalues=json.loads(native['stdout']);receipts.append(native)
        else:
            source=antlr_source(expr,target);n,g,lex=antlr_profile.parse(source,target);original=folder/'Probe.g';write(original,source)
            generated=host(['java','-jar',ROOT/'providers/gems/gems/antlr3-1.11.0/java/antlr-full-3.5.jar',original],folder);receipts.append(generated)
            if lang=='antlr-ruby':
                write(folder/'inputs.json',inputs);native=host(['ruby',ROOT/'antlr_runner.rb',folder/'inputs.json'],folder,gemenv());nativevalues=json.loads(native['stdout']);receipts.append(native)
            else:
                dll=ROOT/'providers/csharp/lib/net40-client/Antlr3.Runtime.dll';shutil.copyfile(dll,folder/'Antlr3.Runtime.dll')
                compiled=host(['mcs','-r:'+str(dll),'-out:'+str(folder/'AntlrHarness.exe'),folder/'ProbeLexer.cs',folder/'ProbeParser.cs',ROOT/'AntlrHarness.cs'],folder);receipts.append(compiled)
                write(folder/'inputs.base64','\n'.join(base64.b64encode(x.encode()).decode() for x in inputs)+'\n')
                native=host(['mono',folder/'AntlrHarness.exe',folder/'inputs.base64'],folder);nativevalues=[x=='true' for x in native['stdout'].splitlines()];receipts.append(native)
        expected=[bool(predicate(s)) for s in inputs];generated=batch_usl(g,inputs);write(folder/'generated.usl',generated);uslvalues,cost=execute(generated,Interpreter);uslcount+=1
        if type(uslvalues) is not list or any(type(x) is not bool for x in uslvalues) or expected!=nativevalues or expected!=uslvalues:raise AssertionError((lang,name,[(s,e,n,u) for s,e,n,u in zip(inputs,expected,nativevalues,uslvalues) if e!=n or e!=u]))
        records.append({'name':name,'source_sha256':sha(source),'generated_sha256':sha(generated),'generated_file':str((folder/'generated.usl').relative_to(out)),'inputs':inputs,'expected':expected,'native':nativevalues,'usl':uslvalues,'native_semantic_observations':len(inputs),'usl_interpreter_invocations':1,**cost});casecount+=len(inputs)
    bound='ASCII complete-input DAG recognizer <=32 rules, <=128-character input; literals, sequence, ordered choice, *, +, ?, literal-only & and !; no trees/actions/labels/Ruby extensions' if lang=='treetop' else 'ANTLR3 '+target+' action-free LL(1) DAG complete-input recognizer; distinct one-character ASCII lexer tokens; parser sequence, unambiguous alternatives, *, + and ?; explicit EOF; no recovery accepted, lexer and parser errors both reject'
    return profile(lang,bound,records,receipts,casecount,uslcount,['full syntax, semantic actions, AST/tree and diagnostic contracts','recursive grammars and native error recovery semantics','Unicode, lexical longest-match, token channels and libraries' if lang!='treetop' else 'all Ruby extensions, character classes, encoding and packrat/tree contracts','ANTLR generator warning/template conformance outside tested forms' if lang!='treetop' else 'all upstream compiler/runtime conformance','full normative/dialect/library/platform and intent-proof qualification gates'])

HEADER='.class public Program\n.super java/lang/Object\n.method public static run(I)I\n.limit stack 8\n.limit locals 4\n'
def asm(body):return HEADER+body+'\n.end method\n'
def wrap(x):return (x+2**31)%2**32-2**31

def jasmin_cases():
    nums=[-2147483648,-2147483647,-100,-7,-1,0,1,2,7,99,2147483646,2147483647]
    for op,fn in [('iadd',lambda x:wrap(x+7)),('isub',lambda x:wrap(x-7)),('imul',lambda x:wrap(x*7)),('idiv',lambda x:abs(x)//7*(-1 if x<0 else 1)),('irem',lambda x:x-(abs(x)//7*(-1 if x<0 else 1))*7)]:yield op,asm('iload_0\nbipush 7\n'+op+'\nireturn'),nums,fn
    yield 'negative-divisor',asm('iload_0\nbipush -3\nidiv\nireturn'),nums,lambda x:abs(x)//3*(-1 if x>0 else 1)
    yield 'min-overflow-div',asm('iload_0\niconst_m1\nidiv\nireturn'),nums,lambda x:wrap(-x)
    yield 'negation',asm('iload_0\nineg\nireturn'),nums,lambda x:wrap(-x)
    yield 'dup-local',asm('iload_0\ndup\nimul\nistore_1\niinc 1 -7\niload_1\nireturn'),nums,lambda x:wrap(x*x-7)
    yield 'swap-pop',asm('iload_0\nldc 2147483647\nswap\npop\nireturn'),nums,lambda x:2147483647
    for op,pred in [('ifeq',lambda x:x==0),('ifne',lambda x:x!=0),('iflt',lambda x:x<0),('ifle',lambda x:x<=0),('ifgt',lambda x:x>0),('ifge',lambda x:x>=0)]:yield op,asm('iload_0\n'+op+' yes\niconst_0\ngoto done\nyes:\niconst_1\ndone:\nireturn'),nums,lambda x,pred=pred:int(pred(x))
    for op,pred in [('if_icmpeq',lambda x:x==2),('if_icmpne',lambda x:x!=2),('if_icmplt',lambda x:x<2),('if_icmple',lambda x:x<=2),('if_icmpgt',lambda x:x>2),('if_icmpge',lambda x:x>=2)]:yield op,asm('iload_0\niconst_2\n'+op+' yes\niconst_0\ngoto done\nyes:\niconst_1\ndone:\nireturn'),nums,lambda x,pred=pred:int(pred(x))
    yield 'bounded-loop',asm('iconst_0\nistore_1\nloop:\niload_0\nifle done\niload_1\niload_0\niadd\nistore_1\niinc 0 -1\ngoto loop\ndone:\niload_1\nireturn'),[-3,0,1,2,5,17,40],lambda x:max(0,x)*(max(0,x)+1)//2
    yield 'division-zero',asm('iload_0\niconst_0\nidiv\nireturn'),[0,1,-1,2147483647],lambda x:'ArithmeticException'
    yield 'remainder-zero',asm('iload_0\niconst_0\nirem\nireturn'),[0,1,-1],lambda x:'ArithmeticException'
    yield 'push-widths',asm('sipush -32768\nbipush -128\niadd\niload_0\niadd\nnop\nireturn'),nums,lambda x:wrap(x-32896)

def jasmin_run(out,Interpreter):
    records=[];receipts=[];casecount=0;uslcount=0
    for name,source,args,predicate in jasmin_cases():
        folder=out/'jasmin'/name;folder.mkdir(parents=True,exist_ok=True);write(folder/'Program.j',source);jasmin_profile.parse(source)
        assembled=host(['java','-jar',ROOT/'providers/jasmin.jar','-d',folder,folder/'Program.j'],folder);receipts.append(assembled)
        if not (folder/'Program.class').is_file():raise AssertionError(assembled)
        compiled=host(['javac','-cp',folder,'-d',folder,ROOT/'JasminHarness.java'],folder);receipts.append(compiled)
        native=host(['java','-Xverify:all','-cp',folder,'JasminHarness',*[str(x) for x in args]],folder);receipts.append(native)
        nativevalues=[x if x=='ArithmeticException' else int(x) for x in native['stdout'].splitlines()];expected=[predicate(x) for x in args];uslvalues=[];samples=[]
        for i,x in enumerate(args):
            generated=jasmin_profile.translate(source,x);path=folder/(str(i)+'.usl');write(path,generated)
            try:value,cost=execute(generated,Interpreter)
            except Exception as exc:
                if expected[i]!='ArithmeticException' or 'Assertion failed' not in str(exc):raise
                value='ArithmeticException';cost={'error':str(exc),'error_mapping':'JVM divide/remainder by zero maps to failed nonzero divisor assertion in USL'}
            uslvalues.append(value);uslcount+=1;samples.append({'argument':x,'generated_sha256':sha(generated),'generated_file':str(path.relative_to(out)),**cost})
        if nativevalues!=expected or uslvalues!=expected:raise AssertionError((name,expected,nativevalues,uslvalues))
        records.append({'name':name,'source_sha256':sha(source),'arguments':args,'expected':expected,'native':nativevalues,'usl':uslvalues,'samples':samples});casecount+=len(args)
    return profile('jasmin','Jasmin 3.0.3 JVM signed32 Program.run(I)I; stack/locals, narrow constants/iinc, + - * / remainder/negation with wrap, dup/pop/swap, all integer conditionals/goto and return; <=128 instructions/32 stack/8 locals/10000 executed instructions. Definite-init and stack-join checks; selected arithmetic error-class mapping, no native diagnostic identity',records,receipts,casecount,uslcount,['all other JVM opcodes/types, classfiles, objects, exceptions and method/ABI contracts','full JVM verification equivalence and termination/resource proof','native Java exception diagnostics and USL error representation equivalence','JasminXT directives, annotations, full lexical forms and version conformance','full normative/library/platform and original-intent proof qualification gates'])

def profile(id,bound,records,receipts,cases,uslcount,openitems):
    return {'catalog_id':id,'scoped_profile_validated':True,'full_standard_qualified':False,'exact_profile':bound,'cases':cases,'native_executions':len(receipts),'usl_executions':uslcount,'native_unit':'physical subprocess invocations (generation/assembly/compilation plus runtime); semantic observations separately labelled','native_semantic_observations':cases,'native_receipts':receipts,'case_records':records,'open_obligations':openitems}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-root',required=True);parser.add_argument('--output',required=True);args=parser.parse_args();out=pathlib.Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
    # Extracted libraries/generator and runtime DLL are verified before use.
    pins=json.loads((ROOT/'EXTRACTED_SHA256.json').read_text())
    for rel,digest in pins.items():
        if sha((ROOT/'providers'/rel).read_bytes())!=digest:raise AssertionError('provider identity '+rel)
    jar=next(x for x in json.loads((ROOT/'PROVIDERS.json').read_text())['providers'] if x['name']=='jasmin')
    if sha((ROOT/'providers'/jar['filename']).read_bytes())!=jar['sha256']:raise AssertionError('Jasmin identity')
    base=pathlib.Path(args.source_root).resolve();sys.path.insert(0,str(base));from usl_systems.language import Interpreter
    records=[peg_run(out,Interpreter,x) for x in ['treetop','antlr-ruby','antlr-csharp']]+[jasmin_run(out,Interpreter)]
    identities={}
    for name in ['ruby','java','javac','mcs','mono']:
        command=[name,'-version' if name in ['java','javac'] else '--version'];receipt=host(command,out)
        identities[name]={'path':shutil.which(name),'resolved_path':str(pathlib.Path(shutil.which(name)).resolve()),'launch_file_sha256':sha(pathlib.Path(shutil.which(name)).resolve().read_bytes()),'version_probe':receipt}
    write(out/'results.json',{'records':records,'toolchain_identity':identities,'usl_runtime_sha256':sha((base/'usl_systems/language.py').read_bytes()),'separate_toolchain_identity_probe_processes':5,'native_or_usl_evidence_cached':False,'full_standard_qualified':False})
    print(json.dumps({'ids':[x['catalog_id'] for x in records],'cases':{x['catalog_id']:x['cases'] for x in records},'native_processes':{x['catalog_id']:x['native_executions'] for x in records},'usl_interpreter_invocations':{x['catalog_id']:x['usl_executions'] for x in records}}))
if __name__=='__main__':main()
