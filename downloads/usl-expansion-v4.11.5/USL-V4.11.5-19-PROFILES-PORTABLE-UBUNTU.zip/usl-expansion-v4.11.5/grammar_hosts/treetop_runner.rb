require 'json'
require 'treetop'
source = File.read(ARGV[0]); name = ARGV[1]
ruby = Treetop::Compiler::GrammarCompiler.new.ruby_source_from_string(source)
File.write('native_parser.rb',ruby)
require File.expand_path('native_parser.rb')
parser = Object.const_get(name+'Parser').new
values = JSON.parse(File.read(ARGV[2])).map { |text| !parser.parse(text).nil? }
puts JSON.generate(values)
