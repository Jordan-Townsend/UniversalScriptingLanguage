# Native grammar and JVM hosts: four bounded profiles

This addon implements actual source frontends and emitted `.usl` programs for
`treetop`, `antlr-ruby`, `antlr-csharp`, and `jasmin`. It compares real upstream
execution, fresh USL execution, and separately written intent predicates. None of
these profiles qualifies a complete language standard or proves arbitrary intent.

Run in the retained Linux/POSIX toolchain environment:

```bash
source /workspace/.onboarding/activate-usl.sh
python restore.py
python -m unittest test_grammar_hosts
python run.py --source-root /workspace/usl-v4.10.0-clean-test --output results
```

The source archive contains no native host binaries. `restore.py` installs small
pinned providers privately under `providers/`: Treetop 1.6.18, Polyglot 0.3.5,
ANTLR3 Ruby runtime 1.11.0 with its upstream ANTLR 3.5 generator, Jasmin 3.0.3
(with its bundled Java CUP dependency), and Antlr3.Runtime 3.5.1 .NET40-client.
`PROVIDERS.json` retains URLs and SHA256 pins; RubyGems pins match publisher
metadata. Maven/NuGet pins were established by HTTPS retrieval, without a claim
of independently qualified publisher signatures. `EXTRACTED_SHA256.json` binds
257 extracted runtime/generator/gemspec files. Native Ruby, Java/Javac and
Mono/MCS are prerequisites; their actual launch identities and version outputs
are recorded by each fresh run. Public provider installs never alter global gems.

The Pygments catalog names were inspected directly. ANTLR C# means the legacy
ANTLR3 **CSharp2** target identified by Pygments, not ANTLR4 or CSharp3. Both ANTLR
profiles actually generate parsers from `.g`, compile the C# output where
applicable, and run the Ruby/C# parsers. Treetop compiles `.tt` to upstream Ruby
and runs it. Jasmin assembles `.j`, and Java loads the class with
`-Xverify:all` before execution.

## Exact scope

Treetop supports a `grammar Probe` declaration, lowercase named rules with one
complete expression line per rule, and a nonrecursive rule DAG. Selected literals
contain lowercase ASCII letters, including empty literal. Sequence, ordered
choice, grouping, `?`, `*`, `+`, and **literal-only** positive/negative lookahead
are translated. Recognition requires the complete input; returned parse trees,
node extensions/actions, labels, regex character classes, Unicode/encoding and
full diagnostics are open. Recursive rules, nullable repetition, and unsupported
syntax are rejected. Source is at most 8192 characters, 32 rules; input is ASCII
at most 128 characters. Full source rule structure is parsed; the input is not
pre-evaluated by the translator.

ANTLR3 supports `grammar Probe`, exact `language=Ruby` or `language=CSharp2`, a
public entry rule named `start` ending in explicit EOF, nonrecursive parser-rule
DAGs, distinct lowercase one-character lexer literals, token/rule references,
sequence, alternatives, grouping, optional and repetition. A static FIRST/FOLLOW
check rejects conflicts before lowering to the shared PEG recognizer. Rule and
alternative order is preserved. Actions, semantic/syntactic predicates, token
channels, imports, lexer ranges/Unicode/longest-match, generated ASTs, recovery
behavior and recursive grammars remain open. Acceptance rejects **both lexer and
parser errors**, including illegal characters that default native recovery may
otherwise skip. Reserved grammar/runtime and selected target names are rejected.

Jasmin supports one exact public `Program.run(I)I` static method, explicit limits
of 32 stack slots and 8 locals, and at most 128 instructions. The frontend
implements int constants (`iconst`, `bipush`, `sipush`, integer `ldc`), loads/stores,
narrow `iinc`, `iadd/isub/imul/idiv/irem/ineg`, `dup/pop/swap/nop`, all zero and
pairwise integer comparisons, `goto`, and `ireturn`. It checks definite local
initialization, operand stack bounds and consistent joins. Signed32 arithmetic
wraps exactly, division truncates toward zero, remainder follows the dividend,
and MIN_VALUE/-1 behavior matches JVM. Selected divide/remainder-by-zero errors
map Java `ArithmeticException` to a failed nonzero-divisor USL assertion; native
exception text/stack trace equivalence is not claimed. At most 10000 instructions
may execute in the USL profile; nontermination equivalence is not proved. Other
JVM opcodes, objects, arbitrary methods/classes and all ABI/library/exception
contracts remain open.

## Evidence and discovered boundaries

Each recognizer batch enumerates all 121 strings of length 0..4 over `abc`, plus
five long/illegal-character inputs. The independent predicates specify accepted
languages directly, including ordered PEG choice and greedy optional/repetition.
Jasmin includes int32 extremes, every selected branch, backward bounded loops,
stack/local reuse, wrapping and arithmetic failures. A mutation that disables
signed32 wrap fails its independent intent check.

Treetop 1.6.18 rejects a predicate directly followed by a repetition suffix, such
as `&"a"*`. The selected frontend rejects this spelling. The upstream compiler
also crashes on `!("a"?) "b"*` with `NoMethodError`; grouped lookahead is therefore
outside this profile. Both discoveries have actual native negative regressions.
ANTLR3 CSharp2 generation emits known upstream template warnings for tested
forms. Complete generated output, warnings, actual C# compilation and runtime
receipts are preserved; those warnings remain a full-generator qualification
obligation. No generator templates or emitted parsers are silently patched.

`results/results.json` contains every input, independent expected result, native
result, USL result, original/generated hashes, fresh native stdout/stderr,
process commands/timing, actual USL operation costs and toolchain identity.
Generated native Ruby/C# and `.usl` source are included alongside original source.
Recognition cases are **semantic observations**, often batched into one process.
`native_executions` counts physical subprocess invocations, including generation
and compilation; `usl_executions` counts actual Interpreter.run invocations.
Five extra toolchain version processes are labelled separately at the root.
No execution evidence is replayed from cache. Shared grammar IR/runtime code is
engineering reuse, not a transferred proof of the language standards.

Ubuntu 26.04 compatibility is determined by the root's fresh Ubuntu workflow;
this family does not independently claim a standalone fresh Ubuntu installer.
