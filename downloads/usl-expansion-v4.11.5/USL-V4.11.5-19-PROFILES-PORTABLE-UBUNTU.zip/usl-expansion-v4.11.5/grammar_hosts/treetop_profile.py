"""Treetop 1.6.18 ASCII DAG recognizer. Native tree values/actions are outside scope."""
import re
import recognizer
Unsupported=recognizer.Unsupported

def parse(source):
    if type(source) is not str or len(source)>8192:raise Unsupported('source type/limit')
    lines=[x.strip() for x in source.splitlines() if x.strip() and not x.lstrip().startswith('#')]
    if not lines or not re.fullmatch(r'grammar [A-Z][A-Za-z0-9_]*',lines[0]) or lines[-1]!='end':raise Unsupported('grammar Name ... end required')
    name=lines[0].split()[1]
    if name!='Probe':raise Unsupported('audited grammar namespace is Probe')
    rules=[];i=1
    while i<len(lines)-1:
        m=re.fullmatch(r'rule ([a-z][a-z0-9_]*)',lines[i])
        if not m or i+2>=len(lines)-1 or lines[i+2]!='end':raise Unsupported('one complete expression line per rule')
        expr=lines[i+1]
        # Ruby literal escapes/interpolation are deliberately excluded: selected
        # native quoted literals consist of plain ASCII a-z letters only.
        for lit in re.findall(r'''"[^"\n]*"|'[^'\n]*' ''',expr,re.X):
            if not re.fullmatch(r'''["'][a-z]*["']''',lit):raise Unsupported('plain lowercase literals only')
        if '\\' in expr or '#{' in expr or any(c in expr for c in '{}[]<>.:'):raise Unsupported('actions/classes/labels/ranges outside recognizer profile')
        # Treetop's predicate grammar does not permit a suffix directly on
        # the predicate operand. Parentheses around the repeated operand are
        # required (e.g. &("a"*)). Reject rather than inherit PEG-host syntax.
        tokens=re.findall(r'"[a-z]*"|\'[a-z]*\'|[a-z][a-z0-9_]*|[()/+*?!&]',expr)
        for at,tok in enumerate(tokens):
            if tok not in ('&','!'):continue
            j=at+1
            if j>=len(tokens) or tokens[j][:1] not in ('\"', "'"):raise Unsupported('literal lookahead operands only; native grouped/nullable compiler boundary')
            if j<len(tokens) and tokens[j]=='(':
                depth=1;j+=1
                while j<len(tokens) and depth:
                    depth+=(tokens[j]=='(')-(tokens[j]==')');j+=1
            else:j+=1
            if j<len(tokens) and tokens[j] in ('*','+','?'):raise Unsupported('Treetop predicate followed by repetition needs parentheses')
        rules.append(m[1]+' = '+expr);i+=3
    if i!=len(lines)-1:raise Unsupported('trailing source')
    grammar=recognizer.parse('\n'.join(rules))
    return name,grammar

def translate(source,text):
    _,g=parse(source)
    if type(text) is not str or len(text)>128 or any(ord(c)>127 for c in text):raise Unsupported('ASCII input <=128')
    return recognizer.RUNTIME+'\nlet rules = '+repr(g['rules'])+'\nlet text = '+repr(text)+'\nlet hit = recognize(rules['+repr(g['start'])+'], text, 0, rules)\nlet result = hit[0] and hit[1] == len(text)\n'
