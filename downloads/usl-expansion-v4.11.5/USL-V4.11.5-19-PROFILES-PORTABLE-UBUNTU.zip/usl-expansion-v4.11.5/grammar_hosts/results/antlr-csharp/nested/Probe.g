grammar Probe;
options { language=CSharp2; }
public start : (A B | C A)* EOF;
A: 'a';
B: 'b';
C: 'c';
