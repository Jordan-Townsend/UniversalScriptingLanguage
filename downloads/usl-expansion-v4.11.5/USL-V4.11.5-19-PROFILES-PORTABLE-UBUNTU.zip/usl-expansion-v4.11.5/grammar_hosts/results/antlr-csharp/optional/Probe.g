grammar Probe;
options { language=CSharp2; }
public start : A? B EOF;
A: 'a';
B: 'b';
C: 'c';
