grammar Probe;
options { language=CSharp2; }
public start : (A B? | C+) EOF;
A: 'a';
B: 'b';
C: 'c';
