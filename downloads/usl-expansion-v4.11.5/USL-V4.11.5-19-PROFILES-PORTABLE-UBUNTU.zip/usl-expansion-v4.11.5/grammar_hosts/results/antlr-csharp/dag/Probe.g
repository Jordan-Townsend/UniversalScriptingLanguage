grammar Probe;
options { language=CSharp2; }
public start : head tail EOF;
head : A | C;
tail : B*;
A: 'a';
B: 'b';
C: 'c';
