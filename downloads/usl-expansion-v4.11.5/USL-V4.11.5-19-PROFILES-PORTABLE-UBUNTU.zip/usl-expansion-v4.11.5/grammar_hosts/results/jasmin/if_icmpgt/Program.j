.class public Program
.super java/lang/Object
.method public static run(I)I
.limit stack 8
.limit locals 4
iload_0
iconst_2
if_icmpgt yes
iconst_0
goto done
yes:
iconst_1
done:
ireturn
.end method
