.class public Program
.super java/lang/Object
.method public static run(I)I
.limit stack 8
.limit locals 4
sipush -32768
bipush -128
iadd
iload_0
iadd
nop
ireturn
.end method
