.class public Program
.super java/lang/Object
.method public static run(I)I
.limit stack 8
.limit locals 4
iload_0
dup
imul
istore_1
iinc 1 -7
iload_1
ireturn
.end method
