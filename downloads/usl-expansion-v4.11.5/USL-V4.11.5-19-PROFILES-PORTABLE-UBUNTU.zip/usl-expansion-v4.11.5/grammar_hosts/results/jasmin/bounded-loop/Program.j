.class public Program
.super java/lang/Object
.method public static run(I)I
.limit stack 8
.limit locals 4
iconst_0
istore_1
loop:
iload_0
ifle done
iload_1
iload_0
iadd
istore_1
iinc 0 -1
goto loop
done:
iload_1
ireturn
.end method
