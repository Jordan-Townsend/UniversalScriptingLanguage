.class public Program
.super java/lang/Object
.method public static run(I)I
.limit stack 8
.limit locals 4
iload_0
bipush 7
irem
ireturn
.end method
