.class public Program
.super java/lang/Object
.method public static run(I)I
.limit stack 8
.limit locals 4
iload_0
ldc 2147483647
swap
pop
ireturn
.end method
