grammar Probe;
options { language=Ruby; }
public start : head tail EOF;
head : A | C;
tail : B*;
A: 'a';
B: 'b';
C: 'c';
