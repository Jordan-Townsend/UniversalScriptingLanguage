#!/usr/bin/env ruby
#
# /workspace/usl-expansion-v4.11.5/grammar_hosts/results/antlr-ruby/literal/Probe.g
# --
# Generated using ANTLR version: 3.5
# Ruby runtime library version: 1.10.0
# Input grammar file: /workspace/usl-expansion-v4.11.5/grammar_hosts/results/antlr-ruby/literal/Probe.g
# Generated at: 2026-10-14 22:23:22
#

# ~~~> start load path setup
this_directory = File.expand_path( File.dirname( __FILE__ ) )
$LOAD_PATH.unshift( this_directory ) unless $LOAD_PATH.include?( this_directory )

antlr_load_failed = proc do
  load_path = $LOAD_PATH.map { |dir| '  - ' << dir }.join( $/ )
  raise LoadError, <<-END.strip!

Failed to load the ANTLR3 runtime library (version 1.10.0):

Ensure the library has been installed on your system and is available
on the load path. If rubygems is available on your system, this can
be done with the command:

  gem install antlr3

Current load path:
#{ load_path }

  END
end

defined?( ANTLR3 ) or begin

  # 1: try to load the ruby antlr3 runtime library from the system path
  require 'antlr3'

rescue LoadError

  # 2: try to load rubygems if it isn't already loaded
  defined?( Gem ) or begin
    require 'rubygems'
  rescue LoadError
    antlr_load_failed.call
  end

  # 3: try to activate the antlr3 gem
  begin
    defined?( gem ) and gem( 'antlr3', '~> 1.10.0' )
  rescue Gem::LoadError
    antlr_load_failed.call
  end

  require 'antlr3'

end
# <~~~ end load path setup

module Probe
  # TokenData defines all of the token type integer values
  # as constants, which will be included in all
  # ANTLR-generated recognizers.
  const_defined?( :TokenData ) or TokenData = ANTLR3::TokenScheme.new

  module TokenData

    # define the token constants
    define_tokens( :EOF => -1, :A => 4, :B => 5, :C => 6 )

  end


  class Lexer < ANTLR3::Lexer
    @grammar_home = Probe
    include TokenData

    begin
      generated_using( "/workspace/usl-expansion-v4.11.5/grammar_hosts/results/antlr-ruby/literal/Probe.g", "3.5", "1.10.0" )
    rescue NoMethodError => error
      # ignore
    end

    RULE_NAMES   = [ "A", "B", "C" ].freeze
    RULE_METHODS = [ :a!, :b!, :c! ].freeze

    def initialize( input=nil, options = {} )
      super( input, options )
    end


    # - - - - - - - - - - - lexer rules - - - - - - - - - - - -
    # lexer rule a! (A)
    # (in /workspace/usl-expansion-v4.11.5/grammar_hosts/results/antlr-ruby/literal/Probe.g)
    def a!
      # -> uncomment the next line to manually enable rule tracing
      # trace_in( __method__, 1 )



      type = A
      channel = ANTLR3::DEFAULT_CHANNEL
    # - - - - label initialization - - - -


      # - - - - main rule block - - - -
      # at line 4:4: 'a'
      match( 0x61 )


      @state.type = type
      @state.channel = channel
    ensure
      # -> uncomment the next line to manually enable rule tracing
      # trace_out( __method__, 1 )


    end

    # lexer rule b! (B)
    # (in /workspace/usl-expansion-v4.11.5/grammar_hosts/results/antlr-ruby/literal/Probe.g)
    def b!
      # -> uncomment the next line to manually enable rule tracing
      # trace_in( __method__, 2 )



      type = B
      channel = ANTLR3::DEFAULT_CHANNEL
    # - - - - label initialization - - - -


      # - - - - main rule block - - - -
      # at line 5:4: 'b'
      match( 0x62 )


      @state.type = type
      @state.channel = channel
    ensure
      # -> uncomment the next line to manually enable rule tracing
      # trace_out( __method__, 2 )


    end

    # lexer rule c! (C)
    # (in /workspace/usl-expansion-v4.11.5/grammar_hosts/results/antlr-ruby/literal/Probe.g)
    def c!
      # -> uncomment the next line to manually enable rule tracing
      # trace_in( __method__, 3 )



      type = C
      channel = ANTLR3::DEFAULT_CHANNEL
    # - - - - label initialization - - - -


      # - - - - main rule block - - - -
      # at line 6:4: 'c'
      match( 0x63 )


      @state.type = type
      @state.channel = channel
    ensure
      # -> uncomment the next line to manually enable rule tracing
      # trace_out( __method__, 3 )


    end

    # main rule used to study the input at the current position,
    # and choose the proper lexer rule to call in order to
    # fetch the next token
    #
    # usually, you don't make direct calls to this method,
    # but instead use the next_token method, which will
    # build and emit the actual next token
    def token!
      # at line 1:8: ( A | B | C )
      alt_1 = 3
      case look_1 = @input.peek( 1 )
      when 0x61 then alt_1 = 1
      when 0x62 then alt_1 = 2
      when 0x63 then alt_1 = 3
      else
        raise NoViableAlternative( "", 1, 0 )

      end
      case alt_1
      when 1
        # at line 1:10: A
        a!


      when 2
        # at line 1:12: B
        b!


      when 3
        # at line 1:14: C
        c!


      end
    end

  end # class Lexer < ANTLR3::Lexer

  at_exit { Lexer.main( ARGV ) } if __FILE__ == $0

end
