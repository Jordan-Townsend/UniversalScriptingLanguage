grammar Probe;
options { language=Ruby; }
public start : A? B EOF;
A: 'a';
B: 'b';
C: 'c';
