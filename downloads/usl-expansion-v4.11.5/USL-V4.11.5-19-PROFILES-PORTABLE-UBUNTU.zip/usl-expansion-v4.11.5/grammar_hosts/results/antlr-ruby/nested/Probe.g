grammar Probe;
options { language=Ruby; }
public start : (A B | C A)* EOF;
A: 'a';
B: 'b';
C: 'c';
