grammar Probe;
options { language=Ruby; }
public start : (A B)+ C? EOF;
A: 'a';
B: 'b';
C: 'c';
