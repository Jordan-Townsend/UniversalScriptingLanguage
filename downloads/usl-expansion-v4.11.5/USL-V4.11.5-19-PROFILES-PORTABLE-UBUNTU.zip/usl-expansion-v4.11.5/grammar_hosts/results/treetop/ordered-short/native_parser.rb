module Probe
  include Treetop::Runtime

  def root
    @root ||= :start
  end

  module Start0
  end

  def _nt_start
    start_index = index
    if node_cache[:start].has_key?(index)
      cached = node_cache[:start][index]
      if cached
        node_cache[:start][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    i0, s0 = index, []
    i1 = index
    if (match_len = has_terminal?("a", false, index))
      r2 = true
      @index += match_len
    else
      terminal_parse_failure('"a"')
      r2 = nil
    end
    if r2
      r2 = SyntaxNode.new(input, (index-1)...index) if r2 == true
      r1 = r2
    else
      if (match_len = has_terminal?("ab", false, index))
        r3 = instantiate_node(SyntaxNode,input, index...(index + match_len))
        @index += match_len
      else
        terminal_parse_failure('"ab"')
        r3 = nil
      end
      if r3
        r3 = SyntaxNode.new(input, (index-1)...index) if r3 == true
        r1 = r3
      else
        @index = i1
        r1 = nil
      end
    end
    s0 << r1
    if r1
      if (match_len = has_terminal?("c", false, index))
        r4 = true
        @index += match_len
      else
        terminal_parse_failure('"c"')
        r4 = nil
      end
      s0 << r4
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Start0)
    else
      @index = i0
      r0 = nil
    end

    node_cache[:start][start_index] = r0

    r0
  end


  class Parser < Treetop::Runtime::CompiledParser
    include Probe
  end
end

(remove_const(:ProbeParser) if const_defined?(:ProbeParser)) rescue nil; ProbeParser = Probe::Parser

