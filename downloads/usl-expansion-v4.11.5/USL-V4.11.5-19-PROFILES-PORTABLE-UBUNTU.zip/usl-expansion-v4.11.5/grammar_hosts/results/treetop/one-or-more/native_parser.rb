module Probe
  include Treetop::Runtime

  def root
    @root ||= :start
  end

  def _nt_start
    start_index = index
    if node_cache[:start].has_key?(index)
      cached = node_cache[:start][index]
      if cached
        node_cache[:start][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    s0, i0 = [], index
    loop do
      if (match_len = has_terminal?("ab", false, index))
        r1 = instantiate_node(SyntaxNode,input, index...(index + match_len))
        @index += match_len
      else
        terminal_parse_failure('"ab"')
        r1 = nil
      end
      if r1
        s0 << r1
      else
        break
      end
    end
    if s0.empty?
      @index = i0
      r0 = nil
    else
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
    end

    node_cache[:start][start_index] = r0

    r0
  end


  class Parser < Treetop::Runtime::CompiledParser
    include Probe
  end
end

(remove_const(:ProbeParser) if const_defined?(:ProbeParser)) rescue nil; ProbeParser = Probe::Parser

