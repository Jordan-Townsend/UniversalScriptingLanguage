module Probe
  include Treetop::Runtime

  def root
    @root ||= :start
  end

  module Start0
  end

  def _nt_start
    start_index = index
    if node_cache[:start].has_key?(index)
      cached = node_cache[:start][index]
      if cached
        node_cache[:start][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    i0, s0 = index, []
    i1 = index
    if (match_len = has_terminal?("a", false, index))
      r2 = true
      @index += match_len
    else
      terminal_parse_failure('"a"')
      r2 = nil
    end
    if r2
      @index = i1
      r1 = instantiate_node(SyntaxNode,input, index...index)
    else
      @index = i1
      r1 = nil
    end
    s0 << r1
    if r1
      s3, i3 = [], index
      loop do
        i4 = index
        if (match_len = has_terminal?("a", false, index))
          r5 = true
          @index += match_len
        else
          terminal_parse_failure('"a"')
          r5 = nil
        end
        if r5
          r5 = SyntaxNode.new(input, (index-1)...index) if r5 == true
          r4 = r5
        else
          if (match_len = has_terminal?("b", false, index))
            r6 = true
            @index += match_len
          else
            terminal_parse_failure('"b"')
            r6 = nil
          end
          if r6
            r6 = SyntaxNode.new(input, (index-1)...index) if r6 == true
            r4 = r6
          else
            @index = i4
            r4 = nil
          end
        end
        if r4
          s3 << r4
        else
          break
        end
      end
      if s3.empty?
        @index = i3
        r3 = nil
      else
        r3 = instantiate_node(SyntaxNode,input, i3...index, s3)
      end
      s0 << r3
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Start0)
    else
      @index = i0
      r0 = nil
    end

    node_cache[:start][start_index] = r0

    r0
  end


  class Parser < Treetop::Runtime::CompiledParser
    include Probe
  end
end

(remove_const(:ProbeParser) if const_defined?(:ProbeParser)) rescue nil; ProbeParser = Probe::Parser

