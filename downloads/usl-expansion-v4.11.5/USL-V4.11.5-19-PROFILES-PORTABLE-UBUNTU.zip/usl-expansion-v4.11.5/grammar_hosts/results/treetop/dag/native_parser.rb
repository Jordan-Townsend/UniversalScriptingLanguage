module Probe
  include Treetop::Runtime

  def root
    @root ||= :start
  end

  module Start0
    def head
      elements[0]
    end

    def tail
      elements[1]
    end
  end

  def _nt_start
    start_index = index
    if node_cache[:start].has_key?(index)
      cached = node_cache[:start][index]
      if cached
        node_cache[:start][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    i0, s0 = index, []
    r1 = _nt_head
    s0 << r1
    if r1
      r2 = _nt_tail
      s0 << r2
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Start0)
    else
      @index = i0
      r0 = nil
    end

    node_cache[:start][start_index] = r0

    r0
  end

  def _nt_head
    start_index = index
    if node_cache[:head].has_key?(index)
      cached = node_cache[:head][index]
      if cached
        node_cache[:head][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    i0 = index
    if (match_len = has_terminal?("a", false, index))
      r1 = true
      @index += match_len
    else
      terminal_parse_failure('"a"')
      r1 = nil
    end
    if r1
      r1 = SyntaxNode.new(input, (index-1)...index) if r1 == true
      r0 = r1
    else
      if (match_len = has_terminal?("b", false, index))
        r2 = true
        @index += match_len
      else
        terminal_parse_failure('"b"')
        r2 = nil
      end
      if r2
        r2 = SyntaxNode.new(input, (index-1)...index) if r2 == true
        r0 = r2
      else
        @index = i0
        r0 = nil
      end
    end

    node_cache[:head][start_index] = r0

    r0
  end

  def _nt_tail
    start_index = index
    if node_cache[:tail].has_key?(index)
      cached = node_cache[:tail][index]
      if cached
        node_cache[:tail][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    s0, i0 = [], index
    loop do
      if (match_len = has_terminal?("b", false, index))
        r1 = true
        @index += match_len
      else
        terminal_parse_failure('"b"')
        r1 = nil
      end
      if r1
        s0 << r1
      else
        break
      end
    end
    r0 = instantiate_node(SyntaxNode,input, i0...index, s0)

    node_cache[:tail][start_index] = r0

    r0
  end


  class Parser < Treetop::Runtime::CompiledParser
    include Probe
  end
end

(remove_const(:ProbeParser) if const_defined?(:ProbeParser)) rescue nil; ProbeParser = Probe::Parser

