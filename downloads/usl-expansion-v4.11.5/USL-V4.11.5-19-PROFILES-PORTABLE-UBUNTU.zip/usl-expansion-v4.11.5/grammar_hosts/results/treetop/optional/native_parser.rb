module Probe
  include Treetop::Runtime

  def root
    @root ||= :start
  end

  module Start0
  end

  def _nt_start
    start_index = index
    if node_cache[:start].has_key?(index)
      cached = node_cache[:start][index]
      if cached
        node_cache[:start][index] = cached = SyntaxNode.new(input, index...(index + 1)) if cached == true
        @index = cached.interval.end
      end
      return cached
    end

    i0, s0 = index, []
    if (match_len = has_terminal?("a", false, index))
      r1 = true
      @index += match_len
    else
      terminal_parse_failure('"a"')
      r1 = nil
    end
    s0 << r1
    if r1
      if (match_len = has_terminal?("b", false, index))
        r3 = true
        @index += match_len
      else
        terminal_parse_failure('"b"')
        r3 = nil
      end
      if r3
        r2 = r3
      else
        r2 = instantiate_node(SyntaxNode,input, index...index)
      end
      s0 << r2
      if r2
        if (match_len = has_terminal?("c", false, index))
          r4 = true
          @index += match_len
        else
          terminal_parse_failure('"c"')
          r4 = nil
        end
        s0 << r4
      end
    end
    if s0.last
      r0 = instantiate_node(SyntaxNode,input, i0...index, s0)
      r0.extend(Start0)
    else
      @index = i0
      r0 = nil
    end

    node_cache[:start][start_index] = r0

    r0
  end


  class Parser < Treetop::Runtime::CompiledParser
    include Probe
  end
end

(remove_const(:ProbeParser) if const_defined?(:ProbeParser)) rescue nil; ProbeParser = Probe::Parser

