#!/usr/bin/env bash
# Execute inside the prepared Ubuntu26 container, with all native observations fresh.
set -euo pipefail
usl_addon_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$usl_addon_root"
source /workspace/.onboarding/activate-usl.sh
export PATH="/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:$PATH"
if [[ -x /workspace/.onboarding/ubuntu26-java21/bin/java ]]; then
    export PATH="/workspace/.onboarding/ubuntu26-java21/bin:$PATH"
fi
if [[ -d /workspace/.onboarding/ubuntu26-compat/usr/lib/x86_64-linux-gnu ]]; then
    export USL_COMPAT_LIBDIR=/workspace/.onboarding/ubuntu26-compat/usr/lib/x86_64-linux-gnu
    export LD_LIBRARY_PATH="$USL_COMPAT_LIBDIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi
python /workspace/usl-expansion-v4.11.4/ubuntu/platform_check.py
if [[ "${1:-check}" == check ]]; then
    exit 0
fi
exec "$@"
