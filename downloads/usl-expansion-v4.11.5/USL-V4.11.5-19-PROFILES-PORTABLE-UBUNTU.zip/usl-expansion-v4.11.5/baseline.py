"""Lossless historical status projection; this does not requalify old profiles."""
import hashlib
import json
from pathlib import Path

CATALOG = Path('/workspace/usl-planning-v4.11.2/current-scope-results/CURRENT_SCOPE.json')
CATALOG_SHA256 = '4208f6e4e365bac58a5474eb3314806a3e971fbc22df07191a9bc2e268adda8d'
PREVIOUS_MANIFEST_SHA256 = '95d3a332aa79bc34b2a33100d2541e1150aa79ac11564bce1427d5239b565da2'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, reason):
    if not value:
        raise ValueError(reason)


def derive(catalog, progress, prior_summary):
    originals = [dict(r) for r in catalog['records'] if r['original_catalog']]
    names = [r['catalog_id'] for r in originals]
    require(len(names) == 606 and len(set(names)) == 606, 'Original catalog lost or duplicated IDs')
    require(all(r['full_standard_qualified'] is False for r in originals), 'Unexpected historical full qualification')
    gaps = {r['catalog_id'] for r in originals if not r['validated_bounded_profile']}
    rows = progress['records']
    require(len(rows) == len(gaps) and {r['catalog_id'] for r in rows} == gaps,
            'Prior progress omitted, duplicated or substituted an original ID')
    mapped = {r['catalog_id']: r for r in rows}
    added = 0
    for row in originals:
        historical = mapped.get(row['catalog_id'])
        row['historical_profiles_requalified_now'] = False
        if historical is None:
            row['historical_evidence_release'] = '4.11.2-or-earlier'
            continue
        require(historical['full_standard_qualified'] is False, 'Prior progress promotes a full standard')
        require(type(historical['evidence_checked']) is bool, 'Invalid historical evidence flag')
        if historical['evidence_checked']:
            profile = historical['new_bounded_profile']
            require(profile['catalog_id'] == row['catalog_id'], 'Historical profile identity mismatch')
            require(profile['scoped_profile_validated'] is True and profile['full_standard_qualified'] is False,
                    'Invalid historical bounded-profile receipt')
            require(type(profile['exact_profile']) is str and profile['exact_profile'].strip(), 'Missing historical scope')
            require(bool(profile['open_obligations']), 'Historical obligations erased')
            row.update(validated_bounded_profile=True, qualified_profile_description=profile['exact_profile'],
                       historical_profile=profile, historical_evidence_release='4.11.4',
                       profile_receipt_sha256=historical['fresh_receipt_sha256'])
            added += 1
    covered = sum(r['validated_bounded_profile'] is True for r in originals)
    require(added == 30 and covered == 277 and prior_summary['bounded_original_profiles'] == covered
            and prior_summary['new_validated_bounded_profiles'] == added
            and prior_summary['original_IDs_without_bounded_profile'] == 606-covered,
            'Historical count claims disagree with individual records')
    return originals


def build(previous, output):
    previous = Path(previous)
    manifest_path = previous/'MANIFEST.json'
    require(sha(manifest_path) == PREVIOUS_MANIFEST_SHA256, 'Previous manifest differs from published v4.11.4 identity')
    require(sha(CATALOG) == CATALOG_SHA256, 'Catalog differs from retained v4.11.2 identity')
    manifest = json.loads(manifest_path.read_text())['files']
    for name in ['ALL359_PROGRESS.json', 'SUMMARY.json']:
        require(sha(previous/name) == manifest[name]['sha256'], 'Prior manifest mismatch: '+name)
    originals = derive(json.loads(CATALOG.read_text()),
                       json.loads((previous/'ALL359_PROGRESS.json').read_text()),
                       json.loads((previous/'SUMMARY.json').read_text()))
    data = {'schema':'usl.v4115.historical-baseline.v1',
            'catalog_scope_sha256':sha(CATALOG), 'previous_manifest_sha256':sha(manifest_path),
            'previous_progress_sha256':sha(previous/'ALL359_PROGRESS.json'),
            'previous_summary_sha256':sha(previous/'SUMMARY.json'),
            'summary':{'original_IDs':606,'validated_bounded_profiles':277,
                       'remaining_without_validated_profile':329,'full_standards_qualified':0,
                       'historical_profiles_requalified_now':False}, 'records':originals}
    Path(output).write_text(json.dumps(data, indent=2)+'\n')
    return data


if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--previous',type=Path,default=Path('/workspace/usl-expansion-v4.11.4'))
    p.add_argument('--output',type=Path,default=Path(__file__).parent/'BASELINE.json')
    a=p.parse_args();build(a.previous,a.output)
