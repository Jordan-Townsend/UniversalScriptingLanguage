import copy
import importlib
import os
from pathlib import Path
import sys
import unittest

from coordinator import validate_records, admission_counts


class CoordinatorReviewTests(unittest.TestCase):
    def test_cache_reclaim_admits_real_jobs_without_creating_resources(self):
        unit=256<<20
        result=admission_counts(11,12*unit,12*unit,7*unit,unit,unit,1024)
        self.assertEqual(result['native_family_slots'],5)
        self.assertEqual(result['clean_inactive_file_estimate_bytes'],5*unit)
        self.assertTrue(result['reclaim_is_not_guaranteed'])

    def test_memory_and_descriptor_limits_are_both_retained(self):
        unit=256<<20
        dirty=admission_counts(11,12*unit,12*unit,unit,unit,0,1024)
        descriptors=admission_counts(11,12*unit,0,0,0,0,24)
        self.assertEqual(dirty['native_family_slots'],1)
        self.assertEqual(descriptors['native_family_slots'],2)

    def fixture(self):
        return {'records':[{'catalog_id':'example','scoped_profile_validated':True,
            'full_standard_qualified':False,'exact_profile':'A registered finite profile',
            'cases':3,'native_executions':3,'usl_executions':3,
            'open_obligations':['Full semantic implementation remains open']}]}

    def test_raw_passed_flag_is_insufficient(self):
        with self.assertRaises(ValueError):
            validate_records({'records':[{'catalog_id':'example','passed':True}]},['example'])

    def test_catalog_omissions_and_substitutions_rejected(self):
        for names in [[],['different'],['example','other']]:
            with self.subTest(names=names),self.assertRaises(ValueError):
                validate_records(self.fixture(),names)
        document=self.fixture();document['records']*=2
        with self.assertRaises(ValueError):validate_records(document,['example'])

    def test_counts_require_exact_positive_integers(self):
        for field in ['cases','native_executions','usl_executions']:
            for bad in [True,False,0,-1,1.0,'3',None]:
                document=self.fixture();document['records'][0][field]=bad
                with self.subTest(field=field,bad=bad),self.assertRaises(ValueError):
                    validate_records(document,['example'])

    def test_full_standard_and_erased_obligations_rejected(self):
        for field,bad in [('full_standard_qualified',True),('full_standard_qualified',0),
                          ('open_obligations',[]),('open_obligations',None),('exact_profile','')]:
            document=self.fixture();document['records'][0][field]=bad
            with self.subTest(field=field,bad=bad),self.assertRaises(ValueError):
                validate_records(document,['example'])

    def test_actual_USL_policy_preserves_all329_counts(self):
        source=Path(os.environ.get('USL_SOURCE_ROOT','/workspace/usl-v4.10.0-clean-test')).resolve()
        sys.path.insert(0,str(source));runtime=importlib.import_module('usl_systems.language')
        interpreter=runtime.Interpreter()
        interpreter.env.update(rows=[{'evidence_checked':i<20} for i in range(329)],
                               historical_bounded=277,original_total=606,initial_remaining=329)
        values=interpreter.run((Path(__file__).parent/'coordinator.usl').read_text()).variables
        self.assertEqual((values['added'],values['bounded_originals'],values['remaining_originals'],values['full_standards_qualified']),(20,297,309,0))


if __name__=='__main__':unittest.main()
