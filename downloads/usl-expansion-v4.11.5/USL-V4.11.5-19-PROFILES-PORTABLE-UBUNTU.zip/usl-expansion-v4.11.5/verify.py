"""Verify the source package, root regressions and fresh all329 family join."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(previous,source_root,output):
    started=time.perf_counter();output=Path(output).resolve()
    if any(output.is_relative_to(root) or root.is_relative_to(output) for root in [ROOT.resolve(),Path(previous).resolve(),Path(source_root).resolve()]):raise ValueError('Fresh output must not overlap source, baseline or runtime')
    if output.exists() and any(p.is_symlink() for p in output.rglob('*')):raise ValueError('Fresh output cannot contain symlink paths')
    output.mkdir(parents=True,exist_ok=True)
    package=ROOT/'MANIFEST.json';files={}
    if package.exists():
        files=json.loads(package.read_text())['files']
        for name,identity in files.items():
            path=(ROOT/name).resolve()
            if not path.is_relative_to(ROOT) or not path.is_file() or sha(path)!=identity['sha256']:raise ValueError('Source package integrity mismatch: '+name)
    env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env['USL_SOURCE_ROOT']=str(Path(source_root).resolve())
    def command(name,args,timeout):
        path=output/(name+'.log')
        with path.open('w') as stream:
            result=subprocess.run([sys.executable]+args,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
        if result.returncode:raise ValueError(name+' failed; see '+str(path))
        return {'passed':True,'log_sha256':sha(path)}
    root_tests=command('root-regressions',['-m','unittest','discover','-v'],60)
    match=re.search(r'Ran (\d+) tests?',(output/'root-regressions.log').read_text())
    if not match or int(match[1])<5:raise ValueError('Root regressions did not complete')
    root_tests['tests_run']=int(match[1])
    # The coordinator owns an asyncio deadline so it can cancel/reap every
    # separately isolated native family group before its process exits.
    join=command('all329-fresh',['coordinator.py','--previous',str(previous),'--source-root',str(source_root),'--output',str(output/'fresh'),'--timeout-seconds','240'],None)
    summary=json.loads((output/'fresh/SUMMARY.json').read_text())
    if not summary['passed'] or summary['full_standards_qualified']!=0:raise ValueError('Joined qualification state invalid')
    if any(sha(ROOT/name)!=identity['sha256'] for name,identity in files.items()):raise ValueError('Package changed during verification')
    result={'passed':True,'root_regressions':root_tests,'fresh_join':join,'source_manifest_files_checked':len(files),
            'summary':summary,'source_unchanged_during_verification':True,'seconds':time.perf_counter()-started,
            'cost_excludes':['Writing this final verification record','Console reporting and process shutdown'],
            'new_task_or_other_OS_restoration_verified':False}
    (output/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result));return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--previous',type=Path,default=Path('/workspace/usl-expansion-v4.11.4'))
    p.add_argument('--source-root',type=Path,default=Path('/workspace/usl-v4.10.0-clean-test'));p.add_argument('--output',type=Path,default=Path('/tmp/usl-v4115-readiness'))
    a=p.parse_args();verify(a.previous,a.source_root,a.output)
