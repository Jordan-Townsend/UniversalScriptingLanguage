"""Meaningful failure cases for catalog integrity, dependency and resource math."""
import copy
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent
if not any(Path(p, 'usl_systems').is_dir() for p in sys.path):
    sys.path.insert(0, '/workspace/usl-v4.10.0-clean-test')
from planner import (build_graph, capacity_calculation, conditional_schedule,
                     evaluate_graph, order_nodes, validate_catalog)


class PlanningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.catalog = json.loads((ROOT / 'inputs/catalog.json').read_text())
        cls.rows = validate_catalog(cls.catalog)
        cls.assumptions = json.loads((ROOT / 'assumptions.json').read_text())

    def test_every_original_retains_all_steps(self):
        graph = build_graph(self.rows, self.assumptions, 'full_pinned_profiles', 'reference')
        originals = [n for n in graph if not n['id'].startswith(('shared:', 'family:'))]
        self.assertEqual(len(originals), 9090)
        self.assertEqual(len({n['id'].split(':')[0] for n in originals}), 606)
        self.assertEqual(sum(len(r['obligation_dimensions']) for r in self.rows), 10908)

    def test_no_scope_is_mistaken_for_full_completion(self):
        full = build_graph(self.rows, self.assumptions, 'full_pinned_profiles', 'lean')
        bounded = build_graph(self.rows, self.assumptions, 'remaining_scoped_profiles', 'lean')
        self.assertEqual(sum(n['id'].endswith(':bounded-profile') for n in bounded), 363)
        for row in self.rows:
            if row['scoped']:
                self.assertTrue(any(n['id'] == row['catalog_id'] + ':profile_conformance' for n in full))

    def test_shared_family_is_counted_once_without_dropping_ID_work(self):
        row = self.rows[0]
        twin = {**copy.deepcopy(row), 'catalog_id': 'independent-dialect'}
        one = build_graph([row], self.assumptions, 'full_pinned_profiles', 'reference')
        two = build_graph([row, twin], self.assumptions, 'full_pinned_profiles', 'reference')
        self.assertEqual(sum(n['id'] == 'family:' + row['family'] for n in two), 1)
        self.assertEqual(len(two) - len(one), 15)
        tail = sum(n['hours'] for n in one if n['id'].startswith(row['catalog_id'] + ':'))
        self.assertAlmostEqual(sum(n['hours'] for n in two) - sum(n['hours'] for n in one), tail)

    def test_cycle_and_missing_prerequisite_are_rejected(self):
        for nodes in [[{'id': 'a', 'parents': ['b'], 'hours': 1}],
                      [{'id': 'a', 'parents': ['b'], 'hours': 1}, {'id': 'b', 'parents': ['a'], 'hours': 1}]]:
            with self.assertRaises(ValueError):
                order_nodes(nodes)

    def test_duplicate_and_nonfinite_work_are_rejected(self):
        for nodes in [[{'id': 'a', 'parents': [], 'hours': float('nan')}],
                      [{'id': 'a', 'parents': [], 'hours': 1}] * 2]:
            with self.assertRaises(ValueError):
                order_nodes(nodes)

    def test_parallel_workers_do_not_remove_critical_path(self):
        graph = [{'id': 'a', 'parents': [], 'hours': 40}, {'id': 'b', 'parents': ['a'], 'hours': 60}]
        answer, receipt = evaluate_graph(graph, 10000, 25)
        self.assertEqual(answer['engineering_hours'], 100)
        self.assertEqual(answer['idealized_lower_bound_weeks'], 4)
        self.assertIsNone(answer['committed_completion_weeks'])
        self.assertTrue(receipt['actual_USL_execution'])
        self.assertEqual(conditional_schedule(graph, 100, 25)['conditional_weeks'], 4)

    def test_schedule_really_overlaps_independent_work(self):
        graph = [{'id': 'a', 'parents': [], 'hours': 32}, {'id': 'b', 'parents': [], 'hours': 32},
                 {'id': 'c', 'parents': ['a', 'b'], 'hours': 32}]
        self.assertEqual(conditional_schedule(graph, 1, 32)['conditional_weeks'], 3)
        self.assertEqual(conditional_schedule(graph, 2, 32)['conditional_weeks'], 2)
        self.assertEqual(conditional_schedule(graph, 100, 32)['conditional_weeks'], 2)

    def resource_inputs(self):
        return {'local_cpu_equivalents': 4, 'logical_tasks': 10926, 'registered_pools': [],
                'overhead_per_useful_cpu_second': .2, 'recoverable_overhead_fraction': .5,
                'parallel_fraction': .6, 'parallel_part_speedup': 5}

    def test_virtual_workers_and_overhead_do_not_create_CPUs(self):
        base = self.resource_inputs()
        first = capacity_calculation(base)['calculated']
        second = capacity_calculation({**base, 'logical_tasks': 1_000_000})['calculated']
        self.assertEqual(first, second)
        self.assertEqual(first['qualified_cpu_equivalents'], 4)
        self.assertAlmostEqual(first['overhead_speedup'], 1.2 / 1.1)
        self.assertAlmostEqual(first['amdahl_speedup'], 1 / .52)

    def test_only_authorized_qualified_compatible_pools_count(self):
        base = self.resource_inputs()
        pools = [{'cpu_equivalents': 100, 'authorized': True, 'qualified': False, 'compatible': True},
                 {'cpu_equivalents': 100, 'authorized': False, 'qualified': True, 'compatible': True},
                 {'cpu_equivalents': 100, 'authorized': True, 'qualified': True, 'compatible': False},
                 {'cpu_equivalents': 8, 'authorized': True, 'qualified': True, 'compatible': True}]
        answer = capacity_calculation({**base, 'registered_pools': pools})['calculated']
        self.assertEqual(answer['qualified_cpu_equivalents'], 12)
        self.assertEqual(answer['accepted_pools'], 1)

    def test_invalid_assumptions_rejected(self):
        for overrides in [{'parallel_fraction': 1.1}, {'parallel_part_speedup': .1},
                          {'recoverable_overhead_fraction': -1}, {'logical_tasks': float('inf')}]:
            with self.assertRaises(ValueError):
                capacity_calculation({**self.resource_inputs(), **overrides})

    def test_external_dependencies_and_entity_unknowns_preserved(self):
        self.assertEqual(len([r for r in self.rows if r['external_dependencies']]), 9)
        tracks = json.loads((ROOT / 'inputs/entity_tracks.json').read_text())
        self.assertEqual(len(tracks), 21)
        self.assertTrue(all(t['next_action'] and t['status'] == 'pending' for t in tracks.values()))


if __name__ == '__main__':
    unittest.main()
