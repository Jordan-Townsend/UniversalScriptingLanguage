"""Conditional budget model. No invented implementation-rate observations."""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import heapq
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def finite(value, label, minimum=0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < minimum:
        raise ValueError(f"{label} must be finite and >= {minimum}")
    return value


def validate_catalog(document):
    rows = document["entries"]
    ids = [r["catalog_id"] for r in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate catalog ID")
    originals = [r for r in rows if r["original_catalog"]]
    if len(originals) != 606 or len(rows) != 607:
        raise ValueError("Expected 606 originals plus USL")
    if sum(r["scoped"] for r in originals) != document['summary']['original_scoped']:
        raise ValueError("Scope summary disagrees with per-ID evidence")
    for row in originals:
        names = [s["step"] for s in row["ordered_steps"]]
        if len(names) != 15 or len(set(names)) != 15:
            raise ValueError("Expected 15 distinct prerequisite steps per ID")
        if row["full_standard_qualified"]:
            raise ValueError("This snapshot has no full-standard qualifications")
        order_nodes([{"id": s["step"], "parents": s["prerequisites"], "hours": 0} for s in row["ordered_steps"]])
    return originals


def apply_scoped_receipt(document, path):
    """Overlay an exact scoped frontend without altering the published base."""
    receipt = json.loads(Path(path).read_text())
    if (receipt.get('catalog_id') != 'brainfuck' or not receipt.get('passed')
            or receipt.get('source_sha256') != sha(ROOT / 'brainfuck_semantics.py')
            or receipt.get('full_standard_qualified') is not False
            or not receipt.get('source_unchanged_during_run')
            or len(receipt.get('records', [])) != 426
            or not all(r['passed'] for r in receipt['records'])):
        raise ValueError('Invalid or stale scoped receipt')
    from brainfuck_semantics import intent_cases
    cases = {case['name']: case for case in intent_cases()}
    if set(cases) != {r['name'] for r in receipt['records']}:
        raise ValueError('Missing or duplicated independent intent cases')
    for record in receipt['records']:
        case = cases[record['name']]
        if record['source'] != case['source'] or record['input_hex'] != case['input'].hex() or record['eof'] != case['eof'] or record['expected_hex'] != case['expected'].hex():
            raise ValueError('Independent intent contract identity changed')
        if not (record['expected_hex'] == record['generated_USL_output_hex'] == record['reference_output_hex']) or not record['native_observations']:
            raise ValueError('Incomplete intent/native evidence')
        if any(r['output_hex'] != record['expected_hex'] for r in record['native_observations']):
            raise ValueError('Native counterexample in scoped receipt')
    row = next(r for r in document['entries'] if r['catalog_id'] == 'brainfuck')
    row.update(scoped=True, profile_kind='code_expression', scope=receipt['scope'],
               scoped_receipt_sha256=sha(path), full_standard_qualified=False)
    originals = [r for r in document['entries'] if r['original_catalog']]
    previous = document['summary']['original_scoped']
    count = sum(r['scoped'] for r in originals)
    document['summary'].update(original_scoped=count, original_without_scope=606-count,
                               code_expression_profiles=document['summary']['code_expression_profiles'] + count-previous)
    return document


def order_nodes(nodes):
    """Validate DAG and deterministically topologically order it."""
    indexed = {n["id"]: n for n in nodes}
    if len(indexed) != len(nodes):
        raise ValueError("Duplicate work node")
    children = collections.defaultdict(list)
    indegree = {}
    for node in nodes:
        finite(node["hours"], "node hours")
        if len(node["parents"]) != len(set(node["parents"])):
            raise ValueError("Duplicate dependency")
        indegree[node["id"]] = len(node["parents"])
        for parent in node["parents"]:
            if parent not in indexed:
                raise ValueError("Missing prerequisite: " + parent)
            children[parent].append(node["id"])
    ready = [key for key, count in indegree.items() if count == 0]
    heapq.heapify(ready)
    ordered = []
    while ready:
        key = heapq.heappop(ready)
        ordered.append(indexed[key])
        for child in children[key]:
            indegree[child] -= 1
            if indegree[child] == 0:
                heapq.heappush(ready, child)
    if len(ordered) != len(nodes):
        raise ValueError("Cyclic work prerequisites")
    return ordered


def run_usl(name, inputs, capabilities=None):
    from usl_systems.language import Interpreter
    source = ROOT / name
    result = Interpreter(capabilities={"planning_inputs" if name == "estimate.usl" else "capacity_inputs": lambda: inputs, **(capabilities or {})},
                         max_ops=3_000_000, timeout=20).run(source.read_text())
    return result.variables["result"], {"source": name, "sha256": sha(source), "actual_USL_execution": True,
                                         "operations": result.operations, "elapsed_ms": result.elapsed_ms}


def evaluate_graph(nodes, capacity, productive_hours):
    finite(capacity, "engineering capacity", 1e-9)
    finite(productive_hours, "productive hours", 1e-9)
    ordered = order_nodes(nodes)
    observed = {}

    def remember(key, value):
        if key in observed:
            raise ValueError("Repeated USL work-node result")
        observed[key] = value

    result, receipt = run_usl("estimate.usl", {"nodes": ordered, "effective_engineering_capacity": capacity,
                           "productive_hours_per_week": productive_hours}, {"read_finish": lambda key: observed[key], "remember_finish": remember})
    # Separate implementation of all arithmetic, including every node finish.
    expected = {}
    for node in ordered:
        expected[node["id"]] = node["hours"] + max((expected[p] for p in node["parents"]), default=0)
    work = math.fsum(n["hours"] for n in ordered)
    critical = max(expected.values(), default=0)
    for key, value in expected.items():
        if not math.isclose(observed[key], value, rel_tol=1e-10, abs_tol=1e-8):
            raise ValueError("USL critical path disagreement")
    checks = {"engineering_hours": work, "critical_path_hours": critical,
              "idealized_lower_bound_weeks": max(critical, work / capacity) / productive_hours}
    for key, value in checks.items():
        if not math.isclose(result[key], value, rel_tol=1e-10, abs_tol=1e-8):
            raise ValueError("USL arithmetic disagreement: " + key)
    return result, receipt


def conditional_schedule(nodes, team, hours_per_week):
    """Feasible list schedule under explicit homogeneous, no-wait assumptions.

    These are engineering-equivalent lanes, not CPU cores or virtual agents.
    A non-preemptive node occupies one lane; critical-path tasks remain serial.
    """
    if type(team) is not int or team < 1:
        raise ValueError("Team lanes must be positive integers")
    finite(hours_per_week, "productive hours", 1e-9)
    ordered = order_nodes(nodes)
    by_id = {n["id"]: n for n in ordered}
    children = collections.defaultdict(list)
    pending = {n["id"]: len(n["parents"]) for n in ordered}
    for node in ordered:
        for parent in node["parents"]:
            children[parent].append(node["id"])
    tail = {}
    for node in reversed(ordered):
        tail[node["id"]] = node["hours"] + max((tail[c] for c in children[node["id"]]), default=0)
    ready = [(-tail[key], key) for key, count in pending.items() if count == 0]
    heapq.heapify(ready)
    active = []
    available = list(range(team))
    heapq.heapify(available)
    now = 0
    records = {}
    while ready or active:
        while ready and available:
            _, key = heapq.heappop(ready)
            lane = heapq.heappop(available)
            end = now + by_id[key]["hours"]
            records[key] = {"start": now, "end": end, "lane": lane}
            heapq.heappush(active, (end, key, lane))
        now = active[0][0]
        while active and active[0][0] == now:
            _, key, lane = heapq.heappop(active)
            heapq.heappush(available, lane)
            for child in children[key]:
                pending[child] -= 1
                if pending[child] == 0:
                    heapq.heappush(ready, (-tail[child], child))
    # Validate the proposed schedule against prerequisites and lane overlaps.
    for node in ordered:
        r = records[node["id"]]
        if any(records[p]["end"] > r["start"] + 1e-8 for p in node["parents"]):
            raise ValueError("Schedule violates prerequisite")
    for lane in range(team):
        items = sorted((r for r in records.values() if r["lane"] == lane), key=lambda r: (r["start"], r["end"]))
        if any(a["end"] > b["start"] + 1e-8 for a, b in zip(items, items[1:])):
            raise ValueError("Schedule overbooks lane")
    return {"team_equivalent_lanes": team, "conditional_weeks": now / hours_per_week,
            "conditional_years": now / hours_per_week / 52, "schedule_nodes_checked": len(records),
            "host_waits_included": False, "empirical_forecast": False}


def planning_class(family, assumptions):
    if family not in assumptions["families"]:
        raise ValueError("Unclassified family: " + family)
    return assumptions["families"][family]


def build_graph(rows, assumptions, milestone, case):
    chosen = rows if milestone == "full_pinned_profiles" else [r for r in rows if not r["scoped"]]
    shared = assumptions['shared_IR_work']
    total_weight = sum(item['weight'] for item in shared)
    finite(total_weight, 'shared IR weight sum', 1e-9)
    nodes = [{"id": 'shared:' + item['id'], "parents": ['shared:' + p for p in item['parents']],
              "hours": assumptions["budgets"][milestone]["shared_ir_hours"][case] * item['weight'] / total_weight}
             for item in shared]
    nodes.append({'id': 'shared:USL-IR-and-validation', 'parents': ['shared:integration'], 'hours': 0})
    families = sorted({r["family"] for r in chosen})
    for family in families:
        category = planning_class(family, assumptions)
        budget = assumptions["budgets"][milestone][category]["family_core_hours"][case]
        nodes += [
            {'id': 'family:' + family + ':audit', 'parents': [], 'hours': budget * .2},
            {'id': 'family:' + family + ':implementation', 'parents': ['family:' + family + ':audit', 'shared:typed_values'], 'hours': budget * .5},
            {'id': 'family:' + family, 'parents': ['family:' + family + ':implementation', 'shared:USL-IR-and-validation'], 'hours': budget * .3},
        ]
    for row in chosen:
        category = planning_class(row["family"], assumptions)
        allocation = assumptions["budgets"][milestone][category]["per_ID_tail_hours"][case]
        if milestone == "remaining_scoped_profiles":
            nodes.append({"id": row["catalog_id"] + ":bounded-profile", "parents": ["family:" + row["family"]], "hours": allocation})
        else:
            weights = assumptions["full_step_weights"]
            if set(weights) != {s["step"] for s in row["ordered_steps"]}:
                raise ValueError("Step weight coverage is incomplete")
            total = sum(weights.values())
            finite(total, "step weight sum", 1e-9)
            for step in row["ordered_steps"]:
                finite(weights[step["step"]], "step weight")
                parents = [row["catalog_id"] + ":" + p for p in step["prerequisites"]]
                # Research/native work need not wait for an entire IR/family build.
                if step['step'] == 'specification_audit':
                    parents.append('family:' + row['family'] + ':audit')
                if step['step'] == 'grammar_frontend':
                    parents.append('family:' + row['family'] + ':implementation')
                if step['step'] == 'native_backend':
                    parents.append('shared:native_runner')
                if step['step'] == 'typed_ir_lowering':
                    parents.append('family:' + row['family'])
                nodes.append({"id": row["catalog_id"] + ":" + step["step"], "parents": parents,
                              "hours": allocation * weights[step["step"]] / total})
    return order_nodes(nodes)


def capacity_calculation(inputs):
    for key in ("local_cpu_equivalents", "logical_tasks", "overhead_per_useful_cpu_second", "recoverable_overhead_fraction", "parallel_fraction", "parallel_part_speedup"):
        finite(inputs[key], key)
    if inputs["local_cpu_equivalents"] <= 0 or inputs["parallel_part_speedup"] < 1 or not 0 <= inputs["parallel_fraction"] <= 1 or not 0 <= inputs["recoverable_overhead_fraction"] <= 1:
        raise ValueError("Invalid capacity assumption")
    for pool in inputs["registered_pools"]:
        finite(pool["cpu_equivalents"], "pool CPU")
        if any(type(pool[k]) is not bool for k in ("authorized", "qualified", "compatible")):
            raise ValueError("Pool registration gates must be explicit booleans")
    answer, receipt = run_usl("capacity.usl", inputs)
    cores = inputs["local_cpu_equivalents"] + sum(p["cpu_equivalents"] for p in inputs["registered_pools"] if p["authorized"] and p["qualified"] and p["compatible"])
    expected = {"qualified_cpu_equivalents": cores, "active_cpu_equivalents": min(cores, inputs["logical_tasks"]),
                "accepted_pools": sum(p["authorized"] and p["qualified"] and p["compatible"] for p in inputs["registered_pools"]),
                "overhead_speedup": (1 + inputs["overhead_per_useful_cpu_second"]) / (1 + inputs["overhead_per_useful_cpu_second"] * (1 - inputs["recoverable_overhead_fraction"])),
                "amdahl_speedup": 1 / (1 - inputs["parallel_fraction"] + inputs["parallel_fraction"] / inputs["parallel_part_speedup"]),
                "virtualization_creates_capacity": False}
    if any(not math.isclose(answer[k], v, rel_tol=1e-12) for k, v in expected.items()):
        raise ValueError("USL resource arithmetic disagreement")
    return {"inputs": inputs, "calculated": answer, "USL_receipt": receipt}


def render_report(report, path):
    lines = ["# Conditional USL project schedule", "", "This is an editable budget model, not an empirically calibrated completion forecast.", "",
             f"The snapshot has **{report['snapshot']['original_scoped']}/606 scoped IDs**, **{report['snapshot']['original_without_scope']} without a scoped profile**, **0 full standards**, and **0/21 completed entity tracks**. Existing scopes do not close whole-language obligations.", "",
             "All 606 IDs have 15 generic prerequisite steps and 18 obligation dimensions. Exact version/dialect/library audits remain open; these templates are not completed normative audits.", "",
             "## Conditional engineering budgets", "", "Assumed 32 productive hours per lane per week. A lane is effective engineering capacity, not a virtual worker, CPU, or promise of autonomous work. Numbers below are hypothetical list schedules, with no host/license waits or newly discovered requirements. Cases are workload stress tests; none is a probability interval or asserted best/worst bound.", "",
             "| Milestone | Budget case | Engineering hours | 1 lane | 20 lanes | 100 lanes |", "|---|---|---:|---:|---:|---:|"]
    for entry in report["scenarios"]:
        schedules = {r["team_equivalent_lanes"]: r for r in entry["schedules"]}
        def duration(team):
            weeks = schedules[team]["conditional_weeks"]
            return f"{weeks:.0f} weeks" if weeks < 104 else f"{weeks/52:.1f} years"
        lines.append(f"| {entry['milestone']} | {entry['budget_case']} | {entry['USL']['engineering_hours']:,.0f} | {duration(1)} | {duration(20)} | {duration(100)} |")
    lines += ["", "A full-profile budget includes the remaining whole-standard work for every original ID, including IDs with bounded scopes. Do not add the scoped milestone to that budget. Formats, logs and templates need their category-specific processing contract; many are not executable programming languages.", "",
              "Shared family-core work is budgeted once. Per-ID semantics, independent tests and qualification remain separate. The proposed family reuse and hour allocations are assumptions, not proven compatible semantic artifacts or measured velocity.", "",
              "## Why no committed full-project finish date", "", "Full pinned-version language support has no measured completion rate yet. Nine IDs carry external host/license records; applicability still needs audit. The complete entity objective also has unbounded research/acceptance questions and unprovided devices/models. All 21 track next actions and dependencies remain in ENTITY_TRACKS.json. External waits and entity effort are unknown, not zero.", "",
              "Universal termination/equivalence proofs for arbitrary programs cannot be guaranteed. Intent proof requires a formal contract and a supported proof domain; other cases must report unknown. Human-equivalent abilities and open-ended future learning do not currently define a finite, testable finish gate. These limitations keep the original whole-project ETA null.", "",
              "## Partial workers and resource recovery", "", "All 10,926 ID/dimension actors may be live concurrently, while physical jobs use measured resource admission. The existing qualification run coalesced 60 ID checks into 32 process jobs, preserved every ID's fresh checks, and built 414 exact pure artifacts for 10,926 logical requests. These figures do not measure compiler engineering productivity.", "",
              "Overhead recovery: speedup = (1 + overhead/useful_work) / (1 + remaining_overhead/useful_work). Recovering half of 20% overhead gives 1.091×, not extra hardware. A hypothetical 5× speedup for 60% of engineering work gives 1.923× overall under Amdahl. Future skills and hosts receive no guaranteed credit before measurement.", "",
              "Hardware discovery is read-only for this run. Registered remote capacity is counted only with explicit authorization, compatible workload support, and qualification evidence. There is no automatic network scan, paid allocation, or assumption that interacting with a device grants access to its resources.", "",
              "## Fastest evidence-based route", "", "1. Pin each ID's specification/version/category and convert the 15 template steps into actual chapter/feature/library obligations. Start license/platform requests alongside independent implementation work.", "2. Maintain all logical workers, share exact pure artifacts by complete identity, and admit native jobs using live CPU/memory/I/O measurements. Never merge distinct program effects or replay execution evidence.", "3. Build the shared IR and compatible family cores once, then implement per-ID deviations, native hosts, libraries, interop and independently authored intent contracts.", "4. Qualify bounded profiles while full conformance remains open. Record active engineering hours, integration/review/rework and feature throughput for representative complex and simple IDs.", "5. Replace every assumed hour budget with those observations. Compare sequential, parallel and collapsed routes end to end; promote improvements only after heldout correctness and cost checks. Report a calibrated forecast only when the audited scope and observed rate support it.", "",
              "## Run", "", "```bash", "source /workspace/.onboarding/activate-usl.sh", "python planner.py --source-root /workspace/usl-v4.10.0-clean-test --scoped-receipt semantic-final/brainfuck/qualification.json --output results", "python -m unittest -v test_planner test_semantics", "```", "",
              "Elsewhere, supply the extracted v4.10 runtime with its dependencies installed. No native compilation is repeated or claimed by this planning addon. See assumptions.json, FAMILY_PLAN.csv, ALL_606_STEPS.json, capacity.json and results.json. The original snapshot files' SHA-256 identities are retained in inputs/provenance.json.", ""]
    path.write_text("\n".join(lines))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--assumptions", type=Path, default=ROOT / "assumptions.json")
    parser.add_argument("--output", type=Path, default=Path("results"))
    parser.add_argument('--scoped-receipt', type=Path)
    args = parser.parse_args(argv)
    sys.path.insert(0, str(args.source_root.resolve()))
    started = time.perf_counter()
    document = json.loads((ROOT / "inputs/catalog.json").read_text())
    if args.scoped_receipt:
        document = apply_scoped_receipt(document, args.scoped_receipt)
    rows = validate_catalog(document)
    assumptions = json.loads(args.assumptions.read_text())
    args.output.mkdir(parents=True, exist_ok=True)
    scenarios = []
    for milestone in ("remaining_scoped_profiles", "full_pinned_profiles"):
        for case in assumptions["cases"]:
            graph = build_graph(rows, assumptions, milestone, case)
            answer, receipt = evaluate_graph(graph, 20, assumptions["productive_hours_per_week"])
            scenarios.append({"milestone": milestone, "budget_case": case, "node_count": len(graph), "USL": answer,
                              "USL_receipt": receipt, "schedules": [conditional_schedule(graph, n, assumptions["productive_hours_per_week"]) for n in assumptions["engineering_lanes"]]})
    families = []
    for family in sorted({r["family"] for r in rows}):
        items = [r for r in rows if r["family"] == family]
        kind = planning_class(family, assumptions)
        budgets = {}
        for milestone in ("remaining_scoped_profiles", "full_pinned_profiles"):
            count = sum(not r["scoped"] for r in items) if milestone == "remaining_scoped_profiles" else len(items)
            config = assumptions["budgets"][milestone][kind]
            budgets[milestone] = 0 if count == 0 else config["family_core_hours"]["reference"] + count * config["per_ID_tail_hours"]["reference"]
        families.append({"family": family, "planning_class": kind, "original_IDs": len(items), "scoped": sum(r["scoped"] for r in items),
                         "without_scope": sum(not r["scoped"] for r in items), "normative_audits_complete": 0, "full_qualified": 0,
                         "reference_scoped_budget_hours": budgets["remaining_scoped_profiles"], "reference_full_budget_hours": budgets["full_pinned_profiles"]})
    with (args.output / "FAMILY_PLAN.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(families[0]));writer.writeheader();writer.writerows(families)
    dump(args.output / "FAMILY_PLAN.json", families)
    # Every ID and prerequisite is retained; full semantics are not collapsed merely by family.
    dump(args.output / "ALL_606_STEPS.json", {"originals": rows, "steps": 9090, "dimensions": 10908, "audit_complete": False})
    tracks = json.loads((ROOT / "inputs/entity_tracks.json").read_text())
    dump(args.output / "ENTITY_TRACKS.json", tracks)
    from usl_systems.resources import discover
    hardware = discover()
    actual = {"local_cpu_equivalents": hardware["cpu_effective"], "logical_tasks": 10926,
              "registered_pools": [], "overhead_per_useful_cpu_second": 0, "recoverable_overhead_fraction": 0,
              "parallel_fraction": 0, "parallel_part_speedup": 1}
    capacity = {"live_hardware": hardware, "current_observation": capacity_calculation(actual), "illustrative_sensitivity_only": []}
    for tasks, pools in [(10926, []), (1_000_000, []), (10926, [{"id": "hypothetical-not-provisioned", "cpu_equivalents": 4, "authorized": False, "qualified": False, "compatible": True}])]:
        capacity["illustrative_sensitivity_only"].append(capacity_calculation({**actual, "logical_tasks": tasks, "registered_pools": pools,
                                        "overhead_per_useful_cpu_second": 0.2, "recoverable_overhead_fraction": 0.5,
                                        "parallel_fraction": 0.6, "parallel_part_speedup": 5}))
    dump(args.output / "capacity.json", capacity)
    report = {"schema": "usl.conditional-effort-model.v1", "snapshot": document["summary"], "assumptions_sha256": sha(args.assumptions),
              'scoped_receipt_sha256': sha(args.scoped_receipt) if args.scoped_receipt else None,
              "scenarios": scenarios, "families": families, "entity_tracks": len(tracks), "entity_effort_hours": None,
              "external_dependency_IDs": [r["catalog_id"] for r in rows if r["external_dependencies"]],
              "external_wait_weeks": None, "full_project_ETA_weeks": None, "empirical_full_profile_completion_rate": None,
              "no_future_acceleration_credited": True, "end_to_end_planner_seconds": time.perf_counter() - started,
              "validation_runtime_is_not_engineering_velocity": True}
    dump(args.output / "results.json", report)
    render_report(report, args.output / "REPORT.md")
    print(json.dumps({"passed": True, "original_IDs_planned": 606, "full_steps_preserved": 9090, "scenarios": len(scenarios),
                      "full_project_ETA_weeks": None, "seconds": report["end_to_end_planner_seconds"]}))


if __name__ == "__main__":
    main()
