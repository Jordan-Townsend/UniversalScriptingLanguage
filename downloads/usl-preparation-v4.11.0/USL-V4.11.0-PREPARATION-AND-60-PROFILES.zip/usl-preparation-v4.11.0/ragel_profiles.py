"""Ragel6 literal-word recognizers, with actual generated target execution.

The ragel-em (embedded-machine lexer category) contract uses a C carrier;
it is not represented as an independent language/runtime.
"""
from pathlib import Path
import copy,hashlib,itertools,json,re,shutil,tempfile
from usl_systems.bounded_process import execute
from usl_systems.language import Interpreter,parse
from usl_systems.semantic_documents import typed

HOSTS={'ragel':('C','gcc','c'),'ragel-c':('C','gcc','c'),'ragel-cpp':('C','g++','cpp'),
 'ragel-objc':('C','objc-gcc','m'),'ragel-em':('C','gcc','c'),'ragel-d':('D','gdc','d'),
 'ragel-java':('J','javac','java'),'ragel-ruby':('R','ruby','rb')}
LANGUAGES=set(HOSTS)
def source_for(word):
 if type(word) is not str or not re.fullmatch('[abc]{1,5}',word):raise ValueError('Canonical nonempty literal word required')
 return "%%{ machine item; main := '"+word+"'; }%%"
def admit(source):
 m=re.fullmatch(r"%%\{ machine item; main := '([abc]{1,5})'; }%%",source)
 if not m:raise ValueError('Ragel source outside pure literal machine profile')
 return m[1]
def dependency_identity(language):
 return {'files':{name:{'path':str(Path(shutil.which(name)).resolve()),'sha256':hashlib.sha256(Path(shutil.which(name)).resolve().read_bytes()).hexdigest()} for name in {'ragel',HOSTS[language][1]}},'complete_native_dependency_closure_qualified':False}

def original(language,source,inputs,admitted=True):
 if admitted:admit(source)
 flag,tool,suffix=HOSTS[language]
 if any(type(s) is not str or not re.fullmatch('[abcx]{0,5}',s) for s in inputs):raise ValueError('Finite ASCII input contract required')
 build=[]
 with tempfile.TemporaryDirectory(prefix='usl-ragel-') as folder:
  p=Path(folder)
  if flag=='C':
   code='#include <stdio.h>\n#include <string.h>\n'+source+'\n%% write data;\nint accepts(const char *p) {\nconst char *pe=p+strlen(p); int cs;\n%% write init;\n%% write exec;\nreturn cs >= item_first_final && p==pe;\n}\nint main(void){'+''.join('printf("%d\\n",accepts('+json.dumps(s)+'));' for s in inputs)+'return 0;}\n'
  elif flag=='D':
   code='import std.stdio;\n'+source+'\n%% write data;\nbool accepts(string input) {\nconst(char)* p=input.ptr; const(char)* pe=p+input.length; int cs;\n%% write init;\n%% write exec;\nreturn cs >= item_first_final && p==pe;\n}\nvoid main(){'+''.join('writeln(accepts('+json.dumps(s)+') ? 1 : 0);' for s in inputs)+'}\n'
  elif flag=='J':
   code='public class Main {\n'+source+'\n%% write data;\nstatic boolean accepts(String text) {\nchar[] data=text.toCharArray(); int p=0, pe=data.length, cs;\n%% write init;\n%% write exec;\nreturn cs >= item_first_final && p==pe;\n}\npublic static void main(String[] args){'+''.join('System.out.println(accepts('+json.dumps(s)+') ? 1 : 0);' for s in inputs)+'}}\n'
  else:
   code=source+'\n%% write data;\ndef accepts(input)\ndata=input.bytes; p=0; pe=data.length\n%% write init;\n%% write exec;\ncs >= item_first_final && p==pe\nend\n'+''.join('puts(accepts('+json.dumps(s)+') ? 1 : 0)\n' for s in inputs)
  (p/'source.rl').write_text(code)
  # Ragel6's binary-search D backend emits a mutable pointer to const keys.
  # Its flat table backend avoids that D2-incompatible generated declaration.
  generate=execute(['ragel','-'+flag]+(['-F1'] if flag=='D' else [])+['-o','Main.'+suffix,'source.rl'],cwd=p,timeout=15);build.append(generate)
  if generate['returncode']:raise ValueError('Actual Ragel generator rejected source: '+generate['stderr'])
  if flag=='R':argv=[tool,'Main.rb']
  elif flag=='J':build.append(execute([tool,'Main.java'],cwd=p,timeout=20));argv=['java','Main']
  else:build.append(execute([tool,'Main.'+suffix,'-o','program'],cwd=p,timeout=30));argv=[str(p/'program')]
  if any(r['returncode'] for r in build):raise ValueError('Actual generated target compiler failed: '+json.dumps(build)[-4000:])
  observed=execute(argv,cwd=p,timeout=15)
  if observed['returncode'] or any(s not in ('0','1') for s in observed['stdout'].splitlines()):raise ValueError('Generated target execution/protocol failed: '+json.dumps(observed)[-1200:])
  values=[s=='1' for s in observed['stdout'].splitlines()]
  if len(values)!=len(inputs):raise ValueError('Missing native machine observations')
  return values,{'build':build,'execution':observed,'actual_target_host':tool,'fresh_original_machine_executions':len(inputs),'actual_native_worker_programs':1,'execution_evidence_replayed':False}

def translate(source,expected_word):
 word=admit(source)
 if word!=expected_word:raise ValueError('Independently declared recognizer intent disagrees')
 code='function accepts(data):\n    return data == '+repr(word)+'\n'
 tree=parse(code);import ast
 node=tree.body[0].body[0].value
 if not isinstance(node,ast.Compare) or ast.literal_eval(node.comparators[0])!=word:raise ValueError('Actual emitted AST violates literal recognizer IR')
 return code

def qualify_one(language):
 cases=[];receipts=[];negative=[]
 # Every string in this declared domain is executed by the real generated
 # target and by USL. Passing other targets/IDs does not transfer this evidence.
 inputs=[''.join(s) for n in range(5) for s in itertools.product('abcx',repeat=n)]
 for word in ('ab','cab'):
  source=source_for(word);code=translate(source,word);original_values,receipt=original(language,source,inputs);receipts.append(receipt)
  observations=[]
  for data,observed in zip(inputs,original_values):
   value=Interpreter().run(code+'let result = accepts('+repr(data)+')\n').variables['result'];expected=data==word
   observations.append({'input':data,'independent_expected':expected,'native':observed,'USL':value,'passed':type(value) is bool and value==observed==expected})
  cases.append({'source':source,'generated_USL_source':code,'word':word,'finite_domain':observations,'passed':all(r['passed'] for r in observations)})
 for label,src,want in [('effect',source_for('ab')+'\nwrite exec;', 'ab'),('wrong_intent',source_for('ab'),'abc')]:
  try:translate(src,want);rejected=False
  except ValueError:rejected=True
  negative.append({'case':label,'rejected':rejected})
 try:original(language,'%%{ machine item; main := (; }%%',['ab'],admitted=False);rejected=False
 except ValueError as error:rejected=True;diagnostic=str(error)
 negative.append({'case':'actual_Ragel_invalid_syntax','rejected':rejected,'diagnostic':diagnostic if rejected else None})
 return {'catalog_id':language,'profile_kind':'grammar_processing','passed':all(c['passed'] for c in cases) and all(c['rejected'] for c in negative),'cases':cases,'negative_cases':negative,'native_executions':len(receipts),'original_engine_observations':receipts,'original_engine_evaluations':len(inputs)*len(cases),'generated_USL_executions':len(inputs)*len(cases),'provider_identity':dependency_identity(language),'full_standard_qualified':False,'scope':'Ragel6 pure literal-word machine, fresh generated native target, exhaustive ASCII domain length0..4, actual USL recognizer AST. Arbitrary actions, machine composition, carrier programs and untested strings remain unqualified.'}
