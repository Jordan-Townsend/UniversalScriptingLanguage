"""Use a genuinely learned retained USL skill on six new native profiles."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import ast,json,time
from native_profiles import LANGUAGES,NativeFrontend,source_for
from usl_systems.language import Interpreter,parse
from usl_systems.entity_program_discovery import ProgramDiscovery
from prepare import digest

def one(request):
 identifier,skill=request;source=skill['document']['source'];expression=ast.unparse(parse(source).body[1].value)
 pairs=[(-37,-73),(81,163),(0,1)];calls=[{'arguments':[n],'expected_result':v,'intent':'Independent new affine transfer result2x+1'} for n,v in pairs]
 contract={'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-1000,'max':1000}},'postcondition':'result ==2*value+1'}
 f=NativeFrontend(identifier,source_for(identifier,expression),'transform',contract,calls)
 checks=[f.verify(target) for target in ('python','javascript')]
 original=[]
 for n,want in pairs:
  observed=ProgramDiscovery._execute(source,n,'int','int');original.append({'input':n,'observed':observed,'independent_expected':str(want)+'\n','passed':observed['stdout']==str(want)+'\n'})
 return {'catalog_id':identifier,'passed':all(c['passed'] for c in checks+original),'learned_USL_source':source,'native_source':f.source,'native_and_generated_checks':checks,'original_USL_checks':original,'fresh_native_programs':sum(c['native_executions'] for c in checks),'language_grammars_learned':False}
def run(bank,output,workers):
 started=time.monotonic();bank=json.loads(Path(bank).read_text());skill=next(r['actual_skill'] for r in bank['records'] if r['name']=='affine');records=[]
 def transfer_all():
  with ProcessPoolExecutor(max_workers=min(workers,len(LANGUAGES))) as pool:records.extend(pool.map(one,[(n,skill) for n in sorted(LANGUAGES)]))
  return {'passed':all(r['passed'] for r in records),'count':len(records)}
 supervisor='let result = transfer_prepared_skill()\nassert result["passed"]\nassert result["count"] ==6\nprint("prepared USL skill transferred to six new native profiles")\n'
 observed=Interpreter(capabilities={'transfer_prepared_skill':transfer_all},timeout=3600).run(supervisor)
 report={'schema':'usl.prepared-skill.native-transfer.v1','passed':True,'actual_USL_supervisor':{'source':supervisor,'stdout':observed.output},'learned_skill_sha256':skill['sha256'],'records':records,'fresh_native_programs':sum(r['fresh_native_programs'] for r in records),'original_learned_USL_executions':18,'generated_USL_executions':12,'elapsed_seconds':time.monotonic()-started,'new_learning_or_holdout_reuse':False,'language_grammars_learned':False,'general_self_study_claimed':False}
 Path(output).write_text(json.dumps(report,indent=2)+'\n');return report
