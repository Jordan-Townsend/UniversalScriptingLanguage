"""Finite USL skill study, fresh heldout qualification, exhaustive checks, retention."""
from pathlib import Path
import ast,itertools,json,time

SPECS=[
 ('affine','int','int',lambda n:2*n+1,['+','*'],[-3,0,4],[-17,23]),
 ('square','int','int',lambda n:n*n,['*'],[-3,0,4],[-13,19]),
 ('absolute','int','int',abs,['+'],[-7,0,4],[-13,19]),
 ('negate','int','int',lambda n:-n,['+'],[-7,0,4],[-13,19]),
 ('nonnegative','int','bool',lambda n:n>=0,['+'],[-2,-1,0,1,2],[-13,19]),
 ('even','int','bool',lambda n:n%2==0,['+'],[-3,-2,0,1,2,3],[-13,18]),
 ('list_sum','list[int]','int',sum,['+'],[[-2,7,-1],[],[5,-7,3]],[[-8,5,7],[1,2,3,4]]),
 ('sum_squares','list[int]','int',lambda xs:sum(x*x for x in xs),['*'],[[-2,7,-1],[],[5,-7,3]],[[-9,4,1],[1,2,3,4]]),
 ('count_nonnegative','list[int]','int',lambda xs:sum(x>=0 for x in xs),['+'],[[-2,0,7],[],[-1,2,3],[-2,-1,-3]],[[-9,0,1],[0,0,-1]]),
 ('keep_nonnegative','list[int]','list[int]',lambda xs:[x for x in xs if x>=0],['+'],[[-2,0,7],[],[-1,2,3],[-2,-1,-3]],[[-9,0,1],[0,0,-1]]),
 ('double_list','list[int]','list[int]',lambda xs:[2*x for x in xs],['+','*'],[[-2,0,7],[],[-1,2,3]],[[-9,0,1],[5,2,-7]]),
 ('all_nonnegative','list[int]','bool',lambda xs:all(x>=0 for x in xs),['+'],[[-2],[-1],[0],[1],[2],[]],[[-29,2],[0,0,5]]),
 ('any_negative','list[int]','bool',lambda xs:any(x<0 for x in xs),['+'],[[-2],[-1],[0],[1],[2],[]],[[-23,3],[5,0]]),
 ('count_even','list[int]','int',lambda xs:sum(x%2==0 for x in xs),['+'],[[-3,-2,0,1],[],[1,3,5],[2,4,6]],[[-9,0,1],[0,0,1]]),
]
MODELS={s[0]:s[3] for s in SPECS}

def train(directory,output):
 from usl_systems.entity_program_discovery import ProgramDiscovery,DiscoverySession
 from usl_systems.intent_contracts import prove_expression
 from usl_systems.language import parse
 from usl_systems.entity_memory import fingerprint
 discovery=ProgramDiscovery(directory);started=time.monotonic();records=[];active={}
 if Path(output).exists():
  previous=json.loads(Path(output).read_text());records=previous['records']
  for record in records:
   current=discovery.memory.skill(record['name']);assert current['sha256']==record['actual_skill']['sha256'] and record['passed']
  completed={r['name'] for r in records}
 else:completed=set()
 if len(completed)==len(SPECS):return previous
 oracle={'source':'Independently authored preparation-kernel contracts, new one-use holdout and prior-skill retention; model functions in skills.py'}
 def cases(values,model):return [{'input':v,'expected_stdout':str(model(v))+'\n','oracle':oracle} for v in values]
 supervisor='let sealed = seal_discovery_suite(artifact("protected"))\nlet learned = discover_program(artifact("request"), sealed["suite_id"])\nassert learned["promoted"]\nprint("prepared skill passed sealed holdout and all prior skill retention")\n'
 for name,kind,out,model,ops,training,holdout in SPECS:
  if name in completed:active[name]=training[:2];continue
  before={n:discovery.memory.skill(n)['sha256'] for n in active}
  retention=[{'name':n,'cases':cases(values,MODELS[n])} for n,values in active.items()]
  imports={'protected':{'schema':'usl.discovery.protected-suite.v1','name':name,'input_type':kind,'output_type':out,'holdout':cases(holdout,model),'retention':retention},
   'request':{'schema':'usl.discovery.request.v1','name':name,'input_type':kind,'output_type':out,'hypothesis':'Infer the declared pure preparation kernel from independent examples; preserve every prior active skill.','evidence':oracle,
    'grammar':{'schema':'usl.discovery.typed-grammar.v1','constants':[-1,0,1,2],'operators':ops,'expression_depth':2 if name=='affine' else 1,'expression_limit':128 if name=='affine' else 32,'predicate_limit':32},'training':cases(training,model),'max_candidates':4096,'max_seconds':20}}
  observed=DiscoverySession(discovery,imports,approved=True).interpret(supervisor)
  skill=discovery.memory.skill(name);doc=skill['document'];assert fingerprint(doc)==skill['sha256']
  selected=discovery.memory.run(doc['discovery_run_id'])['document']
  domain=list(range(-32,33)) if kind=='int' else [list(v) for length in range(5) for v in itertools.product(range(-2,3),repeat=length)]
  checks=[]
  for value in domain:
   actual=ProgramDiscovery._execute(doc['source'],value,kind,out);expected=str(model(value))+'\n'
   checks.append({'input':value,'independent_expected':expected,'actual':actual['stdout'],'passed':actual['stdout']==expected})
  formal=None
  if name in {'affine','square','negate'}:
   expression=ast.unparse(parse(doc['source']).body[1].value)
   post={'affine':'result ==2*value+1','square':'result ==value*value','negate':'result == -value'}[name]
   formal=prove_expression(expression,{'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-10000,'max':10000}},'postcondition':post});assert formal['proved']
  preserved=all(discovery.memory.skill(n)['sha256']==digest for n,digest in before.items())
  record={'name':name,'input_type':kind,'output_type':out,'actual_skill':skill,'discovery_record':selected,'candidate_trials':discovery.history(doc['discovery_run_id']),
   'actual_USL_supervisor':{'source':supervisor,'observed':observed},'independent_exhaustive_domain':{'scalar_min':-32,'scalar_max':32} if kind=='int' else {'list_values':[-2,-1,0,1,2],'max_list_length':4},
   'exhaustive_cases':checks,'bounded_scalar_formal_proof':formal,'prior_skills_retained':len(before),'prior_skill_hashes_unchanged':preserved,
   'passed':all(r['passed'] for r in checks) and preserved,'arbitrary_program_learning_or_intent_proof':False}
  assert record['passed'],name;records.append(record);active[name]=training[:2]
  report={'schema':'usl.preparation.skill-bank.v1','completed':len(records),'candidate_skills':len(SPECS),'passed':len(records)==len(SPECS) and all(r['passed'] for r in records),
   'records':records,'elapsed_seconds':time.monotonic()-started,'elapsed_seconds_scope':'Current training segment only; prior/failed segments must be accounted separately','general_self_study_or_human_equivalence':False,'learning_grammar':'implemented finite typed arithmetic/list/bool grammar',
   'all_past_active_skills_checked_before_each_promotion':True,'skills_state_directory':str(Path(directory).resolve())}
  Path(output).write_text(json.dumps(report,indent=2)+'\n')
 return report

def apply(source,kind,out,value,expected):
 from usl_systems.entity_program_discovery import ProgramDiscovery
 observed=ProgramDiscovery._execute(source,value,kind,out)
 if observed['stdout']!=str(expected)+'\n':raise ValueError('Learned kernel disagrees with independent per-use contract')
 return {'observed':observed,'independent_expected':str(expected)+'\n','passed':True,'input':value}

def verify_bank(path,output):
 """Fresh exhaustive execution of retained skills; no holdout is re-sealed."""
 from usl_systems.entity_memory import fingerprint
 from usl_systems.entity_program_discovery import ProgramDiscovery
 from usl_systems.intent_contracts import prove_expression
 from usl_systems.language import parse
 bank=json.loads(Path(path).read_text());assert bank['passed'] and bank['completed']==14
 assert {r['name'] for r in bank['records']}==set(MODELS)
 started=time.monotonic();records=[]
 for record in bank['records']:
  skill=record['actual_skill'];assert fingerprint(skill['document'])==skill['sha256'];kind=record['input_type'];out=record['output_type'];source=skill['document']['source'];model=MODELS[record['name']]
  domain=list(range(-32,33)) if kind=='int' else [list(v) for length in range(5) for v in itertools.product(range(-2,3),repeat=length)]
  assert [c['input'] for c in record['exhaustive_cases']]==domain
  for value in domain:
   actual=ProgramDiscovery._execute(source,value,kind,out)
   if actual['stdout']!=str(model(value))+'\n':raise ValueError('Fresh retained skill counterexample: '+record['name'])
  formal=None
  if record['name'] in {'affine','square','negate'}:
   expression=ast.unparse(parse(source).body[1].value);post={'affine':'result ==2*value+1','square':'result ==value*value','negate':'result == -value'}[record['name']]
   formal=prove_expression(expression,{'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-10000,'max':10000}},'postcondition':post});assert formal['proved']
  records.append({'name':record['name'],'passed':True,'fresh_exhaustive_executions':len(domain),'formal_proof':formal,'skill_sha256':skill['sha256']})
 report={'schema':'usl.retained-skills.fresh-verification.v1','passed':True,'skills':14,'fresh_exhaustive_executions':sum(r['fresh_exhaustive_executions'] for r in records),'records':records,'elapsed_seconds':time.monotonic()-started,'original_learning_holdouts_reused':False,'new_learning_claimed':False}
 Path(output).write_text(json.dumps(report,indent=2)+'\n');return report
