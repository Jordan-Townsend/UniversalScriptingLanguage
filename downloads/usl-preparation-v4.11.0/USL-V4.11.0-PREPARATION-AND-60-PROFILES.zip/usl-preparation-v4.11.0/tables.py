"""Compact family table: scoped profiles and open normative obligations."""
from pathlib import Path
import csv,html,json
from workers import registry,BLOCKED,audit_bindings
RECIPES={
 'Systems and native imperative':('Versioned native compiler, ABI and runtime','Parse declarations/types/control flow; lower ownership/layout/effects; compile original and target; differential signedness, memory, lifetime, error and FFI tests.'),
 'Scripting and general application languages':('Exact dialect interpreter/compiler and libraries','Implement bindings, value representations, closures/classes/modules, exceptions and host capabilities; compare fresh original/generated observable traces and independent intent tests.'),
 'Transcripts, logs and protocol messages':('Versioned category processor; displayed program hosts separate','Parse complete admitted records; preserve typed fields/order/encoding; reject malformed lengths/delimiters; never execute displayed commands or inherit their language guarantees.'),
 'Templates and composite sources':('Actual template engine AND carrier processor','Implement escaping, control/effects and context scope; lower typed template IR; compare fresh render and carrier behavior; delimit bounded substitution profiles from full engine semantics.'),
 'Grammars, interfaces and schemas':('Exact generator/schema compiler AND generated target runtime','Implement grammar/schema AST, names/types/constraints; lower machine/record IR; compile generated targets, compare acceptance/wire/ABI, negative and boundary intent tests.'),
 'Configuration, build and deployment':('Actual configuration/build engine and isolated fixture services','Model variable resolution, includes/dependency graph and effects; inspect effective configuration and freshly exercise behavior; syntax validity alone qualifies a syntax contract only.'),
 'Assembly and intermediate representations':('Compatible assembler/validator, architecture, linker and ABI','Decode actual instructions/SSA; model registers/memory/flags/undefined behavior and type rules; prove emitted IR intent; compile/link/run original and target on qualified ISA.'),
 'SQL and query languages':('Exact query engine, dialect, schema and fixture data','Model nulls, bags/order, coercion, collation, aggregates, updates and transactions; compare original/generated typed rows and effects on independently specified fixtures.'),
 'HDL, shaders and compute':('Compatible simulator/compiler plus actual device for device claims','Model bit width, signedness, clocks/events or shader execution/memory; compile and validate; compare simulation/device observations with independent signal contracts.'),
 'Logic, proof and verification':('Exact proof assistant/model checker and versioned logic','Implement binding, sorts, proof/kernel obligations and solver interfaces; check real proof objects/countermodels, not just parse success.'),
 'Markup, documents and styles':('Actual document/style processor','Preserve category-specific typed structure, selectors/escaping/layout contracts; compare original and generated projections; rendering and arbitrary embedded code remain separate gates.'),
}
DEFAULT=('Exact versioned native host, standard library, platform and license dependencies','Pin specification/version; implement full grammar, names/types/values/control/effects, typed IR and target runtime; run native conformance, negative/boundary/property/differential tests and independent intent proofs; audit library/ABI/platform gates.')
def build(source_root,results,output):
 rows=audit_bindings(source_root);results=Path(results);out=Path(output);out.mkdir(parents=True,exist_ok=True);round_report=json.loads((results/'qualification/workers.json').read_text());assert round_report['passed'];fresh={r['catalog_id']:r for r in round_report['records'] if r['passed']};inventory=json.loads((results/'preparation.json').read_text());prepared={r['catalog_id']:r['record'] for r in inventory['records']};refs=json.loads((results/'reference-resolution.json').read_text());reference_by_id={n:r for r in refs['records'] for n in r['catalog_ids']};entries=[]
 for row in rows:
  n=row['catalog_id'];recipe=RECIPES.get(row['family'],DEFAULT);p=prepared[n];new=fresh.get(n);report=json.loads((results/'qualification'/(n+'.json')).read_text())['report'] if new else None
  entries.append({'catalog_id':n,'original_catalog':row['original_catalog'],'family':row['family'],'scoped':bool(row['scoped_profile'] or new),'newly_scoped':bool(new),
   'profile_kind':report['profile_kind'] if report else row['scope_kind'],'scope':report['scope'] if report else row['specification_profile'],
   'lexer_metadata':p['lexer'] is not None,'parser_schema':p['parser_schema'] is not None,'normative_preparation_complete':False,'full_standard_qualified':False,
   'host_requirement':recipe[0],'implementation_recipe':recipe[1],'original_tool_requirement':row['original_native_tool_requirement'],'external_dependencies':row['external_dependencies'],
   'ordered_steps':row['ordered_steps'],'obligation_dimensions':row['obligation_dimensions'],'reference_resolution':reference_by_id.get(n),'specific_blocker':BLOCKED.get(n),
   'next_action':'Expand this scoped profile through the still-open normative/library/runtime/ABI/platform/conformance/intent gates.' if row['scoped_profile'] or new else recipe[1]})
 summary={'original_ids':606,'USL_extra':1,'original_scoped':243,'original_without_scope':363,'new_scoped':60,'code_expression_profiles':82,'category_processing_profiles':161,'all_ID_preparation_records':607,'logical_ID_dimension_tasks':10926,'original_normative_dimension_tasks':10908,'full_standards':0,'complete_entity_tracks':0,'entire_objective_ETA_seconds':None}
 assert sum(e['scoped'] and e['original_catalog'] for e in entries)==243
 document={'schema':'usl.all-ID.scoped-backlog.v1','summary':summary,'entries':entries};(out/'LANGUAGES.json').write_text(json.dumps(document,indent=2)+'\n')
 fields=['catalog_id','family','scoped','newly_scoped','profile_kind','lexer_metadata','parser_schema','full_standard_qualified','host_requirement','next_action']
 with (out/'LANGUAGES.csv').open('w',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(entries)
 families={}
 for e in entries:families.setdefault(e['family'],[]).append(e)
 body=['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>USL scoped language backlog</title><style>body{font:16px system-ui;max-width:1150px;margin:2em auto;padding:0 1em}td,th{padding:.5em;text-align:left;vertical-align:top;border-bottom:1px solid #ddd}table{width:100%;border-collapse:collapse}summary{cursor:pointer;padding:.6em}small{color:#555}input{font:inherit;padding:.5em;width:90%}</style><h1>USL language backlog</h1><p>606 original IDs:243 scoped (82 code/expression,161 category processing),363 without scope. USL is the607th entry. All606 full standards and all21 entity tracks remain incomplete.</p><p>60 fresh scopes; preparation inventories and logical workers do not qualify semantics. Expand a family or ID to see its next actions. No implementation completion date is supported by current evidence.</p><label>Filter IDs or families <input id="filter" type="search"></label>']
 for family,items in sorted(families.items()):
  scoped=sum(e['scoped'] and e['original_catalog'] for e in items);original=sum(e['original_catalog'] for e in items)
  body.append('<details class="family"><summary>'+html.escape(family)+f' — {scoped}/{original} original scoped</summary><table><tr><th>ID</th><th>Current evidence</th><th>Remaining work</th></tr>')
  for e in items:
   status='scoped '+str(e['profile_kind']) if e['scoped'] else 'without scoped profile';detail=html.escape(str(e['scope']));step_text=''.join('<li>'+html.escape(json.dumps(s,ensure_ascii=False))+'</li>' for s in e['ordered_steps'])
   body.append('<tr class="language" data-search="'+html.escape((e['catalog_id']+' '+family).lower(),quote=True)+'"><td>'+html.escape(e['catalog_id'])+'</td><td>'+html.escape(status)+'</td><td><details><summary>'+html.escape(e['next_action'])+'</summary><p>'+detail+'</p><p>Native host: '+html.escape(e['host_requirement'])+'</p><ol>'+step_text+'</ol><p>All18 normative dimensions remain unqualified as full gates.</p></details></td></tr>')
  body.append('</table></details>')
 body.append('<script>document.getElementById("filter").addEventListener("input",e=>{let q=e.target.value.toLowerCase();for(let r of document.querySelectorAll(".language"))r.hidden=!r.dataset.search.includes(q);for(let f of document.querySelectorAll(".family")){f.hidden=![...f.querySelectorAll(".language")].some(r=>!r.hidden);if(q)f.open=!f.hidden;}});</script></html>')
 (out/'LANGUAGES.html').write_text(''.join(body));return summary
