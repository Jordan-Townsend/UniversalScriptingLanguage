"""Unified local partial worker sets, exact all-ID planning and scoped joins."""
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import asyncio,collections,hashlib,importlib,json,sys,time,traceback,zlib
from prepare import CAS,addon_identity,digest,initialize
MODULES=('native_profiles','ragel_profiles','new_templates','transcript_profiles','category_profiles')
BLOCKED={'ragel-d':{'reason':'Ragel6 D1 generated carriers fail the installed D2 compiler: const-table pointer types or implicit switch fallthrough.',
 'attempts':['default table: const(char)* cannot convert to char*','G2 goto: switch fallthrough rejected','F1 flat: const(char)* and const(byte)* mutable pointer assignments rejected'],
 'needed':'Implement and validate a versioned D2-compatible backend, or install a compatible native D host. Preserve original rejected generated code evidence; no native pass inferred from other Ragel IDs.'}}
def registry():
 result={}
 for name in MODULES:
  for identifier in importlib.import_module(name).LANGUAGES:
   if identifier in BLOCKED:continue
   if identifier in result:raise ValueError('Overlapping worker catalog binding')
   result[identifier]=name
 return result
def job(identifier):
 started=time.monotonic();module=registry()[identifier]
 try:
  report=importlib.import_module(module).qualify_one(identifier)
  if report['catalog_id']!=identifier:raise ValueError('Worker returned wrong ID')
  return {'catalog_id':identifier,'module':module,'passed':report['passed'],'seconds':time.monotonic()-started,'report':report}
 except Exception as error:return {'catalog_id':identifier,'module':module,'passed':False,'seconds':time.monotonic()-started,'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()}
def group_job(identifiers):
 # Co-residence changes process launches only. Every ID executes its actual
 # processor, malformed cases, USL target and independent oracle afresh.
 if len(identifiers)>1 and any(registry()[n]!='transcript_profiles' for n in identifiers):raise ValueError('No audited cross-profile process-sharing contract')
 return [job(n) for n in identifiers]
def audit_bindings(source_root):
 rows=json.loads((Path(source_root)/'docs/ALL_LANGUAGE_ACTION_PLAN.json').read_text())['entries'];ids={r['catalog_id'] for r in rows};uncovered={r['catalog_id'] for r in rows if r['original_catalog'] and not r['scoped_profile']}
 if len(rows)!=607 or len(ids)!=607 or len(uncovered)!=423:raise ValueError('Wrong base catalog/scope')
 if len(registry())!=60 or not set(registry()).issubset(uncovered):raise ValueError('New worker set lost/duplicated an ID or overlaps a previous scope')
 return rows
class SingleFlight:
 """Share an IN-PROGRESS pure build; native program results are never cached."""
 def __init__(self):self.tasks={};self.builds=0;self.requests=0
 async def get(self,key,builder):
  self.requests+=1
  if key not in self.tasks:
   self.builds+=1;self.tasks[key]=asyncio.create_task(builder())
  return await self.tasks[key]

def run(source_root,output,workers=None):
 from usl_systems.batch_multiplex import source_identity
 from usl_systems.resources import discover
 from usl_systems.language import Interpreter
 rows=audit_bindings(source_root);output=Path(output);output.mkdir(parents=True,exist_ok=True);cas=CAS(output/'objects');initial=source_identity();addon=addon_identity();started=time.monotonic();records=[]
 from pools import capacity
 from policies import process_policy,state_policy
 admission=capacity(workers);ids=sorted(registry());groups={};policy_receipts=[]
 for identifier in ids:
  decision,receipt=process_policy(identifier,registry()[identifier]);groups.setdefault(decision['group'],[]).append(identifier);policy_receipts.append(receipt)
 if sorted(n for group in groups.values() for n in group)!=ids:raise ValueError('Process coalescing lost/duplicated an ID')
 admitted=min(admission['workers'],len(groups));logical_counts={'created':607*18,'started':0,'finished':0,'awaiting_native':0,'max_awaiting_native':0};partial_results=[];flights=SingleFlight();states=SingleFlight()
 def publish(final=False):
  passed=sum(r['passed'] for r in records);elapsed=time.monotonic()-started;pending=len(ids)-len(records)
  report={'schema':'usl.scoped.partial-worker-set.v1','passed':final and passed==len(ids),'finished':final,'candidate_ids':ids,'candidate_count':len(ids),'completed':len(records),'passed_new_profiles':passed,'failed_profiles':len(records)-passed,'pending_candidates':pending,
   'previous_original_scoped':183,'original_scoped':183+passed,'original_without_scope':423-passed,'original_catalog':606,'USL_extra':1,'all_ID_plan_entries':607,
   'new_code_profiles':sum(r['passed'] and r['module']=='native_profiles' for r in records),'new_category_processing_profiles':sum(r['passed'] and r['module']!='native_profiles' for r in records),
   'full_standards_qualified':0,'entity_tracks_complete':0,'workers':admitted,'resource_admission':admission,'logical_partial_tasks':607*18,'continuous_scheduler':True,'fixed_rounds':False,'logical_worker_counts':dict(logical_counts),'elapsed_seconds':elapsed,
   'validation_only_ETA_seconds':pending*(sum(r['seconds'] for r in records)/len(records))/admitted if records and pending else None,'entire_implementation_ETA_seconds':None,
   'base_source_identity':initial,'addon_source_identity':addon,'source_unchanged_during_run':source_identity()==initial and addon_identity()==addon,'native_execution_evidence_replayed':False,
   'counterexample_blockers':BLOCKED,'records':records}
  temp=output/'worker-progress.tmp';temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(output/'workers.json');return report
 async def schedule():
  loop=asyncio.get_running_loop();gate=asyncio.Event()
  from pools import memory_snapshot
  before_memory=memory_snapshot();samples=[];stop_sampling=asyncio.Event()
  async def sample_memory():
   while not stop_sampling.is_set():
    snapshot=memory_snapshot();fields=snapshot['statistics'];samples.append({'elapsed_seconds':time.monotonic()-started,'anon_bytes':fields.get('anon'),'kernel_bytes':fields.get('kernel'),'clean_file_cache_bytes':max(0,fields.get('file',0)-fields.get('file_dirty',0)-fields.get('file_writeback',0)),'events':snapshot['events']})
    try:await asyncio.wait_for(stop_sampling.wait(),timeout=.1)
    except asyncio.TimeoutError:pass
  sampler=asyncio.create_task(sample_memory())
  with ProcessPoolExecutor(max_workers=admitted,initializer=initialize,initargs=(str(source_root),)) as pool:
   async def native_group_work(identifiers):
    await gate.wait()
    group_records=await loop.run_in_executor(pool,group_job,identifiers);summaries={}
    for record in group_records:
     body=json.dumps(record,sort_keys=True,separators=(',',':')).encode();key=cas.put(body)
     if json.loads(cas.get(key))!=record:raise ValueError('Worker CAS restoration failed')
     summary={'catalog_id':record['catalog_id'],'passed':record['passed'],'module':record['module'],'seconds':record['seconds'],'evidence_sha256':key}
     records.append(summary);summaries[record['catalog_id']]=summary;(output/(record['catalog_id']+'.json')).write_text(json.dumps(record,indent=2)+'\n');publish()
    return summaries
   # Every ID/dimension actor is instantiated at once. Actual native jobs are
   # submitted continuously, never partitioned into rounds. All18 actors of
   # one ID refer to that ONE fresh qualification job, not18 replayed runs.
   group_tasks={key:asyncio.create_task(native_group_work(group)) for key,group in groups.items()}
   async def native_view(identifier,task):return (await task)[identifier]
   native_tasks={n:asyncio.create_task(native_view(n,group_tasks[key])) for key,group in groups.items() for n in group}
   async def partial(row,obligation):
    await gate.wait();logical_counts['started']+=1
    await asyncio.sleep(0) # let all logical actors enter before their first work
    payload={'family':row['family'],'obligation':obligation};raw=json.dumps(payload,sort_keys=True,separators=(',',':')).encode();key=hashlib.sha256(raw).hexdigest()
    async def build():
     packed=zlib.compress(raw,9);identity=cas.put(packed)
     if zlib.decompress(cas.get(identity))!=raw:raise ValueError('Pure partial artifact collapse corrupted bytes')
     return identity
    artifact=await flights.get(key,build);identifier=row['catalog_id'];evidence=None
    if identifier in native_tasks:
     logical_counts['awaiting_native']+=1;logical_counts['max_awaiting_native']=max(logical_counts['max_awaiting_native'],logical_counts['awaiting_native'])
     evidence=await native_tasks[identifier];logical_counts['awaiting_native']-=1
    async def decide_state():
     decision,receipt=state_policy(row,evidence);policy_receipts.append(receipt);return decision['state']
    state=await states.get(identifier,decide_state)
    result={'catalog_id':identifier,'dimension':obligation['dimension'],'family':row['family'],'pure_artifact_sha256':artifact,'uncompressed_payload_sha256':key,'state':state,'fresh_profile_evidence_sha256':evidence['evidence_sha256'] if evidence else None,'full_dimension_qualified':False}
    logical_counts['finished']+=1;return result
   tasks=[asyncio.create_task(partial(row,obligation)) for row in rows for obligation in row['obligation_dimensions']]
   if len(tasks)!=607*18:raise ValueError('Missing logical partial actors')
   publish();gate.set();partial_results.extend(await asyncio.gather(*tasks));await asyncio.gather(*native_tasks.values())
  stop_sampling.set();await sampler;after_memory=memory_snapshot()
  event_delta={k:after_memory['events'].get(k,0)-before_memory['events'].get(k,0) for k in ('oom','oom_kill','max')}
  (output/'memory-observations.json').write_text(json.dumps({'before':before_memory,'after':after_memory,'event_delta':event_delta,'samples':samples,'OOM_events_observed':bool(event_delta['oom'] or event_delta['oom_kill']),'whole_cgroup_observed_not_exclusive_native_job_memory':True},indent=2)+'\n')
  if event_delta['oom'] or event_delta['oom_kill']:raise ValueError('Observed OOM event requires reduced admission and fresh validation')
  expected={(r['catalog_id'],o['dimension']) for r in rows for o in r['obligation_dimensions']}
  if len(partial_results)!=len(expected) or {(r['catalog_id'],r['dimension']) for r in partial_results}!=expected:raise ValueError('Lost/duplicated concurrent partial ID/dimension')
  for result in partial_results:
   raw=zlib.decompress(cas.get(result['pure_artifact_sha256']))
   if hashlib.sha256(raw).hexdigest()!=result['uncompressed_payload_sha256']:raise ValueError('Wrong concurrent dependency/artifact join')
  (output/'partial-workers.json').write_text(json.dumps({'schema':'usl.continuous.partial-actors.v1','logical_workers':len(tasks),'all_started':logical_counts['started']==len(tasks),'all_settled':logical_counts['finished']==len(tasks),'max_live_logical_workers_at_start':len(tasks),'native_ID_jobs_submitted_concurrently':len(ids),'process_groups':groups,'physical_process_jobs':len(groups),'process_jobs_avoided_by_USL_policy':len(ids)-len(groups),'physical_executor_slots':admitted,'admission':admission,'fixed_rounds':False,'pure_artifact_requests':flights.requests,'pure_singleflight_builds':flights.builds,'USL_state_policy_executions':states.builds,'USL_policy_receipts':policy_receipts,'native_qualifications_per_ID':1,'native_observations_replayed':False,'state_counts':dict(collections.Counter(r['state'] for r in partial_results)),'records':sorted(partial_results,key=lambda r:(r['catalog_id'],r['dimension']))},indent=2)+'\n')
 def validate():
  publish();asyncio.run(schedule())
  report=publish(True)
  if not report['source_unchanged_during_run']:raise ValueError('Source changed during worker qualification')
  return report
 source=(Path(__file__).parent/'worker_sets.usl').read_text()
 observed=Interpreter(capabilities={'plan_all_ids':lambda:{'original':606,'total':607,'candidates':len(ids)},'validate_candidates':validate},timeout=3600,max_ops=100000).run(source)
 (output/'supervisor.json').write_text(json.dumps({'source':source,'stdout':observed.output,'operations':observed.operations,'actual_USL_supervision':True},indent=2)+'\n')
 return observed.variables['result']
