from pathlib import Path
import argparse,json,sys

def main():
 p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('fresh-results'));p.add_argument('--reference-cache',type=Path,default=Path('/workspace/.onboarding/data/v411-public-reference-cache'));p.add_argument('--workers',type=int,default=None);p.add_argument('--mode',choices=['all','prepare','qualify','race','skills','transfer','tables','test'],default='all');p.add_argument('--stage-report',type=Path);p.add_argument('--offline',action='store_true');p.add_argument('--i-allow-execution',action='store_true');a=p.parse_args()
 if not a.i_allow_execution:raise ValueError('Explicit preparation/verified-skill/public-reference execution required')
 if a.workers is not None and a.workers<1:raise ValueError('Physical executor request must be positive; logical partial tasks are independent')
 sys.path.insert(0,str(a.source_root.resolve()))
 from tools.verify_release import verify
 verification=verify(a.source_root);assert verification['verified'] and verification['version']=='4.10.0',verification
 from pools import capacity
 admitted=capacity(a.workers)['workers'];a.output.mkdir(parents=True,exist_ok=True);results={}
 if a.mode=='all':
  from workflow import run
  result=run(a);print(json.dumps({k:result[k] for k in ['passed','backlog','elapsed_seconds','source_unchanged_during_run']},indent=2));return
 if a.mode=='test':
  import unittest
  suite=unittest.defaultTestLoader.loadTestsFromName('test_addon');outcome=unittest.TextTestRunner(verbosity=2).run(suite)
  if not outcome.wasSuccessful():raise SystemExit(1)
  result={'tests':{'tests_executed':outcome.testsRun,'passed':True}}
  if a.stage_report:a.stage_report.write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(result));return
 if a.mode in {'all','skills'}:
  from skills import verify_bank
  results['skills']=verify_bank(Path(__file__).parent/'results/skill-bank.json',a.output/'skill-verification.json')
 if a.mode in {'all','transfer'}:
  from transfer import run
  result=run(Path(__file__).parent/'results/skill-bank.json',a.output/'transfer.json',admitted);results['transfer']={k:result[k] for k in ['passed','fresh_native_programs','elapsed_seconds']}
 if a.mode in {'all','prepare'}:
  from prepare import execute
  results['preparation']=execute(a.source_root,a.output,a.reference_cache,admitted,False)
  if not a.offline:
   from references import run
   result=run(a.source_root,a.reference_cache,a.output/'reference-resolution.json',min(64,admitted*2));results['references']={k:v for k,v in result.items() if k!='records'}
  else:
   import shutil
   destination=a.output/'reference-resolution.json';existing=Path(__file__).parent/'results/reference-resolution.json'
   if destination.resolve()!=existing.resolve():shutil.copy2(existing,destination)
 if a.mode in {'all','qualify'}:
  from workers import run
  result=run(a.source_root,a.output/'qualification',admitted);results['qualification']={k:v for k,v in result.items() if k!='records'}
 if a.mode in {'all','race'}:
  from race import run
  result=run(a.source_root,a.output/'race.json',admitted);results['race']={k:result[k] for k in ['passed','selected_before_heldout','physical_pool_sizes_measured','end_to_end_seconds']}
 if a.mode in {'all','tables'}:
  from tables import build
  results['backlog']=build(a.source_root,a.output,a.output/'tables')
 (a.stage_report or a.output/'run-summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
if __name__=='__main__':main()
