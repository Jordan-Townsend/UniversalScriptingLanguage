"""Native grammar/schema/build/document processors and finite sed translation."""
from pathlib import Path
import ast,copy,hashlib,importlib.metadata,itertools,json,os,re,shutil,tempfile
from native_profiles import PREFIX
from usl_systems.bounded_process import execute
from usl_systems.language import Interpreter,parse
from usl_systems.semantic_documents import DocumentFrontend,DocumentError,typed,digest

LANGUAGES={'antlr','antlr-java','protobuf','capnp','meson','nginx','scdoc','sed'}
SOURCES={'protobuf':'syntax = "proto3"; message Item { int32 count = 1; string name = 2; }',
 'capnp':'@0x8eedea80e9fa8a56; struct Item { count @0 :Int32; name @1 :Text; }',
 'antlr':"grammar Item; start: 'ab' EOF;",'antlr-java':"grammar Item; start: 'ab' EOF;",
 'meson':"option('count', type: 'integer', value: 7)\n",
 'nginx':'worker_processes 1;\nevents { worker_connections 16; }\n',
 'scdoc':'ITEM(1)\n\n# NAME\n\nitem - alpha\n','sed':'s/alpha/beta/g'}
def admitted(language,source):
 if language not in LANGUAGES or source!=SOURCES[language]:raise DocumentError('Entire source outside declared category grammar')
def program(argv,cwd,timeout=20):
 r=execute(argv,cwd=cwd,timeout=timeout,max_output=2097152)
 if r['returncode']:raise DocumentError('Actual upstream processor rejected source: '+r['stderr'][-2000:]+r['stdout'][-500:])
 return r
def provider_command(name):
 p=PREFIX/'sysroot/usr/bin'/name
 libraries=str(PREFIX/'sysroot/usr/lib/x86_64-linux-gnu')+os.pathsep+os.environ.get('LD_LIBRARY_PATH','')
 return ['env','LD_LIBRARY_PATH='+libraries,str(p)]

def antlr_original(language,source,inputs):
 admitted(language,source);jars=sorted((PREFIX/'sysroot/usr/share/java').glob('*.jar'));classpath=os.pathsep.join(str(p) for p in jars)
 with tempfile.TemporaryDirectory(prefix='usl-antlr-') as folder:
  p=Path(folder);(p/'Item.g4').write_text(source)
  generate=program(['java','-cp',classpath,'org.antlr.v4.Tool','-Dlanguage=Java','Item.g4'],p)
  java='import org.antlr.v4.runtime.*; public class Main { static boolean accepts(String source){final int[] errors={0}; BaseErrorListener l=new BaseErrorListener(){ public void syntaxError(Recognizer<?,?> r,Object t,int line,int col,String msg,RecognitionException e){errors[0]++;}}; ItemLexer lexer=new ItemLexer(CharStreams.fromString(source)); lexer.removeErrorListeners();lexer.addErrorListener(l);ItemParser parser=new ItemParser(new CommonTokenStream(lexer));parser.removeErrorListeners();parser.addErrorListener(l);parser.start();return errors[0]==0;} public static void main(String[] args){'+''.join('System.out.println(accepts('+json.dumps(s)+') ? 1 : 0);' for s in inputs)+'}}'
  (p/'Main.java').write_text(java);build=program(['javac','-cp',classpath,*[f.name for f in sorted(p.glob('*.java'))]],p,30)
  r=program(['java','-cp','.'+os.pathsep+classpath,'Main'],p)
  values=r['stdout'].splitlines()
  if len(values)!=len(inputs) or any(x not in ('0','1') for x in values):raise DocumentError('ANTLR runtime protocol mismatch')
  return [x=='1' for x in values],{'generation':generate,'build':build,'fresh_execution':r}

_CAPNP=None;_CAPNP_TEMP=None
def capnp_module():
 global _CAPNP,_CAPNP_TEMP
 if _CAPNP is None:
  import capnp,atexit
  _CAPNP_TEMP=tempfile.TemporaryDirectory(prefix='usl-capnp-schema-');p=Path(_CAPNP_TEMP.name)/'item.capnp';p.write_text(SOURCES['capnp']);_CAPNP=capnp.load(str(p));atexit.register(_CAPNP_TEMP.cleanup)
 return _CAPNP
def schema_original(language,source,inputs):
 admitted(language,source);observations=[]
 with tempfile.TemporaryDirectory(prefix='usl-schema-') as folder:
  p=Path(folder)
  if language=='protobuf':
   from google.protobuf import descriptor_pb2,descriptor_pool,message_factory
   (p/'item.proto').write_text(source);observations.append(program(provider_command('protoc')+['--proto_path=.','--descriptor_set_out=item.desc','item.proto'],p))
   definitions=descriptor_pb2.FileDescriptorSet.FromString((p/'item.desc').read_bytes());pool=descriptor_pool.DescriptorPool()
   for descriptor in definitions.file:pool.Add(descriptor)
   cls=message_factory.GetMessageClass(pool.FindMessageTypeByName('Item'));fields=[{'name':f.name,'number':f.number,'type':f.type} for f in cls.DESCRIPTOR.fields]
   if fields!=[{'name':'count','number':1,'type':5},{'name':'name','number':2,'type':9}]:raise DocumentError('Actual native schema differs from declared record IR')
   values=[]
   for data in inputs:
    item=cls(**data);encoded=item.SerializeToString();fresh=cls.FromString(encoded);values.append({'count':fresh.count,'name':fresh.name})
  else:
   (p/'item.capnp').write_text(source);observations.append(program(provider_command('capnp')+['compile','-o-','item.capnp'],p))
   cls=capnp_module().Item;fields={k:v.proto.slot.type.which() for k,v in cls.schema.fields.items()}
   if fields!={'count':'int32','name':'text'}:raise DocumentError('Actual Capnp schema differs from typed record intent')
   values=[]
   for data in inputs:
    item=cls.new_message(**data);encoded=item.to_bytes()
    with cls.from_bytes(encoded) as fresh:values.append({'count':fresh.count,'name':str(fresh.name)})
  return values,{'compiler_programs':observations,'actual_roundtrips':len(inputs),'actual_wire_bytes_generated_and_decoded':True,'pure_schema_artifact_reused':language=='capnp','execution_evidence_replayed':False}

def concrete_original(language,source):
 admitted(language,source);observations=[]
 with tempfile.TemporaryDirectory(prefix='usl-category-') as folder:
  p=Path(folder)
  if language=='meson':
   (p/'meson.build').write_text("project('usl')\n");(p/'meson_options.txt').write_text(source)
   observations.append(program(['meson','setup','build','--wrap-mode=nodownload'],p))
   r=program(['meson','introspect','build','--buildoptions'],p);observations.append(r)
   values=[{'name':o['name'],'type':o['type'],'value':o['value']} for o in json.loads(r['stdout']) if o['name']=='count']
   return values,observations
  if language=='nginx':
   (p/'nginx.conf').write_text('pid '+str(p/'nginx.pid')+';\nerror_log stderr;\n'+source)
   r=program(['nginx','-p',str(p)+'/', '-c',str(p/'nginx.conf'),'-t'],p);observations.append(r)
   # Versioned syntax-validation category contract, explicitly no server
   # requests/effective deployment semantics inferred from a successful -t.
   return {'syntax_valid':True,'server_started':False},observations
  (p/'input.scd').write_text(source)
  # scdoc reads stdin. A tiny fixed Python worker supplies bytes without shell
  # expansion; scdoc still is the actual upstream document compiler.
  (p/'run.py').write_text('import subprocess,sys\nr=subprocess.run([sys.argv[1]],input=open("input.scd","rb").read(),capture_output=True)\nsys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)\n')
  r=program([shutil.which('python'), 'run.py',str(PREFIX/'sysroot/usr/bin/scdoc')],p);observations.append(r)
  # Preserve observable man output content and section names, excluding the
  # compiler's current date header. Do not claim entire roff layout equality.
  names=re.findall(r'^\.SH (?:"([^"]+)"|([A-Z][A-Z ]*))$',r['stdout'],re.M)
  names=[a or b for a,b in names]
  if 'item - alpha' not in r['stdout']:raise DocumentError('Native scdoc lost independently specified content')
  return {'sections':names,'name_text':'item - alpha'},observations

def generated_record(data):
 if type(data) is not dict or set(data)!={'count','name'} or type(data['count']) is not int or not -(2**31)<=data['count']<2**31 or type(data['name']) is not str or len(data['name'])>32:raise DocumentError('Bounded int32/text record required')
 code='function transform(data):\n    return {"count": data["count"], "name": data["name"]}\nlet result = transform('+repr(data)+')\n'
 tree=parse(code)
 # Structural inspection binds both actual emitted accesses to their named
 # typed fields. No foreign source/runtime call exists in emitted USL.
 fn=tree.body[0];ret=fn.body[0].value
 if [ast.literal_eval(k) for k in ret.keys]!=['count','name'] or [ast.literal_eval(v.slice) for v in ret.values]!=['count','name']:raise DocumentError('Emitted record AST differs from field intent')
 return code

def sed_original(source,inputs):
 admitted('sed',source)
 with tempfile.TemporaryDirectory(prefix='usl-sed-') as folder:
  p=Path(folder);(p/'inputs.json').write_text(json.dumps(inputs));(p/'run.py').write_text('import json,subprocess,sys\nx=json.load(open("inputs.json"));out=[]\nfor data in x:\n r=subprocess.run(["sed","s/alpha/beta/g"],input=data+"\\n",text=True,capture_output=True,check=True);out.append(r.stdout.removesuffix("\\n"))\nprint(json.dumps(out))\n')
  r=program([shutil.which('python'),'run.py'],p);return json.loads(r['stdout']),r

def negative_native(language):
 with tempfile.TemporaryDirectory(prefix='usl-category-bad-') as folder:
  p=Path(folder)
  if language in {'antlr','antlr-java'}:
   (p/'Bad.g4').write_text('grammar Bad; start: (;');cp=os.pathsep.join(str(f) for f in sorted((PREFIX/'sysroot/usr/share/java').glob('*.jar')));argv=['java','-cp',cp,'org.antlr.v4.Tool','Bad.g4']
  elif language in {'protobuf','capnp'}:
   (p/'bad').write_text('!invalid');argv=provider_command('protoc')+['--proto_path=.','--descriptor_set_out=x','bad'] if language=='protobuf' else provider_command('capnp')+['compile','-o-','bad']
  elif language=='meson':
   (p/'meson.build').write_text('project(!!!)');argv=['meson','setup','build','--wrap-mode=nodownload']
  elif language=='nginx':
   (p/'bad').write_text('invalid_directive;');argv=['nginx','-p',str(p)+'/', '-c',str(p/'bad'),'-t']
  elif language=='scdoc':
   # Upstream scdoc's first line must be a well-formed NAME(section).
   (p/'bad.py').write_text('import subprocess,sys\nr=subprocess.run([sys.argv[1]],input=b"invalid\\n",capture_output=True);sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)');argv=[shutil.which('python'),'bad.py',str(PREFIX/'sysroot/usr/bin/scdoc')]
  else:argv=['sed','s/[invalid/beta/g']
  r=execute(argv,cwd=p,timeout=15)
  return {'case':'actual_upstream_malformed_syntax','rejected':r['returncode']!=0,'native_observation':r}

def dependency_identity(language):
 paths={'implementation':Path(__file__)};providers={}
 if language in {'antlr','antlr-java'}:
  for p in (PREFIX/'sysroot/usr/share/java').glob('*.jar'):paths[p.name]=p
  for name in ('java','javac'):paths[name]=Path(shutil.which(name))
 elif language in {'protobuf','capnp'}:
  name='protoc' if language=='protobuf' else 'capnp';paths[name]=PREFIX/'sysroot/usr/bin'/name
  package='protobuf' if language=='protobuf' else 'pycapnp';d=importlib.metadata.distribution(package)
  providers[package]={'version':d.version,'RECORD_sha256':digest(d.read_text('RECORD') or '')}
  for p in d.files or []:
   if str(p).endswith(('.py','.so')) and Path(d.locate_file(p)).is_file():paths[str(p)]=Path(d.locate_file(p))
 else:
  name='scdoc' if language=='scdoc' else language;paths[name]=PREFIX/'sysroot/usr/bin/scdoc' if language=='scdoc' else Path(shutil.which(name))
 return {'files':{k:hashlib.sha256(p.resolve().read_bytes()).hexdigest() for k,p in sorted(paths.items())},'providers':providers,'complete_dependency_closure_qualified':False}

def qualify_one(language):
 source=SOURCES[language];negative=[];cases=[];receipts=[];code='';kind='schema_processing'
 if language in {'antlr','antlr-java'}:
  inputs=[''.join(s) for n in range(4) for s in itertools.product('abcx',repeat=n)]
  values,receipt=antlr_original(language,source,inputs);receipts.append(receipt);code='function accepts(data):\n    return data == "ab"\n'
  for data,observed in zip(inputs,values):
   want=data=='ab';value=Interpreter().run(code+'let result = accepts('+repr(data)+')\n').variables['result'];cases.append({'input':data,'native':observed,'generated_USL':value,'independent_expected':want,'passed':type(value) is bool and value==observed==want})
  kind='grammar_processing'
 elif language in {'protobuf','capnp'}:
  inputs=[{'count':n,'name':s} for n,s in [(-2**31,'edge'),(-7,'alpha'),(0,''),(2**31-1,'beta')]]
  values,receipt=schema_original(language,source,inputs);receipts.append(receipt)
  for data,observed in zip(inputs,values):
   code=generated_record(data);value=Interpreter().run(code).variables['result'];cases.append({'input':data,'native':observed,'generated_USL':value,'independent_expected':copy.deepcopy(data),'passed':typed(data)==typed(observed)==typed(value),'generated_USL_source':code})
 elif language=='sed':
  inputs=['','alpha','alphaalpha','xalphay','Alpha','alph','beta'];values,receipt=sed_original(source,inputs);receipts.append(receipt)
  expected=['','beta','betabeta','xbetay','Alpha','alph','beta']
  # No foreign replace capability: executable USL scans the complete text.
  code='function transform(data):\n    let out = ""\n    let i = 0\n    while i < len(data):\n        if i + 4 < len(data) and data[i] == "a" and data[i+1] == "l" and data[i+2] == "p" and data[i+3] == "h" and data[i+4] == "a":\n            out = out + "beta"\n            i = i + 5\n        else:\n            out = out + data[i]\n            i = i + 1\n    return out\n'
  for data,observed,want in zip(inputs,values,expected):
   value=Interpreter().run(code+'let result = transform('+repr(data)+')\n').variables['result'];cases.append({'input':data,'native':observed,'generated_USL':value,'independent_expected':want,'passed':value==observed==want})
  kind='text_transformation'
 else:
  expected={'meson':[{'name':'count','type':'integer','value':7}],'nginx':{'syntax_valid':True,'server_started':False},'scdoc':{'sections':['NAME'],'name_text':'item - alpha'}}[language]
  value,receipt=concrete_original(language,source);receipts.extend(receipt);code='let result = '+repr(value)+'\n';generated=Interpreter().run(code).variables['result']
  if ast.literal_eval(parse(code).body[0].value)!=expected:raise DocumentError('Actual emitted concrete AST violates independent intent')
  cases.append({'native':value,'generated_USL':generated,'independent_expected':expected,'passed':typed(value)==typed(generated)==typed(expected)})
  kind='configuration_validation' if language=='nginx' else 'configuration_processing' if language=='meson' else 'document_processing'
 for label,bad in [('unmodelled_effect',source+'\nUNMODELLED_EFFECT')]:
  try:admitted(language,bad);rejected=False
  except ValueError:rejected=True
  negative.append({'case':label,'rejected':rejected})
 negative.append(negative_native(language))
 return {'catalog_id':language,'profile_kind':kind,'passed':all(c['passed'] for c in cases) and all(c['rejected'] for c in negative),'source':source,'generated_USL_source':code,'cases':cases,'negative_cases':negative,'native_observations':receipts,'original_engine_evaluations':len(cases),'generated_USL_executions':len(cases),'native_executions':len(receipts),'provider_identity':dependency_identity(language),'full_standard_qualified':False,'scope':'Exact declared source and bounded category contract with real upstream processing and independently authored results. ANTLR Java literal recognizer; schema record roundtrip; Meson option introspection; nginx syntax validity only; scdoc section/text projection; sed literal substitution samples. No full language, wire-format translator, nginx request semantics or arbitrary-program proof claimed.'}
