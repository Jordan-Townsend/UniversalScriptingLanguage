"""Factored language preparation; inventories do not confer semantic qualification."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,ThreadPoolExecutor,as_completed
from functools import lru_cache
import hashlib,html,importlib.metadata,inspect,json,os,re,sys,threading,time,urllib.parse,urllib.request,uuid

ROOT=Path(__file__).resolve().parent

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def addon_identity():return digest({p.name:file_sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in {'.py','.usl'}})
def file_sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
class CAS:
 def __init__(self,directory):self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
 def put(self,data):
  key=hashlib.sha256(data).hexdigest();p=self.directory/key
  if not p.exists():
   temp=self.directory/('.'+uuid.uuid4().hex);temp.write_bytes(data);temp.replace(p)
  if file_sha(p)!=key:raise ValueError('Preparation CAS corruption')
  return key
 def get(self,key):
  if not re.fullmatch('[0-9a-f]{64}',key):raise ValueError('Invalid CAS identity')
  data=(self.directory/key).read_bytes()
  if hashlib.sha256(data).hexdigest()!=key:raise ValueError('Preparation CAS corrupted bytes')
  return data

def initialize(source_root):sys.path.insert(0,source_root)
@lru_cache(maxsize=1024)
def lexer_artifact(alias):
 from pygments.lexers import get_lexer_by_name
 lexer=get_lexer_by_name(alias);cls=type(lexer);path=Path(inspect.getfile(cls));source=inspect.getsource(cls)
 keywords=set();regexes=[];rule_count=0
 for state,rules in getattr(lexer,'tokens',{}).items():
  for rule in rules:
   if not isinstance(rule,tuple) or len(rule)<2:continue
   rule_count+=1;pattern,action=rule[:2]
   if not str(action).startswith('Token.Keyword'):continue
   words=getattr(pattern,'words',None)
   if words is not None:keywords.update(str(w) for w in words)
   elif isinstance(pattern,str):regexes.append({'state':state,'pattern':pattern,'token':str(action)})
 return {'provider':'Pygments','version':importlib.metadata.version('Pygments'),'module':cls.__module__,'class':cls.__qualname__,
 'source_module_sha256':file_sha(path),'class_source_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'declared_word_keywords':sorted(keywords),'other_keyword_regexes':regexes,'lexer_rule_count':rule_count,
 'complete_keyword_set_proved':False,'semantic_rules_inferred':False,'syntax_highlighting_is_not_a_compiler':True}

@lru_cache(maxsize=1024)
def parser_artifact(name):
 import tree_sitter_language_pack as pack
 language=pack.get_parser(name).language
 nodes=[{'name':language.node_kind_for_id(i),'named':language.node_kind_is_named(i)} for i in range(language.node_kind_count) if language.node_kind_for_id(i) is not None]
 fields=[language.field_name_for_id(i) for i in range(1,language.field_count+1)]
 terminals=sorted({n['name'] for n in nodes if not n['named'] and re.fullmatch('[A-Za-z_][A-Za-z_0-9]*',n['name'])})
 return {'provider':'tree-sitter-language-pack','version':importlib.metadata.version('tree-sitter-language-pack'),'grammar':name,
 'ABI_version':language.abi_version,'nodes':nodes,'fields':fields,'identifier_terminals':terminals,
 'schema_sha256':digest({'nodes':nodes,'fields':fields,'terminals':terminals}),
 'semantic_rules_inferred':False,'native_execution_or_frontend_lowering_qualified':False}

def prepare_one(request):
 row,parser_name,skill_sources=request;started=time.monotonic();record={'catalog_id':row['catalog_id'],'family':row['family'],'original_catalog':row['original_catalog']}
 lexical=None;parser=None;issues=[]
 if row['catalog_id']!='usl':
  try:lexical=lexer_artifact(row['aliases'][0])
  except Exception as e:issues.append({'step':'lexer_inventory','error':type(e).__name__+': '+str(e)[:400]})
 if parser_name:
  try:parser=parser_artifact(parser_name)
  except Exception as e:issues.append({'step':'parser_schema','error':type(e).__name__+': '+str(e)[:400]})
 from skills import apply
 counts=[len(lexical['declared_word_keywords']) if lexical else 0,len(parser['nodes']) if parser else 0,lexical['lexer_rule_count'] if lexical else 0]
 execution=apply(skill_sources['list_sum'],'list[int]','int',counts,sum(counts))
 flags=[1 if lexical else -1,1 if parser else -1,1 if row['scoped_profile'] else -1]
 readiness=apply(skill_sources['count_nonnegative'],'list[int]','int',flags,sum(n>=0 for n in flags))
 valid=apply(skill_sources['all_nonnegative'],'list[int]','bool',counts,all(n>=0 for n in counts))
 record.update(lexer=lexical,parser_schema=parser,issues=issues,existing_scope=row['scope_kind'],already_scoped=row['scoped_profile'],
 specification_profile=row['specification_profile'],native_tool_requirement=row['original_native_tool_requirement'],external_dependencies=row['external_dependencies'],
 ordered_steps=row['ordered_steps'],obligation_dimensions=row['obligation_dimensions'],
 learned_kernel_applications={'inventory_sum':execution,'metadata_count':readiness,'nonnegative_counts':valid},
 inventory_prepared=True,normative_preparation_complete=False,full_standard_qualified=False,
 elapsed_seconds=time.monotonic()-started)
 return record

class HTTPSRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,request,fp,code,msg,headers,newurl):
  if urllib.parse.urlsplit(newurl).scheme!='https':raise ValueError('Non-HTTPS redirect rejected')
  return super().redirect_request(request,fp,code,msg,headers,newurl)

def retrieve(request):
 url,cache_directory=request;started=time.monotonic()
 result={'url':url,'retrieved':False,'normative_standard_audited':False,'license_reviewed':False}
 try:
  parsed=urllib.parse.urlsplit(url)
  if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password or parsed.hostname in ('localhost','127.0.0.1','::1'):raise ValueError('Only public credential-free HTTPS references admitted')
  url=urllib.parse.urlunsplit(('https',parsed.netloc,parsed.path,parsed.query,''));opener=urllib.request.build_opener(HTTPSRedirect())
  # Use stdlib identification. One diagnostic succeeded after a custom-UA503;
  # later both failed, so the request header is not a proved failure cause.
  req=urllib.request.Request(url)
  with opener.open(req,timeout=8) as response:
   body=response.read(4194305)
   if len(body)>4194304:raise ValueError('Reference exceeds4MiB preparation snapshot budget; audited chapter selection required')
   final=response.url
   if urllib.parse.urlsplit(final).scheme!='https':raise ValueError('TLS provenance required')
   content=response.headers.get('Content-Type','');status=response.status
  key=CAS(cache_directory).put(body);title=None;headings=0
  if 'html' in content:
   from lxml import etree
   tree=etree.HTML(body,parser=etree.HTMLParser(no_network=True))
   if tree is not None:
    titles=tree.xpath('//title');title=' '.join(' '.join(t.itertext()) for t in titles)[:90] or None
    headings=len(tree.xpath('//h1|//h2|//h3'))
  result.update(retrieved=True,final_url=final,HTTP_status=status,content_type=content,bytes=len(body),sha256=key,title=title,heading_count=headings,
   raw_snapshot_in_private_cache_only=True,semantic_understanding_claimed=False)
 except Exception as error:result['error']=type(error).__name__+': '+str(error)[:500]
 result['elapsed_seconds']=time.monotonic()-started
 return result

def execute(source_root,output,cache_directory,workers=4,fetch=True):
 source_root=Path(source_root).resolve();sys.path.insert(0,str(source_root))
 from usl_systems.resources import discover
 from usl_systems.language import Interpreter
 from usl_systems.catalog_parser import mappings
 from usl_systems.batch_multiplex import source_identity
 from skills import apply
 output=Path(output);output.mkdir(parents=True,exist_ok=True);cas=CAS(output/'objects')
 plan=json.loads((source_root/'docs/ALL_LANGUAGE_ACTION_PLAN.json').read_text());rows=plan['entries']
 assert len(rows)==607 and len({r['catalog_id'] for r in rows})==607 and sum(r['original_catalog'] for r in rows)==606
 assert plan['summary']['all_scoped_ids']==183
 bank=json.loads((ROOT/'results/skill-bank.json').read_text());assert bank['passed'] and bank['completed']==14
 skills={r['name']:r['actual_skill']['document']['source'] for r in bank['records']}
 from pools import capacity
 admission=capacity(workers,128*1024**2);cpu=discover()['cpu_effective'];workers=admission['workers'];initial=source_identity();addon_initial=addon_identity();started=time.monotonic();records=[];refs=[]
 parser_names=mappings();candidate_urls=sorted({r['reference_metadata'].get('url') for r in rows if r['reference_metadata'].get('url')})
 def publish(stage):
  elapsed=time.monotonic()-started
  progress={'schema':'usl.all-language.preparation-progress.v1','stage':stage,'original_ids':606,'total_ids':607,'ids_inventory_completed':len(records),
   'working_on_catalog_ids':607,'ids_not_yet_inventoried':607-len(records),'reference_groups_completed':len(refs),'reference_groups_total':len(candidate_urls),
   'actual_worker_limit':workers,'elapsed_seconds':elapsed,'full_instantiation_ETA_seconds':None,'original_scope_count_unchanged':183,
   'original_ids_without_scoped_profile':423,'full_standards_qualified':0}
  temporary=output/'progress.tmp';temporary.write_text(json.dumps(progress,indent=2)+'\n');temporary.replace(output/'progress.json')
 def inventory_all():
  with ProcessPoolExecutor(max_workers=workers,initializer=initialize,initargs=(str(source_root),)) as pool:
   jobs={pool.submit(prepare_one,(r,parser_names.get(r['catalog_id'],{}).get('grammar') if parser_names.get(r['catalog_id'],{}).get('available') else None,skills)):r['catalog_id'] for r in rows}
   for future in as_completed(jobs):
    record=future.result();body=json.dumps(record,sort_keys=True,separators=(',',':')).encode();key=cas.put(body)
    records.append({'catalog_id':record['catalog_id'],'family':record['family'],'evidence_sha256':key,'record':record});publish('catalog_inventory')
  return {'passed':len(records)==607 and len({r['catalog_id'] for r in records})==607,'count':len(records)}
 def references_all():
  if fetch:
   with ThreadPoolExecutor(max_workers=workers) as pool:
    jobs=[pool.submit(retrieve,(url,str(cache_directory))) for url in candidate_urls]
    for future in as_completed(jobs):refs.append(future.result());publish('reference_snapshot')
  return {'completed':len(refs),'retrieved':sum(r['retrieved'] for r in refs),'not_retrieved':sum(not r['retrieved'] for r in refs),'normative_audits_complete':0}
 def finish():
  ref_index={r['url']:r for r in refs};families={}
  for item in records:
   record=item['record'];url=next(r['reference_metadata'].get('url') for r in rows if r['catalog_id']==item['catalog_id']);record['reference_snapshot']=ref_index.get(url)
   family=record['family'];families.setdefault(family,[]).append(record)
   assert json.loads(cas.get(item['evidence_sha256']))['catalog_id']==item['catalog_id']
  counts=[len(v) for v in families.values()];aggregate=apply(skills['list_sum'],'list[int]','int',counts,607)
  factored={'family_sets':len(families),'sum_of_family_counts':607,'original_obligation_dimensions':606*18,'per_ID_ordered_steps':15,'total_ordered_steps':607*15,
   'lossless_factor_join_verified':sum(counts)==607,'family_sharing_does_not_transfer_semantic_guarantees':True}
  for item in records:
   record=item['record'];body=json.dumps(record,sort_keys=True,separators=(',',':')).encode();item['evidence_sha256']=cas.put(body)
   assert json.loads(cas.get(item['evidence_sha256']))==record
  report={'schema':'usl.all-language.preparation.v1','version':'4.11.0-preparation','passed':len(records)==607 and source_identity()==initial and addon_identity()==addon_initial,
   'base_version':'4.10.0','base_source_identity':initial,'source_unchanged_during_run':source_identity()==initial,'addon_source_identity':addon_initial,'addon_unchanged_during_run':addon_identity()==addon_initial,'elapsed_seconds':time.monotonic()-started,
   'original_ids_inventoried':606,'extra_USL_inventoried':1,'original_scoped_profiles':183,'remaining_original_ids_without_scope':423,
   'normative_preparation_complete':0,'full_standards_qualified':0,'entity_tracks_complete':0,'prepared_USL_skills':14,
   'keyword_metadata_inventories':sum(r['record']['lexer'] is not None for r in records),'actual_parser_schemas':sum(r['record']['parser_schema'] is not None for r in records),
   'actual_USL_kernel_applications':3*len(records)+1,'exact_all_ID_graph_join':factored,'actual_USL_family_aggregation':aggregate,
   'resource_pool_contract':{'executor':'local_process','capacity_cpu':cpu,'workers':workers,'admission':admission,'requests_serializable_JSON':True,'native_compiler_host_requirements_remain_per_ID':True,'qualified_hosts':['current Linux/POSIX host'],'additional_hardware_or_remote_pools_qualified':False},
   'references':refs,'retrieved_reference_groups':sum(r['retrieved'] for r in refs),'all_evidence_CAS_hashes_restored':True,'records':sorted(records,key=lambda r:r['catalog_id']),
   'preparation_scope':'Catalog, public lexical/parser metadata, reference provenance and required semantic/host actions. Reading source metadata or retrieving documents does not complete normative audit or native semantic implementation.'}
  (output/'preparation.json').write_text(json.dumps(report,indent=2)+'\n');publish('complete')
  return {k:v for k,v in report.items() if k not in ('records','references')}
 supervisor='let inventory = prepare_catalog_all()\nassert inventory["passed"]\nassert inventory["count"] == 607\nlet references = snapshot_public_references()\nlet result = finish_preparation()\nassert result["passed"]\nprint("original IDs inventoried", result["original_ids_inventoried"])\nprint("verified USL skills", result["prepared_USL_skills"])\nprint("remaining original IDs without scope", result["remaining_original_ids_without_scope"])\n'
 publish('starting')
 observed=Interpreter(capabilities={'prepare_catalog_all':inventory_all,'snapshot_public_references':references_all,'finish_preparation':finish},timeout=3600,max_ops=100000).run(supervisor)
 (output/'supervisor.json').write_text(json.dumps({'source':supervisor,'stdout':observed.output,'operations':observed.operations,'actual_USL_supervision':True},indent=2)+'\n')
 return observed.variables['result']
