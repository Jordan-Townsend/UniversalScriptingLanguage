"""New exact native profiles; preserve the released base without monkeypatches.

Proofs concern the authored canonical int32 model. LLVM/GNU/NASM/Vim/LS
implementations and the x86-64 System V ABI remain versioned trust boundaries.
"""
from pathlib import Path
import ast,copy,hashlib,json,os,re,shutil,tempfile
from usl_systems.semantic_next_functions import NextFunctionFrontend
from usl_systems.semantic_more_functions import Arithmetic,PARSER
from usl_systems.semantic_ir_v2 import SemanticTranslationError,fingerprint
from usl_systems.semantic_translation import _require
from usl_systems.intent_contracts import prove_expression
from usl_systems.bounded_process import execute

PREFIX=Path(os.environ.get('USL_V411_PROVIDERS','/workspace/.onboarding/expansion-v411'))
LLVM=Path(os.environ.get('USL_LLVM_ROOT','/workspace/.onboarding/sysroot/usr/lib/llvm-19/bin'))
LANGUAGES={'llvm','gas','nasm','vim','livescript','promela'}

def canonical(e):return ast.unparse(ast.parse(e,mode='eval').body)
def assembly(e):
 lines=[]
 def visit(n):
  if isinstance(n,ast.Name) and n.id=='value':lines.append('mov eax, edi')
  elif isinstance(n,ast.Constant) and type(n.value) is int:lines.append('mov eax, '+str(n.value))
  elif isinstance(n,ast.UnaryOp):
   visit(n.operand)
   if isinstance(n.op,ast.USub):lines.append('neg eax')
  else:
   visit(n.left);lines.append('push rax');visit(n.right);lines.append('pop rcx')
   lines.extend({ast.Add:['add eax, ecx'],ast.Sub:['sub ecx, eax','mov eax, ecx'],ast.Mult:['imul eax, ecx']}[type(n.op)])
 visit(ast.parse(e,mode='eval').body);return lines

def llvm_body(e):
 lines=[]
 def visit(n):
  if isinstance(n,ast.Name) and n.id=='value':return '%value'
  if isinstance(n,ast.Constant) and type(n.value) is int:return str(n.value)
  if isinstance(n,ast.UnaryOp):
   right=visit(n.operand)
   if isinstance(n.op,ast.UAdd):return right
   left,op='0','sub'
  else:left,right,op=visit(n.left),visit(n.right),{ast.Add:'add',ast.Sub:'sub',ast.Mult:'mul'}[type(n.op)]
  name='%t'+str(len(lines));lines.append(name+' = '+op+' i32 '+left+', '+right);return name
 result=visit(ast.parse(e,mode='eval').body);return lines+['ret i32 '+result]

def source_for(language,expression):
 e=canonical(expression)
 if language in {'gas','nasm'}:
  header='.intel_syntax noprefix\n.text\n.globl transform\ntransform:\n' if language=='gas' else 'bits 64\nsection .text\nglobal transform\ntransform:\n'
  return header+'\n'.join('    '+line for line in assembly(e)+['ret'])
 if language=='llvm':return 'define i32 @transform(i32 %value) {\n'+'\n'.join('  '+line for line in llvm_body(e))+'\n}'
 if language=='vim':return 'function! Transform(value)\n  return '+re.sub(r'\bvalue\b','a:value',e)+'\nendfunction'
 if language=='livescript':return 'transform = (value) -> '+e
 if language=='promela':return 'inline transform(value, result) { result = '+e+'; }'
 raise SemanticTranslationError('Unknown exact native ID')

def model(language,source):
 if language in {'vim','livescript','promela'}:
  pattern={'vim':r'function! Transform\(value\)\n  return (.*)\nendfunction','livescript':r'transform = \(value\) -> (.*)','promela':r'inline transform\(value, result\) \{ result = (.*); \}'}[language]
  match=re.fullmatch(pattern,source)
  _require(match is not None,'Entire source grammar rejected')
  return Arithmetic().transform(PARSER.parse(match[1].replace('a:value','value')))
 if language=='llvm':
  _require(source.startswith('define i32 @transform(i32 %value) {\n') and source.endswith('\n}'),'Exact LLVM envelope required')
  names={'%value':'value'};result=None
  for line in source.splitlines()[1:-1]:
   m=re.fullmatch(r'  (%t[0-9]+) = (add|sub|mul) i32 (%[A-Za-z0-9]+|-?[0-9]+), (%[A-Za-z0-9]+|-?[0-9]+)',line)
   def operand(s):
    if s in names:return names[s]
    _require(bool(re.fullmatch(r'-?(0|[1-9][0-9]*)',s)),'Unbound LLVM operand')
    return s
   if m:
    _require(result is None and m[1] not in names,'Invalid SSA assignment')
    a,b=operand(m[3]),operand(m[4]);names[m[1]]='('+a+{'add':'+','sub':'-','mul':'*'}[m[2]]+b+')'
   else:
    m=re.fullmatch(r'  ret i32 (%[A-Za-z0-9]+|-?[0-9]+)',line);_require(m is not None and result is None,'Unmodelled LLVM effect/instruction')
    result=operand(m[1])
  _require(result is not None,'Missing LLVM return');return result
 header=source_for(language,'value').split('    mov eax, edi')[0]
 _require(source.startswith(header),'Exact assembly envelope required')
 registers={'edi':'value'};stack=[];returned=False
 for line in source[len(header):].splitlines():
  _require(not returned,'Instructions after return')
  instruction=line.removeprefix('    ')
  m=re.fullmatch(r'mov (eax|ecx), (edi|ecx|-?(?:0|[1-9][0-9]*))',instruction)
  if m:
   operand=m[2];_require(operand in registers or re.fullmatch(r'-?(0|[1-9][0-9]*)',operand),'Unbound register')
   registers[m[1]]=registers.get(operand,operand)
  elif instruction=='push rax':_require('eax' in registers,'Uninitialized eax');stack.append(registers['eax'])
  elif instruction=='pop rcx':_require(bool(stack),'Stack underflow');registers['ecx']=stack.pop()
  elif instruction=='neg eax':_require('eax' in registers,'Uninitialized eax');registers['eax']='(-'+registers['eax']+')'
  elif instruction in {'add eax, ecx','imul eax, ecx','sub ecx, eax'}:
   _require('eax' in registers and 'ecx' in registers,'Uninitialized arithmetic register')
   dest,left,right,op=('ecx','ecx','eax','-') if instruction.startswith('sub') else ('eax','eax','ecx','+' if instruction.startswith('add') else '*')
   registers[dest]='('+registers[left]+op+registers[right]+')'
  elif instruction=='ret':_require(not stack and 'eax' in registers,'Unbalanced stack or missing result');returned=True
  else:raise SemanticTranslationError('Unmodelled assembly operation')
 _require(returned,'Missing return');return registers['eax']

def dependency_identity(language):
 paths={'gcc':shutil.which('gcc')}
 if language=='llvm':paths.update(llvm_as=str(LLVM/'llvm-as'),llc=str(LLVM/'llc'))
 elif language in {'gas','nasm'}:paths[language]=shutil.which('as' if language=='gas' else 'nasm')
 elif language=='vim':paths['vim']=str(PREFIX/'sysroot/usr/bin/vim.basic')
 elif language=='promela':paths['spin']=str(PREFIX/'sysroot/usr/bin/spin')
 else:
  paths['node']=shutil.which('node');paths['package_lock']=str(PREFIX/'node/package-lock.json')
  for p in sorted((PREFIX/'node/node_modules').rglob('*')):
   if p.is_file() and p.suffix in {'.js','.json'}:paths[str(p.relative_to(PREFIX))]=str(p)
 return {'files':{n:{'path':str(Path(p).resolve()),'sha256':hashlib.sha256(Path(p).resolve().read_bytes()).hexdigest()} for n,p in paths.items() if p},
 'complete_dependency_closure_qualified':False,'host_platform':'Linux x86_64 System V' if language in {'gas','nasm'} else 'current Linux host'}

class NativeFrontend(NextFunctionFrontend):
 def __init__(self,language,source,function,contract,invocations):
  _require(language in LANGUAGES and function=='transform','Exact native profile ID required')
  _require(type(source) is str and 0<len(source.encode())<=16384,'Bounded entire source required')
  try:expression=model(language,source)
  except (KeyError,IndexError,TypeError) as e:raise SemanticTranslationError('Invalid native operation sequence') from e
  # Addition/multiplication in the assembly model reverse operand order. They
  # are commutative, but reconstruct the EXACT instructions before admission.
  if language not in {'gas','nasm'}:_require(source==source_for(language,expression),'Noncanonical native source rejected')
  else:
   _require(all(re.fullmatch(r'    (mov eax, (edi|ecx|-?(0|[1-9][0-9]*))|push rax|pop rcx|neg eax|add eax, ecx|imul eax, ecx|sub ecx, eax|ret)',s) for s in source.splitlines()[4:]),'Exact assembly spelling required')
  _require(set(contract.get('inputs',{}))=={'value'},'One bounded input required')
  proof=prove_expression(expression,contract);_require(proof['proved'],'Source fails intent or intermediate int32 bounds')
  _require(type(invocations) is list and 1<=len(invocations)<=32,'Independent invocation contracts required')
  for row in invocations:
   _require(set(row)=={'arguments','expected_result','intent'} and type(row['arguments']) is list and len(row['arguments'])==1 and type(row['arguments'][0]) is int and type(row['expected_result']) is int and bool(row['intent']),'Exact independent invocation required')
   _require(contract['inputs']['value']['min']<=row['arguments'][0]<=contract['inputs']['value']['max'],'Invocation outside proof domain')
  self.language,self.source,self.function=language,source,function;self.contract,self.invocations=copy.deepcopy(contract),copy.deepcopy(invocations)
  self.expression,self.proof=expression,proof;self.parser={'provider':'Authored exact LLVM SSA / x86 symbolic execution / Lark arithmetic model','source_sha256':fingerprint(source)}
  self.admission=self.identity()
 def native_execute(self):
  self.check();lang=self.language;s=self.source;values=[r['arguments'][0] for r in self.invocations];build=[];identity=dependency_identity(lang)
  with tempfile.TemporaryDirectory(prefix='usl-v411-native-') as folder:
   p=Path(folder)
   if lang in {'gas','nasm','llvm'}:
    main='#include <stdio.h>\n_Static_assert(sizeof(int)==4,"int32 ABI required");\nextern int transform(int);\nint main(void){'+''.join('printf("%d\\n",transform('+str(v)+'));' for v in values)+'return 0;}'
    (p/'main.c').write_text(main)
    if lang=='llvm':
     (p/'skill.ll').write_text(s);build.append(execute([str(LLVM/'llvm-as'),'skill.ll','-o','skill.bc'],cwd=p,timeout=15));build.append(execute([str(LLVM/'llc'),'-filetype=obj','skill.bc','-o','skill.o'],cwd=p,timeout=15))
    else:
     (p/'skill.s').write_text(s+'\n')
     argv=['as','--64','skill.s','-o','skill.o'] if lang=='gas' else ['nasm','-f','elf64','skill.s','-o','skill.o']
     build.append(execute(argv,cwd=p,timeout=15))
    for r in build:_require(r['returncode']==0,'Native assembler/validator rejected original: '+r['stderr'])
    build.append(execute(['gcc','-O0','main.c','skill.o','-o','program'],cwd=p,timeout=20));argv=[str(p/'program')]
   elif lang=='vim':
    (p/'main.vim').write_text(s+'\ncall writefile(['+','.join('string(Transform('+str(v)+'))' for v in values)+'], "output")\nqa!\n')
    argv=[str(PREFIX/'sysroot/usr/bin/vim.basic'),'-Nu','NONE','-i','NONE','-n','-es','-S','main.vim']
   elif lang=='promela':
    (p/'main.pml').write_text(s+'\ninit { int value; int result;\n'+''.join('value = '+str(v)+'; transform(value, result); printf("%d\\n", result);\n' for v in values)+'}\n')
    build.append(execute([str(PREFIX/'sysroot/usr/bin/spin'),'-a','main.pml'],cwd=p,timeout=15));argv=[str(PREFIX/'sysroot/usr/bin/spin'),'-T','main.pml']
   else:
    (p/'main.ls').write_text(s+'\n'+''.join('console.log transform('+str(v)+')\n' for v in values))
    (p/'main.js').write_text('require('+json.dumps(str(PREFIX/'node/node_modules/livescript'))+').run(require("fs").readFileSync("main.ls","utf8"));')
    argv=['node','main.js']
   for r in build:_require(r['returncode']==0,'Native compiler/linker failed: '+r['stderr'])
   observed=execute(argv,cwd=p,timeout=25,track_descendant_sessions=True)
   raw=(p/'output').read_text() if lang=='vim' and (p/'output').is_file() else observed['stdout']
   if lang=='promela':
    _require(raw.endswith('1 process created\n'),'Unexpected Spin simulation termination protocol')
    raw=raw.removesuffix('1 process created\n')
   _require(all(re.fullmatch(r'[+-]?[0-9]+',line) for line in raw.splitlines()),'Native output protocol is not integer-only')
   actual=[int(s) for s in raw.splitlines()];expected=[r['expected_result'] for r in self.invocations]
   _require(dependency_identity(lang)==identity,'Native host changed during execution')
   return {'passed':observed['returncode']==0 and actual==expected,'actual':actual,'independent_expected':expected,'observations':[observed],'build':build,'original_native_program_executions':1,'original_host_identity':identity,'native_observations_replayed':False}

TASKS=[('double','value * 2','value+value',[(-7,-14),(0,0),(21,42),(9999,19998)]),('polynomial','value * value - 2 * value + 1','(value-1)*(value-1)',[(-7,64),(0,1),(1,0),(53,2704)]),('negation','-value + 3','3-value',[(-7,10),(0,3),(21,-18)])]
def qualify_one(language):
 rows=[];negative=[]
 for name,e,post,pairs in TASKS:
  contract={'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-10000,'max':10000}},'postcondition':'result == ('+post+')'}
  invocations=[{'arguments':[n],'expected_result':v,'intent':name+' independent signed integer contract'} for n,v in pairs]
  f=NativeFrontend(language,source_for(language,e),'transform',contract,invocations)
  for target in ('python','javascript'):rows.append(f.verify(target))
  if name=='double':
   for label,s,c in [('extra_effect',f.source+'\nUNMODELLED_EFFECT',contract),('wrong_intent',f.source,{**contract,'postcondition':'result ==91'}),('overflow',f.source,{**contract,'inputs':{'value':{'min':2**30,'max':2**30}}})]:
    try:NativeFrontend(language,s,'transform',c,invocations);rejected=False
    except ValueError:rejected=True
    negative.append({'case':label,'rejected':rejected})
   invalid=copy.copy(f);invalid.source={'vim':'function! Transform(value)\n  return a:value +\nendfunction','livescript':'transform = (value) -> (','llvm':'define i32 @transform(i32 %value) {\n  ret i32 unknown\n}','gas':'.text\ninvalid_opcode','nasm':'bits 64\ninvalid_opcode','promela':'inline transform(value, result) { result = (; }'}[language];invalid.admission=invalid.identity()
   try:r=invalid.native_execute();rejected=not r['passed'];diagnostic=r
   except ValueError as error:rejected=True;diagnostic=str(error)
   negative.append({'case':'actual_native_malformed_source','rejected':rejected,'diagnostic':diagnostic})
 return {'catalog_id':language,'profile_kind':'function_fragment','passed':all(r['passed'] for r in rows) and all(r['rejected'] for r in negative),'cases':rows,'negative_cases':negative,'native_executions':sum(r['native_executions'] for r in rows),'generated_USL_executions':len(rows),'full_standard_qualified':False,'scope':'Bounded single int32 canonical function; original SSA/instruction/expression model, emitted Python/JavaScript/USL AST intent proofs and fresh actual native execution. Other operations, ABI portability and full standards remain unqualified.'}
