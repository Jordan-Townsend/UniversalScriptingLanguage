"""Traceable failover to identified official documentation/upstream sources.

HTTP success is retrieval evidence only. No guessed search result or unrelated
200 page is silently promoted to a language's normative specification.
"""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import json,time
from prepare import retrieve

# Reviewed project identities and concrete documentation targets for this
# tranche. Exact version/dialect and normative chapter audits remain open.
ALTERNATIVES={
 'perl6':[('https://docs.raku.org/language','Raku official language index; replacement candidate for the observed404 /language.html'),('https://docs.raku.org/language/syntax','Raku official syntax chapter')],
 'llvm':[('https://raw.githubusercontent.com/llvm/llvm-project/llvmorg-19.1.7/llvm/docs/LangRef.rst','LLVM19.1.7 language reference')],
 'gas':[('https://sourceware.org/binutils/docs/as/','GNU assembler manual')],
 'nasm':[('https://www.nasm.us/doc/nasm00.html','NASM manual index')],
 'vim':[('https://raw.githubusercontent.com/vim/vim/v9.1.1230/runtime/doc/eval.txt','Vim9.1.1230 expression documentation')],
 'livescript':[('https://livescript.net/','LiveScript official language documentation')],
 'promela':[('https://spinroot.com/spin/Man/promela.html','Spin official Promela manual')],
 'sed':[('https://www.gnu.org/software/sed/manual/sed.html','GNU sed manual')],
 'ragel':[('https://www.colm.net/files/ragel/ragel-guide-6.10.pdf','Ragel6.10 official guide')],
 'smarty':[('https://www.smarty.net/docs/en/','Smarty official documentation; version audit remains required')],
 'twig':[('https://twig.symfony.com/doc/3.x/','Twig3 official documentation')],
 'velocity':[('https://velocity.apache.org/engine/2.4/user-guide.html','Apache Velocity2.4 guide; VelocityJS implementation differences remain required')],
 'antlr':[('https://github.com/antlr/antlr4/blob/4.9.2/doc/index.md','ANTLR4.9.2 upstream documentation')],
 'protobuf':[('https://protobuf.dev/programming-guides/proto3/','Protocol Buffers proto3 guide')],
 'capnp':[('https://capnproto.org/language.html','Capn Proto official schema language guide')],
 'meson':[('https://mesonbuild.com/Build-options.html','Meson build option documentation')],
 'nginx':[('https://nginx.org/en/docs/beginners_guide.html','nginx official configuration guide')],
 'scdoc':[('https://git.sr.ht/~sircmpwn/scdoc/tree/1.11.3/item/scdoc.5.scd','scdoc1.11.3 upstream source manual')],
 'tap':[('https://testanything.org/tap-version-13-specification.html','TAP13 specification')],
 'irc':[('https://www.rfc-editor.org/rfc/rfc2812.html','RFC2812 IRC client protocol')],
 'asc':[('https://www.rfc-editor.org/rfc/rfc4880.html','RFC4880 ASCII armor; updates and packet semantics remain unaudited')],
 'kmsg':[('https://raw.githubusercontent.com/torvalds/linux/v6.12/Documentation/ABI/testing/dev-kmsg','Linux6.12 dev-kmsg ABI documentation')],
 'notmuch':[('https://notmuchmail.org/doc/latest/man1/notmuch-search.html','notmuch search output documentation')],
 'postgres-explain':[('https://www.postgresql.org/docs/current/using-explain.html','PostgreSQL EXPLAIN documentation; exact server version remains unaudited')],
 'wdiff':[('https://www.gnu.org/software/wdiff/manual/wdiff.html','GNU wdiff manual')],
 'dpatch':[('https://manpages.debian.org/trixie/dpatch/dpatch.1.en.html','Debian dpatch manual')],
 'raw-token-data':[('https://pygments.org/docs/lexers/#pygments.lexers.special.RawTokenLexer','Pygments raw token format documentation')],
}
def family_key(identifier):
 if identifier.startswith('ragel'):return 'ragel'
 if identifier.startswith('antlr'):return 'antlr'
 if '+' in identifier and identifier.split('+')[-1] in ALTERNATIVES:return identifier.split('+')[-1]
 return identifier

def resolve(url,identifiers,cache):
 started=time.monotonic();attempts=[retrieve((url,cache))];chosen=attempts[0] if attempts[0]['retrieved'] else None
 alternatives=[]
 for identifier in identifiers:
  for candidate,identity in ALTERNATIVES.get(family_key(identifier),[]):
   if candidate!=url and candidate not in [a[0] for a in alternatives]:alternatives.append((candidate,identity))
 if chosen is None:
  for candidate,identity in alternatives:
   observation=retrieve((candidate,cache));observation['document_identity']=identity;attempts.append(observation)
   if observation['retrieved']:chosen=observation;break
 return {'url':url,'catalog_ids':identifiers,'retrieved':chosen is not None,'chosen':chosen,'attempts':attempts,'failed_primary_preserved':not attempts[0]['retrieved'],
 'replacement_identity_review':'Identified official project/reference targets, content/version/chapter applicability still requires audit' if chosen and chosen is not attempts[0] else None,
 'normative_standard_audited':False,'license_reviewed':False,'elapsed_seconds':time.monotonic()-started}

def run(source_root,cache,output,workers=4):
 rows=json.loads((Path(source_root)/'docs/ALL_LANGUAGE_ACTION_PLAN.json').read_text())['entries'];groups={}
 for row in rows:
  url=row['reference_metadata'].get('url')
  if url:groups.setdefault(url,[]).append(row['catalog_id'])
 records=[];started=time.monotonic()
 with ThreadPoolExecutor(max_workers=workers) as pool:
  futures=[pool.submit(resolve,url,ids,str(cache)) for url,ids in sorted(groups.items())]
  for future in as_completed(futures):records.append(future.result())
 report={'schema':'usl.authoritative-reference-resolution.v1','original_reference_groups':len(groups),'retrieved_groups':sum(r['retrieved'] for r in records),
 'actual_failovers_retrieved':sum(r['retrieved'] and r['failed_primary_preserved'] for r in records),'failed_groups':sum(not r['retrieved'] for r in records),'normative_audits_completed':0,
 'elapsed_seconds':time.monotonic()-started,'records':sorted(records,key=lambda r:r['url']),'raw_full_documents_in_private_cache_only':True}
 Path(output).write_text(json.dumps(report,indent=2)+'\n');return report

def retain_available_evidence(source_root,cache,current,earlier,output):
 """Keep last successful snapshots with later failures; no live-URL claim."""
 import hashlib,datetime
 from prepare import CAS
 from native_profiles import PREFIX
 plan=json.loads((Path(source_root)/'docs/ALL_LANGUAGE_ACTION_PLAN.json').read_text())['entries'];groups={}
 for row in plan:
  if row['reference_metadata'].get('url'):groups.setdefault(row['reference_metadata']['url'],[]).append(row['catalog_id'])
 reports=[json.loads(Path(p).read_text()) for p in [*earlier,current] if Path(p).exists()];history={}
 for index,report in enumerate(reports):
  for row in report['records']:history.setdefault(row['url'],[]).append({'run':index,'observation':row})
 result=[];cas=CAS(cache)
 for url,ids in sorted(groups.items()):
  observations=history.get(url,[]);chosen=None
  for item in reversed(observations):
   candidate=item['observation'].get('chosen')
   if candidate and candidate.get('retrieved'):
    try:cas.get(candidate['sha256']);chosen=candidate;break
    except (OSError,ValueError):continue
  result.append({'url':url,'catalog_ids':ids,'retrieved':chosen is not None,'chosen':chosen,'history':observations,
   'latest_attempt_succeeded':observations[-1]['observation']['retrieved'] if observations else False,
   'cached_snapshot_hash_verified':chosen is not None,'current_URL_liveness_claimed':False,'normative_standard_audited':False})
 local_candidates=[('vim',PREFIX/'sysroot/usr/share/vim/vim91/doc/eval.txt','Vim9.1.1230 expression manual'),
  ('ragel',Path('/workspace/.onboarding/sysroot/usr/share/doc/ragel/ragel-guide.pdf.gz'),'Ragel6.10 upstream guide from checksum-verified Debian package'),
  ('livescript',PREFIX/'node/node_modules/livescript/README.md','LiveScript1.6.0 upstream README; documentation entry point'),
  ('velocity',PREFIX/'node/node_modules/velocityjs/README.md','VelocityJS2.1.5 upstream README; dialect differences still require audit')]
 local=[]
 for identifier,path,identity in local_candidates:
  if path.is_file():local.append({'catalog_family_key':identifier,'document_identity':identity,'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'readable_local_reference':True,'normative_standard_audited':False})
 report={'schema':'usl.reference.available-evidence.v1','original_reference_groups':len(groups),'retrieved_groups':sum(r['retrieved'] for r in result),
  'latest_run_retrieved_groups':reports[-1]['retrieved_groups'],'hash_verified_historical_snapshots_retained':True,'network_failures_do_not_prove_dead_URLs':True,
  'retrieved_failovers':sum(r['chosen'] is not None and r['chosen']['url']!=r['url'] for r in result),'normative_audits_completed':0,
  'observed404_replacement_candidates':ALTERNATIVES['perl6'],'unverified_candidates_are_not_claimed_working':True,'local_references':local,'records':result}
 Path(output).write_text(json.dumps(report,indent=2)+'\n');return report
