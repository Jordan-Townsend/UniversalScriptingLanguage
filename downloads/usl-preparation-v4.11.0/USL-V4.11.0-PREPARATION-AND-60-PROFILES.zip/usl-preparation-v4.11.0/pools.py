"""Resource admission for logical .usl sets; no fixed four-worker limit."""
from pathlib import Path
import math
def memory_snapshot():
 fields={};events={}
 try:fields={k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())}
 except (OSError,ValueError):pass
 try:events={k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}
 except (OSError,ValueError):pass
 return {'statistics':fields,'events':events}
def capacity(requested=None,per_worker_bytes=256*1024**2):
 from usl_systems.resources import discover
 resources=discover();available=resources['memory_bytes']['available'];total=resources['memory_bytes']['total'];snapshot=memory_snapshot();fields=snapshot['statistics']
 reserve=max(512*1024**2,total//8)
 # Clean file pages are kernel-reclaimable even when currently active. Keep
 # a1/8 RAM working-set reserve; exclude anonymous/kernel/shared/dirty/pinned
 # memory. This avoids treating tens of GiB of clean cache as occupied slots.
 if fields:
  non_reclaimable=sum(fields.get(k,0) for k in ('anon','kernel','shmem','file_dirty','file_writeback','unevictable'))
  memory_budget=max(0,total-non_reclaimable-reserve)
 else:non_reclaimable=None;memory_budget=max(0,available-reserve)
 from policies import admission_policy
 if non_reclaimable is None:non_reclaimable=max(0,total-available)
 policy,receipt=admission_policy(total,non_reclaimable,per_worker_bytes,requested)
 if memory_budget!=policy['budget_bytes']:raise ValueError('Independent memory observation/admission mismatch')
 memory_slots=policy['slots']
 cpu_quota=max(1,math.ceil(resources['cpu_effective']))
 # Logical actors are unbounded by this executor count. Automatic admission
 # uses the live memory budget, not a fixed4/8/16 cohort. OS CPU quota remains
 # authoritative while ready programs time-share the admitted processes.
 wanted=memory_slots if requested is None else requested
 if type(wanted) is not int or wanted<1:raise ValueError('Requested physical executor count must be positive')
 return {'workers':policy['admitted'],'USL_admission_policy':receipt,'requested_workers':wanted,'cpu_equivalent_quota':resources['cpu_effective'],
 'logical_cpus_observed':resources['cpu_logical'],'memory_admission_budget_bytes':memory_budget,'per_worker_reservation_bytes':per_worker_bytes,
 'non_reclaimable_memory_bytes':non_reclaimable,'memory_working_set_reserve_bytes':reserve,'memory_snapshot':snapshot,'resources':resources,'GPUs_qualified':[],'remote_pools_registered':[],
 'logical_workers_are_not_limited_by_executor_slots':True,'physical_capacity_not_created_by_virtualization':True}
