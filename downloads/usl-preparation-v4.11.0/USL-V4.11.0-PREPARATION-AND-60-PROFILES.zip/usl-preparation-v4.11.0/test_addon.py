import asyncio,copy,json,tempfile,unittest,zlib
from pathlib import Path
from prepare import CAS,addon_identity,digest
import native_profiles as native,transcript_profiles as logs,category_profiles as categories,new_templates,ragel_profiles,workers,race

class IntegrityTests(unittest.TestCase):
 def test_cas_corruption_and_path_traversal(self):
  with tempfile.TemporaryDirectory() as directory:
   cas=CAS(directory);key=cas.put(b'correct');self.assertEqual(cas.get(key),b'correct');(Path(directory)/key).write_bytes(b'corrupt')
   with self.assertRaises(ValueError):cas.get(key)
   with self.assertRaises(ValueError):cas.get('../outside')
 def test_registry60_no_blocked_or_historical_ID(self):
  self.assertEqual(len(workers.registry()),60);self.assertNotIn('ragel-d',workers.registry());self.assertIn('ragel-d',workers.BLOCKED)
 def test_lossless_factored_join(self):
  rows=[{'catalog_id':n,'family':'family','obligation_dimensions':[{'dimension':'types','needed':['a','b']}]} for n in ('a','b')]
  result=race.join([race.worker((rows,True))],race.expected_bindings(rows))
  self.assertEqual(len(result['bindings']),2);self.assertEqual(result['physical_artifact_builds'],1)
 def test_lossy_and_duplicate_joins_rejected(self):
  rows=[{'catalog_id':'a','family':'f','obligation_dimensions':[{'dimension':'types'}]}];part=race.worker((rows,True));want=race.expected_bindings(rows)
  missing=copy.deepcopy(part);missing['bindings']=[]
  with self.assertRaises(ValueError):race.join([missing],want)
  with self.assertRaises(ValueError):race.join([part,part],want)
 def test_wrong_provider_payload_key_rejected(self):
  rows=[{'catalog_id':'a','family':'f','obligation_dimensions':[{'dimension':'types'}]}];part=race.worker((rows,True));key=next(iter(part['artifacts']));part['artifacts'][key]=zlib.compress(b'wrong provider/semantics')
  with self.assertRaises(ValueError):race.join([part],race.expected_bindings(rows))

class NativeAdmissionTests(unittest.TestCase):
 def contract(self):return {'schema':'usl.intent.integer.v1','inputs':{'value':{'min':-10000,'max':10000}},'postcondition':'result ==value*2'}
 def calls(self):return [{'arguments':[7],'expected_result':14,'intent':'independent double'}]
 def frontend(self,language='nasm',source=None,contract=None,calls=None):return native.NativeFrontend(language,source or native.source_for(language,'value * 2'),'transform',contract or self.contract(),calls or self.calls())
 def test_real_instruction_model_proved(self):
  for language in native.LANGUAGES:
   f=self.frontend(language);self.assertTrue(f.proof['proved']);self.assertTrue(f.translate('javascript')['emitted_AST_original_intent']['proved'])
 def test_forbidden_assembly_effects_and_unbalanced_stack(self):
  s=native.source_for('nasm','value * 2')
  for bad in [s.replace('    ret','    syscall\n    ret'),s.replace('    ret','    push rax\n    ret'),s.replace('    push rax','    pop rcx'),s+'\n    mov eax, 91']:
   with self.assertRaises(ValueError):self.frontend(source=bad)
 def test_llvm_unbound_operand_and_type_rejected(self):
  s=native.source_for('llvm','value * 2')
  for bad in [s.replace('%value, 2','%unknown, 2'),s.replace('mul i32','mul i64'),s.replace('ret i32','call i32')]:
   with self.assertRaises(ValueError):self.frontend('llvm',bad)
 def test_wrong_intent_and_intermediate_overflow(self):
  with self.assertRaises(ValueError):self.frontend(contract={**self.contract(),'postcondition':'result ==91'})
  # Final expression cancels, but the intermediate square exceeds signed32.
  with self.assertRaises(ValueError):self.frontend('llvm',native.source_for('llvm','value * value - value * value'),{**self.contract(),'inputs':{'value':{'min':50000,'max':50000}},'postcondition':'result ==0'})
 def test_mutated_proof_or_invocation_is_rejected(self):
  f=self.frontend();f.proof['proved']=False
  with self.assertRaises(ValueError):f.translate('python')
  f=self.frontend();f.invocations[0]['arguments'][0]=8
  with self.assertRaises(ValueError):f.translate('python')
 def test_out_of_contract_invocation_and_bool_rejected(self):
  for value in (10001,True):
   with self.assertRaises(ValueError):self.frontend(calls=[{'arguments':[value],'expected_result':2,'intent':'bad input'}])

class CategoryTests(unittest.TestCase):
 def test_exact_log_ID_inventory(self):self.assertEqual(set(logs.FIXTURES),logs.LANGUAGES);self.assertEqual(len(logs.LANGUAGES),29)
 def test_original_category_intents_and_fresh_USL(self):
  for identifier in sorted(logs.LANGUAGES):self.assertTrue(logs.qualify_one(identifier)['passed'],identifier)
 def test_crc24_independent_known_vector(self):
  self.assertEqual(logs.crc24(b'123456789'),0x21cf02)
  with self.assertRaises(ValueError):logs.native_process('asc',logs.FIXTURES['asc'][0].replace('=uhx7','=AAAA'))
 def test_log_boundary_counterexamples(self):
  bad=[('kmsg','192,1,2,-;alpha\n'),('notmuch',logs.FIXTURES['notmuch'][0].replace('2026-01-02','2026-99-99')),('pypylog',logs.FIXTURES['pypylog'][0].replace('[abd]','[aaa]')),('tap','TAP version 13\n1..2\nok 1 - alpha\n'),('vctreestatus','M   a/../secret\n')]
  for identifier,source in bad:
   with self.assertRaises(ValueError):logs.native_process(identifier,source)
 def test_template_wrong_intent_and_unmodelled_effect(self):
  for identifier in new_templates.LANGUAGES:
   source,intent=new_templates.fixture(identifier)
   with self.assertRaises(ValueError):new_templates.translate(identifier,source,[{'literal':'wrong'}])
   with self.assertRaises(ValueError):new_templates.translate(identifier,source+'#set($x=1)',intent)
 def test_schema_record_bounds_and_actual_field_AST(self):
  for data in [{'count':2**31,'name':'x'},{'count':True,'name':'x'},{'count':0,'name':'x','extra':1}]:
   with self.assertRaises(ValueError):categories.generated_record(data)
  self.assertIn('data["count"]',categories.generated_record({'count':-2**31,'name':'edge'}))
 def test_ragel_wrong_intent_and_unsupported_actions(self):
  with self.assertRaises(ValueError):ragel_profiles.translate(ragel_profiles.source_for('ab'),'abc')
  with self.assertRaises(ValueError):ragel_profiles.translate("%%{ machine item; main := 'ab' @{ evil(); }; }%%",'ab')
 def test_remote_resources_not_invented(self):
  from pools import capacity
  admission=capacity(16,64*1024**2);self.assertEqual(admission['remote_pools_registered'],[]);self.assertGreaterEqual(admission['workers'],1);self.assertLessEqual(admission['workers'],16)

class ConcurrentWorkerTests(unittest.IsolatedAsyncioTestCase):
 async def test_all_logical_actors_share_one_in_progress_build(self):
  flights=workers.SingleFlight();calls=[]
  async def build():calls.append(1);await asyncio.sleep(0);return 'exact'
  results=await asyncio.gather(*(flights.get('same-identity',build) for _ in range(607)))
  self.assertEqual(results,['exact']*607);self.assertEqual(calls,[1]);self.assertEqual(flights.requests,607)
 async def test_failed_shared_build_propagates_to_every_dependent(self):
  flights=workers.SingleFlight()
  async def fail():await asyncio.sleep(0);raise ValueError('counterexample')
  results=await asyncio.gather(*(flights.get('wrong',fail) for _ in range(30)),return_exceptions=True)
  self.assertTrue(all(isinstance(r,ValueError) for r in results));self.assertEqual(flights.builds,1)

class USLPolicyTests(unittest.TestCase):
 def test_resource_equation_independent_arithmetic(self):
  from policies import admission_policy
  decision,receipt=admission_policy(32*1024**3,2*1024**3,256*1024**2,None)
  self.assertEqual(decision['admitted'],104);self.assertTrue(receipt['actual_USL_execution'])
 def test_process_sharing_requires_audited_profile_kind(self):
  from policies import process_policy
  self.assertEqual(process_policy('pytb','transcript_profiles')[0]['group'],'shared-transcript-process')
  self.assertEqual(process_policy('gas','native_profiles')[0]['group'],'gas')
  with self.assertRaises(ValueError):workers.group_job(['gas','llvm'])
 def test_missing_implementation_is_not_promoted_by_policy(self):
  from policies import state_policy
  row={'catalog_id':'unknown','scoped_profile':False,'original_catalog':True};decision,_=state_policy(row,None)
  self.assertEqual(decision,{'state':'implementation_missing','full_dimension_qualified':False})
  decision,_=state_policy(row,{'passed':True});self.assertEqual(decision['state'],'fresh_scoped_evidence_full_dimension_open');self.assertFalse(decision['full_dimension_qualified'])

if __name__=='__main__':unittest.main()
