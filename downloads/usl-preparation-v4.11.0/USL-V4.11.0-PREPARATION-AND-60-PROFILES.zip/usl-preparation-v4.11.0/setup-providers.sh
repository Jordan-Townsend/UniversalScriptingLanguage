#!/usr/bin/env bash
set -euo pipefail
addon_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
provider_root="${USL_V411_PROVIDERS:-/workspace/.onboarding/expansion-v411}"
usl_activation="${USL_ENV_ACTIVATE:-/workspace/.onboarding/activate-usl.sh}"
if [[ -f "$usl_activation" ]]; then source "$usl_activation"; fi
export USL_V411_PROVIDERS="$provider_root"
mkdir -p "$provider_root/debs" "$provider_root/sysroot" "$provider_root/node"
# Linux/Debian13, existing base toolchains and trusted APT indexes required.
# APT verifies archive acquisition; every package is additionally hash-pinned.
python - "$addon_root" "$provider_root" <<'PY'
import hashlib,json,os,subprocess,sys
from pathlib import Path
addon,root=map(Path,sys.argv[1:]);records=json.loads((addon/'providers/debian-packages.json').read_text());environment=dict(os.environ)
config=Path('/workspace/.onboarding/apt/apt.conf')
if config.exists():environment.setdefault('APT_CONFIG',str(config))
known={hashlib.sha256(p.read_bytes()).hexdigest():p for p in (root/'debs').glob('*.deb')}
missing=[r for r in records if r['sha256'] not in known]
if missing:subprocess.run(['apt-get','download']+[r['package']+'='+r['version'] for r in missing],cwd=root/'debs',env=environment,check=True)
known={hashlib.sha256(p.read_bytes()).hexdigest():p for p in (root/'debs').glob('*.deb')}
for record in records:
 path=known.get(record['sha256'])
 if path is None:raise ValueError('Missing exact checksum-pinned archive: '+record['package'])
 subprocess.run(['dpkg-deb','--extract',str(path),str(root/'sysroot')],check=True)
print('Verified and extracted',len(records),'Debian packages into the separate provider prefix')
PY
python -m pip install --disable-pip-version-check --cache-dir /workspace/.onboarding/pip-cache -r "$addon_root/providers/python.lock.txt"
python -m pip check
cp "$addon_root/providers/package.json" "$addon_root/providers/package-lock.json" "$provider_root/node/"
npm ci --prefer-offline --prefix "$provider_root/node" --cache /workspace/.onboarding/npm-cache --ignore-scripts --no-audit --no-fund
printf '%s\n' 'Provider restoration completed. Run the documented fresh qualification; installation alone does not certify another host.'
