"""Actual USL control decisions; Python supplies observations and cross-checks."""
from pathlib import Path
import hashlib,time
from usl_systems.language import Interpreter
ROOT=Path(__file__).parent
def evaluate(name,capability,inputs):
 source=(ROOT/(name+'.usl')).read_text();started=time.perf_counter()
 result=Interpreter(capabilities={capability:lambda:inputs},timeout=3,max_ops=10000).run(source)
 return result.variables,{'source':name+'.usl','sha256':hashlib.sha256(source.encode()).hexdigest(),'operations':result.operations,'elapsed_seconds':time.perf_counter()-started,'actual_USL_execution':True}
def admission_policy(total,non_reclaimable,reservation,requested):
 values,receipt=evaluate('admission','admission_inputs',{'total_bytes':total,'non_reclaimable_bytes':non_reclaimable,'reservation_bytes':reservation,'requested_workers':requested or 0})
 answer=values['admission'];reserve=max(512*1024**2,total//8);budget=max(0,total-non_reclaimable-reserve);slots=max(1,budget//reservation);want=requested or slots
 if answer!={'working_set_reserve_bytes':reserve,'budget_bytes':budget,'slots':slots,'requested':want,'admitted':min(want,slots)}:raise ValueError('USL admission disagrees with independent arithmetic')
 return answer,receipt
def process_policy(identifier,module):
 pure=module=='transcript_profiles';values,receipt=evaluate('worker_policy','worker_inputs',{'catalog_id':identifier,'module':module,'capability':'bounded_pure_category_processing' if pure else 'native_effect_host','external_program_execution':not pure})
 answer=values['decision'];expected='shared-transcript-process' if pure else identifier
 if answer!={'group':expected,'separate_ID_evidence_required':True,'replay_native_observation':False}:raise ValueError('USL process-sharing contract violated')
 return answer,receipt
def state_policy(row,evidence):
 values,receipt=evaluate('worker_state','state_inputs',{'fresh':evidence is not None,'passed':bool(evidence and evidence['passed']),'prior_scope':row['scoped_profile'],'original':row['original_catalog']})
 decision=values['decision']
 if decision['full_dimension_qualified'] is not False:raise ValueError('Scoped evidence cannot qualify a full normative dimension')
 return decision,receipt
