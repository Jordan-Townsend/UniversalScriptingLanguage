"""Calibrated strategy race on pure all-ID obligation/CAS preparation.

Never reuses native observations. Every logical ID/dimension binding survives.
All costs include payload serialization, artifact construction, hashing and joins;
report loading/selection/auditing overhead separately and in end-to-end cost.
"""
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import hashlib,json,math,resource,time,zlib
from prepare import digest,addon_identity

def bytes_for(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def make_artifact(payload):
 raw=bytes_for(payload);packed=zlib.compress(raw,9);key=hashlib.sha256(raw).hexdigest()
 if zlib.decompress(packed)!=raw:raise ValueError('Pure artifact compression corruption')
 return key,packed
def worker(request):
 rows,local_factor=request;started=time.process_time();artifacts={};bindings=[];builds=0
 for row in rows:
  for obligation in row['obligation_dimensions']:
   payload={'family':row['family'],'obligation':obligation};raw=bytes_for(payload);key=hashlib.sha256(raw).hexdigest()
   if not local_factor or key not in artifacts:
    identity,packed=make_artifact(payload)
    if identity!=key:raise ValueError('Pure artifact identity changed')
    artifacts[key]=packed;builds+=1
   bindings.append((row['catalog_id'],obligation['dimension'],key))
 return {'artifacts':artifacts,'bindings':bindings,'builds':builds,'CPU_seconds':time.process_time()-started,'max_worker_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
def expected_bindings(rows):
 return sorted((r['catalog_id'],o['dimension'],hashlib.sha256(bytes_for({'family':r['family'],'obligation':o})).hexdigest()) for r in rows for o in r['obligation_dimensions'])
def join(parts,expected):
 artifacts={};bindings=[];builds=0
 for part in parts:
  for key,encoded in part['artifacts'].items():
   raw=zlib.decompress(encoded)
   if hashlib.sha256(raw).hexdigest()!=key:raise ValueError('Wrong encoded artifact identity')
   if key in artifacts and artifacts[key]!=encoded:raise ValueError('Conflicting exact pure artifact')
   artifacts[key]=encoded
  bindings.extend(part['bindings']);builds+=part['builds']
 if sorted(bindings)!=expected or len(set((x[0],x[1]) for x in bindings))!=len(expected):raise ValueError('Lossy, duplicated or wrong-ID obligation collapse rejected')
 if any(key not in artifacts for _,_,key in bindings):raise ValueError('Missing pure artifact')
 return {'artifacts':artifacts,'bindings':sorted(bindings),'physical_artifact_builds':builds}
def measure(rows,strategy,workers=4):
 expected=expected_bindings(rows);started=time.perf_counter();before=resource.getrusage(resource.RUSAGE_CHILDREN);cpu_start=time.process_time()
 if strategy=='sequential':parts=[worker((rows,False))]
 elif strategy=='parallel':
  chunks=[rows[i::workers] for i in range(workers)]
  with ProcessPoolExecutor(max_workers=workers) as pool:parts=list(pool.map(worker,[(c,False) for c in chunks if c]))
 elif strategy=='factored':parts=[worker((rows,True))]
 elif strategy=='factored_parallel':
  # Partition by family so an exact family/dimension artifact has one owner.
  families={}
  for row in rows:families.setdefault(row['family'],[]).append(row)
  groups=sorted(families.values(),key=len,reverse=True);chunks=[[] for _ in range(workers)]
  for group in groups:min(chunks,key=len).extend(group)
  with ProcessPoolExecutor(max_workers=workers) as pool:parts=list(pool.map(worker,[(c,True) for c in chunks if c]))
 else:raise ValueError('Unknown measured strategy')
 result=join(parts,expected);after=resource.getrusage(resource.RUSAGE_CHILDREN)
 # Child aggregate includes process lifecycle and OS-accounted children. RSS
 # is per-worker maximum, NOT an invented concurrent aggregate peak.
 cpu=time.process_time()-cpu_start+after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
 wall=time.perf_counter()-started
 report={'strategy':strategy,'passed':True,'wall_seconds':wall,'CPU_seconds':cpu,'max_worker_rss_kib':max(p['max_worker_rss_kib'] for p in parts),'RSS_is_not_concurrent_peak':True,
 'logical_ID_dimension_bindings':len(expected),'unique_artifacts':len(result['artifacts']),'physical_artifact_builds':result['physical_artifact_builds'],
 'encoded_CAS_bytes':sum(len(v) for v in result['artifacts'].values()),'raw_unique_artifact_bytes':sum(len(zlib.decompress(v)) for v in result['artifacts'].values()),'binding_serialization_bytes':len(bytes_for(result['bindings'])),
 'canonical_binding_sha256':digest(result['bindings']),'roundtrip_and_all_ID_joins_verified':True,'native_observations_replayed':0,'workers':1 if strategy in {'sequential','factored'} else workers}
 return report

def run(source_root,output,workers=4):
 from usl_systems.language import Interpreter
 from usl_systems.equations import evaluate
 from usl_systems.resources import discover
 from pools import capacity
 started=time.perf_counter();initial=addon_identity();admission=capacity(workers,64*1024**2);workers=admission['workers']
 rows=json.loads((Path(source_root)/'docs/ALL_LANGUAGE_ACTION_PLAN.json').read_text())['entries'];rows=sorted(rows,key=lambda r:r['catalog_id'])
 calibration=rows[::5];heldout=[r for i,r in enumerate(rows) if i%5]
 counts=sorted({n for n in (1,2,4,8,16,workers) if n<=capacity(16,64*1024**2)['workers']})
 trials=[('sequential',1),('factored',1)]+[(s,n) for n in counts if n>1 for s in ('parallel','factored_parallel')]
 strategies=[s+'/'+str(n) for s,n in trials];samples=[]
 # Strategy choice is frozen using calibration IDs only. Heldout results do
 # not change it, and every slower/failed route remains visible.
 for repetition in range(2):
  for key in strategies[repetition:]+strategies[:repetition]:
   strategy,count=key.split('/');sample=measure(calibration,strategy,int(count));sample['candidate']=key;sample['repetition']=repetition;samples.append(sample)
 costs={s:sum(r['wall_seconds'] for r in samples if r['candidate']==s)/2 for s in strategies};selected=min(strategies,key=lambda s:(costs[s],s));strategy,count=selected.split('/')
 heldout_reports=[measure(heldout,'sequential',1),measure(heldout,strategy,int(count))]
 if heldout_reports[0]['canonical_binding_sha256']!=heldout_reports[1]['canonical_binding_sha256']:raise ValueError('Heldout strategy intent mismatch')
 all_reports=[measure(rows,'sequential',1),measure(rows,strategy,int(count))]
 if all_reports[0]['canonical_binding_sha256']!=all_reports[1]['canonical_binding_sha256']:raise ValueError('All-ID strategy intent mismatch')
 # Negative success-collapse candidate: dropping the last binding must fail,
 # even though doing less work would appear faster.
 bad=worker((rows,True));bad['bindings']=bad['bindings'][:-1]
 try:join([bad],expected_bindings(rows));lossy_rejected=False
 except ValueError:lossy_rejected=True
 if not lossy_rejected:raise ValueError('Lossy success-collapse candidate admitted')
 measured=all_reports[1];baseline=all_reports[0]
 inputs={'logical':measured['logical_ID_dimension_bindings'],'executed':measured['physical_artifact_builds'],'baseline':baseline['wall_seconds'],'candidate':measured['wall_seconds'],'raw':measured['raw_unique_artifact_bytes'],'encoded':measured['encoded_CAS_bytes']}
 source=(Path(__file__).parent/'race_equations.usl').read_text()
 observed=Interpreter(capabilities={'race_measurements':lambda:inputs,'measured_speedup':lambda a,b:evaluate('speedup',{'baseline':a,'candidate':b})['result'],'measured_avoidance':lambda a,b:evaluate('work_avoidance',{'logical':a,'executed':b})['result'],'measured_collapse_ratio':lambda a,b:evaluate('collapse_ratio',{'raw':a,'encoded':b})['result']}).run(source)
 report={'schema':'usl.equation.strategy-race.v1','passed':True,'scope':'Pure all607-ID obligation/CAS preparation on this machine; no programming-language semantic qualification or native execution replay speedup is inferred.',
 'calibration_ids':[r['catalog_id'] for r in calibration],'heldout_ids':[r['catalog_id'] for r in heldout],'calibration_samples':samples,'declared_cost':'mean wall seconds including construction/serialization/hash/merge/audit; CPU/RSS/bytes Pareto alternatives retained',
 'selected_before_heldout':selected,'calibration_costs':costs,'resource_admission':admission,'physical_pool_sizes_measured':counts,'heldout':heldout_reports,'all_ID_race':all_reports,'slower_strategies_retained':True,'lossy_candidate_rejected':lossy_rejected,
 'actual_USL_equations':{'source':source,'stdout':observed.output,'variables':observed.variables,'operations':observed.operations},
 'additional_equations':{'exact_pure_work_saved':'logical_artifact_requests - physical_artifact_builds; every ID binding separately checked','fractal_family_cut':'partition whole family sets so an identical artifact has one owner; balance by actual set sizes','critical_path_lower_bound':'max(total_measured_CPU/workers, largest_indivisible_task); lower bound only, not an end-to-end prediction','scope_delta':'unique freshly qualified IDs minus previous IDs; never equate work avoided with languages qualified'},
 'addon_source_identity':initial,'source_unchanged_during_run':addon_identity()==initial,'end_to_end_seconds':time.perf_counter()-started,'entire_606_implementation_ETA_seconds':None}
 Path(output).write_text(json.dumps(report,indent=2)+'\n');return report
