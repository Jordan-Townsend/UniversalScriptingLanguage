
#line 1 "source.rl"
import std.stdio;

#line 2 "source.rl"


#line 4 "G2.d"
static const int item_start = 1;
static const int item_first_final = 3;
static const int item_error = 0;

static const int item_en_main = 1;


#line 4 "source.rl"
bool accepts(string input) {
const(char)* p=input.ptr; const(char)* pe=p+input.length; int cs;

#line 12 "G2.d"
	{
	cs = item_start;
	}

#line 7 "source.rl"

#line 15 "G2.d"
	{
	if ( p == pe )
		goto _test_eof;
	switch ( cs )
	{
case 1:
	if ( (*p) == 97u )
		goto st2;
	goto st0;
st0:
cs = 0;
	goto _out;
st2:
	if ( ++p == pe )
		goto _test_eof2;
case 2:
	if ( (*p) == 98u )
		goto st3;
	goto st0;
st3:
	if ( ++p == pe )
		goto _test_eof3;
case 3:
	goto st0;
		default: break;
	}
	_test_eof2: cs = 2; goto _test_eof; 
	_test_eof3: cs = 3; goto _test_eof; 

	_test_eof: {}
	_out: {}
	}

#line 8 "source.rl"
return cs >= item_first_final && p==pe;
}
void main(){writeln(accepts("ab") ? 1 : 0);}
