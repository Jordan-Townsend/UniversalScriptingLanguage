
#line 1 "source.rl"
import std.stdio;

#line 2 "source.rl"


#line 4 "F1.d"
static const char[] _item_trans_keys = [
	0u, 0u, 97u, 97u, 98u, 98u, 0u, 0u, 0
];

static const byte[] _item_key_spans = [
	0, 1, 1, 0
];

static const byte[] _item_index_offsets = [
	0, 0, 2, 4
];

static const byte[] _item_indicies = [
	0, 1, 2, 1, 1, 0
];

static const byte[] _item_trans_targs = [
	2, 0, 3
];

static const int item_start = 1;
static const int item_first_final = 3;
static const int item_error = 0;

static const int item_en_main = 1;


#line 4 "source.rl"
bool accepts(string input) {
const(char)* p=input.ptr; const(char)* pe=p+input.length; int cs;

#line 32 "F1.d"
	{
	cs = item_start;
	}

#line 7 "source.rl"

#line 35 "F1.d"
	{
	int _slen;
	int _trans;
	char* _keys;
	byte* _inds;
	if ( p == pe )
		goto _test_eof;
	if ( cs == 0 )
		goto _out;
_resume:
	_keys = &_item_trans_keys[(cs<<1)];
	_inds = &_item_indicies[_item_index_offsets[cs]];

	_slen = _item_key_spans[cs];
	_trans = _inds[ _slen > 0 && _keys[0] <=(*p) &&
		(*p) <= _keys[1] ?
		(*p) - _keys[0] : _slen ];

	cs = _item_trans_targs[_trans];

	if ( cs == 0 )
		goto _out;
	if ( ++p != pe )
		goto _resume;
	_test_eof: {}
	_out: {}
	}

#line 8 "source.rl"
return cs >= item_first_final && p==pe;
}
void main(){writeln(accepts("ab") ? 1 : 0);}
