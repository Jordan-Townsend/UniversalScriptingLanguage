
#line 1 "source.rl"
import std.stdio;

#line 2 "source.rl"


#line 4 "T0.d"
static const byte[] _item_key_offsets = [
	0, 0, 1, 2
];

static const char[] _item_trans_keys = [
	97u, 98u, 0
];

static const byte[] _item_single_lengths = [
	0, 1, 1, 0
];

static const byte[] _item_range_lengths = [
	0, 0, 0, 0
];

static const byte[] _item_index_offsets = [
	0, 0, 2, 4
];

static const byte[] _item_trans_targs = [
	2, 0, 3, 0, 0, 0
];

static const int item_start = 1;
static const int item_first_final = 3;
static const int item_error = 0;

static const int item_en_main = 1;


#line 4 "source.rl"
bool accepts(string input) {
const(char)* p=input.ptr; const(char)* pe=p+input.length; int cs;

#line 36 "T0.d"
	{
	cs = item_start;
	}

#line 7 "source.rl"

#line 39 "T0.d"
	{
	int _klen;
	uint _trans;
	char* _keys;

	if ( p == pe )
		goto _test_eof;
	if ( cs == 0 )
		goto _out;
_resume:
	_keys = &_item_trans_keys[_item_key_offsets[cs]];
	_trans = _item_index_offsets[cs];

	_klen = _item_single_lengths[cs];
	if ( _klen > 0 ) {
		char* _lower = _keys;
		char* _mid;
		char* _upper = _keys + _klen - 1;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + ((_upper-_lower) >> 1);
			if ( (*p) < *_mid )
				_upper = _mid - 1;
			else if ( (*p) > *_mid )
				_lower = _mid + 1;
			else {
				_trans += cast(uint)(_mid - _keys);
				goto _match;
			}
		}
		_keys += _klen;
		_trans += _klen;
	}

	_klen = _item_range_lengths[cs];
	if ( _klen > 0 ) {
		char* _lower = _keys;
		char* _mid;
		char* _upper = _keys + (_klen<<1) - 2;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + (((_upper-_lower) >> 1) & ~1);
			if ( (*p) < _mid[0] )
				_upper = _mid - 2;
			else if ( (*p) > _mid[1] )
				_lower = _mid + 2;
			else {
				_trans += cast(uint)((_mid - _keys)>>1);
				goto _match;
			}
		}
		_trans += _klen;
	}

_match:
	cs = _item_trans_targs[_trans];

	if ( cs == 0 )
		goto _out;
	if ( ++p != pe )
		goto _resume;
	_test_eof: {}
	_out: {}
	}

#line 8 "source.rl"
return cs >= item_first_final && p==pe;
}
void main(){writeln(accepts("ab") ? 1 : 0);}
