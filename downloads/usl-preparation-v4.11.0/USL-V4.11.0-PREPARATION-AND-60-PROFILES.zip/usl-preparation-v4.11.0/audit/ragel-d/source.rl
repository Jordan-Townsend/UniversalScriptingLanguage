import std.stdio;
%%{ machine item; main := 'ab'; }%%
%% write data;
bool accepts(string input) {
const(char)* p=input.ptr; const(char)* pe=p+input.length; int cs;
%% write init;
%% write exec;
return cs >= item_first_final && p==pe;
}
void main(){writeln(accepts("ab") ? 1 : 0);}
