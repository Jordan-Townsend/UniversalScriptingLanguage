"""USL owns the dependency/control loop; adapters launch bounded stage CLIs.

Ready independent stages start immediately. Each completion unlocks dependents
without waiting for a batch. Source, per-stage files and failure evidence remain.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
import hashlib,json,subprocess,sys,time
from prepare import addon_identity
from usl_systems.language import Interpreter
STAGES=[{'name':'test','dependencies':[]},{'name':'skills','dependencies':[]},
 {'name':'prepare','dependencies':['test','skills']},{'name':'transfer','dependencies':['test','skills']},
 {'name':'qualify','dependencies':['prepare']},{'name':'race','dependencies':['prepare']},
 {'name':'tables','dependencies':['qualify','race']}]
def run(args):
 root=Path(__file__).parent;output=args.output;stage_dir=output/'workflow-stages';stage_dir.mkdir(parents=True,exist_ok=True);started=time.monotonic();initial=addon_identity();events=[];active={};launched=set();results={}
 with ThreadPoolExecutor(max_workers=len(STAGES)) as waits:
  def launch(name):
   if name not in {r['name'] for r in STAGES} or name in launched:raise ValueError('Unknown/duplicate workflow stage')
   # Independent adapter check prevents USL policy/source mutation from
   # skipping a prerequisite or reordering an unsafe release gate.
   required=next(s['dependencies'] for s in STAGES if s['name']==name)
   if not set(required).issubset(results):raise ValueError('Workflow dependency gate violated')
   report=stage_dir/(name+'.json');log=(stage_dir/(name+'.log')).open('w')
   command=[sys.executable,str(root/'run.py'),'--source-root',str(args.source_root),'--mode',name,'--output',str(output),'--reference-cache',str(args.reference_cache),'--stage-report',str(report),'--i-allow-execution']
   if args.offline:command.append('--offline')
   if args.workers is not None:command+=['--workers',str(args.workers)]
   process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   future=waits.submit(process.wait);active[future]=(name,process,log,report);launched.add(name);events.append({'event':'started','stage':name,'pid':process.pid,'elapsed_seconds':time.monotonic()-started});return {'launched':True}
  def next_event():
   if not active:raise ValueError('Workflow deadlock: no eligible running stage')
   finished,_=wait(active,return_when=FIRST_COMPLETED);future=next(iter(finished));name,process,log,path=active.pop(future);code=future.result();log.close()
   observed=json.loads(path.read_text()) if code==0 and path.exists() else None;passed=code==0 and observed is not None
   if passed:results[name]=observed
   event={'stage':name,'passed':passed,'returncode':code,'elapsed_seconds':time.monotonic()-started,'report':str(path)};events.append({'event':'completed',**event});return event
  def finish():
   if set(results)!={s['name'] for s in STAGES} or active or addon_identity()!=initial:raise ValueError('Incomplete/changed workflow')
   summary=results['tables']['backlog'];return {'passed':True,**summary}
  source=(root/'workflow.usl').read_text()
  try:observed=Interpreter(capabilities={'workflow_stages':lambda:STAGES,'launch_workflow_stage':launch,'next_workflow_event':next_event,'finish_workflow':finish},timeout=3600,max_ops=100000).run(source)
  finally:
   # Already-running independent checks are allowed to finish and retain logs;
   # their own native adapters enforce deadlines and owned process cleanup.
   for future,(name,process,log,path) in list(active.items()):future.result();log.close()
 flat={}
 for stage in results.values():flat.update(stage)
 report={**flat,'schema':'usl.entire-workflow.v1','passed':True,'actual_USL_control':{'source':'workflow.usl','sha256':hashlib.sha256(source.encode()).hexdigest(),'stdout':observed.output,'operations':observed.operations},'stages':STAGES,'events':events,'stage_summaries':results,'backlog':results['tables']['backlog'],'elapsed_seconds':time.monotonic()-started,'source_identity':initial,'source_unchanged_during_run':addon_identity()==initial,'independent_ready_stages_overlap':True,'fixed_stage_rounds':False}
 (output/'workflow.json').write_text(json.dumps(report,indent=2)+'\n');(output/'run-summary.json').write_text(json.dumps(report,indent=2)+'\n');return report
