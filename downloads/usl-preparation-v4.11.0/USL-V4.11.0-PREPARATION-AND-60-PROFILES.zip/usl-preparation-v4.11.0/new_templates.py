"""Actual Smarty4/Twig3/VelocityJS engines, scoped finite integer templates."""
from pathlib import Path
import ast,copy,hashlib,itertools,json,os,re,shutil,tempfile
from native_profiles import PREFIX
from usl_systems.bounded_process import execute
from usl_systems.language import Interpreter,parse
from usl_systems.semantic_templates import _host_validate,TemplateError,digest

ENGINES={'smarty':{'smarty','css+smarty','html+smarty','javascript+smarty','xml+smarty'},
 'twig':{'twig','html+twig'},'velocity':{'velocity','html+velocity','xml+velocity'}}
LANGUAGES=set.union(*ENGINES.values());ENGINE={n:e for e,ids in ENGINES.items() for n in ids}
PATTERNS={'smarty':r'\{\$([nm])\}','twig':r'\{\{ ([nm]) \}\}','velocity':r'\$\{([nm])\}'}
PHP_EXTENSIONS=Path(os.environ.get('USL_PHP_EXTENSION_DIR','/workspace/.onboarding/sysroot/usr/lib/php/20240924'))
def host(language):return language.split('+')[0] if '+' in language else 'text'
def fixture(language):
 engine=ENGINE[language];markers={'smarty':('{$n}','{$m}'),'twig':('{{ n }}','{{ m }}'),'velocity':('${n}','${m}')}
 a,b=markers[engine]
 left,middle,right={'text':('value=', '; other=', '.'),'xml':('<root><n>','</n><m>','</m></root>'),'html':('<p>value=', '; other=', '.</p>'),'css':('.box { left: ', 'px; top: ', 'px; }'),'javascript':('const n = ', '; const m = ', ';')}[host(language)]
 return left+a+middle+b+right,[{'literal':left},{'variable':'n'},{'literal':middle},{'variable':'m'},{'literal':right}]
def parts(language,source):
 # The entire canonical fixture is the admitted source grammar in this first
 # profile. The value domain is dynamic and exhaustively executed below.
 if source!=fixture(language)[0]:raise TemplateError('Unmodelled template source rejected')
 result=[];last=0
 for m in re.finditer(PATTERNS[ENGINE[language]],source):
  if m.start()>last:result.append({'literal':source[last:m.start()]})
  result.append({'variable':m[1]});last=m.end()
 if last<len(source):result.append({'literal':source[last:]})
 return result
def dependency_identity(language):
 engine=ENGINE[language];paths={}
 if engine=='velocity':
  paths['node']=Path(shutil.which('node'));paths['lock']=PREFIX/'node/package-lock.json'
  for p in (PREFIX/'node/node_modules').rglob('*'):
   if p.is_file() and p.suffix in {'.js','.json'}:paths[str(p.relative_to(PREFIX))]=p
 else:
  paths['php']=Path(shutil.which('php'))
  for name in ('ctype.so','iconv.so'):paths[name]=PHP_EXTENSIONS/name
  for directory in (['smarty4'] if engine=='smarty' else ['Twig','Symfony/Contracts/Deprecation']):
   for p in (PREFIX/'sysroot/usr/share/php'/directory).rglob('*.php'):paths[str(p.relative_to(PREFIX))]=p
 return {'engine':engine,'files':{k:{'path':str(p.resolve()),'sha256':hashlib.sha256(p.resolve().read_bytes()).hexdigest()} for k,p in sorted(paths.items())},'complete_dependency_closure_qualified':False}
def original(language,source,contexts,admitted=True):
 if admitted:parts(language,source)
 engine=ENGINE[language]
 with tempfile.TemporaryDirectory(prefix='usl-v411-template-') as folder:
  p=Path(folder);(p/'input.json').write_text(json.dumps({'source':source,'contexts':contexts}))
  if engine=='velocity':
   code='const fs=require("fs"),v=require('+json.dumps(str(PREFIX/'node/node_modules/velocityjs'))+'),x=JSON.parse(fs.readFileSync("input.json","utf8"));\nconst ast=v.parse(x.source);const t=new v.Compile(ast);console.log(JSON.stringify(x.contexts.map(c=>t.render(c))));\n'
   (p/'run.js').write_text(code);argv=['node','run.js']
  else:
   code='<?php\n$x=json_decode(file_get_contents("input.json"),true,512,JSON_THROW_ON_ERROR); $out=[];\n'
   if engine=='smarty':
    code+='require '+json.dumps(str(PREFIX/'sysroot/usr/share/php/smarty4/Smarty.class.php'))+';\n$t=new Smarty(); $t->setCompileDir(getcwd());$t->setCacheDir(getcwd()); $t->caching=0; foreach($x["contexts"] as $ctx){ $t->clearAllAssign(); $t->assign($ctx); $out[]=$t->fetch("string:".$x["source"]); }\n'
   else:
    code+='require '+json.dumps(str(PREFIX/'sysroot/usr/share/php/Twig/autoload.php'))+';\n$env=new Twig\\Environment(new Twig\\Loader\\ArrayLoader(["source"=>$x["source"]]),["strict_variables"=>true,"autoescape"=>false,"cache"=>false]); $t=$env->load("source"); foreach($x["contexts"] as $ctx){$out[]=$t->render($ctx);}\n'
   code+='echo json_encode($out,JSON_THROW_ON_ERROR);\n';(p/'run.php').write_text(code)
   # Existing Debian PHP extensions, enabled only for this separate worker.
   argv=['php','-d','extension='+str(PHP_EXTENSIONS/'ctype.so'),'-d','extension='+str(PHP_EXTENSIONS/'iconv.so'),'run.php']
  r=execute(argv,cwd=p,timeout=20,max_output=1048576)
  if r['returncode']:raise TemplateError('Actual native template engine rejected source: '+r['stderr'][-1800:])
  try:outputs=json.loads(r['stdout'])
  except ValueError as e:raise TemplateError('Native template output protocol failed') from e
  if not isinstance(outputs,list) or len(outputs)!=len(contexts) or any(type(s) is not str for s in outputs):raise TemplateError('Native render cardinality/type failure')
  return outputs,{'process':r,'engine':engine,'original_renders':len(outputs),'fresh_native_worker_programs':1,'execution_evidence_replayed':False}
def translate(language,source,intent):
 segments=parts(language,source)
 if segments!=intent:raise TemplateError('Source template AST differs from independently supplied intent')
 expr=' + '.join(repr(s['literal']) if 'literal' in s else 'str('+s['variable']+')' for s in segments)
 code='function render(n, m):\n    return '+expr+'\n'
 from usl_systems.semantic_templates import _target_parts
 actual,names=_target_parts(parse(code))
 if actual!=segments or names!=['n','m']:raise TemplateError('Actual emitted USL AST differs from typed template intent')
 return code
def qualify_one(language):
 source,intent=fixture(language);code=translate(language,source,intent);identity=dependency_identity(language)
 contexts=[{'n':n,'m':m} for n,m in itertools.product(range(-9,10),repeat=2)]
 outputs,receipt=original(language,source,contexts);rows=[]
 for ctx,observed in zip(contexts,outputs):
  # Independent intent segments are authored by fixture, never derived from
  # original renderer output or a generated source program.
  expected=''.join(s['literal'] if 'literal' in s else str(ctx[s['variable']]) for s in intent)
  generated=Interpreter().run(code+'let result = render('+str(ctx['n'])+', '+str(ctx['m'])+')\n').variables['result']
  rows.append({'context':ctx,'native':observed,'generated_USL':generated,'independent_expected':expected,'passed':observed==generated==expected})
 positive=[]
 for index,expected in [(0,None),(180,None),(360,None)]:
  observed=outputs[index];value=rows[index]['generated_USL']
  left=_host_validate(host(language),observed);right=_host_validate(host(language),value)
  positive.append({'context':contexts[index],'original_host_processing':left,'generated_host_processing':right,'passed':left==right})
 negative=[]
 for label,src,want in [('effect',source+'#set($x=1)',intent),('wrong_intent',source,[{'literal':'wrong'}])]:
  try:translate(language,src,want);rejected=False
  except ValueError:rejected=True
  negative.append({'case':label,'rejected':rejected})
 bad={'smarty':'{$n + }','twig':'{{ n + }}','velocity':'#if('}[ENGINE[language]]
 try:original(language,bad,[{'n':1,'m':2}],admitted=False);rejected=False
 except ValueError as e:rejected=True;error=str(e)
 negative.append({'case':'actual_native_bad_syntax','rejected':rejected,'diagnostic':error if rejected else None})
 if dependency_identity(language)!=identity:raise TemplateError('Native provider changed during qualification')
 return {'catalog_id':language,'profile_kind':'template_processing','passed':all(r['passed'] for r in rows+positive) and all(r['rejected'] for r in negative),'source':source,'generated_USL_source':code,'independent_intent_segments':intent,'finite_domain':{'n':[-9,9],'m':[-9,9],'contexts':361,'observations':rows},'host_cases':positive,'negative_cases':negative,'native_executions':1,'original_engine_evaluations':361,'generated_USL_executions':361,'native_observations':[receipt],'provider_identity':identity,'full_standard_qualified':False,'scope':'Exact declared template with dynamic bounded two-integer substitutions; exhaustive361 actual original and generated USL executions plus actual host processing. Arbitrary template control/effects/escaping and host program execution remain unqualified.'}
