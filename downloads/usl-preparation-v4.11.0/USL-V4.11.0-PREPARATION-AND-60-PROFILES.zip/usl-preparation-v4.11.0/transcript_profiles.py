"""Category processing for29 original transcript/log IDs, NOT code execution.

These authored parsers preserve declared structured observations. A displayed
command/result is data: this module never claims the logged program was run.
"""
import ast,base64,copy,hashlib,importlib.metadata,json,re,sys
from pathlib import Path
from usl_systems.semantic_documents import DocumentFrontend,DocumentError,typed,digest
from usl_systems.language import Interpreter

PROMPTS={'console':'$ ','doscon':'C:\\>','dylan-console':'? ','jlcon':'julia> ',
 'matlabsession':'>> ','psql':'db=> ','psysh':'>>> ','pwsh-session':'PS C:\\> ',
 'sqlite3':'sqlite> ','tcshcon':'% '}
OBJDUMP={'objdump','c-objdump','cpp-objdump','d-objdump'}
LANGUAGES=set(PROMPTS)|OBJDUMP|{'objdump-nasm','asc','dpatch','irc','kmsg','notmuch','output',
 'postgres-explain','py2tb','pytb','pypylog','raw-token-data','tap','vctreestatus','wdiff'}
def require(condition,message='Source outside declared transcript grammar'):
 if not condition:raise DocumentError(message)
def match(pattern,source):
 m=re.fullmatch(pattern,source);require(m is not None);return m
def crc24(data):
 crc=0xb704ce
 for byte in data:
  crc^=byte<<16
  for _ in range(8):
   crc<<=1
   if crc&0x1000000:crc^=0x1864cfb
 return crc&0xffffff

def native_process(language,source):
 require(language in LANGUAGES,'Unknown exact transcript ID')
 require(type(source) is str and 0<len(source.encode())<=16384 and '\0' not in source and '\r' not in source,'Bounded UTF-8 LF source required')
 if language in PROMPTS:
  lines=source.splitlines(keepends=True);require(len(lines)==2 and all(s.endswith('\n') for s in lines))
  require(lines[0].startswith(PROMPTS[language]));command=lines[0][len(PROMPTS[language]):-1];output=lines[1][:-1]
  require(bool(command) and not any(output.startswith(p) for p in PROMPTS.values()),'Single displayed prompt/output pair required')
  return {'prompt':PROMPTS[language],'displayed_input':command,'displayed_output':output,'logged_program_executed':False}
 if language in OBJDUMP:
  m=match(r'([0-9a-f]+):\t([0-9a-f]{2}(?: [0-9a-f]{2})*)\t([a-z][a-z0-9]*(?: [a-z0-9, %$()+*-]+)?)\n',source)
  return {'address':int(m[1],16),'bytes':list(bytes.fromhex(m[2])),'displayed_instruction':m[3]}
 if language=='objdump-nasm':
  m=match(r'([0-9A-F]{8})  ([0-9A-F]{2}(?:[0-9A-F]{2})*)  ([a-z][a-z0-9]*(?: [a-z0-9, +*-]+)?)\n',source)
  return {'address':int(m[1],16),'bytes':list(bytes.fromhex(m[2])),'displayed_instruction':m[3]}
 if language=='output':return {'displayed_text':source}
 if language=='kmsg':
  m=match(r'(0|[1-9][0-9]*),(0|[1-9][0-9]*),(0|[1-9][0-9]*),([-c]);([^\n]*)\n',source)
  priority=int(m[1]);require(priority<=191,'Kernel syslog priority0..191 required')
  return {'facility':priority//8,'level':priority%8,'sequence':int(m[2]),'timestamp_microseconds':int(m[3]),'flags':m[4],'message':m[5]}
 if language=='irc':
  m=match(r':([a-z][a-z0-9]*)!([a-z][a-z0-9]*)@([a-z0-9.]+) PRIVMSG (#[a-z][a-z0-9]*) :([^\n]*)\n',source)
  return {'nick':m[1],'user':m[2],'host':m[3],'command':'PRIVMSG','target':m[4],'trailing':m[5]}
 if language in {'pytb','py2tb'}:
  m=match(r'Traceback \(most recent call last\):\n  File "([a-z0-9_./-]+)", line ([1-9][0-9]*), in ([a-z_][a-z_0-9]*|<module>)\n    ([^\n]+)\n([A-Za-z][A-Za-z0-9]*): ([^\n]*)\n',source)
  return {'frames':[{'file':m[1],'line':int(m[2]),'function':m[3],'displayed_source':m[4]}],'exception_type':m[5],'message':m[6]}
 if language=='pypylog':
  m=match(r'\[([0-9a-f]+)\] \{([a-z][a-z0-9-]*)\n([^\n]*)\n\[([0-9a-f]+)\] ([a-z][a-z0-9-]*)}\n',source)
  require(m[2]==m[5] and int(m[4],16)>=int(m[1],16),'Mismatched/unordered log interval')
  return {'category':m[2],'start_ticks':int(m[1],16),'end_ticks':int(m[4],16),'displayed_payload':m[3]}
 if language=='raw-token-data':
  from pygments.lexers.special import RawTokenLexer
  from pygments.token import STANDARD_TYPES,string_to_tokentype
  m=match(r'(Token(?:\.[A-Za-z]+)*)\t([^\n]+)\n',source);token=string_to_tokentype(m[1]);require(token in STANDARD_TYPES,'Known Pygments token required')
  try:value=ast.literal_eval(m[2])
  except (ValueError,SyntaxError) as e:raise DocumentError('Invalid literal token payload') from e
  require(type(value) is str)
  result=[{'type':str(t),'text':text} for _,t,text in RawTokenLexer().get_tokens_unprocessed(source)]
  require(result==[{'type':m[1],'text':value}],'Native RawTokenLexer disagrees with record syntax');return result
 if language=='tap':
  lines=source.splitlines();require(len(lines)==3 and lines[0]=='TAP version 13' and lines[1]=='1..1','Single-result TAP13 plan required')
  m=match(r'(ok|not ok) 1 - ([A-Za-z0-9 _-]+?)(?: # (SKIP|TODO) ([A-Za-z0-9 _-]+))?',lines[2])
  return {'version':13,'plan':[1,1],'tests':[{'number':1,'ok':m[1]=='ok','description':m[2],'directive':m[3],'reason':m[4]}]}
 if language=='postgres-explain':
  m=match(r'Seq Scan on ([a-z_][a-z_0-9]*)  \(cost=([0-9]+\.[0-9]{2})\.\.([0-9]+\.[0-9]{2}) rows=(0|[1-9][0-9]*) width=(0|[1-9][0-9]*)\)\n',source)
  from decimal import Decimal
  require(Decimal(m[2])<=Decimal(m[3]),'Ordered planner cost range required')
  return {'node':'Seq Scan','relation':m[1],'startup_cost':m[2],'total_cost':m[3],'rows':int(m[4]),'width':int(m[5])}
 if language=='notmuch':
  m=match(r'thread:([0-9a-f]{16}) ([0-9]{4}-[0-9]{2}-[0-9]{2}) \[([1-9][0-9]*)/([1-9][0-9]*)\] ([^;\n]+); ([^()\n]+) \(([a-z ]+)\)\n',source)
  from datetime import date
  try:date.fromisoformat(m[2])
  except ValueError as e:raise DocumentError('Invalid ISO date') from e
  require(int(m[3])<=int(m[4]),'Matched messages exceed total')
  return {'thread':m[1],'date':m[2],'matched':int(m[3]),'total':int(m[4]),'authors':m[5],'subject':m[6],'tags':m[7].split()}
 if language=='vctreestatus':
  m=match(r'([AMD])   ([a-z][a-z0-9_./-]*)\n',source);require('..' not in m[2].split('/'),'Parent-path observations outside contract')
  return {'status':m[1],'path':m[2]}
 if language=='wdiff':
  m=match(r'([^\[\]{}]*?)\[-([^\[\]{}]*)-\]\{\+([^\[\]{}]*)\+\}([^\[\]{}]*)',source)
  return {'common_prefix':m[1],'removed':m[2],'added':m[3],'common_suffix':m[4]}
 if language=='asc':
  m=match(r'-----BEGIN PGP MESSAGE-----\n\n([A-Za-z0-9+/]+={0,2})\n=([A-Za-z0-9+/]{4})\n-----END PGP MESSAGE-----\n',source)
  try:data=base64.b64decode(m[1],validate=True);checksum=base64.b64decode(m[2],validate=True)
  except ValueError as e:raise DocumentError('Invalid armor base64') from e
  require(crc24(data)==int.from_bytes(checksum,'big'),'OpenPGP armor CRC24 mismatch')
  return {'armor_type':'PGP MESSAGE','decoded_bytes':list(data),'checksum_verified':True,'decryption_or_packet_semantics_qualified':False}
 if language=='dpatch':
  header='#! /bin/sh /usr/share/dpatch/dpatch-run\n@DPATCH@\n';require(source.startswith(header),'Inert dpatch wrapper required')
  from unidiff import PatchSet
  try:files=PatchSet(source[len(header):])
  except Exception as e:raise DocumentError('Native unidiff rejected payload') from e
  require(len(files)==1 and len(files[0])==1,'One file/hunk required')
  f=files[0];h=f[0]
  return {'source':f.source_file,'target':f.target_file,'source_start':h.source_start,'target_start':h.target_start,'changes':[[r.line_type,r.value] for r in h],'wrapper_executed':False}
 raise DocumentError('Missing category processor')

class TranscriptFrontend(DocumentFrontend):
 def __init__(self,language,source,contract):
  require(type(contract) is dict and contract.get('schema')=='usl.intent.document.v1' and contract.get('intent') and 'expected' in contract,'Independent category intent required')
  self.language,self.source,self.contract=language,source,copy.deepcopy(contract);self.value=native_process(language,source)
  self.ir={'schema':'usl.transcript.typed-observations.v1','catalog_id':language,'value':typed(self.value),'source_sha256':digest(source)}
  require(typed(self.value)==typed(contract['expected']),'Authored native processor disagrees with independently declared intent');self.admission=self.identity()
 def verify(self):
  self.check();t=self.translate();observed=native_process(self.language,self.source);generated=Interpreter().run(t['code']).variables['result']
  return {'passed':typed(observed)==typed(generated)==typed(self.contract['expected']),'source':self.source,'translation':t,'native_observed':observed,'generated_USL_observed':generated,'independent_expected':self.contract['expected'],'original_engine_evaluations':1,'generated_USL_executions':1,'execution_evidence_replayed':False}

FIXTURES={
 **{n:(p+'echo alpha\nalpha\n',{'prompt':p,'displayed_input':'echo alpha','displayed_output':'alpha','logged_program_executed':False}) for n,p in PROMPTS.items()},
 **{n:('0:\t90\tnop\n',{'address':0,'bytes':[144],'displayed_instruction':'nop'}) for n in OBJDUMP},
 'objdump-nasm':('00000000  90  nop\n',{'address':0,'bytes':[144],'displayed_instruction':'nop'}),
 'asc':('-----BEGIN PGP MESSAGE-----\n\nYWJj\n=uhx7\n-----END PGP MESSAGE-----\n',{'armor_type':'PGP MESSAGE','decoded_bytes':[97,98,99],'checksum_verified':True,'decryption_or_packet_semantics_qualified':False}),
 'irc':(':nick!user@host PRIVMSG #usl :alpha\n',{'nick':'nick','user':'user','host':'host','command':'PRIVMSG','target':'#usl','trailing':'alpha'}),
 'kmsg':('6,123,456,-;alpha\n',{'facility':0,'level':6,'sequence':123,'timestamp_microseconds':456,'flags':'-','message':'alpha'}),
 'notmuch':('thread:0123456789abcdef 2026-01-02 [1/2] Alice; alpha (inbox unread)\n',{'thread':'0123456789abcdef','date':'2026-01-02','matched':1,'total':2,'authors':'Alice','subject':'alpha','tags':['inbox','unread']}),
 'output':('alpha\n',{'displayed_text':'alpha\n'}),
 'postgres-explain':('Seq Scan on items  (cost=0.00..1.00 rows=1 width=4)\n',{'node':'Seq Scan','relation':'items','startup_cost':'0.00','total_cost':'1.00','rows':1,'width':4}),
 **{n:('Traceback (most recent call last):\n  File "item.py", line 3, in <module>\n    raise ValueError("alpha")\nValueError: alpha\n',{'frames':[{'file':'item.py','line':3,'function':'<module>','displayed_source':'raise ValueError("alpha")'}],'exception_type':'ValueError','message':'alpha'}) for n in ('pytb','py2tb')},
 'pypylog':('[abc] {jit-log-opt\nalpha\n[abd] jit-log-opt}\n',{'category':'jit-log-opt','start_ticks':2748,'end_ticks':2749,'displayed_payload':'alpha'}),
 'raw-token-data':("Token.Keyword\t'return'\n",[{'type':'Token.Keyword','text':'return'}]),
 'tap':('TAP version 13\n1..1\nok 1 - alpha\n',{'version':13,'plan':[1,1],'tests':[{'number':1,'ok':True,'description':'alpha','directive':None,'reason':None}]}),
 'vctreestatus':('M   src/item.py\n',{'status':'M','path':'src/item.py'}),
 'wdiff':('a [-old-]{+new+} z\n',{'common_prefix':'a ','removed':'old','added':'new','common_suffix':' z\n'}),
 'dpatch':('#! /bin/sh /usr/share/dpatch/dpatch-run\n@DPATCH@\n--- a/item\n+++ b/item\n@@ -1 +1 @@\n-old\n+new\n',{'source':'a/item','target':'b/item','source_start':1,'target_start':1,'changes':[['-','old\n'],['+','new\n']],'wrapper_executed':False})}
assert set(FIXTURES)==LANGUAGES and len(LANGUAGES)==29

def dependency_identity(language):
 providers={}
 for name in (['Pygments'] if language=='raw-token-data' else ['unidiff'] if language=='dpatch' else []):
  d=importlib.metadata.distribution(name);providers[name]={'version':d.version,'RECORD_sha256':digest(d.read_text('RECORD') or '')}
 return {'authored_processor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python_executable_sha256':hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest(),'python_version':sys.version,'providers':providers,'category_native_host':'Python processing; displayed programs are not executed','complete_standard_qualified':False}

def qualify_one(language):
 source,expected=FIXTURES[language];contract={'schema':'usl.intent.document.v1','intent':'Independently authored exact structured log observations; displayed programs are data','expected':expected}
 f=TranscriptFrontend(language,source,contract);cases=[f.verify()];negative=[]
 for label,bad,c in [('NUL',source+'\0',contract),('wrong_intent',source,{**contract,'expected':{'wrong':91}})]:
  try:TranscriptFrontend(language,bad,c);rejected=False
  except ValueError:rejected=True
  negative.append({'case':label,'rejected':rejected})
 # A second actual source/value is independent of the first fixture. Output
 # text is the only profile where arbitrary bounded text is intentionally data.
 if language=='output':second=('beta\n',{'displayed_text':'beta\n'})
 elif 'alpha' in source:
  second=(source.replace('alpha','beta'),json.loads(json.dumps(expected).replace('alpha','beta')))
 else:second=None
 if second:cases.append(TranscriptFrontend(language,second[0],{**contract,'expected':second[1]}).verify())
 if language!='output':
  try:native_process(language,'INVALID');rejected=False
  except ValueError:rejected=True
  negative.append({'case':'actual_processor_invalid_syntax','rejected':rejected})
 mutated=copy.copy(f);mutated.source+='x'
 try:mutated.translate();rejected=False
 except ValueError:rejected=True
 negative.append({'case':'mutated_admission','rejected':rejected})
 return {'catalog_id':language,'profile_kind':'transcript_processing','passed':all(c['passed'] for c in cases) and all(c['rejected'] for c in negative),'cases':cases,'negative_cases':negative,'original_engine_evaluations':len(cases),'generated_USL_executions':len(cases),'native_executions':0,'provider_identity':dependency_identity(language),'full_standard_qualified':False,'scope':'Authored bounded category grammar and typed structured observation preservation, actual native Python processor and generated USL execution. Logged/displayed programs are not executed, translated, or certified; full format/category standards remain unqualified.'}
